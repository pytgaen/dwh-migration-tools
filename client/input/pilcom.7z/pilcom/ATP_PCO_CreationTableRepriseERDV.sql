--$HEADER: %HEADER%
------------------------------------------------------------------------------------------------------------------------
--                                                                                                                                                             -
-- NOM FICHIER  : $Workfile:   ATP_PCO_CreationTableRepriseERDV.sql                                                          -
-- TYPE         : Script SQL                                                                                                                   -
-- DESCRIPTION  : Script de création des Tables de reprise ERDV                                           -
--                                                                                                                                                             -
------------------------------------------------------------------------------------------------------------------------
--                HISTORIQUE                                                                                                                   -
--                                                                                                                                                             -
-- DATE           AUTEUR      CREATION/MODIFICATION                                                                                    -
-- 18/11/2019      TCL          Creation
------------------------------------------------------------------------------------------------------------------------

.set width 2000

/*==============================================================*/
/* Table : REP_O_ORDER_ERDV_COM                          */
/*==============================================================*/
.LABEL CREATE1
sel 1 from dbc.tablesV where tablename ='REP_O_ORDER_ERDV_COM' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO CREATE2
.if errorcode <> 0 then .quit 1

Create Multiset Table ${KNB_PCO_TMP}.REP_O_ORDER_ERDV_COM (
MSG_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant du message' NOT NULL,
EXTERNAL_ORDER_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant de la commande' NOT NULL,
ORDER_DEPOSIT_TS TIMESTAMP(0) TITLE 'Date de dÃ©pÃ´t de la commande' NOT NULL,
ORDER_VALIDATION_TS TIMESTAMP(0) TITLE 'Date de validation de la commande' COMPRESS ,
AGENT_ID CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code alliance vendeur' NOT NULL,
ACTIVITY_UNIT_CD VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'UnitÃ© d activite du vendeur' NOT NULL,
CUSTOMER_LAST_NAME_NM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nom ou raison sociale du client',
CUSTOMER_MARKET_SEG_CD CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'segment de marchÃ©' COMPRESS ('M','P','R','X'),
CONTACT_CIVILITY_NM VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'civilitÃ© de l interlocuteur',
CONTACT_LAST_NAME_NM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nom de l interlocuteur',
CONTACT_FIRST_NAME_NM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'PrÃ©nom  de l interlocuteur',
CONTACT_MOBILE_NUMBER_NU VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'NumÃ©ro mobile de l interlocuteur',
CONTACT_TEL_NUMBER_NU VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'NumÃ©ro telephone de l interlocuteur',
OBSERVATIONS_CONTACT_DS VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Observations du contact',
REF_GROUPED_OFFER_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
INTERVENTION_ID VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant intervention',
GPC_ID VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant GPC',
STATUS_INTERVENTION_CD VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Etat de l intervention',
DATE_RESERVATION_TS TIMESTAMP(0) TITLE 'Date de reservation',
DATE_BEGIN_TS TIMESTAMP(0) TITLE 'Date de dÃ©but de plage',
OBSERVATIONS_INTERVENTION_DS VARCHAR(500) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Questionnaire technique et observations contact',
REF_ERDV_CD VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'RÃ©fÃ©rence eRDV' NOT NULL,
NB_LINE_ORDER_NU INTEGER TITLE 'Nombre de lignes de commande eRDV',
NB_LINE_OPER_NU INTEGER TITLE 'Nombre de lignes d operation programme',
ORDER_COMPLETED_IN BYTEINT TITLE 'Indicateur Pour savoir si la commande est complete' NOT NULL,
QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion Tpt' NOT NULL)
PRIMARY INDEX NUPPI_ORD_O_ERDV_COM ( MSG_ID );
.if errorcode <> 0 then .quit 1;


/*==============================================================*/
/* Table : REP_O_ORDER_ERDV_LINE_COM                          */
/*==============================================================*/
.LABEL CREATE2
sel 1 from dbc.tablesV where tablename ='REP_O_ORDER_ERDV_LINE_COM' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO CREATE3
.if errorcode <> 0 then .quit 1

Create Multiset Table ${KNB_PCO_TMP}.REP_O_ORDER_ERDV_LINE_COM (
MSG_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant du message' NOT NULL,
      EXTERNAL_ORDER_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant de la commande' NOT NULL,
      ORDER_DEPOSIT_TS TIMESTAMP(0) TITLE 'Date de dépôt de la commande' NOT NULL,
      ORDER_LINE_EXTERNAL_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant de la ligne de commande' NOT NULL,
      ORDER_LINE_STATUS_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Etat de la ligne de commande',
      ORDER_LINE_CONTRACT_DATE_TS TIMESTAMP(0) TITLE 'Date contractuelle de la ligne de commande',
      ORDER_LINE_WANTED_DATE_TS TIMESTAMP(0) TITLE 'Date souhaitée de la ligne de commande',
      ORDER_LINE_PREST_CD VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code prestation',
      ORDER_LINE_QUANTITY_QT DECIMAL(10,1) TITLE 'Quantité' NOT NULL,
      ORDER_LINE_AMOUNT_AM DECIMAL(15,2) TITLE 'Montant (hors taxe)',
      ORDER_LINE_TVA_RT DECIMAL(5,2) TITLE 'Taux de TVA',
      ORDER_LINE_OPER_CD VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Référence opération ponctuelle',
      CUSTOMER_MARKET_SEG_CD CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Segment de marché',
      CUSTOMER_LAST_NAME_NM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nom ou raison sociale du client livré',
      CUSTOMER_ADDRESS_APPT_NM VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant appartement du client livré',
      CUSTOMER_ADDRESS_ESC_NM VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Escalier du client livré',
      CUSTOMER_ADDRESS_STAGE_NM VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Etage du client livré',
      CUSTOMER_ADDRESS_BAT_NM VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Bâtiment du client livré',
      CUSTOMER_ADDRESS_RESIDENCE_NM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Résidence du client livré',
      CUSTOMER_ADDRESS_ZIPCODE_CD VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code postal adresse du client livré',
      CUSTOMER_ADDRESS_NUMBER_NU VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Numéro dans la voie du client livré',
      CUSTOMER_ADDRESS_STR_TYPE_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Type de voie du client livré',
      CUSTOMER_ADDRESS_STREET_NM VARCHAR(140) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nom de la voie du client livré' NOT NULL,
      CUSTOMER_ADDRESS_CITY_NM VARCHAR(60) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nom de la Ville du client livré' NOT NULL,
      CUSTOMER_ADDRESS_INSEE_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code INSEE du client livré' NOT NULL,
      REF_OFFRE_CIBLE_CD VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code produit' NOT NULL,
      CATALOGUE_CD VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Catalogue Produit' NOT NULL,
      CUSTOMER_ND_NU VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'ND du client livré' NOT NULL,
      CUSTOMER_NDS_NU VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'ND ligne support',
      QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
      STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion Tpt' NOT NULL)
PRIMARY INDEX NUPPI_ORD_O_ERDV_LINE_COM ( MSG_ID );
.if errorcode <> 0 then .quit 1;

/*==============================================================*/
/* Table : REP_O_ORDER_ERDV_OPERATION                          */
/*==============================================================*/
.LABEL CREATE3
sel 1 from dbc.tablesV where tablename ='REP_O_ORDER_ERDV_OPERATION' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO FIN
.if errorcode <> 0 then .quit 1

Create Multiset Table ${KNB_PCO_TMP}.REP_O_ORDER_ERDV_OPERATION (

      MSG_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant du message' NOT NULL,
      EXTERNAL_ORDER_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant de la commande' NOT NULL,
      ORDER_DEPOSIT_TS TIMESTAMP(0) TITLE 'Date de dépôt de la commande' NOT NULL,
      ORDER_LINE_EXTERNAL_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant de la ligne de commande' NOT NULL,
      TYPE_OP_NM VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Type d operation',
      INTERVENTION_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant de l intervention',
      QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
      STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion Tpt' NOT NULL)
PRIMARY INDEX NUPPI_ORD_O_ERDV_OPER ( MSG_ID );
.if errorcode <> 0 then .quit 1



.LABEL FIN
.if errorcode <> 0 then .quit 1


