
--$HEADER:   %HEADER%
-------------------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DIGITAL_CAR_Alimentation_ELIG_JRC.sql  $                                       
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL  alimentation de la table ORD_W_CAR_ELIG_JRC_DIGITAL avec la table d'extraction de CAR
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 19/04/2019     SSI         Creation
-- 24/06/2019     JCR         Modif
-- 30/07/2019     GRH         Modif 

---------------------------------------------------------------------------------

.set width 5000
---des actes qui sont nouvellement integres dans la [Table des actes digitaux]
---------------------------------------
-- Table : ORD_W_CAR_ELIG_JRC_DIGITAL--
---------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_CAR_ELIG_JRC_DIGITAL;
.if errorcode <> 0 then .quit 1;

insert Into ${KNB_PCO_TMP}.ORD_W_CAR_ELIG_JRC_DIGITAL
( 
  CODE_PROCESS             ,
  INTRNL_SOURCE_ID         ,
  SOURCE_DS                ,
  ACT_ACTE_FAMILLE_KPI     ,
  ACTE_ID                  ,
  ACT_DT                   ,
  PAR_UNIFIED_PARTY_ID     ,
  PAR_PID_ID               ,
  PAR_CID_ID               ,
  IND_HD_TEMPO_CD          ,
  RAP_PID_ID               ,
  RAP_UNIFIED_PARTY_ID     ,
  INTRCTN_DT               ,
  DELAI                    ,
  ACTE_ID_INTRCTN          ,
  INTRCTN_ID               ,
  KEYGEN_CD                ,
  APPLI_SOURCE_ID          ,
  UNIFIED_PARTY_ID         ,
  PID_ID                   ,
  CID_ID                   ,
  INT_OPRTR_ID             ,
  ORG_AGENT_IOBSP          ,
  OPRTR_TEAM_HIERCH_ID     ,
  OPRTR_TEAM_ACTVT_ID      ,
  UNVRS_CD                 ,
  DIRCTN_CD                ,
  CHANL_CD                 ,
  MEDIA_CD                 ,
  ORIGN_CD                 ,
  WAY_CD                   ,
  REASN_CD                 ,
  REASN_DETL_CD            ,
  CONCLSN_CD               ,
  UNIFIED_SHOP_CD          ,
  ORG_REM_CHANNEL_CD       ,
  ORG_CHANNEL_CD           ,
  ORG_SUB_CHANNEL_CD       ,
  ORG_SUB_SUB_CHANNEL_CD   ,
  ORG_GT_ACTIVITY          ,
  ORG_FIDELISATION         ,
  ORG_WEB_ACTIVITY         ,
  ORG_AUTO_ACTIVITY        ,
  ORG_EDO_ID               ,
  ORG_TYPE_EDO             ,
  ORG_TEAM_LEVEL_1_CD      ,
  ORG_TEAM_LEVEL_1_DS      ,
  ORG_TEAM_LEVEL_2_CD      ,
  ORG_TEAM_LEVEL_2_DS      ,
  ORG_TEAM_LEVEL_3_CD      ,
  ORG_TEAM_LEVEL_3_DS      ,
  ORG_TEAM_LEVEL_4_CD      ,
  ORG_TEAM_LEVEL_4_DS      ,
  WORK_TEAM_LEVEL_1_CD     ,
  WORK_TEAM_LEVEL_1_DS     ,
  WORK_TEAM_LEVEL_2_CD     ,
  WORK_TEAM_LEVEL_2_DS     ,
  WORK_TEAM_LEVEL_3_CD     ,
  WORK_TEAM_LEVEL_3_DS     ,
  WORK_TEAM_LEVEL_4_CD     ,
  WORK_TEAM_LEVEL_4_DS     ,
  ANNUL_HD_DT              ,
  ANNUL_HD_DS              ,
  IND_HD_CD                ,
  IND_HD_RAP_CD            ,
  HD_RAP_DT                ,
  CLOSURE_DT               

)

select
    Case When CAR_EXTR.ORG_EDO_ID = 116019 And CAR_EXTR.ORG_CHANNEL_CD = 'DNU'
    Then 'Smartlife'
    Else 'Omnicanal'
  End                                 As CODE_PROCESS                    ,
  CAR_EXTR.INTRNL_SOURCE_ID           As INTRNL_SOURCE_ID                ,
  CAR_EXTR.SOURCE_DS                  As SOURCE_DS                       ,
  CAR_EXTR.ACT_ACTE_FAMILLE_KPI       As ACT_ACTE_FAMILLE_KPI            ,
  CAR_EXTR.ACTE_ID                    As ACTE_ID                         ,
  CAR_EXTR.ACT_DT                     As ACT_DT                          ,
  CAR_EXTR.PAR_UNIFIED_PARTY_ID       As PAR_UNIFIED_PARTY_ID            ,
  CAR_EXTR.PAR_PID_ID                 As PAR_PID_ID                      ,
  CAR_EXTR.PAR_CID_ID                 As PAR_CID_ID                      ,
  Null                                As IND_HD_TEMPO_CD                 ,
  Null                                As RAP_PID_ID                      ,
  Null                                As RAP_UNIFIED_PARTY_ID            ,
  Null                                As INTRCTN_DT                      ,
  Null                                As DELAI                           ,
  Null                                As ACTE_ID_INTRCTN                 ,
  Null                                As INTRCTN_ID                      ,
  Null                                As KEYGEN_CD                       ,
  Null                                As APPLI_SOURCE_ID                 ,
  Null                                As UNIFIED_PARTY_ID                ,
  Null                                As PID_ID                          ,
  Null                                As CID_ID                          ,
  Null                                As INT_OPRTR_ID                    ,
  Null                                As ORG_AGENT_IOBSP                 ,
  Null                                As OPRTR_TEAM_HIERCH_ID            ,
  Null                                As OPRTR_TEAM_ACTVT_ID             ,
  Null                                As UNVRS_CD                        ,
  Null                                As DIRCTN_CD                       ,
  Null                                As CHANL_CD                        ,
  Null                                As MEDIA_CD                        ,
  Null                                As ORIGN_CD                        ,
  Null                                As WAY_CD                          ,
  Null                                As REASN_CD                        ,
  Null                                As REASN_DETL_CD                   ,
  Null                                As CONCLSN_CD                      ,
  CAR_EXTR.UNIFIED_SHOP_CD            As UNIFIED_SHOP_CD                 ,
  CAR_EXTR.ORG_REM_CHANNEL_CD         As ORG_REM_CHANNEL_CD              ,
  CAR_EXTR.ORG_CHANNEL_CD             As ORG_CHANNEL_CD                  ,
  CAR_EXTR.ORG_SUB_CHANNEL_CD         As ORG_SUB_CHANNEL_CD              ,
  CAR_EXTR.ORG_SUB_SUB_CHANNEL_CD     As ORG_SUB_SUB_CHANNEL_CD          ,
  CAR_EXTR.ORG_GT_ACTIVITY            As ORG_GT_ACTIVITY                 ,
  CAR_EXTR.ORG_FIDELISATION           As ORG_FIDELISATION                ,
  CAR_EXTR.ORG_WEB_ACTIVITY           As ORG_WEB_ACTIVITY                ,
  CAR_EXTR.ORG_AUTO_ACTIVITY          As ORG_AUTO_ACTIVITY               ,
  CAR_EXTR.ORG_EDO_ID                 As ORG_EDO_ID                      ,
  CAR_EXTR.ORG_TYPE_EDO               As ORG_TYPE_EDO                    ,
  CAR_EXTR.ORG_TEAM_LEVEL_1_CD        As ORG_TEAM_LEVEL_1_CD             ,
  CAR_EXTR.ORG_TEAM_LEVEL_1_DS        As ORG_TEAM_LEVEL_1_DS             ,
  CAR_EXTR.ORG_TEAM_LEVEL_2_CD        As ORG_TEAM_LEVEL_2_CD             ,
  CAR_EXTR.ORG_TEAM_LEVEL_2_DS        As ORG_TEAM_LEVEL_2_DS             ,
  CAR_EXTR.ORG_TEAM_LEVEL_3_CD        As ORG_TEAM_LEVEL_3_CD             ,
  CAR_EXTR.ORG_TEAM_LEVEL_3_DS        As ORG_TEAM_LEVEL_3_DS             ,
  CAR_EXTR.ORG_TEAM_LEVEL_4_CD        As ORG_TEAM_LEVEL_4_CD             ,
  CAR_EXTR.ORG_TEAM_LEVEL_4_DS        As ORG_TEAM_LEVEL_4_DS             ,
  CAR_EXTR.WORK_TEAM_LEVEL_1_CD       As WORK_TEAM_LEVEL_1_CD            ,
  CAR_EXTR.WORK_TEAM_LEVEL_1_DS       As WORK_TEAM_LEVEL_1_DS            ,
  CAR_EXTR.WORK_TEAM_LEVEL_2_CD       As WORK_TEAM_LEVEL_2_CD            ,
  CAR_EXTR.WORK_TEAM_LEVEL_2_DS       As WORK_TEAM_LEVEL_2_DS            ,
  CAR_EXTR.WORK_TEAM_LEVEL_3_CD       As WORK_TEAM_LEVEL_3_CD            ,
  CAR_EXTR.WORK_TEAM_LEVEL_3_DS       As WORK_TEAM_LEVEL_3_DS            ,
  CAR_EXTR.WORK_TEAM_LEVEL_4_CD       As WORK_TEAM_LEVEL_4_CD            ,
  CAR_EXTR.WORK_TEAM_LEVEL_4_DS       As WORK_TEAM_LEVEL_4_DS            ,
  Null                                As ANNUL_HD_DT                     ,
  Null                                As ANNUL_HD_DS                     ,
  Null                                As IND_HD_CD                       ,
  Null                                As IND_HD_RAP_CD                   ,
  Null                                As HD_RAP_DT                       ,
  Null                                As CLOSURE_DT                       


From ${KNB_PCO_TMP}.ORD_W_EXTRACT_CAR_DIGITAL                            as   CAR_EXTR      
Where
  1 = 1
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_W_CAR_ELIG_JRC_DIGITAL;
.if errorcode <> 0 then .quit 1;

