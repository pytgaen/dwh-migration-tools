--$HEADER:   %HEADER% 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CAR_Acte_Consolidation_CalculPerenniteVerifActionClient_OT.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Verif Action Client 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/08/2015      AOU         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_CHECK_ACTCLI_OT All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_CHECK_ACTCLI_OT
(
  ACTE_ID                     ,
  ORD_DEPOSIT_DT              ,
  PERNNT_IN                   ,
  PERNNT_END_DT               ,
  PERNNT_MOTIF                ,
  ORDAGD_DT_CANCEL            ,
  SEG_COM_ID_FINAL_ORDER      ,
  SEG_FINAL_ORDER_DT          ,
  SEG_FINAL_ORDER_CANCEL_DT   
)
Select
  Acte.ACTE_ID                                                    as ACTE_ID                      ,
  Acte.ORD_DEPOSIT_DT                                             as ORD_DEPOSIT_DT               ,
  --On applique la règle : s'il résilie
  Case  When (RefAgend.ORDAGD_ETAT   = 'R') And (Acte.ORD_DEPOSIT_DT = RefAgend.ORDAGD_DEMANDE_DT  And RefAgend.ORDAGD_DT_EFFET <= Acte.ORD_DEPOSIT_DT + 60)
          Then  'N'
        -- s'il a souscrit à une nouvelle offre
        When RefAgend.START_COMM_DT >=  Acte.ORD_DEPOSIT_DT
          Then  'O'
        Else    'N'
  End                                                             as PERNNT_IN                      ,
  RefAgend.ORDAGD_DEMANDE_DT                                      as PERNNT_END_DT                  ,
  
    Case  When RefAgend.ORDAGD_ETAT   = 'R' And (Acte.ORD_DEPOSIT_DT = RefAgend.ORDAGD_DEMANDE_DT  And RefAgend.ORDAGD_DT_EFFET <= Acte.ORD_DEPOSIT_DT + 60)
          Then  'Résiliation'
        -- s'il a souscrit à une nouvelle offre
        When RefAgend.START_COMM_DT >=  Acte.ORD_DEPOSIT_DT
          Then  Null
        Else    'Migration'
  End                                                             as PERNNT_MOTIF                    ,
  
  Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET)     as ORDAGD_DT_CANCEL               ,
  RefAgend.SEG_COM_ID                                             as SEG_COM_ID_FINAL_ORDER         ,
  RefAgend.ORDAGD_DEMANDE_DT                                      as SEG_FINAL_ORDER_DT             ,
  Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET)     as SEG_FINAL_ORDER_CANCEL_DT      
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_EXRACT Acte
  Inner Join  ${KNB_PCO_TMP}.ORD_W_AGENDE_SEG_REFCOM_OT RefAgend
    On    Acte.PAR_IMSI                 =   RefAgend.DOSSIER_NU_IMSI
      --And Acte.SEG_COM_ID               =   RefAgend.SEG_COM_ID
      And Acte.ORD_DEPOSIT_DT           <=  RefAgend.ORDAGD_DEMANDE_DT
      And RefAgend.ORDAGD_DEMANDE_DT    <=  (Acte.ORD_DEPOSIT_DT + 60)
      And Acte.SEG_COM_ID_LP            <>  RefAgend.SEG_COM_ID
      -- On Reformat le type de commande CAR
      --DEMGT
      --FIDELISATION
      --MAINT
      --MIGR
      --SUPP
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID_LP          Not In ('NS','OPTTECH','OPT_INC')
  And Acte.TYPE_OT_SO             in ('OT')
  And Acte.PAR_IMSI               Is Not Null
  -- On filtre les ordres annulé
  And RefAgend.ORDAGD_ETAT        Not In ('K')
  --On recherche les annulation :
  And RefAgend.ORDAGD_OPE         In ('A')
  Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order by PERNNT_IN Asc, Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET) Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_CHECK_ACTCLI_OT;
.if errorcode <> 0 then .quit 1



.quit 0


