-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_PCO_EnrichissementPlacementClient_PCM.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2011     CDR         Création
-- 06/02/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_CLIENT_PCM All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_CLIENT All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_BAL All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_ADR All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_USCM All
;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- Alimentation des Attributs clients Nom Prenom
-- On requete dans TDDOSSIER uniquement pour les clients Prépaid
------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_CLIENT_PCM
(
  ACTE_ID                   ,
  PAR_LASTNAME              ,
  PAR_FIRSTNAME             
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Récupération du Nom
  Brc.BCR_ADRBCR_NP                 as PAR_LASTNAME         ,
  --Récupération du Nom
  Null                              as PAR_FIRSTNAME        
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_TFBCR Brc
    On    Inter.ID_BCR                            =   Brc.BCR_ID_BCR
Where
  (1=1)
  And ( Inter.PAR_LASTNAME Is Null )
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Brc.CREATION_TS Desc)=1


------------------------------------------------------------------
-- Alimentation des Attributs clients Nom Prenom
-- On requete dans TDCLIENT uniquement pour les clients PostPaid
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_CLIENT
(
  ACTE_ID                   ,
  PAR_LASTNAME              ,
  PAR_FIRSTNAME             ,
  PAR_TYPE                  
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  -- Dans le cas des clients Pro on met tous dans le Nom :
  Client.CLIENT_LL_NOM              as PAR_LASTNAME         ,
  -- Dans le cas des clients Post Paid on ne peut pas séparer le nom
  -- du prénom
  Null                              as PAR_FIRSTNAME        ,
  Client.CLIENT_CO_TYPCLI           as PAR_TYPE             
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_TDCLIENT Client
    On    Inter.CLIENT_NU =   Client.CLIENT_NU
Where
  (1=1)
  And ( Inter.PAR_TYPE Is Null)
  --On ne fait n'exclu pas les prépaid pour récupérer leur le code Type Client
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Client.CREATION_TS Desc)=1


------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Mail
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_BAL
(
  ACTE_ID                   ,
  PAR_EMAIL                 
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Récupération de l'adresse mail
  Brc.BCR_EMAIL                     as PAR_EMAIL            
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_TFBCR Brc
    On    Inter.ID_BCR                            =   Brc.BCR_ID_BCR
Where
  (1=1)
  And ( Inter.PAR_EMAIL Is Null )
  And ( Brc.BCR_EMAIL Is Not Null )
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Brc.CREATION_TS Desc)=1

------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Postale
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_ADR
(
  ACTE_ID                   ,
  PAR_BILL_ADRESS_1         ,
  PAR_BILL_ADRESS_2         ,
  PAR_BILL_ADRESS_3         ,
  PAR_BILL_ADRESS_4         ,
  PAR_BILL_CD_POSTAL        ,
  PAR_DO                    
)
Select
  Inter.ACTE_ID                                       as ACTE_ID              ,
  --Récupération de l'adresse du client
  TD_SYSFNLIB.Oreplace(UPPER(Brc.BCR_ADR1BCR), 'NULL ', '')                           AS PAR_BILL_ADRESS_1    ,
  TD_SYSFNLIB.Oreplace(UPPER(Brc.BCR_ADR2BCR), 'NULL ', '')                           AS PAR_BILL_ADRESS_2    ,
  TD_SYSFNLIB.Oreplace(UPPER(Brc.BCR_ADR3BCR), 'NULL', '')                            AS PAR_BILL_ADRESS_3    ,
  COALESCE (CASE WHEN UPPER(Brc.BCR_ADR4BCR) = 'NULL' THEN NULL
                 ELSE Brc.BCR_ADR4BCR
            END , Brc.BCR_ADRBCR_VILLE)                                   AS PAR_BILL_ADRESS_4    ,
  --Calcul du code Postale => 5 Premier caractère du code (Car le champ : Code Postal + INSEE)
  Substring(Trim(Brc.BCR_ADRBCR_CPOS) From 1 For 5) as PAR_BILL_CD_POSTAL ,
  --Calcul De la DO : En fonction du département Pour la métropole 2 1er caractère
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Brc.BCR_ADRBCR_CPOS) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988','998','999')
          Then  Substring(Trim(Brc.BCR_ADRBCR_CPOS) From 1 For 3)
        When    Brc.BCR_ADRBCR_CPOS Is Not Null
          Then  Substring(Trim(Brc.BCR_ADRBCR_CPOS) From 1 For 2)
        Else    '999'
  End                                                 as PAR_DO             
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_TFBCR Brc
    On    Inter.ID_BCR                            =   Brc.BCR_ID_BCR
Where
  (1=1)
  And ( Inter.PAR_BILL_CD_POSTAL Is Null )
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Brc.CREATION_TS Desc)=1
------------------------------------------------------------------
-- Alimentation de la DEO de rattachement (USCM)
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_USCM
(
  ACTE_ID                   ,
  USCM_CO_ADV               
)
Select
  Tmp.ACTE_ID         as ACTE_ID      ,
  Tmp.USCM_CO_ADV     as USCM_CO_ADV  
From
  (
      Select
        Inter.ACTE_ID                                       as ACTE_ID              ,
        PARCLI_USC_CO                                       as USCM_CO_ADV          ,
        1                                                   as PRIO                 
      From
        ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
        Inner Join ${KNB_IBU_SOC_V}.VF_THPARCLI Parc
          On    Inter.CLIENT_NU                         =   Parc.PARCLI_CLIENT_NU
            And Inter.DATESAISIEBCR                     >   Parc.PARCLI_DT_DEB
            And Inter.DATESAISIEBCR                     <=  Parc.PARCLI_DT_FIN
      Where
        (1=1)
        And ( Inter.USCM_CO_ADV Is Null )
        And Parc.PARCLI_PLTF_CO <> 'VI1'
      Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Parc.PARCLI_DT_DEB Asc, PARCLI_DT_FIN Desc)=1
    Union all
      Select
        Inter.ACTE_ID                                       as ACTE_ID              ,
        PARCLI_USC_CO                                       as USCM_CO_ADV          ,
        2                                                   as PRIO                 
      From
        ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
        Inner Join ${KNB_IBU_SOC_V}.VF_THPARCLI Parc
          On    Inter.CLIENT_NU                         =   Parc.PARCLI_CLIENT_NU
            And Inter.DATESAISIEBCR                     =   Parc.PARCLI_DT_DEB
      Where
        (1=1)
        And ( Inter.USCM_CO_ADV Is Null )
        And Parc.PARCLI_PLTF_CO <> 'VI1'
      Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Parc.CREATION_TS Desc)=1
    Union all
      Select
        Inter.ACTE_ID                     as ACTE_ID              ,
        Client.CLIENT_USCM_CO             as USCM_CO_ADV          ,
        3                                 as PRIO                 
      From
        ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
        Inner Join ${KNB_IBU_SOC_V}.VF_TDCLIENT Client
          On    Inter.CLIENT_NU =   Client.CLIENT_NU
      Where
        (1=1)
        And ( Inter.USCM_CO_ADV Is Null)
        --On ne fait n'exclu pas les prépaid pour récupérer leur le code Type Client
      Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Client.CREATION_TS Desc)=1
  )Tmp
Qualify Row_number() Over (Partition by Tmp.ACTE_ID order by Tmp.PRIO asc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_CLIENT_PCM;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_CLIENT;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_BAL;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_ADR;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_USCM;
.if errorcode <> 0 then .quit 1

.quit 0

