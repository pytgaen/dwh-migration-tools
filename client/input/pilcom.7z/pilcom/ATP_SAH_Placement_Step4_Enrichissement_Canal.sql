-- $HEADER: mm2pco/current/sql/ATP_SAH_Placement_Step4_Enrichissement_Canal.sql 13_05#4 24-SEP-2018 15:59:39 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SAH_Placement_Step4_Enrichissement_Canal.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissement Canal Macro
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 13/07/2017      MDE         Creation
-- 24/09/2018      JCR         Uniformisation valeur ORG_WEB_ACTIVITY
-- 21/06/2021      EVI         PILCOM-938 : Optimisation utilisation CAT_W_PILCOM_REFO3_JOUR
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
--   Purge de la table temporaire avant insertion
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
--Etape 1-- Recherche QW AD 
----------------------------------------------------------------------------------------------
   Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL
(
 
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_REM_CHANNEL_CD         ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_PLT_CONV_NB           ,
  FLAG_PLT_SCH_IN            ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  FLAG_TYPE_PTN_NTK          ,
  DISTRBTN_CHANNL_ID         ,
  STORE_NM                   ,
  FLAG_STP                   ,
  FLAG_AD_SC            
 
   )
Select
  RefId.ACTE_ID                             As ACTE_ID                                  ,
  RefId.ORDER_DEPOSIT_DT                    As ORDER_DEPOSIT_DT                         ,
  Null                                      As ORG_CHANNEL_CD                           ,
    --Sous Canal
   Null                                     As ORG_SUB_CHANNEL_CD                       ,
  --Sous Sous Canal
  Null                                      As ORG_SUB_SUB_CHANNEL_CD                   ,
  -- GT/Activité 
  ORG.ACTIVITY                              As ORG_GT_ACTIVITY                          ,
  --Canal de Rem
  Null                                      As ORG_REM_CHANNEL_CD                       ,
  Null                                      As ORG_FIDELISATION                         ,
  'NON'                                     As ORG_WEB_ACTIVITY                         ,
  Null                                      As ORG_AUTO_ACTIVITY                        ,
  ORG.EDO_ID                                As EDO_ID                                   ,
  ORG.TYPE_EDO                              As TYPE_EDO_ID                              ,
  ORG.NETWRK_TYP_EDO_ID                     As NETWRK_TYP_EDO_ID                        ,
  ORG.FLAG_PLT_CONV_NB                      As FLAG_PLT_CONV_NB                         ,
  NULL                                      As FLAG_PLT_SCH_IN                          ,
  ORG.FLAG_TYPE_GEO_CD                      As FLAG_TYPE_GEO_CD                         ,
  ORG.FLAG_TYPE_CPT_NTK_NU                  As FLAG_TYPE_CPT_NTK                        ,
  Case  When trim(NETWRK_TYP_EDO_ID)='RP'
          Then 'GDT'
  End                                       As FLAG_TYPE_PTN_NTK                        ,
  ORG.DISTRBTN_CHANNL_ID                    As DISTRBTN_CHANNL_ID                       ,
  ORG.STORE_NM                              As STORE_NM                                 ,
  1                                         As FLAG_STP                                 , 
  1                                         As FLAG_AD_SC      
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 As RefId
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_AD_EDO As ORG
        On    RefId.ORG_AGENT_ID      =   ORG.CUID
        And RefId.ORDER_DEPOSIT_TS      >=  ORG.DT_DEBUT
        And RefId.ORDER_DEPOSIT_TS      <=   ORG.DT_FIN
   Where
    (1=1)
     And ORG.EDO_ID Is Not Null
-- Verification quâil nây a rien dans le QW SC avec une date de debut posterieure au QW AD
    And Not Exists (
        Select
        1
        From ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORGSC
        where  RefId.ORG_AGENT_ID        =     ORGSC.CUID
        And RefId.ORDER_DEPOSIT_TS      >=    ORGSC.DT_DEBUT
        And RefId.ORDER_DEPOSIT_TS      <=    ORGSC.DT_FIN
        And ORGSC.DT_DEBUT               >     ORG.DT_DEBUT
    )
Qualify Row_number() over (Partition by RefId.ACTE_ID ,RefId.ORDER_DEPOSIT_DT Order By  ORG.DT_DEBUT Desc, ORG.EDO_ID Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL;
.if errorcode <> 0 then .quit 1




----------------------------------------------------------------------------------------------
--Etape 2-- Recherche QW SC 
----------------------------------------------------------------------------------------------
   Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL
(
 
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_REM_CHANNEL_CD         ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_PLT_CONV_NB           ,
  FLAG_PLT_SCH_IN            ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  FLAG_TYPE_PTN_NTK          ,
  DISTRBTN_CHANNL_ID         ,
  STORE_NM                   ,
  FLAG_STP                   ,
  FLAG_AD_SC                 ,
  PRIO       
 
   )
Select
   RefId.ACTE_ID                             As ACTE_ID                                 ,
  RefId.ORDER_DEPOSIT_DT                    As ORDER_DEPOSIT_DT                         ,
  Null                                      As ORG_CHANNEL_CD                           ,
    --Sous Canal
   Null                                     As ORG_SUB_CHANNEL_CD                       ,
  --Sous Sous Canal
  Null                                      As ORG_SUB_SUB_CHANNEL_CD                   ,
  -- GT/Activité 
  Null                                      As ORG_GT_ACTIVITY                          ,
  --Canal de Rem
  Null                                      As ORG_REM_CHANNEL_CD                       ,
  Null                                      As ORG_FIDELISATION                         ,
  'NON'                                     As ORG_WEB_ACTIVITY                         ,
  Null                                      As ORG_AUTO_ACTIVITY                        ,
  ORG.EDO_ID_EQUI_RAT                       As EDO_ID                                   ,
  ORG.FLAG_HIER_EQUI_RAT                    As TYPE_EDO_ID                              ,
  Null                                      As NETWRK_TYP_EDO_ID                        ,
  ORG.FLAG_PLT_CONV_EQUI_RAT                As FLAG_PLT_CONV_NB                         ,
  ORG.FLAG_SCH_EQUI_RAT                     As FLAG_PLT_SCH_IN                          ,
  Null                                      As FLAG_TYPE_GEO_CD                         ,
  Null                                      As FLAG_TYPE_CPT_NTK                        ,
  Null                                      As FLAG_TYPE_PTN_NTK                        ,
  Null                                      As DISTRBTN_CHANNL_ID                       ,
  Null                                      As STORE_NM                                 ,
  2                                         As FLAG_STP                                 , 
  0                                         As FLAG_AD_SC                               ,
   Case  When ORG.SOURCE = 'MCRM'
            Then 1
          When ORG.SOURCE = 'POCC'
            Then 2
          When ORG.SOURCE = 'HRF'
            Then 3
          When ORG.SOURCE = 'RFOR'
            Then 4
          When ORG.SOURCE = 'EDL'
            Then 5
          When ORG.SOURCE = 'OEE'
            Then 6
          Else 7
    End                                                        As PRIO

   From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 As RefId
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORG
        On    RefId.ORG_AGENT_ID        =   ORG.CUID
        And RefId.ORDER_DEPOSIT_TS      >=  ORG.DT_DEBUT
        And RefId.ORDER_DEPOSIT_TS      <=   ORG.DT_FIN
   
    Where
   (1=1)
  And ORG.EDO_ID_EQUI_RAT Is Not Null
  And
  Not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL AD
       where
         RefId.ACTE_ID=AD.ACTE_ID
      )
Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT Order By PRIO Asc , ORG.DT_DEBUT Desc, ORG.EDO_ID_EQUI_RAT Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

;

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
--Etape 3-- Recherche ADV 
----------------------------------------------------------------------------------------------
    Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_REM_CHANNEL_CD         ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_PLT_CONV_NB           ,
  FLAG_PLT_SCH_IN            ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  FLAG_TYPE_PTN_NTK          ,
  FLAG_STP                   ,
  FLAG_AD_SC                  
)

Select
  RefId.ACTE_ID                             As ACTE_ID                                ,
  RefId.ORDER_DEPOSIT_DT                    As ORDER_DEPOSIT_DT                       ,
    --Canal de vente Macro = Dist
   --Case when RefEDO.FLAG_PLT_AD = 1 or    RefId.UNIFIED_SHOP_CD     like '%PH%'
  Case 
     When xAD.VAL_AXS_CLSSF_ID = 'UAT' 
        Then 'AT Home'
     When RefEDO.FLAG_PLT_AD = 1 or   RefEDO.NETWRK_TYP_EDO_ID in ('RP')
       Then 'Dist' 
      Else 'Exclus'
  End                                     As ORG_CHANNEL_CD_AGR                       ,
    --Sous Canal
  Case  
    When xAD.VAL_AXS_CLSSF_ID = 'UAT' 
        Then 'ATH' 
    When ORG_CHANNEL_CD_AGR ='Dist' and RefEDO.NETWRK_TYP_EDO_ID = 'FT'
        Then 'AD'
    When RefEDO.NETWRK_TYP_EDO_ID='RP' 
          Then 'RP'
      Else 'Exclus'
  End                                     As ORG_SUB_CHANNEL_CD_AGR                   ,
  --Sous Sous Canal
  Case  
     When ORG_SUB_CHANNEL_CD_AGR = 'UAT'  
          Then 
              Case When RefEDO.FLAG_TYPE_GEO in ('REUNION','CARAIBES')  
                     Then 'Dom'
                   Else 'Metropole'
              End
  When ORG_SUB_CHANNEL_CD_AGR = 'AD'  
          Then 
              Case When RefEDO.FLAG_TYPE_GEO in ('REUNION','CARAIBES')  
                     Then 'Dom'
                   Else 'Metropole'
              End
  When ORG_SUB_CHANNEL_CD_AGR = 'RP'  
          Then 
              Case When RefEDO.FLAG_TYPE_GEO in ('REUNION','CARAIBES')  
                     Then 'Dom'
                   Else 'Metropole'
              End
          
        Else 'Exclus'
  End                                     As ORG_SUB_SUB_CHANNEL_CD                   ,
  -- GT/Activité 
  Case  
     When ORG_SUB_CHANNEL_CD_AGR = 'UAT'
          Then 'UAT' 
  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'Boutique FT'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'GDT'
      Else 'Exclus'
  End                                     As ORG_GT_ACTIVITY                          ,
  --Canal de Rem
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD' 
          Then 'AD'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP' 
          Then 'Exclus'
        Else 'Exclus'
  End                                     As ORG_REM_CHANNEL_CD                       ,
  Null                                    As ORG_FIDELISATION                         ,
  'NON'                                   As ORG_WEB_ACTIVITY                         ,
  'NON'                                   As ORG_AUTO_ACTIVITY                        ,
  adv.EDO_ID                              As EDO_ID                                   ,
  RefEDO.TYPE_EDO                         As TYPE_EDO_ID                              ,
  RefEDO.NETWRK_TYP_EDO_ID                As NETWRK_TYP_EDO_ID                        ,
  RefEDO.FLAG_PLT_CONV                    As FLAG_PLT_CONV_NB                         ,
  RefEDO.FLAG_PLT_SCH                     As FLAG_PLT_SCH_IN                          ,
  RefEDO.FLAG_TYPE_GEO                    As FLAG_TYPE_GEO_CD                         ,
  RefEDO.FLAG_TYPE_CPT_NTK                As FLAG_TYPE_CPT_NTK                        ,
  RefEDO.FLAG_TYPE_PTN_NTK                As FLAG_TYPE_PTN_NTK                        ,
  3                                       AS  FLAG_STP                                ,
  Null                                    As FLAG_AD_SC                                

 From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 RefId
  Inner Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    RefId.EXT_SHOP_ADV_CD   = RefEDO.EXTNL_VAL_COD_CD
    And   RefId.ORDER_DEPOSIT_DT  Between RefEDO.START_EXTNL_VAL_DT And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Inner join  ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK adv
    ON adv.EXTNL_COD_CD = 'ADV'
      and RefId.EXT_SHOP_ADV_CD  = adv.EXTNL_VAL_COD_CD 
      and RefID.ORDER_DEPOSIT_DT between adv.START_EXTNL_VAL_DT and adv.END_EXTNL_VAL_DT
      and adv.CURRENT_IN = 1
  LEFT JOIN ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO xAD
      ON xAD.EDO_ID = RefEDO.edo_id and xAD.CURRENT_IN = 1 and xAD.VAL_AXS_CLSSF_ID in ('UAT')
  
        
 Where
  (1=1)
  And Not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL EX
       where
         RefId.ACTE_ID=EX.ACTE_ID
      )
 Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT Order By RefEDO.EDO_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
--Etape 4-- Recherche PDL 
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_REM_CHANNEL_CD         ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_PLT_CONV_NB           ,
  FLAG_PLT_SCH_IN            ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  FLAG_TYPE_PTN_NTK          ,
  FLAG_STP                   ,
  FLAG_AD_SC                  
)

Select
  RefId.ACTE_ID                             As ACTE_ID                                ,
  RefId.ORDER_DEPOSIT_DT                    As ORDER_DEPOSIT_DT                       ,
    --Canal de vente Macro = Dist
   --Case when RefEDO.FLAG_PLT_AD = 1 or    RefId.UNIFIED_SHOP_CD     like '%PH%'
  Case when RefEDO.FLAG_PLT_AD = 1 or   RefEDO.NETWRK_TYP_EDO_ID in ('RP')
--Case when  xAD.VAL_AXS_CLSSF_ID is not null or  RefEDO.NETWRK_TYP_EDO_ID in ( 'RP' ,'RC')
       Then 'Dist'
       Else 'Exclus'
  End                                     As ORG_CHANNEL_CD_AGR                       ,
    --Sous Canal
  Case  When ORG_CHANNEL_CD_AGR ='Dist' and RefEDO.NETWRK_TYP_EDO_ID = 'FT'
          Then 'AD'
        When RefEDO.NETWRK_TYP_EDO_ID='RP' 
          Then 'RP'
        Else 'Exclus'
  End                                     As ORG_SUB_CHANNEL_CD_AGR                   ,
  --Sous Sous Canal
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'  
          Then 
              Case When RefEDO.FLAG_TYPE_GEO in ('REUNION','CARAIBES')  
                     Then 'Dom'
                   Else 'Metropole'
              End
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'  
          Then 
              Case When RefEDO.FLAG_TYPE_GEO in ('REUNION','CARAIBES')  
                     Then 'Dom'
                   Else 'Metropole'
              End
        Else 'Exclus'
  End                                     As ORG_SUB_SUB_CHANNEL_CD                   ,
  -- GT/Activité 
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'Boutique FT'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'GDT'
        Else 'Exclus'
  End                                     As ORG_GT_ACTIVITY                          ,
  --Canal de Rem
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD' 
          Then 'AD'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP' 
          Then 'Exclus'
        Else 'Exclus'
  End                                     As ORG_REM_CHANNEL_CD                       ,
  Null                                    As ORG_FIDELISATION                         ,
  'NON'                                   As ORG_WEB_ACTIVITY                         ,
  'NON'                                   As ORG_AUTO_ACTIVITY                        ,
  adv.EDO_ID                              As EDO_ID                                   ,
  RefEDO.TYPE_EDO                         As TYPE_EDO_ID                              ,
  RefEDO.NETWRK_TYP_EDO_ID                As NETWRK_TYP_EDO_ID                        ,
  RefEDO.FLAG_PLT_CONV                    As FLAG_PLT_CONV_NB                         ,
  RefEDO.FLAG_PLT_SCH                     As FLAG_PLT_SCH_IN                          ,
  RefEDO.FLAG_TYPE_GEO                    As FLAG_TYPE_GEO_CD                         ,
  RefEDO.FLAG_TYPE_CPT_NTK                As FLAG_TYPE_CPT_NTK                        ,
  RefEDO.FLAG_TYPE_PTN_NTK                As FLAG_TYPE_PTN_NTK                        ,
  4                                       AS FLAG_STP                                 ,
  Null                                    As FLAG_AD_SC                                

From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 RefId
  Inner Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    RefId.EXT_SHOP_ID  = RefEDO.EXTNL_VAL_COD_CD
    And   RefId.ORDER_DEPOSIT_DT  Between RefEDO.START_EXTNL_VAL_DT And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
   Inner join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO adv
    ON adv.EXTNL_COD_CD = 'PDL'
    and RefId.EXT_SHOP_ID  = adv.EXTNL_VAL_COD_CD 
    and RefID.ORDER_DEPOSIT_DT between adv.START_EXTNL_VAL_DT and adv.END_EXTNL_VAL_DT
    and adv.CURRENT_IN = 1
Where
  (1=1)
  And Not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL EX
       where
         RefId.ACTE_ID=EX.ACTE_ID
      )
  
Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT Order By RefEDO.EDO_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
--Etape 5-1 -  Recherche dans le matrice compte_cd, user_cd  => non nul  
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL
(
 
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_REM_CHANNEL_CD         ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_PLT_CONV_NB           ,
  FLAG_PLT_SCH_IN            ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  FLAG_TYPE_PTN_NTK          ,
  DISTRBTN_CHANNL_ID         ,
  STORE_NM                   ,
  FLAG_STP                   ,
  FLAG_AD_SC            
 
   )
Select
  RefId.ACTE_ID                                           As ACTE_ID                                  ,
  RefId.ORDER_DEPOSIT_DT                                  As ORDER_DEPOSIT_DT                         ,
  MTR.ORG_CHANNEL_CD                                      As ORG_CHANNEL_CD                           ,
    --Sous Canal
   MTR.ORG_SUB_CHANNEL_CD                                 As ORG_SUB_CHANNEL_CD                       ,
  --Sous Sous Canal
  MTR.ORG_SUB_SUB_CHANNEL_CD                              As ORG_SUB_SUB_CHANNEL_CD                   ,
  -- GT/Activité 
  MTR.ORG_GT_ACTIVITY                                     As ORG_GT_ACTIVITY                          ,
  --Canal de Rem
  MTR.ORG_REM_CHANNEL_CD                                  As ORG_REM_CHANNEL_CD                       ,
  MTR.ORG_FIDELISATION                                    As ORG_FIDELISATION                         ,
  MTR.ORG_WEB_ACTIVITY                                    As ORG_WEB_ACTIVITY                         ,
  MTR.ORG_AUTO_ACTIVITY                                   As ORG_AUTO_ACTIVITY                        ,
  MTR.EDO_ID                                              As EDO_ID                                   ,
  MTR.TYPE_EDO_ID                                         As TYPE_EDO_ID                              ,
  Null                                                    As NETWRK_TYP_EDO_ID                        ,
  Null                                                    As FLAG_PLT_CONV_NB                         ,
  Null                                                    As FLAG_PLT_SCH_IN                          ,
  Null                                                    As FLAG_TYPE_GEO_CD                         ,
  Null                                                    As FLAG_TYPE_CPT_NTK                        ,
  Null                                                    As FLAG_TYPE_PTN_NTK                        ,
  Null                                                    As DISTRBTN_CHANNL_ID                       ,
  Null                                                    As STORE_NM                                 ,
  5                                                       As FLAG_STP                                 , 
  Null                                                    As FLAG_AD_SC      
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 As RefId
   Inner Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_SAH_PDV MTR
        On    RefId.EXT_SHOP_ID    =   MTR.COMPTE_CD
        And   RefId.EXT_AGENT_ID   =   MTR.USER_CD
        And   MTR.CURRENT_IN       = 1
        And   MTR.CLOSURE_DT         Is Null
        And   RefId.EXT_SHOP_ID      Is Not Null 
        And   RefId.EXT_AGENT_ID     Is Not Null
        
    Where (1=1)
     And Not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL EX
       where
         RefId.ACTE_ID=EX.ACTE_ID
      )
    Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT Order By MTR.ORG_REM_CHANNEL_CD desc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL;
.if errorcode <> 0 then .quit 1

 
----------------------------------------------------------------------------------------------
--Etape 5-2 -  Recherche dans le matrice compte_cd, user_cd  =>   nul  
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL
(
 
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_REM_CHANNEL_CD         ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_PLT_CONV_NB           ,
  FLAG_PLT_SCH_IN            ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  FLAG_TYPE_PTN_NTK          ,
  DISTRBTN_CHANNL_ID         ,
  STORE_NM                   ,
  FLAG_STP                   ,
  FLAG_AD_SC            
 
   )
Select
  RefId.ACTE_ID                                           As ACTE_ID                                  ,
  RefId.ORDER_DEPOSIT_DT                                  As ORDER_DEPOSIT_DT                         ,
  MTR.ORG_CHANNEL_CD                                      As ORG_CHANNEL_CD                           ,
    --Sous Canal
   MTR.ORG_SUB_CHANNEL_CD                                 As ORG_SUB_CHANNEL_CD                       ,
  --Sous Sous Canal
  MTR.ORG_SUB_SUB_CHANNEL_CD                              As ORG_SUB_SUB_CHANNEL_CD                   ,
  -- GT/Activité 
  MTR.ORG_GT_ACTIVITY                                     As ORG_GT_ACTIVITY                          ,
  --Canal de Rem
  MTR.ORG_REM_CHANNEL_CD                                  As ORG_REM_CHANNEL_CD                       ,
  MTR.ORG_FIDELISATION                                    As ORG_FIDELISATION                         ,
  MTR.ORG_WEB_ACTIVITY                                    As ORG_WEB_ACTIVITY                         ,
  MTR.ORG_AUTO_ACTIVITY                                   As ORG_AUTO_ACTIVITY                        ,
  MTR.EDO_ID                                              As EDO_ID                                   ,
  MTR.TYPE_EDO_ID                                         As TYPE_EDO_ID                              ,
  Null                                                    As NETWRK_TYP_EDO_ID                        ,
  Null                                                    As FLAG_PLT_CONV_NB                         ,
  Null                                                    As FLAG_PLT_SCH_IN                          ,
  Null                                                    As FLAG_TYPE_GEO_CD                         ,
  Null                                                    As FLAG_TYPE_CPT_NTK                        ,
  Null                                                    As FLAG_TYPE_PTN_NTK                        ,
  Null                                                    As DISTRBTN_CHANNL_ID                       ,
  Null                                                    As STORE_NM                                 ,
  5                                                       As FLAG_STP                                 , 
  Null                                                    As FLAG_AD_SC      
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 As RefId
   Inner Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_SAH_PDV MTR
        On    RefId.EXT_SHOP_ID      =   MTR.COMPTE_CD
        And   MTR.CURRENT_IN         = 1
        And   MTR.CLOSURE_DT         Is Null
        And   RefId.EXT_SHOP_ID      Is Not Null 
       And    MTR.USER_CD     Is Null
        
    Where (1=1)
     And Not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL EX
       where
         RefId.ACTE_ID=EX.ACTE_ID
      )
    Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT Order By MTR.ORG_REM_CHANNEL_CD desc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_CHANNEL;
.if errorcode <> 0 then .quit 1

    
----------------------------------------------------------------------------------------------
--Etape 6 -  Calcul  ACTIVITY
----------------------------------------------------------------------------------------------
Delete from  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_ACT all ;

.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_ACT
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  AGENT_ID                      ,
  START_ACTIVITY_TS             ,
  END_ACTIVITY_TS               ,
  ACTIVITY                      ,
  PRIO
)
Select
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  AGENT_ID             ,
  START_ACTIVITY_TS    ,
  END_ACTIVITY_TS      ,
  ACTIVITY             ,
  PRIO
From
(
  Select
    RefId.ACTE_ID                           As ACTE_ID              ,
    RefId.ORDER_DEPOSIT_DT                  As ORDER_DEPOSIT_DT     ,
    ACTIVITY.CUID                           As AGENT_ID             ,
    ACTIVITY.START_ACTIVITY_TS              As START_ACTIVITY_TS    ,
    ACTIVITY.END_ACTIVITY_TS                As END_ACTIVITY_TS      ,
    ACTIVITY.ACTIVITY                       As ACTIVITY             ,
    Case  When ACTIVITY.SOURCE = 'RFOR'
            Then 1
          When ACTIVITY.SOURCE = 'CHO'
            Then 2
          Else 3
    End                                     As PRIO
  From
    ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 As RefId
    Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_ACTIVITY As ACTIVITY
      On    RefId.ORG_AGENT_ID    =   ACTIVITY.CUID
        And RefId.ORDER_DEPOSIT_TS      >=  ACTIVITY.START_ACTIVITY_TS
        And RefId.ORDER_DEPOSIT_TS      <=  ACTIVITY.END_ACTIVITY_TS
  Where
    (1=1)
Qualify Row_number() over
              (Partition by
                  RefId.ACTE_ID                 ,
                  RefId.ORDER_DEPOSIT_DT
               Order By
                  PRIO ASC                          ,
                  ACTIVITY.START_ACTIVITY_TS Desc   ,
                  ACTIVITY.END_ACTIVITY_TS Desc
              ) = 1
 ) RefAct
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_ACT;
.if errorcode <> 0 then .quit 1

.quit 0

 

