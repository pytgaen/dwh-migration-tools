--$HEADER:   %HEADER% 
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_CHO_ANTICIP_AlimHot_ORD_T_ACTE_UNIFIED_CHO.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données chaudes de la source Chorus dans la table ORD_T_ACTE_UNIFIED_CHO  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 28/01/2014     XKN         Création
-- 08/04/2014     AID         EVOL
-- 19/06/2015     OCH         Modif: digital
-- 12/12/2016     HOB         Modif : Ajout Champs VA
-- 01/10/2019     SSI         KPI2020--Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
-- 30/09/2021     EVI         PILCOM-1023 : Refonte VU - Suppression champs obsolètes
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_CHO --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO;
.if errorcode <> 0 then .quit 1;

-- CHO

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  ACT_CA_LINE_AM                ,
  DEPARTMNT_ID                  ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  CHO.ACTE_ID                                                              As ACTE_ID,
  CHO.OPERATOR_PROVIDER_ID                                                 As OPERATOR_PROVIDER_ID,
  CHO.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID,
  '${P_PIL_368}'                                                           As TYPE_SOURCE_ID,
  CHO.ACTE_ID                                                              As MASTER_ACTE_ID,
  CHO.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID,
  ${P_PIL_354}                                                             As MASTER_FLAG,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND,
  Null                                                                     As CPLT_ACTE_ID,
  Null                                                                     As CPLT_INTRNL_SOURCE_ID,
  '${P_PIL_388}'                                                           As CPLT_IN,
  '${P_PIL_362}'                                                           As RULE_ID,
  Null                                                                     As OFFSET_NB,
  '${P_PIL_324}'                                                           As ACT_TYPE,
  CHO.EXTERNAL_INT_ID                                                      As ORDER_EXTERNAL_ID,
  '${P_PIL_397}'                                                           As STATUS_CD,
  Case When CHO.CONCURENCE_IN = 'O' Then '${P_PIL_385}'
       When CHO.CONFIRMATION_IN = 'N' Then '${P_PIL_386}' 
       When CHO.PERENNITE_IN = 'O' Then '${P_PIL_384}' 
       When CHO.DELIVERY_IN = 'O' And CHO.PERENNITE_IN = 'N' Then '${P_PIL_387}' 
       When CHO.DELIVERY_IN = 'O' Then '${P_PIL_383}' 
       When CHO.CONFIRMATION_IN = 'O' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                      As ACT_UNIFIED_STATUS_CD,
  CHO.INT_DEPOSIT_TS                                                       As ACT_TS,
  CHO.INT_DEPOSIT_DT                                                       As ACT_DT,
  Extract(HOUR From CHO.INT_DEPOSIT_TS)                                    As ACT_HH,
  CHO.INT_MODIF_TS                                                         As ACT_LAST_UPD_TS,
  CHO.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE,
  CHO.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE,
  CHO.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE,
  CHO.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE,
  Case When ACT_PRODUCT_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                      As ACT_OPER_ID_PRE,
  CHO.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL,
  CHO.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL,
  CHO.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL,
  CHO.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL,
  Null                                                                     As ACT_OPER_ID_FINAL,
  CHO.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL,
  CHO.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID,
  CHO.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF,
  CHO.ACT_CD                                                               As ACT_CD,
  CHO.ACT_REM_ID                                                           As ACT_REM_ID,
  CHO.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM,
  CHO.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And CHO.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And CHO.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And CHO.ORG_REM_CHANNEL_CD In (${L_PIL_043})
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And CHO.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And CHO.CLOSURE_DT              Is Null
                    -- Edo interne
                    And ( CHO.ORG_TYPE_EDO        = 'INT' Or CHO.ORG_TYPE_EDO  is Null )
                )
        Then 'O' 
       Else 'N'  
  End                                                                      As ACT_FLAG_PVC_REM,
  CHO.ACT_ACTE_VALO                                                        As ACT_ACTE_VALO,
  CHO.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI,
  CHO.ACT_PERIODE_ID                                                       As ACT_PERIODE_ID,
  CHO.ORIG_DEM_SC                                                          As ORIGIN_CD,
  CHO.ORG_AGENT_ID                                                         As AGENT_ID,
  CHO.ORG_AGENT_ID                                                         As AGENT_ID_UPD,
  Null                                                                     As AGENT_ID_UPD_DT,
  CHO.ORG_PRENOM                                                           As AGENT_FIRST_NAME,
  CHO.ORG_NOM                                                              As AGENT_LAST_NAME,
  Null                                                                     As UNIFIED_SHOP_CD,
  CHO.ORG_CANAL_ID_MACRO_SC                                                As ORG_SPE_CANAL_ID_MACRO,
  CHO.ORG_CANAL_ID_SC                                                      As ORG_SPE_CANAL_ID,
  CHO.ORG_REM_CHANNEL_CD                                                   As ORG_REM_CHANNEL_CD,
  CHO.ORG_CHANNEL_CD                                                       As ORG_CHANNEL_CD,
  CHO.ORG_SUB_CHANNEL_CD                                                   As ORG_SUB_CHANNEL_CD,
  CHO.ORG_SUB_SUB_CHANNEL_CD                                               As ORG_SUB_SUB_CHANNEL_CD,
  CHO.ORG_GT_ACTIVITY                                                      As ORG_GT_ACTIVITY,
  CHO.ORG_FIDELISATION                                                     As ORG_FIDELISATION,
  CHO.ORG_WEB_ACTIVITY                                                     As ORG_WEB_ACTIVITY,
  CHO.ORG_AUTO_ACTIVITY                                                    As ORG_AUTO_ACTIVITY,
  CHO.ORG_EDO_ID                                                           As ORG_EDO_ID,
  CHO.ORG_TYPE_EDO                                                         As ORG_TYPE_EDO,
  CHO.ORG_FLAG_PLT_CONV                                                    As ORG_FLAG_PLT_CONV,
  CHO.ORG_FLAG_TEAM_MKT                                                    As ORG_FLAG_TEAM_MKT,
  CHO.ORG_FLAG_TYPE_CMP                                                    As ORG_FLAG_TYPE_CMP,
  Null                                                                     As ORG_RESP_EDO_ID,
  Null                                                                     As ORG_RESP_TYPE_EDO, 
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV,
  Null                                                                     As ACTIVITY_CD,
  Null                                                                     As ACTIVITY_GROUPNG_CD,
  Null                                                                     As AUTO_ACTIVITY_IN,
  CASE WHEN CHO.ORG_EDO_ID IS NOT NULL THEN 'O3'
       ELSE CHO.ORG_REF_TRAV
  END                                                                      As ORG_TYPE_CD,
  Null                                                                     As ORG_TEAM_TYPE_ID                ,
  CHO.ORG_TEAM_LEVEL_1_CD                                                  As ORG_TEAM_LEVEL_1_CD             ,
  CHO.ORG_TEAM_LEVEL_1_DS                                                  As ORG_TEAM_LEVEL_1_DS             ,
  CHO.ORG_TEAM_LEVEL_2_CD                                                  As ORG_TEAM_LEVEL_2_CD             ,
  CHO.ORG_TEAM_LEVEL_2_DS                                                  As ORG_TEAM_LEVEL_2_DS             ,
  CHO.ORG_TEAM_LEVEL_3_CD                                                  As ORG_TEAM_LEVEL_3_CD             ,
  CHO.ORG_TEAM_LEVEL_3_DS                                                  As ORG_TEAM_LEVEL_3_DS             ,
  CHO.ORG_TEAM_LEVEL_4_CD                                                  As ORG_TEAM_LEVEL_4_CD             ,
  CHO.ORG_TEAM_LEVEL_4_DS                                                  As ORG_TEAM_LEVEL_4_DS             ,
  CHO.WORK_TEAM_LEVEL_1_CD                                                 As WORK_TEAM_LEVEL_1_CD            ,
  CHO.WORK_TEAM_LEVEL_1_DS                                                 As WORK_TEAM_LEVEL_1_DS            ,
  CHO.WORK_TEAM_LEVEL_2_CD                                                 As WORK_TEAM_LEVEL_2_CD            ,
  CHO.WORK_TEAM_LEVEL_2_DS                                                 As WORK_TEAM_LEVEL_2_DS            ,
  CHO.WORK_TEAM_LEVEL_3_CD                                                 As WORK_TEAM_LEVEL_3_CD            ,
  CHO.WORK_TEAM_LEVEL_3_DS                                                 As WORK_TEAM_LEVEL_3_DS            ,
  CHO.WORK_TEAM_LEVEL_4_CD                                                 As WORK_TEAM_LEVEL_4_CD            ,
  CHO.WORK_TEAM_LEVEL_4_DS                                                 As WORK_TEAM_LEVEL_4_DS            ,
  CHO.CONFIRMATION_IN                                                      As CONFIRMATION_IN                 ,
  CHO.MIGRA_DT                                                             As MIGRA_DT                        ,
  CHO.MIGRA_NEXT_OFFRE                                                     As MIGRA_NEXT_OFFRE                ,
  CHO.DMC_LINE_ID                                                          As LINE_ID,
  CHO.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID, 
  CHO.PAR_GEO_MACROZONE                                                    As PAR_GEO_MACROZONE ,            
  CHO.PAR_UNIFIED_PARTY_ID                                                 As PAR_UNIFIED_PARTY_ID ,
  CHO.PAR_PARTY_REGRPMNT_ID                                                As PAR_PARTY_REGRPMNT_ID ,
  CHO.PAR_TYPE                                                             As CUST_TYPE_CD,
  Coalesce(CHO.DOSSIER_NU, '0000000000')                                   As MSISDN_ID,
  Coalesce(CHO.PAR_ND, '0000000000')                                       As NDS_VALUE_DS,
  Coalesce(CHO.CLIENT_NU, '0000000000')                                    As EXTERNAL_PARTY_ID,
  CHO.PAR_AID                                                              As RES_VALUE_DS,
  Null                                                                     As PAR_ACCES_SERVICE,
  Null                                                                     As TAC_CD, 
  Null                                                                     As IMEI_CD, 
  CHO.PAR_IMSI                                                             As IMSI_CD, 
  CHO.DMC_ACTIVATION_DT_INT                                                As HOM_START_DT, 
  CHO.DMC_ACTIVATION_DT                                                    As MOB_START_DT, 
  CHO.PAR_SCORE_NU_INT                                                     As I_SCORE_VALUE,
  CHO.PAR_TRESHOLD_NU_INT                                                  As I_SCORE_TRESHOLD,
  Case                                                                     
    When CHO.PAR_SCORE_IN_INT = 'O' Then 1                                     
    Else 0                                                                 
  End                                                                      As I_SCORE_IN,
  CHO.PAR_SCORE_NU_MOB                                                     As M_SCORE_VALUE,
  Case
    When CHO.PAR_TRESHOLD_NU_MOB > 100 Then -1
    Else CHO.PAR_TRESHOLD_NU_MOB        
  End                                                                      As M_SCORE_TRESHOLD,
  CHO.PAR_SCORE_IN_MOB                                                     As M_SCORE_IN,
  Cast(Case When CHO.OTO_OSCAR_VALUE_NU = 'SC' Then -1
            Else CHO.OTO_OSCAR_VALUE_NU
  End As BYTEINT)                                                          As OSCAR_VALUE, 
  '${P_PIL_376}'                                                           As CUST_BU_TYPE_CD,
  CHO.PAR_USCM                                                             As CUST_BU_CD,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE,
  Trim(
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_1 = 'null' Then Null Else PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_2 = 'null' Then Null Else PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_3 = 'null' THEN Null Else PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(CHO.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_4 = 'null' Then Null Else PAR_BILL_ADRESS_4 End,'')) || ' ' ||
    Trim(Coalesce(CHO.PAR_BILL_VILLE,'')) 
  )                                                                        As ADDRESS_CONCAT_NM,
  CHO.PAR_BILL_CD_POSTAL                                                   As POSTAL_CD,
  CHO.PAR_INSEE_CD                                                         As INSEE_CD,      
  Null                                                                     As BU_CD,
   Case When CHO.ACT_UNITE_CD ='${P_PIL_620}' --Unité = NB
         Then Null
       Else Coalesce(CHO.ACT_DELTA_TARIF,0)
  End                                                                      as ACT_CA_LINE_AM                    ,
  CHO.PAR_DO                                                               As DEPARTMNT_ID,
  Null                                                                     As CHECK_INITIAL_STATUS_CD,
  Null                                                                     As CHECK_NAT_STATUS_CD,
  Null                                                                     As CHECK_NAT_COMMENT,
  Null                                                                     As CHECK_NAT_STATUS_LN,
  Null                                                                     As CHECK_LOC_STATUS_CD,
  Null                                                                     As CHECK_LOC_COMMENT,
  Null                                                                     As CHECK_LOC_STATUS_LN,
  Null                                                                     As CHECK_VALIDT_DT,
  Null                                                                     As ACT_END_UNIFIED_DT,
  Null                                                                     As ACT_END_UNIFIED_DS,
  Null                                                                     As ACT_CLOSURE_DT,
  Null                                                                     As ACT_CLOSURE_DS,
  CHO.HOT_IN                                                               As HOT_IN,
  '${KNB_VACATION_RUN_ID}'                                                 As RUN_ID,
  CHO.CREATION_TS                                                          As CREATION_TS,
  Null                                                                     As LAST_MODIF_TS,
  1                                                                        As FRESH_IN,
  0                                                                        As COHERENCE_IN 
From ${KNB_PCO_TMP}.INT_T_ACTE_CHO_A CHO 
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
      On  CHO.ACT_PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                           = 1
      And EtatPeriode.FRESH_IN                             = 1
      And EtatPeriode.CLOSURE_DT                           Is Null
Where (1=1) 
And Substr(CHO.ACT_CD,1,3) Not In (${L_PIL_036})
And CHO.ACT_SEG_COM_ID_FINAL    Not In ('ACCINTERF','ACCINTERS','ACCINTERC')
And CHO.ACT_SEG_COM_ID_FINAL <> '${P_PIL_295}'
And CHO.ACT_CD <> '${P_PIL_067}'
And CHO.HOT_IN = 1
And CHO.CLOSURE_DT Is Null 
-- la periode n est pas close
And ( EtatPeriode.PERIODE_STATUS is Null Or EtatPeriode.PERIODE_STATUS = 'O' )
And CHO.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO;
.if errorcode <> 0 then .quit 1;
