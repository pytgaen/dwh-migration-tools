-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Placement_Hot_Alimentation_CalculIDExterne.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul des ID externes pour les actes ERDV
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 19/12/2013      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H_EXT All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H_EXT
(
    EXTERNAL_ACTE_ID                      ,
    TYPE_SOURCE_ID                        ,
    INTRNL_SOURCE_ID                      ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    INTERVENTION_ID                       , 
    ORDER_LINE_EXTERNAL_ID                ,
    ORDER_LINE_STATUS_CD                  ,
    TYPE_OP_NM                            ,
    AGENT_ID                              ,
    ACTIVITY_UNIT_CD                      ,
    CONTRACT_CUSTOMER_LAST_NAME           ,
    CONTRACT_CUSTOMER_MARKET_SEG          ,
    CONTACT_CIVILITY_NM                   ,
    CONTACT_LAST_NAME_NM                  ,
    CONTACT_FIRST_NAME_NM                 ,
    CONTACT_MOBILE_NUMBER_NU              ,
    CONTACT_TEL_NUMBER_NU                 ,
    REF_GROUPED_OFFER_CD                  ,  
    GPC_ID                                ,
    STATUS_INTERVENTION_CD                ,
    DATE_RESERVATION_TS                   ,
    DATE_BEGIN_TS                         ,
    REF_ERDV_CD                           ,
    ORDER_LINE_CONTRACT_DATE_TS           ,
    ORDER_LINE_WANTED_DATE_TS             ,
    ORDER_LINE_PREST_CD                   ,
    ORDER_LINE_QUANTITY_QT                ,
    ORDER_LINE_AMOUNT_AM                  ,
    ORDER_LINE_TVA_RT                     ,
    ORDER_LINE_OPER_CD                    ,
    DELIVERY_CUSTOMER_MARKET_SEG          ,
    DELIVERY_CUSTOMER_LAST_NAME           ,
    DELIVERY_CUSTOMER_ADDRESS_APPT        ,
    DELIVERY_CUSTOMER_ADDRESS_ESC         ,
    DELIVERY_CUSTOMER_ADDRESS_STG         ,
    DELIVERY_CUSTOMER_ADDRESS_BAT         ,
    DELIVERY_CUSTOMER_ADDRESS_RES         ,
    DELIVERY_CUSTOMER_ADDRESS_ZIP         ,
    DELIVERY_CUSTOMER_ADDRESS_NUM         ,
    DELIVERY_CUSTOMER_ADDRESS_ST_T        ,
    DELIVERY_CUSTOMER_ADDRESS_STR         ,
    DELIVERY_CUSTOMER_ADDRESS_CITY        ,
    DELIVERY_CUSTOMER_ADDRESS_INSE        ,
    REF_OFFRE_CIBLE_CD                    ,
    CATALOGUE_CD                          ,    
    CUSTOMER_ND_NU                        ,
    CUSTOMER_NDS_NU                       ,    
    QUEUE_TS                              ,
    RUN_ID                                ,
    STREAMING_TS                          ,
    CREATION_TS                           ,
    LAST_MODIF_TS                         ,
    HOT_IN                                ,
    FRESH_IN                              ,
    COHERENCE_IN
)
Select
  --La clé est définie à partir de l'id commande + id ligne de commande + code produit
  trim(Commande.EXTERNAL_ORDER_ID)||'|'||trim(LigneCom.ORDER_LINE_EXTERNAL_ID)||'|'||trim(LigneCom.REF_OFFRE_CIBLE_CD)||'|'||trim(LigneCom.CATALOGUE_CD)  as EXTERNAL_ACTE_ID   ,
  ${IdentifiantTechniqueSource}                  as TYPE_SOURCE_ID                        ,
  ${IdSourceInterne}                             as INTRNL_SOURCE_ID                      ,
  Commande.EXTERNAL_ORDER_ID                     as EXTERNAL_ORDER_ID                     ,
  Commande.ORDER_DEPOSIT_TS                      as ORDER_DEPOSIT_TS                      ,
  Commande.ORDER_DEPOSIT_DT                      as ORDER_DEPOSIT_DT                      ,
  Commande.INTERVENTION_ID                       as INTERVENTION_ID                       ,
  LigneCom.ORDER_LINE_EXTERNAL_ID                as ORDER_LINE_EXTERNAL_ID                ,
  LigneCom.ORDER_LINE_STATUS_CD                  as ORDER_LINE_STATUS_CD                  ,
  Oper.TYPE_OP_NM                                as TYPE_OP_NM                            ,
  Commande.AGENT_ID                              as AGENT_ID                              ,
  Commande.ACTIVITY_UNIT_CD                      as ACTIVITY_UNIT_CD                      ,
  Commande.CUSTOMER_LAST_NAME_NM                 as CONTRACT_CUSTOMER_LAST_NAME           ,
  Commande.CUSTOMER_MARKET_SEG_CD                as CONTRACT_CUSTOMER_MARKET_SEG          ,
  Commande.CONTACT_CIVILITY_NM                   as CONTACT_CIVILITY_NM                   ,
  Commande.CONTACT_LAST_NAME_NM                  as CONTACT_LAST_NAME_NM                  ,
  Commande.CONTACT_FIRST_NAME_NM                 as CONTACT_FIRST_NAME_NM                 ,
  Commande.CONTACT_MOBILE_NUMBER_NU              as CONTACT_MOBILE_NUMBER_NU              ,
  Commande.CONTACT_TEL_NUMBER_NU                 as CONTACT_TEL_NUMBER_NU                 ,
  Commande.REF_GROUPED_OFFER_CD                  as REF_GROUPED_OFFER_CD                  ,
  Commande.GPC_ID                                as GPC_ID                                ,
  Commande.STATUS_INTERVENTION_CD                as STATUS_INTERVENTION_CD                ,
  Commande.DATE_RESERVATION_TS                   as DATE_RESERVATION_TS                   ,
  Commande.DATE_BEGIN_TS                         as DATE_BEGIN_TS                         ,
  Commande.REF_ERDV_CD                           as REF_ERDV_CD                           ,
  LigneCom.ORDER_LINE_CONTRACT_DATE_TS           as ORDER_LINE_CONTRACT_DATE_TS           ,
  LigneCom.ORDER_LINE_WANTED_DATE_TS             as ORDER_LINE_WANTED_DATE_TS             ,
  LigneCom.ORDER_LINE_PREST_CD                   as ORDER_LINE_PREST_CD                   ,
  LigneCom.ORDER_LINE_QUANTITY_QT                as ORDER_LINE_QUANTITY_QT                ,
  LigneCom.ORDER_LINE_AMOUNT_AM                  as ORDER_LINE_AMOUNT_AM                  ,
  LigneCom.ORDER_LINE_TVA_RT                     as ORDER_LINE_TVA_RT                     ,
  LigneCom.ORDER_LINE_OPER_CD                    as ORDER_LINE_OPER_CD                    ,
  LigneCom.CUSTOMER_MARKET_SEG_CD                as DELIVERY_CUSTOMER_MARKET_SEG          ,
  LigneCom.CUSTOMER_LAST_NAME_NM                 as DELIVERY_CUSTOMER_LAST_NAME           ,
  LigneCom.CUSTOMER_ADDRESS_APPT_NM              as DELIVERY_CUSTOMER_ADDRESS_APPT        ,
  LigneCom.CUSTOMER_ADDRESS_ESC_NM               as DELIVERY_CUSTOMER_ADDRESS_ESC         ,
  LigneCom.CUSTOMER_ADDRESS_STAGE_NM             as DELIVERY_CUSTOMER_ADDRESS_STG         ,
  LigneCom.CUSTOMER_ADDRESS_BAT_NM               as DELIVERY_CUSTOMER_ADDRESS_BAT         ,
  LigneCom.CUSTOMER_ADDRESS_RESIDENCE_NM         as DELIVERY_CUSTOMER_ADDRESS_RES         ,
  LigneCom.CUSTOMER_ADDRESS_ZIPCODE_CD           as DELIVERY_CUSTOMER_ADDRESS_ZIP         ,
  LigneCom.CUSTOMER_ADDRESS_NUMBER_NU            as DELIVERY_CUSTOMER_ADDRESS_NUM         ,
  LigneCom.CUSTOMER_ADDRESS_STR_TYPE_CD          as DELIVERY_CUSTOMER_ADDRESS_ST_T        ,
  LigneCom.CUSTOMER_ADDRESS_STREET_NM            as DELIVERY_CUSTOMER_ADDRESS_STR         ,
  LigneCom.CUSTOMER_ADDRESS_CITY_NM              as DELIVERY_CUSTOMER_ADDRESS_CITY        ,
  LigneCom.CUSTOMER_ADDRESS_INSEE_CD             as DELIVERY_CUSTOMER_ADDRESS_INSE        ,
  LigneCom.REF_OFFRE_CIBLE_CD                    as REF_OFFRE_CIBLE_CD                    ,
  LigneCom.CATALOGUE_CD                          as CATALOGUE_CD                          ,
  LigneCom.CUSTOMER_ND_NU                        as CUSTOMER_ND_NU                        ,
  LigneCom.CUSTOMER_NDS_NU                       as CUSTOMER_NDS_NU                       ,    
  Commande.QUEUE_TS                              as QUEUE_TS                              ,
  Commande.RUN_ID                                as RUN_ID                                ,
  Commande.STREAMING_TS                          as STREAMING_TS                          ,
  Current_Timestamp(0)                           as CREATION_TS                           ,
  Current_Timestamp(0)                           as LAST_MODIF_TS                         ,
  1                                              as HOT_IN                                ,
  1                                              as FRESH_IN                              ,
  0                                              as COHERENCE_IN
From
  --On prend tout le contenu de la table miroir tmp
  ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_COM Commande
  Inner Join ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_LINE_COM LigneCom
    On  Commande.EXTERNAL_ORDER_ID = LigneCom.EXTERNAL_ORDER_ID
  Inner Join ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_OPERATION Oper
    On  Commande.EXTERNAL_ORDER_ID = Oper.EXTERNAL_ORDER_ID
    And LigneCom.ORDER_LINE_EXTERNAL_ID = Oper.ORDER_LINE_EXTERNAL_ID
-- On ne garde qu'un type d'opération programmée pour une ligne de commande
Qualify row_number() over (partition by EXTERNAL_ACTE_ID order by TYPE_OP_NM desc)=1

;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H_EXT;
.if errorcode <> 0 then .quit 1

.quit 0
