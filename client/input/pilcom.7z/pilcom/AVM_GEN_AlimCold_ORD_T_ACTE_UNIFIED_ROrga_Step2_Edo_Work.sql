-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    AVM_GEN_AlimCold_ORD_T_ACTE_UNIFIED_ROrga_Step2_Edo_Work.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 02/05/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_WORK All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_WORK
(
  ACTE_ID                     ,
  AGENT_ID                    ,
  ACT_TS                      ,
  TRAV_ORGA_EQUI_CO_GRP       ,
  EDO_ID_EQUI_TRAV            ,
  FLAG_SCH_EQUI_TRAV          ,
  FLAG_HIER_EQUI_TRAV         ,
  FLAG_PLT_CONV_EQUI_TRAV     ,
  PRIO                        
)
Select
  ACT.ACTE_ID                             As ACTE_ID                    ,
  ORG.CUID                                As AGENT_ID                   ,
  ACT.ACT_TS                              As ACT_TS                     ,
  ORG.TRAV_ORGA_EQUI_CO_GRP               As TRAV_ORGA_EQUI_CO_GRP      ,
  ORG.EDO_ID_EQUI_TRAV                    As EDO_ID_EQUI_TRAV           ,
  ORG.FLAG_SCH_EQUI_TRAV                  As FLAG_SCH_EQUI_TRAV         ,
  ORG.FLAG_HIER_EQUI_TRAV                 As FLAG_HIER_EQUI_TRAV        ,
  ORG.FLAG_PLT_CONV_EQUI_TRAV             As FLAG_PLT_CONV_EQUI_TRAV    ,
  Case  When ORG.SOURCE = 'MCRM'
          Then 1
        When ORG.SOURCE = 'POCC'
          Then 1
        When ORG.SOURCE = 'HRF'
          Then 3
        When ORG.SOURCE = 'RFOR'
          Then 4
        When ORG.SOURCE = 'EDL'
          Then 5
        When ORG.SOURCE = 'OEE'
          Then 6
        Else 7
  End                                     As PRIO                       
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG As ACT
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORG
    On ACT.AGENT_ID     =   ORG.CUID
      And ACT.ACT_TS    >=  ORG.DT_DEBUT
      And ACT.ACT_TS    <=  ORG.DT_FIN
Where
  (1=1)
  And ORG.EDO_ID_EQUI_TRAV Is Not Null
Qualify Row_number() over (Partition by ACT.ACTE_ID Order By PRIO Asc , ORG.DT_DEBUT Desc, ORG.EDO_ID_EQUI_TRAV Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1


Collect Stat On  ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_WORK;
.if errorcode <> 0 then .quit 1

.quit 0
