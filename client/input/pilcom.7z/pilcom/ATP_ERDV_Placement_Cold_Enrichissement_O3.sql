-- $HEADER: mm2pco/current/sql/ATP_ERDV_Placement_Cold_Enrichissement_O3.sql 13_05#6 13-AVR-2017 08:51:23 FQJR5800
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Placement_Cold_Enrichissement_O3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 11/12/2014      KBH          Creation
-- 29/04/2015      YZH          Modif: Rajout flags SCH/AD
-- 23/06/2015      HZO          Modif: Application du QW AD +SC pour ERDV + Application du QW Activité pour les SC
-- 10/04/2017      JCR          Modif: ajout restriction dans le quickwin priorité SC QC 1641
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Création de la table Volatile                                                ----
----------------------------------------------------------------------------------------------

Create Multiset Volatile Table ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3(
      ACTE_ID                     BIGINT                  Not Null    ,
      ORDER_DEPOSIT_DT            DATE FORMAT 'YYYYMMDD'  Not Null    ,
      ACTIVITY_UNIT_CD            VARCHAR(15)                         ,
      EDO_ID                      BIGINT                              ,
      TYPE_EDO                    CHAR(3)                             ,
      FLAG_PLT_CONV               BYTEINT                             ,
      FLAG_PLT_SCH                BYTEINT                             ,
      FLAG_PLT_AD                 BYTEINT                             ,
      FLAG_PLT_PRO                BYTEINT                             ,
      FLAG_TEAM_MKT               BYTEINT                             ,
      FLAG_TYPE_CMP               CHAR(1)                             ,
      NETWRK_TYP_EDO_ID           CHAR(2)                             ,
      FLAG_TYPE_GEO               VARCHAR(15)                         ,
      FLAG_TYPE_CPT_NTK           VARCHAR(10)                         ,
      FLAG_TYPE_PTN_NTK           VARCHAR(10)                         ,
      ORIGIN                      BYTEINT                             
)
Primary Index(
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table avec les données QW AD                              ----
----------------------------------------------------------------------------------------------

Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  ACTIVITY_UNIT_CD        ,
  EDO_ID                  ,
  TYPE_EDO                ,
  FLAG_PLT_CONV           ,
  FLAG_PLT_SCH            ,
  FLAG_PLT_AD             ,
  FLAG_PLT_PRO            ,
  FLAG_TEAM_MKT           ,
  FLAG_TYPE_CMP           ,
  NETWRK_TYP_EDO_ID       ,
  FLAG_TYPE_GEO           ,
  FLAG_TYPE_CPT_NTK       ,
  FLAG_TYPE_PTN_NTK       ,
  ORIGIN                  
)
Select
  Placement.ACTE_ID                                          AS EXTERNAL_ORDER_ID                 ,
  Placement.ORDER_DEPOSIT_DT                                 AS ORDER_DEPOSIT_DT                  ,
  Placement.ACTIVITY_UNIT_CD                                 AS ACTIVITY_UNIT_CD                  ,
  RefO3AD.EDO_ID                                             AS EDO_ID                            ,
  RefO3AD.TYPE_EDO                                           As TYPE_EDO                          ,
  RefO3AD.FLAG_PLT_CONV_NB                                   As FLAG_PLT_CONV                     ,
  0                                                          As FLAG_PLT_SCH                      ,
  1                                                          As FLAG_PLT_AD                       ,
  Case  When RefEdoPRO.EDO_ID Is Not Null
          Then  1 --Si on trouve une correspondance alors c'est un plateau PRO
        Else    0
  End                                                        As FLAG_PLT_PRO                      ,
  Null                                                       As FLAG_TEAM_MKT                     ,
  '#'                                                        AS FLAG_TYPE_CMP                     ,
  RefO3AD.NETWRK_TYP_EDO_ID                                  AS NETWRK_TYP_EDO_ID                 ,
  RefO3AD.FLAG_TYPE_GEO_CD                                   AS FLAG_TYPE_GEO                     ,
  RefO3AD.FLAG_TYPE_CPT_NTK_NU                               AS FLAG_TYPE_CPT_NTK                 ,
  Null                                                       AS FLAG_TYPE_PTN_NTK                 ,
  2                                                          As ORIGIN                            
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_EXTR Placement
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_AD_EDO As RefO3AD
      On    Placement.AGENT_ID      =   RefO3AD.CUID
      And Placement.ORDER_DEPOSIT_TS      >=  RefO3AD.DT_DEBUT
      And Placement.ORDER_DEPOSIT_TS      <=   RefO3AD.DT_FIN
  Left Outer Join
      (
        Select
          EDO_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in ('GSCP','1016','ATH')
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
            Group By
            EDO_ID
      ) RefEdoPRO
      On  RefO3AD.EDO_ID   = RefEdoPRO.EDO_ID
Where
    (1=1)
    And RefO3AD.EDO_ID Is Not Null
-- Verification qu’il n’y a rien dans le QW SC avec une date de debut posterieure au QW AD 
    And Not Exists ( 
        Select 
        1 
        From ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORGSC
        where  Placement.AGENT_ID            =     ORGSC.CUID
        And Placement.ORDER_DEPOSIT_TS      >=    ORGSC.DT_DEBUT
        And Placement.ORDER_DEPOSIT_TS      <=    ORGSC.DT_FIN
        And ORGSC.DT_DEBUT                  >     RefO3AD.DT_DEBUT
    )
Qualify Row_number() over (Partition by Placement.EXTERNAL_ORDER_ID,Placement.ORDER_DEPOSIT_DT Order By  RefO3AD.DT_DEBUT Desc, RefO3AD.EDO_ID Asc, RefO3AD.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3 Column (ACTE_ID);
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 3 : Alimentation de la table avec les données QW SC                              ----
----------------------------------------------------------------------------------------------

Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  ACTIVITY_UNIT_CD        ,
  EDO_ID                  ,
  TYPE_EDO                ,
  FLAG_PLT_CONV           ,
  FLAG_PLT_SCH            ,
  FLAG_PLT_AD             ,
  FLAG_PLT_PRO            ,
  FLAG_TEAM_MKT           ,
  FLAG_TYPE_CMP           ,
  NETWRK_TYP_EDO_ID       ,
  FLAG_TYPE_GEO           ,
  FLAG_TYPE_CPT_NTK       ,
  FLAG_TYPE_PTN_NTK       ,
  ORIGIN                  
)
Select 
  RefSC.EXTERNAL_ORDER_ID                 ,
  RefSC.ORDER_DEPOSIT_DT                  ,
  RefSC.ACTIVITY_UNIT_CD                  ,
  RefSC.EDO_ID                            ,
  RefSC.TYPE_EDO                          ,
  RefSC.FLAG_PLT_CONV                     ,
  RefSC.FLAG_PLT_SCH                      ,
  RefSC.FLAG_PLT_AD                       ,
  RefSC.FLAG_PLT_PRO                      ,
  RefSC.FLAG_TEAM_MKT                     ,
  RefSC.FLAG_TYPE_CMP                     ,
  RefSC.NETWRK_TYP_EDO_ID                 ,
  RefSC.FLAG_TYPE_GEO                     ,
  RefSC.FLAG_TYPE_CPT_NTK                 ,
  RefSC.FLAG_TYPE_PTN_NTK                 ,
  1                                       
From
(
  Select
    Placement.ACTE_ID                                          AS EXTERNAL_ORDER_ID                 ,
    Placement.ORDER_DEPOSIT_DT                                 AS ORDER_DEPOSIT_DT                  ,
    Placement.ACTIVITY_UNIT_CD                                 AS ACTIVITY_UNIT_CD                  ,
    RefO3SC.EDO_ID_EQUI_RAT                                    AS EDO_ID                            ,
    RefO3SC.FLAG_HIER_EQUI_RAT                                 As TYPE_EDO                          ,
    RefO3SC.FLAG_PLT_CONV_EQUI_RAT                             As FLAG_PLT_CONV                     ,
    RefO3SC.FLAG_SCH_EQUI_RAT                                  As FLAG_PLT_SCH                      ,
    0                                                          As FLAG_PLT_AD                       ,
    Case  When RefEdoPRO.EDO_ID Is Not Null
            Then  1 --Si on trouve une correspondance alors c'est un plateau PRO
          Else    0
    End                                                        As FLAG_PLT_PRO                      ,
    Null                                                       As FLAG_TEAM_MKT                     ,
    '#'                                                        AS FLAG_TYPE_CMP                     ,
    RefEDO.NETWRK_TYP_EDO_ID                                   AS NETWRK_TYP_EDO_ID                 ,
    Null                                                       AS FLAG_TYPE_GEO                     ,
    Null                                                       AS FLAG_TYPE_CPT_NTK                 ,
    Null                                                       AS FLAG_TYPE_PTN_NTK                 ,
    Case  When RefO3SC.SOURCE = 'MCRM'
            Then 1
          When RefO3SC.SOURCE = 'POCC'
            Then 2
          When RefO3SC.SOURCE = 'HRF'
            Then 3
          When RefO3SC.SOURCE = 'RFOR'
            Then 4
          When RefO3SC.SOURCE = 'EDL'
            Then 5
          When RefO3SC.SOURCE = 'OEE'
            Then 6
          Else 7
    End                                                        As PRIO                               
  From
    ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_EXTR Placement
    Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO RefO3SC
      On Placement.AGENT_ID                 =     RefO3SC.CUID
        And Placement.ORDER_DEPOSIT_DT      >=    RefO3SC.DT_DEBUT
        And Placement.ORDER_DEPOSIT_DT      <=    RefO3SC.DT_FIN
        And RefO3SC.EDO_ID_EQUI_RAT is not null
    Left outer Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEDO
      On RefO3SC.EDO_ID_EQUI_RAT            =     RefEDO.EDO_ID
        And RefEDO.CURRENT_IN = 1
        And RefEDO.CLOSURE_DT Is Null
    Left Outer Join
        (
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
              (1=1)
              And EdoAx.VAL_AXS_CLSSF_ID  in ('GSCP','1016','ATH')
              And EdoAx.FRESH_IN          = 1
              And EdoAx.CURRENT_IN        = 1
              And EdoAx.CLOSURE_DT        Is Null
              Group By
              EDO_ID
        ) RefEdoPRO
        On  RefO3SC.EDO_ID_EQUI_RAT   = RefEdoPRO.EDO_ID
  Qualify Row_number() over (Partition by Placement.ACTE_ID Order By PRIO Asc , RefO3SC.DT_DEBUT Desc, RefO3SC.EDO_ID_EQUI_RAT Asc, RefO3SC.DT_FIN Desc) = 1
) RefSC
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3 Column (ACTE_ID);
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 4 : Alimentation de la table avec les données O3 ERDV                            ----
----------------------------------------------------------------------------------------------

Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  ACTIVITY_UNIT_CD        ,
  EDO_ID                  ,
  TYPE_EDO                ,
  FLAG_PLT_CONV           ,
  FLAG_PLT_SCH            ,
  FLAG_PLT_AD             ,
  FLAG_PLT_PRO            ,
  FLAG_TEAM_MKT           ,
  FLAG_TYPE_CMP           ,
  NETWRK_TYP_EDO_ID       ,
  FLAG_TYPE_GEO           ,
  FLAG_TYPE_CPT_NTK       ,
  FLAG_TYPE_PTN_NTK       ,
  ORIGIN                  
)
Select
  Placement.ACTE_ID                                          AS EXTERNAL_ORDER_ID                 ,
  Placement.ORDER_DEPOSIT_DT                                 AS ORDER_DEPOSIT_DT                  ,
  Placement.ACTIVITY_UNIT_CD                                 AS ACTIVITY_UNIT_CD                  ,
  RefO3.EDO_ID                                               AS EDO_ID                            ,
  RefO3.TYPE_EDO                                             As TYPE_EDO                          ,
  RefO3.FLAG_PLT_CONV                                        As FLAG_PLT_CONV                     ,
  RefO3.FLAG_PLT_SCH                                         As FLAG_PLT_SCH                      ,
  RefO3.FLAG_PLT_AD                                          As FLAG_PLT_AD                       ,
  RefO3.FLAG_PLT_PRO                                         As FLAG_PLT_PRO                      ,
  Null                                                       As FLAG_TEAM_MKT                     ,
  '#'                                                        AS FLAG_TYPE_CMP                     ,
  RefO3.NETWRK_TYP_EDO_ID                                    AS NETWRK_TYP_EDO_ID                 ,
  RefO3.FLAG_TYPE_GEO                                        AS FLAG_TYPE_GEO                     ,
  RefO3.FLAG_TYPE_CPT_NTK                                    AS FLAG_TYPE_CPT_NTK                 ,
  RefO3.FLAG_TYPE_PTN_NTK                                    AS FLAG_TYPE_PTN_NTK                 ,
  0                                                          As ORIGIN                            
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_EXTR Placement
  Inner Join ${KNB_PCO_TMP}.CAT_W_ERDV_REF_O3 RefO3
    On Placement.ACTIVITY_UNIT_CD = RefO3.EXTNL_VAL_COD_CD
    And Placement.ORDER_DEPOSIT_DT Between RefO3.START_EXTNL_VAL_DT
    And Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
  Qualify Row_Number() Over(Partition by  Placement.ACTE_ID
                          Order by      RefO3.START_EXTNL_VAL_DT Desc,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3 Column (ACTE_ID);
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 5 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_O3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 6 : Dédoublonnage et alimentation de la table de travail Par priorité            ----
----------------------------------------------------------------------------------------------

Insert into  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_O3
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  ACTIVITY_UNIT_CD        ,
  EDO_ID                  ,
  TYPE_EDO                ,
  FLAG_PLT_CONV           ,
  FLAG_PLT_SCH            ,
  FLAG_PLT_AD             ,
  FLAG_PLT_PRO            ,
  FLAG_TEAM_MKT           ,
  FLAG_TYPE_CMP           ,
  NETWRK_TYP_EDO_ID       ,
  FLAG_TYPE_GEO           ,
  FLAG_TYPE_CPT_NTK       ,
  FLAG_TYPE_PTN_NTK       ,
  ORIGIN                  
)
Select
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  ACTIVITY_UNIT_CD        ,
  EDO_ID                  ,
  TYPE_EDO                ,
  FLAG_PLT_CONV           ,
  FLAG_PLT_SCH            ,
  FLAG_PLT_AD             ,
  FLAG_PLT_PRO            ,
  FLAG_TEAM_MKT           ,
  FLAG_TYPE_CMP           ,
  NETWRK_TYP_EDO_ID       ,
  FLAG_TYPE_GEO           ,
  FLAG_TYPE_CPT_NTK       ,
  FLAG_TYPE_PTN_NTK       ,
  ORIGIN                  
From
  ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ERDV_C_O3
Qualify Row_Number() over (Partition by ACTE_ID, ORDER_DEPOSIT_DT order by ORIGIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_O3;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 7 : Application  du QW Activité SC                                               ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_ACT All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_ACT
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  AGENT_ID                      ,
  START_ACTIVITY_TS             ,
  END_ACTIVITY_TS               ,
  ACTIVITY                      ,
  PRIO                          
)
Select
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  AGENT_ID             ,
  START_ACTIVITY_TS    ,
  END_ACTIVITY_TS      ,
  ACTIVITY             ,
  PRIO                 
From
(
  Select
    Placement.ACTE_ID                       As ACTE_ID              ,
    Placement.ORDER_DEPOSIT_DT              As ORDER_DEPOSIT_DT     ,
    ACTIVITY.CUID                           As AGENT_ID             ,
    ACTIVITY.START_ACTIVITY_TS              As START_ACTIVITY_TS    ,
    ACTIVITY.END_ACTIVITY_TS                As END_ACTIVITY_TS      ,
    ACTIVITY.ACTIVITY                       As ACTIVITY             ,
    Case  When ACTIVITY.SOURCE = 'RFOR'
            Then 1
          When ACTIVITY.SOURCE = 'CHO'
            Then 2
          Else 3
    End                                     As PRIO
  From
    ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_EXTR As Placement
    Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_ACTIVITY As ACTIVITY
      On    Placement.AGENT_ID    =   ACTIVITY.CUID
        And Placement.ORDER_DEPOSIT_TS      >=  ACTIVITY.START_ACTIVITY_TS
        And Placement.ORDER_DEPOSIT_TS      <=  ACTIVITY.END_ACTIVITY_TS
  Where
    (1=1)
  Qualify Row_number() over
              (Partition by
                  Placement.ACTE_ID                 ,
                  Placement.ORDER_DEPOSIT_DT        
               Order By
                  PRIO ASC                          ,
                  ACTIVITY.START_ACTIVITY_TS Desc   ,
                  ACTIVITY.END_ACTIVITY_TS Desc     
              ) = 1
 ) RefAct
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_C_ACT;
.if errorcode <> 0 then .quit 1

.quit 0
