-- $HEADER: mm2pco/current/sql/ATP_EXF_Placement_C_Alimentation_Step3_Enrich_O3.sql 13_05#7 05-AVR-2019 17:22:15 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EXF_Placement_C_Alimentation_Step3_Enrich_O3.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement O3 du placement 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 11/07/2014      OCH           Creation
-- 02/03/2016      TPI           QC 1072 : Modification paramÃ¨tres
-- 07/11/2018      LMU           Modifications : QC 1798 : Prise en compte REINJ
-- 22/03/2019      SSI           Modifications : Calcul de l'axe canal via O3
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3 All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP  avec ACT_W_PL_EXF_C_PL                         ----
----------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3
(
  ACTE_ID                ,
  ORDER_DEPOSIT_DT       ,
  EDO_ID                 ,
  EXTNL_VAL_COD_CD       ,
  FLAG_PLT_CONV_IN       ,
  FLAG_PLT_SCH_IN        ,
  TYPE_EDO_IN            ,
  FLAG_TYPE_GEO_IN       ,
  FLAG_TYPE_CPT_NTK_IN   ,
  NETWRK_TYP_EDO_ID      ,
  VAL_AXS_CLSSF_ID_SSCNL ,
  VAL_AXS_CLSSF_ID_CVG   ,
  VAL_AXS_CLSSF_ID_PSFL  ,
  VAL_AXS_CLSSF_ID_GMM   
)
Select
  RefId.ACTE_ID                     As ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT            As ORDER_DEPOSIT_DT     ,
  RefId.EDO_ID                      As EDO_ID               ,
  RefADV.EXTNL_VAL_COD_CD           As EXTNL_VAL_COD_CD     ,
  --On vÃ©rifie si le plateau travail sur du convergent ou pas
  Case  When RefEdoConv.EDO_ID Is Not Null
          Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
        When RefEdoAVSC.EDO_ID Is Not Null
          Then  1
        Else    0
  End                               As FLAG_PLT_CONV_IN        ,
  Case  When RefEdoAVSC.EDO_ID Is Not Null
          Then  1
        Else    0
  End                               As FLAG_PLT_SCH_IN         ,
  Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT' --
          Then  '${P_PIL_235}'
        Else    '${P_PIL_236}'
  End                               As TYPE_EDO_IN             ,
  RefEdoDOM.AXS_CLSSF_ID            As FLAG_TYPE_GEO_IN        ,
  RefEdoCompNetwork.AXS_CLSSF_ID    As FLAG_TYPE_CPT_NTK_IN    ,
  RefEdo.NETWRK_TYP_EDO_ID          As NETWRK_TYP_EDO_ID       ,
  RefEdoSSCNL.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID_SSCNL  ,
  RefEdoCVG.VAL_AXS_CLSSF_ID        As VAL_AXS_CLSSF_ID_CVG    ,
  RefEdoPSFL.VAL_AXS_CLSSF_ID       As VAL_AXS_CLSSF_ID_PSFL   ,
  RefEdoGMM.VAL_AXS_CLSSF_ID        As VAL_AXS_CLSSF_ID_GMM     
From
  ( Select PL.ACTE_ID,PL.ORDER_DEPOSIT_DT,PL.EDO_ID 
      From ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL PL
   )RefId
      --On va dans le rÃ©fÃ©rentiel des EDO pour savoir si c'est un PDV interne ou Externe
    Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
      On    RefId.EDO_ID          = RefEdo.EDO_ID
        And RefEdo.CURRENT_IN     = 1
        And RefEdo.CLOSURE_DT     Is Null
    Inner Join ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefADV -- Recuperation du code ADV
      On    RefADV.EDO_ID = RefId.EDO_ID
        And   RefADV.CURRENT_IN   = 1
        And   RefADV.FRESH_IN     = 1
        And   RefADV.CLOSURE_DT   Is NULL    
    Left Outer Join
    (--On applique ici la sous- requete qui permet de savoir si l'EDO a dÃ©jÃ  Ã©tÃ© convergent
      Select
        EDO_ID                          As EDO_ID
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF ClassAx
          On    EdoAx.VAL_AXS_CLSSF_ID  = ClassAx.AXS_CLSSF_ID
            And ClassAx.FRESH_IN        = 1
            And ClassAx.CURRENT_IN      = 1
            And ClassAx.CLOSURE_DT      Is Null
      Where
            (1=1)
            And ClassAx.NAME_CLSSF_DS   = 'Convergent' --Like '${P_PIL_336}%'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
      Group By
                EDO_ID
    ) RefEdoConv
    On  RefId.EDO_ID   = RefEdoConv.EDO_ID
    --On va dans le referentiel axs_edo pour remonter les CARAIBES et REUNION
    Left Outer Join
    (
      Select
        EDO_ID                          As EDO_ID             ,
        VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111}) -- 'CARAIBES','REUNION'
        And EdoAx.FRESH_IN              = 1
        And EdoAx.CURRENT_IN            = 1
        And EdoAx.CLOSURE_DT            Is Null
      Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
    ) RefEdoDOM
    On  RefId.EDO_ID   = RefEdoDOM.EDO_ID
    --On va dans le referentiel axs_edo pour remonter les GSS et GSA
    Left Outer Join
    (
      Select
        EDO_ID                          As EDO_ID             ,
        VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112}) -- 'GSS','GSA','AUTRC'
        And EdoAx.FRESH_IN              = 1
        And EdoAx.CURRENT_IN            = 1
        And EdoAx.CLOSURE_DT            Is Null
      Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
    ) RefEdoCompNetwork
    On  RefId.EDO_ID   = RefEdoCompNetwork.EDO_ID
    Left Outer Join
    (
      --On applique ici la sous- requete qui permet de savoir si l'EDO appartient Ã  un plateau AVSC (1014)
      Select
        EDO_ID
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In (${L_PIL_113}) -- 'GSCR','1014'
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      Group By
        EDO_ID
    ) RefEdoAVSC
    On  RefId.EDO_ID   = RefEdoAVSC.EDO_ID
    
    -- Recuperation Axe classif pour le sous canal
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.RGT_ID         In ('AD', 'RP', 'RC')
          And AxClss.NAME_CLSSF_DS  = 'Sous Canal'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
        And EdoAx.VAL_AXS_CLSSF_ID  In ('BTQ','PSE', 'PST','OCA','ORM','CONS','ORM','POD', 'GSA','GSS','ATH','SCC','PAE','1016', 'GSCP', 'B2P', 'BOP', 'CBO', 'CN2', 'DEF', 'DVI', 'TEP', 'MPP','OPEN','SOSH','1014','GSCR','700','OFP')
  
      ) RefEdoSSCNL
      On RefId.EDO_ID              =   RefEdoSSCNL.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoSSCNL.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoSSCNL.START_VAL_AXS_DT
  
      -- Recuperation Axe classif pour convergent
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.NAME_CLSSF_DS  = 'Convergent'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
  
      ) RefEdoCVG
      On RefId.EDO_ID              =   RefEdoCVG.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoCVG.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoCVG.START_VAL_AXS_DT
  
      -- Recuperation Axe classif pour canal de vente Parsifal
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.NAME_CLSSF_DS  = 'Canal de vente (PARSIFAL)'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
  
      ) RefEdoPSFL
      On RefId.EDO_ID              =   RefEdoPSFL.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoPSFL.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoPSFL.START_VAL_AXS_DT
  
      -- Recuperation Axe classif pour la gamme
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.NAME_CLSSF_DS  = 'Gamme'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
  
      ) RefEdoGMM
      On RefId.EDO_ID              =   RefEdoGMM.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoGMM.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoGMM.START_VAL_AXS_DT

Where
  (1=1)
Qualify Row_Number() Over(Partition by
                                        RefId.ACTE_ID,
                                        RefId.ORDER_DEPOSIT_DT order by 1 Asc)=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP  avec V_ACT_F_PLACEMENT_EXF                     ----
----------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3
(
  ACTE_ID                ,
  ORDER_DEPOSIT_DT       ,
  EDO_ID                 ,
  EXTNL_VAL_COD_CD       ,
  FLAG_PLT_CONV_IN       ,
  FLAG_PLT_SCH_IN        ,
  TYPE_EDO_IN            ,
  FLAG_TYPE_GEO_IN       ,
  FLAG_TYPE_CPT_NTK_IN   ,
  NETWRK_TYP_EDO_ID      ,
  VAL_AXS_CLSSF_ID_SSCNL ,
  VAL_AXS_CLSSF_ID_CVG   ,
  VAL_AXS_CLSSF_ID_PSFL  ,
  VAL_AXS_CLSSF_ID_GMM   
)
Select
  RefId.ACTE_ID                     As ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT            As ORDER_DEPOSIT_DT     ,
  RefId.EDO_ID                      As EDO_ID               ,
  RefADV.EXTNL_VAL_COD_CD           As EXTNL_VAL_COD_CD     ,
--On vÃ©rifie si le plateau travail sur du convergent ou pas
  Case  When RefEdoConv.EDO_ID Is Not Null
          Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
        When RefEdoAVSC.EDO_ID Is Not Null
          Then  1
        Else    0
  End                               As FLAG_PLT_CONV_IN        ,
  Case  When RefEdoAVSC.EDO_ID Is Not Null
          Then  1
        Else    0
  End                               As FLAG_PLT_SCH_IN         ,
  Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT' --
          Then  '${P_PIL_235}'
        Else    '${P_PIL_236}'
  End                               As TYPE_EDO_IN             ,
  RefEdoDOM.AXS_CLSSF_ID            As FLAG_TYPE_GEO_IN        ,
  RefEdoCompNetwork.AXS_CLSSF_ID    As FLAG_TYPE_CPT_NTK_IN    ,
  RefEdo.NETWRK_TYP_EDO_ID          As NETWRK_TYP_EDO_ID       ,
  RefEdoSSCNL.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID_SSCNL  ,
  RefEdoCVG.VAL_AXS_CLSSF_ID        As VAL_AXS_CLSSF_ID_CVG    ,
  RefEdoPSFL.VAL_AXS_CLSSF_ID       As VAL_AXS_CLSSF_ID_PSFL   ,
  RefEdoGMM.VAL_AXS_CLSSF_ID        As VAL_AXS_CLSSF_ID_GMM     

From
  (  Select VPL.ACTE_ID,VPL.ORDER_DEPOSIT_DT,VPL.EDO_ID
      From ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF VPL
      Where  VPL.ORDER_DEPOSIT_DT > Cast(Cast(${KNB_PILCOM_ACTE_BORNE_INF} As Char(8)) as Date Format 'YYYYMMDD')
      And    VPL.ORDER_DEPOSIT_DT < Cast(Cast(${KNB_PILCOM_ACTE_BORNE_MAX} As Char(8)) as Date Format 'YYYYMMDD') 
   )RefId
      --On va dans le rÃ©fÃ©rentiel des EDO pour savoir si c'est un PDV interne ou Externe
    Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
      On    RefId.EDO_ID          = RefEdo.EDO_ID
        And RefEdo.CURRENT_IN     = 1
        And RefEdo.CLOSURE_DT     Is Null
    Inner Join ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefADV -- Recuperation du code ADV
      On    RefADV.EDO_ID = RefId.EDO_ID
        And   RefADV.CURRENT_IN   = 1
        And   RefADV.FRESH_IN     = 1
        And   RefADV.CLOSURE_DT   Is NULL    
    Left Outer Join
    (--On applique ici la sous- requete qui permet de savoir si l'EDO a dÃ©jÃ  Ã©tÃ© convergent
      Select
        EDO_ID                          As EDO_ID
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF ClassAx
          On    EdoAx.VAL_AXS_CLSSF_ID  = ClassAx.AXS_CLSSF_ID
            And ClassAx.FRESH_IN        = 1
            And ClassAx.CURRENT_IN      = 1
            And ClassAx.CLOSURE_DT      Is Null
      Where
            (1=1)
            And ClassAx.NAME_CLSSF_DS   = 'Convergent' --Like '${P_PIL_336}%'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
      Group By
                EDO_ID
    ) RefEdoConv
    On  RefId.EDO_ID   = RefEdoConv.EDO_ID
    --On va dans le referentiel axs_edo pour remonter les CARAIBES et REUNION
    Left Outer Join
    (
      Select
        EDO_ID                          As EDO_ID             ,
        VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111}) -- 'CARAIBES','REUNION'
        And EdoAx.FRESH_IN              = 1
        And EdoAx.CURRENT_IN            = 1
        And EdoAx.CLOSURE_DT            Is Null
      Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
    ) RefEdoDOM
    On  RefId.EDO_ID   = RefEdoDOM.EDO_ID
    --On va dans le referentiel axs_edo pour remonter les GSS et GSA
    Left Outer Join
    (
      Select
        EDO_ID                          As EDO_ID             ,
        VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112}) -- 'GSS','GSA','AUTRC'
        And EdoAx.FRESH_IN              = 1
        And EdoAx.CURRENT_IN            = 1
        And EdoAx.CLOSURE_DT            Is Null
      Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
    ) RefEdoCompNetwork
    On  RefId.EDO_ID   = RefEdoCompNetwork.EDO_ID
    Left Outer Join
    (
      --On applique ici la sous- requete qui permet de savoir si l'EDO appartient Ã  un plateau AVSC (1014)
      Select
        EDO_ID
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In (${L_PIL_113}) -- 'GSCR','1014'
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      Group By
        EDO_ID
    ) RefEdoAVSC
    On  RefId.EDO_ID   = RefEdoAVSC.EDO_ID
    
    -- Recuperation Axe classif pour le sous canal
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.RGT_ID         In ('AD', 'RP', 'RC')
          And AxClss.NAME_CLSSF_DS  = 'Sous Canal'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
        And EdoAx.VAL_AXS_CLSSF_ID  In ('BTQ','PSE', 'PST','OCA','ORM','CONS','ORM','POD', 'GSA','GSS','ATH','SCC','PAE','1016', 'GSCP', 'B2P', 'BOP', 'CBO', 'CN2', 'DEF', 'DVI', 'TEP', 'MPP','OPEN','SOSH','1014','GSCR','700','OFP')
  
      ) RefEdoSSCNL
      On RefId.EDO_ID              =   RefEdoSSCNL.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoSSCNL.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoSSCNL.START_VAL_AXS_DT
  
      -- Recuperation Axe classif pour convergent
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.NAME_CLSSF_DS  = 'Convergent'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
  
      ) RefEdoCVG
      On RefId.EDO_ID              =   RefEdoCVG.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoCVG.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoCVG.START_VAL_AXS_DT
  
      -- Recuperation Axe classif pour canal de vente Parsifal
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.NAME_CLSSF_DS  = 'Canal de vente (PARSIFAL)'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
  
      ) RefEdoPSFL
      On RefId.EDO_ID              =   RefEdoPSFL.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoPSFL.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoPSFL.START_VAL_AXS_DT
  
      -- Recuperation Axe classif pour la gamme
    Left Outer Join
    (
      Select
        EdoAx.EDO_ID                As EDO_ID           ,
        EdoAx.VAL_AXS_CLSSF_ID      As VAL_AXS_CLSSF_ID ,
        EdoAx.START_VAL_AXS_DT      As START_VAL_AXS_DT ,
        Coalesce (EdoAx.END_VAL_AXS_DT, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY')) As END_VAL_AXS_DT
      From 
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF AxClss 
        On AxClss.AXS_CLSSF_ID = EdoAx.VAL_AXS_CLSSF_ID
          And AxClss.NAME_CLSSF_DS  = 'Gamme'
          And AxClss.FRESH_IN       = 1
          And AxClss.CURRENT_IN     = 1
          And AxClss.CLOSURE_DT     Is Null
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
  
      ) RefEdoGMM
      On RefId.EDO_ID              =   RefEdoGMM.EDO_ID 
      And RefId.ORDER_DEPOSIT_DT  <   RefEdoGMM.END_VAL_AXS_DT
      And RefId.ORDER_DEPOSIT_DT  >=  RefEdoGMM.START_VAL_AXS_DT

Where
  (1=1)
Qualify Row_Number() Over(Partition by
                                        RefId.ACTE_ID,
                                        RefId.ORDER_DEPOSIT_DT order by 1 Asc )=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3;
.if errorcode <> 0 then .quit 1

.quit 0