-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_CRF_Referentiel_MiseAPlatRefcom.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  EXTRACTION DES SEULS PRODUITS OPENCAT PRESENTS DANS LE REFERENTIEL COMMERCIAL REFCOM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 03/06/2016      GMA         Modif variable refcom
--------------------------------------------------------------------------------
-- 

DELETE FROM      ${KNB_PCO_TMP}.CAT_R_REF_PRODUCT_HRF ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.CAT_R_REF_PRODUCT_HRF
                  (
                    PRODUCT_ID
                  , COMPST_OFFR_ID
                  , ATOMIC_OFFR_ID
                  , FUNCTN_ID
                  , FUNCTN_VALUE_ID
                  )
SELECT             V_CAT_R_REF_PRODUCT_OPENCAT.PRODUCT_ID                                       AS PRODUCT_ID
                 , CASE WHEN TT.TT_OFFR_TYPE_ID = '${P_PIL_294}'
                        THEN '${P_PIL_293}' || V_CAT_R_REF_PRODUCT_OPENCAT.COMPST_OFFR_ID
                        ELSE  V_CAT_R_REF_PRODUCT_OPENCAT.COMPST_OFFR_ID
                   END                                                                          AS COMPST_OFFR_ID
                 , CASE WHEN TT.TT_OFFR_TYPE_ID = '${P_PIL_294}'
                        THEN '${P_PIL_293}' || V_CAT_R_REF_PRODUCT_OPENCAT.ATOMIC_OFFR_ID
                        ELSE V_CAT_R_REF_PRODUCT_OPENCAT.ATOMIC_OFFR_ID
                   END                                                                          AS ATOMIC_OFFR_ID 
                 , CASE WHEN TT.TT_OFFR_TYPE_ID = '${P_PIL_294}'
                        THEN '${P_PIL_293}' || V_CAT_R_REF_PRODUCT_OPENCAT.FUNCTN_ID
                        ELSE V_CAT_R_REF_PRODUCT_OPENCAT.FUNCTN_ID
                   END                                                                          AS FUNCTN_ID 
                 , V_CAT_R_REF_PRODUCT_OPENCAT.FUNCTN_VALUE_ID                                  AS FUNCTN_VALUE_ID
FROM             ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OPENCAT                                     V_CAT_R_REF_PRODUCT_OPENCAT

LEFT JOIN         (

                    SELECT   CAT_R_PRODUCT_TYPE.PRODCT_EXTRNL_PRINCPL_ID                                            AS TT_PRODCT_EXTRNL_PRINCPL_ID
                           , CAT_R_PRODUCT_TYPE.OFFR_TYPE_ID                                                        AS TT_OFFR_TYPE_ID
                    FROM     ${KNB_COM_SOC}.V_CAT_R_PRODUCT_TYPE                                                              CAT_R_PRODUCT_TYPE
                    WHERE    1                                                                               =         1
                    AND      CAT_R_PRODUCT_TYPE.CURRENT_IN                                                   =         1
                    AND      CAT_R_PRODUCT_TYPE.CLOSURE_DT                                                   IS NULL
                  -- CONSERVATION EXCLUSIVE DE L'ETAT DU PRODUIT LE PLUS RECENT
                    QUALIFY  ROW_NUMBER() OVER(
                                                PARTITION BY CAT_R_PRODUCT_TYPE.PRODCT_EXTRNL_PRINCPL_ID
                                                ORDER BY     CAT_R_PRODUCT_TYPE.CREATION_TS DESC
                                              )                                                              =         1
                    
                    
                  ) TT (
                         TT_PRODCT_EXTRNL_PRINCPL_ID
                       , TT_OFFR_TYPE_ID
                       )

ON                 V_CAT_R_REF_PRODUCT_OPENCAT.COMPST_OFFR_ID                  =         TT.TT_PRODCT_EXTRNL_PRINCPL_ID

WHERE              1                                                           =         1
-- SELECTION EXCLUSIVE DE L'ETAT COURANT ET ACTIF DANS LE REFERENTIEL DES PRODUITS OPENCAT
AND                V_CAT_R_REF_PRODUCT_OPENCAT.CURRENT_IN                      =         1
AND                V_CAT_R_REF_PRODUCT_OPENCAT.CLOSURE_DT                      IS NULL
AND                                                                            EXISTS
                  (
                    SELECT   1
                    FROM   ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM                  V_CAT_R_LIEN_PRD_SGMCM_PILCOM
                    WHERE    1                                                 =         1
                    AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.PRODUCT_ID          =         V_CAT_R_REF_PRODUCT_OPENCAT.PRODUCT_ID
                  -- début Xavier
                    AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.PERIODE_ID          =         V_CAT_R_REF_PRODUCT_OPENCAT.PERIODE_ID
                  -- fin Xavier  

                  -- SELECTION EXCLUSIVE DES PRODUITS OPENCAT CORRESPONDANT A DES OFFRES D'ACCES DANS LE REFERENTIEL REFCOM
                    AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.TYPE_SERVICE        IN     (${L_PIL_018})
                  -- SELECTION EXCLUSIVE DES PRODUITS ASSOCIES A UN SEGMENT IDENTIFIE DANS LE REFERENTIEL REFCOM
                  --  AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.SEG_COM_ID         <>      '${P_PIL_295}'
                  -- SELECTION EXCLUSIVE DE L'ETAT COURANT ET ACTIF DANS LE REFERENTIEL DES LIENS (PRODUIT, SEGMENT, PERIODE)
                    AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.CURRENT_IN          =         1
                    AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.CLOSURE_DT          IS NULL
/*
                  -- SEULE LA VERSION LA PLUS RECENTE DU CATALOGUE EST CONSIDEREE
                    AND      V_CAT_R_LIEN_PRD_SGMCM_PILCOM.PERIODE_ID          =        (
                                                                                          SELECT   MAX(V_CAT_R_PERIODE_COM_PILCOM.PERIODE_ID)
                                                                                          FROM   ${KNB_PCO_SOC}.V_CAT_R_PERIODE_COM_PILCOM                     V_CAT_R_PERIODE_COM_PILCOM
                                                                                          WHERE    1                                                =          1 
                                                                                          AND      V_CAT_R_PERIODE_COM_PILCOM.CURRENT_IN            =          1
                                                                                          AND      V_CAT_R_PERIODE_COM_PILCOM.CLOSURE_DT            IS NULL
                                                                                        )
*/
                  )
-- début Xavier                  
GROUP BY 
  1, 2, 3, 4, 5
-- fin Xavier
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

.quit 0


