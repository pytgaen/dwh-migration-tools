-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_MD2_Placement_Hot_Enrichissement_Step1_ClientDossier.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/08/2014      DME         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS all;
.if errorcode <> 0 then .quit 1

--------------------------------------------------------------------------------------
-- On Va dans la table des Id chorus (Produit Principal installé) afin de 
-- récupérer les information sur le dossier Client
--------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  OPERATOR_PROVIDER_ID    ,
  PRODUIT_PRINCIPAL_CHOH   ,
  DOSSIER_NU              ,
  CLIENT_NU               
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT         ,
  RefId.OPERATOR_PROVIDER_ID                as OPERATOR_PROVIDER_ID   ,
  RefId.PRODUIT_PRINCIPAL_CHOH              as PRODUIT_PRINCIPAL_CHOH  ,
  IdChorus.IDCHODOS_FC_MSISDN               as DOSSIER_NU             ,
  IdChorus.IDCHODOS_RBTBILLSYSACCTID        as CLIENT_NU              
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDIDCHODOS IdChorus
      --Jointure sur le produit installé
    On    RefId.PRODUIT_PRINCIPAL_CHOH = IdChorus.IDCHODOS_INST_PROD_ID
      -- On applique aussi une restriction sur l'operateur de com
      And RefId.OPERATOR_PROVIDER_ID  = IdChorus.IDCHODOS_SETID
Where
  (1=1)
  And (RefId.DOSSIER_NU Is Null Or RefId.CLIENT_NU Is Null)
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS;
.if errorcode <> 0 then .quit 1


--------------------------------------------------------------------------------------
-- On Va dans la table des Id chorus (Produit Principal installé) afin de 
-- récupérer les information sur le dossier Client
-- Dans ce cas la si on a pas trouvé d'info dans la table Sans Doublon, on va dans
-- la table contenant des doublons
--------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  OPERATOR_PROVIDER_ID    ,
  PRODUIT_PRINCIPAL_CHOH   ,
  DOSSIER_NU              ,
  CLIENT_NU               
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT         ,
  RefId.OPERATOR_PROVIDER_ID                      as OPERATOR_PROVIDER_ID   ,
  RefId.PRODUIT_PRINCIPAL_CHOH                    as PRODUIT_PRINCIPAL_CHOH  ,
  IdChorusDoublon.IDCHODOS_FC_MSISDN              as DOSSIER_NU             ,
  IdChorusDoublon.IDCHODOS_RBTBILLSYSACCTID       as CLIENT_NU              
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_1 RefId
  --On Jointe pour ne réenrichir que le necessaire
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS RefEnrichi
    On    RefId.ACTE_ID         = RefEnrichi.ACTE_ID
      And RefId.INT_DEPOSIT_DT  = RefEnrichi.INT_DEPOSIT_DT
      --Jointure sur le produit installé
  Inner Join ${KNB_IBU_SOC}.V_TTIDCHODOSDB  IdChorusDoublon
    On    RefId.PRODUIT_PRINCIPAL_CHOH = IdChorusDoublon.IDCHODOS_INST_PROD_ID
      -- On applique aussi une restriction sur l'operateur de com
      And RefId.OPERATOR_PROVIDER_ID  = IdChorusDoublon.IDCHODOS_SETID
Where
  (1=1)
  And RefEnrichi.ACTE_ID Is Null
  And (RefId.DOSSIER_NU Is Null Or RefId.CLIENT_NU Is Null)
Qualify Row_Number() Over(Partition By RefId.ACTE_ID Order By IdChorusDoublon.CREATION_TS Asc) = 1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS;
.if errorcode <> 0 then .quit 1




.quit 0

