-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_Enrichissement_Step2_Vendeur_Responsable.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement vendeur responsable 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
--------------------------------------------------------------------------------

.set width 2500;


Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP All;
.if errorcode <> 0 then .quit 1



Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_RESP_REF_TRAV         ,
  ORG_RESP_XI               ,
  ORG_RESP_AGENT_ID         
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  'POCSC'                           as ORG_RESP_REF_TRAV    ,
  --Code Xi du conseiller Maintenant responsable de la vente
  MatPoc.XI                         as ORG_RESP_XI          ,
  --Code Alliance du conseiller Maintenant responsable de la vente
  MatPoc.UPPER_ID_FT                as ORG_RESP_AGENT_ID    
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP_2 RefId
  Inner Join ${KNB_IBU_GLB_V}.VPOCCSLMAT MatPoc
    On    RefId.CUID              =   MatPoc.UPPER_ID_FT
    And   RefId.INT_DEPOSIT_TS    >=  MatPoc.CSLORGA_DT_DEB
    And   RefId.INT_DEPOSIT_TS    <   MatPoc.CSLORGA_DT_FIN
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by MatPoc.CSLORGA_DT_DEB asc)=1
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP;
.if errorcode <> 0 then .quit 1



--On insert les lignes dont on calcul par l'orga EDL EDEL : TDCONSEIL:
--On fait l'enrichissement second rideau pour le responsable 
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_RESP_REF_TRAV         ,
  ORG_RESP_XI               ,
  ORG_RESP_AGENT_ID         
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  --Lorsqu'on trouve Dans l'orga EDLEDEL
  'EDLEDEL'                         as ORG_RESP_REF_TRAV    ,
  --Code Xi du Vendeur :CLIENT_CO_TYPCLI
  Conseil.CONSEIL_XI                as ORG_RESP_XI          ,
  --Code Aliance du vendeur :
  Conseil.CONSEIL_LB_UTIL           as ORG_RESP_AGENT_ID    
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP_2 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDCONSEIL Conseil
    On    RefId.CONSEIL_XI      =   Conseil.CONSEIL_XI
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP RefIdVend
    On    RefId.ACTE_ID           = RefIdVend.ACTE_ID
      And RefId.INT_DEPOSIT_DT    = RefIdVend.INT_DEPOSIT_DT
Where
  (1=1)
  And RefIdVend.ACTE_ID is null
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Conseil.CONSEIL_XI desc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP;
.if errorcode <> 0 then .quit 1


.quit 0
