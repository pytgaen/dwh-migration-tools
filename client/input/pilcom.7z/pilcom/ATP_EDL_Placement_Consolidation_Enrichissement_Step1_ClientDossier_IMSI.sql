-- $HEADER:   %HEADER% 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_Enrichissement_Step1_ClientDossier_Resiliation.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrichissement Client Dossier 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/11/2013      XKN         Creation
-- 20/03/2014      AID         Industrialisation
-- 03/08/2015      YZH         QC 1100 (stabilisation perennite )
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CLIIMSI all;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Creation de la table Volatile pour stocker le temporaire :
----------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI (
  ACTE_ID               Bigint                  Not null  ,
  INT_DEPOSIT_DT        Date Format 'YYYYMMDD'  Not null  ,
  CLIENT_NU             Char(10)                          ,
  DOSSIER_NU            Char(10)                          ,
  PAR_IMSI              Varchar(15)             Not null  
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
--On va récupéré ensuite le statut du Dossier du Client Poussé par la source
----------------------------------------------------------------------------
Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  CLIENT_NU             ,
  DOSSIER_NU            ,
  PAR_IMSI              
)
Select
  Tmp.ACTE_ID                                                             as ACTE_ID                ,
  Tmp.INT_DEPOSIT_DT                                                      as INT_DEPOSIT_DT         ,
  Tmp.CLIENT_NU                                                           as CLIENT_NU              ,
  Tmp.DOSSIER_NU                                                          as DOSSIER_NU             ,
  Tmp.PAR_IMSI                                                            as PAR_IMSI               
From
  (
      Select
        RefId.ACTE_ID                                                             as ACTE_ID                ,
        RefId.INT_DEPOSIT_DT                                                      as INT_DEPOSIT_DT         ,
        RefId.CLIENT_NU                                                           as CLIENT_NU              ,
        RefId.DOSSIER_NU                                                          as DOSSIER_NU             ,
        DossierCli.DOSSIER_NU_IMSI                                                as PAR_IMSI               ,
        2                                                                         as PRIORITE             
      From
        ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1 RefId
        Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER DossierCli
          On    RefId.DOSSIER_NU        = DossierCli.DOSSIER_NU
            And RefId.CLIENT_NU         = DossierCli.DOSSIER_CLIENT_NU
      Where
        (1=1)
        And DossierCli.DOSSIER_NU_IMSI    Is Not Null
  )Tmp
Qualify Row_Number() Over (Partition by Tmp.ACTE_ID Order by Tmp.PRIORITE asc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI Column(PAR_IMSI);
.if errorcode <> 0 then .quit 1




----------------------------------------------------------------------------
-- Creation de la table Volatile pour stocker le temporaire :
----------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIACT(
  ACTE_ID               Bigint                  Not null  ,
  INT_DEPOSIT_DT        Date Format 'YYYYMMDD'  Not null  ,
  PAR_IMSI              Varchar(15)                       ,
  DATE_ACTIV_DOS        Date Format 'YYYYMMDD'            
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIRES(
  ACTE_ID               Bigint                  Not null  ,
  INT_DEPOSIT_DT        Date Format 'YYYYMMDD'  Not null  ,
  PAR_IMSI              Varchar(15)                       ,
  DATE_RESIL_DOS        Date Format 'YYYYMMDD'            ,
  CO_RESILDOS           Varchar(5)                        ,
  DOSSIER_MOTIF_RESIL   Varchar(32)                       
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1







----------------------------------------------------------------------------
---- On s'occupe ensuite des Dossiers Dont le client a été transféré :
----------------------------------------------------------------------------
Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIACT
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  PAR_IMSI              ,
  DATE_ACTIV_DOS        
)
Select
  RefImsi.ACTE_ID                                                         as ACTE_ID                ,
  RefImsi.INT_DEPOSIT_DT                                                  as INT_DEPOSIT_DT         ,
  RefImsi.PAR_IMSI                                                        as PAR_IMSI             ,
  Cast(Dossier.DOSSIER_DT_CREAT As Date Format 'YYYYMMDD')                as DATE_ACTIV_DOS    
From
  ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI RefImsi
  Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
    On    RefImsi.PAR_IMSI     = Dossier.DOSSIER_NU_IMSI
Qualify Row_Number() Over (Partition By RefImsi.ACTE_ID
                                      Order by  Dossier.DOSSIER_DT_CREAT  asc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIACT Column(ACTE_ID);
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
---- On s'occupe ensuite des Clients dont le numéro à été porté
----------------------------------------------------------------------------
Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIRES
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  PAR_IMSI              ,
  DATE_RESIL_DOS        ,
  CO_RESILDOS           ,
  DOSSIER_MOTIF_RESIL   
)
Select
  Tmp.ACTE_ID                     as ACTE_ID                    ,
  Tmp.INT_DEPOSIT_DT              as INT_DEPOSIT_DT             ,
  Tmp.PAR_IMSI                    as PAR_IMSI                   ,
  Tmp.DATE_RESIL_DOS              as DATE_RESIL_DOS             ,
  Tmp.CO_RESILDOS                 as CO_RESILDOS                ,
  Tmp.DOSSIER_MOTIF_RESIL         as DOSSIER_MOTIF_RESIL        
From
  (
    Select
      RefImsi.ACTE_ID                                                           as ACTE_ID                ,
      RefImsi.INT_DEPOSIT_DT                                                    as INT_DEPOSIT_DT         ,
      RefImsi.PAR_IMSI                                                          as PAR_IMSI               ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then Coalesce(Cast(Dossier.DOSSIER_DT_RESIL as Date Format 'YYYYMMDD'),Dossier.DOSSIER_DT_DER_CHGT)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DATE_RESIL_DOS         ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then Dossier.DOSSIER_CO_RESILDOS
            Else
              --Sinon on prend rien
              Null
      End                                                                       as CO_RESILDOS           ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend le Motif de Résil
              Then Dossier.DOSSIER_LL_MOTRESIL --Varchar(32)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DOSSIER_MOTIF_RESIL  ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90,99999) Or Dossier.CLOSURE_DT Is Not Null
              --On priorise les dossier actif
              Then  0
            Else
                    1
      End                                                                       as PRIORITY             ,
      Dossier.DOSSIER_DT_DER_CHGT                                               as DOSSIER_DT_DER_CHGT  ,
      Dossier.DOSSIER_DT_CREAT                                                  as DOSSIER_DT_CREAT     ,
      Dossier.DOSSIER_LC_STD                                                    as DOSSIER_LC_STD     
    From
      ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI RefImsi
      Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
        On    RefImsi.PAR_IMSI     = Dossier.DOSSIER_NU_IMSI
  )Tmp
Qualify Row_Number() Over (Partition By Tmp.ACTE_ID
                                      Order by  Tmp.PRIORITY              Desc  ,
                                                Tmp.DOSSIER_DT_DER_CHGT   Desc  ,
                                                Tmp.DOSSIER_DT_CREAT      Desc  ,
                                                Tmp.DOSSIER_LC_STD        Desc  ,
                                                Tmp.CO_RESILDOS           Desc  ,
                                                Tmp.DATE_RESIL_DOS        Asc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIRES Column(ACTE_ID);
.if errorcode <> 0 then .quit 1


--Fusion et Insertion dans la table Finale
Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CLIIMSI
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  PAR_IMSI              ,
  DOSSIER_DATE_ACTIV    ,
  DOSSIER_DATE_RESIL    ,
  DOSSIER_TYPE_RESIL    ,
  DOSSIER_MOTIF_RESIL   
)
Select
  RefId.ACTE_ID                                                                                             as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                                                                                      as INT_DEPOSIT_DT             ,
  RefId.PAR_IMSI                                                                                            as PAR_IMSI                   ,
  DosAct.DATE_ACTIV_DOS                                                                                     as DOSSIER_DATE_ACTIV         ,
  DosRes.DATE_RESIL_DOS                                                                                     as DATE_RESIL_DOS             ,
  DosRes.CO_RESILDOS                                                                                        as CO_RESILDOS                ,
  DosRes.DOSSIER_MOTIF_RESIL                                                                                as DOSSIER_MOTIF_RESIL        
From
  ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSI RefId
  Left Outer Join ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIACT DosAct
    On    RefId.ACTE_ID         = DosAct.ACTE_ID
      And RefId.INT_DEPOSIT_DT  = DosAct.INT_DEPOSIT_DT
  Left Outer Join ${KNB_TERADATA_USER}.INT_V_PLACEMENT_EDL_CLIIMSIRES DosRes
    On    RefId.ACTE_ID         = DosRes.ACTE_ID
      And RefId.INT_DEPOSIT_DT  = DosRes.INT_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1


Collect Stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CLIIMSI;
.if errorcode <> 0 then .quit 1


.quit 0

