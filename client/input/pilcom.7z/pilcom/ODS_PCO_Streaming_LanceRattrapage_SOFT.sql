-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ODS_PCO_Streaming_LanceRattrapage_SOFT.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 30/10/2014      GAM         Changement de table pour les reprises
-- 04/11/2014      VMO
-- 18/11/2019      TCL         Changement COM_PCO_TMP pour les tables de reprise
--------------------------------------------------------------------------------

.set width 2500;

Create Multiset Volatile Table ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P(
  EXTERNAL_ORDER_ID VARCHAR(19)  NOT NULL,
  ORDER_STATUS_CD VARCHAR(20) NOT NULL,
  STATUS_MODIF_TS TIMESTAMP(0) NOT NULL
)
PRIMARY INDEX ( EXTERNAL_ORDER_ID ,
ORDER_STATUS_CD ,STATUS_MODIF_TS 
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1




--Alimentation de la table Volatile avec les ID :
--Principe On fait N requete pour chaque sous ensemble de commande et on agrège ensuite tout.
Insert Into ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P
(
  EXTERNAL_ORDER_ID ,
  ORDER_STATUS_CD   ,
  STATUS_MODIF_TS   
)
Select
  CalculFinal.EXTERNAL_ORDER_ID   as EXTERNAL_ORDER_ID  ,
  CalculFinal.ORDER_STATUS_CD     as ORDER_STATUS_CD    ,
  CalculFinal.STATUS_MODIF_TS     as STATUS_MODIF_TS    
From
  (
    --On agrège l'ensemble sur la clé afin de supprimer les null des sous ensemble de requete
    Select
      FusionComm.EXTERNAL_ORDER_ID        as EXTERNAL_ORDER_ID  ,
      FusionComm.ORDER_STATUS_CD          as ORDER_STATUS_CD    ,
      FusionComm.STATUS_MODIF_TS          as STATUS_MODIF_TS    ,
      Coalesce(Max(NB_LINE_ORDER_INT),0)  as NB_LINE_ORDER_INT  ,
      Coalesce(Max(COUNTLINEORDERINT),0)  as COUNTLINEORDERINT  ,
      Coalesce(Max(NB_LINE_ORDER_MOB),0)  as NB_LINE_ORDER_MOB  ,
      Coalesce(Max(COUNTLINEORDERMOB),0)  as COUNTLINEORDERMOB  ,
      Coalesce(Max(NB_LINE_ORDER_PCM),0)  as NB_LINE_ORDER_PCM  ,
      Coalesce(Max(COUNTLINEORDERPCM),0)  as COUNTLINEORDERPCM  
    From
      (
          --On requete Pour calculer si le nombre de ligne de commande Internet
          Select
            RefCommande.EXTERNAL_ORDER_ID           as EXTERNAL_ORDER_ID  ,
            RefCommande.ORDER_STATUS_CD             as ORDER_STATUS_CD    ,
            RefCommande.STATUS_MODIF_TS             as STATUS_MODIF_TS    ,
            RefCommande.NB_LINE_ORDER_INT           as NB_LINE_ORDER_INT  ,
            Count(LigneInternet.EXTERNAL_ORDER_ID)  as COUNTLINEORDERINT  ,
            null                                    as NB_LINE_ORDER_MOB  ,
            null                                    as COUNTLINEORDERMOB  ,
            null                                    as NB_LINE_ORDER_PCM  ,
            null                                    as COUNTLINEORDERPCM  
          From
            ${DatabaseTMP}.REP_O_FACADE_ORDER RefCommande
            Inner Join ${DatabaseTMP}.REP_O_FACADE_ORDER_LINE_INT LigneInternet
              On    RefCommande.EXTERNAL_ORDER_ID = LigneInternet.EXTERNAL_ORDER_ID
                And RefCommande.ORDER_STATUS_CD   = LigneInternet.ORDER_STATUS_CD
                And RefCommande.STATUS_MODIF_TS   = LigneInternet.STATUS_MODIF_TS
          Where
            (1=1)
            --On ne selectionne que les lignes qui n'ont pas été complète
            --And RefCommande.ORDER_COMPLETED  = 0
            --Et qui on été reçues il y a moins de X minutes
          Group by
            RefCommande.EXTERNAL_ORDER_ID           ,
            RefCommande.ORDER_STATUS_CD             ,
            RefCommande.STATUS_MODIF_TS             ,
            RefCommande.NB_LINE_ORDER_INT           
        Union All
          --On requete Pour calculer si le nombre de ligne de commande Mobile
          Select
            RefCommande.EXTERNAL_ORDER_ID           as EXTERNAL_ORDER_ID  ,
            RefCommande.ORDER_STATUS_CD             as ORDER_STATUS_CD    ,
            RefCommande.STATUS_MODIF_TS             as STATUS_MODIF_TS    ,
            Null                                    as NB_LINE_ORDER_INT  ,
            Null                                    as COUNTLINEORDERINT  ,
            RefCommande.NB_LINE_ORDER_MOB           as NB_LINE_ORDER_MOB  ,
            Count(LigneMobile.EXTERNAL_ORDER_ID)    as COUNTLINEORDERMOB  ,
            null                                    as NB_LINE_ORDER_PCM  ,
            null                                    as COUNTLINEORDERPCM  
          From
            ${DatabaseTMP}.REP_O_FACADE_ORDER RefCommande
            Inner Join ${DatabaseTMP}.REP_O_FACADE_ORDER_LINE_MOB LigneMobile
              On    RefCommande.EXTERNAL_ORDER_ID = LigneMobile.EXTERNAL_ORDER_ID
                And RefCommande.ORDER_STATUS_CD   = LigneMobile.ORDER_STATUS_CD
                And RefCommande.STATUS_MODIF_TS   = LigneMobile.STATUS_MODIF_TS
          Where
            (1=1)
            --On ne selectionne que les lignes qui n'ont pas été complète
            --And RefCommande.ORDER_COMPLETED  = 0
            --Et qui on été reçues il y a moins de X minutes
          Group by
            RefCommande.EXTERNAL_ORDER_ID           ,
            RefCommande.ORDER_STATUS_CD             ,
            RefCommande.STATUS_MODIF_TS             ,
            RefCommande.NB_LINE_ORDER_MOB           
        Union All
          --On requete Pour calculer si le nombre de ligne de commande Mobile
          Select
            RefCommande.EXTERNAL_ORDER_ID           as EXTERNAL_ORDER_ID  ,
            RefCommande.ORDER_STATUS_CD             as ORDER_STATUS_CD    ,
            RefCommande.STATUS_MODIF_TS             as STATUS_MODIF_TS    ,
            Null                                    as NB_LINE_ORDER_INT  ,
            Null                                    as COUNTLINEORDERINT  ,
            Null                                    as NB_LINE_ORDER_MOB  ,
            Null                                    as COUNTLINEORDERMOB  ,
            RefCommande.NB_LINE_ORDER_PCM           as NB_LINE_ORDER_PCM  ,
            Count(LignePCM.EXTERNAL_ORDER_ID)       as COUNTLINEORDERPCM  
          From
            ${DatabaseTMP}.REP_O_FACADE_ORDER RefCommande
            Inner Join ${DatabaseTMP}.REP_O_FACADE_ORDER_LINE_PCM LignePCM
              On    RefCommande.EXTERNAL_ORDER_ID = LignePCM.EXTERNAL_ORDER_ID
                And RefCommande.ORDER_STATUS_CD   = LignePCM.ORDER_STATUS_CD
                And RefCommande.STATUS_MODIF_TS   = LignePCM.STATUS_MODIF_TS
          Where
            (1=1)
            --On ne selectionne que les lignes qui n'ont pas été complète
            --And RefCommande.ORDER_COMPLETED  = 0
            --Et qui on été reçues il y a moins de X minutes
          Group by
            RefCommande.EXTERNAL_ORDER_ID           ,
            RefCommande.ORDER_STATUS_CD             ,
            RefCommande.STATUS_MODIF_TS             ,
            RefCommande.NB_LINE_ORDER_PCM           
      )FusionComm
    Group By
      FusionComm.EXTERNAL_ORDER_ID        ,
      FusionComm.ORDER_STATUS_CD          ,
      FusionComm.STATUS_MODIF_TS          
  )CalculFinal
Where
  (1=1)
  And Not Exists
    (
      Select
        1
      From
        ${DatabaseODS}.ATP_O_FACADE_ORDER RefPilcom
      Where
        (1=1)
        And CalculFinal.EXTERNAL_ORDER_ID     = RefPilcom.EXTERNAL_ORDER_ID
        And CalculFinal.ORDER_STATUS_CD       = RefPilcom.ORDER_STATUS_CD
        And CalculFinal.STATUS_MODIF_TS       = RefPilcom.STATUS_MODIF_TS
    )
  And CalculFinal.NB_LINE_ORDER_INT=CalculFinal.COUNTLINEORDERINT
  And CalculFinal.NB_LINE_ORDER_MOB=CalculFinal.COUNTLINEORDERMOB
  And CalculFinal.NB_LINE_ORDER_PCM=CalculFinal.COUNTLINEORDERPCM
;
.if errorcode <> 0 then .quit 1

--On collecte les stats sur la table Volatile
Collect Stat ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P Column(EXTERNAL_ORDER_ID,ORDER_STATUS_CD,STATUS_MODIF_TS);
.if errorcode <> 0 then .quit 1

--On procèdes aux alimentations des tables Temporaires pour ces commandes :


--Insertion dans la table des commandes :
Insert Into ${DatabaseODS}.ATP_O_FACADE_ORDER
(
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  BCR_ID                        ,
  ETASK_ORDER_ID                ,
  PARSIFAL_ORDER_ID             ,
  VAD_ORDER_ID                  ,
  ORDER_DEPOSIT_TS              ,
  ORDER_VALIDATION_TS           ,
  ORDER_DELIVERY_TS             ,
  AGENT_ID                      ,
  DISTRBTN_CHANNL_ID            ,
  STORE_NAME                    ,
  MOTV_ORDR_ID                  ,
  FLAG_ORDER_CREATE_SIMUL       ,
  ORDER_TYPE_CD                 ,
  ORDER_TYPE_ID                 ,
  CANCEL_MOTV_DS                ,
  ACTE_OPERTR_ID_COMPST_OFFR    ,
  COMPST_OFFR_ID                ,
  COMPST_OFFR_DS                ,
  PREVIOUS_COMPST_OFFR_ID       ,
  PREVIOUS_COMPST_OFFR_DS       ,
  ACTE_OPERTR_ID_OT             ,
  OFFRE_TYPE_ID                 ,
  OFFRE_TYPE_DS                 ,
  PREVIOUS_OFFRE_TYPE_ID        ,
  PREVIOUS_OFFRE_TYPE_DS        ,
  CUSTOMER_CIVILITY             ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_MARKET_SEG           ,
  CUSTOMER_SIRET                ,
  CUSTOMER_BSS_ID               ,
  CUSTOMER_FGT_ID               ,
  CUSTOMER_ND                   ,
  CUSTOMER_CPT_FAC_FGT          ,
  CUSTOMER_CLIENT_NU_ADV        ,
  CUSTOMER_DOSSIER_NU_ADV       ,
  CUSTOMER_BO_ID                ,
  CUSTOMER_ND_AR                ,
  INSTALL_ADDRESS_STREET        ,
  INSTALL_ADDRESS_ZIPCODE       ,
  INSTALL_ADDRESS_CITY          ,
  INSTALL_ADDRESS_COUNTRY       ,
  INSTALL_REGIONAL_DIRCTN_ID    ,
  CONTACT_CIVILITY              ,
  CONTACT_LAST_NAME             ,
  CONTACT_FIRST_NAME            ,
  CONTACT_MOBILE_NUMBER         ,
  CONTACT_MAIL_ADDRESS          ,
  CONTACT_ADDRESS_STREET        ,
  CONTACT_ADDRESS_ZIPCODE       ,
  CONTACT_ADDRESS_CITY          ,
  CONTACT_ADDRESS_COUNTRY       ,
  SHIPMENT_ADDRESS_RELAY_ID     ,
  SHIPMENT_ADDRESS_STREET       ,
  SHIPMENT_ADDRESS_ZIPCODE      ,
  SHIPMENT_ADDRESS_CITY         ,
  SHIPMENT_ADDRESS_COUNTRY      ,
  NB_LINE_ORDER_INT             ,
  NB_LINE_ORDER_MOB             ,
  NB_LINE_ORDER_PCM             ,
  BO_AGENT_ID                   ,
  PARSIFAL_ERROR_CD             ,
  PARSIFAL_ERROR_DS             ,
  COMMENT_ETASK                 ,
  COMMENT_SOFT_ORIGINE          ,
  COMMENT_SOFT_TYPE             ,
  COMMENT_SOFT_FULL_DS          ,
  COMMENT_SOFT_SUMMARY          ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ORDER_COMPLETED               
)
Select
  RefCommande.EXTERNAL_ORDER_ID             as EXTERNAL_ORDER_ID              ,
  RefCommande.ORDER_STATUS_CD               as ORDER_STATUS_CD                ,
  RefCommande.STATUS_MODIF_TS               as STATUS_MODIF_TS                ,
  RefCommande.BCR_ID                        as BCR_ID                         ,
  RefCommande.ETASK_ORDER_ID                as ETASK_ORDER_ID                 ,
  RefCommande.PARSIFAL_ORDER_ID             as PARSIFAL_ORDER_ID              ,
  RefCommande.VAD_ORDER_ID                  as VAD_ORDER_ID                   ,
  RefCommande.ORDER_DEPOSIT_TS              as ORDER_DEPOSIT_TS               ,
  RefCommande.ORDER_VALIDATION_TS           as ORDER_VALIDATION_TS            ,
  RefCommande.ORDER_DELIVERY_TS             as ORDER_DELIVERY_TS              ,
  RefCommande.AGENT_ID                      as AGENT_ID                       ,
  RefCommande.DISTRBTN_CHANNL_ID            as DISTRBTN_CHANNL_ID             ,
  RefCommande.STORE_NAME                    as STORE_NAME                     ,
  RefCommande.MOTV_ORDR_ID                  as MOTV_ORDR_ID                   ,
  RefCommande.FLAG_ORDER_CREATE_SIMUL       as FLAG_ORDER_CREATE_SIMUL        ,
  RefCommande.ORDER_TYPE_CD                 as ORDER_TYPE_CD                  ,
  RefCommande.ORDER_TYPE_ID                 as ORDER_TYPE_ID                  ,
  RefCommande.CANCEL_MOTV_DS                as CANCEL_MOTV_DS                 ,
  RefCommande.ACTE_OPERTR_ID_COMPST_OFFR    as ACTE_OPERTR_ID_COMPST_OFFR     ,
  RefCommande.COMPST_OFFR_ID                as COMPST_OFFR_ID                 ,
  RefCommande.COMPST_OFFR_DS                as COMPST_OFFR_DS                 ,
  RefCommande.PREVIOUS_COMPST_OFFR_ID       as PREVIOUS_COMPST_OFFR_ID        ,
  RefCommande.PREVIOUS_COMPST_OFFR_DS       as PREVIOUS_COMPST_OFFR_DS        ,
  RefCommande.ACTE_OPERTR_ID_OT             as ACTE_OPERTR_ID_OT              ,
  RefCommande.OFFRE_TYPE_ID                 as OFFRE_TYPE_ID                  ,
  RefCommande.OFFRE_TYPE_DS                 as OFFRE_TYPE_DS                  ,
  RefCommande.PREVIOUS_OFFRE_TYPE_ID        as PREVIOUS_OFFRE_TYPE_ID         ,
  RefCommande.PREVIOUS_OFFRE_TYPE_DS        as PREVIOUS_OFFRE_TYPE_DS         ,
  RefCommande.CUSTOMER_CIVILITY             as CUSTOMER_CIVILITY              ,
  RefCommande.CUSTOMER_LAST_NAME            as CUSTOMER_LAST_NAME             ,
  RefCommande.CUSTOMER_FIRST_NAME           as CUSTOMER_FIRST_NAME            ,
  RefCommande.CUSTOMER_MARKET_SEG           as CUSTOMER_MARKET_SEG            ,
  RefCommande.CUSTOMER_SIRET                as CUSTOMER_SIRET                 ,
  RefCommande.CUSTOMER_BSS_ID               as CUSTOMER_BSS_ID                ,
  RefCommande.CUSTOMER_FGT_ID               as CUSTOMER_FGT_ID                ,
  RefCommande.CUSTOMER_ND                   as CUSTOMER_ND                    ,
  RefCommande.CUSTOMER_CPT_FAC_FGT          as CUSTOMER_CPT_FAC_FGT           ,
  RefCommande.CUSTOMER_CLIENT_NU_ADV        as CUSTOMER_CLIENT_NU_ADV         ,
  RefCommande.CUSTOMER_DOSSIER_NU_ADV       as CUSTOMER_DOSSIER_NU_ADV        ,
  RefCommande.CUSTOMER_BO_ID                as CUSTOMER_BO_ID                 ,
  RefCommande.CUSTOMER_ND_AR                as CUSTOMER_ND_AR                 ,
  RefCommande.INSTALL_ADDRESS_STREET        as INSTALL_ADDRESS_STREET         ,
  RefCommande.INSTALL_ADDRESS_ZIPCODE       as INSTALL_ADDRESS_ZIPCODE        ,
  RefCommande.INSTALL_ADDRESS_CITY          as INSTALL_ADDRESS_CITY           ,
  RefCommande.INSTALL_ADDRESS_COUNTRY       as INSTALL_ADDRESS_COUNTRY        ,
  RefCommande.INSTALL_REGIONAL_DIRCTN_ID    as INSTALL_REGIONAL_DIRCTN_ID     ,
  RefCommande.CONTACT_CIVILITY              as CONTACT_CIVILITY               ,
  RefCommande.CONTACT_LAST_NAME             as CONTACT_LAST_NAME              ,
  RefCommande.CONTACT_FIRST_NAME            as CONTACT_FIRST_NAME             ,
  RefCommande.CONTACT_MOBILE_NUMBER         as CONTACT_MOBILE_NUMBER          ,
  RefCommande.CONTACT_MAIL_ADDRESS          as CONTACT_MAIL_ADDRESS           ,
  RefCommande.CONTACT_ADDRESS_STREET        as CONTACT_ADDRESS_STREET         ,
  RefCommande.CONTACT_ADDRESS_ZIPCODE       as CONTACT_ADDRESS_ZIPCODE        ,
  RefCommande.CONTACT_ADDRESS_CITY          as CONTACT_ADDRESS_CITY           ,
  RefCommande.CONTACT_ADDRESS_COUNTRY       as CONTACT_ADDRESS_COUNTRY        ,
  RefCommande.SHIPMENT_ADDRESS_RELAY_ID     as SHIPMENT_ADDRESS_RELAY_ID      ,
  RefCommande.SHIPMENT_ADDRESS_STREET       as SHIPMENT_ADDRESS_STREET        ,
  RefCommande.SHIPMENT_ADDRESS_ZIPCODE      as SHIPMENT_ADDRESS_ZIPCODE       ,
  RefCommande.SHIPMENT_ADDRESS_CITY         as SHIPMENT_ADDRESS_CITY          ,
  RefCommande.SHIPMENT_ADDRESS_COUNTRY      as SHIPMENT_ADDRESS_COUNTRY       ,
  RefCommande.NB_LINE_ORDER_INT             as NB_LINE_ORDER_INT              ,
  RefCommande.NB_LINE_ORDER_MOB             as NB_LINE_ORDER_MOB              ,
  RefCommande.NB_LINE_ORDER_PCM             as NB_LINE_ORDER_PCM              ,
  RefCommande.BO_AGENT_ID                   as BO_AGENT_ID                    ,
  RefCommande.PARSIFAL_ERROR_CD             as PARSIFAL_ERROR_CD              ,
  RefCommande.PARSIFAL_ERROR_DS             as PARSIFAL_ERROR_DS              ,
  RefCommande.COMMENT_ETASK                 as COMMENT_ETASK                  ,
  RefCommande.COMMENT_SOFT_ORIGINE          as COMMENT_SOFT_ORIGINE           ,
  RefCommande.COMMENT_SOFT_TYPE             as COMMENT_SOFT_TYPE              ,
  RefCommande.COMMENT_SOFT_FULL_DS          as COMMENT_SOFT_FULL_DS           ,
  RefCommande.COMMENT_SOFT_SUMMARY          as COMMENT_SOFT_SUMMARY           ,
  RefCommande.QUEUE_TS                      as QUEUE_TS                       ,
  RefCommande.STREAMING_TS                  as STREAMING_TS                   ,
  0                                         as ORDER_COMPLETED                
From
  ${DatabaseTMP}.REP_O_FACADE_ORDER RefCommande
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P RefId
    On    RefCommande.EXTERNAL_ORDER_ID = RefId.EXTERNAL_ORDER_ID
      And RefCommande.ORDER_STATUS_CD   = RefId.ORDER_STATUS_CD
      And RefCommande.STATUS_MODIF_TS   = RefId.STATUS_MODIF_TS

--Insertion dans la table des lignes de commandes Internet :
;Insert Into ${DatabaseODS}.ATP_O_FACADE_ORDER_LINE_INT
(
  EXTERNAL_ORDER_ID              ,
  ORDER_STATUS_CD                ,
  STATUS_MODIF_TS                ,
  ORDER_DEPOSIT_TS               ,
  ORDER_LINE_EXTERNAL_ID         ,
  EXT_OPER_ID                    ,
  ATOMIC_OFFR_ID                 ,
  ATOMIC_OFFR_DS                 ,
  FUNCTN_ID                      ,
  FUNCTN_DS                      ,
  FUNCTN_VALUE_ID                ,
  FUNCTN_VALUE_DS                ,
  PREVIOUS_FUNCTN_VALUE_ID       ,
  PREVIOUS_FUNCTN_VALUE_DS       ,
  QUEUE_TS                       ,
  STREAMING_TS                   
)
Select
  LigneInternet.EXTERNAL_ORDER_ID             as EXTERNAL_ORDER_ID              ,
  LigneInternet.ORDER_STATUS_CD               as ORDER_STATUS_CD                ,
  LigneInternet.STATUS_MODIF_TS               as STATUS_MODIF_TS                ,
  LigneInternet.ORDER_DEPOSIT_TS              as ORDER_DEPOSIT_TS               ,
  LigneInternet.ORDER_LINE_EXTERNAL_ID        as ORDER_LINE_EXTERNAL_ID         ,
  LigneInternet.EXT_OPER_ID                   as EXT_OPER_ID                    ,
  LigneInternet.ATOMIC_OFFR_ID                as ATOMIC_OFFR_ID                 ,
  LigneInternet.ATOMIC_OFFR_DS                as ATOMIC_OFFR_DS                 ,
  LigneInternet.FUNCTN_ID                     as FUNCTN_ID                      ,
  LigneInternet.FUNCTN_DS                     as FUNCTN_DS                      ,
  LigneInternet.FUNCTN_VALUE_ID               as FUNCTN_VALUE_ID                ,
  LigneInternet.FUNCTN_VALUE_DS               as FUNCTN_VALUE_DS                ,
  LigneInternet.PREVIOUS_FUNCTN_VALUE_ID      as PREVIOUS_FUNCTN_VALUE_ID       ,
  LigneInternet.PREVIOUS_FUNCTN_VALUE_DS      as PREVIOUS_FUNCTN_VALUE_DS       ,
  LigneInternet.QUEUE_TS                      as QUEUE_TS                       ,
  LigneInternet.STREAMING_TS                  as STREAMING_TS                   
From
  ${DatabaseTMP}.REP_O_FACADE_ORDER_LINE_INT LigneInternet
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P RefId
    On    LigneInternet.EXTERNAL_ORDER_ID = RefId.EXTERNAL_ORDER_ID
      And LigneInternet.ORDER_STATUS_CD   = RefId.ORDER_STATUS_CD
      And LigneInternet.STATUS_MODIF_TS   = RefId.STATUS_MODIF_TS

--Insertion dans la table des lignes de commandes Mobile :
;Insert Into ${DatabaseODS}.ATP_O_FACADE_ORDER_LINE_MOB
(
  EXTERNAL_ORDER_ID              ,
  ORDER_STATUS_CD                ,
  STATUS_MODIF_TS                ,
  ORDER_DEPOSIT_TS               ,
  EXT_OPER_ID                    ,
  SERVICE_OPTIONNEL_ID           ,
  SERVICE_OPTIONNEL_DS           ,
  QUEUE_TS                       ,
  STREAMING_TS                   
)
Select
  LigneMobile.EXTERNAL_ORDER_ID             as EXTERNAL_ORDER_ID              ,
  LigneMobile.ORDER_STATUS_CD               as ORDER_STATUS_CD                ,
  LigneMobile.STATUS_MODIF_TS               as STATUS_MODIF_TS                ,
  LigneMobile.ORDER_DEPOSIT_TS              as ORDER_DEPOSIT_TS               ,
  LigneMobile.EXT_OPER_ID                   as EXT_OPER_ID                    ,
  LigneMobile.SERVICE_OPTIONNEL_ID          as SERVICE_OPTIONNEL_ID           ,
  LigneMobile.SERVICE_OPTIONNEL_DS          as SERVICE_OPTIONNEL_DS           ,
  LigneMobile.QUEUE_TS                      as QUEUE_TS                       ,
  LigneMobile.STREAMING_TS                  as STREAMING_TS                   
From
  ${DatabaseTMP}.REP_O_FACADE_ORDER_LINE_MOB LigneMobile
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P RefId
    On    LigneMobile.EXTERNAL_ORDER_ID = RefId.EXTERNAL_ORDER_ID
      And LigneMobile.ORDER_STATUS_CD   = RefId.ORDER_STATUS_CD
      And LigneMobile.STATUS_MODIF_TS   = RefId.STATUS_MODIF_TS


--Insertion dans la table des lignes de commandes PCM :
;Insert Into ${DatabaseODS}.ATP_O_FACADE_ORDER_LINE_PCM
(
  EXTERNAL_ORDER_ID               ,
  ORDER_STATUS_CD                 ,
  STATUS_MODIF_TS                 ,
  ORDER_DEPOSIT_TS                ,
  TERMINAL_CODE_EAN               ,
  TERMINAL_DS                     ,
  TERMINAL_PRICE                  ,
  NB_POINT_USED                   ,
  DUREE_REENGAGEMENT              ,
  OSCAR_SEGEMENT                  ,
  CODE_DIGIT_TERMINAL_ID         ,
  TYPE_TARIF_ID                  ,
  IMEI_ID                        ,
  PRIX_TTC_PAYE                  ,
  MONTANT_TTC_SUBVTN             ,
  MODE_REMISE                    ,
  NSCESIM                        ,
  CODE_EAN_SIM_ID                ,
  CODE_OFFR_VAD_ID               ,
  LIBELLE_OFFRE_VAD_DS           , 
  QUEUE_TS                        ,
  STREAMING_TS                    
)
Select
  LignePCM.EXTERNAL_ORDER_ID              as EXTERNAL_ORDER_ID              ,
  LignePCM.ORDER_STATUS_CD                as ORDER_STATUS_CD                ,
  LignePCM.STATUS_MODIF_TS                as STATUS_MODIF_TS                ,
  LignePCM.ORDER_DEPOSIT_TS               as ORDER_DEPOSIT_TS               ,
  LignePCM.TERMINAL_CODE_EAN              as TERMINAL_CODE_EAN              ,
  LignePCM.TERMINAL_DS                    as TERMINAL_DS                    ,
  LignePCM.TERMINAL_PRICE                 as TERMINAL_PRICE                 ,
  LignePCM.NB_POINT_USED                  as NB_POINT_USED                  ,
  LignePCM.DUREE_REENGAGEMENT             as DUREE_REENGAGEMENT             ,
  LignePCM.OSCAR_SEGEMENT                 as OSCAR_SEGEMENT                 ,
  LignePCM.CODE_DIGIT_TERMINAL_ID         as CODE_DIGIT_TERMINAL_ID         ,
  LignePCM.TYPE_TARIF_ID                  as TYPE_TARIF_ID                  ,
  LignePCM.IMEI_ID                        as IMEI_ID                        ,
  LignePCM.PRIX_TTC_PAYE                  as PRIX_TTC_PAYE                  ,
  LignePCM.MONTANT_TTC_SUBVTN             as MONTANT_TTC_SUBVTN             ,
  LignePCM.MODE_REMISE                    as MODE_REMISE                    ,
  LignePCM.NSCESIM                        as NSCESIM                        ,
  LignePCM.CODE_EAN_SIM_ID                as CODE_EAN_SIM_ID                ,
  LignePCM.CODE_OFFR_VAD_ID               as CODE_OFFR_VAD_ID               ,
  LignePCM.LIBELLE_OFFRE_VAD_DS           as LIBELLE_OFFRE_VAD_DS           ,
  LignePCM.QUEUE_TS                       as QUEUE_TS                       ,
  LignePCM.STREAMING_TS                   as STREAMING_TS                   
From
  ${DatabaseTMP}.REP_O_FACADE_ORDER_LINE_PCM LignePCM
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_SOFT_TO_LOAD_P RefId
    On    LignePCM.EXTERNAL_ORDER_ID = RefId.EXTERNAL_ORDER_ID
      And LignePCM.ORDER_STATUS_CD   = RefId.ORDER_STATUS_CD
      And LignePCM.STATUS_MODIF_TS   = RefId.STATUS_MODIF_TS
;
.if errorcode <> 0 then .quit 1


