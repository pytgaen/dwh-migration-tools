-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERC_Placement_Cold_Alimentation_Step3_CalculIDExterne.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de l'id externe
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/07/2014      MCA         Creation
-- 19/08/2014      MCA         Indus
--------------------------------------------------------------------------------

.set width 2500;



----------------------------------------------------------------*/
-- Etape 1 : Delete de la table TMP                             */
----------------------------------------------------------------*/
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------*/
-- Etape 2 : Alimentation de la table TMP                       */
----------------------------------------------------------------*/



INSERT INTO ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT
(
  EXTERNAL_ACTE_ID            ,
  INTRNL_SOURCE_ID            ,
  TYPE_SOURCE_ID              ,
  APPLI_SOURCE_ID             ,
  REPRISE_ID                  ,
  AGENT_ID                    ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  EDO_ID                      ,
  IMEI                        ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  ORDER_DEPOSIT_DT            ,
  REPRISE_TS                  ,
  REPRISE_VAL                 ,
  PROMOTION_VAL               ,
  RECEPTION_TS                ,
  TRTMT_TS                    ,
  HOMOLOGATION_TS             ,
  HOMOLOGATION_CD             ,
  POST_TRTMT_VAL              ,
  AJUSTMNT_RAISON             ,
  AJUSTMNT_VAL                ,
  ECART_RAISON                ,
  FIRST_NAME_NM               ,
  LAST_NAME_NM                ,
  MSISDN                      ,
  REPRISE_NUM                 ,
  BON_ID                      ,
  MODE_PAIEMENT               ,
  PAIEMENT_STATUT             ,
  CONSUMPTN_TS                ,
  MAX_VALIDITY_TS             ,
  CANCELLATION_TS             ,
  EQPT_CD                     ,
  BRAND_SHOP_CD               ,
  SEGMENT                     ,
  RAISON_SOCIALE              ,
  SIRET                       ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
SELECT
  --La clé est définie à partir de Identifiant de la reprise et le PDV
  Placement.REPRISE_ID                  as EXTERNAL_ACTE_ID                  ,
  --Appli source Interne --> voir table PLC_LAB_SOC.ORD_R_SOURCE: 13
  ${IdSourceInterne}                    as INTRNL_SOURCE_ID                  ,
  -- Param pour la table ID :  --> 213
  ${IdentifiantTechniqueSource}         as TYPE_SOURCE_ID                    ,
  'ERC'                                 as APPLI_SOURCE_ID                   ,
  Placement.REPRISE_ID                  as REPRISE_ID                        ,
  Placement.AGENT_ID                    as AGENT_ID                          ,
  Placement.STORE_CD                    as STORE_CD                          ,
  Placement.ADV_STORE_CD                as ADV_STORE_CD                      ,
  Placement.EDO_ID                      as EDO_ID                            ,
  Placement.IMEI                        as IMEI                              ,
  Placement.TERMINAL_BRAND              as TERMINAL_BRAND                    ,
  Placement.TERMINAL_MODEL              as TERMINAL_MODEL                    ,
  CAST(CAST(Placement.REPRISE_TS AS TIMESTAMP(0) FORMAT 'DD/MM/YYYY HH:MI:SS') AS DATE FORMAT 'YYYY-MM-DD')  as ORDER_DEPOSIT_DT,
  Placement.REPRISE_TS                  as REPRISE_TS                        ,
  Placement.REPRISE_VAL                 as REPRISE_VAL                       ,
  Placement.PROMOTION_VAL               as PROMOTION_VAL                     ,
  Placement.RECEPTION_TS                as RECEPTION_TS                      ,
  Placement.TRTMT_TS                    as TRTMT_TS                          ,
  Placement.HOMOLOGATION_TS             as HOMOLOGATION_TS                   ,
  Placement.HOMOLOGATION_CD             as HOMOLOGATION_CD                   ,
  Placement.POST_TRTMT_VAL              as POST_TRTMT_VAL                    ,
  Placement.AJUSTMNT_RAISON             as AJUSTMNT_RAISON                   ,
  Placement.AJUSTMNT_VAL                as AJUSTMNT_VAL                      ,
  Placement.ECART_RAISON                as ECART_RAISON                      ,
  Placement.FIRST_NAME_NM               as FIRST_NAME_NM                     ,
  Placement.LAST_NAME_NM                as LAST_NAME_NM                      ,
  Placement.MSISDN                      as MSISDN_DS                         ,
  Placement.REPRISE_NUM                 as REPRISE_NUM                       ,
  Placement.BON_ID                      as BON_ID                            ,
  Placement.MODE_PAIEMENT               as MODE_PAIEMENT                     ,
  Placement.PAIEMENT_STATUT             as PAIEMENT_STATUT                   ,
  Placement.CONSUMPTN_TS                as CONSUMPTN_TS                      ,
  Placement.MAX_VALIDITY_TS             as MAX_VALIDITY_TS                   ,
  Placement.CANCELLATION_TS             as CANCELLATION_TS                   ,
  Placement.EQPT_CD                     as EQPT_CD                           ,
  Placement.BRAND_SHOP_CD               as BRAND_SHOP_CD                     ,
  Placement.SEGMENT                     as SEGMENT                           ,
  Placement.RAISON_SOCIALE              as RAISON_SOCIALE                    ,
  Placement.SIRET                       as SIRET                             ,
  0                                     as HOT_IN                            ,
  Current_Timestamp(0)                  as CREATION_TS                       ,
  Current_Timestamp(0)                  as LAST_MODIF_TS                     ,
  1                                     as FRESH_IN                          ,
  0                                     as COHERENCE_IN
FROM
  -- On prend la table tmp extraite de l'ODS
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1 Placement
WHERE
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT
;
.if errorcode <> 0 then .quit 1
.quit 0
