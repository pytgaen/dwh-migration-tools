-- $HEADER: mm2pco/current/sql/ATP_BPM_Placement_Hot_Step5_Enrichissement_O3.sql 13_05#1 06-DEC-2016 16:43:09 XPFJ4492
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BPM_Placement_Hot_Step5_Enrichissement_O3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  d'enrichissement O3
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/11/2016      ABO         Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP  Calcul Hierarchique                                  ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_H_HIERO3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_H_HIERO3
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  TYPE_EDO_ID                 ,
  ORG_TEAM_LEVEL_1_CD         ,
  ORG_TEAM_LEVEL_1_DS         ,
  ORG_TEAM_LEVEL_2_CD         ,
  ORG_TEAM_LEVEL_2_DS         ,
  ORG_TEAM_LEVEL_3_CD         ,
  ORG_TEAM_LEVEL_3_DS         ,
  ORG_TEAM_LEVEL_4_CD         ,
  ORG_TEAM_LEVEL_4_DS         ,
  WORK_TEAM_LEVEL_1_CD        ,
  WORK_TEAM_LEVEL_1_DS        ,
  WORK_TEAM_LEVEL_2_CD        ,
  WORK_TEAM_LEVEL_2_DS        ,
  WORK_TEAM_LEVEL_3_CD        ,
  WORK_TEAM_LEVEL_3_DS        ,
  WORK_TEAM_LEVEL_4_CD        ,
  WORK_TEAM_LEVEL_4_DS         

)
Select
  BPM.ACTE_ID                               AS ACTE_ID                     ,
  BPM.ORDER_DEPOSIT_DT                      AS ORDER_DEPOSIT_DT            ,
  Case    When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                    WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                Or  WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                Or  WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                Or  WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                )
            Then '${P_PIL_236}'
          Else '${P_PIL_235}'
  End                                       As TYPE_EDO_ID                 ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As ORG_TEAM_LEVEL_1_CD         ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As ORG_TEAM_LEVEL_1_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As ORG_TEAM_LEVEL_2_CD         ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As ORG_TEAM_LEVEL_2_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As ORG_TEAM_LEVEL_3_CD         ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As ORG_TEAM_LEVEL_3_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As ORG_TEAM_LEVEL_4_CD         ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As ORG_TEAM_LEVEL_4_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As WORK_TEAM_LEVEL_1_CD        ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As WORK_TEAM_LEVEL_1_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As WORK_TEAM_LEVEL_2_CD        ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As WORK_TEAM_LEVEL_2_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As WORK_TEAM_LEVEL_3_CD        ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As WORK_TEAM_LEVEL_3_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As WORK_TEAM_LEVEL_4_CD        ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As WORK_TEAM_LEVEL_4_DS         
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_H_2 BPM
  --On jointe dans l'orga Hierarchique
  Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL WLvl1
     On   BPM.EDO_ID                           =   WLvl1.ORG_TEAM_LEVEL_1_CD
      And BPM.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_1_START_DT
      And BPM.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_1_END_DT
      And BPM.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_2_START_DT
      And BPM.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_2_END_DT
      And BPM.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_3_START_DT
      And BPM.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_3_END_DT
      And BPM.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_4_START_DT
      And BPM.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_4_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition By BPM.ACTE_ID,BPM.ORDER_DEPOSIT_DT Order By           WLvl1.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_H_HIERO3;
.if errorcode <> 0 then .quit 1


.quit 0





