-- $HEADER: %HEADER%
----------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_FUGDT_Step1_Alimentation_TableTmpDay.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'alimentation pour initialiser la table tampon
--
--------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE             AUTEUR      CREATION/MODIFICATION
-- 10/05/2021       EVI         CREATION
--------------------------------------------------------------------------------------------------------

.set width 5000

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP des extraction des actes                              ----
----------------------------------------------------------------------------------------------
DELETE FROM ${KNB_PCO_TMP}.ACT_T_GDT_DAY;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Extraction Partielle des KPI spécifiques
----------------------------------------------------------------------------------------------
INSERT INTO ${KNB_PCO_TMP}.ACT_T_GDT_DAY
(
    EXT_DT
  , ID_ACTE                
  , CODE_ACTE              
  , FAMILLE_KPI            
  , TYPE_PRODUIT           
  , DATE_ACTE              
  , ID_ACTE_COMPLEMENTAIRE 
  , NUMERO_GSM             
  , IMEI                   
  , NSCE                   
  , NUMERO_CLIENT          
  , CUID                   
  , CODE_ADV               
  , CODE_EDO               
  , CODE_OFFRE1            
  , CODE_OFFRE2            
  , LIBELLE_OFFRE          
  , CODE_OFFRE_DEPART1     
  , CODE_OFFRE_DEPART2     
  , LIBELLE_OFFRE_DEPART   
  , CODE_ARTICLE           
  , LIBELLE_ARTICLE        
  , NUMERO_ACCORD          
  , MONTANT_PCM            
  , CODE_TYPE_PVC          
  , CREATION_TS
  , CURRENT_IN   
  , FRESH_IN      
  , COHERENCE_IN  
)
Select 
  '${DATE_EXTRACT}'                                         As EXT_DT                 ,
  VU.ACTE_ID                                                As ID_ACTE                ,
  VU.ACT_CD                                                 As CODE_ACTE              ,
  VU.ACT_ACTE_FAMILLE_KPI                                   As FAMILLE_KPI            ,
  Matrice.TYPE_PRODUIT                                      As TYPE_PRODUIT           ,
  VU.ACT_DT                                                 As DATE_ACTE              ,
  Case when VU.ACT_TYPE_COMMANDE_ID = 'TSUBV' then VU.CPLT_ACTE_ID     
       else NULL
  End                                                  	   As ID_ACTE_COMPLEMENTAIRE ,
  Case 
    When Coalesce(VU.MSISDN_ID,'0000000000') <> '0000000000'
      Then VU.MSISDN_ID
    Else Null 
  End                                                       As NUMERO_GSM             ,
  VU.IMEI_CD                                                As IMEI                   ,
  VU.SIM_CD                                                 As NSCE                   ,
  VU.EXTERNAL_PARTY_ID                                      As NUMERO_CLIENT          ,
  VU.AGENT_ID_UPD                                           As CUID                   ,
  VU.UNIFIED_SHOP_CD                                        As CODE_ADV               ,
  VU.ORG_EDO_ID                                             As CODE_EDO               ,
  Case
    When Matrice.TYPE_LIGNE = 'O'
      Then Final_Agap.EXT_PRODUCT_ID1 
    When Matrice.TYPE_LIGNE = 'P' And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then BCR.BCR_FORMULE_CO
    Else Null
  End                                                       As CODE_OFFRE1            ,
  Case
    When Matrice.TYPE_LIGNE = 'O'
      Then Final_Agap.EXT_PRODUCT_ID2 
    When Matrice.TYPE_LIGNE = 'P' And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then BCR.BCR_PRESFACT_CO
    Else Null
  End                                                       As CODE_OFFRE2            ,
  Case
    When Matrice.TYPE_LIGNE = 'O'
      Then Final_Agap.PRODUCT_DS 
    When Matrice.TYPE_LIGNE = 'P' And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then Bcr_Agap.PRODUCT_DS
    Else Null
  End                                                       As LIBELLE_OFFRE          ,
  Previous_Agap.EXT_PRODUCT_ID1                             As CODE_OFFRE_DEPART1     ,
  Previous_Agap.EXT_PRODUCT_ID2                             As CODE_OFFRE_DEPART2     ,
  Previous_Agap.PRODUCT_DS                                  As LIBELLE_OFFRE_DEPART   ,
  Case 
    When REGEXP_SIMILAR(TRIM(VU.EAN_CD), '^[0-9]*$') = 1 
      Then Lpad( VU.EAN_CD, 13,'0')
    Else Null
  End                                                       As CODE_ARTICLE           ,
  Case 
    When Matrice.TYPE_LIGNE In ('P','T') And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then RefEAN.PRODUIT_DS
    Else Null 
  End                                                       As LIBELLE_ARTICLE        ,
  Case 
    When Matrice.TYPE_LIGNE = 'P' And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then 'ADV' || Lpad(VU.ORDER_EXTERNAL_ID, 10, '0')
    Else Null 
  End                                                       As NUMERO_ACCORD          ,
  Case 
    When Matrice.TYPE_LIGNE = 'P' And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then BCR_Article.COMMARTICLE_MONTANTPRIME
    Else Null 
  End                                                       As MONTANT_PCM            ,
  Case 
    When Matrice.TYPE_LIGNE = 'P' And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
      Then 'PCMS' || Trim(VU.PCM_LEVEL_POINT_NU)
    Else Null 
  End                                                       As CODE_TYPE_PVC          ,
  CAST('${KNB_BATCH_DATE}' AS timestamp(0))                 As CREATION_TS            ,
  1                                                         As CURRENT_IN             ,
  1                                                         As FRESH_IN               ,
  1                                                         As COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED VU
  -- Matrice Extraction Fichier GDT
  Left outer join ${KNB_PCO_SOC}.ORG_R_MATRICE_FU_GDT Matrice
      On    Trim(Matrice.ACT_ACTE_FAMILLE_KPI) = Trim(VU.ACT_ACTE_FAMILLE_KPI)
        And (Trim(Matrice.ACT_TYPE_COMMANDE_ID) = Trim(VU.ACT_TYPE_COMMANDE_ID) or  Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' )
  -- Source PCM
  Left Join ${KNB_IBU_SOC_V}.VF_TFBCR BCR
      On    Trim(Cast(BCR.BCR_ID_BCR As Format 'Z(I)')) = VU.ORDER_EXTERNAL_ID
  Left Join ${KNB_IBU_SOC_V}.VF_TFCOMMARTICLE BCR_Article
      On    BCR_Article.COMMARTICLE_ID_BCR = BCR.BCR_ID_BCR
  -- Referentiel EAN
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_EAN RefEAN
      On    Trim(RefEAN.PRODUCT_ID) = Trim(VU.ACT_PRODUCT_ID_FINAL)
        And RefEAN.PERIODE_ID       = VU.ACT_PERIODE_ID
        And RefEAN.CURRENT_IN       = 1
  -- Referentiel AGAP : Produit Final
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP Final_Agap
      On    Trim(Final_Agap.PRODUCT_ID)  = Trim(VU.ACT_PRODUCT_ID_FINAL)
        And Final_Agap.PERIODE_ID        = VU.ACT_PERIODE_ID       
        And Final_Agap.CURRENT_IN        = 1
  -- Referentiel AGAP : Produit Precédent
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP Previous_Agap
      On    Trim(Previous_Agap.PRODUCT_ID)  = Trim(VU.ACT_PRODUCT_ID_PRE)
        And Previous_Agap.PERIODE_ID        = VU.ACT_PERIODE_ID       
        And Previous_Agap.CURRENT_IN        = 1
  -- Referentiel AGAP : Produit PCM
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP Bcr_Agap
      On    Trim(Bcr_Agap.EXT_PRODUCT_ID1) = Trim(BCR.BCR_FORMULE_CO) 
        And Trim(Bcr_Agap.EXT_PRODUCT_ID2) = Trim(BCR.BCR_PRESFACT_CO)
        And Bcr_Agap.PERIODE_ID            = VU.ACT_PERIODE_ID       
        And Bcr_Agap.CURRENT_IN            = 1
Where 
(1=1)
  And VU.ORG_GT_ACTIVITY     =  'GDT'
  And VU.ORG_WEB_ACTIVITY    <> 'Omnicanal'
  And VU.MASTER_FLAG         = 1
  And (
       VU.CONCLDD_IN = 'O' 
      Or 
       VU.ORDER_CANCELING_DT Is Not Null
      )
  And VU.ACT_DT >= current_date - 30
;
.if errorcode <> 0 then .quit 1
/* 
----------------------------------------------------------------------------------------------
-- Etape 3 : Extraction Totale des KPI (ALL) 
----------------------------------------------------------------------------------------------
INSERT INTO ${KNB_PCO_TMP}.ACT_T_GDT_DAY
(
    EXT_DT
  , ID_ACTE                
  , CODE_ACTE              
  , FAMILLE_KPI            
  , TYPE_PRODUIT           
  , DATE_ACTE              
  , ID_ACTE_COMPLEMENTAIRE 
  , NUMERO_GSM             
  , IMEI                   
  , NSCE                   
  , NUMERO_CLIENT          
  , CUID                   
  , CODE_ADV               
  , CODE_EDO               
  , CODE_OFFRE1            
  , CODE_OFFRE2            
  , LIBELLE_OFFRE          
  , CODE_OFFRE_DEPART1     
  , CODE_OFFRE_DEPART2     
  , LIBELLE_OFFRE_DEPART   
  , CODE_ARTICLE           
  , LIBELLE_ARTICLE        
  , NUMERO_ACCORD          
  , MONTANT_PCM            
  , CODE_TYPE_PVC          
  , CREATION_TS
  , CURRENT_IN   
  , FRESH_IN      
  , COHERENCE_IN  
)
Select 
  '${DATE_EXTRACT}'                                         As EXT_DT                 ,
  VU.ACTE_ID                                                As ID_ACTE                ,
  VU.ACT_CD                                                 As CODE_ACTE              ,
  VU.ACT_ACTE_FAMILLE_KPI                                   As FAMILLE_KPI            ,
  Matrice.TYPE_PRODUIT                                      As TYPE_PRODUIT           ,
  VU.ACT_DT                                                 As DATE_ACTE              ,
  Case when VU.ACT_TYPE_COMMANDE_ID = 'TSUBV' then VU.CPLT_ACTE_ID     
       else NULL
  End                                                  	   As ID_ACTE_COMPLEMENTAIRE ,
  Case 
    When Coalesce(VU.MSISDN_ID,'0000000000') <> '0000000000'
      Then VU.MSISDN_ID
    Else Null 
  End                                                       As NUMERO_GSM             ,
  VU.IMEI_CD                                                As IMEI                   ,
  VU.SIM_CD                                                 As NSCE                   ,
  VU.EXTERNAL_PARTY_ID                                      As NUMERO_CLIENT          ,
  VU.AGENT_ID_UPD                                           As CUID                   ,
  VU.UNIFIED_SHOP_CD                                        As CODE_ADV               ,
  VU.ORG_EDO_ID                                             As CODE_EDO               ,
  Case
    When Matrice.TYPE_LIGNE = 'O'
      Then Final_Agap.EXT_PRODUCT_ID1 
    When Matrice.TYPE_LIGNE = 'P'
      Then BCR.BCR_FORMULE_CO
    Else Null
  End                                                       As CODE_OFFRE1            ,
  Case
    When Matrice.TYPE_LIGNE = 'O'
      Then Final_Agap.EXT_PRODUCT_ID2 
    When Matrice.TYPE_LIGNE = 'P'
      Then BCR.BCR_PRESFACT_CO
    Else Null
  End                                                       As CODE_OFFRE2            ,
  Case
    When Matrice.TYPE_LIGNE = 'O'
      Then Final_Agap.PRODUCT_DS 
    When Matrice.TYPE_LIGNE = 'P'
      Then Bcr_Agap.PRODUCT_DS
    Else Null
  End                                                       As LIBELLE_OFFRE          ,
  Previous_Agap.EXT_PRODUCT_ID1                             As CODE_OFFRE_DEPART1     ,
  Previous_Agap.EXT_PRODUCT_ID2                             As CODE_OFFRE_DEPART2     ,
  Previous_Agap.PRODUCT_DS                                  As LIBELLE_OFFRE_DEPART   ,
  Case 
    When REGEXP_SIMILAR(TRIM(VU.EAN_CD), '^[0-9]*$') = 1 
      Then Lpad( VU.EAN_CD, 13,'0')
    Else Null
  End                                                       As CODE_ARTICLE           ,
  Case 
    When Matrice.TYPE_LIGNE In ('P','T')
      Then RefEAN.PRODUIT_DS
    Else Null 
  End                                                       As LIBELLE_ARTICLE        ,
  Case 
    When Matrice.TYPE_LIGNE = 'P'
      Then 'ADV' || Lpad(VU.ORDER_EXTERNAL_ID, 10, '0')
    Else Null 
  End                                                       As NUMERO_ACCORD          ,
  Case 
    When Matrice.TYPE_LIGNE = 'P'
      Then BCR_Article.COMMARTICLE_MONTANTPRIME
    Else Null 
  End                                                       As MONTANT_PCM            ,
  Case 
    When Matrice.TYPE_LIGNE = 'P'
      Then 'PCMS' || Trim(VU.PCM_LEVEL_POINT_NU)
    Else Null 
  End                                                       As CODE_TYPE_PVC          ,
  CAST('${KNB_BATCH_DATE}' AS timestamp(0))                 As CREATION_TS            ,
  1                                                         As CURRENT_IN             ,
  1                                                         As FRESH_IN               ,
  1                                                         As COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED VU
  -- Matrice Extraction Fichier GDT
  Left outer join ${KNB_PCO_SOC}.ORG_R_MATRICE_FU_GDT Matrice
      On    Trim(Matrice.ACT_ACTE_FAMILLE_KPI) = Trim(VU.ACT_ACTE_FAMILLE_KPI)
  -- Source PCM
  Left Join ${KNB_IBU_SOC_V}.VF_TFBCR BCR
      On    Trim(Cast(BCR.BCR_ID_BCR As Format 'Z(I)')) = VU.ORDER_EXTERNAL_ID
  Left Join ${KNB_IBU_SOC_V}.VF_TFCOMMARTICLE BCR_Article
      On    BCR_Article.COMMARTICLE_ID_BCR = BCR.BCR_ID_BCR
  -- Referentiel EAN
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_EAN RefEAN
      On    Trim(RefEAN.PRODUCT_ID) = Trim(VU.ACT_PRODUCT_ID_FINAL)
        And RefEAN.PERIODE_ID       = VU.ACT_PERIODE_ID
        And RefEAN.CURRENT_IN       = 1
  -- Referentiel AGAP : Produit Final
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP Final_Agap
      On    Trim(Final_Agap.PRODUCT_ID)  = Trim(VU.ACT_PRODUCT_ID_FINAL)
        And Final_Agap.PERIODE_ID        = VU.ACT_PERIODE_ID       
        And Final_Agap.CURRENT_IN        = 1
  -- Referentiel AGAP : Produit Precédent
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP Previous_Agap
      On    Trim(Previous_Agap.PRODUCT_ID)  = Trim(VU.ACT_PRODUCT_ID_PRE)
        And Previous_Agap.PERIODE_ID        = VU.ACT_PERIODE_ID       
        And Previous_Agap.CURRENT_IN        = 1
  -- Referentiel AGAP : Produit PCM
  Left Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP Bcr_Agap
      On    Trim(Bcr_Agap.EXT_PRODUCT_ID1) = Trim(BCR.BCR_FORMULE_CO) 
        And Trim(Bcr_Agap.EXT_PRODUCT_ID2) = Trim(BCR.BCR_PRESFACT_CO)
        And Bcr_Agap.PERIODE_ID            = VU.ACT_PERIODE_ID       
        And Bcr_Agap.CURRENT_IN            = 1
Where 
(1=1)
  And VU.ORG_GT_ACTIVITY     =  'GDT'
  And VU.ORG_WEB_ACTIVITY    <> 'Omnicanal'
  And VU.MASTER_FLAG         = 1
  And (
       VU.CONCLDD_IN = 'O' 
      Or 
       VU.ORDER_CANCELING_DT Is Not Null
      )
  And VU.ACT_DT >= current_date - 30
  And Matrice.ACT_TYPE_COMMANDE_ID  = 'ALL' 
; */
.if errorcode <> 0 then .quit 1



