-- $HEADER:  %HEADER% 
--------------------------------------------------------------------------------
--                                                                              
-- NOM FICHIER  : $Workfile:   ATP_SPVC_Cold_Alimentation.sql   $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul des données de la table Miroir de SPVC
--------------------------------------------------------------------------------
--                HISTORIQUE
--                                                                
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 29/07/2015      YZH         Creation
-- 15/02/2016      HFO         MODIFICATION ajout acte VALO
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_T_ACTE_SPVC All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ACT_T_ACTE_SPVC
(
  ACTE_ID         ,    
  ACTE_VALO       ,
  FILE_ID         ,    
  ACT_MTH         ,    
  FRESH_TS        ,   
  HOT_IN          ,     
  CREATION_TS     ,
  LAST_MODIF_TS   ,
  FRESH_IN        ,   
  COHERENCE_IN        
)
Select
  SPVC.ACTE_ID                                                                                          As ACTE_ID               ,
  SPVC.ACTE_VALO                                                                                        As ACTE_VALO               ,
  SPVC.FILE_ID                                                                                          As FILE_ID               ,
  Substr(SPVC.FILE_ID,13,6)                                                                             As ACT_MTH               , 
  Cast(Substr(SPVC.FILE_ID,20,14) as timestamp(0) FORMAT 'YYYYMMDDhhmiss')                              As FRESH_TS              ,
  0                                                                                                     As HOT_IN                ,
  Current_Timestamp(0)                                                                                  As CREATION_TS           ,
  Current_Timestamp(0)                                                                                  As LAST_MODIF_TS         ,
  1                                                                                                     As FRESH_IN              ,
  1                                                                                                     As COHERENCE_IN
From
  -- On extrait les donnees de la table ODS 
  ${KNB_PCO_TMP}.ACT_W_ACTE_SPVC SPVC
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_T_ACTE_SPVC;
.if errorcode <> 0 then .quit 1

.quit 0
