-- $HEADER: mm2pco/current/sql/ATP_DPVC_Placement_Step4_Consolidation.sql 13_05#4 06-JAN-2017 15:40:23 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DPVC_Placement_Step4_Consolidation.sql  $$
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 23/07/2014      HZO         Creation
-- 03/02/2016      MDE         Evol Pilcom Digital 
-- 07/04/2015      MDE         Evol  : profondeur calcul 100 jrs
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PLACEMENT_DECLAR_PVC All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ACT_W_PLACEMENT_DECLAR_PVC
(
  ACTE_ID                           ,
  EXTERNAL_ACTE_ID                  ,
  INTRNL_SOURCE_ID                  ,
  PVC_ACTE_ID                       ,
  PVC_ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE                  ,
  ACTE_ID_DETAIL_CONTACTE           ,
  ACTE_ID_COMMANDE_REFERENCE        ,
  SOURCE_ID                         ,
  ACTE_STATUT                       ,
  ACTION_ACTE                       ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  CUID                              ,
  ORDER_STATUT                      ,
  ORDER_STATUT_TS                   ,
  SELLER_LAST_NAME                  ,
  SELLER_FIRST_NAME                 ,
  SALE_CHANNEL_DLC                  ,
  SALE_CHANNEL_ORDER                ,
  CODE_PARC_CLI                     ,
  ORIGINE_DLC_DS                    ,
  CUSTOMER_TYPE                     ,
  CUSTOMER_SEG                      ,
  CUSTOMER_LAST_NAME                ,
  CUSTOMER_FIRST_NAME               ,
  CUSTOMER_SIRET                    ,
  MISISDN                           ,
  ND                                ,
  NDIP                              ,
  CUSTOMER_CAT                      ,
  CUSTOMER_AGENCE                   ,
  CUSTOMER_ZIPCODE                  ,
  VOLUME                            ,
  VALEUR                            ,
  CA                                ,
  STATUT_CSO                        ,
  STATUT_CSO_DS                     ,
  COMMENTAIRE_DS                    ,
  TEAM_DLC_DES                      ,
  TEAM_ORDER_DES                    ,
  ACT_CD                            ,
  ACT_TYPE_COMMANDE_ID              ,
  TYPE_COMMANDE_INI                 ,
  CODE_COMMANDE_FIN                 ,
  TYPE_COMMANDE_FIN                 ,
  CODE_PRODUCT_FIN                  ,
  PRODUCT_DSC_FIN                   ,
  SEGMENT_COM_FIN                   ,
  CODE_PRODUCT_INI                  ,
  PRODUCT_DSC_INI                   ,
  SEGMENT_COM_INI                   ,
  CODE_MIGR_INI                     ,
  DSC_MIGR_INI                      ,
  CODE_MIGR_FIN                     ,
  DSC_MIGR_FIN                      ,
  ID_FREGATE                        ,
  DT_CHECK_PARC                     ,
  DT_END_PARC                       ,
  END_PARC_DSC                      ,
  TAUX_PERENNITE                    ,
  DELAIS_PERENNITE                  ,
  OSCAR_VALUE                       ,
  DUREE_ENG                         ,
  IMEI                              ,
  EAN                               ,
  SIM                               ,
  ID_PARSIFAL                       ,
  SERVICE_ACCESS_ID                 ,
  PAR_IMSI_CD                       ,
  CLIENT_NU                         ,
  PAR_DEPARTMNT_ID                  ,
  PAR_BU_CD                         ,
  PAR_POSTAL_CD                     ,
  PAR_INSEE_CD                      ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  PAR_IRIS2000_CD                   ,
  PAR_FIBER_IN                      ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  DMC_LINE_TYPE                     ,
  DMC_ACTIVATION_DT                 ,
  MOTIF_DLC_DS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  FRESH_IN                          ,
  COHERENCE_IN                      ,
  RUN_ID                            
)
Select
  Placement.ACTE_ID                                                       As ACTE_ID                            ,
  Placement.EXTERNAL_ACTE_ID                                              As EXTERNAL_ACTE_ID                   ,
  Placement.INTRNL_SOURCE_ID                                              As INTRNL_SOURCE_ID                   ,
  Placement.PVC_ACTE_ID                                                   As PVC_ACTE_ID                        ,
  Placement.PVC_ACTE_ID_EXTERNE                                           As PVC_ACTE_ID_EXTERNE                ,
  Placement.ACTE_ID_CONTACTE                                              As ACTE_ID_CONTACTE                   ,
  Placement.ACTE_ID_DETAIL_CONTACTE                                       As ACTE_ID_DETAIL_CONTACTE            ,
  Placement.ACTE_ID_COMMANDE_REFERENCE                                    As ACTE_ID_COMMANDE_REFERENCE         ,
  Placement.SOURCE_ID                                                     As SOURCE_ID                          ,
  Placement.ACTE_STATUT                                                   As ACTE_STATUT                        ,
  Placement.ACTION_ACTE                                                   As ACTION_ACTE                        ,
  Placement.ORDER_DEPOSIT_DT                                              As ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                              As ORDER_DEPOSIT_TS                   ,
  Placement.CUID                                                          As CUID                               ,
  Placement.ORDER_STATUT                                                  As ORDER_STATUT                       ,
  Placement.ORDER_STATUT_TS                                               As ORDER_STATUT_TS                    ,
  Placement.SELLER_LAST_NAME                                              As SELLER_LAST_NAME                   ,
  Placement.SELLER_FIRST_NAME                                             As SELLER_FIRST_NAME                  ,
  Placement.SALE_CHANNEL_DLC                                              As SALE_CHANNEL_DLC                   ,
  Placement.SALE_CHANNEL_ORDER                                            As SALE_CHANNEL_ORDER                 ,
  Placement.CODE_PARC_CLI                                                 As CODE_PARC_CLI                      ,
  Placement.ORIGINE_DLC_DS                                                As ORIGINE_DLC_DS                     ,
  Placement.CUSTOMER_TYPE                                                 As CUSTOMER_TYPE                      ,
  Placement.CUSTOMER_SEG                                                  As CUSTOMER_SEG                       ,
  Placement.CUSTOMER_LAST_NAME                                            As CUSTOMER_LAST_NAME                 ,
  Placement.CUSTOMER_FIRST_NAME                                           As CUSTOMER_FIRST_NAME                ,
  Placement.CUSTOMER_SIRET                                                As CUSTOMER_SIRET                     ,
  Placement.MISISDN                                                       As MISISDN                            ,
  Placement.ND                                                            As ND                                 ,
  Placement.NDIP                                                          As NDIP                               ,
  Placement.CUSTOMER_CAT                                                  As CUSTOMER_CAT                       ,
  Placement.CUSTOMER_AGENCE                                               As CUSTOMER_AGENCE                    ,
  Placement.CUSTOMER_ZIPCODE                                              As CUSTOMER_ZIPCODE                   ,
  Placement.VOLUME                                                        As VOLUME                             ,
  Placement.VALEUR                                                        As VALEUR                             ,
  Placement.CA                                                            As CA                                 ,
  Placement.STATUT_CSO                                                    As STATUT_CSO                         ,
  Placement.STATUT_CSO_DS                                                 As STATUT_CSO_DS                      ,
  Placement.COMMENTAIRE_DS                                                As COMMENTAIRE_DS                     ,
  Placement.TEAM_DLC_DES                                                  As TEAM_DLC_DES                       ,
  Placement.TEAM_ORDER_DES                                                As TEAM_ORDER_DES                     ,
  Placement.ACT_CD                                                        As ACT_CD                             ,
  Placement.ACT_TYPE_COMMANDE_ID                                          As ACT_TYPE_COMMANDE_ID               ,
  Placement.TYPE_COMMANDE_INI                                             As TYPE_COMMANDE_INI                  ,
  Placement.CODE_COMMANDE_FIN                                             As CODE_COMMANDE_FIN                  ,
  Placement.TYPE_COMMANDE_FIN                                             As TYPE_COMMANDE_FIN                  ,
  Placement.CODE_PRODUCT_FIN                                              As CODE_PRODUCT_FIN                   ,
  Placement.PRODUCT_DSC_FIN                                               As PRODUCT_DSC_FIN                    ,
  Placement.SEGMENT_COM_FIN                                               As SEGMENT_COM_FIN                    ,
  Placement.CODE_PRODUCT_INI                                              As CODE_PRODUCT_INI                   ,
  Placement.PRODUCT_DSC_INI                                               As PRODUCT_DSC_INI                    ,
  Placement.SEGMENT_COM_INI                                               As SEGMENT_COM_INI                    ,
  Placement.CODE_MIGR_INI                                                 As CODE_MIGR_INI                      ,
  Placement.DSC_MIGR_INI                                                  As DSC_MIGR_INI                       ,
  Placement.CODE_MIGR_FIN                                                 As CODE_MIGR_FIN                      ,
  Placement.DSC_MIGR_FIN                                                  As DSC_MIGR_FIN                       ,
  Placement.ID_FREGATE                                                    As ID_FREGATE                         ,
  Placement.DT_CHECK_PARC                                                 As DT_CHECK_PARC                      ,
  Placement.DT_END_PARC                                                   As DT_END_PARC                        ,
  Placement.END_PARC_DSC                                                  As END_PARC_DSC                       ,
  Placement.TAUX_PERENNITE                                                As TAUX_PERENNITE                     ,
  Placement.DELAIS_PERENNITE                                              As DELAIS_PERENNITE                   ,
  Placement.OSCAR_VALUE                                                   As OSCAR_VALUE                        ,
  Placement.DUREE_ENG                                                     As DUREE_ENG                          ,
  Placement.IMEI                                                          As IMEI                               ,
  Placement.EAN                                                           As EAN                                ,
  Placement.SIM                                                           As SIM                                ,
  Placement.ID_PARSIFAL                                                   As ID_PARSIFAL                        ,
  Placement.SERVICE_ACCESS_ID                                             As SERVICE_ACCESS_ID                  ,
  Placement.PAR_IMSI_CD                                                   As PAR_IMSI_CD                        ,
  Placement.CLIENT_NU                                                     As CLIENT_NU                          ,
  Placement.PAR_DEPARTMNT_ID                                              As PAR_DEPARTMNT_ID                   ,
  Placement.PAR_BU_CD                                                     As PAR_BU_CD                          ,
  Placement.PAR_POSTAL_CD                                                 As PAR_POSTAL_CD                      ,
  Placement.PAR_INSEE_CD                                                  As PAR_INSEE_CD                       ,
  Placement.PAR_GEO_MACROZONE                                             As PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                                          As PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                                         As PAR_PARTY_REGRPMNT_ID              ,
  Placement.PAR_IRIS2000_CD                                               As PAR_IRIS2000_CD                    ,
  Placement.PAR_FIBER_IN                                                  As PAR_FIBER_IN                       ,
  Placement.DMC_LINE_ID                                                   AS DMC_LINE_ID                        ,
  Placement.DMC_MASTER_LINE_ID                                            AS DMC_MASTER_LINE_ID                 ,
  Placement.DMC_LINE_TYPE                                                 AS DMC_LINE_TYPE                      ,
  Placement.DMC_ACTIVATION_DT                                             AS DMC_ACTIVATION_DT                  ,
  Placement.MOTIF_DLC_DS                                                  As MOTIF_DLC_DS                       ,
  Placement.CREATION_TS                                                   As CREATION_TS                        ,
  Placement.LAST_MODIF_TS                                                 As LAST_MODIF_TS                      ,
  Placement.FRESH_IN                                                      As FRESH_IN                           ,
  Placement.COHERENCE_IN                                                  As COHERENCE_IN                       ,
  Placement.RUN_ID                                                        As RUN_ID                             
From
  --On prend tout le contenu
  ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_DECLAR_PVC Placement
  Where
  (1=1)
  And Placement.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_526}) 
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_W_PLACEMENT_DECLAR_PVC;
.if errorcode <> 0 then .quit 1

.quit 0
