-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_REFCOM_Export_VariableChargement.sql
-- TYPE         : Script SQL 
-- DESCRIPTION  : Sql d'export des variables pour l'intégration de REFCOM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/04/2015      GMA         Creation
--------------------------------------------------------------------------------


.set width 2000;



Select
  Trim(Coalesce(CAS_REJ,''))||';'||
  Trim(Coalesce(REJ_LIB,''))||';'||
  Trim(Coalesce(Sum(NB_REJ),'')) (title '')
From
  ${KNB_PCO_REFCOM}.V_CAT_F_REJECT_REFCOM
Where
  (1=1)
  And CREATION_TS  = Cast('${KNB_BATCH_DATE}' AS Timestamp(0))
Group by
  CAS_REJ         ,
  REJ_LIB         
;
.if errorcode <> 0 then .quit 1

.quit 0

