--$HEADER:   %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_EnrichissementPlacement_Cold_TAC_IMEI_EAN_PCM.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d 'alimentation Code TAC, IMEI,EAN pour PCM
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 02/07/2015     HFO         CREATION
---------------------------------------------------------------------------------


.set width 5000

--------------------------------
--             --
--------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PCM_C_TIE

;Insert  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PCM_C_TIE 
(
  ACTE_ID       ,
  ORDER_DEPOSIT_DT        ,
  TAC_PREVIOUS_CD         ,
  IMEI_PREVIOUS_CD        ,
  EAN_PREVIOUS_CD         
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID      ,
  RefDmc.DATESAISIEBCR            as ORDER_DEPOSIT_DT       ,
  HistDmc.TAC_ID                  as TAC_PREVIOUS_CD        ,
  HistDmc.IMEI_CD                 as IMEI_PREVIOUS_CD       ,
  codeEAN.CODE_EAN                as EAN_PREVIOUS_CD         
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_DMC_PCM RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_HIST HistDmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_MASTER_LINE_ID   =  HistDmc.MASTER_LINE_ID
      And HistDmc.VAL_END_DT      <  RefDmc.DATESAISIEBCR
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_EAN codeEAN
     On codeEAN.CODE_TAC=HistDmc.TAC_ID
      And codeEAN.CODE_TAC Is not null
      And codeEAN.CURRENT_IN      =  1
      And codeEAN.CLOSURE_DT      Is null
Where
  (1=1)
  And HistDmc.TAC_ID is not null
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID 
                            Order by HistDmc.VAL_END_DT Desc,HistDmc.VAL_START_DT Desc,codeEAN.PRODUCT_ID asc )=1 ;

.if errorcode <> 0 then .quit 1

Collect Stats On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PCM_C_TIE;
.if errorcode <> 0 then .quit 1

.quit 0
