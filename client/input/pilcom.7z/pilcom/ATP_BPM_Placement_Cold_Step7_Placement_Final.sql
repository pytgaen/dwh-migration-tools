--$HEADER:   mm2pco/current/sql/ATP_BPM_Placement_Cold_Step7_Placement_Final.sql 13_05#16 26-JUN-2019 11:39:21 NNGS2043                                                                
--------------------------------------------------------------------------------      
--                                                                                    
-- NOM FICHIER  : $Workfile:   ATP_BPM_Placement_Cold_Step7_Placement_Final.sql  $    
-- TYPE         : Script SQL                                                          
-- DESCRIPTION  : SQL de                                                              
--------------------------------------------------------------------------------      
--                HISTORIQUE                                                          
--                                                                                    
-- DATE            AUTEUR      CREATION/MODIFICATION                                  
-- 16/08/2016      ABO         Creation     
-- 10/03/2017      MDE         Modif                                          
-- 13/03/2017      HOB         Modif Oslo
-- 12/12/2017      HOB         Modif du Mapping de IOBSP 
-- 19/07/2018      HOB         Carte Premium 
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 06/08/2020      EVI         PILCOM-638 : Gestion Bundle
--------------------------------------------------------------------------------      
                
.set width 2500;
                
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BPM_C All;
.if errorcode <> 0 then .quit 1                      
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BPM_C     
(
   ACTE_ID                 ,
   BANK_LINE_ID            ,
--   BK_RECRD_ID             ,
   TYPE_SOURCE_ID          ,
   INTRNL_SOURCE_ID        ,
   TYPE_LINE               ,
   TYPE_COMMANDE_ID        ,
   ORDER_DEPOSIT_DT        ,
   ORDER_DEPOSIT_TS        ,
   BK_SUB_PRD_CD           ,
   BK_SUB_PRD_ID           ,
   IND_SUB_PRD_CD          ,
   BK_SUB_PRD_TYP          ,
   EVENT_CALC_DS           ,
   LAST_STATUS_CD          ,
   CALCUL_TS               ,
   EXTERNAL_INDCTN_ID      ,
   EXTERNAL_SUBSCRPTN_ID   ,
   FLAG_PROCESS            ,
   EXTERNAL_PRODUCT_ID     ,
   EXTERNAL_PRODUCT_DS     ,
   STATUS_CD               ,
   EXTERNAL_CHANNEL_ID     ,
   OPTIN_IN                ,
   OPTOUT_IN               ,
   REFER_CD                ,
   LIGHTNNG_DS             ,
   REFER_SUB_CD            ,
   LIGHTNNG_SUB_DS         ,
   CHANNL_FINAL_CD         ,
   PAR_CID_ID              ,
   PAR_PID_ID              ,
   PAR_FIRST_IN            ,
   EXTERNAL_PARTY_ID       ,
   ORIGIN                  ,
   COMPTE_BK_ID            ,
   CUST_BK_ID              ,
   REASON_END_DS           ,
   ACCOUNT_START_TS        ,
   ACCOUNT_END_TS          ,
   BK_SAME_PARTY_IN        ,
   BK_SUB_CITY_LN          ,
   BK_SUB_COUNTRY_CD       ,
   BK_SUB_SALUTATION_CD    ,
   PAR_LASTNAME            ,
   PAR_FIRSTNAME           ,
   BK_SUB_ADRESS_NM        ,
   PAR_BIRTH_DT            ,
   PAR_EMAIL               ,
   PAR_FIXE_DS             ,
   SERVICE_ACCESS_ID       ,
   PAR_ND_DS               ,
   PAR_MOBILE_DS           ,
   MSISDN_ID               ,
   FIB_CLIENT_TYPE         ,
   DOSSIER_NU              ,
   CLIENT_NU               ,
   DMC_LINE_ID             ,
   MASTER_LINE_ID          ,
   DMC_LINE_TYPE           ,
   DMC_ACTIVATION_DT       ,
   PAR_DEPRTMNT_ID         ,
   PAR_AID                 ,
   PAR_REGRPMNT_ID         ,
   PAR_UNIFIED_PARTY_ID    ,
   PAR_GEO_MACROZONE       ,
   MAIL_ADRESS             ,
   PAR_POSTAL_CD           ,
   PAR_INSEE_NB            ,
   PAR_BU_CD               ,
   PAR_IRIS2000_CD         ,
   PAR_FIBER_IN            ,
   SCORE_PRE               ,
   OFFER                   ,
   BK_OFFER_CD             ,
   TYPE_CPT                ,
   CROSS_BENEFITS          ,
   ABORT_MOT_ID            ,
   ORG_AGENT_ID            ,
   ORG_NOM                 ,
   ORG_PRENOM              ,
   UNIFIED_SHOP_CD         ,
   EDO_ID                  ,
   TYPE_EDO_ID             ,
   IND_SHOP_IN             ,
   SUB_SHOP_IN             ,
   ORG_AGENT_IOBSP         ,
   ORG_EDO_IOBSP           ,
   DISTRBTN_CHANNL_ID      ,
   ACTIVITY                ,
   FLAG_PLT_SCH_IN         ,
   FLAG_PLT_CONV_NB        ,
   FLAG_TYPE_GEO_CD        ,
   FLAG_TYPE_CPT_NTK       ,
   NETWRK_TYP_EDO_ID       ,
   FLAG_TYPE_PTN_NTK       ,
   FLAG_AD_SC              ,
   ORG_CHANNEL_CD          ,
   ORG_SUB_CHANNEL_CD      ,
   ORG_SUB_SUB_CHANNEL_CD  ,
   ORG_GT_ACTIVITY         ,
   ORG_FIDELISATION        ,
   ORG_WEB_ACTIVITY        ,
   ORG_AUTO_ACTIVITY       ,
   ORG_REM_CHANNEL_CD      ,
   ORG_TEAM_LEVEL_1_CD     ,
   ORG_TEAM_LEVEL_1_DS     ,
   ORG_TEAM_LEVEL_2_CD     ,
   ORG_TEAM_LEVEL_2_DS     ,
   ORG_TEAM_LEVEL_3_CD     ,
   ORG_TEAM_LEVEL_3_DS     ,
   ORG_TEAM_LEVEL_4_CD     ,
   ORG_TEAM_LEVEL_4_DS     ,
   WORK_TEAM_LEVEL_1_CD    ,
   WORK_TEAM_LEVEL_1_DS    ,
   WORK_TEAM_LEVEL_2_CD    ,
   WORK_TEAM_LEVEL_2_DS    ,
   WORK_TEAM_LEVEL_3_CD    ,
   WORK_TEAM_LEVEL_3_DS    ,
   WORK_TEAM_LEVEL_4_CD    ,
   WORK_TEAM_LEVEL_4_DS    ,
   FIBR_ELIGBT_IN          ,
   DATE_CREATE_TS          ,
   DATE_REM_TS             ,
   CLOSURE_FONC_DT         ,
   CLOSURE_FONC_CD         ,
   COMPTTN_IN              ,
   COMPTTN_ID              ,
   PACKAGE_CD              ,
   HOT_IN                  ,
   CREATION_TS             ,
   LAST_MODIF_TS           ,
   FRESH_IN                ,
   COHERENCE_IN             
)                                                      
Select                                                 
   Placement.ACTE_ID                as ACTE_ID                 ,
   Placement.BANK_LINE_ID           as BANK_LINE_ID            ,
--   Placement.BK_RECRD_ID            as BK_RECRD_ID             ,
   Placement.TYPE_SOURCE_ID         as TYPE_SOURCE_ID          ,
   Placement.INTRNL_SOURCE_ID       as INTRNL_SOURCE_ID        ,
   Placement.TYPE_LINE              as TYPE_LINE               ,
   Placement.TYPE_COMMANDE_ID       as TYPE_COMMANDE_ID        ,
   Placement.ORDER_DEPOSIT_DT       as ORDER_DEPOSIT_DT        ,
   Placement.ORDER_DEPOSIT_TS       as ORDER_DEPOSIT_TS        ,
   Placement.BK_SUB_PRD_CD          as BK_SUB_PRD_CD           ,
   Placement.BK_SUB_PRD_ID          as BK_SUB_PRD_ID           ,
   Placement.IND_SUB_PRD_CD         as IND_SUB_PRD_CD       ,
   Placement.BK_SUB_PRD_TYP         as BK_SUB_PRD_TYP          ,
   Placement.EVENT_CALC_DS          as EVENT_CALC_DS           ,
   Placement.LAST_STATUS_CD         as LAST_STATUS_CD          ,
   Placement.CALCUL_TS              as CALCUL_TS               ,
   Placement.EXTERNAL_INDCTN_ID     as EXTERNAL_INDCTN_ID      ,
   Placement.EXTERNAL_SUBSCRPTN_ID  as EXTERNAL_SUBSCRPTN_ID   ,
   Placement.FLAG_PROCESS           as FLAG_PROCESS            ,
   Placement.EXTERNAL_PRODUCT_ID    as EXTERNAL_PRODUCT_ID     ,
   Placement.EXTERNAL_PRODUCT_DS    as EXTERNAL_PRODUCT_DS     ,
   Placement.STATUS_CD              as STATUS_CD               ,
   Placement.EXTERNAL_CHANNEL_ID    as EXTERNAL_CHANNEL_ID     ,
   Placement.OPTIN_IN               as OPTIN_IN                ,
   Placement.OPTOUT_IN              as OPTOUT_IN               ,
   Placement.REFER_CD               as REFER_CD                ,
   Placement.LIGHTNNG_DS            as LIGHTNNG_DS             ,
   Placement.REFER_SUB_CD           as REFER_SUB_CD            ,
   Placement.LIGHTNNG_SUB_DS        as LIGHTNNG_SUB_DS         ,
   Placement.CHANNL_FINAL_CD        as CHANNL_FINAL_CD         ,
   Placement.PAR_CID_ID             as PAR_CID_ID              ,
   Placement.PAR_PID_ID             as PAR_PID_ID              ,
   Placement.PAR_FIRST_IN           as PAR_FIRST_IN            ,
   Placement.EXTERNAL_PARTY_ID      as EXTERNAL_PARTY_ID       ,
   Placement.ORIGIN                 as ORIGIN                  ,
   Placement.COMPTE_BK_ID           as COMPTE_BK_ID            ,
   Placement.CUST_BK_ID             as CUST_BK_ID              ,
   Placement.REASON_END_DS          as REASON_END_DS           ,
   Placement.ACCOUNT_START_TS       as ACCOUNT_START_TS        ,
   Placement.ACCOUNT_END_TS         as ACCOUNT_END_TS          ,
   Placement.BK_SAME_PARTY_IN       as BK_SAME_PARTY_IN        ,
   Placement.BK_SUB_CITY_LN         as BK_SUB_CITY_LN          ,
   Placement.BK_SUB_COUNTRY_CD      as BK_SUB_COUNTRY_CD       ,
   Placement.BK_SUB_SALUTATION_CD   as BK_SUB_SALUTATION_CD    ,
   Placement.PAR_LASTNAME           as PAR_LASTNAME            ,
   Placement.PAR_FIRSTNAME          as PAR_FIRSTNAME           ,
   Placement.BK_SUB_ADRESS_NM       as BK_SUB_ADRESS_NM        ,
   Placement.PAR_BIRTH_DT           as PAR_BIRTH_DT            ,
   Placement.PAR_EMAIL              as PAR_EMAIL               ,
   Placement.PAR_FIXE_DS            as PAR_FIXE_DS             ,
   Placement.SERVICE_ACCESS_ID      as SERVICE_ACCESS_ID       ,
   Placement.PAR_ND_DS              as PAR_ND_DS               ,
   Placement.PAR_MOBILE_DS          as PAR_MOBILE_DS           ,
   Placement.MSISDN_ID              as MSISDN_ID               ,
   Placement.FIB_CLIENT_TYPE        as FIB_CLIENT_TYPE         ,
   Placement.DOSSIER_NU             as DOSSIER_NU              ,
   Placement.CLIENT_NU              as CLIENT_NU               ,
   Placement.DMC_LINE_ID            as DMC_LINE_ID             ,
   Placement.MASTER_LINE_ID         as MASTER_LINE_ID          ,
   Placement.DMC_LINE_TYPE          as DMC_LINE_TYPE           ,
   Placement.DMC_ACTIVATION_DT      as DMC_ACTIVATION_DT       ,
   Placement.PAR_DEPRTMNT_ID        as PAR_DEPRTMNT_ID         ,
   Placement.PAR_AID                as PAR_AID                 ,
   Placement.PAR_REGRPMNT_ID        as PAR_REGRPMNT_ID         ,
   Placement.PAR_UNIFIED_PARTY_ID   as PAR_UNIFIED_PARTY_ID    ,
   Placement.PAR_GEO_MACROZONE      as PAR_GEO_MACROZONE       ,
   Placement.MAIL_ADRESS            as MAIL_ADRESS             ,
   Placement.PAR_POSTAL_CD          as PAR_POSTAL_CD           ,
   Placement.PAR_INSEE_NB           as PAR_INSEE_NB            ,
   Placement.PAR_BU_CD              as PAR_BU_CD               ,
   Placement.PAR_IRIS2000_CD        as PAR_IRIS2000_CD         ,
   Placement.PAR_FIBER_IN           as PAR_FIBER_IN            ,
   Placement.SCORE_PRE              as SCORE_PRE               ,
   Placement.OFFER                  as OFFER                   ,
   Placement.BK_OFFER_CD            as BK_OFFER_CD             ,
   Placement.TYPE_CPT               as TYPE_CPT                ,
   Placement.CROSS_BENEFITS         as CROSS_BENEFITS          ,
   Placement.ABORT_MOT_ID           as ABORT_MOT_ID            ,
   Placement.ORG_AGENT_ID           as ORG_AGENT_ID            ,
   Placement.ORG_NOM                as ORG_NOM                 ,
   Placement.ORG_PRENOM             as ORG_PRENOM              ,
   Placement.UNIFIED_SHOP_CD        as UNIFIED_SHOP_CD         ,
   Placement.EDO_ID                 as EDO_ID                  ,
   Placement.TYPE_EDO_ID            as TYPE_EDO_ID             ,
   Placement.IND_SHOP_IN            as IND_SHOP_IN             ,
   Placement.SUB_SHOP_IN            as SUB_SHOP_IN             ,
   Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
   End                              as ORG_AGENT_IOBSP       ,
   Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
   End                              as ORG_EDO_IOBSP              ,
   Placement.DISTRBTN_CHANNL_ID     as DISTRBTN_CHANNL_ID      ,
   Placement.ACTIVITY               as ACTIVITY                ,
   Placement.FLAG_PLT_SCH_IN        as FLAG_PLT_SCH_IN         ,
   Placement.FLAG_PLT_CONV_NB       as FLAG_PLT_CONV_NB        ,
   Placement.FLAG_TYPE_GEO_CD       as FLAG_TYPE_GEO_CD        ,
   Placement.FLAG_TYPE_CPT_NTK      as FLAG_TYPE_CPT_NTK       ,
   Placement.NETWRK_TYP_EDO_ID      as NETWRK_TYP_EDO_ID       ,
   Placement.FLAG_TYPE_PTN_NTK      as FLAG_TYPE_PTN_NTK       ,
   Placement.FLAG_AD_SC             as FLAG_AD_SC              ,
   Placement.ORG_CHANNEL_CD         as ORG_CHANNEL_CD          ,
   Placement.ORG_SUB_CHANNEL_CD     as ORG_SUB_CHANNEL_CD      ,
   Placement.ORG_SUB_SUB_CHANNEL_CD as ORG_SUB_SUB_CHANNEL_CD  ,
   Placement.ORG_GT_ACTIVITY        as ORG_GT_ACTIVITY         ,
   Placement.ORG_FIDELISATION       as ORG_FIDELISATION        ,
   Placement.ORG_WEB_ACTIVITY       as ORG_WEB_ACTIVITY        ,
   Placement.ORG_AUTO_ACTIVITY      as ORG_AUTO_ACTIVITY       ,
   Placement.ORG_REM_CHANNEL_CD     as ORG_REM_CHANNEL_CD      ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_1_CD , Placement.ORG_TEAM_LEVEL_1_CD  )     as ORG_TEAM_LEVEL_1_CD     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_1_DS , Placement.ORG_TEAM_LEVEL_1_DS  )     as ORG_TEAM_LEVEL_1_DS     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_2_CD , Placement.ORG_TEAM_LEVEL_2_CD  )     as ORG_TEAM_LEVEL_2_CD     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_2_DS , Placement.ORG_TEAM_LEVEL_2_DS  )     as ORG_TEAM_LEVEL_2_DS     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_3_CD , Placement.ORG_TEAM_LEVEL_3_CD  )     as ORG_TEAM_LEVEL_3_CD     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_3_DS , Placement.ORG_TEAM_LEVEL_3_DS  )     as ORG_TEAM_LEVEL_3_DS     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_4_CD , Placement.ORG_TEAM_LEVEL_4_CD  )     as ORG_TEAM_LEVEL_4_CD     ,
   Coalesce(RefO3.ORG_TEAM_LEVEL_4_DS ,  Placement.ORG_TEAM_LEVEL_4_DS )     as ORG_TEAM_LEVEL_4_DS     ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_1_CD , Placement.WORK_TEAM_LEVEL_1_CD )    as WORK_TEAM_LEVEL_1_CD    ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_1_DS , Placement.WORK_TEAM_LEVEL_1_DS )    as WORK_TEAM_LEVEL_1_DS    ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_2_CD , Placement.WORK_TEAM_LEVEL_2_CD )    as WORK_TEAM_LEVEL_2_CD    ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_2_DS , Placement.WORK_TEAM_LEVEL_2_DS )    as WORK_TEAM_LEVEL_2_DS    ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_3_CD , Placement.WORK_TEAM_LEVEL_3_CD )   as WORK_TEAM_LEVEL_3_CD     ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_3_DS , Placement.WORK_TEAM_LEVEL_3_DS )   as WORK_TEAM_LEVEL_3_DS     ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_4_CD , Placement.WORK_TEAM_LEVEL_4_CD )   as WORK_TEAM_LEVEL_4_CD     ,
   Coalesce(RefO3.WORK_TEAM_LEVEL_4_DS , Placement.WORK_TEAM_LEVEL_4_DS )   as WORK_TEAM_LEVEL_4_DS     ,
   Placement.FIBR_ELIGBT_IN         as FIBR_ELIGBT_IN          ,
   Placement.DATE_CREATE_TS         as DATE_CREATE_TS          ,
   Placement.DATE_REM_TS            as DATE_REM_TS             ,
   Placement.CLOSURE_FONC_DT        as CLOSURE_FONC_DT         ,
   Placement.CLOSURE_FONC_CD        as CLOSURE_FONC_CD         ,
   Placement.COMPTTN_IN             as COMPTTN_IN              ,
   Placement.COMPTTN_ID             as COMPTTN_ID              ,
   Placement.PACKAGE_CD             as PACKAGE_CD              ,
   0                                as HOT_IN                  ,
   Current_Timestamp(0)             as CREATION_TS             ,
   Current_Timestamp(0)             as LAST_MODIF_TS           ,
   1                                as FRESH_IN                ,
   0                                as COHERENCE_IN             

From                                                                       
  --On prend tout le contenu de la table fusion                            
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_C_2     Placement                     
  --Enrichissement HIER O3                                                 
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_C_HIERO3 RefO3        
    On    Placement.ACTE_ID           = RefO3.ACTE_ID                      
      And Placement.ORDER_DEPOSIT_DT  = RefO3.ORDER_DEPOSIT_DT             
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    Placement.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Placement.ORG_AGENT_ID=CuidOBK.AGENT_ID
        And   Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
        And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))  
      
  Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By Placement.ORDER_DEPOSIT_TS asc)=1     

;                                                      
.if errorcode <> 0 then .quit 1                        
Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BPM_C  ;
.if errorcode <> 0 then .quit 1                        
.quit 0



