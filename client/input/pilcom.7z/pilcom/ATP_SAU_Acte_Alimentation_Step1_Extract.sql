--$HEADER:   mm2pco/current/sql/ATP_SAU_Acte_Alimentation_Step1_Extract.sql 13_05#4 06-JUL-2017 10:05:52 FQJR5800
--------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_SAU_Acte_Alimentation_Step1_Extract.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/05/2017      MDE         Creation

--------------------------------------------------------------------------------

.set width 2500;

---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des placements
--et réorganisation pour pouvoir jointer dans la table des catalogues
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SAU_C_EXT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SAU_C_EXT
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  EDO_ID                    ,
  TYPE_PRODUCT              ,
  EXT_OPER_ID               ,
  CODE_EAN                  ,
  CODE_INTERNE_CD           ,
  PERIODE_ID                
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.EDO_ID                                                as EDO_ID                     ,
  Null                                                            as TYPE_PRODUCT               ,
  'REA'                                                           as EXT_OPER_ID                ,
  Placement.OPSRV_EAN_CD                                          as CODE_EAN                   ,
  trim(cast(Placement.CODE_INTERNE_CD  as varchar(50)))           as CODE_INTERNE_CD            ,
  --Période
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )          as PERIODE_ID                 
From
   ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SAVI_SAU Placement
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
Where
  (1=1)
  And  Placement.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_524})
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SAU_C_EXT;
.if errorcode <> 0 then .quit 1

.quit 0

