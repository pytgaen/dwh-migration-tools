-- $HEADER: mm2pco/current/sql/ATP_AGC_PRP_Acte_Cold_CALC.sql 13_05#5 24-JAN-2018 09:39:26 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_PRP_Acte_Cold_CALC.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table T placement pour AGC PRP
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/05/2014      YZH         Creation
-- 21/03/2016      MDE         Modif : Correction Coalesce sur period_id
-- 07/04/2015      MDE         Evol  : profondeur calcul 100 jrs
-- 18/12/2017      JCR         Modif changement jointure Sachem
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_PRP_CALC_C All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

-- Pour les OT
Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_PRP_CALC_C
(
    ACTE_ID                               ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_DT                      ,
    PERIODE_ID                            ,
    PRODUCT_ID_PRE                        ,
    SEG_COM_ID_PRE                        ,
    SEG_COM_AGG_ID_PRE                    ,
    TYPE_MVT_PRE                          ,
    PRODUCT_ID_FINAL                      ,
    SEG_COM_ID_FINAL                      ,
    SEG_COM_AGG_ID_FINAL                  ,
    TYPE_SERVICE_FINAL                    ,
    TYPE_MVT_FINAL                        ,
    TYPE_COMMANDE_ID                      ,
    DELTA_TARIF                                      
)
Select                                                                                                    
    Placement.ACTE_ID                                                                                        as ACTE_ID                    ,
    Placement.CONTEXT_ID                                                                                     as CONTEXT_ID                 ,
    Placement.EXTERNAL_ORDER_ID                                                                              as EXTERNAL_ORDER_ID          ,
    Placement.ORDER_DEPOSIT_DT                                                                               as ORDER_DEPOSIT_DT           ,
    Coalesce(Periode.PERIODE_ID                 ,${P_PIL_049}  )                                             as PERIODE_ID                 ,
    Null                                                                                                     as PRODUCT_ID_PRE             ,
    Null                                                                                                     as SEG_COM_ID_PRE             ,
    Null                                                                                                     as SEG_COM_AGG_ID_PRE         ,
    Null                                                                                                     as TYPE_MVT_PRE               ,
    Coalesce(RefPRP.PRODUCT_ID, '${P_PIL_021}')                                                              as PRODUCT_ID_FINAL           ,
    Coalesce(RefPRP.SEG_COM_ID, '${P_PIL_022}')                                                              as SEG_COM_ID_FINAL           ,
    Coalesce(RefPRP.SEG_COM_AGG_ID,          '${P_PIL_024}')                                                 as SEG_COM_AGG_ID_FINAL       ,
    RefPRP.TYPE_SERVICE                                                                                      as TYPE_SERVICE_FINAL         ,
    Placement.MOUVEMENT                                                                                      as TYPE_MVT_FINAL             ,
    '${P_PIL_026}'                                                                                           as TYPE_COMMANDE_ID           ,  --ACQ
    NULL                                                                                                     as DELTA_TARIF                                                                         
From  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_AGC_PRP Placement
Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Periode
      On  Placement.ORDER_DEPOSIT_DT           >=    Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT           <=    Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                      =    1
      And Periode.CURRENT_IN                    =    1
      And Periode.CLOSURE_DT                    Is Null
Left Outer Join  ${KNB_PCO_TMP}.CAT_W_AGC_REFCOM_JOUR_PREP RefPRP
      On  Placement.PRODUCT_TYPE                =    RefPRP.TYPE_PRODUIT
      And (
             Placement.PRODUCT_TYPE = 'SO'
        or ( Placement.PRODUCT_TYPE = 'OT' and Placement.EXTERNAL_PRODUCT_ID = RefPRP.EXT_PRODUCT_ID )
      )      
      And  Coalesce(Placement.EXTERNAL_PRODUCT_ID_SEC,'ND')    =    RefPRP.EXT_PRODUCT_ID_SEC
      And Periode.PERIODE_ID                    =    RefPRP.PERIODE_ID
Where                                      1    =    1
     And Placement.ORDER_DEPOSIT_DT       >= (Current_date - ${P_PIL_523}) 

;                          
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_PRP_CALC_C;
.if errorcode <> 0 then .quit 1

.quit 0

