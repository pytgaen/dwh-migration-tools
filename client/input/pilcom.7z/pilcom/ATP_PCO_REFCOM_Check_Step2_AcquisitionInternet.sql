 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_MigrationInternet.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des migrations Internet
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000

Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD_ACQ (
  ORDER_EXTERNAL_ID         Varchar(20)         Not Null  
)
Primary Index (
  ORDER_EXTERNAL_ID     
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1



Insert Into ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD_ACQ
(
  ORDER_EXTERNAL_ID     
)
Select
  Int1.ORDER_EXTERNAL_ID                                  As ORDER_EXTERNAL_ID      
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int1
Where
  (1=1)
  And Int1.ORDER_OPER_ID                = 'CREAT'
  And Int1.ORDER_DEPOSIT_DT             >= Current_Date - 30
  --Il faut que les migrations soit en dehors de Maintient idientifiant et access
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int3
      Where
        (1=1)
        And Int1.ORDER_EXTERNAL_ID    = Int3.ORDER_EXTERNAL_ID
        And Int3.ORDER_DEPOSIT_DT     >= Current_Date - 30
        And Int3.ACT_PRODUCT_ID_FINAL in (
                                            Select
                                              PRODUCT_ID
                                            From
                                              ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OPENCAT
                                            Where
                                              (1=1)
                                              And CURRENT_IN      =1
                                              And FRESH_IN        =1
                                              And CLOSURE_DT      is null
                                              And COMPST_OFFR_ID  in ('OC50000000008','OC50000000080')
                                              And ATOMIC_OFFR_ID  Is Null
                                              And FUNCTN_ID       Is Null
                                              And FUNCTN_VALUE_ID Is Null
                                              And PERIODE_ID      = (Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
                                          )
    )
  --Il ne faut pas avoir une migration RMV -> ADD de qualifier pour cette commande
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int2
      Where
        (1=1)
        And Int1.ORDER_EXTERNAL_ID            = Int2.ORDER_EXTERNAL_ID
        And Int2.ORDER_DEPOSIT_DT             >= Current_Date - 30
        And Int2.ACT_TYPE_SERVICE_FINAL       In ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX','ACCRTC')
        And Int2.ACT_SEG_COM_ID_FINAL         Not In ('NS')
      )
Group by
  Int1.ORDER_EXTERNAL_ID
;
.if errorcode <> 0 Then .quit 1


Collect Stat On ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD_ACQ Column(ORDER_EXTERNAL_ID);
.if errorcode <> 0 Then .quit 1

-------------------
--Aucune offre trouvée dans la commande 
------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  4                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  'Aucune Offre paramétrée pour une acquisition sur l offre Internet ) ; ( '
        ||Coalesce(Trim(Tmp.COMPST_OFFR_ID),'')
        ||' - '
        ||Coalesce(Trim(Tmp.COMPST_OFFR_DS),'')
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Tmp.ORDER_DEPOSIT_DT)                                     As DateMinRecue           ,
  Max(Tmp.ORDER_DEPOSIT_DT)                                     As DateMaxRecue           
From
  (
    Select
      Commande.ORDER_STATUS_CD            as ORDER_STATUS_CD            ,
      Commande.ORDER_DEPOSIT_DT           as ORDER_DEPOSIT_DT           ,
      Commande.COMPST_OFFR_ID             as COMPST_OFFR_ID             ,
      Commande.COMPST_OFFR_DS             as COMPST_OFFR_DS             
    From
      ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD_ACQ RefId
      Inner Join ${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM Commande
        On    RefId.ORDER_EXTERNAL_ID     = Commande.EXTERNAL_ORDER_ID
    Where
      (1=1)
    Qualify Row_Number() Over (Partition By Commande.EXTERNAL_ORDER_ID Order by Commande.ORDER_STATUS_CD Desc)=1
  )Tmp
Group by  4
;
.if errorcode <> 0 Then .quit 1


-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
