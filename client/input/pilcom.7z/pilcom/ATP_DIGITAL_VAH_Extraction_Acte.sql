
--$HEADER:   %HEADER%
--------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DIGITAL_VAH_Extraction_Acte.sql  $                                  
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL  de la source Digital des actes VAH dans la table ORD_W_EXTRACT_VAH_DIGITAL
--------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 19/07/2019     GRH         CREATION             
---------------------------------------------------------------------------------

.set width 5000

-----------------------------------------
-- Table : ORD_W_EXTRACT_VAH_DIGITAL-----
-----------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_EXTRACT_VAH_DIGITAL;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_W_EXTRACT_VAH_DIGITAL
(
  ACTE_ID                       ,
  ACT_DT                        ,
  INTRNL_SOURCE_ID              ,
  SOURCE_DS                     ,
  ACT_ACTE_FAMILLE_KPI          ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PID_ID                    ,
  PAR_CID_ID                    ,
  UNIFIED_SHOP_CD               ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS           
)
Select
  VAH.ACTE_ID_GEN                                                          As ACTE_ID                         ,
  VAH.ORDER_DEPOSIT_DT                                                     As ACT_DT                          ,
  VAH.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID                ,
  'VAH'                                                                    As SOURCE_DS                       ,
  VAH.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI            ,
  VAH.PAR_UNIFIED_PARTY_ID                                                 As PAR_UNIFIED_PARTY_ID            ,
  VAH.PAR_PID_ID                                                           As PAR_PID_ID                      ,
  VAH.PAR_CID_ID                                                           As PAR_CID_ID                      ,
  Null                                                                     As UNIFIED_SHOP_CD                 ,
  VAH.ORG_REM_CHANNEL_CD                                                   As ORG_REM_CHANNEL_CD              ,
  VAH.ORG_CHANNEL_CD                                                       As ORG_CHANNEL_CD                  ,
  VAH.ORG_SUB_CHANNEL_CD                                                   As ORG_SUB_CHANNEL_CD              ,
  VAH.ORG_SUB_SUB_CHANNEL_CD                                               As ORG_SUB_SUB_CHANNEL_CD          ,
  VAH.ORG_GT_ACTIVITY                                                      As ORG_GT_ACTIVITY                 ,
  VAH.ORG_FIDELISATION                                                     As ORG_FIDELISATION                ,
  VAH.ORG_WEB_ACTIVITY                                                     As ORG_WEB_ACTIVITY                ,
  VAH.ORG_AUTO_ACTIVITY                                                    As ORG_AUTO_ACTIVITY               ,
  VAH.ORG_EDO_ID                                                           As ORG_EDO_ID                      ,
  VAH.ORG_TYPE_EDO                                                         As ORG_TYPE_EDO                    ,
  Trim(VAH.ORG_TEAM_LEVEL_1_CD)                                            As ORG_TEAM_LEVEL_1_CD             ,
  Trim(VAH.ORG_TEAM_LEVEL_1_DS)                                            As ORG_TEAM_LEVEL_1_DS             ,
  Trim(VAH.ORG_TEAM_LEVEL_2_CD)                                            As ORG_TEAM_LEVEL_2_CD             ,
  Trim(VAH.ORG_TEAM_LEVEL_2_DS)                                            As ORG_TEAM_LEVEL_2_DS             ,
  Trim(VAH.ORG_TEAM_LEVEL_3_CD)                                            As ORG_TEAM_LEVEL_3_CD             ,
  Trim(VAH.ORG_TEAM_LEVEL_3_DS)                                            As ORG_TEAM_LEVEL_3_DS             ,
  Trim(VAH.ORG_TEAM_LEVEL_4_CD)                                            As ORG_TEAM_LEVEL_4_CD             ,
  Trim(VAH.ORG_TEAM_LEVEL_4_DS)                                            As ORG_TEAM_LEVEL_4_DS             ,
  Trim(VAH.WORK_TEAM_LEVEL_1_CD)                                           As WORK_TEAM_LEVEL_1_CD            ,
  Trim(VAH.WORK_TEAM_LEVEL_1_DS)                                           As WORK_TEAM_LEVEL_1_DS            ,
  Trim(VAH.WORK_TEAM_LEVEL_2_CD)                                           As WORK_TEAM_LEVEL_2_CD            ,
  Trim(VAH.WORK_TEAM_LEVEL_2_DS)                                           As WORK_TEAM_LEVEL_2_DS            ,
  Trim(VAH.WORK_TEAM_LEVEL_3_CD)                                           As WORK_TEAM_LEVEL_3_CD            ,
  Trim(VAH.WORK_TEAM_LEVEL_3_DS)                                           As WORK_TEAM_LEVEL_3_DS            ,
  Trim(VAH.WORK_TEAM_LEVEL_4_CD)                                           As WORK_TEAM_LEVEL_4_CD            ,
  Trim(VAH.WORK_TEAM_LEVEL_4_DS)                                           As WORK_TEAM_LEVEL_4_DS
From ${KNB_PCO_VM}.V_ORD_F_ACTE_VAH As VAH
Where (1=1)
  And Substr(VAH.ACT_CD,1,3)      Not In (${L_PIL_036})
  And VAH.ACT_SEG_COM_ID_FINAL    <>      '${P_PIL_295}'
  And VAH.ACT_CD                  <>      '${P_PIL_067}'
  And VAH.ORDER_DEPOSIT_DT        >       '20130402'
  And VAH.HOT_IN                  =       0
  And VAH.ORDER_DEPOSIT_DT        >= Current_date - 250
  And VAH.ORG_CHANNEL_CD        IN ('Online','DNU')
  And VAH.ORDER_DEPOSIT_DT        >= '${P_PIL_518}'
  And ((VAH.LAST_MODIF_TS         >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' 
        And VAH.LAST_MODIF_TS  <=  '${KNB_PILCOM_EXTRACT_BORNE_MAX}'
        )  
       or VAH.ORDER_DEPOSIT_DT > Current_date - 10
       )
;

.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_W_EXTRACT_VAH_DIGITAL;
 if errorcode <> 0 then .quit 1;