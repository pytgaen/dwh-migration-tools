-- $HEADER: mm2pco/current/sql/ATP_PCO_Alimentation_Calcul_PLACEMENT_VAD.sql 13_05#8 11-OCT-2018 17:19:13 LXQG9925
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_PCO_Alimentation_Calcul_PLACEMENT_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table COM_T_CALCUL_PL_VAD
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     GMA         Création
-- 06/02/2014     AID         Indus
-- 22/09/2014     HZO         Modification : Perform
-- 05/01/2015     MDE         Evol: ajout TARIF_HT
-- 24/03/2016     OCH         Ajout BCR_ID
-- 05/10/2018     LMU         Ajout champs VAD Mobile (RS lot 2)
-- 17/06/2020     TCL         Ajout du champ NSCE pour les KPI ESIM
---------------------------------------------------------------------------------

.set width 2000;


--Selection des lignes de VAD :


--Delete de la table TMP :

Delete from ${KNB_PCO_TMP}.COM_T_CALCUL_PL_VAD All;
.if errorcode <> 0 then .quit 1


--------------------------------------------------------------------------------------
-- Etape 1 : On cherche les différentes commandes :
--------------------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.LIST_ID_TO_CALC_VAD (
  CDE_REFERENCE       Varchar(20)             Not null  ,
  DOSSIER_NU          Char(10)                Not null  ,
  CLIENT_NU           Char(10)                Not null  ,
  DATE_SAISIE         Date Format 'YYYYMMDD'  Not null  
)
Primary Index (
  DOSSIER_NU,
  CLIENT_NU
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1



Insert into ${KNB_TERADATA_USER}.LIST_ID_TO_CALC_VAD
(
  CDE_REFERENCE       ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  DATE_SAISIE         
)
Select
  CDE_REFERENCE       ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  DATE_SAISIE         
From
  ${KNB_PCO_TMP}.PLACEMENT_VAD_PRECALC
Where
  DOSSIER_NU Is not Null and CLIENT_NU Is not Null
Group by
  CDE_REFERENCE       ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  DATE_SAISIE         
;
.if errorcode <> 0 then .quit 1




--------------------------------------------------------------------------------------
-- Etape 1 : On réalise l'enrichissement de presfac_co + l'enrichissement ND/BSS
--------------------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.ENRICHI_CALC_VAD (
  CDE_REFERENCE       Varchar(20)             Not null  ,
  DOSSIER_NU          Char(10)                Not null  ,
  CLIENT_NU           Char(10)                Not null  ,
  DATE_SAISIE         Date Format 'YYYYMMDD'  Not null  ,
  PRESFACT_CO         Char(5)                           ,
  AID                 Char(10)                          ,
  ND                  Char(10)                          
)
Primary Index (
  CDE_REFERENCE
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1




Insert into ${KNB_TERADATA_USER}.ENRICHI_CALC_VAD
(
  CDE_REFERENCE       ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  DATE_SAISIE         ,
  PRESFACT_CO         ,
  AID                 ,
  ND                  
)
Select
  RefId.CDE_REFERENCE         as CDE_REFERENCE  ,
  RefId.DOSSIER_NU            as DOSSIER_NU     ,
  RefId.CLIENT_NU             as CLIENT_NU      ,
  RefId.DATE_SAISIE           as DATE_SAISIE    ,
  Prestation.PRESFACT_CO_FORM as PRESFACT_CO    ,
  Srv.AID                     as AID            ,
  Srv.ND                      as ND             
From
  ${KNB_TERADATA_USER}.LIST_ID_TO_CALC_VAD RefId
  Left Outer Join
  (
    Select
      Tf.SRVTECH_DOSSIER_NU,
      Tf.SRVTECH_CLIENT_NU,
      Max(Case When Tf.SRVTECH_CO_SERVBASE='${P_PIL_060}' Then substr(Trim(Tf.SRVTECH_NU_TEL),2,Character_Length(Tf.SRVTECH_NU_TEL)-1) Else Null End) as AID,
      Max(Case When Tf.SRVTECH_CO_SERVBASE='${P_PIL_061}' Then Trim(Tf.SRVTECH_NU_TEL) Else Null End) as ND
    From ${KNB_IBU_SOC_V}.TFSRVTECH Tf
    Where Tf.SRVTECH_CO_SERVBASE In ('${P_PIL_061}','${P_PIL_060}')
      And Tf.SRVTECH_PLTF_CO not In ('${P_PIL_062}','${P_PIL_063}')
      And Tf.SRVTECH_IN_SRV_ACTIF = '${P_PIL_064}'
    Group By Tf.SRVTECH_DOSSIER_NU,Tf.SRVTECH_CLIENT_NU
  )  Srv
  On    RefId.DOSSIER_NU = Srv.SRVTECH_DOSSIER_NU
    And RefId.CLIENT_NU  = Srv.SRVTECH_CLIENT_NU
  Left Outer Join ${KNB_IBU_SOC_V}.VF_TFSRVFCDOS ParcADV
    On    RefId.DOSSIER_NU  = ParcADV.SRVFCDOS_DOSSIER_NU
      And RefId.CLIENT_NU   = ParcADV.SRVFCDOS_CLIENT_NU
      And RefId.DATE_SAISIE >= ParcADV.SRVFCDOS_DT_DEBUT
      And RefId.DATE_SAISIE <= coalesce(ParcADV.SRVFCDOS_DT_FIN,ParcADV.SRVFCDOS_DT_FIN_FACT)
      And ParcADV.CLOSURE_DT is null
  Left Outer Join ${KNB_IBU_SOC_V}.VF_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO  = Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT    = 'O'
      And Prestation.CURRENT_IN         = 1
Qualify row_number() over (partition by RefId.CDE_REFERENCE order by coalesce(ParcADV.SRVFCDOS_DT_FIN,ParcADV.SRVFCDOS_DT_FIN_FACT) desc, ParcADV.SRVFCDOS_DT_DEBUT desc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1
;
.if errorcode <> 0 then .quit 1



--On fait la fusion dans la table :
-------------------------------------


Insert into ${KNB_PCO_TMP}.COM_T_CALCUL_PL_VAD
(
  EXTERNAL_ACTE_ID    ,
  TYPE_SOURCE_ID      , 
  PLACEMENT_ID_EXT    ,
  APPLI_SOURCE_ID     ,
  CDE_REFERENCE       ,
  DATE_SAISIE         ,
  DATE_SAISIE_TS      ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  PRESFACT_CO_COM     ,
  PRESFACT_CO_PREC    ,
  USCM_CO             ,
  PDV                 ,
  STATUT_CDE          ,
  DUREE_ENGAGEMENT    ,
  TYPE_DUR_ENGAGEMENT ,
  TYPE_LIG_CDE        ,
  CDE_LIG_ID          ,
  EXT_PRODUCT_ID      ,
  PRIX_HT             ,
  DATEVALIDATION      ,
  DATE_DECLA_SACHEM   ,
  DATE_LIVRAISON      ,
  NUMEROIMEI          ,
  NSCE                ,
  CODEVENDEUR         ,
  EAN_FTT             ,
  CODE_TAC            ,
  TERM_PERFORM_IND    ,
  CODEVENDEUR_MOD     ,
  STATUT_CLOS         ,
  STATUT_ANNUL        ,
  AID                 ,
  ND                  ,
  TYPPROD_CO          ,
  BCR_ID              ,
  TARIF_HT            ,
  RCS_IN              , -- RCS
  RCS_MOTIF_ID        , -- RCS
  RCS_CODE_ADV_MOTIF    -- RCS
  
)
Select
  IdVad.PLACEMENT_ID_EXT    as EXTERNAL_ACTE_ID     ,
  ${TYPE_SOURCE_ID}         as TYPE_SOURCE_ID       ,
  IdVad.PLACEMENT_ID_EXT    as PLACEMENT_ID_EXT     ,
  IdVad.APPLI_SOURCE_ID     as APPLI_SOURCE_ID      ,
  IdVad.CDE_REFERENCE       as CDE_REFERENCE        ,
  IdVad.DATE_SAISIE         as DATE_SAISIE          ,
  IdVad.DATE_SAISIE_TS      as DATE_SAISIE_TS       ,
  IdVad.DOSSIER_NU          as DOSSIER_NU           ,
  IdVad.CLIENT_NU           as CLIENT_NU            ,
  IdVad.PRESFACT_CO_COM     as PRESFACT_CO_COM      ,
  RefEnri.PRESFACT_CO       as PRESFACT_CO_PREC     ,
  IdVad.USCM_CO             as USCM_CO              ,
  IdVad.PDV                 as PDV                  ,
  IdVad.STATUT_CDE          as STATUT_CDE           ,
  IdVad.DUREE_ENGAGEMENT    as DUREE_ENGAGEMENT     ,
  IdVad.TYPE_DUR_ENGAGEMENT as TYPE_DUR_ENGAGEMENT  ,
  IdVad.TYPE_LIG_CDE        as TYPE_LIG_CDE         ,
  IdVad.CDE_LIG_ID          as CDE_LIG_ID           ,
  IdVad.EXT_PRODUCT_ID      as EXT_PRODUCT_ID       ,
  IdVad.PRIX_HT             as PRIX_HT              ,
  IdVad.DATEVALIDATION      as DATEVALIDATION       ,
  IdVad.DATE_DECLA_SACHEM   as DATE_DECLA_SACHEM    ,
  IdVad.DATE_LIVRAISON      as DATE_LIVRAISON       ,
  IdVad.NUMEROIMEI          as NUMEROIMEI           ,
  IdVad.NSCE                as NSCE                 ,
  IdVad.CODEVENDEUR         as CODEVENDEUR          ,
  IdVad.EAN_FTT             as EAN_FTT              ,
  IdVad.CODE_TAC            as CODE_TAC             ,
  IdVad.TERM_PERFORM_IND    as TERM_PERFORM_IND     ,--Flag Perform
  IdVad.CODEVENDEUR_MOD     as CODEVENDEUR_MOD      ,
  IdVad.STATUT_CLOS         as STATUT_CLOS          ,
  IdVad.STATUT_ANNUL        as STATUT_ANNUL         ,
  RefEnri.AID               as AID                  ,
  RefEnri.ND                as ND                   ,
  IdVad.TYPPROD_CO          as TYPPROD_CO           ,
  IdVad.BCR_ID              as BCR_ID               ,
  IdVad.TARIF_HT            as TARIF_HT             ,
  IdVad.RCS_IN              as RCS_IN               ,
  IdVad.RCS_MOTIF_ID        as RCS_MOTIF_ID         ,
  IdVad.RCS_CODE_ADV_MOTIF  as RCS_CODE_ADV_MOTIF

From
  ${KNB_PCO_TMP}.PLACEMENT_VAD_PRECALC IdVad
  Left Outer Join ${KNB_TERADATA_USER}.ENRICHI_CALC_VAD RefEnri
    On IdVad.CDE_REFERENCE=RefEnri.CDE_REFERENCE
;
.if errorcode <> 0 then .quit 1

.quit 0

