-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Cold_Alimentation_Step4_Enrichissement_EngagementPrecedant.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  d'enrichissement de l'engagement précédant pour le placement SOFT
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------


.set width 2000;



----------------------------------------------------------------------------------------------
-- Etape 1 : Calcul de l'engagement en parc avant le dépot de la commande                 ----
----------------------------------------------------------------------------------------------

--Selection des commande que l'on peut enrichir
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_SOFT_REF32RPARC (
  EXTERNAL_ORDER_ID                           Varchar(19)             Not Null    ,
  ORDER_DEPOSIT_DT                            Date format 'YYYYMMDD'  Not Null    ,
  PARSIFAL_PARC_ID                            Varchar(128)            Not Null    
)
Primary Index (
  PARSIFAL_PARC_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

--Identification de la dernieres commande reçues
Insert into ${KNB_TERADATA_USER}.ORD_V_SOFT_REF32RPARC
(
  EXTERNAL_ORDER_ID             ,
  ORDER_DEPOSIT_DT              ,
  PARSIFAL_PARC_ID              
)
Select
  Commande.EXTERNAL_ORDER_ID              as EXTERNAL_ORDER_ID              ,
  Commande.ORDER_DEPOSIT_DT               as ORDER_DEPOSIT_DT               ,
  Commande.PARSIFAL_PARC_ID               as PARSIFAL_PARC_ID               
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_PSFIDP Commande
;
.if errorcode <> 0 then .quit 1

Collect stat On ${KNB_TERADATA_USER}.ORD_V_SOFT_REF32RPARC Column(PARSIFAL_PARC_ID);
.if errorcode <> 0 then .quit 1
Collect stat On ${KNB_TERADATA_USER}.ORD_V_SOFT_REF32RPARC Column(ORDER_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------
--Calcul en parc 
-------------------------------------------------------------





Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENG_PRE all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENG_PRE
(
  EXTERNAL_ORDER_ID     ,
  ORDER_DEPOSIT_DT      ,
  CONTRCT_DT_SIGN_PREC  ,
  CONTRCT_DT_FIN_PREC   
)
Select
  TmpPark.EXTERNAL_ORDER_ID               as EXTERNAL_ORDER_ID              ,
  TmpPark.ORDER_DEPOSIT_DT                as ORDER_DEPOSIT_DT               ,
  Max(TmpPark.CONTRCT_DT_SIGN_PREC)       as CONTRCT_DT_SIGN_PREC           ,
  Max(TmpPark.CONTRCT_DT_FIN_PREC)        as CONTRCT_DT_FIN_PREC            
From
  (
    Select
      RefId.EXTERNAL_ORDER_ID                         as EXTERNAL_ORDER_ID              ,
      RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT               ,
      --La date de début d'engagement
      Case When (Park.FUNCTN_ID='${P_PIL_094}') --FONC50000000004 (Debut Eng)
                Then Cast(Park.SIMPLE_FUNCTN_VALUE_NM as date format 'YYYY-MM-DD')
           Else Null
      End                                             as CONTRCT_DT_SIGN_PREC           ,
      --La date de fin d'engagement
      Case When (Park.FUNCTN_ID='${P_PIL_095}') -- FONC50000000005 (Fin Eng)
                Then Cast(Park.SIMPLE_FUNCTN_VALUE_NM as date format 'YYYY-MM-DD')
           Else Null
      End                                             as CONTRCT_DT_FIN_PREC            
    From
      ${KNB_TERADATA_USER}.ORD_V_SOFT_REF32RPARC  RefId
      Inner Join ${KNB_COM_SOC_V_PRS}.VF_INB_F_PARK Park
        On    RefId.PARSIFAL_PARC_ID        = Park.PARK_EXTRNL_OC_ID -- On requete sur le parc du client
          -- On recupère les attributs que possède le client avant la commande
          And (
                    Park.REALZTN_DT is not null
                And RefId.ORDER_DEPOSIT_DT > Park.REALZTN_DT
              )
          And Park.CURRENT_IN=1
      Inner Join  ${KNB_COM_SOC_V_PRS}.VF_CAT_R_COMMTMNT_PARMTR Param
            On    Park.ATOMIC_OFFR_ID   = Param.ATOMIC_OFFR_ID
              And Param.OFFER_TYPE      = 1 --On ne recupère que les offres engagentes
              And Param.CURRENT_IN      = 1
              And Param.CLOSURE_DT      Is Null
  )TmpPark
Group by
    TmpPark.EXTERNAL_ORDER_ID  ,
    TmpPark.ORDER_DEPOSIT_DT  
;
.if errorcode <> 0 then .quit 1



Collect stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENG_PRE;
.if errorcode <> 0 then .quit 1


.quit 0



