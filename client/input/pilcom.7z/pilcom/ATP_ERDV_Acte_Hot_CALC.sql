-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Acte_Hot_CALC.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table T placement pour ERDV
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/12/2014      YZH         Creation
-- 09/03/2015      YZH         Modifiation
-- 01/06/2015      YZH         Modification
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_ERDV_CALC_H All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

-- Pour les OT
Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_ERDV_CALC_H
(
    ACTE_ID                               ,  
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_DT                      ,
    PERIODE_ID                            ,                            
    PRODUCT_ID_FINAL                      ,
    PRODUCT_DS_FINAL                      ,
    SEG_COM_ID_FINAL                      ,
    SEG_COM_AGG_ID_FINAL                  ,
    TYPE_SERVICE_FINAL                    ,
    TYPE_COMMANDE_ID                                                                       
)
Select                                                                                                    
    Placement.ACTE_ID                                                                                        as ACTE_ID                    ,
    Placement.EXTERNAL_ORDER_ID                                                                              as EXTERNAL_ORDER_ID          ,
    Placement.ORDER_DEPOSIT_DT                                                                               as ORDER_DEPOSIT_DT           ,
    Periode.PERIODE_ID                                                                                       as PERIODE_ID                 ,
    Coalesce(RefERDV.PRODUCT_ID, '${P_PIL_021}')                                                             as PRODUCT_ID_FINAL           ,
    Coalesce(RefERDV.PRODUCT_DS, '${P_PIL_021}')                                                             as PRODUCT_DS_FINAL           ,
    Coalesce(RefERDV.SEG_COM_ID, '${P_PIL_022}')                                                             as SEG_COM_ID_FINAL           ,
    Coalesce(RefERDV.SEG_COM_AGG_ID, '${P_PIL_024}')                                                         as SEG_COM_AGG_ID_FINAL       ,
    RefERDV.TYPE_SERVICE                                                                                     as TYPE_SERVICE_FINAL         ,
    '${P_PIL_026}'                                                                                           as TYPE_COMMANDE_ID        --ACQ                                                                         
From  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_ERDV_H Placement
Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Periode
      On  Placement.ORDER_DEPOSIT_DT           >=    Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT           <=    Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                      =    1
      And Periode.CURRENT_IN                    =    1
      And Periode.CLOSURE_DT                    Is Null
Left Outer Join  ${KNB_PCO_TMP}.CAT_W_ERDV_REFCOM_JOUR RefERDV
      On  Placement.REF_OFFRE_CIBLE_CD         =    RefERDV.EXT_PRODUCT_ID_3 -- Code Prestation      
      And Case When Placement.CATALOGUE_CD Like '%MET%' Then 'MET'  
            Else Placement.CATALOGUE_CD 
          End                                  =    RefERDV.EXT_PRODUCT_ID_5 -- Type Catalogue
      And Periode.PERIODE_ID                   =    RefERDV.PERIODE_ID
Where                                      1   =    1

;                          
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_W_ACTE_ERDV_CALC_H;
.if errorcode <> 0 then .quit 1

.quit 0

