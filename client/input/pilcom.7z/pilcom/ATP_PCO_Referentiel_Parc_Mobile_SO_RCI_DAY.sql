-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_Referentiel_Parc_Mobile_SO_RCI_DAY.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de mise a plat du parc mobile sur le segment refcom pour les OT
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 04/09/2014      HFO         Correction QC 657
-- 02/07/2015      GMA         Modification Pour ajouter le Delete Insert En MS
-- 03/06/2016      MDE         Modif / REFCOM KNB_PCO_REFCOM 
-- 03/02/2020      EVI         PILCOM-256 : Optimisation Requete
--------------------------------------------------------------------------------

.set width 2500;

-----------------------------------------------------------------------------------------------------------------------------
-- Etape 1 On extrait le Parc RCI :
-----------------------------------------------------------------------------------------------------------------------------

--Drop Table ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_OT ;
--.if ErrorCode <> 0 Then .Quit 1;

--Delete :
-----------------------------
Delete from ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO_TRT All;
.if ErrorCode <> 0 Then .Quit 1;


--Pérennité sur les option Dossier :
Insert into ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO_TRT
(
  DOSSIER_NU_IMSI       ,
  DOSSIER_NU            ,
  CLIENT_NU             ,
  PRESFACT_CO           ,
  PRESFACT_CO_FORM      ,
  TYPE_PRODUIT          ,
  BEGIN_DT              ,
  END_DT                
)
Select
  Dossier.DOSSIER_NU_IMSI                                                         as DOSSIER_NU_IMSI_T      ,
  --Couple Client Dossier Parc
  ParcADV.SRVFCDOS_DOSSIER_NU                                                     as DOSSIER_NU_T           ,
  ParcADV.SRVFCDOS_CLIENT_NU                                                      as CLIENT_NU_T            ,
  --Code ADV de la prestation :
  ParcADV.SRVFCDOS_PRESFACT_CO                                                    as PRESFACT_CO_T          ,
  --Code AGAP du produit :
  ServOpt.SERVOPT_CO                                                              as PRESFACT_CO_FORM_T     ,
  'SO'                                                                            as TYPE_PRODUIT_T         ,
  --Date de fin de parc
  ParcADV.SRVFCDOS_DT_DEBUT                                                       as BEGIN_DT_T             ,
  --Date début Parc
  case when  ParcADV.SRVFCDOS_DT_FIN <= ParcADV.SRVFCDOS_DT_DEBUT
          Then ParcADV.SRVFCDOS_DT_DEBUT
       Else  Coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('29991231' as date format 'YYYYMMDD'))    
  End                                                                             as END_DT_T               
From
  ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
  --On va ensuite Dans la table des Prestation pour récupérer le code ADV
  Inner Join ${KNB_IBU_SOC}.V_TDSERVOPT ServOpt
    On    ParcADV.SRVFCDOS_PRESFACT_CO      = ServOpt.SERVOPT_CO_PREST_ABONN
      And ServOpt.CURRENT_IN                = 1
  Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER  Dossier
    On    ParcADV.SRVFCDOS_DOSSIER_NU     = Dossier.DOSSIER_NU
      And ParcADV.SRVFCDOS_CLIENT_NU      = Dossier.DOSSIER_CLIENT_NU
Where
  (1=1)
  And Dossier.DOSSIER_NU_IMSI   Is Not Null
Group By DOSSIER_NU_IMSI_T, DOSSIER_NU_T, CLIENT_NU_T, PRESFACT_CO_T, PRESFACT_CO_FORM_T, TYPE_PRODUIT_T, BEGIN_DT_T, END_DT_T
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO_TRT ;
.if ErrorCode <> 0 Then .Quit 1;




-----------------------------------------------------------------------------------------------------------------------------
-- Etape 2 On calcul le segment sur les produits externes 
-----------------------------------------------------------------------------------------------------------------------------

Create Volatile Table ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_SO (
  TYPE_PRODUIT          Char(2)         Not Null      ,
  PRESFACT_CO_FORM      Varchar(20)     Not Null      ,
  SEG_COM_ID            Varchar(64)     Not Null      ,
  TYPE_SERVICE          Varchar(20)                   ,
  BEGIN_DT              Date Format 'YYYYMMDD'        ,
  END_DT                Date Format 'YYYYMMDD'        
)
Primary Index(
  TYPE_PRODUIT          ,
  PRESFACT_CO_FORM      
)
On Commit Preserve Rows
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_SO Column(TYPE_PRODUIT,PRESFACT_CO_FORM);
.if ErrorCode <> 0 Then .Quit 1;




Insert Into ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_SO
(
  TYPE_PRODUIT          ,
  PRESFACT_CO_FORM      ,
  SEG_COM_ID            ,
  TYPE_SERVICE          ,
  BEGIN_DT              ,
  END_DT                
)
Select
  Case  When ProdAgap.TYPE_PRODUIT = 'OT'
          Then  'OT'
        Else    'SO'
  End                                                                           as TYPE_PRODUIT         ,
  ProdAgap.EXT_PRODUCT_ID1                                                      as PRESFACT_CO_FORM     ,
  Seg.SEG_COM_ID                                                                as SEG_COM_ID           ,
  Seg.TYPE_SERVICE                                                              as TYPE_SERVICE         ,
  Coalesce(ProdAgap.DATE_DEBUT, Cast('19000101' as Date format 'YYYYMMDD'))     as BEGIN_DT             ,
  Coalesce(ProdAgap.DATE_FIN, Cast('29991231' as Date format 'YYYYMMDD'))       as END_DT               
From
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP ProdAgap
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM Seg
    On    ProdAgap.PERIODE_ID     = Seg.PERIODE_ID
      And ProdAgap.PRODUCT_ID     = Seg.PRODUCT_ID
      And Seg.CURRENT_IN          = 1
      And Seg.CLOSURE_DT          Is Null
Where
  (1=1)
  And ProdAgap.CURRENT_IN  = 1
  And ProdAgap.CLOSURE_DT  Is Null
Qualify Row_Number() Over (Partition By 
                                        ProdAgap.EXT_PRODUCT_ID1                    ,
                                        Case  When ProdAgap.TYPE_PRODUIT = 'OT'
                                                Then  'OT'
                                              Else    'SO'
                                        End
                            Order by Seg.PERIODE_ID Desc
                          )=1
;
.if ErrorCode <> 0 Then .Quit 1;




Collect Stat On  ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_SO Column(TYPE_PRODUIT,PRESFACT_CO_FORM);
.if ErrorCode <> 0 Then .Quit 1;

  
Delete  From ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO
;Insert Into ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO
(
  DOSSIER_NU_IMSI       ,
  SEG_COM_ID            ,
  TYPE_SERVICE          ,
  PARC_BEGIN_DT         ,
  PARC_END_DT           ,
  COM_BEGIN_DT          ,
  COM_END_DT            
)
Select
  RefParc.DOSSIER_NU_IMSI               as DOSSIER_NU_IMSI      ,
  CatRefCom.SEG_COM_ID                  as SEG_COM_ID           ,
  CatRefCom.TYPE_SERVICE                as TYPE_SERVICE         ,
  RefParc.BEGIN_DT                      as PARC_BEGIN_DT        ,
  RefParc.END_DT                        as PARC_END_DT          ,
  CatRefCom.BEGIN_DT                    as COM_BEGIN_DT         ,
  CatRefCom.END_DT                      as COM_END_DT           
From
  ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO_TRT RefParc
  Inner Join ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_SO CatRefCom
    On    RefParc.PRESFACT_CO_FORM        = CatRefCom.PRESFACT_CO_FORM
      And RefParc.TYPE_PRODUIT            = CatRefCom.TYPE_PRODUIT
Where
  (1=1)
  And CatRefCom.SEG_COM_ID              Not In ('NS','OPTTECH','OPT_INC')
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO;
.if ErrorCode <> 0 Then .Quit 1;


--On purge les tables volatiles :

Drop table ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_SO;
.if ErrorCode <> 0 Then .Quit 1;

Delete From ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO_TRT;
.if ErrorCode <> 0 Then .Quit 1;

-----------------------------------------------------------------------------------------------------------------------------
-- Etape 4 : On fait la Fusion et lissage du parc RCI sur le segment
-----------------------------------------------------------------------------------------------------------------------------



Delete From  ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO
;Insert into ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO
(
  DOSSIER_NU_IMSI     ,
  SEG_COM_ID          ,
  TYPE_SERVICE        ,
  PARC_BEGIN_DT       ,
  PARC_END_DT         ,
  COM_BEGIN_DT        ,
  COM_END_DT          
)
Select
  tmp.DOSSIER_NU_IMSI       as DOSSIER_NU_IMSI        ,
  tmp.SEG_COM_ID            as SEG_COM_ID             ,
  tmp.TYPE_SERVICE          as TYPE_SERVICE           ,
  tmp.PARC_BEGIN_DT         as PARC_BEGIN_DT          ,
  Case
    When TO_BE_MERGED=1
      Then
        -- lignes à fusionner avec la suivante, on prend la prochaine D_FIN (correspond à la D_FIN des lignes flag 2)
        Min(tmp.PARC_END_DT) over (Partition By tmp.DOSSIER_NU_IMSI,tmp.SEG_COM_ID  Order By tmp.PARC_BEGIN_DT Rows Between 1 following and 1 following)
      Else
        -- lignes uniques ou à fusionner avec la précédente, on conserve BORNE_SUP
        tmp.PARC_END_DT
  end                       as PARC_END_DT            ,
  tmp.COM_BEGIN_DT          as COM_BEGIN_DT           ,
  tmp.COM_END_DT            as COM_END_DT             
From
  (
    select
      RefRCIOTSeg.DOSSIER_NU_IMSI     as DOSSIER_NU_IMSI        ,
      RefRCIOTSeg.SEG_COM_ID          as SEG_COM_ID             ,
      RefRCIOTSeg.TYPE_SERVICE        as TYPE_SERVICE           ,
      RefRCIOTSeg.PARC_BEGIN_DT       as PARC_BEGIN_DT          ,
      RefRCIOTSeg.PARC_END_DT         as PARC_END_DT            ,
      RefRCIOTSeg.COM_BEGIN_DT        as COM_BEGIN_DT           ,
      RefRCIOTSeg.COM_END_DT          as COM_END_DT             ,
       -- qualification des lignes devant être fusionnées avec les suivantes (flag 1)
           Case
                  When Min(RefRCIOTSeg.PARC_BEGIN_DT) Over (Partition by    RefRCIOTSeg.DOSSIER_NU_IMSI ,
                                                                            RefRCIOTSeg.SEG_COM_ID      
                                                          order by          RefRCIOTSeg.PARC_BEGIN_DT rows between 1 following and 1 following 
                                                      ) <=  (RefRCIOTSeg.PARC_END_DT + 1)
             Then 1 else 0
           End
           +
       -- qualification des lignes devant être fusionnées avec les précédentes (flag 2)
           Case
                When Max(RefRCIOTSeg.PARC_END_DT) Over (Partition by        RefRCIOTSeg.DOSSIER_NU_IMSI ,
                                                                            RefRCIOTSeg.SEG_COM_ID      
                                                          order by          RefRCIOTSeg.PARC_BEGIN_DT rows between 1 preceding and 1 preceding 
                                                      ) >=  (RefRCIOTSeg.PARC_BEGIN_DT - 1)
           then 2 else 0
       -- lignes devant être fusionnées avec les précédentes et les suivantes on un flag 3 (1+2)
           end as TO_BE_MERGED
    from
      (
        Select
          RefParcOT.DOSSIER_NU_IMSI           as DOSSIER_NU_IMSI        ,
          RefParcOT.SEG_COM_ID                as SEG_COM_ID             ,
          RefParcOT.TYPE_SERVICE              as TYPE_SERVICE           ,
          RefParcOT.PARC_BEGIN_DT             as PARC_BEGIN_DT          ,
          RefParcOT.PARC_END_DT               as PARC_END_DT            ,
          RefParcOT.COM_BEGIN_DT              as COM_BEGIN_DT           ,
          RefParcOT.COM_END_DT                as COM_END_DT             
        From
          ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SO RefParcOT
        Qualify Row_Number() Over (Partition By RefParcOT.DOSSIER_NU_IMSI, RefParcOT.SEG_COM_ID, RefParcOT.PARC_BEGIN_DT Order by RefParcOT.PARC_BEGIN_DT Desc, RefParcOT.PARC_END_DT Desc) = 1
      ) RefRCIOTSeg
    Qualify TO_BE_MERGED <> 3
  ) tmp
-- on ne conserve que les lignes uniques et celles fusionnées avec la suivante uniquement
Qualify TO_BE_MERGED in (0,1)
;
.if ErrorCode <> 0 Then .Quit 1;


Collect Stat On ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO;
.if ErrorCode <> 0 Then .Quit 1;



.quit 0


