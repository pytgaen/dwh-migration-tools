--$HEADER:   mm2pco/current/sql/ATP_COE_Acte_Alimentation_Step2_PreCalcul.sql 13_05#5 30-AVR-2019 15:30:04 NNGS2043
-------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_COE_Acte_Alimentation_Step2_PreCalcul.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 17/10/2018      HOB         Creation
-- 20/11/2018      JCR         Modif pour type de commande
-- 04/12/2018      JCR         Modif pour gérer les erreurs (passage en left)
--------------------------------------------------------------------------------

.set width 2000;




-- **************************************************************
-- Alimentation de la table ORD_W_ACTE_MATREFCOM_COE Catalogue OEE --Ca doit générer INIT/REA
-- **************************************************************

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_COE all;
.if errorcode <> 0 then .quit 1
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_COE
(  
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  ORDR_TYP_CD                   ,
  PRODUCT_ID_FINAL              ,
  PERIODE_ID                    ,
  TYPE_COMMANDE_ID              ,
  SEG_COM_ID_FINAL              ,
  TYPE_SERVICE_FINAL            ,
  ACT_ID                        ,
  ACTE_REM_ID                   ,
  FLAG_ACT_REM                  ,
  FLAG_PEC_PERPVC               ,
  ACTE_VALO                     ,
  ACTE_FAMILLE_KPI              ,
  TAUX_MARGE                    

)
Select
  Placement.ACTE_ID                                                      as ACTE_ID                                ,
  Placement.ORDER_DEPOSIT_DT                                             as ORDER_DEPOSIT_DT                       ,
  Placement.ORDR_TYP_CD                                                  as ORDR_TYP_CD                            ,
  Coalesce (OEE.PRODUCT_ID, 'PRODUIT INCONNU')                           as PRODUCT_ID_FINAL                       ,
  Matrice.PERIODE_ID                                                     as PERIODE_ID                             ,
  -- Matrice.TYPE_COMMANDE_ID ACQ/REA/INIT ON DOIT GENERER QUE DU INIT/REA
  TRIM(SUBSTR(ORDR_TYP_CD,1,4 ))                                         as TYPE_COMMANDE_ID_AGR                   ,
  Coalesce (RefSeg.SEG_COM_ID, 'CODECAT INCONNU')                        as SEG_COM_ID_FINAL                       ,
  RefSeg.TYPE_SERVICE                                                    as TYPE_SERVICE_FINAL                     ,
  Coalesce (Matrice.ACTE_ID, 'WAR_PLACEMENT_NON_ELIGIBLE_REFCOM')        as ACT_ID                                 ,
  Coalesce (Acte.ACTE_REM_ID, 'WAR_PLACEMENT_NON_ELIGIBLE_REFCOM')       as ACTE_REM_ID                            ,
  Coalesce (Acte.FLAG_ACT_REM, 'N')                                      as FLAG_ACT_REM                           ,
  Coalesce (Acte.FLAG_PEC_PERPVC, 'N')                                   as FLAG_PEC_PERPVC                        ,
  Coalesce (Acte.ACTE_VALO, 0)                                           as ACTE_VALO                              ,
  Coalesce (Acte.ACTE_FAMILLE_KPI , 'NON PARAM')                         as ACTE_FAMILLE_KPI                       ,
  Coalesce (Acte.TAUX_MARGE, 0)                                          as TAUX_MARGE                              
From
 ${KNB_PCO_TMP}.ORD_W_ACTE_COE_EXT Placement
  Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_REF_PRODUCT_OEE OEE
    On   Placement.EXT_PRODUCT_ID_1        =  OEE.RESOLU_ID
    And  Placement.EXT_PRODUCT_ID_2        =  OEE.CONCLU_ID
    And  Placement.EXT_PRODUCT_ID_3        =  OEE.SSCONCLU_ID
    And  Placement.PERIODE_ID              =  OEE.PERIODE_ID
    And  OEE.CURRENT_IN = 1
    And  OEE.TYPE_PRODUIT                  <> 'NS'
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSeg
    On   RefSeg.PERIODE_ID                 = OEE.PERIODE_ID
    And  RefSeg.PRODUCT_ID                 = OEE.PRODUCT_ID
    And  RefSeg.CURRENT_IN                 =  1
    And  RefSeg.CLOSURE_DT                 Is Null
    And  RefSeg.TYPE_SERVICE               = 'PRESTASCESO'
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM  Matrice
    On   Matrice.PERIODE_ID                = OEE.PERIODE_ID
    And  Matrice.TYPE_COMMANDE_ID          = TYPE_COMMANDE_ID_AGR
    And  Matrice.SEG_COM_ID_INI            = '#'
    And  Matrice.SEG_COM_ID_FINAL          = RefSeg.SEG_COM_ID
    And  Matrice.CURRENT_IN                =  1
    And  Matrice.FRESH_IN                  =  1
    And  Matrice.CLOSURE_DT                Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
    On   Matrice.PERIODE_ID                = Acte.PERIODE_ID
    And  Matrice.ACTE_ID                   = Acte.ACTE_ID
    And  Acte.CURRENT_IN                   = 1
    And  Acte.CLOSURE_DT                   Is Null
Where
  (1=1)
  And Placement.INIT_MOTIF_RCS is null 
Qualify Row_Number() Over (Partition by   Placement.ACTE_ID
                            Order by      OEE.PRODUCT_ID asc
                          )=1


;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_COE;
.if errorcode <> 0 then .quit 1


-- **************************************************************
-- Alimentation de la table ORD_W_ACTE_MATREFCOM_COE Catalogue OEE INIT Boutique 
-- **************************************************************

Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_COE
(  
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  ORDR_TYP_CD                   ,
  PRODUCT_ID_FINAL              ,
  PERIODE_ID                    ,
  TYPE_COMMANDE_ID              ,
  SEG_COM_ID_FINAL              ,
  TYPE_SERVICE_FINAL            ,
  ACT_ID                        ,
  ACTE_REM_ID                   ,
  FLAG_ACT_REM                  ,
  FLAG_PEC_PERPVC               ,
  ACTE_VALO                     ,
  ACTE_FAMILLE_KPI              ,
  TAUX_MARGE                    

)
Select
  Placement.ACTE_ID                                                       as ACTE_ID                                ,
  Placement.ORDER_DEPOSIT_DT                                              as ORDER_DEPOSIT_DT                       ,
  Placement.ORDR_TYP_CD                                                   as ORDR_TYP_CD                            ,
  Coalesce (OEE.PRODUCT_ID, 'PRODUIT INCONNU')                            as PRODUCT_ID_FINAL                       ,
  Matrice.PERIODE_ID                                                      as PERIODE_ID                             ,
  TRIM(SUBSTR(ORDR_TYP_CD,1,4 ))                                          as TYPE_COMMANDE_ID_AGR                   ,
  Coalesce (RefSeg.SEG_COM_ID, 'CODECAT INCONNU')                         as SEG_COM_ID_FINAL                       ,
  RefSeg.TYPE_SERVICE                                                     as TYPE_SERVICE_FINAL                     ,
  Coalesce (Matrice.ACTE_ID, 'WAR_PLACEMENT_NON_ELIGIBLE_REFCOM')         as ACT_ID                                 ,
  Coalesce (Acte.ACTE_REM_ID, 'WAR_PLACEMENT_NON_ELIGIBLE_REFCOM')        as ACTE_REM_ID                            ,
  Coalesce (Acte.FLAG_ACT_REM, 'N')                                       as FLAG_ACT_REM                           ,
  Coalesce (Acte.FLAG_PEC_PERPVC, 'N')                                    as FLAG_PEC_PERPVC                        ,
  Coalesce (Acte.ACTE_VALO, 0)                                            as ACTE_VALO                              ,
  Coalesce (Acte.ACTE_FAMILLE_KPI, 'NON PARAM')                           as ACTE_FAMILLE_KPI                       ,
  Coalesce (Acte.TAUX_MARGE, 0)                                           as TAUX_MARGE                             
From
 ${KNB_PCO_TMP}.ORD_W_ACTE_COE_EXT Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_MOTIF_OEE OEE
    On   Placement.INIT_MOTIF_RCS    =  OEE.EXT_PRODUCT_ID_1
    And  Placement.PERIODE_ID        =  OEE.PERIODE_ID
    And  OEE.CURRENT_IN = 1
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSeg
    On   RefSeg.PERIODE_ID           = OEE.PERIODE_ID
    And  RefSeg.PRODUCT_ID           = OEE.PRODUCT_ID
    And  RefSeg.CURRENT_IN           =  1
    And  RefSeg.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM  Matrice
    On   Matrice.PERIODE_ID          = OEE.PERIODE_ID
    And  Matrice.TYPE_COMMANDE_ID    = TYPE_COMMANDE_ID_AGR
    And  Matrice.SEG_COM_ID_INI      = '#'
    And  Matrice.SEG_COM_ID_FINAL    = RefSeg.SEG_COM_ID
    And  Matrice.CURRENT_IN          =  1
    And  Matrice.FRESH_IN            =  1
    And  Matrice.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
    On Matrice.PERIODE_ID            = Acte.PERIODE_ID
    And Matrice.ACTE_ID              = Acte.ACTE_ID
    And Acte.CURRENT_IN              = 1
    And Acte.CLOSURE_DT              Is Null
Where
  (1=1)
  And Placement.INIT_MOTIF_RCS is not null 
Qualify Row_Number() Over (Partition by   Placement.ACTE_ID
                            Order by      OEE.PRODUCT_ID asc
                          )=1


;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_COE;
.if errorcode <> 0 then .quit 1

.quit 0
