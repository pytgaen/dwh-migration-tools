-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Placement_Consolidation_Enrichissement_Step1_ClientNomAdresse.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrechissement Nom adresse Client
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CLPREPAID All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CLPOSTPAID All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_BAL All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_ADR All;
.if errorcode <> 0 then .quit 1




------------------------------------------------------------------
-- Alimentation des Attributs clients Nom Prenom
-- On requete dans TDDOSSIER uniquement pour les clients Prépaid
-- En effet Les prépaid ont un compte client générique donc non
-- Significatif
------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CLPREPAID
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PAR_LASTNAME            ,
  PAR_FIRSTNAME           
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT         ,
  --Récupération du Nom
  Dossier.DOSSIER_LB_NOM_UTIL               as PAR_LASTNAME           ,
  --Récupération du Prenom
  Dossier.DOSSIER_LB_PRENOM_UTIL            as PAR_FIRSTNAME          
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
    On    RefId.CLIENT_NU                             =   Dossier.DOSSIER_CLIENT_NU
      And RefId.DOSSIER_NU                            =   Dossier.DOSSIER_NU
      --On ajout un delais afin de gérer la désynchronisation / Activation
      And (RefId.INT_DEPOSIT_TS + interval '45' day)  >=  Dossier.DOSSIER_DT_CREAT
Where
  (1=1)
  And ( RefId.PAR_LASTNAME Is Null )
  --Dans le cas des Prépaid le numéro de client est générique et commence par 000000
  And (Substring(RefId.CLIENT_NU From 1 For 6)= '000000')
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Dossier.DOSSIER_DT_CREAT Desc)=1

------------------------------------------------------------------
-- Alimentation des Attributs clients Nom Prenom
-- On requete dans TDCLIENT uniquement pour les clients PostPaid
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CLPOSTPAID
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PAR_LASTNAME              ,
  PAR_FIRSTNAME             ,
  PAR_TYPE                  
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT         ,
  -- Dans le cas des clients Pro on met tous dans le Nom :
  Client.CLIENT_LL_NOM                      as PAR_LASTNAME           ,
  -- Dans le cas des clients Post Paid on ne peut pas séparer le nom
  -- du prénom
  Null                                      as PAR_FIRSTNAME          ,
  --Type du client
  Client.CLIENT_CO_TYPCLI                   as PAR_TYPE               
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDCLIENT Client
    On    RefId.CLIENT_NU =   Client.CLIENT_NU
Where
  (1=1)
  And ( RefId.PAR_LASTNAME Is Null Or RefId.PAR_TYPE Is Null)
  --On ne fait n'exclu pas les prépaid pour récupérer leur le code Type Client
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Client.CREATION_TS Desc)=1

------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Mail
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_BAL
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PAR_EMAIL                 
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT         ,
  --Récupération de l'adresse mail
  AdrMail.CLIDEMAT_LB_EMAIL                 as PAR_EMAIL              
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDCLIDEMAT AdrMail
    On    RefId.CLIENT_NU                         =   AdrMail.CLIDEMAT_CLIENT_NU
      And AdrMail.CURRENT_IN                      =   1
      And AdrMail.CLOSURE_DT                      Is Null
Where
  (1=1)
  And ( RefId.PAR_EMAIL Is Null )
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by  --On privilégie les Clients sur le meme dossier
                                                                Case
                                                                    When RefId.DOSSIER_NU = AdrMail.CLIDEMAT_NU_DOSSIER
                                                                      Then  1
                                                                    Else    0
                                                                End Desc, AdrMail.CREATION_TS Desc)=1

------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Postale
-- POur les Clients PostPaid On va dans THADRCLI (Car c'est l'adresse
-- de facturation du client donc ne marche pas pour les prépaid car
-- compte client générique)
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_ADR
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PAR_BILL_ADRESS_1         ,
  PAR_BILL_ADRESS_2         ,
  PAR_BILL_ADRESS_3         ,
  PAR_BILL_ADRESS_4         ,
  PAR_BILL_VILLE            ,
  PAR_BILL_CD_POSTAL        ,
  PAR_INSEE_CD              ,
  PAR_DO                    
)
Select
  RefId.ACTE_ID                                       as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                                as INT_DEPOSIT_DT         ,
  --Récupération de l'adresse du client Depuis ADRCLI
  Adr.ADRCLI_LB_ADR1                                  as PAR_BILL_ADRESS_1      ,
  Adr.ADRCLI_LB_ADR2                                  as PAR_BILL_ADRESS_2      ,
  Adr.ADRCLI_LB_ADR3                                  as PAR_BILL_ADRESS_3      ,
  Adr.ADRCLI_LB_ADR4                                  as PAR_BILL_ADRESS_4      ,
  CodePost.CODPOST_LB_LOCAL                           as PAR_BILL_VILLE         ,
  --Calcul du code Postale => 5 Premier caractère du code (Car le champ : Code Postal + INSEE)
  Substring(Trim(Adr.ADRCLI_CODPOST_CO) From 1 For 5) as PAR_BILL_CD_POSTAL     ,
  CodePost.CODPOST_NU_INSEE                           as PAR_INSEE_CD           ,
  --Calcul De la DO : En fonction du département Pour la métropole 2 1er caractère
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Coalesce(Adr.ADRCLI_CODPOST_CO,Client.CLIENT_CODPOST_CO)) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988','998','999')
          Then  Substring(Trim(Coalesce(Adr.ADRCLI_CODPOST_CO,Client.CLIENT_CODPOST_CO)) From 1 For 3)
        When    Coalesce(Adr.ADRCLI_CODPOST_CO,Client.CLIENT_CODPOST_CO) Is Not Null
          Then  Substring(Trim(Coalesce(Adr.ADRCLI_CODPOST_CO,Client.CLIENT_CODPOST_CO)) From 1 For 2)
        Else    Null
  End                                                 as PAR_DO                 
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 RefId
  Left Outer Join ${KNB_IBU_SOC}.V_THADRCLI Adr
    On    RefId.CLIENT_NU                         =   Adr.ADRCLI_CLIENT_NU
      And RefId.INT_DEPOSIT_DT                    >=  Adr.ADRCLI_DT_DEB
      And (
              RefId.INT_DEPOSIT_DT                <   Adr.ADRCLI_DT_FIN
            Or
              Adr.ADRCLI_DT_FIN                   Is null
          )
  Left Outer Join ${KNB_IBU_SOC}.V_TDCODPOST CodePost
    On    Adr.ADRCLI_CODPOST_CO                   =   CodePost.CODPOST_CO
      And CodePost.CURRENT_IN                     =   1
      And CodePost.CLOSURE_DT                     Is Null
  Left Outer Join ${KNB_IBU_SOC}.V_TDCLIENT Client
    On    RefId.CLIENT_NU                         =   Client.CLIENT_NU
Where
  (1=1)
  And ( RefId.PAR_BILL_CD_POSTAL Is Null Or RefId.PAR_DO Is Null)
  --Dans le cas des Prépaid le numéro de client est générique et commence par 000000
  And (Substring(RefId.CLIENT_NU From 1 For 6)<> '000000')
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Adr.ADRCLI_DT_DEB Asc)=1

------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Postale
-- Pour les Clients Prépaid On va dans TDDOSSIER
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_ADR
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PAR_BILL_ADRESS_1         ,
  PAR_BILL_ADRESS_2         ,
  PAR_BILL_ADRESS_3         ,
  PAR_BILL_ADRESS_4         ,
  PAR_BILL_VILLE            ,
  PAR_BILL_CD_POSTAL        ,
  PAR_INSEE_CD              ,
  PAR_DO                    
)
Select
  RefId.ACTE_ID                                           as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                                    as INT_DEPOSIT_DT         ,
  --Récupération de l'adresse du client
  Dossier.DOSSIER_LB_ADRESSE1                             as PAR_BILL_ADRESS_1      ,
  Dossier.DOSSIER_LB_ADRESSE2                             as PAR_BILL_ADRESS_2      ,
  Dossier.DOSSIER_LB_ADRESSE3                             as PAR_BILL_ADRESS_3      ,
  Dossier.DOSSIER_LB_ADRESSE4                             as PAR_BILL_ADRESS_4      ,
  Dossier.DOSSIER_LB_VILLE                                as PAR_BILL_VILLE         ,
  --Calcul du code Postale
  Trim(Dossier.DOSSIER_CODPOST_CO)                        as PAR_BILL_CD_POSTAL     ,
  Null                                                    as PAR_INSEE_CD           ,
  --Calcul De la DO : En fonction du département Pour la métropole 2 1er caractère
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Dossier.DOSSIER_CODPOST_CO) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988','998','999')
          Then  Substring(Trim(Dossier.DOSSIER_CODPOST_CO) From 1 For 3)
        When    Dossier.DOSSIER_CODPOST_CO Is Not Null
          Then  Substring(Trim(Dossier.DOSSIER_CODPOST_CO) From 1 For 2)
        Else    '999'
  End                                                     as PAR_DO                 
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
    On    RefId.CLIENT_NU                         =   Dossier.DOSSIER_CLIENT_NU
      And RefId.DOSSIER_NU                        =   Dossier.DOSSIER_NU
Where
  (1=1)
  And ( RefId.PAR_BILL_CD_POSTAL Is Null Or RefId.PAR_DO Is Null)
  --Dans le cas des Prépaid le numéro de client est générique et commence par 000000
  And (Substring(RefId.CLIENT_NU From 1 For 6)= '000000')
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Dossier.CREATION_TS desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CLPREPAID;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CLPOSTPAID;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_BAL;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_CL_ADR;
.if errorcode <> 0 then .quit 1



.quit 0



