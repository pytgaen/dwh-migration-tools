--$HEADER: mm2pco/current/sql/ATP_NSH_Placement_Cold_Alimentation_CalculIDExterne.sql 13_05#3 13-NOV-2019 11:33:32 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Hot_Alimentation_CalculIDExterne.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul d'identifiant externe
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 06/01/2014      MCA         Creation
-- 18/07/2014      MCA         Indus
-- 01/12/2014      MCA         Ajout et alim champs perform
-- 27/01/2016      OCH         Ajout STW
-- 25/04/2016      OCH         Ajout XSELL
-- 13/06/2016      GMA         Ajout du regroupement par Accessoire
-- 25/07/2016      GMA         Filtrage des commmandes Accessoires pour supprimer les forfaits / options
-- 23/01/2018      HOB         Evol Refonte NSH S2W
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_NEWSHOP_PLACEMENT_C_EXT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


-- Type terminaux
-- Insertion de donnees delta dans une table tampon placement
Insert Into ${KNB_PCO_TMP}.ORD_W_NEWSHOP_PLACEMENT_C_EXT
(
  EXTERNAL_ACTE_ID            ,
  APPLI_SOURCE_ID             ,
  INTRNL_SOURCE_ID            ,
  TYPE_SOURCE_ID              ,
  MSISDN_DS                   ,
  ORDR_CREATN_DT              ,
  ORDR_CREATN_DATE            ,
  CATGR_DS                    ,
  EXTERNAL_ORDER_ID_SPO       ,
  ORDER_TYPE                  ,
  EXTERNAL_ORDER_ID           ,
  VAD_ID                      ,
  OPAL_ID                     ,
  VAD_HOM_ID                  ,
  TYP_ORDR_CD                 ,
  ORDR_TYPLG_DS               ,
  EXTERNAL_PRODUCT_ID_OT      ,
  EXTERNAL_PRODUCT_ID_OT_OP   ,
  ORG_AGENT_ID                ,
  POSTAL_CD                   ,
  ORDER_LINE_TYPE             ,
  EXTERNAL_PRODUCT_ID         ,
  EXTERNAL_PRODUCT_ID_PRE     ,
  SUBSCRPTN_DURTN_DS          ,
  ADV_ID                      ,
  SHOP_COD_DS                 ,
  SHOP_ADV_COD_DS             ,
  BRAND_SHOP_DS               ,
  PAYMNT_FORMLTN_ID           ,
  MONTHL_PRIC                 ,
  MONTHL_PERD                 ,
  QUANTT_QT                   ,
  ID_QUANTITE                 ,
  AMNT_HT_ARTCL_AM            ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
Select
  --La cle est definie a partir de SUBSCRPTN_ID et le code EAN 
    Trim(RefSPO.SUBSCRPTN_ID||'|${P_PIL_202}|'||RefSPO.TERMNL_EAN_DS||Trim(Quantite.ID_QUANTITE))           as EXTERNAL_ACTE_ID           ,
  --ApplicsourceID
  RefSPO.APPLI_SOURCE_ID                                                                                    as APPLI_SOURCE_ID            ,
  --Appli source Interne
  ${IdSourceInterne}                                                                                        as INTRNL_SOURCE_ID           ,
  -- Param pour la table ID : 207
  ${IdentifiantTechniqueSource}                                                                             as TYPE_SOURCE_ID             ,
  RefSPO.MSISDN_DS                                                                                          as MSISDN_DS                  ,
  RefSPO.ORDR_CREATN_DT                                                                                     as ORDR_CREATN_DT             ,
  cast(RefSPO.ORDR_CREATN_DATE As Date Format 'YYYYMMDD')                                                   as ORDR_CREATN_DATE           ,
  RefSPO.CATGR_DS                                                                                           as CATGR_DS                   ,
  RefSPO.SUBSCRPTN_ID                                                                                       as EXTERNAL_ORDER_ID_SPO      ,
  Case when ( RefSPO.VAD_ID is not null and RefSPO.OPAL_ID is not null) then 'CSA'
       when RefSPO.VAD_HOM_ID is not null  then 'VAH'
       When RefSPO.VAD_ID is not null  then '${P_PIL_422}'
       When RefSPO.OPAL_ID is not null  then '${P_PIL_423}'
       else 'NON PARAM'
  End                                                                                                       as ORDER_TYPE                 ,
  Coalesce(Trim(RefSPO.VAD_HOM_ID),Trim(RefSPO.VAD_ID), Trim(RefSPO.OPAL_ID))                               as EXTERNAL_ORDER_ID          ,
  RefSPO.VAD_ID                                                                                             as VAD_ID                     ,
  Trim(RefSPO.OPAL_ID)                                                                                      as OPAL_ID                    ,
  Trim(RefSPO.VAD_HOM_ID)                                                                                   as VAD_HOM_ID                 ,
  RefSPO.TYP_ORDR_CD                                                                                        as TYP_ORDR_CD                ,
  RefSPO.ORDR_TYPLG_DS                                                                                      as ORDR_TYPLG_DS              ,
  Coalesce(RefSPO.SUBSCRPTN_TIM_CREDT_ADV_CD,RefSPO.SUB_INITL_TIM_CREDT_ADV_CD)                             as EXTERNAL_PRODUCT_ID_OT     ,
  Case  When RefSPO.SUBSCRPTN_TIM_CREDT_ADV_CD is not null
          Then  'C'
        When RefSPO.SUB_INITL_TIM_CREDT_ADV_CD is not Null
          Then  'M'
        Else    Null
  End                                                                                                       as EXTERNAL_PRODUCT_ID_OT_OP  ,
  RefSPO.AGNT_ID                                                                                            as ORG_AGENT_ID               ,
  RefSPO.POSTAL_CD                                                                                          as POSTAL_CD                  ,
  RefSPO.ORDER_LINE_TYPE                                                                                    as ORDER_LINE_TYPE            ,
  RefSPO.TERMNL_EAN_DS                                                                                      as EXTERNAL_PRODUCT_ID        ,
  Null                                                                                                      as EXTERNAL_PRODUCT_ID_PRE    ,
  RefSPO.SUBSCRPTN_DURTN_DS                                                                                 as SUBSCRPTN_DURTN_DS         ,
  RefSPO.ADV_ID                                                                                             as ADV_ID                     ,
  RefSPO.SHOP_COD_DS                                                                                        as SHOP_COD_DS                ,
  RefSPO.SHOP_ADV_COD_DS                                                                                    as SHOP_ADV_COD_DS            ,
  RefSPO.BRAND_SHOP_DS                                                                                      as BRAND_SHOP_DS              ,
  RefSPO.PAYMNT_FORMLTN_ID                                                                                  as PAYMNT_FORMLTN_ID          ,
  RefSPO.MONTHL_PRIC                                                                                        as MONTHL_PRIC                ,
  RefSPO.MONTHL_PERD                                                                                        as MONTHL_PERD                ,
  RefSpo.QUANTT_QT                                                                                          as QUANTT_QT                  ,
  Quantite.ID_QUANTITE                                                                                      as ID_QUANTITE                ,
  RefSpo.AMNT_HT_ARTCL_AM                                                                                   as AMNT_HT_ARTCL_AM           ,
  0                                                                                                         as HOT_IN                     ,
  Current_Timestamp(0)                                                                                      as CREATION_TS                ,
  Current_Timestamp(0)                                                                                      as LAST_MODIF_TS              ,
  1                                                                                                         as FRESH_IN                   ,
  0                                                                                                         as COHERENCE_IN
From
  --On prend la table de delta extraite de ORD_F_SHOP_TO_WEB_OL_R_VM de la base SPO
  ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT RefSPO
  Inner Join ${KNB_PCO_TMP}.ORD_T_PILCOM_GEN_QUANTITY Quantite
    On RefSpo.QUANTT_QT = Quantite.REF_QUANTITE
Where
  (1=1)
  And RefSPO.ORDER_LINE_TYPE ='T'
   


-- Type Offre (forfaits)

;Insert Into ${KNB_PCO_TMP}.ORD_W_NEWSHOP_PLACEMENT_C_EXT
(
  EXTERNAL_ACTE_ID            ,
  APPLI_SOURCE_ID             ,
  INTRNL_SOURCE_ID            ,
  TYPE_SOURCE_ID              ,
  MSISDN_DS                   ,
  ORDR_CREATN_DT              ,
  ORDR_CREATN_DATE            ,
  CATGR_DS                    ,
  EXTERNAL_ORDER_ID_SPO       ,
  ORDER_TYPE                  ,
  EXTERNAL_ORDER_ID           ,
  VAD_ID                      ,
  OPAL_ID                     ,
  VAD_HOM_ID                  ,
  TYP_ORDR_CD                 ,
  ORDR_TYPLG_DS               ,
  ORG_AGENT_ID                ,
  POSTAL_CD                   ,
  ORDER_LINE_TYPE             ,
  EXTERNAL_PRODUCT_ID         ,
  EXTERNAL_PRODUCT_ID_PRE     ,
  EXTERNAL_PRODUCT_ID_OT      ,
  EXTERNAL_PRODUCT_ID_OT_OP   ,
  SUBSCRPTN_DURTN_DS          ,
  ADV_ID                      ,
  SHOP_COD_DS                 ,
  SHOP_ADV_COD_DS             ,
  BRAND_SHOP_DS               ,
  PAYMNT_FORMLTN_ID           ,
  MONTHL_PRIC                 ,
  MONTHL_PERD                 ,
  QUANTT_QT                   ,
  ID_QUANTITE                 ,
  AMNT_HT_ARTCL_AM            ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
Select
  --La cle est definie a partir de SUBSCRPTN_ID et le code SUBSCRPTN_TIM_CREDT_ADV_DS 
  Trim(RefSPO.SUBSCRPTN_ID||'|${P_PIL_040}|'||RefSPO.SUBSCRPTN_TIM_CREDT_ADV_CD)                            as EXTERNAL_ACTE_ID           ,
  --ApplicsourceID
  RefSPO.APPLI_SOURCE_ID                                                                                    as APPLI_SOURCE_ID            ,
  --Appli source Interne
  ${IdSourceInterne}                                                                                        as INTRNL_SOURCE_ID           ,
  -- Param pour la table ID : 207
  ${IdentifiantTechniqueSource}                                                                             as TYPE_SOURCE_ID             ,
  RefSPO.MSISDN_DS                                                                                          as MSISDN_DS                  ,
  RefSPO.ORDR_CREATN_DT                                                                                     as ORDR_CREATN_DT             ,
  cast(RefSPO.ORDR_CREATN_DATE As Date Format 'YYYYMMDD')                                                   as ORDR_CREATN_DATE           ,
  RefSPO.CATGR_DS                                                                                           as CATGR_DS                   ,
  RefSPO.SUBSCRPTN_ID                                                                                       as EXTERNAL_ORDER_ID_SPO      ,
  Case when RefSPO.VAD_HOM_ID is not null then 'VAH'
       when RefSPO.VAD_ID is not null then '${P_PIL_422}' 
       else '${P_PIL_423}' end                                                                              as ORDER_TYPE                 ,
  Coalesce(RefSPO.VAD_ID, Trim(RefSPO.OPAL_ID),Trim(RefSPO.VAD_HOM_ID))                                     as EXTERNAL_ORDER_ID          ,
  Trim(RefSPO.VAD_ID)                                                                                       as VAD_ID                     ,
  Trim(RefSPO.OPAL_ID)                                                                                      as OPAL_ID                    ,
  RefSPO.VAD_HOM_ID                                                                                         as VAD_HOM_ID                 ,
  RefSPO.TYP_ORDR_CD                                                                                        as TYP_ORDR_CD                ,
  RefSPO.ORDR_TYPLG_DS                                                                                      as ORDR_TYPLG_DS              ,
  RefSPO.AGNT_ID                                                                                            as ORG_AGENT_ID               ,
  RefSPO.POSTAL_CD                                                                                          as POSTAL_CD                  ,
  RefSPO.ORDER_LINE_TYPE                                                                                    as ORDER_LINE_TYPE            ,
  RefSPO.SUBSCRPTN_TIM_CREDT_ADV_CD                                                                         as EXTERNAL_PRODUCT_ID        ,
  RefSPO.SUB_INITL_TIM_CREDT_ADV_CD                                                                         as EXTERNAL_PRODUCT_ID_PRE    ,
  Null                                                                                                      as EXTERNAL_PRODUCT_ID_OT     ,
  Null                                                                                                      as EXTERNAL_PRODUCT_ID_OT_OP  ,
  RefSPO.SUBSCRPTN_DURTN_DS                                                                                 as SUBSCRPTN_DURTN_DS         ,
  RefSPO.ADV_ID                                                                                             as ADV_ID                     ,
  RefSPO.SHOP_COD_DS                                                                                        as SHOP_COD_DS                ,
  RefSPO.SHOP_ADV_COD_DS                                                                                    as SHOP_ADV_COD_DS            ,
  RefSPO.BRAND_SHOP_DS                                                                                      as BRAND_SHOP_DS              ,
  RefSPO.PAYMNT_FORMLTN_ID                                                                                  as PAYMNT_FORMLTN_ID          ,
  RefSPO.MONTHL_PRIC                                                                                        as MONTHL_PRIC                ,
  RefSPO.MONTHL_PERD                                                                                        as MONTHL_PERD                ,
  1                                                                                                         as QUANTT_QT                  ,
  1                                                                                                         as ID_QUANTITE                ,
  0                                                                                                         as AMNT_HT_ARTCL_AM           ,
  0                                                                                                         as HOT_IN                     ,
  Current_Timestamp(0)                                                                                      as CREATION_TS                ,
  Current_Timestamp(0)                                                                                      as LAST_MODIF_TS              ,
  1                                                                                                         as FRESH_IN                   ,
  0                                                                                                         as COHERENCE_IN
From
  --On prend la table de delta extraite de ORD_F_SHOP_TO_WEB_OL_R_VM 
  ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT RefSPO
Where 
  (1=1)
  And RefSPO.ORDER_LINE_TYPE   ='OT'
  --On filtre les commandes accessoires pour la génération des forfaits + options
  And RefSPO.TYP_ORDR_CD                  Not In ('3')
  Qualify Row_Number() Over (Partition by RefSPO.SUBSCRPTN_ID Order by RefSPO.VAD_ID, Trim(RefSPO.OPAL_ID),Trim(RefSPO.VAD_HOM_ID) Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_W_NEWSHOP_PLACEMENT_C_EXT;
.if errorcode <> 0 then .quit 1




--creation table volatile
CREATE MULTISET VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_SHOP_TO_WEB_OL_R_VM  -- _V pour volatile
  (
     ID                       VARCHAR(500)          NOT NULL,
     OPTN_ELT                 VARCHAR(500)          NOT NULL,
     OPTN_ELT_POS             SMALLINT              NOT NULL
  )
PRIMARY INDEX (ID)

ON COMMIT PRESERVE ROWS
;
.IF errorcode <> 0 THEN .QUIT 1;



Insert into ORD_V_SHOP_TO_WEB_OL_R_VM
  (
    ID          ,
    OPTN_ELT    ,
    OPTN_ELT_POS
  )
With Recursive LISTE_STW_OPTION_ADV
(
  OPTIONCMD             ,
  COMPOSANTEOPTIONCMD   ,
  OPTIONCMDSUITE        ,
  ID_POSITION
)
As
(
    Select
      f.OPTNS_ADV_DS                                                                        As OPTIONCMD            ,
      Case    --Si on a trouve le motif 'S'
              When Index(OPTIONCMD, '$' ) -1 > 0
                --Alors on prend les caractÃ¨re jusqu'a $
                Then Substring(OPTIONCMD From 1 For Index(OPTIONCMD, '$' ) -1)
              --Sinon on retourne le champ
              Else  Substring(OPTIONCMD From 1)
      End                                                                                   As COMPOSANTEOPTIONCMD  ,
      Case    --Si on a trouve le motif 'S'
              When Index(OPTIONCMD, '$' ) -1 > 0
                --On ecrit le reste de la commande
                Then Substring(OPTIONCMD From Index(OPTIONCMD, '$' ) +1)
              Else  Null
      End                                                                                   As OPTIONCMDSUITE       ,
      1                                                                                     As ID_POSITION
    From
      ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT f
    Where
      (1=1)
      And f.OPTNS_ADV_DS Is Not Null
  Union All
    Select
      r.OPTIONCMD                                                                           As OPTIONCMD            ,
      Case    --Si on a trouve le motif 'S'
              When Index(r.OPTIONCMDSUITE, '$' ) -1 > 0
                --Alors on prend les caractere jusqu'a $
                Then Substring(r.OPTIONCMDSUITE From 1 For Index(r.OPTIONCMDSUITE, '$' ) -1)
              --Sinon on retourne le champ
              Else  Substring(r.OPTIONCMDSUITE from 1)
      End                                                                                   As COMPOSANTEOPTIONCMD  ,
      Case    --Si on a trouve le motif 'S'
              When Index(r.OPTIONCMDSUITE, '$' ) -1 > 0
                --On ecrit le reste de la commande
                Then Substring(r.OPTIONCMDSUITE From Index(r.OPTIONCMDSUITE, '$' ) +1)
              Else  Null
      End                                                                                   As OPTIONCMDSUITE       ,
      r.ID_POSITION +1                                                                      As ID_POSITION
    From
        LISTE_STW_OPTION_ADV r
    where
      (1=1)
      And OPTIONCMDSUITE Is Not Null
)
Select
  RefId.OPTIONCMD                                                                           As ID                   ,
  RefId.COMPOSANTEOPTIONCMD                                                                 As OPTN_ELT             ,
  RefId.ID_POSITION                                                                         As OPTN_ELT_POS
From
  LISTE_STW_OPTION_ADV RefId
Group by
  RefId.OPTIONCMD               ,
  RefId.COMPOSANTEOPTIONCMD     ,
  RefId.ID_POSITION
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.ORD_V_SHOP_TO_WEB_OL_R_VM Column(ID);
.if errorcode <> 0 then .quit 1


-- Type option

Insert Into ${KNB_PCO_TMP}.ORD_W_NEWSHOP_PLACEMENT_C_EXT
(
  EXTERNAL_ACTE_ID            ,
  APPLI_SOURCE_ID             ,
  INTRNL_SOURCE_ID            ,
  TYPE_SOURCE_ID              ,
  MSISDN_DS                   ,
  ORDR_CREATN_DT              ,
  ORDR_CREATN_DATE            ,
  CATGR_DS                    ,
  EXTERNAL_ORDER_ID_SPO       ,
  ORDER_TYPE                  ,
  EXTERNAL_ORDER_ID           ,
  VAD_ID                      ,
  OPAL_ID                     ,
  VAD_HOM_ID                  ,
  TYP_ORDR_CD                 ,
  ORDR_TYPLG_DS               ,
  EXTERNAL_PRODUCT_ID_OT      ,
  EXTERNAL_PRODUCT_ID_OT_OP   ,
  ORG_AGENT_ID                ,
  POSTAL_CD                   ,
  ORDER_LINE_TYPE             ,
  EXTERNAL_PRODUCT_ID         ,
  EXTERNAL_PRODUCT_ID_PRE     ,
  SUBSCRPTN_DURTN_DS          ,
  ADV_ID                      ,
  SHOP_COD_DS                 ,
  SHOP_ADV_COD_DS             ,
  BRAND_SHOP_DS               ,
  PAYMNT_FORMLTN_ID           ,
  MONTHL_PRIC                 ,
  MONTHL_PERD                 ,
  QUANTT_QT                   ,
  ID_QUANTITE                 ,
  AMNT_HT_ARTCL_AM            ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
Select
  --La cle est definie a partir de SUBSCRPTN_ID et le code ADV 
  Trim(RefSPO.SUBSCRPTN_ID||'|${P_PIL_041}|'||RefSO.OPTN_ELT)                                               as EXTERNAL_ACTE_ID           ,
  --ApplicsourceID
  RefSPO.APPLI_SOURCE_ID                                                                                    as APPLI_SOURCE_ID            ,
  --Appli source Interne
  ${IdSourceInterne}                                                                                        as INTRNL_SOURCE_ID           ,
  -- Param pour la table ID : 207
  ${IdentifiantTechniqueSource}                                                                             as TYPE_SOURCE_ID             ,
  RefSPO.MSISDN_DS                                                                                          as MSISDN_DS                  ,
  RefSPO.ORDR_CREATN_DT                                                                                     as ORDR_CREATN_DT             ,
  cast(RefSPO.ORDR_CREATN_DATE As Date Format 'YYYYMMDD')                                                   as ORDR_CREATN_DATE           ,
  RefSPO.CATGR_DS                                                                                           as CATGR_DS                   ,
  RefSPO.SUBSCRPTN_ID                                                                                       as EXTERNAL_ORDER_ID_SPO      ,
  Case when RefSPO.VAD_ID is not null then '${P_PIL_422}' else '${P_PIL_423}' end                           as ORDER_TYPE                 ,
  Coalesce(RefSPO.VAD_ID, Trim(RefSPO.OPAL_ID),Trim(RefSPO.VAD_HOM_ID))                                     as EXTERNAL_ORDER_ID          ,
  Trim(RefSPO.VAD_ID)                                                                                       as VAD_ID                     ,
  Trim(RefSPO.OPAL_ID)                                                                                      as OPAL_ID                    ,
  RefSPO.VAD_HOM_ID                                                                                         as VAD_HOM_ID                 ,
  RefSPO.TYP_ORDR_CD                                                                                        as TYP_ORDR_CD                ,
  RefSPO.ORDR_TYPLG_DS                                                                                      as ORDR_TYPLG_DS              ,
  Coalesce(RefSPO.SUBSCRPTN_TIM_CREDT_ADV_CD,RefSPO.SUB_INITL_TIM_CREDT_ADV_CD)                             as EXTERNAL_PRODUCT_ID_OT     ,
  Case  When RefSPO.SUBSCRPTN_TIM_CREDT_ADV_CD is not null
          Then 'C'
        Else 'M'
  End                                                                                                       as EXTERNAL_PRODUCT_ID_OT_OP  ,
  RefSPO.AGNT_ID                                                                                            as ORG_AGENT_ID               ,
  RefSPO.POSTAL_CD                                                                                          as POSTAL_CD                  ,
  RefSPO.ORDER_LINE_TYPE                                                                                    as ORDER_LINE_TYPE            ,
  RefSO.OPTN_ELT                                                                                            as EXTERNAL_PRODUCT_ID        ,
  Null                                                                                                      as EXTERNAL_PRODUCT_ID_PRE    ,
  RefSPO.SUBSCRPTN_DURTN_DS                                                                                 as SUBSCRPTN_DURTN_DS         ,
  RefSPO.ADV_ID                                                                                             as ADV_ID                     ,
  RefSPO.SHOP_COD_DS                                                                                        as SHOP_COD_DS                ,
  RefSPO.SHOP_ADV_COD_DS                                                                                    as SHOP_ADV_COD_DS            ,
  RefSPO.BRAND_SHOP_DS                                                                                      as BRAND_SHOP_DS              ,
  RefSPO.PAYMNT_FORMLTN_ID                                                                                  as PAYMNT_FORMLTN_ID          ,
  RefSPO.MONTHL_PRIC                                                                                        as MONTHL_PRIC                ,
  RefSPO.MONTHL_PERD                                                                                        as MONTHL_PERD                ,
  1                                                                                                         as QUANTT_QT                  ,
  1                                                                                                         as ID_QUANTITE                ,
  0                                                                                                         as AMNT_HT_ARTCL_AM           ,
  0                                                                                                         as HOT_IN                     ,
  Current_Timestamp(0)                                                                                      as CREATION_TS                ,
  Current_Timestamp(0)                                                                                      as LAST_MODIF_TS              ,
  1                                                                                                         as FRESH_IN                   ,
  0                                                                                                         as COHERENCE_IN
From
  --On prend la table de delta extraite de ORD_F_SHOP_TO_WEB_OL_R_VM 
  ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT RefSPO
  --On jointe avec la table volatile pour generer le bon nombre de ligne
  Inner join ${KNB_TERADATA_USER}.ORD_V_SHOP_TO_WEB_OL_R_VM RefSO
    On RefSPO.OPTNS_ADV_DS=RefSO.ID
Where 
  (1=1)
  And RefSPO.ORDER_LINE_TYPE     ='SO'
  --On filtre les commandes accessoires pour la génération des forfaits + options
  And RefSPO.TYP_ORDR_CD                  Not In ('3')
Qualify Row_Number() Over (Partition by RefSPO.SUBSCRPTN_ID,RefSO.OPTN_ELT Order By RefSPO.SUBSCRPTN_ID Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_NEWSHOP_PLACEMENT_C_EXT;
.if errorcode <> 0 then .quit 1



 
.quit 0
