--$HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_VAD_CrossActes_CAR_ORD_T_ACTE_UNIFIED.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de croisement de la source CAR (TFTRACEUNI) avec la source VAD
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 10/10/2018     TCL         Création
-- 09/04/2019     SII         Modification les rapprochements historiques
-- 23/05/2019     JCR         les actes Omnicanaaux doivent conserver les informations omnicanal : 
--                             on met à jour juste le lien entre maitre et esclave.
-- 08/07/2021     BCH         PILCOM-946 : Suppression des colonnes obsolètes de ORD_T_ACTE_UNIFIED_VAD
--------------------------------------------------------------------------------

.set width 5000

--------------------------------
-- Table : VAD_TMP_RCS
-- Pour filtrer les actes VAD RCS Only  (Reference Externe : RCSO1 ou RCSS1)
--------------------------------
Create volatile Table ${KNB_TERADATA_USER}.VAD_TMP_RCS (
      ACTE_ID                           BIGINT                       ,
      ORDER_REF_EXTERNAL_ID             VARCHAR(20)                  ,
      ORDER_DEPOSIT_DT                  DATE FORMAT 'YYYYMMDD'      ) 
PRIMARY INDEX (ACTE_ID,ORDER_DEPOSIT_DT) ON COMMIT PRESERVE ROWS;
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_TERADATA_USER}.VAD_TMP_RCS
  ( 
  ACTE_ID                         ,
  ORDER_REF_EXTERNAL_ID           ,
  ORDER_DEPOSIT_DT
  )
  Select 
    Vad.ACTE_ID,
    Vad.ORDER_REF_EXTERNAL_ID,
    Vad.ORDER_DEPOSIT_DT
   From ${KNB_PCO_VM}.ORD_F_ACTE_VAD Vad
   Where  Vad.ORDER_REF_EXTERNAL_ID in ('RCSO1','RCSS1');
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_TERADATA_USER}.VAD_TMP_RCS Column( ACTE_ID,ORDER_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1;
Collect Stats On ${KNB_TERADATA_USER}.VAD_TMP_RCS Column( ORDER_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1;

--------------------------------                                        
-- Table : ORD_T_ACTE_UNIFIED --
--------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-- Identification Croisement 

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
(
  MASTER_ACTE_ID                  ,
  SLAVE_ACTE_ID                   ,
  MASTER_SOURCE_ID                ,
  SLAVE_SOURCE_ID                 ,
  MASTER_NB_FOUND                 ,
  OFFSET 
)
Select 
  RES.MASTER_ACTE_ID              ,
  RES.SLAVE_ACTE_ID               ,
  RES.MASTER_SOURCE_ID            ,
  RES.SLAVE_SOURCE_ID             ,
  RES.MASTER_NB_FOUND             ,
  RES.OFFSET    
From 
(
  Select
    MASTER.ACTE_ID                                                                            As MASTER_ACTE_ID,
    SLAVE.ACTE_ID                                                                             As SLAVE_ACTE_ID,
    MASTER.INTRNL_SOURCE_ID                                                                   As MASTER_SOURCE_ID,
    SLAVE.INTRNL_SOURCE_ID                                                                    As SLAVE_SOURCE_ID,
    Count(*) Over (Partition By SLAVE.ACTE_ID)                                                As MASTER_NB_FOUND,                                                                                    
    Abs((MASTER.ACT_TS - SLAVE.ACT_TS) Day(4) To Second)                                      As DIFF_TS, 
    (Extract(Day From DIFF_TS) * 86400) + (Extract(Hour From DIFF_TS) * 3600) + 
    (Extract(Minute From DIFF_TS) * 60) + Extract(Second From DIFF_TS)                        As OFFSET_SEC,
    MASTER.ACT_DT - SLAVE.ACT_DT                                                              As OFFSET 
  From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} ${SourceTmp}
  Inner join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ${SourceSoc}
    On  ${SourceTmp}.MSISDN_ID                =  ${SourceSoc}.MSISDN_ID  
    And ${SourceTmp}.ACT_DT                   =  ${SourceSoc}.ACT_DT 
    And ${SourceTmp}.ACT_SEG_COM_ID_FINAL     =  ${SourceSoc}.ACT_SEG_COM_ID_FINAL
  Inner join ${KNB_TERADATA_USER}.VAD_TMP_RCS rcs  -- Jointure pour le filtre RCS Only
   On   rcs.ACTE_ID = MASTER.ACTE_ID
   And  rcs.ORDER_DEPOSIT_DT = MASTER.ACT_DT
  Where 
  (1=1)
    And ${SourceTmp}.INTRNL_SOURCE_ID = '${SourceAlimId}' 
    And ${SourceTmp}.ACT_CLOSURE_DT Is Null 
    And ${SourceTmp}.ACT_END_UNIFIED_DT Is Null 
    And ${SourceSoc}.INTRNL_SOURCE_ID = '${SourceEnrId}' 
    And ${SourceSoc}.ACT_CLOSURE_DT Is Null 
    And ${SourceSoc}.ACT_END_UNIFIED_DT Is Null 
  Qualify Row_Number() Over(Partition By SLAVE.ACTE_ID Order By OFFSET_SEC Asc) = 1
)RES;
.if errorcode <> 0 then .quit 1;
  
Collect Stats On ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-- Alimentation des maîtres ou esclaves dans le TMP 
-- Récupération de données esclaves depuis la VU et les insérer dans la table temporaire pour les recalculer  
Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} 
Select 
  SOC.ACTE_ID,
  SOC.OPERATOR_PROVIDER_ID,
  SOC.INTRNL_SOURCE_ID,
  SOC.TYPE_SOURCE_ID,
  SOC.MASTER_ACTE_ID,
  SOC.MASTER_INTRNL_SOURCE_ID,
  SOC.MASTER_FLAG,
  SOC.MASTER_NB_FOUND,
  SOC.CPLT_ACTE_ID,
  SOC.CPLT_INTRNL_SOURCE_ID,
  SOC.CPLT_IN,
  SOC.RULE_ID,
  SOC.OFFSET_NB,
  SOC.ACT_TYPE,
  SOC.ORDER_EXTERNAL_ID,
  SOC.STATUS_CD,
  SOC.ACT_UNIFIED_STATUS_CD,
  SOC.ACT_TS,
  SOC.ACT_DT,
  SOC.ACT_HH,
  SOC.ACT_LAST_UPD_TS,
  SOC.ACT_PRODUCT_ID_PRE,
  SOC.ACT_SEG_COM_ID_PRE,
  SOC.ACT_SEG_COM_AGG_ID_PRE,
  SOC.ACT_CODE_MIGR_PRE,
  SOC.ACT_OPER_ID_PRE,
  SOC.ACT_PRODUCT_ID_FINAL,
  SOC.ACT_SEG_COM_ID_FINAL,
  SOC.ACT_SEG_COM_AGG_ID_FINAL,
  SOC.ACT_CODE_MIGR_FINAL,
  SOC.ACT_OPER_ID_FINAL,
  SOC.ACT_TYPE_SERVICE_FINAL,
  SOC.ACT_TYPE_COMMANDE_ID,
  SOC.ACT_DELTA_TARIF,
  SOC.ACT_CD,
  SOC.ACT_REM_ID,
  SOC.ACT_FLAG_ACT_REM,
  SOC.ACT_FLAG_PEC_PERPVC,
  SOC.ACT_FLAG_PVC_REM,
  SOC.ACT_ACTE_VALO,
  SOC.ACT_ACTE_FAMILLE_KPI,
  SOC.ACT_PERIODE_ID,
  SOC.ACT_PERIODE_STATUS,
  SOC.ACT_PERIODE_CLOSURE_DT,
  SOC.ORIGIN_CD,
  SOC.AGENT_ID,
  SOC.AGENT_ID_UPD,
  SOC.AGENT_ID_UPD_DT,
  SOC.ORG_AGENT_IOBSP,
  SOC.AGENT_FIRST_NAME,
  SOC.AGENT_LAST_NAME,
  SOC.UNIFIED_SHOP_CD,
  SOC.ORG_SPE_CANAL_ID_MACRO,
  SOC.ORG_SPE_CANAL_ID,
  SOC.ORG_REM_CHANNEL_CD,
  SOC.ORG_CHANNEL_CD,
  SOC.ORG_SUB_CHANNEL_CD,
  SOC.ORG_SUB_SUB_CHANNEL_CD,
  SOC.ORG_GT_ACTIVITY,
  SOC.ORG_FIDELISATION,
  SOC.ORG_WEB_ACTIVITY,
  SOC.ORG_AUTO_ACTIVITY,
  SOC.ORG_EDO_ID,
  SOC.ORG_TYPE_EDO,
  SOC.ORG_EDO_IOBSP,
  SOC.ORG_FLAG_PLT_CONV,
  SOC.ORG_FLAG_TEAM_MKT,
  SOC.ORG_FLAG_TYPE_CMP,
  SOC.ORG_RESP_EDO_ID,
  SOC.ORG_RESP_TYPE_EDO,
  SOC.ORG_RESP_FLAG_PLT_CONV,
  SOC.ACTIVITY_CD,
  SOC.ACTIVITY_GROUPNG_CD,
  SOC.AUTO_ACTIVITY_IN,
  SOC.ORG_TYPE_CD,
  SOC.ORG_TEAM_TYPE_ID,
  SOC.ORG_TEAM_LEVEL_1_CD,
  SOC.ORG_TEAM_LEVEL_1_DS,
  SOC.ORG_TEAM_LEVEL_2_CD,
  SOC.ORG_TEAM_LEVEL_2_DS,
  SOC.ORG_TEAM_LEVEL_3_CD,
  SOC.ORG_TEAM_LEVEL_3_DS,
  SOC.ORG_TEAM_LEVEL_4_CD,
  SOC.ORG_TEAM_LEVEL_4_DS,
  SOC.WORK_TEAM_LEVEL_1_CD,
  SOC.WORK_TEAM_LEVEL_1_DS,
  SOC.WORK_TEAM_LEVEL_2_CD,
  SOC.WORK_TEAM_LEVEL_2_DS,
  SOC.WORK_TEAM_LEVEL_3_CD,
  SOC.WORK_TEAM_LEVEL_3_DS,
  SOC.WORK_TEAM_LEVEL_4_CD,
  SOC.WORK_TEAM_LEVEL_4_DS,
  SOC.CONFIRMATION_IN,
  SOC.CONCLDD_IN,
  SOC.COMPTTN_IN,
  SOC.COMPTTN_ID,
  SOC.PERNNT_IN,
  SOC.PERNNT_END_DT,
  SOC.PERNNT_MOTIF,
  SOC.PERNNT_CALC_END_DT,
  SOC.MIGRA_DT,
  SOC.MIGRA_NEXT_OFFRE,
  SOC.PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SOC.SEGMENT_DELIVERY_IN_PARK_DT,
  SOC.ORDER_CANCELING_DT,
  SOC.LINE_ID,
  SOC.MASTER_LINE_ID,
  SOC.CUST_TYPE_CD,
  SOC.MSISDN_ID,
  SOC.NDS_VALUE_DS,
  SOC.EXTERNAL_PARTY_ID,
  SOC.RES_VALUE_DS,
  SOC.PAR_ACCES_SERVICE,
  SOC.TAC_CD,
  SOC.IMEI_CD,
  SOC.IMSI_CD,
  SOC.HOM_START_DT,
  SOC.MOB_START_DT,
  SOC.I_SCORE_VALUE,
  SOC.I_SCORE_TRESHOLD,
  SOC.I_SCORE_IN,
  SOC.M_SCORE_VALUE,
  SOC.M_SCORE_TRESHOLD,
  SOC.M_SCORE_IN,
  SOC.OSCAR_VALUE,
  SOC.CUST_BU_TYPE_CD,
  SOC.CUST_BU_CD,
  SOC.ADDRESS_TYPE,
  SOC.ADDRESS_CONCAT_NM,
  SOC.POSTAL_CD,
  SOC.INSEE_CD,
  SOC.BU_CD,
  SOC.DEPARTMNT_ID,
  SOC.PAR_GEO_MACROZONE,
  SOC.PAR_UNIFIED_PARTY_ID,
  SOC.PAR_PARTY_REGRPMNT_ID,
  SOC.PAR_CID_ID,
  SOC.PAR_PID_ID,
  SOC.PAR_FIRST_IN,
  SOC.PAR_IRIS2000_CD,
  SOC.COMMARTICLE_RP_REFPRIX_CD,
  SOC.ACT_CA_LINE_AM,
  SOC.ACT_CA_TTC_AM,
  SOC.EAN_CD,
  SOC.SIM_CD,
  SOC.SIM_EAN_CD,
  SOC.ORG_RESP_ID,
  SOC.EAN_PREVIOUS_CD,
  SOC.TAC_PREVIOUS_CD,
  SOC.IMEI_PREVIOUS_CD,
  SOC.PCM_PREVIOUS_OFFRE_CD,
  SOC.PCM_COMMTMNT_PERIOD_NU,
  SOC.PCM_LEVEL_POINT_NU,
  SOC.PCM_OFFRE_CD,
  SOC.PCM_EFFCTV_NEXT_OFFRE_DT,
  SOC.PCM_TYPE_OFFRE_MOBILE_CD,
  SOC.PCM_POINT_UTIL_NU,
  SOC.PCM_BALANCE_POINT_NU,
  SOC.PCM_STATUT_POINT_CD,
  SOC.PCM_POINT_DUE_NU,
  SOC.PAR_ELIGIBLE_FIBER_IN,
  SOC.CHECK_INITIAL_STATUS_CD,
  SOC.CHECK_NAT_STATUS_CD,
  SOC.CHECK_NAT_COMMENT,
  SOC.CHECK_NAT_STATUS_LN,
  SOC.CHECK_LOC_STATUS_CD,
  SOC.CHECK_LOC_COMMENT,
  SOC.CHECK_LOC_STATUS_LN,
  SOC.CHECK_VALIDT_DT,
  SOC.ACT_END_UNIFIED_DT,
  SOC.ACT_END_UNIFIED_DS,
  SOC.ACT_CLOSURE_DT,
  SOC.ACT_CLOSURE_DS,
  SOC.HOT_IN,
  SOC.RUN_ID,
  SOC.CREATION_TS,
  SOC.LAST_MODIF_TS,
  SOC.FRESH_IN,
  SOC.COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED SOC 
Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} SRC
On  SOC.ACTE_ID = SRC.${SourceSoc}_ACTE_ID 
And SOC.INTRNL_SOURCE_ID = '${SourceEnrId}' 
And SOC.TYPE_SOURCE_ID In ( '${SourceEnrTyp}' )
Qualify Row_Number() Over (Partition by SOC.ACTE_ID Order by SOC.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim};
.if errorcode <> 0 then .quit 1;

-- Enrichissement Esclave depuis maître

Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
     ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} SRC
Set
  MASTER_ACTE_ID          = SRC.MASTER_ACTE_ID,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID,
  MASTER_FLAG             = 0,
  MASTER_NB_FOUND         = SRC.MASTER_NB_FOUND,
  OFFSET_NB               = SRC.OFFSET,
  CPLT_ACTE_ID            = Null,
  CPLT_INTRNL_SOURCE_ID   = Null,
  CPLT_IN                 = '${P_PIL_388}'
Where (1=1)
And CIB.ACTE_ID = SRC.SLAVE_ACTE_ID;
.if errorcode <> 0 then .quit 1;

-- On met a jour les maitres : attention il n'y a pas besoin de filtre sur l'omnicanal car l'update ne les impacte pas.
-- Mais il faut garder à l'esprit qu'on ne doit pas ecraser les champs omnicanal
Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET) = 1
) SRC
Set
  MASTER_ACTE_ID          = SRC.MASTER_ACTE_ID,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID,
  MASTER_FLAG             = 1,
  OFFSET_NB               = SRC.OFFSET,
  CPLT_ACTE_ID            = SRC.SLAVE_ACTE_ID,
  CPLT_INTRNL_SOURCE_ID   = SRC.SLAVE_SOURCE_ID,
  CPLT_IN                 = '${P_PIL_356}',
  RULE_ID                 = 32 
Where 
  (1=1)
  And CIB.ACTE_ID           = SRC.MASTER_ACTE_ID
;
.if errorcode <> 0 then .quit 1;



.quit 0

