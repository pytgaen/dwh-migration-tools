-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_HRF_T_ACTE.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Perimetre RF - ACTE - VALORISATION TAMPON ACTE -
--
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 08/08/13        DARTIGUE    Creation
-- 15/01/14        YZH         Modification des tables Refcom
-- 03/09/14        YZH         EVOL TERMINTN_VALUE_DS & VIO
-- 23/02/2016      MDE         Evol Pilcom Digital  
-- 01/06/2016      MDE         Modif Refcom  KNB_PCO_REFCOM   
-- 12/01/2017      HLA         Ventes associées   
-- 05/12/2017      HOB         Modif IOBSP
-- 23/09/2019      EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF
---------------------------------------------------------------------------------

-- PURGE DU TAMPON

DELETE FROM      ${KNB_PCO_TMP}.INT_T_ACTE_HRF ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_T_ACTE_HRF
                  (
                    ACTE_ID_GEN                   
                  , ACTE_ID                       
                  , EXTERNAL_ACTE_ID              
                  , TYPE_SOURCE_ID                
                  , INT_ID                        
                  , INT_DETL_ID                   
                  , INT_TYPE                      
                  , INT_CREATED_BY_TS             
                  , INT_CREATED_BY_DT             
                  , INT_SRC                       
                  , INT_RESULT                    
                  , INT_REASON                    
                  , INT_DETL_SRC                  
                  , DRK_PARTY_ID                  
                  , FREG_PARTY_ID                 
                  , EUREKA_PARTY_ID               
                  , PAR_PARC_CD                   
                  , PAR_WKNESS_SCO                
                  , PAR_STORE_CD                  
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD                
                  , FLAG_HD
                  , ORG_CHANNEL_CD                
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD            
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY
                  , ORG_FIDELISATION
                  , ORG_WEB_ACTIVITY
                  , ORG_AUTO_ACTIVITY
                  , ORG_EDO_ID
                  , ORG_EDO_DS
                  , ORG_TYPE_EDO
                  , ORG_EDO_IOBSP
                  , ORG_FLAG_PLT_CONV
                  , ORG_FLAG_TEAM_MKT
                  , ORG_FLAG_TYPE_CMP
                  , ORG_EDO_FATHR_ID_NIV1
                  , ORG_EDO_FATHR_DS_NIV1
                  , ORG_EDO_FATHR_ID_NIV2
                  , ORG_EDO_FATHR_DS_NIV2
                  , ORG_EDO_FATHR_ID_NIV3
                  , ORG_EDO_FATHR_DS_NIV3
                  , AUTO_ACTIVITY_IN              
                  , ORG_TEAM_TYPE_ID              
                  , AGENT_LOGIN_CD                
                  , AGENT_FIRST_NAME              
                  , AGENT_LAST_NAME               
                  , EXTERNAL_TEAM_CD              
                  , EXTERNAL_TEAM_NM              
                  , O3_ACTIVE_TEAM_CD             
                  , O3_RATTACHEMENT_TEAM_CD       
                  , INT_DETL_HABLT                
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID               
                  , ID_FACADE                     
                  , EXTERNAL_PRODUCT_ID_FINAL     
                  , INTRNL_PRDCT_ID_OPENCAT_INI   
                  , EXTERNAL_GAM_PRODUCT_ID       
                  , IND_GAM_TYPE                  
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE
                  , IND_TECH_DMC_THRESHOLD
                  , NEW_OC_OCATID                 
                  , OLD_OC_OCATID                 
                  , LINE_ID                       
                  , MASTER_LINE_ID                
                  , LINE_TYPE                     
                  , LINE_START_DT                 
                  , OPERATOR_PROVIDER_ID          
                  , SERVICE_ACCESS_ID             
                  , PARTY_KNB_ID                  
                  , TERMINTN_VALUE_DS             
                  , EXTERNAL_SYSTEM_ID            
                  , EXTERNAL_PARTY_ID             
                  , FREG_PARTY_EXTERNL_ID         
                  , BSS_PARTY_EXTERNL_ID          
                  , RES_VALUE_DS                  
                  , PARTY_REGRPMNT_ID             
                  , SIRET_CODE_CD                 
                  , LAST_NAME_NM                  
                  , FIRST_NAME_NM                 
                  , NAME_NM                       
                  , INST_ADDRESS1_NM              
                  , INST_ADDRESS2_NM              
                  , INST_ADDRESS3_NM              
                  , INST_ADDRESS4_NM              
                  , INST_ADDRESS5_NM              
                  , INST_ADDRESS6_NM              
                  , MAIN_ADDRESS1_NM              
                  , MAIN_ADDRESS2_NM              
                  , MAIN_ADDRESS3_NM              
                  , MAIN_ADDRESS4_NM              
                  , MAIN_ADDRESS5_NM              
                  , MAIN_ADDRESS6_NM              
                  , BILL_ADDRESS1_NM              
                  , BILL_ADDRESS2_NM              
                  , BILL_ADDRESS3_NM              
                  , BILL_ADDRESS4_NM              
                  , BILL_ADDRESS5_NM              
                  , BILL_ADDRESS6_NM              
                  , INSEE_NB                      
                  , POSTAL_CD                     
                  , DEPARTMNT_ID                  
                  , PAR_FIBER_IN         
                  , PAR_GEO_MACROZONE                         
                  , PAR_UNIFIED_PARTY_ID          
                  , PAR_PARTY_REGRPMNT_ID             
                  , PAR_IRIS2000_CD              
                  , PAR_BU_CD
                  , CITY_LN
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , ACT_CD                        
                  , ACT_REM_ID                    
                  , ACT_FLAG_ACT_REM
                  , ACT_ACTE_VALO
                  , ACT_FLAG_PEC_PERPVC
                  , ACT_ACTE_FAMILLE_KPI              
                  , ACT_PRODUCT_ID_FINAL          
                  , ACT_SEG_COM_ID_FINAL          
                  , ACT_SEG_COM_AGG_ID_FINAL      
                  , ACT_CODE_MIGR_FINAL           
                  , ACT_MIGR_REGRPT_ID_FINAL      
                  , ACT_PRODUCT_ID_PRE            
                  , ACT_SEG_COM_ID_PRE            
                  , ACT_SEG_COM_AGG_ID_PRE        
                  , ACT_CODE_MIGR_PRE             
                  , ACT_MIGR_REGRPT_ID_PRE        
                  , ACT_TYPE_COMMANDE_ID          
                  , ACT_DELTA_TARIF               
                  , ACT_UNITE_CD				  
                  , ACT_PERIODE_ID                
                  , ACT_PERIODE_STATUS            
                  , ACT_PERIODE_CLOSURE_DT        
                  , ACT_TYPE_SERVICE_FINAL        
                  , CONTRCT_DT_SIGN_PREC          
                  , CONTRCT_DT_FIN_PREC           
                  , CONTRCT_DT_SIGN_POST          
                  , CONTRCT_DUREE_ENG             
                  , CONTRCT_UNIT_ENG              
                  , CONFIRMATION_IN               
                  , CONFIRMATION_DT               
                  , CONFIRMATION_CALC_FIN_DT      
                  , DELIVERY_IN                   
                  , DELIVERY_DT                   
                  , DELIVERY_CALC_FIN_DT          
                  , PERENNITE_IN                  
                  , PERENNITE_FIN_DT              
                  , PERENNITE_CALC_FIN_DT         
                  , PERENNITE_PVC_IN                  
                  , PERENNITE_PVC_FIN_DT              
                  , PERENNITE_PVC_CALC_FIN_DT         
                  , CONCURENCE_IN                 
                  , CONCURENCE_CONCLU_IN          
                  , CONCURENCE_ID                 
                  , DELIVERY_ONTIME_IN            
                  , AGENT_ID_UPD                  
                  , AGENT_ID_UPD_DT               
                  , ORG_AGENT_IOBSP
                  , CHECK_INITIAL_STATUS_CD       
                  , CHECK_NAT_STATUS_CD           
                  , CHECK_NAT_COMMENT             
                  , CHECK_NAT_STATUS_LN           
                  , CHECK_LOC_STATUS_CD           
                  , CHECK_LOC_COMMENT             
                  , CHECK_LOC_STATUS_LN           
                  , CHECK_VALIDT_DT
                  , CLOSURE_DT               
                  , CREATION_TS                   
                  , LAST_MODIF_TS                 
                  , FRESH_IN                      
                  , COHERENCE_IN                  
                  , HOT_IN                        
                  , RUN_ID                        
                  )
SELECT             CASE WHEN INT_W_ACTE_HRF_ENRI_REFCOM.ACTE_ID IS NOT NULL
                 -- TRACAGE MANUEL:
                 -- (1) DONT LE PRODUIT ET LA GAMME SONT VALORISES
                 -- (2) DONT LE RESULTAT DE DETAIL DE CONTACT RFORCE NE CORRESPOND PAS A UNE ERREUR
                        THEN INT_W_ACTE_HRF_ENRI_REFCOM.ACTE_ID_GEN
                 -- TRACAGE AUTOMATIQUE
                 -- OU TRACAGE MANUEL DONT LE PRODUIT OU LA GAMME NE SONT PAS VALORISES
                 -- OU TRACAGE MANUEL DONT LE RESULTAT DE DETAIL DE CONTACT RFORCE CORRESPOND A UNE ERREUR
                        ELSE INT_W_PLACEMENT_EXTRCT_HRF.ACTE_ID * (-1)
                   END                                                                                           AS ACTE_ID_GEN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ACTE_ID                                                            AS ACTE_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_ACTE_ID                                                   AS EXTERNAL_ACTE_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.TYPE_SOURCE_ID                                                     AS TYPE_SOURCE_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_ID                                                             AS INT_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_DETL_ID                                                        AS INT_DETL_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_TYPE                                                           AS INT_TYPE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_CREATED_BY_TS                                                  AS INT_CREATED_BY_TS
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_CREATED_BY_DT                                                  AS INT_CREATED_BY_DT
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_SRC                                                            AS INT_SRC
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_RESULT                                                         AS INT_RESULT
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_REASON                                                         AS INT_REASON
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_DETL_SRC                                                       AS INT_DETL_SRC
               ,   INT_W_PLACEMENT_EXTRCT_HRF.DRK_PARTY_ID                                                       AS DRK_PARTY_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.FREG_PARTY_ID                                                      AS FREG_PARTY_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EUREKA_PARTY_ID                                                    AS EUREKA_PARTY_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_PARC_CD                                                        AS PAR_PARC_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_WKNESS_SCO                                                     AS PAR_WKNESS_SCO
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_STORE_CD                                                       AS PAR_STORE_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.REM_CHANNEL_CD                                                     AS REM_CHANNEL_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_REM_CHANNEL_CD                                                 AS ORG_REM_CHANNEL_CD
               ,   V_CAT_R_KPI_PILCOM.HUMAINDIGITAL                                                              AS FLAG_HD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_CHANNEL_CD                                                     AS ORG_CHANNEL_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_SUB_CHANNEL_CD                                                 AS ORG_SUB_CHANNEL_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_SUB_SUB_CHANNEL_CD                                             AS ORG_SUB_SUB_CHANNEL_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ACTIVITY_CD                                                        AS ACTIVITY_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_GT_ACTIVITY                                                    AS ORG_GT_ACTIVITY
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_FIDELISATION                                                   AS ORG_FIDELISATION
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_WEB_ACTIVITY                                                   AS ORG_WEB_ACTIVITY
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_AUTO_ACTIVITY                                                  AS ORG_AUTO_ACTIVITY
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_ID                                                         AS ORG_EDO_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_DS                                                         AS ORG_EDO_DS
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_TYPE_EDO                                                       AS ORG_TYPE_EDO
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_IOBSP                                                      AS ORG_EDO_IOBSP
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_FLAG_PLT_CONV                                                  AS ORG_FLAG_PLT_CONV
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_FLAG_TEAM_MKT                                                  AS ORG_FLAG_TEAM_MKT
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_FLAG_TYPE_CMP                                                  AS ORG_FLAG_TYPE_CMP
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_FATHR_ID_NIV1                                              AS ORG_EDO_FATHR_ID_NIV1
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_FATHR_DS_NIV1                                              AS ORG_EDO_FATHR_DS_NIV1
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_FATHR_ID_NIV2                                              AS ORG_EDO_FATHR_ID_NIV2
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_FATHR_DS_NIV2                                              AS ORG_EDO_FATHR_DS_NIV2
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_FATHR_ID_NIV3                                              AS ORG_EDO_FATHR_ID_NIV3
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_EDO_FATHR_DS_NIV3                                              AS ORG_EDO_FATHR_DS_NIV3
               ,   INT_W_PLACEMENT_EXTRCT_HRF.AUTO_ACTIVITY_IN                                                   AS AUTO_ACTIVITY_IN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_TEAM_TYPE_ID                                                   AS ORG_TEAM_TYPE_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.AGENT_LOGIN_CD                                                     AS AGENT_LOGIN_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.AGENT_FIRST_NAME                                                   AS AGENT_FIRST_NAME
               ,   INT_W_PLACEMENT_EXTRCT_HRF.AGENT_LAST_NAME                                                    AS AGENT_LAST_NAME
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_TEAM_CD                                                   AS EXTERNAL_TEAM_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_TEAM_NM                                                   AS EXTERNAL_TEAM_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.O3_ACTIVE_TEAM_CD                                                  AS O3_ACTIVE_TEAM_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.O3_RATTACHEMENT_TEAM_CD                                            AS O3_RATTACHEMENT_TEAM_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_DETL_HABLT                                                     AS INT_DETL_HABLT
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INT_CANAL_VENTE                                                    AS INT_CANAL_VENTE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_CANAL_ID                                                       AS ORG_CANAL_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ID_FACADE                                                          AS ID_FACADE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_PRODUCT_ID_FINAL                                          AS EXTERNAL_PRODUCT_ID_FINAL
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.INTRNL_PRDCT_ID_OPENCAT_INI                                        AS INTRNL_PRDCT_ID_OPENCAT_INI
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_GAM_PRODUCT_ID                                            AS EXTERNAL_GAM_PRODUCT_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IND_GAM_TYPE                                                       AS IND_GAM_TYPE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IND_INT_RESULT_ERR                                                 AS IND_INT_RESULT_ERR
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IND_DMC_COH_DOMAIN                                                 AS IND_DMC_COH_DOMAIN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IND_TECH_DMC_THRESHOLD_TYPE                                        AS IND_TECH_DMC_THRESHOLD_TYPE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IND_TECH_DMC_THRESHOLD                                             AS IND_TECH_DMC_THRESHOLD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.NEW_OC_OCATID                                                      AS NEW_OC_OCATID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.OLD_OC_OCATID                                                      AS OLD_OC_OCATID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.LINE_ID                                                            AS LINE_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MASTER_LINE_ID                                                     AS MASTER_LINE_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.LINE_TYPE                                                          AS LINE_TYPE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.LINE_START_DT                                                      AS LINE_START_DT
               ,   INT_W_PLACEMENT_EXTRCT_HRF.OPERATOR_PROVIDER_ID                                               AS OPERATOR_PROVIDER_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.SERVICE_ACCESS_ID                                                  AS SERVICE_ACCESS_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PARTY_KNB_ID                                                       AS PARTY_KNB_ID
               ,   COALESCE(INT_W_PLACEMENT_EXTRCT_HRF.TERMINTN_VALUE_DS,'0000000000')                           AS TERMINTN_VALUE_DS
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_SYSTEM_ID                                                 AS EXTERNAL_SYSTEM_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.EXTERNAL_PARTY_ID                                                  AS EXTERNAL_PARTY_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.FREG_PARTY_EXTERNL_ID                                              AS FREG_PARTY_EXTERNL_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BSS_PARTY_EXTERNL_ID                                               AS BSS_PARTY_EXTERNL_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.RES_VALUE_DS                                                       AS RES_VALUE_DS
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PARTY_REGRPMNT_ID                                                  AS PARTY_REGRPMNT_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.SIRET_CODE_CD                                                      AS SIRET_CODE_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.LAST_NAME_NM                                                       AS LAST_NAME_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.FIRST_NAME_NM                                                      AS FIRST_NAME_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.NAME_NM                                                            AS NAME_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INST_ADDRESS1_NM                                                   AS INST_ADDRESS1_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INST_ADDRESS2_NM                                                   AS INST_ADDRESS2_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INST_ADDRESS3_NM                                                   AS INST_ADDRESS3_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INST_ADDRESS4_NM                                                   AS INST_ADDRESS4_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INST_ADDRESS5_NM                                                   AS INST_ADDRESS5_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INST_ADDRESS6_NM                                                   AS INST_ADDRESS6_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MAIN_ADDRESS1_NM                                                   AS MAIN_ADDRESS1_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MAIN_ADDRESS2_NM                                                   AS MAIN_ADDRESS2_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MAIN_ADDRESS3_NM                                                   AS MAIN_ADDRESS3_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MAIN_ADDRESS4_NM                                                   AS MAIN_ADDRESS4_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MAIN_ADDRESS5_NM                                                   AS MAIN_ADDRESS5_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.MAIN_ADDRESS6_NM                                                   AS MAIN_ADDRESS6_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BILL_ADDRESS1_NM                                                   AS BILL_ADDRESS1_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BILL_ADDRESS2_NM                                                   AS BILL_ADDRESS2_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BILL_ADDRESS3_NM                                                   AS BILL_ADDRESS3_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BILL_ADDRESS4_NM                                                   AS BILL_ADDRESS4_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BILL_ADDRESS5_NM                                                   AS BILL_ADDRESS5_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.BILL_ADDRESS6_NM                                                   AS BILL_ADDRESS6_NM
               ,   INT_W_PLACEMENT_EXTRCT_HRF.INSEE_NB                                                           AS INSEE_NB
               ,   INT_W_PLACEMENT_EXTRCT_HRF.POSTAL_CD                                                          AS POSTAL_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.DEPARTMNT_ID                                                       AS DEPARTMNT_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_FIBER_IN                                                       AS PAR_FIBER_IN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_GEO_MACROZONE                                                  AS PAR_GEO_MACROZONE               
               ,   INT_W_PLACEMENT_EXTRCT_HRF.UNIFIED_PARTY_ID                                                   AS UNIFIED_PARTY_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PARTY_REGRPMNT_ID                                                  AS PARTY_REGRPMNT_ID
               
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_IRIS2000_CD                                                    AS PAR_IRIS2000_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.PAR_BU_CD                                                          AS PAR_BU_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.CITY_LN                                                            AS CITY_LN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.SCORE_VALUE                                                        AS SCORE_VALUE
               ,   INT_W_PLACEMENT_EXTRCT_HRF.SCORE_THRESHOLD                                                    AS SCORE_THRESHOLD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.SCORE_IN                                                           AS SCORE_IN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.TAC_ID                                                             AS TAC_ID
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IMEI_CD                                                            AS IMEI_CD
               ,   INT_W_PLACEMENT_EXTRCT_HRF.IMSI_CD                                                            AS IMSI_CD
               ,   CASE INT_W_ACTE_HRF_ENRI_REFCOM.ACTE_TYPOLOGIE
                  -- IDENTIFIANT DE PRODUIT EXTERNE ABSENT DU REFERENTIEL COMMERCIAL
                        WHEN 1 THEN '${P_PIL_224}'
                  -- DATE DU TRACAGE ABSENTE DU REFERENTIEL COMMERCIAL
                        WHEN 2 THEN '${P_PIL_217}'
                  -- PRODUIT EXTERNE ASSOCIE A UN SEGMENT
                        WHEN 3 THEN '${P_PIL_221}'
                  -- PRODUIT EXTERNE ASSOCIE A UN REGROUPEMENT NON SUIVI ET CORRESPONDANT A UN PLACEMENT
                        WHEN 4 THEN COALESCE(V_CAT_R_MATRICE_PILCOM.ACTE_ID,  '${P_PIL_220}')
                  -- PRODUIT EXTERNE ASSOCIE A UN REGROUPEMENT NON SUIVI ET NE CORRESPONDANT PAS A UN PLACEMENT
                        WHEN 5 THEN '${P_PIL_238}'
                  -- PRODUIT EXTERNE ASSOCIE A UN SEGMENT ET UN REGROUPEMENT SUIVIS ET CORRESPONDANT A UN PLACEMENT
                        WHEN 6 THEN  COALESCE(V_CAT_R_MATRICE_PILCOM.ACTE_ID,  '${P_PIL_220}')
                  -- LIGNE FIXE
                        WHEN 7 THEN  COALESCE(V_CAT_R_MATRICE_PILCOM.ACTE_ID,  '${P_PIL_240}')
                  -- IDENTIFICATION DE LA LIGNE DMC EN ECHEC
                        WHEN 8 THEN '${P_PIL_239}'
                  -- IDENTIFICATION DU PARC PRECEDENT EN ECHEC
                        WHEN 9 THEN '${P_PIL_237}'
                  -- PRODUIT PRECEDENT ASSOCIE A UN REGROUPEMENT DE MIGRATION NON SUIVI
                        WHEN 10 THEN '${P_PIL_241}'
                  -- MIGRATION DU PRODUIT PRECEDENT NON PARAMETRE
                        WHEN 11 THEN '${P_PIL_222}'
                  -- IDENTIFICATION DU PRODUIT PRECEDENT
                        WHEN 12 THEN COALESCE(V_CAT_R_MATRICE_PILCOM.ACTE_ID,  '${P_PIL_220}')
                  -- COUPLE (PRODUIT RFORCE, RESULTAT DE DETAIL DE CONTACT) ABSENT DU REFERENTIEL COMMERCIAL
                        WHEN 13 THEN '${P_PIL_248}'
                  -- DEMENAGEMENT ISO-OFFRE
                        WHEN 14 THEN COALESCE(V_CAT_R_MATRICE_PILCOM.ACTE_ID,  '${P_PIL_220}')
                   -- VIO
                        WHEN 15 THEN COALESCE(V_CAT_R_MATRICE_PILCOM.ACTE_ID,  '${P_PIL_220}')
                  -- TRACAGE DONT LE PRODUIT OU LA GAMME N'EST PAS VALORISE                              
                  -- TRACAGE DONT LE PRODUIT OU LA GAMME N'EST PAS VALORISE
                  -- OU TRACAGE DONT LE RESULTAT DE DETAIL DE CONTACT RFORCE CARACTERISE UNE ERREUR
                  -- OU TRACAGE AUTOMATIQUE 
                        ELSE '${P_PIL_067}'
                   END                                                                                    AS ACT_CD
               ,   COALESCE(V_CAT_R_ACTE_PILCOM.ACTE_REM_ID, '${P_PIL_067}')                              AS ACT_REM_ID
               ,   COALESCE(V_CAT_R_ACTE_PILCOM.FLAG_ACT_REM, '${P_PIL_101}')                             AS ACT_FLAG_ACT_REM 
               ,   CASE
                     -- Unite = CA  
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_490}' 
                          THEN   Null
                     -- Unite = NB  
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_620}' 
                          THEN   V_CAT_R_ACTE_PILCOM.ACTE_VALO
                     -- Unite = MKT
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_623}' 
                          THEN   ( ACT_DELTA_TARIF * V_CAT_R_ACTE_PILCOM.TAUX_MARGE )
                     -- Unite = CA_CALIPSO (TMX)  
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_622}' 
                          THEN   0
                     ELSE Null
                   END                                                                                    AS ACT_ACTE_VALO
               ,   V_CAT_R_ACTE_PILCOM.FLAG_PEC_PERPVC                                                    AS ACT_FLAG_PEC_PERPVC
               ,   V_CAT_R_ACTE_PILCOM.ACTE_FAMILLE_KPI                                                   AS ACT_ACTE_FAMILLE_KPI                                                       
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.PRODUCT_ID_FINAL                                            AS ACT_PRODUCT_ID_FINAL
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.SEG_COM_ID_FINAL                                            AS ACT_SEG_COM_ID_FINAL
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.SEG_COM_AGG_ID_FINAL                                        AS ACT_SEG_COM_AGG_ID_FINAL
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CODE_MIGRATION_FINAL                                        AS ACT_CODE_MIGR_FINAL
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.MIGR_REGROUPEMENT_ID_FINAL                                  AS ACT_MIGR_REGRPT_ID_FINAL
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.PRODUCT_ID_INITIAL                                          AS ACT_PRODUCT_ID_PRE
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.SEG_COM_ID_INITIAL                                          AS ACT_SEG_COM_ID_PRE
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.SEG_COM_AGG_ID_INITIAL                                      AS ACT_SEG_COM_AGG_ID_PRE
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CODE_MIGRATION_INITIAL                                      AS ACT_CODE_MIGR_PRE
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.MIGR_REGROUPEMENT_ID_INITIAL                                AS ACT_MIGR_REGRPT_ID_PRE
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.TYPE_COMMANDE_ID                                            AS ACT_TYPE_COMMANDE_ID
               ,   CASE
                     -- Unite = CA  
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_490}' 
                          THEN   Null
                     -- Unite = NB  
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_620}' 
                          THEN   Null
                     -- Unite = MKT
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_623}' 
                          THEN   V_CAT_R_ACTE_PILCOM.CA_MARKETING
                     -- Unite = CA_CALIPSO (TMX)  
                     WHEN V_CAT_R_ACTE_PILCOM.UNITE_CD ='${P_PIL_622}' 
                          THEN   0
                     ELSE Null
                   END                                                                                    AS ACT_DELTA_TARIF            
			   ,   V_CAT_R_ACTE_PILCOM.UNITE_CD                                                           AS ACT_UNITE_CD
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.PERIODE_ID                                                  AS ACT_PERIODE_ID
               ,   Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                                              as ACT_PERIODE_STATUS            
               ,   EtatPeriode.PERIODE_CLOSURE_DT                                                         as ACT_PERIODE_CLOSURE_DT              
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.TYPE_SERVICE_FINAL                                          AS ACT_TYPE_SERVICE_FINAL
               ,   NULL                                                                                   AS CONTRCT_DT_SIGN_PREC        
               ,   NULL                                                                                   AS CONTRCT_DT_FIN_PREC         
               ,   NULL                                                                                   AS CONTRCT_DT_SIGN_POST        
               ,   NULL                                                                                   AS CONTRCT_DUREE_ENG           
               ,   NULL                                                                                   AS CONTRCT_UNIT_ENG            
               ,   NULL                                                                                   AS CONFIRMATION_IN             
               ,   NULL                                                                                   AS CONFIRMATION_DT             
               ,   NULL                                                                                   AS CONFIRMATION_CALC_FIN_DT    
               ,   NULL                                                                                   AS DELIVERY_IN                 
               ,   NULL                                                                                   AS DELIVERY_DT                 
               ,   NULL                                                                                   AS DELIVERY_CALC_FIN_DT        
               ,   NULL                                                                                   AS PERENNITE_IN                
               ,   NULL                                                                                   AS PERENNITE_FIN_DT            
               ,   NULL                                                                                   AS PERENNITE_CALC_FIN_DT
               ,   NULL                                                                                   AS PERENNITE_PVC_IN
               ,   NULL                                                                                   AS PERENNITE_PVC_FIN_DT
               ,   NULL                                                                                   AS PERENNITE_PVC_CALC_FIN_DT       
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CONCURENCE_IN                                               AS CONCURENCE_IN
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CONCURENCE_CONCLU_IN                                        AS CONCURENCE_CONCLU_IN
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CONCURENCE_ID                                               AS CONCURENCE_ID
               ,   NULL                                                                                   AS DELIVERY_ONTIME_IN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.AGENT_LOGIN_CD                                              AS AGENT_ID_UPD
               ,   NULL                                                                                   AS AGENT_ID_UPD_DT               
               ,   INT_W_PLACEMENT_EXTRCT_HRF.ORG_AGENT_IOBSP                                             AS ORG_AGENT_IOBSP               
               ,   NULL                                                                                   AS CHECK_INITIAL_STATUS_CD       
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_NAT_STATUS_CD                                         AS CHECK_NAT_STATUS_CD
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_NAT_COMMENT                                           AS CHECK_NAT_COMMENT
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_NAT_STATUS_LN                                         AS CHECK_NAT_STATUS_LN
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_LOC_STATUS_CD                                         AS CHECK_LOC_STATUS_CD
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_LOC_COMMENT                                           AS CHECK_LOC_COMMENT
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_LOC_STATUS_LN                                         AS CHECK_LOC_STATUS_LN
               ,   INT_W_ACTE_HRF_ENRI_REFCOM.CHECK_VALIDT_DT                                             AS CHECK_VALIDT_DT
               ,   NULL                                                                                   AS CLOSURE_DT               
               ,   CAST('${KNB_MICRO_BATCH_TS}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}')       AS CREATION_TS
               ,   CAST('${KNB_MICRO_BATCH_TS}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}')       AS LAST_MODIF_TS
               ,   1                                                                                      AS FRESH_IN
               ,   0                                                                                      AS COHERENCE_IN
               ,   1                                                                                      AS HOT_IN
               ,   INT_W_PLACEMENT_EXTRCT_HRF.RUN_ID                                                      AS RUN_ID
FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_EXTRCT_HRF                                                          INT_W_PLACEMENT_EXTRCT_HRF
-- ENRICHISSEMENT DES TRACAGES MANUELS AVEC LES ATTRIBUTS PRODUITS ISSUS DU REFERENTIEL COMMERCIAL
LEFT JOIN        ${KNB_PCO_TMP}.INT_W_ACTE_HRF_ENRI_REFCOM                                                              INT_W_ACTE_HRF_ENRI_REFCOM
ON                 INT_W_PLACEMENT_EXTRCT_HRF.ACTE_ID                                                   =         INT_W_ACTE_HRF_ENRI_REFCOM.ACTE_ID
-- ENRICHISSEMENT AVEC LES ATTRIBUTS ACTES DU REFERENTIEL COMMERCIAL
LEFT JOIN        ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM                                                       V_CAT_R_MATRICE_PILCOM
ON                 1                                                                               =         1
AND                INT_W_ACTE_HRF_ENRI_REFCOM.PERIODE_ID                                                      =         V_CAT_R_MATRICE_PILCOM.PERIODE_ID
AND                INT_W_ACTE_HRF_ENRI_REFCOM.TYPE_COMMANDE_ID                                                =         V_CAT_R_MATRICE_PILCOM.TYPE_COMMANDE_ID
AND                COALESCE(INT_W_ACTE_HRF_ENRI_REFCOM.SEG_COM_ID_INITIAL, '${P_PIL_211}')                    =         COALESCE(V_CAT_R_MATRICE_PILCOM.SEG_COM_ID_INI, '${P_PIL_211}')
AND                INT_W_ACTE_HRF_ENRI_REFCOM.SEG_COM_ID_FINAL                                                =         V_CAT_R_MATRICE_PILCOM.SEG_COM_ID_FINAL
AND                INT_W_ACTE_HRF_ENRI_REFCOM.TYPE_COMMANDE_ID                                                =         V_CAT_R_MATRICE_PILCOM.TYPE_COMMANDE_ID
AND                V_CAT_R_MATRICE_PILCOM.CATEGORIE_CLIENT_ID                                      =      '${P_PIL_104}'
AND                V_CAT_R_MATRICE_PILCOM.CLOSURE_DT                                               IS NULL
AND                V_CAT_R_MATRICE_PILCOM.CURRENT_IN                                               =         1
LEFT JOIN        ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM                                                          V_CAT_R_ACTE_PILCOM
ON                 1                                                                               =         1
AND                V_CAT_R_MATRICE_PILCOM.PERIODE_ID                                               =         V_CAT_R_ACTE_PILCOM.PERIODE_ID
AND                V_CAT_R_MATRICE_PILCOM.ACTE_ID                                                  =         V_CAT_R_ACTE_PILCOM.ACTE_ID
AND                V_CAT_R_ACTE_PILCOM.CLOSURE_DT                                                  IS NULL
AND                V_CAT_R_ACTE_PILCOM.CURRENT_IN                                                  =         1
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
On                 INT_W_ACTE_HRF_ENRI_REFCOM.PERIODE_ID                                           = EtatPeriode.PERIODE_ID
And                EtatPeriode.CURRENT_IN                                                          = 1
And                EtatPeriode.FRESH_IN                                                            = 1
And                EtatPeriode.CLOSURE_DT                                                          Is Null
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM                                                            V_CAT_R_KPI_PILCOM
On                 V_CAT_R_KPI_PILCOM.PERIODE_ID                                                   = V_CAT_R_ACTE_PILCOM.PERIODE_ID
And                V_CAT_R_KPI_PILCOM.FAMILLE_KPI_ID                                               = V_CAT_R_ACTE_PILCOM.ACTE_FAMILLE_KPI
And                V_CAT_R_KPI_PILCOM.CURRENT_IN                                                   = 1
And                V_CAT_R_KPI_PILCOM.CLOSURE_DT                                                   Is Null
WHERE              1                                                                               =         1
;

.IF ERRORCODE <> 0 THEN .QUIT 1;










