--$HEADER: mm2pco/current/sql/ATP_NSH_Placement_Cold_FusionEnrichie_Stepe2.sql 13_05#19 23-OCT-2019 10:35:40 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_FusionEnrichie_Stepe2.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'alimentation TMP acte
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 27/03/2014      MCA         Creation
-- 31/07/2014      MCA         Indus
-- 08/12/2014      MCA         Modification et ajout champs perform
-- 07/05/2015      MDE         Correction: Canal de rem QC989 "Exclus" au lieu de "Exclu"
-- 27/01/2016      OCH         Modif Digital
-- 27/01/2016      OCH         Ajout STW
-- 25/04/2016      OCH         Ajout XSELL
-- 28/06/2016      GMA         Modif axe canal MultiCanal
-- 05/01/2017      HOB         Modif Ajout Champs VA
-- 04/12/2017      MEL         IOBSP
-- 23/01/2018      HOB         Evol REFONTE S2W  
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 11/10/2019      TCL         Modif pour décomm 6PO
--------------------------------------------------------------------------------

.set width 2500;

--------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_NSH All;
.if errorcode <> 0 then .quit 1
--------------------------------------------------------------------------------

-- Insertion dans la table TMP cold final 
Insert into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_NSH
(
  ACTE_ID                                   ,
  ORDER_DEPOSIT_TS                          ,
  ORDER_DEPOSIT_DT                          ,
  INTRNL_SOURCE_ID                          ,
  APPLI_SOURCE_ID                           ,
  EXTERNAL_ORDER_ID_SPO                     ,
  ORDER_TYPE                                ,
  EXTERNAL_ORDER_ID                         ,
  VAD_ID                                    ,
  OPAL_ID                                   ,
  VAD_HOM_ID                                ,
  TYP_ORDR_CD                               ,
  ORDR_TYPLG_DS                             ,
  ORDER_LINE_TYPE                           ,
  EXTERNAL_PRODUCT_ID                       ,
  EXTERNAL_PRODUCT_ID_PRE                   ,
  EXTERNAL_PRODUCT_ID_OT                    ,
  EXTERNAL_PRODUCT_ID_OT_OP                 ,
  CONTRCT_DUREE_ENG_MOB                     ,
  CONTRCT_UNIT_ENG_MOB                      ,
  ORG_AGENT_ID                              ,
  EXTNL_VAL_COD_CD                          ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  SHOP_COD_DS                               ,
  SHOP_ADV_COD_DS                           ,
  BRAND_SHOP_DS                             ,
  --
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  --
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  NETWRK_TYP_EDO_ID                         ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_REF_TRAV                              ,
  FLAG_TYPE_GEO                             ,
  FLAG_TYPE_CPT_NTK                         ,
  FLAG_TYPE_PTN_NTK                         ,
  PAR_ADV_CLIENT_NU                         ,
  PAR_ADV_DOSSIER_NU                        ,
  PRESFACT_CO_PRECED                        ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  PAR_DEPARTMNT_ID                          ,
  PAR_BU_CD                                 ,
  PAR_POSTAL_CD                             ,
  PAR_INSEE_CD                              ,
  PAR_GEO_MACROZONE                         ,
  PAR_UNIFIED_PARTY_ID                      ,
  PAR_PARTY_REGRPMNT_ID                     , 
  PAR_CID_ID                                ,
  PAR_PID_ID                                ,
  PAR_FIRST_IN                              ,
  ORG_AGENT_IOBSP                           ,
  ORG_EDO_IOBSP                             ,
  PAR_IRIS2000_CD                           ,
  PAR_FIBER_IN                              ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_SIRET                                 ,
  PAR_MARKET_SEG                            ,
  PAR_TYPE                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_MOB_IMSI                              ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  PAR_SCORE_NU_MOB                          ,
  PAR_SCORE_IN_MOB                          ,
  PAR_TRESHOLD_NU_MOB                       ,
  PAYMNT_FORMLTN_ID                         ,
  MONTHL_PRIC                               ,
  MONTHL_PERD                               ,
  QUANTT_QT                                 ,
  ID_QUANTITE                               ,
  AMNT_HT_ARTCL_AM                          ,
  RUN_ID                                    ,
  HOT_IN                                    ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN
)
Select
  NewPl.ACTE_ID                                           as ACTE_ID                  ,
  NewPl.ORDER_DEPOSIT_TS                                  as ORDER_DEPOSIT_TS         ,
  NewPl.ORDER_DEPOSIT_DT                                  as ORDER_DEPOSIT_DT         ,
  NewPl.INTRNL_SOURCE_ID                                  as INTRNL_SOURCE_ID         ,
  NewPl.APPLI_SOURCE_ID                                   as APPLI_SOURCE_ID          ,
  NewPl.EXTERNAL_ORDER_ID_SPO                             as EXTERNAL_ORDER_ID_SPO    ,
  NewPl.ORDER_TYPE                                        as ORDER_TYPE               ,
  NewPl.EXTERNAL_ORDER_ID                                 as EXTERNAL_ORDER_ID        ,
  NewPl.VAD_ID                                            as VAD_ID                   ,
  NewPl.OPAL_ID                                           as OPAL_ID                  ,
  NewPl.VAD_HOM_ID                                        as VAD_HOM_ID               ,
  NewPl.TYP_ORDR_CD                                       as TYP_ORDR_CD              ,
  NewPl.ORDR_TYPLG_DS                                     as ORDR_TYPLG_DS            ,
  NewPl.ORDER_LINE_TYPE                                   as ORDER_LINE_TYPE          ,
  NewPl.EXTERNAL_PRODUCT_ID                               as EXTERNAL_PRODUCT_ID      ,
  NewPl.EXTERNAL_PRODUCT_ID_PRE                           as EXTERNAL_PRODUCT_ID_PRE  ,
  NewPl.EXTERNAL_PRODUCT_ID_OT                            as EXTERNAL_PRODUCT_ID_OT   ,
  NewPl.EXTERNAL_PRODUCT_ID_OT_OP                         as EXTERNAL_PRODUCT_ID_OT_OP,
  NewPl.CONTRCT_DUREE_ENG_MOB                             as CONTRCT_DUREE_ENG_MOB    ,
  NewPl.CONTRCT_UNIT_ENG_MOB                              as CONTRCT_UNIT_ENG_MOB     ,
  Coalesce(Vend.ORG_AGENT_ID,NewPl.ORG_AGENT_ID)          as ORG_AGENT_ID             ,
  Null                                                    as EXTNL_VAL_COD_CD         ,
  Vend.ORG_POC_XI                                         as ORG_POC_XI               ,
  Vend.ORG_NOM                                            as ORG_NOM                  ,
  Vend.ORG_PRENOM                                         as ORG_PRENOM               ,
  Vend.ORG_GROUPE_ID                                      as ORG_GROUPE_ID            ,
  Null                                                    as ORG_ACTVT_REEL           ,
  Null                                                    as ORG_RESP_REF_TRAV        ,
  Null                                                    as ORG_RESP_AGENT_ID        ,
  Null                                                    as ORG_RESP_XI              ,
  NewPl.SHOP_COD_DS                                       as SHOP_COD_DS              ,
  NewPl.SHOP_ADV_COD_DS                                   as SHOP_ADV_COD_DS          ,
  NewPl.BRAND_SHOP_DS                                     as BRAND_SHOP_DS            ,
  --Canal Macro
  'Dist'                                                  as ORG_CHANNEL_CD           ,
  --Sous Canal
  Case When RefO3.NETWRK_TYP_EDO_ID = 'FT'
        Then 'AD'
       Else 'RP'
  End                                                     as ORG_SUB_CHANNEL_CD       ,
  --Sous Sous Canal
  Case When RefO3.FLAG_TYPE_GEO Is Not Null
                Then 'DOM'
               Else 'Metropole'
  End                                                     as ORG_SUB_SUB_CHANNEL_CD   ,
  --Canal de Rem
  Case When RefO3.NETWRK_TYP_EDO_ID = 'FT'
        Then 'AD'
       Else 'Exclus'
  End                                                     as ORG_REM_CHANNEL_CD       ,
  --GT/Activité
  Case When NewPl.BRAND_SHOP_DS = 'NS_STW_MOB'
        THEN 'Mobistore'
       When NewPl.BRAND_SHOP_DS = 'NS_STW_GDT'
        Then 'GDT'
       When NewPl.BRAND_SHOP_DS = 'NS_STW_AFT'
        Then 'Boutique FT'
  End                                                     as ORG_GT_ACTIVITY          ,
  --Fidelisation
  Case When RefO3.NETWRK_TYP_EDO_ID = 'FT'
        Then 'INT'
       Else 'EXT'
  End                                                     as ORG_FIDELISATION         ,
  --Web Activité
  'OUI'                                                   as ORG_WEB_ACTIVITY         ,
  --Auto Activité
  'NON'                                                   as ORG_AUTO_ACTIVITY        ,
  --Organisation O3
  RefO3.EDO_ID                                            as ORG_EDO_ID               ,
  RefO3.TYPE_EDO                                          as ORG_TYPE_EDO             ,
  RefO3.NETWRK_TYP_EDO_ID                                 as NETWRK_TYP_EDO_ID        ,
  RefO3.FLAG_PLT_CONV                                     as ORG_FLAG_PLT_CONV        ,
  RefO3.FLAG_TEAM_MKT                                     as ORG_FLAG_TEAM_MKT        ,
  RefO3.FLAG_TYPE_CMP                                     as ORG_FLAG_TYPE_CMP        ,
  Vend.ORG_REF_TRAV                                       as ORG_REF_TRAV             ,
  ------------nouveau champ
  RefO3.FLAG_TYPE_GEO                                     as FLAG_TYPE_GEO            ,
  RefO3.FLAG_TYPE_CPT_NTK                                 as FLAG_TYPE_CPT_NTK        ,
  Case When SUBSTR('SHOP_ADV_COD_DS',3,3) = 'MOB'
        Then 'MobiStore'
       When SUBSTR('SHOP_ADV_COD_DS',3,3) = 'GDT'
        Then 'GDT'
  End                                                     as FLAG_TYPE_PTN_NTK        ,
  ------
  NewPl.PAR_ADV_CLIENT_NU                                 as PAR_ADV_CLIENT_NU        ,
  NewPl.PAR_ADV_DOSSIER_NU                                as PAR_ADV_DOSSIER_NU       ,
  Coalesce( ParcPre.PRESFACT_CO_PRECED,NewPl.PRESFACT_CO_PRECED)  as PRESFACT_CO_PRECED       ,
  --Attribut DMC
  DmcLine.DMC_LINE_ID                                     as DMC_LINE_ID              ,
  DmcLine.DMC_MASTER_LINE_ID                              as DMC_MASTER_LINE_ID       ,
  LineDMC.DEPRTMNT_ID                                     as PAR_DEPARTMNT_ID         ,
  LineDMC.BU_CD                                           as PAR_BU_CD                ,
  LineDMC.POSTAL_CD                                       as PAR_POSTAL_CD            ,
  LineDMC.INSEE_NB                                        as PAR_INSEE_CD             ,
  IRIS.PAR_GEO_MACROZONE                                  as PAR_GEO_MACROZONE        ,
  DmcLine.PAR_UNIFIED_PARTY_ID                            as PAR_UNIFIED_PARTY_ID     ,
  DmcLine.PAR_PARTY_REGRPMNT_ID                           as PAR_PARTY_REGRPMNT_ID    ,
  Null                                                    as PAR_CID_ID               ,
  Null                                                    as PAR_PID_ID               ,
  Null                                                    as PAR_FIRST_IN             ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                   as  ORG_AGENT_IOBSP         ,
  Case When EdoOBK.EDO_ID is Not Null
         Then 'O'
          Else 'N'
  End                                                     as ORG_EDO_IOBSP            ,
  IRIS.PAR_IRIS2000_CD                                    as PAR_IRIS2000_CD          ,
  FIBER.PAR_FIBER_IN                                      as PAR_FIBER_IN             ,
  --On met le code OSCAR
  NewPl.OTO_OSCAR_VALUE_NU                                as OTO_OSCAR_VALUE_NU       ,
  Dossier.PAR_LASTNAME                                    as PAR_LASTNAME             ,
  Dossier.PAR_FIRSTNAME                                   as PAR_FIRSTNAME            ,
  Null                                                    as PAR_SIRET                ,
  Null                                                    as PAR_MARKET_SEG           ,
  Client.PAR_TYPE                                         as PAR_TYPE                 ,
  AdrMail.PAR_EMAIL                                       as PAR_EMAIL                ,
  Adr.PAR_BILL_ADRESS_1                                   as PAR_BILL_ADRESS_1        ,
  Adr.PAR_BILL_ADRESS_2                                   as PAR_BILL_ADRESS_2        ,
  Adr.PAR_BILL_ADRESS_3                                   as PAR_BILL_ADRESS_3        ,
  Adr.PAR_BILL_ADRESS_4                                   as PAR_BILL_ADRESS_4        ,
  Adr.PAR_BILL_CD_POSTAL                                  as PAR_BILL_CD_POSTAL       ,
  Adr.PAR_DO                                              as PAR_DO                   ,
  Uscm.PAR_USCM                                           as PAR_USCM                 ,
  Uscm.PAR_USCM_DS                                        as PAR_USCM_DS              ,
  Uscm.PAR_USCM_USCM_DS                                   as PAR_USCM_USCM_DS         ,
  Uscm.PAR_USCM_REGUSCM                                   as PAR_USCM_REGUSCM         ,
  Uscm.PAR_USCM_REGUSCM_DS                                as PAR_USCM_REGUSCM_DS      ,
  AidNd.PAR_AID                                           as PAR_AID                  ,
  AidNd.PAR_AID                                           as PAR_ND                   ,
  --Enrichissement des attributs Du Mobiles :
  ImeTac.PAR_MOB_IMEI                                     as PAR_MOB_IMEI             ,
  ImeTac.PAR_MOB_TAC                                      as PAR_MOB_TAC              ,
  SimIms.PAR_MOB_SIM                                      as PAR_MOB_SIM              ,
  SimIms.PAR_MOB_IMSI                                     as PAR_MOB_IMSI             ,
  --Score du client Internet
  Null                                                    as PAR_SCORE_NU_INT         ,
  Null                                                    as PAR_SCORE_IN_INT         ,
  Null                                                    as PAR_TRESHOLD_NU_INT      ,
  --Score du client Mobile
  ScoMob.PAR_SCORE_NU_MOB                                 as PAR_SCORE_NU_MOB         ,
  ScoMob.PAR_SCORE_IN_MOB                                 as PAR_SCORE_IN_MOB         ,
  ScoMob.PAR_TRESHOLD_NU_MOB                              as PAR_TRESHOLD_NU_MOB      ,
  NewPl.PAYMNT_FORMLTN_ID                                 as PAYMNT_FORMLTN_ID        ,
  NewPl.MONTHL_PRIC                                       as MONTHL_PRIC              ,
  NewPl.MONTHL_PERD                                       as MONTHL_PERD              ,
  NewPl.QUANTT_QT                                         as QUANTT_QT                ,
  NewPl.ID_QUANTITE                                       as ID_QUANTITE              ,
  NewPl.AMNT_HT_ARTCL_AM                                  as AMNT_HT_ARTCL_AM       ,
  0                                                       as RUN_ID                   ,
  0                                                       as HOT_IN                   ,
  Current_Timestamp(0)                                    as CREATION_TS              ,
  Current_Timestamp(0)                                    as LAST_MODIF_TS            ,
  1                                                       as FRESH_IN                 ,
  1                                                       as COHERENCE_IN
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP NewPl
  Left Outer join ${KNB_PCO_TMP}.ORD_W_ORDER_NEWSHOP_C_O3 RefO3
    On    NewPl.ACTE_ID                =   RefO3.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT       =   RefO3.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC DmcLine
    On    NewPl.ACTE_ID                =   DmcLine.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT       =   DmcLine.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_PREPAID Dossier
    On    NewPl.ACTE_ID               =   Dossier.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   Dossier.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_POSTPAID Client
    On    NewPl.ACTE_ID               =   Client.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   Client.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CLMAL AdrMail
    On    NewPl.ACTE_ID               =   AdrMail.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   AdrMail.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CLADR Adr
    On    NewPl.ACTE_ID               =   Adr.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   Adr.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_VENDEUR Vend
    On    NewPl.ACTE_ID               =   Vend.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   Vend.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_AT AidNd
    On    NewPl.ACTE_ID               =   AidNd.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   AidNd.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_IMEI ImeTac
    On    NewPl.ACTE_ID               =   ImeTac.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   ImeTac.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_SIM SimIms
    On    NewPl.ACTE_ID               =   SimIms.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   SimIms.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_USCM Uscm
    On    NewPl.ACTE_ID               =   Uscm.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   Uscm.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_SCORE ScoMob
    On    NewPl.ACTE_ID               =   ScoMob.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   ScoMob.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC LineDMC
    On    NewPl.ACTE_ID               =   LineDMC.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   LineDMC.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_IRIS IRIS
    On    NewPl.ACTE_ID               =   IRIS.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   IRIS.ORDER_DEPOSIT_DT
  Left Outer join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_FIBER FIBER
    On    NewPl.ACTE_ID               =   FIBER.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT      =   FIBER.ORDER_DEPOSIT_DT
  --Recherche en Parc
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_PARCPRE ParcPre
    On    NewPl.ACTE_ID          = ParcPre.ACTE_ID
      And NewPl.ORDER_DEPOSIT_DT = ParcPre.ORDER_DEPOSIT_DT
-- IOBSP
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On   RefO3.EDO_ID   = EdoOBK.EDO_ID
        And NewPl.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')     And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On   Coalesce (Vend.ORG_AGENT_ID, NewPl.ORG_AGENT_ID)=CuidOBK.AGENT_ID
      AND NewPl.ORDER_DEPOSIT_DT >= CuidOBK.HABILL_BEGIN_DT 
      AND NewPl.ORDER_DEPOSIT_DT < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))

Where
  (1=1)
Qualify Row_Number() Over(Partition by NewPl.ACTE_ID order by 1)=1
;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_NSH;
.if errorcode <> 0 then .quit 1


