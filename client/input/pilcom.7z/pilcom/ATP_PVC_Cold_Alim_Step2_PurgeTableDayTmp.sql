--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PVC_Cold_Alim_Step2_PurgeTableDayTmp.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de delete de la table ACT_T_PVC_DAY
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 03/10/2013     XKN         Création
---------------------------------------------------------------------------------

.set width 5000

Delete From ${KNB_PCO_TMP}.ACT_T_PVC_DAY All;
.if errorcode <> 0 then .quit 1

.quit 0

