-- $HEADER: mm2pco/current/sql/ATP_CHO_Placement_Consolidation_Enrichissement_Step2_IDLineDMC.sql 13_05#7 15-MAR-2016 15:51:36 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_Enrichissement_Step2_IDLineDMC.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 14/03/2016      HLA         Ajout champs digital
-- 12/12/2016     HOB         Modif : Ajout Champs VA
--------------------------------------------------------------------------------

.set width 2500;



Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC all;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  DMC_LINE_TYPE             ,
  DMC_ACTIVATION_DT         ,
  PAR_DEPRTMNT_ID           ,
  PAR_POSTAL_CD             ,
  PAR_INSEE_NB              ,
  PAR_BU_CD                 ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID 
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT             ,
  LineDmc.LINE_ID                                 as DMC_LINE_ID                ,
  LineDmc.LINE_ID                                 as DMC_MASTER_LINE_ID         ,
  LineDmc.LINE_TYPE                               as DMC_LINE_TYPE              ,
  LineDmc.ACTIVATION_DT                           as DMC_ACTIVATION_DT          ,
  Ldmc.DEPRTMNT_ID                                as PAR_DEPRTMNT_ID            ,
  Ldmc.POSTAL_CD                                  as PAR_POSTAL_CD              ,
  Ldmc.INSEE_NB                                   as PAR_INSEE_NB               ,
  Geo.BU_CD                                       as PAR_BU_CD                  , 
  Ldmc.UNIFIED_PARTY_ID                           AS PAR_UNIFIED_PARTY_ID ,
  Ldmc.PARTY_REGRPMNT_ID                          AS PAR_PARTY_REGRPMNT_ID  
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 RefId
Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_LNK_AR LineDmc
      --Jointure Client/Dossier
     On RefId.DOSSIER_NU = LineDmc.RES_VALUE_DS
    And RefId.CLIENT_NU  = LineDmc.ADV_CLIENT_NU
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On LineDmc.LINE_ID = Ldmc.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
Where
  (1=1)
  And RefId.DMC_LINE_ID   Is Null
  --And LineDmc.LINE_TYPE   In ('P','M')
  And LineDmc.CLOSURE_DT  Is Null
  
     Qualify row_number() over (Partition by RefId.ACTE_ID, RefId.INT_DEPOSIT_DT order by LineDmc.START_DT desc)=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC;
.if errorcode <> 0 then .quit 1




----------------------------------------------------------------------------
-- Etape 2 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------


Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_CV All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_CV
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  DMC_LINE_ID           ,
  DMC_MASTER_LINE_ID    ,
  DMC_CONVERGENT_IN     
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID              ,
  RefDmc.INT_DEPOSIT_DT           as INT_DEPOSIT_DT       ,
  RefDmc.DMC_LINE_ID              as DMC_LINE_ID          ,
  RefDmc.DMC_MASTER_LINE_ID       as DMC_MASTER_LINE_ID   ,
  Dmc.CONVERGENT_IN               as DMC_CONVERGENT_IN    
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_HIST Dmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_LINE_ID      =  Dmc.LINE_ID
      And RefDmc.INT_DEPOSIT_DT   >   Dmc.VAL_START_DT
      And RefDmc.INT_DEPOSIT_DT   <=  Dmc.VAL_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID, RefDmc.INT_DEPOSIT_DT Order by Dmc.VAL_START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_CV;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------
-- Etape 3 : On recherche l'identifiant ligne Internet en relation :
----------------------------------------------------------------------------


Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  DMC_LINE_ID_INT       ,
  DMC_LINE_TYPE_INT     ,
  DMC_ACTIVATION_DT_INT ,
  DMC_SERVICE_ACCESS_ID ,
  PAR_UNIFIED_PARTY_ID ,
  PAR_PARTY_REGRPMNT_ID
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID                  ,
  RefDmc.INT_DEPOSIT_DT           as INT_DEPOSIT_DT           ,
  Dmc.LINE_ID                     as DMC_LINE_ID_INT          ,
  Dmc.LINE_TYPE                   as DMC_LINE_TYPE_INT        ,
  Dmc.ACTIVATION_DT               as DMC_ACTIVATION_DT_INT    ,
  Dmc.SERVICE_ACCESS_ID           as DMC_SERVICE_ACCESS_ID    ,
  Dmc.UNIFIED_PARTY_ID            AS PAR_UNIFIED_PARTY_ID    , 
  Dmc.PARTY_REGRPMNT_ID           AS PAR_PARTY_REGRPMNT_ID
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_CV RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Dmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_MASTER_LINE_ID       =   Dmc.MASTER_LINE_ID
--       And RefDmc.INT_DEPOSIT_DT           >   Dmc.VAL_START_DT
--       And RefDmc.INT_DEPOSIT_DT           <=  Dmc.VAL_END_DT
Where
  (1=1)
  --On va faire la recherhe dans DMC que pour les convergen
  --And RefDmc.DMC_CONVERGENT_IN = 1
  --On filtre que sur les lignes Internet / Fixe
  And Dmc.LINE_TYPE           in ('I','F')
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID, RefDmc.INT_DEPOSIT_DT Order by Dmc.START_DT, Dmc.LINE_ID Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT;
.if errorcode <> 0 then .quit 1







-------------------------------------------------------------------------------------------------------
-- Etape 4 : on détermine le Score Internet                                                        ----
-------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT_SC All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT_SC
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PAR_SCORE_NU_INT        ,
  PAR_SCORE_IN_INT        ,
  PAR_TRESHOLD_NU_INT     
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID              ,
  RefDmc.INT_DEPOSIT_DT           as INT_DEPOSIT_DT       ,
  ScoreDmc.SCORE_VALUE_1          as PAR_SCORE_NU_INT     ,
  ScoreDmc.SCORE_TRESHOLD_1       as PAR_SCORE_IN_INT     ,
  Null                            as PAR_TRESHOLD_NU_INT  
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_CPLT_HIST ScoreDmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_LINE_ID_INT  = ScoreDmc.LINE_ID
      And RefDmc.INT_DEPOSIT_DT   >= ScoreDmc.VAL_START_DT
      And RefDmc.INT_DEPOSIT_DT   <  ScoreDmc.VAL_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID, RefDmc.INT_DEPOSIT_DT Order by ScoreDmc.VAL_START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT_SC;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 5 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IRIS
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID               ,
  PAR_IRIS2000_CD           ,
  PAR_GEO_MACROZONE
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT             ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD            ,
  LFIBER.RESERV_4                                 AS  PAR_GEO_MACROZONE     
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
  on RefId.DMC_LINE_ID = LFIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.INT_DEPOSIT_DT Order by LFIBER.LAST_MODIF_TS Desc)=1  
  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 6 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_FIBER All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_FIBER
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID                ,
  PAR_FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT             ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN            
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
  Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.INT_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_FIBER;
.if errorcode <> 0 then .quit 1


.quit 0


