-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EXT_Placement_C_Alimentation_Step2_Enrichissement_AGENT_ID.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement cuid du placement
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/06/2014      OCH         Creation
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_AGENT_ID All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_AGENT_ID
(
  ACTE_ID               ,
  ORDER_DEPOSIT_DT      ,
  ORG_AGENT_ID          ,
  ORG_LAST_NAME_NM      ,
  ORG_FIRST_NAME_NM           
)
Select
  Placement.ACTE_ID                                             As ACTE_ID              ,
  Placement.ORDER_DEPOSIT_DT                                    As ORDER_DEPOSIT_DT     ,
  Placement.AGENT_ID                                            As ORG_AGENT_ID         ,
  RefAGENT_ID.LAST_NAME_NM                                      As ORG_LAST_NAME_NM     ,
  RefAGENT_ID.FIRST_NAME_NM                                     As ORG_FIRST_NAME_NM     
From
  --On prend tout le contenu de la table miroir tmp
  ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL Placement
  Inner Join  ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefAGENT_ID
    On  Placement.AGENT_ID      = RefAGENT_ID.AGENT_CUID
        And RefAGENT_ID.CURRENT_IN  = 1
        And RefAGENT_ID.CLOSURE_DT  is Null
Where
  (1=1)
Qualify Row_Number() Over(Partition by placement.ACTE_ID order by 1)=1

;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL;
.if errorcode <> 0 then .quit 1

.quit 0
