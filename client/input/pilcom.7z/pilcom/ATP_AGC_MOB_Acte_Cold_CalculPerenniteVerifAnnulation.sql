-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_MOB_Acte_Cold_CalculPerenniteVerifAnnulation.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul de la pérénnité pour AGC MOB 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 10/07/2014      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_AGCM_CHECK_CANCLNG All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_AGCM_CHECK_CANCLNG
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT          
)
Select
  Acte.ACTE_ID                                           as ACTE_ID            ,
  Cast(Acte.ORDER_DEPOSIT_DT as date format 'YYYYMMDD')  as ORDER_DEPOSIT_DT         
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C Acte
  Inner Join  ${KNB_PCO_TMP}.ORD_W_AGENDE_SEG_REFCOM_DB RefAgend
    On    Acte.PAR_IMSI_CD        = RefAgend.DOSSIER_NU_IMSI
      And Acte.SEG_COM_ID_LP      = RefAgend.SEG_COM_ID
      And Acte.ORDER_DEPOSIT_DT     = RefAgend.ORDAGD_DEMANDE_DT
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  --And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID_LP          Not In ('NS','OPTTECH','OPT_INC')
  And Acte.PAR_IMSI_CD            Is Not Null
  -- On filtre les ordres annulé
  And RefAgend.ORDAGD_ETAT = 'K'
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order by Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET) Desc)=1
;

.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_AGCM_CHECK_CANCLNG;
.if errorcode <> 0 then .quit 1






.quit 0


