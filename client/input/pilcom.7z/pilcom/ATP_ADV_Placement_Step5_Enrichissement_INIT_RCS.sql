--$HEADER: mm2pco/current/sql/ATP_ADV_Placement_Step5_Enrichissement_INIT_RCS.sql 13_05#5 19-DEC-2018 11:55:29 LXQG9925
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_ADV_Placement_Step5_Enrichissement_INIT_RCS.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissement O3/ACTE_INIT
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 27/07/2018      HOB         Creation
-- 11/10/2018      JCR         Modification : priorisation INIT
-- 02/11/2018      LMU         Modification : enrichissement COE
-- 06/12/2018      LMU         Modification : enrichissement VAD
-- 30/09/2020      EVI         PILCOM-711 : Enrichissement ADV par VAD Mobile - Restriction aux actes de type RCS
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Enrichissement client/dossier                                                ----
----------------------------------------------------------------------------------------------

--Purge de la table temporaire avant insertion

Delete From ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV_INIT All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
--Etape 2-1 : Alimentation de la table temporaire avec l'enrichissement MSISDN Mobile avec les autres sources INIT 
----------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV_INIT
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  MSISDN_ID                 ,
  RCS_ENR_ACTE_ID           ,
  RCS_AGENT_ID              ,
  RCS_NOM                   ,
  RCS_PRENOM                ,
  EDO_ID                    ,
  TYPE_EDO_ID               ,
  DISTRBTN_CHANNL_ID        ,
  FLAG_PLT_CONV_NB          ,
  ORG_CHANNEL_CD            ,
  ORG_SUB_CHANNEL_CD        ,
  ORG_SUB_SUB_CHANNEL_CD    ,
  ORG_GT_ACTIVITY           ,
  ORG_FIDELISATION          ,
  ORG_WEB_ACTIVITY          ,
  ORG_AUTO_ACTIVITY         ,
  ORG_REM_CHANNEL_CD        ,
  ORG_TEAM_LEVEL_1_CD       ,
  ORG_TEAM_LEVEL_1_DS       ,
  ORG_TEAM_LEVEL_2_CD       ,
  ORG_TEAM_LEVEL_2_DS       ,
  ORG_TEAM_LEVEL_3_CD       ,
  ORG_TEAM_LEVEL_3_DS       ,
  ORG_TEAM_LEVEL_4_CD       ,
  ORG_TEAM_LEVEL_4_DS       ,
  WORK_TEAM_LEVEL_1_CD      ,
  WORK_TEAM_LEVEL_1_DS      ,
  WORK_TEAM_LEVEL_2_CD      ,
  WORK_TEAM_LEVEL_2_DS      ,
  WORK_TEAM_LEVEL_3_CD      ,
  WORK_TEAM_LEVEL_3_DS      ,
  WORK_TEAM_LEVEL_4_CD      ,
  WORK_TEAM_LEVEL_4_DS      ,
  CREATION_TS               ,
  LAST_MODIF_TS             ,
  FRESH_IN                  ,
  COHERENCE_IN

)
Select
  ADV.ACTE_ID                                                                               As ACTE_ID               ,
  ADV.ORDER_DEPOSIT_DT                                                                      As ORDER_DEPOSIT_DT      ,
  ADV.MSISDN_ID                                                                             As MSISDN_ID             ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ACTE_ID    
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ACTE_ID
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ACTE_ID      
      When CAR.DOSSIER_NU         is not null   Then CAR.ACTE_ID          
      Else Null  -- valeur essentielle pour pouvoir filtrer dans l'etape suivante les INIT renseignes
  End                                                                                       As RCS_ENR_ACTE_ID       ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_AGENT_ID   
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_AGENT_ID     
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_AGENT_ID   
  End                                                                                       As RCS_AGENT_ID          ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_LAST_NAME_NM
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_AGENT_LAST_NAME    
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_AGENT_LAST_NAME  
  End                                                                                       As RCS_NOM               ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_FIRST_NAME_NM           
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_AGENT_FIRST_NAME   
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_AGENT_FIRST_NAME 
  End                                                                                       As RCS_PRENOM            ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.EDO_ID   
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_EDO_ID     
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_EDO_ID   
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_EDO_ID     
  End                                                                                       As EDO_ID                ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.TYPE_EDO_ID 
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TYPE_EDO   
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TYPE_EDO 
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TYPE_EDO   
  End                                                                                       As TYPE_EDO_ID           ,
  Case 
      --When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_CANAL_ID 
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_CANAL_ID   
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_CANAL_ID 
  End                                                                                       As DISTRBTN_CHANNL_ID    ,
  Case
      When COE.PAR_MSISDN_ID      is not null   Then COE.FLAG_PLT_CONV_NB  
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_FLAG_PLT_CONV    
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_FLAG_PLT_CONV  
  End                                                                                       As FLAG_PLT_CONV_NB      ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_CHANNEL_CD 
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_CHANNEL_CD   
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_CHANNEL_CD 
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_CHANNEL_CD   
  End                                                                                       As ORG_CHANNEL_CD        ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_SUB_CHANNEL_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_SUB_CHANNEL_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_SUB_CHANNEL_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_SUB_CHANNEL_CD
  End                                                                                      As ORG_SUB_CHANNEL_CD    ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_SUB_SUB_CHANNEL_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_SUB_SUB_CHANNEL_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_SUB_SUB_CHANNEL_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_SUB_SUB_CHANNEL_CD
  End                                                                                       As ORG_SUB_SUB_CHANNEL_CD,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_GT_ACTIVITY
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_GT_ACTIVITY
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_GT_ACTIVITY
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_GT_ACTIVITY
  End                                                                                       As ORG_GT_ACTIVITY       ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_FIDELISATION
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_FIDELISATION
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_FIDELISATION
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_FIDELISATION
  End                                                                                       As ORG_FIDELISATION      ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_WEB_ACTIVITY
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_WEB_ACTIVITY
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_WEB_ACTIVITY
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_WEB_ACTIVITY
  End                                                                                       As ORG_WEB_ACTIVITY      ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_AUTO_ACTIVITY
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_AUTO_ACTIVITY
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_AUTO_ACTIVITY
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_AUTO_ACTIVITY
  End                                                                                       As ORG_AUTO_ACTIVITY     ,
   Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_REM_CHANNEL_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_REM_CHANNEL_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_REM_CHANNEL_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_REM_CHANNEL_CD
  End                                                                                       As ORG_REM_CHANNEL_CD    ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_1_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_1_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_1_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_1_CD
  End                                                                                       As ORG_TEAM_LEVEL_1_CD   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_1_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_1_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_1_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_1_DS
  End                                                                                       As ORG_TEAM_LEVEL_1_DS   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_2_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_2_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_2_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_2_CD
  End                                                                                       As ORG_TEAM_LEVEL_2_CD   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_2_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_2_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_2_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_2_DS
 End                                                                                        As ORG_TEAM_LEVEL_2_DS   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_3_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_3_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_3_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_3_CD
  End                                                                                       As ORG_TEAM_LEVEL_3_CD   ,
   Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_3_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_3_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_3_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_3_DS
  End                                                                                       As ORG_TEAM_LEVEL_3_DS   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_4_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_4_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_4_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_4_CD
  End                                                                                       As ORG_TEAM_LEVEL_4_CD   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.ORG_TEAM_LEVEL_4_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.ORG_TEAM_LEVEL_4_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.ORG_TEAM_LEVEL_4_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.ORG_TEAM_LEVEL_4_DS
  End                                                                                       As ORG_TEAM_LEVEL_4_DS   ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_1_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_1_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_1_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_1_CD
  End                                                                                       As WORK_TEAM_LEVEL_1_CD  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_1_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_1_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_1_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_1_DS
  End                                                                                       As WORK_TEAM_LEVEL_1_DS  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_2_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_2_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_2_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_2_CD
   End                                                                                      As WORK_TEAM_LEVEL_2_CD  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_2_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_2_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_2_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_2_DS
  End                                                                                       As WORK_TEAM_LEVEL_2_DS  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_3_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_3_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_3_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_3_CD
  End                                                                                       As WORK_TEAM_LEVEL_3_CD  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_3_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_3_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_3_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_3_DS
  End                                                                                       As WORK_TEAM_LEVEL_3_DS  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_4_CD
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_4_CD
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_4_CD
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_4_CD
  End                                                                                       As WORK_TEAM_LEVEL_4_CD  ,
  Case 
      When COE.PAR_MSISDN_ID      is not null   Then COE.WORK_TEAM_LEVEL_4_DS
      When PCM.PAR_ADV_DOSSIER_NU is not null   Then PCM.WORK_TEAM_LEVEL_4_DS
      When VAD.PAR_ADV_DOSSIER_NU is not null   Then VAD.WORK_TEAM_LEVEL_4_DS
      When CAR.DOSSIER_NU         is not null   Then CAR.WORK_TEAM_LEVEL_4_DS
  End                                                                                       As WORK_TEAM_LEVEL_4_DS  ,
   Current_timestamp(0)                                                                     As CREATION_TS           ,
   Current_timestamp(0)                                                                     As LAST_MODIF_TS         ,
   1                                                                                        As FRESH_IN              ,
   1                                                                                        As COHERENCE_IN

From
  ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV_1 ADV 
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_COE COE 
         On   ADV.MSISDN_ID                            = COE.PAR_MSISDN_ID
        And   ADV.ORDER_DEPOSIT_DT                     = COE.EXTRNL_CLOSED_TS
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_CAR CAR 
         On   ADV.MSISDN_ID               = CAR.DOSSIER_NU
        And   CAR.ORD_DEPOSIT_DT          Between  (ADV.ORDER_DEPOSIT_DT-10)   And ADV.ORDER_DEPOSIT_DT
        And   CAR.ACT_TYPE_SERVICE_FINAL  In ('OPTRCS1','OPTRCS2','PRESTASCE','PRESTASCESO')
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM PCM 
         On   ADV.MSISDN_ID               =  PCM.PAR_ADV_DOSSIER_NU
        And   PCM.ORDER_DEPOSIT_DT        Between  (ADV.ORDER_DEPOSIT_DT-10)   And ADV.ORDER_DEPOSIT_DT
        And   PCM.ACT_TYPE_SERVICE_FINAL  In ('OPTRCS1','OPTRCS2','PRESTASCE','PRESTASCESO')
  Left Outer Join ${KNB_PCO_VM}.ORD_F_ACTE_VAD VAD 
         On   ADV.MSISDN_ID               =  VAD.PAR_ADV_DOSSIER_NU
        And   VAD.ORDER_DEPOSIT_DT Between (ADV.ORDER_DEPOSIT_DT - 10) And ADV.ORDER_DEPOSIT_DT
        And   VAD.ACT_TYPE_SERVICE_FINAL  In ('PRESTASCESO')  
       
     
Where
  (1=1)
  
Qualify  Row_Number() over (Partition by ADV.ACTE_ID 
                            Order by coalesce(COE.ORDER_DEPOSIT_TS, PCM.ORDER_DEPOSIT_DT,
                                              VAD.ORDER_DEPOSIT_DT, CAR.ORD_DEPOSIT_DT, ADV.ORDER_DEPOSIT_DT)) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV_INIT ;
.if errorcode <> 0 then .quit 1

.quit 0
