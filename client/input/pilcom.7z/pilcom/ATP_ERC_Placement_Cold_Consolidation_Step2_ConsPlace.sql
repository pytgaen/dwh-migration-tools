-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERC_Placement_Cold_Consolidation_Step2_ConsPlace.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de consolidation placement
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/07/2014      MCA         Creation
-- 19/08/2014      MCA         Indus
-- 25/05/2016      MDE         Evol : gestion des doublous (ajout update sur HOMOLOGATION_TS)
--------------------------------------------------------------------------------

.set width 2500;



----------------------------------------------------------------*/
-- Etape 1 : Delete de la table TMP                             */
----------------------------------------------------------------*/
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1 All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------*/
-- Etape 2 : Alimentation de la table TMP                       */
----------------------------------------------------------------*/



INSERT INTO ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1
(
  REPRISE_ID                  ,
  AGENT_ID                    ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  EDO_ID                      ,
  IMEI                        ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  REPRISE_TS                  ,
  REPRISE_VAL                 ,
  PROMOTION_VAL               ,
  RECEPTION_TS                ,
  TRTMT_TS                    ,
  HOMOLOGATION_TS             ,
  HOMOLOGATION_CD             ,
  POST_TRTMT_VAL              ,
  AJUSTMNT_RAISON             ,
  AJUSTMNT_VAL                ,
  ECART_RAISON                ,
  FIRST_NAME_NM               ,
  LAST_NAME_NM                ,
  MSISDN                      ,
  REPRISE_NUM                 ,
  BON_ID                      ,
  MODE_PAIEMENT               ,
  PAIEMENT_STATUT             ,
  CONSUMPTN_TS                ,
  MAX_VALIDITY_TS             ,
  CANCELLATION_TS             ,
  EQPT_CD                     ,
  BRAND_SHOP_CD               ,
  SEGMENT                     ,
  RAISON_SOCIALE              ,
  SIRET                       ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
SELECT
  Ods.REPRISE_ID                        as REPRISE_ID                        ,
  Ods.AGENT_ID                          as AGENT_ID                          ,
  Ods.STORE_CD                          as STORE_CD                          ,
  Ods.ADV_STORE_CD                      as ADV_STORE_CD                      ,
  Ods.EDO_ID                            as EDO_ID                            ,
  Ods.IMEI                              as IMEI                              ,
  Ods.TERMINAL_BRAND                    as TERMINAL_BRAND                    ,
  Ods.TERMINAL_MODEL                    as TERMINAL_MODEL                    ,
  Ods.REPRISE_TS                        as REPRISE_TS                        ,
  Ods.REPRISE_VAL                       as REPRISE_VAL                       ,
  Ods.PROMOTION_VAL                     as PROMOTION_VAL                     ,
  Ods.RECEPTION_TS                      as RECEPTION_TS                      ,
  Ods.TRTMT_TS                          as TRTMT_TS                          ,
  Ods.HOMOLOGATION_TS                   as HOMOLOGATION_TS                   ,
  Ods.HOMOLOGATION_CD                   as HOMOLOGATION_CD                   ,
  Ods.POST_TRTMT_VAL                    as POST_TRTMT_VAL                    ,
  Ods.AJUSTMNT_RAISON                   as AJUSTMNT_RAISON                   ,
  Ods.AJUSTMNT_VAL                      as AJUSTMNT_VAL                      ,
  Ods.ECART_RAISON                      as ECART_RAISON                      ,
  Ods.FIRST_NAME_NM                     as FIRST_NAME_NM                     ,
  Ods.LAST_NAME_NM                      as LAST_NAME_NM                      ,
  Ods.MSISDN                            as MSISDN                            ,
  Ods.REPRISE_NUM                       as REPRISE_NUM                       ,
  Ods.BON_ID                            as BON_ID                            ,
  Ods.MODE_PAIEMENT                     as MODE_PAIEMENT                     ,
  Ods.PAIEMENT_STATUT                   as PAIEMENT_STATUT                   ,
  Ods.CONSUMPTN_TS                      as CONSUMPTN_TS                      ,
  Ods.MAX_VALIDITY_TS                   as MAX_VALIDITY_TS                   ,
  Ods.CANCELLATION_TS                   as CANCELLATION_TS                   ,
  Ods.EQPT_CD                           as EQPT_CD                           ,
  Ods.BRAND_SHOP_CD                     as BRAND_SHOP_CD                     ,
  Ods.SEGMENT                           as SEGMENT                           ,
  Ods.RAISON_SOCIALE                    as RAISON_SOCIALE                    ,
  Ods.SIRET                             as SIRET                             ,
  0                                     as HOT_IN                            ,
  Current_Timestamp(0)                  as CREATION_TS                       ,
  Current_Timestamp(0)                  as LAST_MODIF_TS                     ,
  1                                     as FRESH_IN                          ,
  0                                     as COHERENCE_IN
FROM
${KNB_PCO_TMP}.ORD_W_ORDER_ERC_1 Ods

WHERE
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1
;
.if errorcode <> 0 then .quit 1

-- Insertion des données consolidées
INSERT INTO ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1
(
  REPRISE_ID                  ,
  AGENT_ID                    ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  EDO_ID                      ,
  IMEI                        ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  REPRISE_TS                  ,
  REPRISE_VAL                 ,
  PROMOTION_VAL               ,
  RECEPTION_TS                ,
  TRTMT_TS                    ,
  HOMOLOGATION_TS             ,
  HOMOLOGATION_CD             ,
  POST_TRTMT_VAL              ,
  AJUSTMNT_RAISON             ,
  AJUSTMNT_VAL                ,
  ECART_RAISON                ,
  FIRST_NAME_NM               ,
  LAST_NAME_NM                ,
  MSISDN                      ,
  REPRISE_NUM                 ,
  BON_ID                      ,
  MODE_PAIEMENT               ,
  PAIEMENT_STATUT             ,
  CONSUMPTN_TS                ,
  MAX_VALIDITY_TS             ,
  CANCELLATION_TS             ,
  EQPT_CD                     ,
  BRAND_SHOP_CD               ,
  SEGMENT                     ,
  RAISON_SOCIALE              ,
  SIRET                       ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
SELECT
  Cons.REPRISE_ID                       as REPRISE_ID                        ,
  Cons.AGENT_ID                         as AGENT_ID                          ,
  Cons.STORE_CD                         as STORE_CD                          ,
  Cons.ADV_STORE_CD                     as ADV_STORE_CD                      ,
  Cons.EDO_ID                           as EDO_ID                            ,
  Cons.IMEI                             as IMEI                              ,
  Cons.TERMINAL_BRAND                   as TERMINAL_BRAND                    ,
  Cons.TERMINAL_MODEL                   as TERMINAL_MODEL                    ,
  Cons.REPRISE_TS                       as REPRISE_TS                        ,
  Cons.REPRISE_VAL                      as REPRISE_VAL                       ,
  Cons.PROMOTION_VAL                    as PROMOTION_VAL                     ,
  Cons.RECEPTION_TS                     as RECEPTION_TS                      ,
  Cons.TRTMT_TS                         as TRTMT_TS                          ,
  Cons.HOMOLOGATION_TS                  as HOMOLOGATION_TS                   ,
  Cons.HOMOLOGATION_CD                  as HOMOLOGATION_CD                   ,
  Cons.POST_TRTMT_VAL                   as POST_TRTMT_VAL                    ,
  Cons.AJUSTMNT_RAISON                  as AJUSTMNT_RAISON                   ,
  Cons.AJUSTMNT_VAL                     as AJUSTMNT_VAL                      ,
  Cons.ECART_RAISON                     as ECART_RAISON                      ,
  Cons.FIRST_NAME_NM                    as FIRST_NAME_NM                     ,
  Cons.LAST_NAME_NM                     as LAST_NAME_NM                      ,
  Cons.MSISDN                           as MSISDN                            ,
  Cons.REPRISE_NUM                      as REPRISE_NUM                       ,
  Cons.BON_ID                           as BON_ID                            ,
  Cons.MODE_PAIEMENT                    as MODE_PAIEMENT                     ,
  Cons.PAIEMENT_STATUT                  as PAIEMENT_STATUT                   ,
  Cons.CONSUMPTN_TS                     as CONSUMPTN_TS                      ,
  Cons.MAX_VALIDITY_TS                  as MAX_VALIDITY_TS                   ,
  Cons.CANCELLATION_TS                  as CANCELLATION_TS                   ,
  Cons.EQPT_CD                          as EQPT_CD                           ,
  Cons.BRAND_SHOP_CD                    as BRAND_SHOP_CD                     ,
  Cons.SEGMENT                          as SEGMENT                           ,
  Cons.RAISON_SOCIALE                   as RAISON_SOCIALE                    ,
  Cons.SIRET                            as SIRET                             ,
  0                                     as HOT_IN                            ,
  Current_Timestamp(0)                  as CREATION_TS                       ,
  Current_Timestamp(0)                  as LAST_MODIF_TS                     ,
  1                                     as FRESH_IN                          ,
  0                                     as COHERENCE_IN
FROM
${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_CON Cons

WHERE
  (1=1)
  -- Ici on ne prend pas les mêmes reprise_id qui envoyer par ERC
    And Cons.REPRISE_ID not in (select distinct(reprise_id) 
                                from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1
                                ) 
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1
;
.if errorcode <> 0 then .quit 1


-- Update gestion des doublons: ORD_W_PLACEMENT_ERC_EXT_1

Update  RefId
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT_1   RefId               ,
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_ERC       Placement
Set
  HOMOLOGATION_TS                           =   Placement.HOMOLOGATION_TS      
Where
  (1=1)
   And  RefId.REPRISE_ID                    =   Placement.REPRISE_ID
   And  Placement.HOMOLOGATION_TS               Is Not Null
;
.if errorcode <> 0 then .quit 1





.quit 0
