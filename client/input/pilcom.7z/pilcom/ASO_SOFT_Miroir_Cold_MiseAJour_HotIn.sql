-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ASO_SOFT_Miroir_Cold_MiseAJour_HotIn.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de mise à jour du Hot IN dans la table Mirroir
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 28/03/2014      AID         Modification ${KNB_PCO_SOC}.ORD_F_ORDER_SOFT_COM
--------------------------------------------------------------------------------

.set width 2500;




--Insertion dans la table des commandes :


Update Socle
From
  ${KNB_COM_SOC}.ORD_F_ORDER_SOFT_COM               Socle ,
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_EXTRACT     RefID
Set
  HOT_IN          = 0                           ,
  LAST_MODIF_TS   = Current_timestamp(0)        
Where
  (1=1)
  And Socle.EXTERNAL_ORDER_ID = RefID.EXTERNAL_ORDER_ID
  And Socle.ORDER_STATUS_CD   = RefID.ORDER_STATUS_CD
  And Socle.STATUS_MODIF_TS   = RefID.STATUS_MODIF_TS
  And Socle.FRESH_IN          = 1
  And Socle.HOT_IN            = 1
;
.if errorcode <> 0 then .quit 1


.quit 0


