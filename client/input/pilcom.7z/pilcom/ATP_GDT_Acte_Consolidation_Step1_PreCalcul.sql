--$HEADER: mm2pco/current/sql/ATP_GDT_Acte_Consolidation_Step1_PreCalcul.sql 13_05#8 12-AOU-2019 16:53:22 KPRZ8434
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_GDT_Acte_Consolidation_Step1_PreCalcul.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 12/08/2019      EVI         Creation
-- 07/10/2019      EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF / ACT_UNITE_CD
-- 23/10/2020      EVI         PILCOM-734 : Recalcul sur + de 100 jours
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_CALC all;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------
--Alimentation : Limitation des periodes - Recalcul +100 jours
---------------------------------------------------------
       
Create Volatile Table ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM (
  PERIODE_ID               INTEGER                       Not null           ,
  PERIODE_DATE_DEB         DATE FORMAT 'YYYYMMDD'                           ,
  PERIODE_DATE_FIN         DATE FORMAT 'YYYYMMDD'                           ,
  FRESH_IN                 BYTEINT                                          ,
  CURRENT_IN               BYTEINT                                          ,
  CLOSURE_DT               DATE FORMAT 'YYYYMMDD'
)
Primary Index (PERIODE_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

-- Limitation des periodes sur 12 mois

Insert into ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM
(
  PERIODE_ID                   ,
  PERIODE_DATE_DEB             ,
  PERIODE_DATE_FIN             ,
  FRESH_IN                     ,
  CURRENT_IN                   ,
  CLOSURE_DT     
)
Select
  RefPeriod.PERIODE_ID                          As PERIODE_ID             ,
  RefPeriod.PERIODE_DATE_DEB                    As PERIODE_DATE_DEB       ,
  RefPeriod.PERIODE_DATE_FIN                    As PERIODE_DATE_FIN       ,
  RefPeriod.FRESH_IN                            As FRESH_IN               ,
  RefPeriod.CURRENT_IN                          As CURRENT_IN             ,
  RefPeriod.CLOSURE_DT                          As CLOSURE_DT             
  From
  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM RefPeriod
  Where
  (1=1)
    And RefPeriod.FRESH_IN                        = 1
    And RefPeriod.CURRENT_IN                      = 1
    And RefPeriod.CLOSURE_DT                      Is Null
    And RefPeriod.PERIODE_ID >=  (  Select 
                                      min (MinRefPeriod.PERIODE_ID)  
                                    From 
                                    ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM MinRefPeriod
                                    Where
                                       (1=1)
                                         And MinRefPeriod.FRESH_IN                        = 1
                                         And MinRefPeriod.CURRENT_IN                      = 1
                                         And MinRefPeriod.CLOSURE_DT                      Is Null
                                         And ( MinRefPeriod.PERIODE_DATE_FIN  >=  add_months(current_date ,-12) And MinRefPeriod.PERIODE_DATE_DEB  <= add_months(current_date ,-12))
                                  )
;
.if errorcode <> 0 then .quit 1
Collect stat On ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM Column (PERIODE_ID);
.if errorcode <> 0 then .quit 1

-----------------------------
-- CAT_W_SOFT_REFCOM_JOUR_MATRICE_GDT
-----------------------------
Delete From  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE_GDT
;Insert into ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE_GDT
(
  PERIODE_ID              ,
  TYPE_COMMANDE_ID        ,
  CATEGORIE_CLIENT_ID     ,
  SEG_COM_ID_INI          ,
  SEG_COM_ID_FINAL        ,
  ACTE_ID                 ,
  ACTE_REM_ID             ,
  FLAG_ACT_REM            ,
  FLAG_PEC_PERPVC         ,
  ACTE_VALO               ,
  ACTE_FAMILLE_KPI        ,
  TAUX_MARGE              ,
  UNITE_CD                ,
  CA_MARKETING            ,
  HUMAINDIGITAL  
)
Select
  Matrice.PERIODE_ID              as PERIODE_ID               ,
  Matrice.TYPE_COMMANDE_ID        as TYPE_COMMANDE_ID         ,
  Matrice.CATEGORIE_CLIENT_ID     as CATEGORIE_CLIENT_ID      ,
  Matrice.SEG_COM_ID_INI          as SEG_COM_ID_INI           ,
  Matrice.SEG_COM_ID_FINAL        as SEG_COM_ID_FINAL         ,
  Matrice.ACTE_ID                 as ACTE_ID                  ,
  Acte.ACTE_REM_ID                as ACTE_REM_ID              ,
  Acte.FLAG_ACT_REM               as FLAG_ACT_REM             ,
  Acte.FLAG_PEC_PERPVC            as FLAG_PEC_PERPVC          ,
  Acte.ACTE_VALO                  as ACTE_VALO                ,
  Acte.ACTE_FAMILLE_KPI           as ACTE_FAMILLE_KPI         ,
  Acte.TAUX_MARGE                 as TAUX_MARGE               ,
  Acte.UNITE_CD                   as UNITE_CD                 ,
  Acte.CA_MARKETING               as CA_MARKETING             ,
  RefKPI.HUMAINDIGITAL            as HUMAINDIGITAL  
From
  ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM  Matrice
  Inner Join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      RefPeriod.PERIODE_ID            = Matrice.PERIODE_ID
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
      On    Matrice.PERIODE_ID              = Acte.PERIODE_ID
        And Matrice.ACTE_ID                 = Acte.ACTE_ID
        And Acte.CURRENT_IN                 = 1
        And Acte.CLOSURE_DT                 is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM RefKPI
      On    RefKPI.PERIODE_ID              = Acte.PERIODE_ID
        And RefKPI.FAMILLE_KPI_ID          = Acte.ACTE_FAMILLE_KPI
        And RefKPI.CURRENT_IN              = 1
        And RefKPI.CLOSURE_DT              Is Null
Where
  (1=1)
  And Matrice.CURRENT_IN                 =1
  And Matrice.CLOSURE_DT                 is null
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE_GDT;
.if errorcode <> 0 then .quit 1

-----------------------------
-- CAT_W_SOFT_REFCOM_JOUR_EAN_GDT
-----------------------------
Delete From  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN_GDT
;Insert into ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN_GDT
(
  PRODUCT_ID                ,
  TYPE_PRODUIT              ,
  CODE_EAN                  ,
  PRODUIT_DS                ,
  CODE_TAC                  ,
  PERIODE_ID                ,
  SEG_COM_ID                ,
  SEG_COM_AGG_ID            ,
  TYPE_SERVICE              ,
  RGR_TYPE_SRV_CD           ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  CODE_MIGRATION            ,
  TARIF_HT                  ,
  START_COMM_DT             ,
  END_COMM_DT               
)
Select
  RefProduit.PRODUCT_ID                                                                     as PRODUCT_ID                 ,
  RefProduit.TYPE_PRODUIT                                                                   as TYPE_PRODUIT               ,
  RefProduit.CODE_EAN                                                                       as CODE_EAN                   ,
  RefProduit.PRODUIT_DS                                                                     as PRODUIT_DS                 ,
  RefProduit.CODE_TAC                                                                       as CODE_TAC                   ,
  Coalesce(RefProduit.PERIODE_ID              ,'${P_PIL_049}')                              as PERIODE_ID                 ,
  Coalesce(RefSegCom.SEG_COM_ID               ,'${P_PIL_022}')                              as SEG_COM_ID                 ,
  Coalesce(RefSegType.SEG_COM_AGG_ID          ,'${P_PIL_022}')                              as SEG_COM_AGG_ID             ,
  RefSegCom.TYPE_SERVICE                                                                    as TYPE_SERVICE               ,
  RefSegProd.RGR_TYPE_SRV_CD                                                                as RGR_TYPE_SRV_CD            ,
  Coalesce(RefCat.MIGRATION_REGROUPEMENT_ID   ,'${P_PIL_023}')                              as MIGRATION_REGROUPEMENT_ID  ,
  Coalesce(RegMigPossible.MIGRATION_POSSIBLE  ,'${P_PIL_020}')                              as MIGRATION_POSSIBLE         ,
  Coalesce(RefCat.CODE_MIGRATION              ,'${P_PIL_024}')                              as CODE_MIGRATION             ,
  Coalesce(RefProduit.TARIF_HT                ,0)                                           as TARIF_HT                   ,
  RefProduit.DATE_DEBUT                                                                     as START_COMM_DT              ,
  RefProduit.DATE_FIN                                                                       as END_COMM_DT                
From
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_EAN RefProduit
  Inner join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      RefPeriod.PERIODE_ID            = RefProduit.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
      On    RefProduit.PRODUCT_ID           = RefSegCom.PRODUCT_ID
        And RefProduit.PERIODE_ID           = RefSegCom.PERIODE_ID
        And RefSegCom.CURRENT_IN            = 1
        And RefSegCom.CLOSURE_DT            is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegProd
      On    RefProduit.PRODUCT_ID           = RefSegProd.PRODUCT_ID
        And RefProduit.PERIODE_ID           = RefSegProd.PERIODE_ID
        And RefSegProd.CURRENT_IN            = 1
        And RefSegProd.CLOSURE_DT            is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCat
    On    RefSegCom.SEG_COM_ID              = RefCat.SEG_COM_ID
      And RefSegCom.PERIODE_ID              = RefCat.PERIODE_ID
      And RefCat.CURRENT_IN                 = 1
      And RefCat.CLOSURE_DT                 is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSegType
    On    RefSegCom.SEG_COM_ID              = RefSegType.SEG_COM_ID
      And RefSegCom.PERIODE_ID              = RefSegType.PERIODE_ID
      And RefSegType.CURRENT_IN             = 1
      And RefSegType.CLOSURE_DT             is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REGR_MIGR_PILCOM RegMigPossible
    On    RefCat.MIGRATION_REGROUPEMENT_ID  = RegMigPossible.MIGRATION_REGROUPEMENT_ID
      And RefCat.PERIODE_ID                 = RegMigPossible.PERIODE_ID
      And RegMigPossible.CURRENT_IN         = 1
      And RegMigPossible.CLOSURE_DT         is null
Where
  (1=1)
  And RefProduit.CURRENT_IN                 =1
  And RefProduit.CLOSURE_DT                 is null
Qualify Row_Number() Over (Partition by   RefProduit.CODE_EAN             ,
                                          RefProduit.PERIODE_ID           
                            Order by      RefProduit.PRODUCT_ID asc
                          )=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN_GDT;
.if errorcode <> 0 then .quit 1

-----------------------------
-- CAT_W_REFCOM_MAT_JOUR_DECLA_GDT
-----------------------------
Delete from ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA_GDT
;Insert Into ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA_GDT
(
  PERIODE_ID                ,
  ACTE_REM_ID               ,
  PRODUCT_ID_PRE            ,
  SEG_COM_ID_PRE            ,
  SEG_COM_AGG_ID_PRE        ,
  CODE_MIGR_PRE             ,
  OPER_ID_PRE               ,
  PRODUCT_ID_FINAL          ,
  PRODUCT_DS_FINAL          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  CODE_MIGR_FINAL           ,
  OPER_ID_FINAL             ,
  TYPE_SERVICE_FINAL        ,
  TYPE_COMMANDE_ID          ,
  ACT_CD                    ,
  FLAG_ACT_REM              ,
  FLAG_PEC_PERPVC           ,
  ACTE_VALO                 ,
  ACTE_FAMILLE_KPI          ,
  KPI_ID                    ,
  TAUX_MARGE                ,
  UNITE_CD                  ,
  CA_MARKETING              ,
  HUMAINDIGITAL
)
Select
  Mat.PERIODE_ID                                                                  as PERIODE_ID                       ,
  Mat.ACTE_REM_ID                                                                 as ACTE_REM_ID                      ,
  Mat.PRODUCT_ID_INI                                                              as PRODUCT_ID_PRE                   ,
  PrdIni.SEG_COM_ID                                                               as SEG_COM_ID_PRE                   ,
  PrdIni.SEG_COM_AGG_ID                                                           as SEG_COM_AGG_ID_PRE               ,
  PrdIni.CODE_MIGRATION                                                           as CODE_MIGR_PRE                    ,
  Case  when Mat.PRODUCT_ID_INI = 'ND'
      Then
          Null
      Else
          'RMV'
  End                                                                             as OPER_ID_PRE                      ,
  Mat.PRODUCT_ID_FINAL                                                            as PRODUCT_ID_FINAL                 ,
  PrdFin.PRODUCT_DS                                                               as PRODUCT_DS_FINAL                 ,
  PrdFin.SEG_COM_ID                                                               as SEG_COM_ID_FINAL                 ,
  Coalesce(PrdFin.SEG_COM_AGG_ID          ,'CODECAT INCONNU')                     as SEG_COM_AGG_ID_FINAL             ,
  PrdFin.CODE_MIGRATION                                                           as CODE_MIGR_FINAL                  ,
  'ADD'                                                                           as OPER_ID_FINAL                    ,
  PrdFin.TYPE_SERVICE                                                             as TYPE_SERVICE_FINAL               ,
  Mat.TYPE_COMMANDE_ID                                                            as TYPE_COMMANDE_ID                 ,
  Mat.ACTE_ID                                                                     as ACT_CD                           ,
  MatActePil.FLAG_ACT_REM                                                         as FLAG_ACT_REM                     ,
  MatActePil.FLAG_PEC_PERPVC                                                      as FLAG_PEC_PERPVC                  ,
  MatActePil.ACTE_VALO                                                            as ACTE_VALO                        ,
  MatActePil.ACTE_FAMILLE_KPI                                                     as ACTE_FAMILLE_KPI                 ,
  Kpi.KPI_ID                                                                      as KPI_ID                           ,
  MatActePil.TAUX_MARGE                                                           as TAUX_MARGE                       ,
  MatActePil.UNITE_CD                                                             as UNITE_CD                         ,
  MatActePil.CA_MARKETING                                                         as CA_MARKETING                     ,
  Kpi.HUMAINDIGITAL                                                               as HUMAINDIGITAL
From
  ${KNB_PCO_REFCOM}.V_CAT_R_MAT_DECLA Mat
   Inner Join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      RefPeriod.PERIODE_ID      = Mat.PERIODE_ID
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA PrdIni
    On Mat.PERIODE_ID                 = PrdIni.PERIODE_ID
      And Mat.PRODUCT_ID_INI          = PrdIni.PRODUCT_ID
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA PrdFin
    On Mat.PERIODE_ID                 = PrdFin.PERIODE_ID
      And Mat.PRODUCT_ID_FINAL        = PrdFin.PRODUCT_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM MatActePil
    On Mat.PERIODE_ID                 = MatActePil.PERIODE_ID
      And Mat.ACTE_ID                 = MatActePil.ACTE_ID
      And MatActePil.FRESH_IN         = 1
      And MatActePil.CURRENT_IN       = 1
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM Kpi
    On Mat.PERIODE_ID                 = Kpi.PERIODE_ID
      And MatActePil.ACTE_FAMILLE_KPI = Kpi.FAMILLE_KPI_ID
      And Kpi.CURRENT_IN              = 1
      And Kpi.FRESH_IN                = 1
Where (1                              = 1)
  And Mat.CURRENT_IN                  = 1
  And Mat.FRESH_IN                    = 1
  --And Mat.COHERENCE_IN                = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA_GDT;
.if errorcode <> 0 then .quit 1


------------------------------------------------------------------------------------------
-- Recuperation des champs Refcom Produit Fictif 
------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_CALC
(  
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  PRODUCT_ID_FINAL          ,
  PRODUCT_DS_FINAL          ,
  PERIODE_ID                ,
  TYPE_COMMANDE_ID          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  TYPE_SERVICE_FINAL        ,
  ACT_ID                    ,
  CODE_MIGR_FINAL           ,
  ACT_REM_ID                ,
  FLAG_ACT_REM              ,
  FLAG_PEC_PERPVC           ,
  ACTE_VALO                 ,
  ACTE_FAMILLE_KPI          ,
  TAUX_MARGE                ,
  TYPE_MVT_FINAL            ,
  TERMINAL_PRICE            ,
  TERMINAL_PRICE_HT         ,
  TARIF_HT                  ,
  PRODUCT_ID_GDT            ,
  ACT_UNITE_CD              ,   
  HUMAINDIGITAL             ,     
  CA_MARKETING    
)
  
Select
  Placement.ACTE_ID                                     As ACTE_ID              ,
  Placement.ORDER_DEPOSIT_DT                            As ORDER_DEPOSIT_DT     ,
  Coalesce(RefCat.PRODUCT_ID         ,'${P_PIL_021}')   As PRODUCT_ID_FINAL     ,
  RefCat.PRODUIT_DS                                     As PRODUCT_DS_FINAL     ,  
  Placement.PERIODE_ID                                  As PERIODE_ID           ,
  '${P_PIL_026}'                                        As TYPE_COMMANDE_ID     ,  
  --Coalesce(Matrice.TYPE_COMMANDE_ID,'${P_PIL_026}')   As TYPE_COMMANDE_ID     ,
  Coalesce(RefSeg.SEG_COM_ID         ,'${P_PIL_022}')   As SEG_COM_ID_FINAL     ,
  Coalesce(RefSegType.SEG_COM_AGG_ID ,'${P_PIL_024}')   As SEG_COM_AGG_ID_FINAL ,
  RefSeg.TYPE_SERVICE                                   As TYPE_SERVICE_FINAL   ,   
  Coalesce(Matrice.ACTE_ID           ,'${P_PIL_220}')   As ACT_ID               ,
  Coalesce(RefCatSeg.CODE_MIGRATION  ,'${P_PIL_024}')   As CODE_MIGR_FINAL      ,
  Acte.ACTE_REM_ID                                      As ACT_REM_ID           ,
  Acte.FLAG_ACT_REM                                     As FLAG_ACT_REM         ,
  Acte.FLAG_PEC_PERPVC                                  As FLAG_PEC_PERPVC      ,
  Acte.ACTE_VALO                                        As ACTE_VALO            ,
  Acte.ACTE_FAMILLE_KPI                                 As ACTE_FAMILLE_KPI     ,
  Acte.TAUX_MARGE                                       As TAUX_MARGE           ,
  Placement.EXT_OPER_ID                                 As TYPE_MVT_FINAL       ,
  Placement.TERMINAL_PRICE                              As TERMINAL_PRICE       ,
  Placement.TERMINAL_PRICE_HT                           As TERMINAL_PRICE_HT    ,
  Null                                                  As TARIF_HT             ,
  Null                                                  As PRODUCT_ID_GDT       ,
  Acte.UNITE_CD                                         As ACT_UNITE_CD         ,   
  RefKPI.HUMAINDIGITAL                                  As HUMAINDIGITAL        ,     
  Acte.CA_MARKETING                                     As CA_MARKETING     
                   
  From
  ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_EXRACT Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_FICTIF RefCat
     On    Placement.EXTERNAL_PRODUCT_ID  = RefCat.PRODUCT_ID
     And   Placement.PERIODE_ID =  RefCat.PERIODE_ID
     And RefCat.CURRENT_IN                       = 1
     And RefCat.FRESH_IN                         = 1
   Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSeg
     On   RefSeg.PERIODE_ID  = RefCat.PERIODE_ID
      And RefSeg.PRODUCT_ID  =  RefCat.PRODUCT_ID
      And RefSeg.CURRENT_IN                =  1
      And RefSeg.CLOSURE_DT                Is Null    
   Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM  Matrice
      On   Matrice.PERIODE_ID = RefCat.PERIODE_ID
	   And Matrice.TYPE_COMMANDE_ID               = '${P_PIL_026}' 
       And Matrice.SEG_COM_ID_INI                 = '${P_PIL_211}'
	   And Matrice.SEG_COM_ID_FINAL               = Coalesce(RefSeg.SEG_COM_ID,'${P_PIL_022}')
       And Matrice.CURRENT_IN                     = 1
       And Matrice.FRESH_IN                       = 1
       And Matrice.CLOSURE_DT                     Is Null
   Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
      On Matrice.PERIODE_ID           = Acte.PERIODE_ID
     And Matrice.ACTE_ID              = Acte.ACTE_ID
     And Acte.CURRENT_IN              = 1
     And Acte.CLOSURE_DT             Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSegType
      On    RefSeg.SEG_COM_ID        = RefSegType.SEG_COM_ID
        And RefSeg.PERIODE_ID        = RefSegType.PERIODE_ID
        And RefSegType.FRESH_IN      = 1
        And RefSegType.CURRENT_IN    = 1
        And RefSegType.CLOSURE_DT    is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCatSeg
      On    RefSeg.SEG_COM_ID        = RefCatSeg.SEG_COM_ID
        And RefSeg.PERIODE_ID        = RefCatSeg.PERIODE_ID
        And RefCatSeg.CURRENT_IN        = 1
        And RefCatSeg.CLOSURE_DT        is null
 Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM   RefKPI
     On      RefKPI.PERIODE_ID       = Acte.PERIODE_ID
        And  RefKPI.FAMILLE_KPI_ID   = Acte.ACTE_FAMILLE_KPI
        And  RefKPI.CURRENT_IN       = 1
        And  RefKPI.CLOSURE_DT       Is Null

Where
  (1=1)
  And Placement.TYPE_PRODUIT In ('ASSURANCE','SERV_GDT')
;

.if errorcode <> 0 then .quit 1

   
---------------------------------------------------------------------------
--Recuperation des champs Refcom EAN 
---------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_CALC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  PRODUCT_ID_FINAL          ,
  PRODUCT_DS_FINAL          ,
  PERIODE_ID                ,
  TYPE_COMMANDE_ID          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  TYPE_SERVICE_FINAL        ,
  ACT_ID                    ,
  CODE_MIGR_FINAL           ,
  ACT_REM_ID                ,
  FLAG_ACT_REM              ,
  FLAG_PEC_PERPVC           ,
  ACTE_VALO                 ,
  ACTE_FAMILLE_KPI          ,
  TAUX_MARGE                ,
  TYPE_MVT_FINAL            ,
  TERMINAL_PRICE            ,
  TERMINAL_PRICE_HT         ,
  TARIF_HT                  ,
  PRODUCT_ID_GDT            ,
  ACT_UNITE_CD              ,   
  HUMAINDIGITAL             ,     
  CA_MARKETING    
)

Select
  Placement.ACTE_ID                                                As ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                                       As ORDER_DEPOSIT_DT           ,
  Coalesce(RefEAN.PRODUCT_ID      ,   '${P_PIL_021}')              As PRODUCT_ID_FINAL           ,
  RefEAN.PRODUIT_DS                                                As PRODUCT_DS_FINAL           ,
  Placement.PERIODE_ID                                             As PERIODE_ID                 ,
  Case When Placement.TYPE_PRODUIT = 'TERMINAL'
     Then 'TMS'
   Else '${P_PIL_026}'  
  End                                                              As TYPE_COMMANDE_ID_AGR       ,  
  --Coalesce(Mat.TYPE_COMMANDE_ID ,'${P_PIL_026}')                 As TYPE_COMMANDE_ID           ,
  Coalesce(RefEAN.SEG_COM_ID      ,'${P_PIL_022}')                 As SEG_COM_ID_FINAL           ,
  Coalesce(RefEAN.SEG_COM_AGG_ID  ,'${P_PIL_024}')                 As SEG_COM_AGG_ID_FINAL       ,
  RefEAN.TYPE_SERVICE                                              As TYPE_SERVICE_FINAL         ,
  Coalesce(Mat.ACTE_ID            ,'${P_PIL_220}')                 As ACT_ID                     ,
  Coalesce(RefEAN.CODE_MIGRATION  ,'${P_PIL_024}')                 As CODE_MIGR_FINAL            ,
  Mat.ACTE_REM_ID                                                  As ACT_REM_ID                 ,
  Mat.FLAG_ACT_REM                                                 As FLAG_ACT_REM               ,
  Mat.FLAG_PEC_PERPVC                                              As FLAG_PEC_PERPVC            ,
  Mat.ACTE_VALO                                                    As ACTE_VALO                  ,
  Mat.ACTE_FAMILLE_KPI                                             As ACTE_FAMILLE_KPI           ,
  Mat.TAUX_MARGE                                                   As TAUX_MARGE                 ,
  Placement.EXT_OPER_ID                                            As TYPE_MVT_FINAL             ,
  Placement.TERMINAL_PRICE                                         As TERMINAL_PRICE             ,
  Placement.TERMINAL_PRICE_HT                                      As TERMINAL_PRICE_HT          ,
  RefEAN.TARIF_HT                                                  As TARIF_HT                   ,
  Substr(Placement.EXTERNAL_PRODUCT_ID,1,13)                       As PRODUCT_ID_GDT             ,
  Mat.UNITE_CD                                                     As ACT_UNITE_CD               ,   
  Mat.HUMAINDIGITAL                                                As HUMAINDIGITAL              ,     
  Mat.CA_MARKETING                                                 As CA_MARKETING     
   
From 
  ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_EXRACT Placement
  Left Outer Join  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN_GDT RefEAN
    On    Substr(Placement.EXTERNAL_PRODUCT_ID,1,13)  = RefEAN.CODE_EAN
   And    Placement.PERIODE_ID                        = RefEAN.PERIODE_ID
 Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE_GDT Mat
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On    TYPE_COMMANDE_ID_AGR                          = Mat.TYPE_COMMANDE_ID
      And '${P_PIL_211}'                                = Mat.SEG_COM_ID_INI
      And Coalesce(RefEAN.SEG_COM_ID,  '${P_PIL_022}')  = Mat.SEG_COM_ID_FINAL
      And Placement.PERIODE_ID                          = Mat.PERIODE_ID

Where
  (1=1)
    And Placement.TYPE_PRODUIT In ('TERMINAL','ACCESSOIRE','SERV_ORANGE') 
;

.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------
--Recuperation des champs Refcom DECLA
---------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_CALC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  PRODUCT_ID_FINAL          ,
  PRODUCT_DS_FINAL          ,
  PERIODE_ID                ,
  TYPE_COMMANDE_ID          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  TYPE_SERVICE_FINAL        ,
  ACT_ID                    ,
  CODE_MIGR_FINAL           ,
  ACT_REM_ID                ,
  FLAG_ACT_REM              ,
  FLAG_PEC_PERPVC           ,
  ACTE_VALO                 ,
  ACTE_FAMILLE_KPI          ,
  TAUX_MARGE                ,
  TYPE_MVT_FINAL            ,
  TERMINAL_PRICE            ,
  TERMINAL_PRICE_HT         ,
  TARIF_HT                  ,
  PRODUCT_ID_GDT            ,
  ACT_UNITE_CD              ,   
  HUMAINDIGITAL             ,     
  CA_MARKETING    
)

Select
  Placement.ACTE_ID                                                As ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                                       As ORDER_DEPOSIT_DT           ,
  Coalesce(MatDec.PRODUCT_ID_FINAL     ,'${P_PIL_021}')            As PRODUCT_ID_FINAL           ,
  MatDec.PRODUCT_DS_FINAL                                          As PRODUCT_DS_FINAL           ,
  Placement.PERIODE_ID                                             As PERIODE_ID                 ,
  '${P_PIL_026}'                                                   As TYPE_COMMANDE_ID           ,  
  --Coalesce(MatDec.TYPE_COMMANDE_ID   ,'${P_PIL_026}')            As TYPE_COMMANDE_ID           ,
  Coalesce(MatDec.SEG_COM_ID_FINAL     ,'${P_PIL_022}')            As SEG_COM_ID_FINAL           ,
  Coalesce(MatDec.SEG_COM_AGG_ID_FINAL ,'${P_PIL_024}')            As SEG_COM_AGG_ID_FINAL       ,
  MatDec.TYPE_SERVICE_FINAL                                        As TYPE_SERVICE_FINAL         ,
  Coalesce(MatDec.ACT_CD               ,'${P_PIL_220}')            As ACT_ID                     ,
  Coalesce(MatDec.CODE_MIGR_FINAL      ,'${P_PIL_024}')            As CODE_MIGR_FINAL            ,
  MatDec.ACTE_REM_ID                                               As ACT_REM_ID                 , 
  MatDec.FLAG_ACT_REM                                              As FLAG_ACT_REM               , 
  MatDec.FLAG_PEC_PERPVC                                           As FLAG_PEC_PERPVC            , 
  MatDec.ACTE_VALO                                                 As ACTE_VALO                  ,
  MatDec.ACTE_FAMILLE_KPI                                          As ACTE_FAMILLE_KPI           ,
  MatDec.TAUX_MARGE                                                As TAUX_MARGE                 ,
  Placement.EXT_OPER_ID                                            As TYPE_MVT_FINAL             ,
  Placement.TERMINAL_PRICE                                         As TERMINAL_PRICE             ,
  Placement.TERMINAL_PRICE_HT                                      As TERMINAL_PRICE_HT          ,
  Null                                                             As TARIF_HT                   ,
  Null                                                             As PRODUCT_ID_GDT             ,
  MatDec.UNITE_CD                                                  As ACT_UNITE_CD               ,   
  MatDec.HUMAINDIGITAL                                             As HUMAINDIGITAL              ,     
  MatDec.CA_MARKETING                                              As CA_MARKETING     
   
From 
  ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_EXRACT Placement
  Left Outer Join  ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA_GDT MatDec
    On    Placement.EXTERNAL_PRODUCT_ID                 = MatDec.ACTE_REM_ID
   And    Placement.PERIODE_ID                          = MatDec.PERIODE_ID

Where
  (1=1)
    And Placement.TYPE_PRODUIT In ('PRO') 
;

.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_CALC;
.if errorcode <> 0 then .quit 1
