-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERC_Placement_Cold_Alimentation_Step4_CalculIDActe.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de calcul des actes
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/07/2014      MCA         Creation
-- 19/08/2014      MCA         Indus
--------------------------------------------------------------------------------

.set width 2500;



----------------------------------------------------------------*/
-- Etape 1 : Delete de la table TMP                             */
----------------------------------------------------------------*/
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------*/
-- Etape 2 : Alimentation de la table TMP                       */
----------------------------------------------------------------*/



INSERT INTO ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC
(
  ACTE_ID                     ,
  EXTERNAL_ACTE_ID            ,
  INTRNL_SOURCE_ID            ,
  TYPE_SOURCE_ID              ,
  APPLI_SOURCE_ID             ,
  REPRISE_ID                  ,
  AGENT_ID                    ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  EDO_ID                      ,
  IMEI                        ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  ORDER_DEPOSIT_DT            ,
  REPRISE_TS                  ,
  REPRISE_VAL                 ,
  PROMOTION_VAL               ,
  RECEPTION_TS                ,
  TRTMT_TS                    ,
  HOMOLOGATION_TS             ,
  HOMOLOGATION_CD             ,
  POST_TRTMT_VAL              ,
  AJUSTMNT_RAISON             ,
  AJUSTMNT_VAL                ,
  ECART_RAISON                ,
  FIRST_NAME_NM               ,
  LAST_NAME_NM                ,
  MSISDN                      ,
  REPRISE_NUM                 ,
  BON_ID                      ,
  MODE_PAIEMENT               ,
  PAIEMENT_STATUT             ,
  CONSUMPTN_TS                ,
  MAX_VALIDITY_TS             ,
  CANCELLATION_TS             ,
  EQPT_CD                     ,
  BRAND_SHOP_CD               ,
  SEGMENT                     ,
  RAISON_SOCIALE              ,
  SIRET                       ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
SELECT
  ActeId.ACTE_ID                        as ACTE_ID,
  Placement.EXTERNAL_ACTE_ID            as EXTERNAL_ACTE_ID                  ,
  Placement.INTRNL_SOURCE_ID            as INTRNL_SOURCE_ID                  ,
  Placement.TYPE_SOURCE_ID              as TYPE_SOURCE_ID                    ,
  Placement.APPLI_SOURCE_ID             as APPLI_SOURCE_ID                   ,
  Placement.REPRISE_ID                  as REPRISE_ID                        ,
  Placement.AGENT_ID                    as AGENT_ID                          ,
  Placement.STORE_CD                    as STORE_CD                          ,
  Placement.ADV_STORE_CD                as ADV_STORE_CD                      ,
  Placement.EDO_ID                      as EDO_ID                            ,
  Placement.IMEI                        as IMEI                              ,
  Placement.TERMINAL_BRAND              as TERMINAL_BRAND                    ,
  Placement.TERMINAL_MODEL              as TERMINAL_MODEL                    ,
  Placement.ORDER_DEPOSIT_DT            as ORDER_DEPOSIT_DT                  ,
  Placement.REPRISE_TS                  as REPRISE_TS                        ,
  Placement.REPRISE_VAL                 as REPRISE_VAL                       ,
  Placement.PROMOTION_VAL               as PROMOTION_VAL                     ,
  Placement.RECEPTION_TS                as RECEPTION_TS                      ,
  Placement.TRTMT_TS                    as TRTMT_TS                          ,
  Placement.HOMOLOGATION_TS             as HOMOLOGATION_TS                   ,
  Placement.HOMOLOGATION_CD             as HOMOLOGATION_CD                   ,
  Placement.POST_TRTMT_VAL              as POST_TRTMT_VAL                    ,
  Placement.AJUSTMNT_RAISON             as AJUSTMNT_RAISON                   ,
  Placement.AJUSTMNT_VAL                as AJUSTMNT_VAL                      ,
  Placement.ECART_RAISON                as ECART_RAISON                      ,
  Placement.FIRST_NAME_NM               as FIRST_NAME_NM                     ,
  Placement.LAST_NAME_NM                as LAST_NAME_NM                      ,
  Placement.MSISDN                      as MSISDN                            ,
  Placement.REPRISE_NUM                 as REPRISE_NUM                       ,
  Placement.BON_ID                      as BON_ID                            ,
  Placement.MODE_PAIEMENT               as MODE_PAIEMENT                     ,
  Placement.PAIEMENT_STATUT             as PAIEMENT_STATUT                   ,
  Placement.CONSUMPTN_TS                as CONSUMPTN_TS                      ,
  Placement.MAX_VALIDITY_TS             as MAX_VALIDITY_TS                   ,
  Placement.CANCELLATION_TS             as CANCELLATION_TS                   ,
  Placement.EQPT_CD                     as EQPT_CD                           ,
  Placement.BRAND_SHOP_CD               as BRAND_SHOP_CD                     ,
  Placement.SEGMENT                     as SEGMENT                           ,
  Placement.RAISON_SOCIALE              as RAISON_SOCIALE                    ,
  Placement.SIRET                       as SIRET                             ,
  0                                     as HOT_IN                            ,
  Current_Timestamp(0)                  as CREATION_TS                       ,
  Current_Timestamp(0)                  as LAST_MODIF_TS                     ,
  1                                     as FRESH_IN                          ,
  0                                     as COHERENCE_IN
FROM
-- on prend tout le contenu de la table miroir tmp
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_EXT Placement
  -- on jointe avec la table gen pour genere le bon nombre de ligne
  Inner Join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN ActeId
    On    Placement.EXTERNAL_ACTE_ID = ActeId.EXTERNAL_ACTE_ID
      And Placement.TYPE_SOURCE_ID   = ActeId.TYPE_SOURCE_ID
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC
;
.if errorcode <> 0 then .quit 1
.quit 0
