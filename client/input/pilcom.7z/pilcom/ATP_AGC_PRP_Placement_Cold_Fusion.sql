-- $HEADER: mm2pco/current/sql/ATP_AGC_PRP_Placement_Cold_Fusion.sql 13_05#11 26-JUN-2019 11:39:06 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_PRP_Placement_Cold_Fusion.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de fusion d'enrichissement de placements à froid pour AGC PREPAID
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/04/2014      YZH         Creation
-- 22/01/2016      MDE         Evol Pilcom Digital 
-- 25/04/2016      MDE         Evol : Axe Canal sur AGC   
-- 27/12/2016      JCR         Evol : Ajouts Champs Ventes associées
-- 01/02/2017      HOB         Evol :Enrichissement VAs
-- 04/10/2017      HOB         Evol CIA CID/PID/FIRST ET IOBSP
-- 22/02/2019      SSI         Alimentation Champs ORG_AGENT_IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_PRP_C All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_PRP_C
(
    ACTE_ID                               ,
    EXTERNAL_ACTE_ID                      ,
    INTRNL_SOURCE_ID                      ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    ORDER_TYPE_CD                         ,
    PRODUCT_TYPE                          ,
    EXTERNAL_PRODUCT_ID                   ,
    EXTERNAL_PRODUCT_ID_SEC               ,
    MOUVEMENT                             ,
    MSISDN_PORTED                         ,
    PAR_IMEI_CD                           ,
    PAR_IMSI_CD                           ,
    PAR_SIM_CD                            ,
    SIM_EAN_CD                            ,
    MAIN_MSISDN_ID                        ,
    SECOND_MSISDN_ID                      ,
    HOLDER_CIVILITY                       ,
    HOLDER_LAST_NAME                      ,
    HOLDER_FIRST_NAME                     ,
    HOLDER_SIRET                          ,
    HOLDER_ADDRESS_NM_1                   ,
    HOLDER_ADDRESS_NM_2                   ,
    HOLDER_ADDRESS_NM_3                   ,
    HOLDER_ADDRRESS_NM_4                  ,
    HOLDER_ADDRESS_POSTAL_CD              ,
    HOLDER_CITY                           ,
    HOLDER_BANK_CD                        ,
    HOLDER_OFFICE_CD                      ,
    HOLRDER_ACCOUNT_CD                    ,
    HOLDER_RIB_KEY_CD                     ,
    HOLDER_MAIL                           ,
    CUSTOMER_CLIENT_NU_ADV                ,
    CUSTOMER_DOSSIER_NU_ADV               ,
    CUSTOMER_MARKET_SEG                   ,
    CUSTOMER_CIVILITY                     ,
    CUSTOMER_LAST_NAME_NM                 ,
    CUSTOMER_FIRST_NAME_NM                ,
    CUSTOMER_NAME_NM                      ,
    CUSTOMER_SIRET                        ,
    CUSTOMER_ADDRESS_1_NM                 ,
    CUSTOMER_ADDRESS_2_NM                 ,
    CUSTOMER_ADDRESS_3_NM                 ,
    CUSTOMER_ADDRESS_4_NM                 ,
    CUSTOMER_ADDRESS_POSTAL_CD            ,
    CUSTOMER_CITY                         ,
    CUSTOMER_CATEGORIE                    ,
    SERVICE_ACCESS_ID                     ,
    PAR_CID_ID                            ,
    PAR_PID_ID                            ,
    PAR_FIRST_IN                          ,
    LINE_ID                               ,
    MASTER_LINE_ID                        ,
    CONVERGENT_IN                         ,
    BSS_PARTY_KNB_ID                      ,
    BSS_PARTY_EXTERNL_ID                  ,
    FREG_PARTY_KNB_ID                     ,
    FREG_PARTY_EXTERNL_ID                 ,
    RESIL_MOB_DT                          ,
    RESIL_MOB_MOTIF                       ,
    RESIL_MOB_MOTIF_DS                    ,
    STORE_CD                              ,
    ADV_STORE_CD                          ,
    FLAG_TYPE_PTN_NTK                     ,
    AGENT_ID                              ,
    ORG_AGENT_IOBSP                       ,
    AGENT_LAST_NAME_NM                    ,
    AGENT_FIRST_NAME_NM                   ,
    EDO_ID                                ,
    TYPE_EDO                              ,
    ORG_EDO_IOBSP                         ,
    NETWRK_TYP_EDO_ID                     ,
    FLAG_PLT_CONV                         ,
    FLAG_TEAM_MKT                         ,
    FLAG_TYPE_CMP                         ,
    FLAG_TYPE_GEO                         ,
    FLAG_TYPE_CPT_NTK                     ,
    PAR_DEPARTMNT_ID                      ,
    PAR_BU_CD                             ,
    PAR_POSTAL_CD                         ,
    PAR_INSEE_CD                          ,
    PAR_GEO_MACROZONE                     ,
    PAR_UNIFIED_PARTY_ID                  ,
    PAR_PARTY_REGRPMNT_ID                 ,
    PAR_IRIS2000_CD                       ,
    PAR_FIBER_IN                          ,
    CLOSURE_DT                            ,
    QUEUE_TS                              ,
    RUN_ID                                ,
    STREAMING_TS                          ,
    CREATION_TS                           ,
    LAST_MODIF_TS                         ,
    HOT_IN                                ,
    FRESH_IN                              ,
    COHERENCE_IN                           
)
Select                                                                                                    
      Placement.ACTE_ID                                        AS ACTE_ID                    , 
      Placement.EXTERNAL_ACTE_ID                               AS EXTERNAL_ACTE_ID           , 
      Placement.INTRNL_SOURCE_ID                               AS INTRNL_SOURCE_ID           ,
      Placement.CONTEXT_ID                                     AS CONTEXT_ID                 , 
      Placement.EXTERNAL_ORDER_ID                              AS EXTERNAL_ORDER_ID          , 
      Placement.ORDER_DEPOSIT_TS                               AS ORDER_DEPOSIT_TS           ,
      Placement.ORDER_DEPOSIT_DT                               AS ORDER_DEPOSIT_DT           ,
      Placement.ORDER_TYPE_CD                                  AS ORDER_TYPE_CD              , 
      Placement.PRODUCT_TYPE                                   AS PRODUCT_TYPE               , 
      Placement.EXTERNAL_PRODUCT_ID                            AS EXTERNAL_PRODUCT_ID        ,
      Placement.EXTERNAL_PRODUCT_ID_SEC                        AS EXTERNAL_PRODUCT_ID_SEC    , 
      Placement.MOUVEMENT                                      AS MOUVEMENT                  , 
      Placement.MSISDN_PORTED                                  AS MSISDN_PORTED              ,
      Placement.PAR_IMEI_CD                                    AS PAR_IMEI_CD                ,
      RefIMSI.PAR_IMSI                                         AS PAR_IMSI_CD                ,
      Placement.PAR_SIM_CD                                     AS PAR_SIM_CD                 ,
      Placement.SIM_EAN_CD                                     AS SIM_EAN_CD                 ,             
      Placement.MAIN_MSISDN_ID                                 AS MAIN_MSISDN_ID             ,
      Placement.SECOND_MSISDN_ID                               AS SECOND_MSISDN_ID           ,
      Placement.HOLDER_CIVILITY                                AS HOLDER_CIVILITY            ,
      Placement.HOLDER_LAST_NAME                               AS HOLDER_LAST_NAME           ,
      Placement.HOLDER_FIRST_NAME                              AS HOLDER_FIRST_NAME          ,
      Placement.HOLDER_SIRET                                   AS HOLDER_SIRET               ,
      Placement.HOLDER_ADDRESS_NM_1                            AS HOLDER_ADDRESS_NM_1        ,
      Placement.HOLDER_ADDRESS_NM_2                            AS HOLDER_ADDRESS_NM_2        ,
      Placement.HOLDER_ADDRESS_NM_3                            AS HOLDER_ADDRESS_NM_3        ,
      Placement.HOLDER_ADDRRESS_NM_4                           AS HOLDER_ADDRRESS_NM_4       ,
      Placement.HOLDER_ADDRESS_POSTAL_CD                       AS HOLDER_ADDRESS_POSTAL_CD   ,
      Placement.HOLDER_CITY                                    AS HOLDER_CITY                ,
      Placement.HOLDER_BANK_CD                                 AS HOLDER_BANK_CD             ,
      Placement.HOLDER_OFFICE_CD                               AS HOLDER_OFFICE_CD           ,
      Placement.HOLRDER_ACCOUNT_CD                             AS HOLRDER_ACCOUNT_CD         ,
      Placement.HOLDER_RIB_KEY_CD                              AS HOLDER_RIB_KEY_CD          ,
      Placement.HOLDER_MAIL                                    AS HOLDER_MAIL                ,
      Placement.CUSTOMER_CLIENT_NU_ADV                         AS CUSTOMER_CLIENT_NU_ADV     ,
      Placement.CUSTOMER_DOSSIER_NU_ADV                        AS CUSTOMER_DOSSIER_NU_ADV    ,
      Placement.CUSTOMER_MARKET_SEG                            AS CUSTOMER_MARKET_SEG        ,
      Placement.CUSTOMER_CIVILITY                              AS CUSTOMER_CIVILITY          ,
      Placement.CUSTOMER_LAST_NAME_NM                          AS CUSTOMER_LAST_NAME_NM      ,
      Placement.CUSTOMER_FIRST_NAME_NM                         AS CUSTOMER_FIRST_NAME_NM     ,
      Placement.CUSTOMER_NAME_NM                               AS CUSTOMER_NAME_NM           ,
      Placement.CUSTOMER_SIRET                                 AS CUSTOMER_SIRET             ,
      Placement.CUSTOMER_ADDRESS_1_NM                          AS CUSTOMER_ADDRESS_1_NM      ,
      Placement.CUSTOMER_ADDRESS_2_NM                          AS CUSTOMER_ADDRESS_2_NM      ,
      Placement.CUSTOMER_ADDRESS_3_NM                          AS CUSTOMER_ADDRESS_3_NM      ,
      Placement.CUSTOMER_ADDRESS_4_NM                          AS CUSTOMER_ADDRESS_4_NM      ,
      Placement.CUSTOMER_ADDRESS_POSTAL_CD                     AS CUSTOMER_ADDRESS_POSTAL_CD ,
      Placement.CUSTOMER_CITY                                  AS CUSTOMER_CITY              ,
      Placement.CUSTOMER_CATEGORIE                             AS CUSTOMER_CATEGORIE         ,
      RefDMC.SERVICE_ACCESS_ID                                 AS SERVICE_ACCESS_ID          ,
      RefDMC.PAR_CID_ID                                        as PAR_CID_ID                 ,
      RefDMC.PAR_PID_ID                                        as PAR_PID_ID                 ,
      RefDMC.PAR_FIRST_IN                                      as PAR_FIRST_IN               ,
      RefDMC.LINE_ID                                           AS LINE_ID                    ,
      RefDMC.MASTER_LINE_ID                                    AS MASTER_LINE_ID             ,
      RefDMC.CONVERGENT_IN                                     AS CONVERGENT_IN              ,
      RefDMC.BSS_PARTY_KNB_ID                                  AS BSS_PARTY_KNB_ID           ,
      RefDMC.BSS_PARTY_EXTERNL_ID                              AS BSS_PARTY_EXTERNL_ID       ,
      RefDMC.FREG_PARTY_KNB_ID                                 AS FREG_PARTY_KNB_ID          ,
      RefDMC.FREG_PARTY_EXTERNL_ID                             AS FREG_PARTY_EXTERNL_ID      ,
      RefIMSI.RESIL_MOB_DT                                     AS RESIL_MOB_DT               ,
      RefIMSI.RESIL_MOB_MOTIF                                  AS RESIL_MOB_MOTIF            ,
      RefIMSI.RESIL_MOB_MOTIF_DS                               AS RESIL_MOB_MOTIF_DS         ,
      Placement.STORE_CD                                       AS STORE_CD                   ,
      Placement.ADV_STORE_CD                                   AS ADV_STORE_CD               ,
      RefO3.FLAG_TYPE_PTN_NTK                                  AS FLAG_TYPE_PTN_NTK          ,
      Placement.AGENT_ID                                       AS AGENT_ID                   ,
      Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
      End                                                      as ORG_AGENT_IOBSP            ,
      Placement.AGENT_LAST_NAME_NM                             AS AGENT_LAST_NAME_NM         ,
      Placement.AGENT_FIRST_NAME_NM                            AS AGENT_FIRST_NAME_NM        ,
      RefO3.EDO_ID                                             AS EDO_ID                     ,
      RefO3.TYPE_EDO                                           AS TYPE_EDO                   ,
      Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
      End                                                      as ORG_EDO_IOBSP              ,
      RefO3.NETWRK_TYP_EDO_ID                                  AS NETWRK_TYP_EDO_ID          ,
      RefO3.FLAG_PLT_CONV                                      AS FLAG_PLT_CONV              ,
      RefO3.FLAG_TEAM_MKT                                      AS FLAG_TEAM_MKT              ,
      RefO3.FLAG_TYPE_CMP                                      AS FLAG_TYPE_CMP              ,
      RefO3.FLAG_TYPE_GEO                                      AS FLAG_TYPE_GEO              ,
      RefO3.FLAG_TYPE_CPT_NTK                                  AS FLAG_TYPE_CPT_NTK          ,
      RefDMC.DEPARTMNT_ID                                      AS PAR_DEPARTMNT_ID           ,
      RefDMC.BU_CD                                             AS PAR_BU_CD                  ,
      RefDMC.POSTAL_CD                                         AS PAR_POSTAL_CD              ,
      RefDMC.INSEE_CD                                          AS PAR_INSEE_CD               ,
      RefIRIS.PAR_GEO_MACROZONE                                AS PAR_GEO_MACROZONE          ,
      Coalesce(RefDMC.PAR_UNIFIED_PARTY_ID,DMC.PAR_UNIFIED_PARTY_ID) AS PAR_UNIFIED_PARTY_ID ,
      Coalesce(RefDMC.PAR_PARTY_REGRPMNT_ID,DMC.PAR_PARTY_REGRPMNT_ID) AS PAR_PARTY_REGRPMNT_ID ,
      RefIRIS.PAR_IRIS2000_CD                                  AS PAR_IRIS2000_CD            ,
      RefFIBER.FIBER_IN                                        AS PAR_FIBER_IN               ,
      Placement.CLOSURE_DT                                     AS CLOSURE_DT                 ,
      Placement.QUEUE_TS                                       AS QUEUE_TS                   ,
      Placement.RUN_ID                                         AS RUN_ID                     ,
      Placement.STREAMING_TS                                   AS STREAMING_TS               ,
      Current_Timestamp(0)                                     AS CREATION_TS                ,
      Current_Timestamp(0)                                     AS LAST_MODIF_TS              ,
      0                                                        AS HOT_IN                     ,
      1                                                        AS FRESH_IN                   ,
      0                                                        AS COHERENCE_IN                                                                                              
From  
      ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_C_EXTR Placement
Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_C_O3 RefO3
On     Placement.ACTE_ID  =  RefO3.ACTE_ID  
Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_DMC_SA  RefDMC
On     Placement.ACTE_ID  =  RefDMC.ACTE_ID
Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_DMC DMC
On     Placement.ACTE_ID  =  DMC.ACTE_ID
Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_CLIIMSI RefIMSI
On     Placement.ACTE_ID  =  RefIMSI.ACTE_ID
Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_IRIS RefIRIS
On     Placement.ACTE_ID  =  RefIRIS.ACTE_ID
Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_FIBER RefFIBER
On     Placement.ACTE_ID  =  RefFIBER.ACTE_ID
Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
   On    RefO3.EDO_ID   = EdoOBK.EDO_ID
     And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
     And EdoOBK.VAL_AXS_CLSSF_ID  in ('ORANGEBANK')    And  EdoOBK.CURRENT_IN        = 1
Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
   On   Placement.AGENT_ID=CuidOBK.AGENT_ID
   And  Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
  And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))


  Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By Placement.ORDER_DEPOSIT_TS asc)=1     
-- D'autres enrichissement à ajouter      

;                          
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_PRP_C;
.if errorcode <> 0 then .quit 1

.quit 0
