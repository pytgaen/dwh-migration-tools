-- $HEADER:   ATP_PIF_Acte_Alimentation_Step1_PreCalcul.sql
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_PreCalcul_ACTE_PIF.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ORD_W_ACTE_PIF_EXT
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 11/08/2016     HLA         Création
-- 15/02/2017     HLA         Modification ACT_TS pour calcul de la période
---------------------------------------------------------------------------------

.set width 2000;
-- **************************************************************
-- Alimentation de la table ORD_W_ACTE_PIF_EXT
-- **************************************************************

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_PIF_EXT;
.if errorcode <> 0 then .quit 1

-------------STEP 1: pour les offres
Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_PIF_EXT
( 
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ACT_TS                    ,
  PERIODE_ID                ,
  TYPE_COMMANDE_ID          ,
  SEG_COM_ID                ,
  TYPE_SERVICE               
)
Select
  Placement.ACTE_ID                                          as ACTE_ID                     ,
  Placement.ORDER_DEPOSIT_DT                                 as ORDER_DEPOSIT_DT            ,
  Case When Placement.DATE_REM_TS is NOT NULL 
        Then Placement.DATE_REM_TS
       When Placement.DATE_TRANS_TS is NOT NULL 
        Then Placement.DATE_TRANS_TS
       When Placement.DATE_ELIG_TS is NOT NULL 
        Then Placement.DATE_ELIG_TS
         Else Placement.DATE_CREATE_TS       
  END                                                        as  ACT_TS                     ,
  Coalesce(Period.PERIODE_ID, ${P_PIL_049} )                 as  PERIODE_ID                 ,
 Case When Placement.DATE_REM_TS is NOT NULL 
        Then 'ACQ'
       When Placement.DATE_TRANS_TS is NOT NULL 
        Then 'TRANS'
       When Placement.DATE_ELIG_TS is NOT NULL 
        Then 'ELIG'
         Else 'INIT'        
    END                                                      as  TYPE_COMMANDE_ID          ,
  'PIF'                                                      as  SEG_COM_ID                ,
  'ND'                                                       as  TYPE_SERVICE               

From                         
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_PIF Placement
  
  Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
        On      ACT_TS           >= Period.PERIODE_DATE_DEB
            And ACT_TS           <= Period.PERIODE_DATE_FIN
            And Period.FRESH_IN         = 1
            And Period.CURRENT_IN       = 1
            And Period.CLOSURE_DT       Is Null
              
 ;       
 .if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_PIF_EXT;
.if errorcode <> 0 then .quit 1 

