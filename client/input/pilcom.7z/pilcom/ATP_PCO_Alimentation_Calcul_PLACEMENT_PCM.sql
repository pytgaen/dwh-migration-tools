-- $HEADER: mm2pco/current/sql/ATP_PCO_Alimentation_Calcul_PLACEMENT_PCM.sql 13_05#4 25-JUN-2018 18:31:13 LXQG9925
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_Alimentation_Calcul_PLACEMENT_PCM.sql$
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     GMA         Création
-- 06/02/2014     AID         Indus
-- 26/04/2018     LMU         Modification dans le cadre des RCS
-- 24/02/2021     EVI         PILCOM-758 : REFONTE DIGITAL - Fiabilisation Gestion ANNUL 
---------------------------------------------------------------------------------

.set width 2000;


-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM
-- Type PCM
-- **************************************************************

--Paramètre attendu : Les bornes de dates

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM
(
  EXTERNAL_ACTE_ID    ,
  TYPE_SOURCE_ID      ,
  ID_BCR              ,
  TYPE_COMMANDE       ,  -- PCM
  DATESAISIEBCR       ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  PRESFACT_CO         ,
  USCM_CO_ADV         ,
  USCM_CO_PCM         ,
  NUMCATALMAIL        ,
  CD_CANALDIST        ,
  ADV_CO_BCR          ,
  PDV_XI_BCR          ,
  STATUTBCR_CO        ,
  DUREEREENG          ,
  TB_TYPEBCR          ,
  NBPOINTSUTIL        ,
  COMPLEMENT          ,
  DATEVALIDATION      ,
  NUMEROIMEI          ,
  PV_POINTVENTE       ,
  CODEVENDEUR         ,
  SEGMENTVALEURCLIENT ,
  ID_PROGRAMMEFID     ,
  REFARTICLE          ,
  ID_MODELE           ,
  PRIXARTICLE         ,
  CODE_TAC            ,
  CONSEIL_XI          ,
  ACT_ID              ,
  ID_USER             ,
  IDENTIFIANT_FT      ,
  DATECATALMAIL       ,
  TYPECATALMAIL       ,
  TYPEENVOI           ,
  SCORE_IN            ,
  SEG_VAL             ,
  STATUT_SAISIE_CAL   ,
  STATUT_VALID_CAL    ,
  STATUT_VALID_BCR    ,
  STATUT_CLOS         ,
  STATUT_TRANSM_BO    ,
  STATUT_ANNUL        ,
  STATUT_NON_CONCLU   ,
  STATUT_NON_PERENNE  ,
  AID                 ,
  ND                  ,
  INDCARTESIM     --RCS
)
Select
  trim(cast (cast(CalcTmp.ID_BCR as decimal(10,0) format '---------9')as varchar(255))) as EXTERNAL_ACTE_ID,
  ${TYPE_SOURCE_ID}            as TYPE_SOURCE_ID, 
  CalcTmp.ID_BCR                as ID_BCR               ,
  'PCM'                         as TYPE_COMMANDE        ,
  CalcTmp.DATESAISIEBCR         as DATESAISIEBCR        ,
  CalcTmp.DOSSIER_NU            as DOSSIER_NU           ,
  CalcTmp.CLIENT_NU             as CLIENT_NU            ,
  Prestation.PRESFACT_CO_FORM   as PRESFACT_CO          ,
  CalcTmp.USCM_CO_ADV           as USCM_CO_ADV          ,
  CalcTmp.USCM_CO_PCM           as USCM_CO_PCM          ,
  CalcTmp.NUMCATALMAIL          as NUMCATALMAIL         ,
  CalcTmp.CD_CANALDIST          as CD_CANALDIST         ,
  CalcTmp.ADV_CO_BCR            as ADV_CO_BCR           ,
  CalcTmp.PDV_XI_BCR            as PDV_XI_BCR           ,
  CalcTmp.STATUTBCR_CO          as STATUTBCR_CO         ,
  CalcTmp.DUREEREENG            as DUREEREENG           ,
  CalcTmp.TB_TYPEBCR            as TB_TYPEBCR           ,
  CalcTmp.NBPOINTSUTIL          as NBPOINTSUTIL         ,
  CalcTmp.COMPLEMENT            as COMPLEMENT           ,
  CalcTmp.DATEVALIDATION        as DATEVALIDATION       ,
  CalcTmp.NUMEROIMEI            as NUMEROIMEI           ,
  CalcTmp.PV_POINTVENTE         as PV_POINTVENTE        ,
  CalcTmp.CODEVENDEUR           as CODEVENDEUR          ,
  CalcTmp.SEGMENTVALEURCLIENT   as SEGMENTVALEURCLIENT  ,
  CalcTmp.ID_PROGRAMMEFID       as ID_PROGRAMMEFID      ,
  CalcTmp.REFARTICLE            as REFARTICLE           ,
  CalcTmp.ID_MODELE             as ID_MODELE            ,
  CalcTmp.PRIXARTICLE           as PRIXARTICLE          ,
  CalcTmp.CODE_TAC              as CODE_TAC             ,
  CalcTmp.CONSEIL_XI            as CONSEIL_XI           ,
  CalcTmp.ACT_ID                as ACT_ID               ,
  CalcTmp.ID_USER               as ID_USER              ,
  CalcTmp.IDENTIFIANT_FT        as IDENTIFIANT_FT       ,
  CalcTmp.DATECATALMAIL         as DATECATALMAIL        ,
  CalcTmp.TYPECATALMAIL         as TYPECATALMAIL        ,
  CalcTmp.TYPEENVOI             as TYPEENVOI            ,
  CalcTmp.SCORE_IN              as SCORE_IN             ,
  CalcTmp.SEG_VAL               as SEG_VAL              ,
  CalcTmp.STATUT_SAISIE_CAL     as STATUT_SAISIE_CAL    ,
  CalcTmp.STATUT_VALID_CAL      as STATUT_VALID_CAL     ,
  CalcTmp.STATUT_VALID_BCR      as STATUT_VALID_BCR     ,
  CalcTmp.STATUT_CLOS           as STATUT_CLOS          ,
  CalcTmp.STATUT_TRANSM_BO      as STATUT_TRANSM_BO     ,
  CalcTmp.STATUT_ANNUL          as STATUT_ANNUL         ,
  CASE WHEN CalcTmp.STATUT_NON_CONCLU <= CalcTmp.DATESAISIEBCR THEN CalcTmp.STATUT_NON_CONCLU
       WHEN CalcTmp.STATUTBCR_CO In('AB','AN') And CalcTmp.STATUT_ANNUL > CalcTmp.DATESAISIEBCR THEN CalcTmp.STATUT_ANNUL
       ELSE NULL
  END                           as STATUT_NON_CONCLU    ,
  CASE WHEN CalcTmp.STATUT_NON_PERENNE <= (CalcTmp.DATESAISIEBCR + 60) THEN CalcTmp.STATUT_NON_PERENNE
       ELSE NULL
  END                           as STATUT_NON_PERENNE   ,
  CalcTmp.AID                   as AID                  ,
  CalcTmp.ND                    as ND                   ,
  CalcTmp.INDCARTESIM       as INDCARTESIM
From
  (
    Select                 
      Brc.ID_BCR                                    as ID_BCR               ,
      Coalesce(DATESTATUT.SAISI,Brc.DATESAISIEBCR)  as DATESAISIEBCR        ,
      Brc.DOSSIER_NU                                as DOSSIER_NU           ,
      Brc.CLIENT_NU                                 as CLIENT_NU            ,
      Null                                          as PRESFACT_CO          ,
      Null                                          as USCM_CO_ADV          ,
      Brc.USCM_CO_PCM                               as USCM_CO_PCM          ,
      Brc.NUMCATALMAIL                              as NUMCATALMAIL         ,
      Brc.CD_CANALDIST                              as CD_CANALDIST         ,
      Brc.ADV_CO_BCR                                as ADV_CO_BCR           ,
      Brc.PDV_XI_BCR                                as PDV_XI_BCR           ,
      Brc.STATUTBCR_CO                              as STATUTBCR_CO         ,
      Brc.DUREEREENG                                as DUREEREENG           ,
      Brc.TB_TYPEBCR                                as TB_TYPEBCR           ,
      Brc.NBPOINTSUTIL                              as NBPOINTSUTIL         ,
      Brc.COMPLEMENT                                as COMPLEMENT           ,
      Brc.DATEVALIDATION                            as DATEVALIDATION       ,
      Brc.NUMEROIMEI                                as NUMEROIMEI           ,
      Brc.PV_POINTVENTE                             as PV_POINTVENTE        ,
      Brc.CODEVENDEUR                               as CODEVENDEUR          ,
      Brc.SEGMENTVALEURCLIENT                       as SEGMENTVALEURCLIENT  ,
      Brc.ID_PROGRAMMEFID                           as ID_PROGRAMMEFID      ,
      -- Calcul des attribut du mobile depuis TFCOMMARTICLE
      Matricule.COMMARTICLE_REFARTICLE              as REFARTICLE           ,
      Matricule.COMMARTICLE_ID_MODELE               as ID_MODELE            ,
      Matricule.COMMARTICLE_PRIXARTICLE             as PRIXARTICLE          ,
      substr(Trim(Brc.NUMEROIMEI),1,8)              as CODE_TAC             ,
      -- Calcul du Vendeur ayant réaliser la saisie depuis THSTATUTBCR
      PremVendeur.STATUTBCR_CONSEIL_XI              as CONSEIL_XI           ,
      PremVendeur.STATUTBCR_ACT_ID                  as ACT_ID               ,
      -- Calcul du Vendeur ayant réaliser la saisie depuis TDACTEUR
      PremVendeur.ACTEUR_USER                       as ID_USER              ,
      PremVendeur.ACTEUR_IDENTIFIANT_FT             as IDENTIFIANT_FT       ,
      -- Calcul sur le catalogue Par mail depuis TFCATALMAIL
      Mail.CATALMAIL_DATECATALMAIL                  as DATECATALMAIL        ,
      Case  When Mail.CATALMAIL_TYPEENVOI = 'E'
              Then 'X'
            Else Mail.CATALMAIL_TYPECATALMAIL
      End                                           as TYPECATALMAIL        ,
      MAIL.CATALMAIL_TYPEENVOI                      as TYPEENVOI            ,
      -- Calcul des attribut générique du dossier depuis TDDOSSIER
      --   Dossier.DOSSIER_CO_CODOFTP                as CO_CODOFTP           ,
      --   Dossier.DOSSIER_DT_FIN_PREV_CONTRAT       as DT_FIN_PREV_CONTRAT  ,
      -- Calcul du score de fragilité du client depuis SGM_H_SEGMENT_IPS
      Coalesce(SEG.SCORE_IN,'SC')                   as SCORE_IN             ,
      -- Calcul du Segment dossier depuis TFSEGCORP
      SEGCORP_SEG_VAL                               as SEG_VAL              ,
      -- Calcul des Dates depuis la table d'histo
      DATESTATUT.SAISI                              as STATUT_SAISIE_CAL    ,
      DATESTATUT.VALID                              as STATUT_VALID_CAL     ,
      Brc.DATEVALIDATION                            as STATUT_VALID_BCR     ,
      DATESTATUT.CLOS                               as STATUT_CLOS          ,
      DATESTATUT.TRANSMIS                           as STATUT_TRANSM_BO     ,
      DATESTATUT.ANNUL                              as STATUT_ANNUL         ,
      DATESTATUT.NON_CONCLU                         as STATUT_NON_CONCLU    ,
      DATESTATUT.NON_PERENNE                        as STATUT_NON_PERENNE   ,
      -- Calcul des attributs Clients des offres convergeantes
      Srv.AID                                       as AID                  ,
      Srv.ND                                        as ND                   ,
      Brc.INDCARTESIM                           as INDCARTESIM
    From
      ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC Brc
      --Jointure pour récupérer les Identifiant du Mobile
      Left Outer Join ${KNB_IBU_SOC_V}.VF_TFCOMMARTICLE Matricule
        On   Brc.ID_BCR = Matricule.COMMARTICLE_ID_BCR
      --Jointure pour récupérer les attributs Internet (Offre convergeante)
      Left Outer Join
      (
        Select
          Tf.SRVTECH_DOSSIER_NU,
          Tf.SRVTECH_CLIENT_NU,
          Max(Case When Tf.SRVTECH_CO_SERVBASE='SBINT' Then substr(Trim(Tf.SRVTECH_NU_TEL),2,Character_Length(Tf.SRVTECH_NU_TEL)-1) Else Null End) as AID,
          Max(Case When Tf.SRVTECH_CO_SERVBASE='SBIP' Then Trim(Tf.SRVTECH_NU_TEL) Else Null End) as ND 
        From
          ${KNB_IBU_SOC_V}.VF_TFSRVTECH Tf
        Where
              Tf.SRVTECH_CO_SERVBASE In ('SBIP','SBINT')
          And Tf.SRVTECH_PLTF_CO not In ('MOBI','VI1')
          And Tf.SRVTECH_IN_SRV_ACTIF = 'A'
        Group By Tf.SRVTECH_DOSSIER_NU,Tf.SRVTECH_CLIENT_NU
      ) Srv
        On    Brc.DOSSIER_NU  = Srv.SRVTECH_DOSSIER_NU
          And Brc.CLIENT_NU   = Srv.SRVTECH_CLIENT_NU
      --Jointure pour récupérer les attributs Sur le 1er vendeur
      Left Outer Join
      (
        Select
          PremStatut.STATUTBCR_ID_BCR               as STATUTBCR_ID_BCR       ,
          PremStatut.STATUTBCR_SB_STATUTBCR         as STATUTBCR_SB_STATUTBCR ,
          PremStatut.STATUTBCR_CONSEIL_XI           as STATUTBCR_CONSEIL_XI   ,
          PremStatut.STATUTBCR_ACT_ID               as STATUTBCR_ACT_ID       ,
          PremStatut.STATUTBCR_DATESTATUT           as STATUTBCR_DATESTATUT   ,
          Acteur.ACTEUR_ID                          as ACTEUR_ID              ,
          Acteur.ACTEUR_USER                        as ACTEUR_USER            ,
          Acteur.ACTEUR_IDENTIFIANT_FT              as ACTEUR_IDENTIFIANT_FT  
        From
          (
            Select
              STATUTBCR_ID_BCR                      as STATUTBCR_ID_BCR       ,
              STATUTBCR_SB_STATUTBCR                as STATUTBCR_SB_STATUTBCR ,
              STATUTBCR_CONSEIL_XI                  as STATUTBCR_CONSEIL_XI   ,
              STATUTBCR_ACT_ID                      as STATUTBCR_ACT_ID       ,
              STATUTBCR_DATESTATUT                  as STATUTBCR_DATESTATUT   
            From
              ${KNB_IBU_SOC_V}.VF_THSTATUTBCR
            Where
              STATUTBCR_SB_STATUTBCR in ('SA')
            Qualify Row_Number() Over(Partition by STATUTBCR_ID_BCR Order By STATUTBCR_DATESTATUT Asc) = 1
          )PremStatut
          Left outer Join ${KNB_IBU_SOC_V}.TDACTEUR Acteur
            On    PremStatut.STATUTBCR_ACT_ID   = Acteur.ACTEUR_ID
              And Acteur.CURRENT_IN             = 1
              And Acteur.CLOSURE_DT             is null
        Qualify Row_Number() Over(Partition by PremStatut.STATUTBCR_ID_BCR Order By Acteur.ACTEUR_IDENTIFIANT_FT Desc)=1
      )PremVendeur
        On    Brc.ID_BCR         = PremVendeur.STATUTBCR_ID_BCR
      --Jointure pour récupérer le mail
      Left Outer Join ${KNB_IBU_SOC_V}.VF_TFCATALMAIL Mail
        On    Brc.NUMCATALMAIL   = Mail.CATALMAIL_NUMCATALMAIL
      --Jointure pour récupérer le segment
      Left Outer Join ${KNB_COM_SOC_V_PRS}.VF_SGM_H_SEGMENT_IPS Seg
        On    Brc.CLIENT_NU      = Seg.RBTBILLSYSACCTID
          And Brc.DOSSIER_NU     = Seg.MSISDN_ID 
          And Brc.DATESAISIEBCR >= Seg.VALIDITY_START_TS
          And Brc.DATESAISIEBCR <= Seg.VALIDITY_END_TS
      Left Outer Join ${KNB_IBU_SOC_V}.VF_TFSEGCORP SegVal
        On    Brc.CLIENT_NU      = SegVal.SEGCORP_CLIENT_NU 
          And Brc.DOSSIER_NU     = SegVal.SEGCORP_DOSSIER_NU
      --Jointure pour récupérer les dates des statuts 
      Left Outer Join 
      (
        Select
          STATUTBCR_ID_BCR    as STATUTBCR_ID_BCR,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('SA')                          Then STATUTBCR_DATESTATUT  End) as SAISI       ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('VA','TR','RE','RL','RV','EP') Then STATUTBCR_DATESTATUT  End) as VALID       ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('LP','LV')                     Then STATUTBCR_DATESTATUT  End) as CLOS        ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('TR')                          Then STATUTBCR_DATESTATUT  End) as TRANSMIS    ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('AB','AN')                     Then STATUTBCR_DATESTATUT  End) as ANNUL       ,
          Min(Case When STATUTBCR_SB_STATUTBCR in (${L_PIL_045})                  Then STATUTBCR_DATESTATUT  End) as NON_CONCLU  ,
          Min(Case When STATUTBCR_SB_STATUTBCR in (${L_PIL_046})                  Then STATUTBCR_DATESTATUT  End) as NON_PERENNE
        From
          ${KNB_IBU_SOC_V}.VF_THSTATUTBCR
        Group by
          STATUTBCR_ID_BCR
      )DATESTATUT
        on Brc.ID_BCR                 = DATESTATUT.STATUTBCR_ID_BCR
  )CalcTmp
  --On réalise l'enrichissement du PRESFAC_CO dans TFSRVFCDOS
  Left Outer Join ${KNB_IBU_SOC_V}.VF_TFSRVFCDOS ParcADV
    On    CalcTmp.DOSSIER_NU  = ParcADV.SRVFCDOS_DOSSIER_NU
      And CalcTmp.CLIENT_NU   = ParcADV.SRVFCDOS_CLIENT_NU
      And CalcTmp.DATESAISIEBCR >  ParcADV.SRVFCDOS_DT_DEBUT
      And CalcTmp.DATESAISIEBCR <= coalesce(ParcADV.SRVFCDOS_DT_FIN,ParcADV.SRVFCDOS_DT_FIN_FACT)
      And ParcADV.CLOSURE_DT is null
  Left Outer Join ${KNB_IBU_SOC_V}.VF_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO=Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT = 'O'
      And Prestation.CURRENT_IN=1
Qualify row_number() over (partition by CalcTmp.ID_BCR order by coalesce(ParcADV.SRVFCDOS_DT_FIN,ParcADV.SRVFCDOS_DT_FIN_FACT) desc, ParcADV.SRVFCDOS_DT_DEBUT desc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1


;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM;
.if errorcode <> 0 then .quit 1













-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM
-- Type RCS
-- **************************************************************


Insert into ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM
(
  EXTERNAL_ACTE_ID    ,
  TYPE_SOURCE_ID      ,
  ID_BCR              ,
  TYPE_COMMANDE       , -- RCS
  DATESAISIEBCR       ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  PRESFACT_CO         ,
  USCM_CO_ADV         ,
  USCM_CO_PCM         ,
  NUMCATALMAIL        ,
  CD_CANALDIST        ,
  ADV_CO_BCR          ,
  PDV_XI_BCR          ,
  STATUTBCR_CO        ,
  DUREEREENG          ,
  TB_TYPEBCR          , -- RCS
  NBPOINTSUTIL        ,
  COMPLEMENT          ,
  DATEVALIDATION      ,
  NUMEROIMEI          ,
  PV_POINTVENTE       ,
  CODEVENDEUR         ,
  SEGMENTVALEURCLIENT ,
  ID_PROGRAMMEFID     ,
  REFARTICLE          ,
  ID_MODELE           ,
  PRIXARTICLE         ,
  CODE_TAC            ,
  CONSEIL_XI          ,
  ACT_ID              ,
  ID_USER             ,
  IDENTIFIANT_FT      ,
  DATECATALMAIL       ,
  TYPECATALMAIL       ,
  TYPEENVOI           ,
  SCORE_IN            ,
  SEG_VAL             ,
  STATUT_SAISIE_CAL   ,
  STATUT_VALID_CAL    ,
  STATUT_VALID_BCR    ,
  STATUT_CLOS         ,
  STATUT_TRANSM_BO    ,
  STATUT_ANNUL        ,
  STATUT_NON_CONCLU   ,
  STATUT_NON_PERENNE  ,
  AID                 ,
  ND                  ,
  INDCARTESIM          -- RCS
)
Select
  trim(cast (cast(CalcTmp.ID_BCR as decimal(10,0) format '---------9')as varchar(255))) || 'RCS' as EXTERNAL_ACTE_ID,
  ${TYPE_SOURCE_ID}             as TYPE_SOURCE_ID, 
  CalcTmp.ID_BCR                as ID_BCR               ,
  'RCS'                         as TYPE_COMMANDE        ,
  CalcTmp.DATESAISIEBCR         as DATESAISIEBCR        ,
  CalcTmp.DOSSIER_NU            as DOSSIER_NU           ,
  CalcTmp.CLIENT_NU             as CLIENT_NU            ,
  Prestation.PRESFACT_CO_FORM   as PRESFACT_CO          ,
  CalcTmp.USCM_CO_ADV           as USCM_CO_ADV          ,
  CalcTmp.USCM_CO_PCM           as USCM_CO_PCM          ,
  CalcTmp.NUMCATALMAIL          as NUMCATALMAIL         ,
  CalcTmp.CD_CANALDIST          as CD_CANALDIST         ,
  CalcTmp.ADV_CO_BCR            as ADV_CO_BCR           ,
  CalcTmp.PDV_XI_BCR            as PDV_XI_BCR           ,
  CalcTmp.STATUTBCR_CO          as STATUTBCR_CO         ,
  CalcTmp.DUREEREENG            as DUREEREENG           ,
  CalcTmp.TB_TYPEBCR            as TB_TYPEBCR           ,
  CalcTmp.NBPOINTSUTIL          as NBPOINTSUTIL         ,
  CalcTmp.COMPLEMENT            as COMPLEMENT           ,
  CalcTmp.DATEVALIDATION        as DATEVALIDATION       ,
  CalcTmp.NUMEROIMEI            as NUMEROIMEI           ,
  CalcTmp.PV_POINTVENTE         as PV_POINTVENTE        ,
  CalcTmp.CODEVENDEUR           as CODEVENDEUR          ,
  CalcTmp.SEGMENTVALEURCLIENT   as SEGMENTVALEURCLIENT  ,
  CalcTmp.ID_PROGRAMMEFID       as ID_PROGRAMMEFID      ,
  CalcTmp.REFARTICLE            as REFARTICLE           ,
  CalcTmp.ID_MODELE             as ID_MODELE            ,
  CalcTmp.PRIXARTICLE           as PRIXARTICLE          ,
  CalcTmp.CODE_TAC              as CODE_TAC             ,
  CalcTmp.CONSEIL_XI            as CONSEIL_XI           ,
  CalcTmp.ACT_ID                as ACT_ID               ,
  CalcTmp.ID_USER               as ID_USER              ,
  CalcTmp.IDENTIFIANT_FT        as IDENTIFIANT_FT       ,
  CalcTmp.DATECATALMAIL         as DATECATALMAIL        ,
  CalcTmp.TYPECATALMAIL         as TYPECATALMAIL        ,
  CalcTmp.TYPEENVOI             as TYPEENVOI            ,
  CalcTmp.SCORE_IN              as SCORE_IN             ,
  CalcTmp.SEG_VAL               as SEG_VAL              ,
  CalcTmp.STATUT_SAISIE_CAL     as STATUT_SAISIE_CAL    ,
  CalcTmp.STATUT_VALID_CAL      as STATUT_VALID_CAL     ,
  CalcTmp.STATUT_VALID_BCR      as STATUT_VALID_BCR     ,
  CalcTmp.STATUT_CLOS           as STATUT_CLOS          ,
  CalcTmp.STATUT_TRANSM_BO      as STATUT_TRANSM_BO     ,
  CalcTmp.STATUT_ANNUL          as STATUT_ANNUL         ,
  CASE WHEN CalcTmp.STATUT_NON_CONCLU <= CalcTmp.DATESAISIEBCR THEN CalcTmp.STATUT_NON_CONCLU
       WHEN CalcTmp.STATUTBCR_CO In('AB','AN') And CalcTmp.STATUT_ANNUL > CalcTmp.DATESAISIEBCR THEN CalcTmp.STATUT_ANNUL
       ELSE NULL
  END                           as STATUT_NON_CONCLU    ,
  CASE WHEN CalcTmp.STATUT_NON_PERENNE <= (CalcTmp.DATESAISIEBCR + 60) THEN CalcTmp.STATUT_NON_PERENNE
       ELSE NULL
  END                           as STATUT_NON_PERENNE   ,
  CalcTmp.AID                   as AID                  ,
  CalcTmp.ND                    as ND                   ,
  CalcTmp.INDCARTESIM       as INDCARTESIM
From
  (
    Select                 
      Brc.ID_BCR                                    as ID_BCR               ,
      Coalesce(DATESTATUT.SAISI,Brc.DATESAISIEBCR)  as DATESAISIEBCR        ,
      Brc.DOSSIER_NU                                as DOSSIER_NU           ,
      Brc.CLIENT_NU                                 as CLIENT_NU            ,
      Null                                          as PRESFACT_CO          ,
      Null                                          as USCM_CO_ADV          ,
      Brc.USCM_CO_PCM                               as USCM_CO_PCM          ,
      Brc.NUMCATALMAIL                              as NUMCATALMAIL         ,
      Brc.CD_CANALDIST                              as CD_CANALDIST         ,
      Brc.ADV_CO_BCR                                as ADV_CO_BCR           ,
      Brc.PDV_XI_BCR                                as PDV_XI_BCR           ,
      Brc.STATUTBCR_CO                              as STATUTBCR_CO         ,
      Brc.DUREEREENG                                as DUREEREENG           ,
      Brc.TB_TYPEBCR                                as TB_TYPEBCR           ,
      Brc.NBPOINTSUTIL                              as NBPOINTSUTIL         ,
      Brc.COMPLEMENT                                as COMPLEMENT           ,
      Brc.DATEVALIDATION                            as DATEVALIDATION       ,
      Brc.NUMEROIMEI                                as NUMEROIMEI           ,
      Brc.PV_POINTVENTE                             as PV_POINTVENTE        ,
      Brc.CODEVENDEUR                               as CODEVENDEUR          ,
      -- Placements RCS : on force la valeur a 'SC' car dans l'anticipe c'est la valeur par defaut
      'SC'                                          as SEGMENTVALEURCLIENT  ,
      Brc.ID_PROGRAMMEFID                           as ID_PROGRAMMEFID      ,
      -- Calcul des attribut du mobile depuis TFCOMMARTICLE
      Matricule.COMMARTICLE_REFARTICLE              as REFARTICLE           ,
      Matricule.COMMARTICLE_ID_MODELE               as ID_MODELE            ,
      Matricule.COMMARTICLE_PRIXARTICLE             as PRIXARTICLE          ,
      substr(Trim(Brc.NUMEROIMEI),1,8)              as CODE_TAC             ,
      -- Calcul du Vendeur ayant réaliser la saisie depuis THSTATUTBCR
      PremVendeur.STATUTBCR_CONSEIL_XI              as CONSEIL_XI           ,
      PremVendeur.STATUTBCR_ACT_ID                  as ACT_ID               ,
      -- Calcul du Vendeur ayant réaliser la saisie depuis TDACTEUR
      PremVendeur.ACTEUR_USER                       as ID_USER              ,
      PremVendeur.ACTEUR_IDENTIFIANT_FT             as IDENTIFIANT_FT       ,
      -- Calcul sur le catalogue Par mail depuis TFCATALMAIL
      Mail.CATALMAIL_DATECATALMAIL                  as DATECATALMAIL        ,
      Case  When Mail.CATALMAIL_TYPEENVOI = 'E'
              Then 'X'
            Else Mail.CATALMAIL_TYPECATALMAIL
      End                                           as TYPECATALMAIL        ,
      MAIL.CATALMAIL_TYPEENVOI                      as TYPEENVOI            ,
      -- Calcul des attribut générique du dossier depuis TDDOSSIER
      --   Dossier.DOSSIER_CO_CODOFTP                as CO_CODOFTP           ,
      --   Dossier.DOSSIER_DT_FIN_PREV_CONTRAT       as DT_FIN_PREV_CONTRAT  ,
      -- Calcul du score de fragilité du client depuis SGM_H_SEGMENT_IPS
      Coalesce(SEG.SCORE_IN,'SC')                   as SCORE_IN             ,
      -- Calcul du Segment dossier depuis TFSEGCORP
      SEGCORP_SEG_VAL                               as SEG_VAL              ,
      -- Calcul des Dates depuis la table d'histo
      DATESTATUT.SAISI                              as STATUT_SAISIE_CAL    ,
      DATESTATUT.VALID                              as STATUT_VALID_CAL     ,
      Brc.DATEVALIDATION                            as STATUT_VALID_BCR     ,
      DATESTATUT.CLOS                               as STATUT_CLOS          ,
      DATESTATUT.TRANSMIS                           as STATUT_TRANSM_BO     ,
      DATESTATUT.ANNUL                              as STATUT_ANNUL         ,
      DATESTATUT.NON_CONCLU                         as STATUT_NON_CONCLU    ,
      DATESTATUT.NON_PERENNE                        as STATUT_NON_PERENNE   ,
      -- Calcul des attributs Clients des offres convergeantes
      Srv.AID                                       as AID                  ,
      Srv.ND                                        as ND                   ,
      Brc.INDCARTESIM                           as INDCARTESIM
    From
      ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC Brc
      --Jointure pour récupérer les Identifiant du Mobile
      Left Outer Join ${KNB_IBU_SOC_V}.VF_TFCOMMARTICLE Matricule
        On   Brc.ID_BCR = Matricule.COMMARTICLE_ID_BCR
      --Jointure pour récupérer les attributs Internet (Offre convergeante)
      Left Outer Join
      (
        Select
          Tf.SRVTECH_DOSSIER_NU,
          Tf.SRVTECH_CLIENT_NU,
          Max(Case When Tf.SRVTECH_CO_SERVBASE='SBINT' Then substr(Trim(Tf.SRVTECH_NU_TEL),2,Character_Length(Tf.SRVTECH_NU_TEL)-1) Else Null End) as AID,
          Max(Case When Tf.SRVTECH_CO_SERVBASE='SBIP' Then Trim(Tf.SRVTECH_NU_TEL) Else Null End) as ND 
        From
          ${KNB_IBU_SOC_V}.VF_TFSRVTECH Tf
        Where
              Tf.SRVTECH_CO_SERVBASE In ('SBIP','SBINT')
          And Tf.SRVTECH_PLTF_CO not In ('MOBI','VI1')
          And Tf.SRVTECH_IN_SRV_ACTIF = 'A'
        Group By Tf.SRVTECH_DOSSIER_NU,Tf.SRVTECH_CLIENT_NU
      ) Srv
        On    Brc.DOSSIER_NU  = Srv.SRVTECH_DOSSIER_NU
          And Brc.CLIENT_NU   = Srv.SRVTECH_CLIENT_NU
      --Jointure pour récupérer les attributs Sur le 1er vendeur
      Left Outer Join
      (
        Select
          PremStatut.STATUTBCR_ID_BCR               as STATUTBCR_ID_BCR       ,
          PremStatut.STATUTBCR_SB_STATUTBCR         as STATUTBCR_SB_STATUTBCR ,
          PremStatut.STATUTBCR_CONSEIL_XI           as STATUTBCR_CONSEIL_XI   ,
          PremStatut.STATUTBCR_ACT_ID               as STATUTBCR_ACT_ID       ,
          PremStatut.STATUTBCR_DATESTATUT           as STATUTBCR_DATESTATUT   ,
          Acteur.ACTEUR_ID                          as ACTEUR_ID              ,
          Acteur.ACTEUR_USER                        as ACTEUR_USER            ,
          Acteur.ACTEUR_IDENTIFIANT_FT              as ACTEUR_IDENTIFIANT_FT  
        From
          (
            Select
              STATUTBCR_ID_BCR                      as STATUTBCR_ID_BCR       ,
              STATUTBCR_SB_STATUTBCR                as STATUTBCR_SB_STATUTBCR ,
              STATUTBCR_CONSEIL_XI                  as STATUTBCR_CONSEIL_XI   ,
              STATUTBCR_ACT_ID                      as STATUTBCR_ACT_ID       ,
              STATUTBCR_DATESTATUT                  as STATUTBCR_DATESTATUT   
            From
              ${KNB_IBU_SOC_V}.VF_THSTATUTBCR
            Where
              STATUTBCR_SB_STATUTBCR in ('SA')
            Qualify Row_Number() Over(Partition by STATUTBCR_ID_BCR Order By STATUTBCR_DATESTATUT Asc) = 1
          )PremStatut
          Left outer Join ${KNB_IBU_SOC_V}.TDACTEUR Acteur
            On    PremStatut.STATUTBCR_ACT_ID   = Acteur.ACTEUR_ID
              And Acteur.CURRENT_IN             = 1
              And Acteur.CLOSURE_DT             is null
        Qualify Row_Number() Over(Partition by PremStatut.STATUTBCR_ID_BCR Order By Acteur.ACTEUR_IDENTIFIANT_FT Desc)=1
      )PremVendeur
        On    Brc.ID_BCR         = PremVendeur.STATUTBCR_ID_BCR
      --Jointure pour récupérer le mail
      Left Outer Join ${KNB_IBU_SOC_V}.VF_TFCATALMAIL Mail
        On    Brc.NUMCATALMAIL   = Mail.CATALMAIL_NUMCATALMAIL
      --Jointure pour récupérer le segment
      Left Outer Join ${KNB_COM_SOC_V_PRS}.VF_SGM_H_SEGMENT_IPS Seg
        On    Brc.CLIENT_NU      = Seg.RBTBILLSYSACCTID
          And Brc.DOSSIER_NU     = Seg.MSISDN_ID 
          And Brc.DATESAISIEBCR >= Seg.VALIDITY_START_TS
          And Brc.DATESAISIEBCR <= Seg.VALIDITY_END_TS
      Left Outer Join ${KNB_IBU_SOC_V}.VF_TFSEGCORP SegVal
        On    Brc.CLIENT_NU      = SegVal.SEGCORP_CLIENT_NU 
          And Brc.DOSSIER_NU     = SegVal.SEGCORP_DOSSIER_NU
      --Jointure pour récupérer les dates des statuts 
      Left Outer Join 
      (
        Select
          STATUTBCR_ID_BCR    as STATUTBCR_ID_BCR,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('SA')                          Then STATUTBCR_DATESTATUT  End) as SAISI       ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('VA','TR','RE','RL','RV','EP') Then STATUTBCR_DATESTATUT  End) as VALID       ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('LP','LV')                     Then STATUTBCR_DATESTATUT  End) as CLOS        ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('TR')                          Then STATUTBCR_DATESTATUT  End) as TRANSMIS    ,
          Min(Case When STATUTBCR_SB_STATUTBCR in ('AB','AN')                     Then STATUTBCR_DATESTATUT  End) as ANNUL       ,
          Min(Case When STATUTBCR_SB_STATUTBCR in (${L_PIL_045})                  Then STATUTBCR_DATESTATUT  End) as NON_CONCLU  ,
          Min(Case When STATUTBCR_SB_STATUTBCR in (${L_PIL_046})                  Then STATUTBCR_DATESTATUT  End) as NON_PERENNE
        From
          ${KNB_IBU_SOC_V}.VF_THSTATUTBCR
        Group by
          STATUTBCR_ID_BCR
      )DATESTATUT
        on Brc.ID_BCR                 = DATESTATUT.STATUTBCR_ID_BCR
  Where Brc.INDCARTESIM = 'O'  -- Critere RCS
  And   Brc.TB_TYPEBCR = 'E'   -- Critere RCS
  )CalcTmp
  --On réalise l'enrichissement du PRESFAC_CO dans TFSRVFCDOS
  Left Outer Join ${KNB_IBU_SOC_V}.VF_TFSRVFCDOS ParcADV
    On    CalcTmp.DOSSIER_NU  = ParcADV.SRVFCDOS_DOSSIER_NU
      And CalcTmp.CLIENT_NU   = ParcADV.SRVFCDOS_CLIENT_NU
      And CalcTmp.DATESAISIEBCR >  ParcADV.SRVFCDOS_DT_DEBUT
      And CalcTmp.DATESAISIEBCR <= coalesce(ParcADV.SRVFCDOS_DT_FIN,ParcADV.SRVFCDOS_DT_FIN_FACT)
      And ParcADV.CLOSURE_DT is null
  Left Outer Join ${KNB_IBU_SOC_V}.VF_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO=Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT = 'O'
      And Prestation.CURRENT_IN=1

Qualify row_number() over (partition by CalcTmp.ID_BCR order by coalesce(ParcADV.SRVFCDOS_DT_FIN,ParcADV.SRVFCDOS_DT_FIN_FACT) desc, ParcADV.SRVFCDOS_DT_DEBUT desc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1


;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.COM_T_CALCUL_PL_PCM;
.if errorcode <> 0 then .quit 1


