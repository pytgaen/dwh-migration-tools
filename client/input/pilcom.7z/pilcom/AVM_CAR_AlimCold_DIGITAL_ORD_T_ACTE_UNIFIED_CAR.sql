--$HEADER:   %HEADER% 
------------------------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_CAR_AlimCold_DIGITAL_ORD_T_ACTE_UNIFIED_CAR.sql  $                                   
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données à froid de la source ECARE dans la table ORD_T_ACTE_UNIFIED_CAR 
                     
----------------------------------------------------------------------------------------------------- 
--HISTORIQUE                                                                                          
-- DATE             AUTEUR      CREATION/MODIFICATION                                                 
--12/07/2019        SSI          Création                                                             
--10/09/2019        GRH          KPI2020 : Mis à jour du champ  ACT_CA_LINE_AM                        
--10/10/2019        GRH          KPI2020 : Ajout du filtre sur les NS/NSTECH pour data enabler        
--03/07/2020        TCL          Rajout des SIM_CD et SIM_EAN_CD
--29/09/2021        EVI          PILCOM-1021 : Refonte VU : Suppression champs obsolètes
------------------------------------------------------------------------------------------------------


.set width 5000

------------------------------------
-- Table : ORD_W_EXTRACT_CAR_DIGITAL --
------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CAR 
(
  ACTE_ID                             ,
  OPERATOR_PROVIDER_ID                ,
  INTRNL_SOURCE_ID                    ,
  TYPE_SOURCE_ID                      ,
  MASTER_ACTE_ID                      ,
  MASTER_INTRNL_SOURCE_ID             ,
  MASTER_FLAG                         ,
  MASTER_NB_FOUND                     ,
  CPLT_ACTE_ID                        ,
  CPLT_INTRNL_SOURCE_ID               ,
  CPLT_IN                             ,
  RULE_ID                             ,
  OFFSET_NB                           ,
  ACT_TYPE                            ,
  ORDER_EXTERNAL_ID                   ,
  STATUS_CD                           ,
  ACT_UNIFIED_STATUS_CD               ,
  ACT_TS                              ,
  ACT_DT                              ,
  ACT_HH                              ,
  ACT_LAST_UPD_TS                     ,
  ACT_PRODUCT_ID_PRE                  ,
  ACT_SEG_COM_ID_PRE                  ,
  ACT_SEG_COM_AGG_ID_PRE              ,
  ACT_CODE_MIGR_PRE                   ,
  ACT_OPER_ID_PRE                     ,
  ACT_PRODUCT_ID_FINAL                ,
  ACT_SEG_COM_ID_FINAL                ,
  ACT_SEG_COM_AGG_ID_FINAL            ,
  ACT_CODE_MIGR_FINAL                 ,
  ACT_OPER_ID_FINAL                   ,
  ACT_TYPE_SERVICE_FINAL              ,
  ACT_TYPE_COMMANDE_ID                ,
  ACT_DELTA_TARIF                     ,
  ACT_CD                              ,
  ACT_REM_ID                          ,
  ACT_FLAG_ACT_REM                    ,
  ACT_FLAG_PEC_PERPVC                 ,
  ACT_FLAG_PVC_REM                    ,
  ACT_ACTE_VALO                       ,
  ACT_ACTE_FAMILLE_KPI                ,
  ACT_PERIODE_ID                      ,
  ACT_PERIODE_STATUS                  ,
  ACT_PERIODE_CLOSURE_DT              ,
  ORIGIN_CD                           ,
  AGENT_ID                            ,
  AGENT_ID_UPD                        ,
  AGENT_ID_UPD_DT                     ,
  ORG_AGENT_IOBSP                     ,
  AGENT_FIRST_NAME                    ,
  AGENT_LAST_NAME                     ,
  UNIFIED_SHOP_CD                     ,
  ORG_SPE_CANAL_ID_MACRO              ,
  ORG_SPE_CANAL_ID                    ,
  ORG_REM_CHANNEL_CD                  ,
  ORG_CHANNEL_CD                      ,
  ORG_SUB_CHANNEL_CD                  ,
  ORG_SUB_SUB_CHANNEL_CD              ,
  ORG_GT_ACTIVITY                     ,
  ORG_FIDELISATION                    ,
  ORG_WEB_ACTIVITY                    ,
  ORG_AUTO_ACTIVITY                   ,
  ORG_EDO_ID                          ,
  ORG_TYPE_EDO                        ,
  ORG_EDO_IOBSP                       ,
  ORG_FLAG_PLT_CONV                   ,
  ORG_FLAG_TEAM_MKT                   ,
  ORG_FLAG_TYPE_CMP                   ,
  ORG_RESP_EDO_ID                     ,
  ORG_RESP_TYPE_EDO                   ,
  ORG_RESP_FLAG_PLT_CONV              ,
  ACTIVITY_CD                         ,
  ACTIVITY_GROUPNG_CD                 ,
  AUTO_ACTIVITY_IN                    ,
  ORG_TYPE_CD                         ,
  ORG_TEAM_TYPE_ID                    ,
  ORG_TEAM_LEVEL_1_CD                 ,
  ORG_TEAM_LEVEL_1_DS                 ,
  ORG_TEAM_LEVEL_2_CD                 ,
  ORG_TEAM_LEVEL_2_DS                 ,
  ORG_TEAM_LEVEL_3_CD                 ,
  ORG_TEAM_LEVEL_3_DS                 ,
  ORG_TEAM_LEVEL_4_CD                 ,
  ORG_TEAM_LEVEL_4_DS                 ,
  WORK_TEAM_LEVEL_1_CD                ,
  WORK_TEAM_LEVEL_1_DS                ,
  WORK_TEAM_LEVEL_2_CD                ,
  WORK_TEAM_LEVEL_2_DS                ,
  WORK_TEAM_LEVEL_3_CD                ,
  WORK_TEAM_LEVEL_3_DS                ,
  WORK_TEAM_LEVEL_4_CD                ,
  WORK_TEAM_LEVEL_4_DS                ,
  CONFIRMATION_IN                     ,
  CONCLDD_IN                          ,
  COMPTTN_IN                          ,
  COMPTTN_ID                          ,
  PERNNT_IN                           ,
  PERNNT_END_DT                       ,
  PERNNT_MOTIF                        ,
  PERNNT_CALC_END_DT                  ,
  MIGRA_DT                            ,
  MIGRA_NEXT_OFFRE                    ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN      ,
  SEGMENT_DELIVERY_IN_PARK_DT         ,
  ORDER_CANCELING_DT                  ,
  LINE_ID                             ,
  MASTER_LINE_ID                      ,
  CUST_TYPE_CD                        ,
  MSISDN_ID                           ,
  NDS_VALUE_DS                        ,
  EXTERNAL_PARTY_ID                   ,
  RES_VALUE_DS                        ,
  PAR_ACCES_SERVICE                   ,
  TAC_CD                              ,
  IMEI_CD                             ,
  IMSI_CD                             ,
  HOM_START_DT                        ,
  MOB_START_DT                        ,
  I_SCORE_VALUE                       ,
  I_SCORE_TRESHOLD                    ,
  I_SCORE_IN                          ,
  M_SCORE_VALUE                       ,
  M_SCORE_TRESHOLD                    ,
  M_SCORE_IN                          ,
  OSCAR_VALUE                         ,
  CUST_BU_TYPE_CD                     ,
  CUST_BU_CD                          ,
  ADDRESS_TYPE                        ,
  ADDRESS_CONCAT_NM                   ,
  POSTAL_CD                           ,
  INSEE_CD                            ,
  BU_CD                               ,
  DEPARTMNT_ID                        ,
  PAR_GEO_MACROZONE                   ,
  PAR_UNIFIED_PARTY_ID                ,
  PAR_PARTY_REGRPMNT_ID               ,
  PAR_CID_ID                          ,
  PAR_PID_ID                          ,
  PAR_FIRST_IN                        ,
  PAR_IRIS2000_CD                     ,
  COMMARTICLE_RP_REFPRIX_CD           ,
  ACT_CA_LINE_AM                      ,
  ACT_CA_TTC_AM                       ,
  EAN_CD                              ,
  SIM_CD                              ,
  SIM_EAN_CD                          ,
  ORG_RESP_ID                         ,
  EAN_PREVIOUS_CD                     ,
  TAC_PREVIOUS_CD                     ,
  IMEI_PREVIOUS_CD                    ,
  PCM_PREVIOUS_OFFRE_CD               ,
  PCM_COMMTMNT_PERIOD_NU              ,
  PCM_LEVEL_POINT_NU                  ,
  PCM_OFFRE_CD                        ,
  PCM_EFFCTV_NEXT_OFFRE_DT            ,
  PCM_TYPE_OFFRE_MOBILE_CD            ,
  PCM_POINT_UTIL_NU                   ,
  PCM_BALANCE_POINT_NU                ,
  PCM_STATUT_POINT_CD                 ,
  PCM_POINT_DUE_NU                    ,
  PAR_ELIGIBLE_FIBER_IN               ,
  CHECK_INITIAL_STATUS_CD             ,
  CHECK_NAT_STATUS_CD                 ,
  CHECK_NAT_COMMENT                   ,
  CHECK_NAT_STATUS_LN                 ,
  CHECK_LOC_STATUS_CD                 ,
  CHECK_LOC_COMMENT                   ,
  CHECK_LOC_STATUS_LN                 ,
  CHECK_VALIDT_DT                     ,
  ACT_END_UNIFIED_DT                  ,
  ACT_END_UNIFIED_DS                  ,
  ACT_CLOSURE_DT                      ,
  ACT_CLOSURE_DS                      ,
  HOT_IN                              ,
  RUN_ID                              ,
  CREATION_TS                         ,
  LAST_MODIF_TS                       ,
  FRESH_IN                            ,
  COHERENCE_IN                         

)
Select
  CAR.ACTE_ID                                                               As  ACTE_ID                             ,
  CAR.OPERATOR_PROVIDER_ID                                                  As  OPERATOR_PROVIDER_ID                ,
  CAR.INTRNL_SOURCE_ID                                                      As  INTRNL_SOURCE_ID                    ,
  '${P_PIL_368}'                                                            As  TYPE_SOURCE_ID                      ,
  CAR.ACTE_ID                                                               As  MASTER_ACTE_ID                      ,
  CAR.INTRNL_SOURCE_ID                                                      As  MASTER_INTRNL_SOURCE_ID             ,
  ${P_PIL_354}                                                              As  MASTER_FLAG                         ,
  ${P_PIL_375}                                                              As  MASTER_NB_FOUND                     ,
  DIGITAL.ACTE_ID_INTRCTN                                                   As CPLT_ACTE_ID                    ,
  Case  When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then  31 -- code de la source JRC
    Else Null
  End                                                                       As  CPLT_INTRNL_SOURCE_ID               ,
                        
           
        
  '${P_PIL_388}'                                                            As  CPLT_IN                             ,
  '${P_PIL_362}'                                                            As  RULE_ID                             ,
  NULL                                                                      As  OFFSET_NB                           ,
  '${P_PIL_324}'                                                            As  ACT_TYPE                            ,
  CAR.EXTERNAL_ORD_ID                                                       As  ORDER_EXTERNAL_ID                   ,
  '${P_PIL_397}'                                                            As  STATUS_CD                           ,
  Case When CAR.CONCURENCE_IN = 'O' Then '${P_PIL_385}'
       When CAR.CONFIRMATION_IN = 'N' Then '${P_PIL_386}' 
       When CAR.PERENNITE_IN = 'O' Then '${P_PIL_384}' 
       When CAR.DELIVERY_IN = 'O' And CAR.PERENNITE_IN = 'N' Then '${P_PIL_387}' 
       When CAR.DELIVERY_IN = 'O' Then '${P_PIL_383}' 
       When CAR.CONFIRMATION_IN = 'O' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                        As  ACT_UNIFIED_STATUS_CD               ,
  CAR.ORD_DEPOSIT_TS                                                         As  ACT_TS                              ,
  CAR.ORD_DEPOSIT_DT                                                         As  ACT_DT                              ,
  Extract(HOUR From CAR.ORD_DEPOSIT_TS)                                      As  ACT_HH                              ,
  CAR.ORD_DEPOSIT_TS                                                         As  ACT_LAST_UPD_TS                     ,
  Case  When CAR.ACT_SEG_COM_ID_PRE Is Not Null
          Then CAR.ACT_PRODUCT_ID_PRE
        Else Null
  End                                                                        As  ACT_PRODUCT_ID_PRE                  ,
  CAR.ACT_SEG_COM_ID_PRE                                                     As  ACT_SEG_COM_ID_PRE                  ,
  Case  When CAR.ACT_SEG_COM_AGG_ID_PRE Is Not Null
          Then CAR.ACT_SEG_COM_AGG_ID_PRE
        Else Null
  End                                                                        As  ACT_SEG_COM_AGG_ID_PRE              ,
  Case  When CAR.ACT_CODE_MIGR_PRE Is Not Null                              
          Then CAR.ACT_CODE_MIGR_PRE                                        
        Else Null                                                           
  End                                                                        As  ACT_CODE_MIGR_PRE                   ,
  Case When CAR.ACT_SEG_COM_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                        As  ACT_OPER_ID_PRE                     ,
  CAR.ACT_PRODUCT_ID_FINAL                                                   As  ACT_PRODUCT_ID_FINAL                ,
  CAR.ACT_SEG_COM_ID_FINAL                                                   As  ACT_SEG_COM_ID_FINAL                ,
  CAR.ACT_SEG_COM_AGG_ID_FINAL                                               As  ACT_SEG_COM_AGG_ID_FINAL            ,
  CAR.ACT_CODE_MIGR_FINAL                                                    As  ACT_CODE_MIGR_FINAL                 ,
  'ADD'                                                                      As  ACT_OPER_ID_FINAL                   ,
  CAR.ACT_TYPE_SERVICE_FINAL                                                 As  ACT_TYPE_SERVICE_FINAL              ,
  CAR.ACT_TYPE_COMMANDE_ID                                                   As  ACT_TYPE_COMMANDE_ID                ,
  CAR.ACT_DELTA_TARIF                                                        As  ACT_DELTA_TARIF                     ,
  CAR.ACT_CD                                                                 As  ACT_CD                              ,
  CAR.ACT_REM_ID                                                             As  ACT_REM_ID                          ,
  CAR.ACT_FLAG_ACT_REM                                                       As  ACT_FLAG_ACT_REM                    ,
  CAR.ACT_FLAG_PEC_PERPVC                                                    As  ACT_FLAG_PEC_PERPVC                 ,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And CAR.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    --And CAR.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And CAR.ORG_REM_CHANNEL_CD In (${L_PIL_043})
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    And CAR.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And CAR.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then  'O'
       Else   'N'
  End                                                                        As  ACT_FLAG_PVC_REM                    ,
  CAR.ACT_ACTE_VALO                                                          As  ACT_ACTE_VALO                       ,
  CAR.ACT_ACTE_FAMILLE_KPI                                                   As  ACT_ACTE_FAMILLE_KPI                ,
  CAR.ACT_PERIODE_ID                                                         As  ACT_PERIODE_ID                      ,
  CAR.ACT_PERIODE_STATUS                                                     As  ACT_PERIODE_STATUS                  ,
  CAR.ACT_PERIODE_CLOSURE_DT                                                 As  ACT_PERIODE_CLOSURE_DT              ,
  Null                                                                       As  ORIGIN_CD                           ,
 Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Trim (DIGITAL.INT_OPRTR_ID)
    Else Null
  End                                                                        As  AGENT_ID                        ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Trim (DIGITAL.INT_OPRTR_ID)
    Else Null
  End                                                                        As AGENT_ID_UPD                    ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.INTRCTN_DT
    Else Null
  End                                                                      As AGENT_ID_UPD_DT                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.ORG_AGENT_IOBSP
    Else CAR.ORG_AGENT_IOBSP
  End                                                                        As  ORG_AGENT_IOBSP                     ,
  NULL                                                                       As  AGENT_FIRST_NAME                    ,
  NULL                                                                       As  AGENT_LAST_NAME                     ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_UNIFIED_SHOP_CD
    Else Null
  End                                                                       As UNIFIED_SHOP_CD                       ,
  Null                                                                      As  ORG_SPE_CANAL_ID_MACRO              ,
  Null                                                                      As  ORG_SPE_CANAL_ID                    ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_REM_CHANNEL_CD
    Else CAR.ORG_REM_CHANNEL_CD
  End                                                                      As ORG_REM_CHANNEL_CD              ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_CHANNEL_CD
    Else CAR.ORG_CHANNEL_CD
  End                                                                      As ORG_CHANNEL_CD                  ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_CHANNEL_CD
    Else CAR.ORG_SUB_CHANNEL_CD
  End                                                                      As ORG_SUB_CHANNEL_CD              ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_SUB_CHANNEL_CD
    Else CAR.ORG_SUB_SUB_CHANNEL_CD
  End                                                                      As ORG_SUB_SUB_CHANNEL_CD          ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_GT_ACTIVITY
    Else CAR.ORG_GT_ACTIVITY
  End                                                                      As ORG_GT_ACTIVITY                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_FIDELISATION
    Else CAR.ORG_FIDELISATION
  End                                                                      As ORG_FIDELISATION                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_WEB_ACTIVITY
    Else CAR.ORG_WEB_ACTIVITY
  End                                                                      As ORG_WEB_ACTIVITY                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_AUTO_ACTIVITY
    Else CAR.ORG_AUTO_ACTIVITY
  End                                                                      As ORG_AUTO_ACTIVITY               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_ID
    Else CAR.ORG_EDO_ID
  End                                                                      As ORG_EDO_ID                      ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TYPE_EDO
    Else CAR.ORG_TYPE_EDO
  End                                                                      As ORG_TYPE_EDO                    ,
   Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_IOBSP
    Else CAR.ORG_EDO_IOBSP
  End                                                                      As ORG_EDO_IOBSP                   ,
  Null                                                                     As ORG_FLAG_PLT_CONV               ,
  Null                                                                     As ORG_FLAG_TEAM_MKT               ,
  Null                                                                     As ORG_FLAG_TYPE_CMP               ,
  Null                                                                     As ORG_RESP_EDO_ID                 ,
  Null                                                                     As ORG_RESP_TYPE_EDO               ,
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV          ,
  Null                                                                     As ACTIVITY_CD                     ,
  Null                                                                     As ACTIVITY_GROUPNG_CD             ,
  Null                                                                     As AUTO_ACTIVITY_IN                ,
  '${P_PIL_366}'                                                           As ORG_TYPE_CD                     ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TYPE_EDO
    Else Null
  End                                                                      As ORG_TEAM_TYPE_ID                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_CD
    Else Trim(CAR.ORG_TEAM_LEVEL_1_CD)
  End                                                                      As ORG_TEAM_LEVEL_1_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_DS
    Else Trim(CAR.ORG_TEAM_LEVEL_1_DS)
  End                                                                      As ORG_TEAM_LEVEL_1_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_CD
    Else Trim(CAR.ORG_TEAM_LEVEL_2_CD)
  End                                                                      As ORG_TEAM_LEVEL_2_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_DS
    Else Trim(CAR.ORG_TEAM_LEVEL_2_DS)
  End                                                                      As ORG_TEAM_LEVEL_2_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_CD
    Else Trim(CAR.ORG_TEAM_LEVEL_3_CD)
  End                                                                      As ORG_TEAM_LEVEL_3_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_DS
    Else Trim(CAR.ORG_TEAM_LEVEL_3_DS)
  End                                                                      As ORG_TEAM_LEVEL_3_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_CD
    Else Trim(CAR.ORG_TEAM_LEVEL_4_CD)
  End                                                                      As ORG_TEAM_LEVEL_4_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_DS
    Else Trim(CAR.ORG_TEAM_LEVEL_4_DS)
  End                                                                      As ORG_TEAM_LEVEL_4_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_CD
    Else Trim(CAR.WORK_TEAM_LEVEL_1_CD)
  End                                                                      As WORK_TEAM_LEVEL_1_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_DS
    Else Trim(CAR.WORK_TEAM_LEVEL_1_DS)
  End                                                                      As WORK_TEAM_LEVEL_1_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_CD
    Else Trim(CAR.WORK_TEAM_LEVEL_2_CD)
  End                                                                      As WORK_TEAM_LEVEL_2_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_DS
    Else Trim(CAR.WORK_TEAM_LEVEL_2_DS)
  End                                                                      As WORK_TEAM_LEVEL_2_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_CD
    Else Trim(CAR.WORK_TEAM_LEVEL_3_CD)
  End                                                                      As WORK_TEAM_LEVEL_3_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_DS
    Else Trim(CAR.WORK_TEAM_LEVEL_3_DS)
  End                                                                      As WORK_TEAM_LEVEL_3_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_CD
    Else Trim(CAR.WORK_TEAM_LEVEL_4_CD)
  End                                                                      As WORK_TEAM_LEVEL_4_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_DS
    Else Trim(CAR.WORK_TEAM_LEVEL_4_DS)
  End                                                                      As WORK_TEAM_LEVEL_4_DS            ,
                                                         
  CAR.CONFIRMATION_IN                                                        As CONFIRMATION_IN                      ,
  --Flag Si la vente en conclue                                             
  Null                                                                        As CONCLDD_IN                       ,
 --Flag De concurrence
  Null                                                                        As COMPTTN_IN                       ,
  Null                                                                        As COMPTTN_ID                       ,
  CAR.PERNNT_IN                                                               As PERNNT_IN                        ,
                                                         
                       
  CAR.PERNNT_END_DT                                                           As PERNNT_END_DT                    ,
         
                                                         
                       
  CAR.PERNNT_MOTIF                                                            As PERNNT_MOTIF                     ,
         
                                                         
  CAR.PERNNT_CALC_END_DT                                                      As PERNNT_CALC_END_DT               ,
  CAR.MIGRA_DT                                                                As MIGRA_DT                         ,
  CAR.MIGRA_NEXT_OFFRE                                                        As MIGRA_NEXT_OFFRE                 ,
                                             
  CAR.SEG_PRES_PARC_COMMANDE                                                  As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  Case  When  ( CAR.ORD_DEPOSIT_DT + CAR.DELIVERY_DEAD_LINE_NU ) >= CAR.SEG_FIND_LIVR_DT
          Then CAR.SEG_FIND_LIVR_DT 
        Else Null
  End                                                                         As SEGMENT_DELIVERY_IN_PARK_DT      ,
  CAR.ORDER_CANCELING_DT                                                      As ORDER_CANCELING_DT               ,
  CAR.DMC_LINE_ID                                                             As LINE_ID                          ,
  CAR.DMC_MASTER_LINE_ID                                                      As MASTER_LINE_ID                   ,
  CAR.PAR_TYPE                                                                As CUST_TYPE_CD                     ,
  Coalesce(CAR.DOSSIER_NU, '0000000000')                                      As MSISDN_ID                        ,
  Coalesce(CAR.PAR_ND, '0000000000')                                          As NDS_VALUE_DS                     ,
  Coalesce(CAR.CLIENT_NU, '0000000000')                                       As EXTERNAL_PARTY_ID                ,
  CAR.PAR_AID                                                                 As RES_VALUE_DS                     ,
  Null                                                                        As PAR_ACCES_SERVICE                ,
  Null                                                                        As TAC_CD                           ,
  Null                                                                        As IMEI_CD                          ,
  CAR.PAR_IMSI                                                                As IMSI_CD                          ,
  CAR.DMC_ACTIVATION_DT_INT                                                   As HOM_START_DT                     ,
  CAR.DMC_ACTIVATION_DT                                                       As MOB_START_DT                     ,
  CAR.PAR_SCORE_NU_INT                                                        As I_SCORE_VALUE                    ,
  CAR.PAR_TRESHOLD_NU_INT                                                     As I_SCORE_TRESHOLD                 ,
                                                                      
  Case                                                                
        When CAR.PAR_SCORE_IN_INT = 'O'                               
          Then 1                                                      
        Else 0                                                        
  End                                                                         As I_SCORE_IN                       ,
  CAR.PAR_SCORE_NU_MOB                                                        As M_SCORE_VALUE                    ,
  Case
        When CAR.PAR_TRESHOLD_NU_MOB > 100
          Then -1
        Else CAR.PAR_TRESHOLD_NU_MOB
  End                                                                         As M_SCORE_TRESHOLD                 ,
  CAR.PAR_SCORE_IN_MOB                                                        As M_SCORE_IN                       ,
  Cast(Case When CAR.OTO_OSCAR_VALUE_NU = 'SC' Then -1                
            Else CAR.OTO_OSCAR_VALUE_NU                               
  End As BYTEINT)                                                             As OSCAR_VALUE                      ,
  '${P_PIL_376}'                                                              As CUST_BU_TYPE_CD                  ,
  CAR.PAR_USCM                                                                As CUST_BU_CD                       ,
  '${P_PIL_373}'                                                              As ADDRESS_TYPE                     ,
  Trim(
    Trim(Coalesce(Case When CAR.PAR_BILL_ADRESS_1 = 'null' Then Null Else CAR.PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When CAR.PAR_BILL_ADRESS_2 = 'null' Then Null Else CAR.PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When CAR.PAR_BILL_ADRESS_3 = 'null' THEN Null Else CAR.PAR_BILL_ADRESS_3 End,'')) || ' ' ||
                                                           
    Trim(Coalesce(CAR.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(Case When CAR.PAR_BILL_ADRESS_4 = 'null' Then Null Else CAR.PAR_BILL_ADRESS_4 End,'')) || ' ' ||
    Trim(Coalesce(CAR.PAR_BILL_VILLE,'')) 
  )                                                                           As ADDRESS_CONCAT_NM                ,

  Coalesce(CAR.PAR_POSTAL_CD,CAR.PAR_BILL_CD_POSTAL)                          As  POSTAL_CD                       ,
  CAR.PAR_INSEE_CD                                                            As  INSEE_CD                        ,
  CAR.PAR_BU_CD                                                               As  BU_CD                           ,
  Coalesce(CAR.PAR_DEPRTMNT_ID,CAR.PAR_DO   )                                 As  DEPARTMNT_ID                    ,
                                                         
  CAR.PAR_GEO_MACROZONE                                                       As  PAR_GEO_MACROZONE               ,
                         
                   
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_UNIFIED_PARTY_ID
    Else CAR.PAR_UNIFIED_PARTY_ID
  End                                                                        As PAR_UNIFIED_PARTY_ID            ,
  CAR.PAR_PARTY_REGRPMNT_ID                                                  As PAR_PARTY_REGRPMNT_ID           ,
  CAR.PAR_CID_ID                                                             As PAR_CID_ID                      ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_PID_ID
    Else CAR.PAR_PID_ID
  End                                                                        As PAR_PID_ID                       ,                                                        
  CAR.PAR_FIRST_IN                                                            As  PAR_FIRST_IN                    ,
  CAR.PAR_IRIS2000_CD                                                         As  PAR_IRIS2000_CD                 ,
  NULL                                                                        As  COMMARTICLE_RP_REFPRIX_CD       ,
  CAR.ACT_DELTA_TARIF                                                         As  ACT_CA_LINE_AM                  ,
  NULL                                                                        As  ACT_CA_TTC_AM                   ,
  NULL                                                                        As  EAN_CD                          ,
  CAR.PAR_MOB_SIM                                                             As  SIM_CD                          ,
  Null                                                                        As  SIM_EAN_CD                      ,
  NULL                                                                        As  ORG_RESP_ID                     ,
  NULL                                                                        As  EAN_PREVIOUS_CD                 ,
  NULL                                                                        As  TAC_PREVIOUS_CD                 ,
  NULL                                                                        As  IMEI_PREVIOUS_CD                ,
  NULL                                                                        As  PCM_PREVIOUS_OFFRE_CD           ,
  NULL                                                                        As  PCM_COMMTMNT_PERIOD_NU          ,
  NULL                                                                        As  PCM_LEVEL_POINT_NU              ,
  NULL                                                                        As  PCM_OFFRE_CD                    ,
  NULL                                                                        As  PCM_EFFCTV_NEXT_OFFRE_DT        ,
  NULL                                                                        As  PCM_TYPE_OFFRE_MOBILE_CD        ,
  NULL                                                                        As  PCM_POINT_UTIL_NU               ,
  NULL                                                                        As  PCM_BALANCE_POINT_NU            ,
  NULL                                                                        As  PCM_STATUT_POINT_CD             ,
  NULL                                                                        As  PCM_POINT_DUE_NU                ,
  NULL                                                                        As  PAR_ELIGIBLE_FIBER_IN           ,
  CAR.CHECK_INITIAL_STATUS_CD                                                 As  CHECK_INITIAL_STATUS_CD         ,
  CAR.CHECK_NAT_STATUS_CD                                                     As  CHECK_NAT_STATUS_CD             ,
  CAR.CHECK_NAT_COMMENT                                                       As  CHECK_NAT_COMMENT               ,
  CAR.CHECK_NAT_STATUS_LN                                                     As  CHECK_NAT_STATUS_LN             ,
  CAR.CHECK_LOC_STATUS_CD                                                     As  CHECK_LOC_STATUS_CD             ,
  CAR.CHECK_LOC_COMMENT                                                       As  CHECK_LOC_COMMENT               ,
  CAR.CHECK_LOC_STATUS_LN                                                     As  CHECK_LOC_STATUS_LN             ,
  CAR.CHECK_VALIDT_DT                                                         As  CHECK_VALIDT_DT                 ,
  Null                                                                        As  ACT_END_UNIFIED_DT              ,
  Null                                                                        As  ACT_END_UNIFIED_DS              ,
  CAR.CLOSURE_DT                                                              As  ACT_CLOSURE_DT                  ,
  Case When CAR.CLOSURE_DT Is Not Null                              
        Then 'Acte Clos'                                            
  End                                                                         As ACT_CLOSURE_DS                   ,
  0                                                                           As HOT_IN                           ,
  Null                                                                        As RUN_ID                           ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                   As CREATION_TS                      ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                   As LAST_MODIF_TS                    ,
  1                                                                           As FRESH_IN                         ,
  0                                                                           As COHERENCE_IN                     
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_CAR As CAR  
Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL DIGITAL
    On CAR.ACTE_ID            = DIGITAL.ACTE_ID
    And CAR.ORD_DEPOSIT_DT  = DIGITAL.ACT_DT
    And DIGITAL.CURRENT_IN = 1

Where
(1=1)
  And Substr(CAR.ACT_CD,1,3)        Not In (${L_PIL_036})
  And CAR.ACT_SEG_COM_ID_FINAL      <> '${P_PIL_295}'
  And CAR.ACT_CD                    <> '${P_PIL_067}'
  And CAR.ACT_ACTE_FAMILLE_KPI      Not In (${L_PIL_626}) -- NS, NSTECH
  And CAR.ACT_PERIODE_ID            > 12
  And CAR.ORD_DEPOSIT_DT            >= Current_date - 250
  And CAR.ORG_CHANNEL_CD             IN ('Online','DNU')
  And ((CAR.LAST_MODIF_TS           >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And CAR.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or CAR.ORD_DEPOSIT_DT > Current_date - 15)
  And CAR.HOT_IN                    = 0
  And Not Exists (
    Select 'X' 
    From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CAR CA
    Where CA.ACTE_ID = DIGITAL.ACTE_ID
    And CA.ACT_DT  = DIGITAL.ACT_DT
  )
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CAR;
.if errorcode <> 0 then .quit 1;

.quit 0

