--$HEADER: mm2pco/current/sql/ATP_NSH_Placement_Cold_CalculDelta_Jour.sql 13_05#2 23-OCT-2019 10:40:20 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_CalculDelta_Jour.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'extraction des données ShoptoWeb
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/01/2014      MCA         Creation
-- 18/07/2014      MCA         Indus
-- 01/12/2014      MCA         Ajout champs perfom
-- 27/01/2016      OCH         Ajout STW
-- 25/04/2016      OCH         Ajout XSELL
-- 21/07/2016      GMA         Ajout filtre des vadhome sans id vadhome
-- 23/01/2018      HOB         Evol REFONTE S2W
-- 19/09/2018      JCR         Modif calcul delta
-- 20/09/2019      TCL         Reprise du SQL en cold pour le décom du flux à chaud NSH
--------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
--On insert dans la table delta les donnees extraites de 6PO.

insert into ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT
(
  SHOP_COD_DS                       ,
  SHOP_ADV_COD_DS                   ,
  AGNT_ID                           ,
  POSTAL_CD                         ,
  SUBSCRPTN_ID                      ,
  VAD_ID                            ,
  OPAL_ID                           ,
  TYP_ORDR_CD                       ,
  ORDR_TYPLG_DS                     ,
  ORDER_LINE_TYPE                   ,
  ORDER_TYPE                        ,
  SUB_INITL_TIM_CREDT_ADV_CD        ,
  SUB_INITL_TIM_CREDT_ADV_DS        ,
  MSISDN_DS                         ,
  ORDR_CREATN_DT                    ,
  ORDR_CREATN_DATE                  ,
  CATGR_DS                          ,
  SUBSCRPTN_DURTN_DS                ,
  ADV_ID                            ,
  BRAND_SHOP_DS                     ,
  TERMNL_EAN_DS                     ,
  SUBSCRPTN_TIM_CREDT_ADV_CD        ,
  SUBSCRPTN_TIM_CREDT_ADV_DS        ,
  OPTNS_ADV_DS                      ,
  APPLI_SOURCE_ID                   ,
  PAYMNT_FORMLTN_ID                 ,
  MONTHL_PRIC                       ,
  MONTHL_PERD                       ,
  VAD_HOM_ID                        ,
  QUANTT_QT                         ,
  AMNT_HT_ARTCL_AM                  ,
  HOT_IN                            ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  FRESH_IN                          ,
  COHERENCE_IN
)
Select
  RefSpo.SHOP_COD_DS                       as SHOP_COD_DS                       ,
  RefSpo.SHOP_ADV_COD_DS                   as SHOP_ADV_COD_DS                   ,
  RefSpo.AGNT_ID                           as AGNT_ID                           ,
  RefSpo.POSTAL_CD                         as POSTAL_CD                         ,
  RefSpo.SUBSCRPTN_ID                      as SUBSCRPTN_ID                      ,
  RefSpo.VAD_ID                            as VAD_ID                            ,
  RefSpo.OPAL_ID                           as OPAL_ID                           ,
  Matrice.TYP_ORDR_CD                      as TYP_ORDR_CD                       ,
  RefSpo.ORDR_TYPLG_DS                     as ORDR_TYPLG_DS                     ,
  Matrice.ORDER_LINE_TYPE                  as ORDER_LINE_TYPE                   ,
  Matrice.ORDER_TYPE                       as ORDER_TYPE                        ,
  RefSpo.SUB_INITL_TIM_CREDT_ADV_CD        as SUB_INITL_TIM_CREDT_ADV_CD        ,
  RefSpo.SUB_INITL_TIM_CREDT_ADV_DS        as SUB_INITL_TIM_CREDT_ADV_DS        ,
  RefSpo.MSISDN_DS                         as MSISDN_DS                         ,
  RefSpo.ORDR_CREATN_DT                    as ORDR_CREATN_DT                    ,
  RefSpo.ORDR_CREATN_DATE                  as ORDR_CREATN_DATE                  ,
  RefSpo.CATGR_DS                          as CATGR_DS                          ,
  RefSpo.SUBSCRPTN_DURTN_DS                as SUBSCRPTN_DURTN_DS                ,
  RefSpo.ADV_ID                            as ADV_ID                            ,
  RefSpo.BRAND_SHOP_DS                     as BRAND_SHOP_DS                     ,
  RefSpo.TERMNL_EAN_DS                     as TERMNL_EAN_DS                     ,
  RefSpo.SUBSCRPTN_TIM_CREDT_ADV_CD        as SUBSCRPTN_TIM_CREDT_ADV_CD        ,
  RefSpo.SUBSCRPTN_TIM_CREDT_ADV_DS        as SUBSCRPTN_TIM_CREDT_ADV_DS        ,
  RefSpo.OPTNS_ADV_DS                      as OPTNS_ADV_DS                      ,
  RefSpo.APPLI_SOURCE_ID                   as APPLI_SOURCE_ID                   ,
  RefSpo.PAYMNT_FORMLTN_ID                 as PAYMNT_FORMLTN_ID                 ,
  RefSpo.MONTHL_PRIC                       as MONTHL_PRIC                       ,
  RefSpo.MONTHL_PERD                       as MONTHL_PERD                       ,
  RefSpo.VAD_HOM_ID                        as VAD_HOM_ID                        ,
  RefSpo.QUANTT_QT                         as QUANTT_QT                         ,
  RefSpo.AMNT_HT_ARTCL_AM                  as AMNT_HT_ARTCL_AM                  ,
  0                                        as HOT_IN                            ,
  Current_Timestamp(0)                     as CREATION_TS                       ,
  Current_Timestamp(0)                     as LAST_MODIF_TS                     ,
  1                                        as FRESH_IN                          ,
  0                                        as COHERENCE_IN
From
-- on extrait les donnees de la table 6PO.
  ${KNB_SPO_VM_V}.VF_ORD_F_SHOP_TO_WEB_OL_R_VM RefSpo
    Inner Join ${KNB_PCO_SOC}.ORG_R_MATRICE_NSH_S2W Matrice
       on   RefSpo.TYP_ORDR_CD           = Matrice.TYP_ORDR_CD
        And RefSpo.ARTCL_TYP_CD          = Matrice.ARTCL_TYP_CD 
where
  (1=1)
  And RefSpo.CURRENT_IN = 1
  And (
      RefSpo.TYP_ORDR_CD    <> 3 
    Or 
      RefSpo.VAD_HOM_ID   Is Not Null
      )
  And RefSpo.FRESH_TS >= '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
      
;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_NEWSHOP_NSH_C_EXT
;
.if errorcode <> 0 then .quit 1
.quit 0

