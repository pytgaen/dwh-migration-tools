-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Hot_Alimentation_GEN_GenKey.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de génération à chaud SOFT de l'identifiant de l'acte
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------


.set width 2000;

Insert into ${KNB_PCO_SOC}.ACT_F_ACTE_GEN
(
  EXTERNAL_ACTE_ID      ,
  TYPE_SOURCE_ID        ,
  COMPTEUR              ,
  ACTE_ID               
)
Select
  RefPlacement.EXTERNAL_ACTE_ID                                 as EXTERNAL_ACTE_ID     ,
  RefPlacement.TYPE_SOURCE_ID                                   as TYPE_SOURCE_ID       ,
  ${maxIdActe}+ sum(1) over ( rows unbounded PRECEDING )        as COMPTEUR             ,
  Cast(     '${SousSource}'||
            Cast((${maxIdActe}+ sum(1) over ( rows unbounded PRECEDING )) as Varchar(50))
       As Bigint )                                              as ACTE_ID              
From
  ${DatabaseName}.${TableName} RefPlacement
  Left Outer Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN GenID
    On    GenID.EXTERNAL_ACTE_ID  = RefPlacement.EXTERNAL_ACTE_ID
      And GenID.TYPE_SOURCE_ID    = RefPlacement.TYPE_SOURCE_ID
Where
  GenID.EXTERNAL_ACTE_ID is null
;
.if errorcode <> 0 then .quit 1

.quit 0 


