--$HEADER:   mm2pco/current/sql/ATP_COE_Placement_Enrichissement_Step4_RCS.sql 13_05#3 16-NOV-2018 10:34:53 KRQJ9961
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_COE_Placement_Enrichissement_RCS.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'Enrichissement CUID 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/10/2018       HOB          Creation
----------------------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_RCS All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
  Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_RCS
  (  
    ACTE_ID                     ,
    EXTERNAL_ORDER_ID           ,
    ORDER_DEPOSIT_DT            ,
    OPERATOR_PROVIDER_ID        ,
    EXTRNL_APPLI_SOURCE_ID      ,
    ORDR_TYP_CD                 ,
    EXTRNL_CONCLSN_ID           ,
    EXTRNL_DOSSIER_NU           ,
    EXTRNL_CLIENT_NU            ,
    INIT_MOTIF_RCS              ,
    INIT_MOTIF_STATUS_CD        

    )
  Select
    Placement.ACTE_ID                                             as  ACTE_ID                      ,
    Placement.EXTERNAL_ORDER_ID                                   as  EXTERNAL_ORDER_ID            ,
    Placement.ORDER_DEPOSIT_DT                                    as  ORDER_DEPOSIT_DT             ,
    Placement.OPERATOR_PROVIDER_ID                                as  OPERATOR_PROVIDER_ID         ,
    Placement.EXTRNL_APPLI_SOURCE_ID                              as  EXTRNL_APPLI_SOURCE_ID       ,
    Placement.ORDR_TYP_CD                                         as  ORDR_TYP_CD                  ,
    Placement.EXTRNL_CONCLSN_ID                                   as  EXTRNL_CONCLSN_ID            ,
    Placement.EXTRNL_DOSSIER_NU                                   as  EXTRNL_DOSSIER_NU            ,
    Placement.EXTRNL_CLIENT_NU                                    as  EXTRNL_CLIENT_NU             ,
    O.OPERATIONSIM_CODEMOTREN_CD                                  as  INIT_MOTIF_RCS               ,
    O.OPERATIONSIM_ETAT_ID                                        as  INIT_MOTIF_STATUS_CD         
   
  From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_1  Placement 
      Inner join ${KNB_IBU_SOC_V_PRS}.VF_TFDEMANDE D On Substr(Placement.EXTERNAL_ORDER_ID, 1, 11) = D.DEMANDE_ID
        And D.FTDOSSIERID Is Not Null
      Inner Join ${KNB_IBU_SOC_V_PRS}.VF_TFSIMHISTORIQUE H On  H.SIMHISTO_DOSSIER_ID = D.FTDOSSIERID
      Inner Join ${KNB_IBU_SOC_V_PRS}.VF_TFOPERATIONSIM O  On O.OPERATIONSIM_SIMHISTO_ID = H.SIMHISTO_ID 
        And O.OPERATIONSIM_ETAT_ID = 'O1' 
Where
  (1=1)
  And Placement.ORDR_TYP_CD      ='INITAD'
  And Placement.INIT_MOTIF_RCS  is  null
   Qualify Row_Number() Over (Partition By Placement.ACTE_ID Order By O.OPERATIONSIM_DATEOPERATION_DT Desc )=1    ; 

.if errorcode <> 0 then .quit 1            
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_RCS  ; 
.if errorcode <> 0 then .quit 1  
