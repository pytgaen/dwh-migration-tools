-----------------------------------------------------------------------------------------
-- $HEADER      : mm2pco/current/sql/ATP_PLC_REFCOM_Update_Periode.sql 4 27-FEV-2015 09:51:25 FQJR5800                                                              -
-----------------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_PLC_REFCOM_Update_Periode.sql    $                   -
-- TYPE         : Script SQL                                                            -
-- DESCRIPTION  : Mise à jour de la periode pour REFCOM                                 -
-----------------------------------------------------------------------------------------
--                 HISTORIQUE                                                           -
-- DATE            AUTEUR      CREATION/MODIFICATION                                    -
-- 00/00/00        XXX         Creation                                                 -
-- 10/01/14        AID         Modification mise ne norme DSM                           -
--27/02/2015       MDE         Modification : Date de fraicheur  'FRESH_TS QC876'       -
-----------------------------------------------------------------------------------------
.set width 250;


-- On positionne la fraîcheur par défaut à la fraîcheur du tampon (du flux)
--UPDATE ${KNB_COM_TMP}.CAT_T_PERIODE_COM_PILCOM
--SET FRESH_TS = CAST('${FRESH_TS}' AS TIMESTAMP(0))
-- On écrase cette fraîcheur avec celle du socle, pour les lignes ne présentant aucune différence
-- sur les 2 attributs (date début/date fin) et n'existant pas dans la table T_Matrice
Update TMP
From
  ${KNB_COM_TMP}.CAT_T_PERIODE_COM_PILCOM       TMP     ,
  (
    Select
      T.PERIODE_ID,
      S.FRESH_TS
    From
      ${KNB_COM_TMP}.CAT_T_PERIODE_COM_PILCOM T
      Inner Join ${KNB_COM_SOC}.V_CAT_R_PERIODE_COM_PILCOM S
        On    T.PERIODE_ID        = S.PERIODE_ID
          And T.PERIODE_DATE_DEB  = S.PERIODE_DATE_DEB
          And T.PERIODE_DATE_FIN  = S.PERIODE_DATE_FIN
          And S.CURRENT_IN        = 1
          And S.CLOSURE_DT        Is Null
    Where
      (1=1)
  ) SRC
Set
  FRESH_TS = SRC.FRESH_TS
Where
  (1=1)
  And TMP.PERIODE_ID = SRC.PERIODE_ID
  And TMP.PERIODE_ID Not In
    (
      Select
        Distinct
        PERIODE_ID
      From
        ${KNB_COM_TMP}.CAT_T_MAT_MIGR_PILCOM
    )
;

.IF ERRORCODE <> 0 THEN .QUIT 1;
