-----------------------------------------------------------------------------------------
-- $HEADER: %HEADER%
-----------------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:  FCT_PCO_truncate_ods.sql $                                -
-- TYPE         : Script SQL                                                            -
-- DESCRIPTION  : Requetes purge ODS                                                    -
-----------------------------------------------------------------------------------------
--                 HISTORIQUE                                                           -
-- DATE            AUTEUR      CREATION/MODIFICATION                                    -
-- 00/00/00        XXX         Creation                                                 -
-- 10/01/14        AID         Modification mise ne norme DSM                           -
-----------------------------------------------------------------------------------------
.set width 250;


-- On genere dynamiquement les requêtes de purge de l'ODS

SELECT 
CASE
	WHEN RK>1 THEN ';' 
	ELSE ''
END ||
'DELETE FROM '||
TARGET_BASE_NM||'.'||
TARGET_TABLE_NM||
' WHERE FILE_ID='''||
FILE_NM||''''||
case
	when RK = count(*) over(partition by 1) then ';'
	else ''
end (TITLE '')
FROM
(
SELECT 
	row_number() over(order by 1) AS RK,
	A.*
FROM 
	${KNB_PCO_TECH}.MET_W_COMPLETUDE_${FCT_PCO_SOURCE_CD} A
) W
ORDER BY RK
;

.if errorcode <> 0 then .quit 1



