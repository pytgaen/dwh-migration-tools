-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_OEE_Acte_Consolidation_Step2_CalculPerennitePVCSegmentVerifPresParcAvant.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/11/2013      XKN         Creation
-- 27/03/2014      AID         Indus
-- 25/09/2015      MDE         Modif : Ajout filtre sur la periode id pour  CAT_R_REF_EXCLUDED_SEEK_SEG
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEGPRES All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEGPRES
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PAR_IMSI                ,
  SEG_COM_ID              ,
  TYPE_SERVICE            ,
  TYPE_COMMANDE           ,
  TYPE_OT_SO              
)
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.INT_DEPOSIT_DT                   as INT_DEPOSIT_DT         ,
  Acte.PAR_IMSI                         as PAR_IMSI               ,
  Acte.SEG_COM_ID                       as SEG_COM_ID             ,
  Acte.TYPE_SERVICE                     as TYPE_SERVICE           ,
  Acte.TYPE_COMMANDE                    as TYPE_COMMANDE          ,
  Acte.TYPE_OT_SO                       as TYPE_OT_SO             
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.INT_W_ACTE_OEE_EXRACT Acte
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID             Not In ('NS','OPTTECH','OPT_INC')
  --And Acte.TYPE_OT_SO             in ('SO')
  And Acte.PAR_IMSI               Is Not Null
  --On filtre pour enlevé les segments à exclures :
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_SOC}.V_CAT_R_REF_EXCLUDED_SEEK_SEG SegExclu
    Where
      (1=1)
      And SegExclu.CURRENT_IN   = 1
      And SegExclu.CLOSURE_DT   Is Null
      And SegExclu.SEG_COM_ID   = Acte.SEG_COM_ID
      And SegExclu.PERIODE_ID   = Acte.PERIODE_ID
  )
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEGPRES;
.if errorcode <> 0 then .quit 1





-------------------------------------------------------------------------------------------
--Step 2 :  On recherche en parc si le segment était déjà la à J-1
-------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_DEJPRES All;
.if errorcode <> 0 then .quit 1

--Insertion des OT
Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_DEJPRES
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.INT_DEPOSIT_DT          as ORDER_DEPOSIT_DT   
From
  ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEGPRES Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_OT ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  And (Refid.INT_DEPOSIT_DT - 1) >= ParcSeg.PARC_BEGIN_DT
  And (Refid.INT_DEPOSIT_DT - 1) <= Coalesce(ParcSeg.PARC_END_DT,Cast('29991231' as Date format 'YYYYMMDD'))
  And Refid.TYPE_OT_SO             in ('OT')


--Insertion des SO
;Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_DEJPRES
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.INT_DEPOSIT_DT          as ORDER_DEPOSIT_DT   
From
  ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEGPRES Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  And (Refid.INT_DEPOSIT_DT - 1) >= ParcSeg.PARC_BEGIN_DT
  And (Refid.INT_DEPOSIT_DT - 1) <= Coalesce(ParcSeg.PARC_END_DT,Cast('29991231' as Date format 'YYYYMMDD'))
  And Refid.TYPE_OT_SO             in ('SO')
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_DEJPRES;
.if errorcode <> 0 then .quit 1



.quit 0


