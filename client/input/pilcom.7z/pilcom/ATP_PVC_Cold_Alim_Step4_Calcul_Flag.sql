-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PVC_Cold_Alim_Step4_Calcul_Flag.sq  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de mise à jour du FLAG_ETAT_PVC de la table ${KNB_PCO_TMP}.ACT_T_PVC_DAY
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 02/10/2013     XKN         Création
-- 04/08/2014     HZO         Modification : Hichem QC 557, Valorisation du STAUT_CSO et du STATUT_CSO_DS
-- 24/11/2015     HZO         Modification : QC 1259 : Réactivation acte C --> NC et NC --> C
---------------------------------------------------------------------------------

.set width 2000;

-- *****************************************
--  pour les Extractions PVC
-- *****************************************

-- Modifications Hichem QC 557, Valorisation du STAUT_CSO, du STATUT_CSO_DS et du COMMENTAIRE_DS
Update CIB
From
    ${KNB_PCO_TMP}.ACT_T_PVC_DAY                           As CIB       ,
    ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED                     As SRC_AU    
Set
    STATUT_CSO        =   Case
                              When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) In ('6', '7') 
                                Then Null
                              Else Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD, '5')
                          End                                                                                                                   ,
    STATUT_CSO_DS     =   Case 
                              When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) In ('6', '7') 
                                Then 'A contrôler'
                              When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) = '5' 
                                Then 'Valide AUTO'
                              When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) = '4' 
                                Then 'Non controlé'
                              When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) = '2' 
                                Then 'Non Valide'
                              Else 
                                Coalesce(SRC_AU.CHECK_LOC_STATUS_LN,SRC_AU.CHECK_NAT_STATUS_LN, 'Valide AUTO')
                          End                                                                                                                    ,
    COMMENTAIRE_DS    =   Coalesce(SRC_AU.CHECK_LOC_COMMENT,SRC_AU.CHECK_NAT_COMMENT,CIB.COMMENTAIRE_DS)                                         
Where
  (1=1)
  And CIB.ACTE_ID = SRC_AU.ACTE_ID
  And (SRC_AU.CHECK_LOC_STATUS_CD is not Null
          Or SRC_AU.CHECK_NAT_STATUS_CD is not Null
          Or SRC_AU.CHECK_INITIAL_STATUS_CD is not Null
      )
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_T_PVC_DAY;
.if errorcode <> 0 then .quit 1

-- Création de la table Volatile contenant l'ACTE_ID et le Type de modification qui lui est associé pour les SCH
Create Volatile Table ${KNB_TERADATA_USER}.VOL_LISTE_ID_EXT_PVC (
  ACTE_ID               Bigint        Not Null,
  FLAG_ETAT_GRV         Char(2)       Not Null,
  ACTION_ACTE           BYTEINT  
)
Primary index (
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_TERADATA_USER}.VOL_LISTE_ID_EXT_PVC
(
  ACTE_ID           ,
  FLAG_ETAT_GRV     ,
  ACTION_ACTE
)
SELECT
  ExtDay.ACTE_ID                    as ACTE_ID                   ,
  Case When ActSent.Acte_ID is Null Then '${P_PIL_427}'                                                                                               -- Création
       When (ExtDay.Acte_ID is Not Null and ExtCur.Acte_ID is Null) Then '${P_PIL_428}'                                                               -- Modification vraie
       When (ExtDay.Acte_ID is Not Null and ExtCur.Acte_ID is Not Null) And ExtCur.FLAG_ETAT_GRV in ('${P_PIL_431}','${P_PIL_432}') Then '${P_PIL_428}' -- Réactivation
       When (ExtDay.Acte_ID is Not Null and ExtCur.Acte_ID is Not Null) And 
            (
                Case When Coalesce(ExtDay.EXT_SOURCE_ID             , '-1')                                          <> Coalesce(ExtCur.EXT_SOURCE_ID             , '-1')                                       Then 1 Else 0 End                                     
              + Case When Coalesce(ExtDay.ACTE_ID_EXTERNE           , '-1')                                          <> Coalesce(ExtCur.ACTE_ID_EXTERNE           , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ACTE_ID_CONTACTE          , -1)                                            <> Coalesce(ExtCur.ACTE_ID_CONTACTE          , -1)                                         Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ACTE_ID_DETAIL_CONTACTE   , -1)                                            <> Coalesce(ExtCur.ACTE_ID_DETAIL_CONTACTE   , -1)                                         Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ACTE_ID_COMMANDE_REFERENCE, -1)                                            <> Coalesce(ExtCur.ACTE_ID_COMMANDE_REFERENCE, -1)                                         Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SOURCE_ID                 , '-1')                                          <> Coalesce(ExtCur.SOURCE_ID                 , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ACTE_STATUT               , -1)                                            <> Coalesce(ExtCur.ACTE_STATUT               , -1)                                         Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ORDER_DEPOSIT_TS          , CAST('19000101' AS DATE FORMAT 'YYYYMMDD'))    <> Coalesce(ExtCur.ORDER_DEPOSIT_TS          , CAST('19000101' AS DATE FORMAT 'YYYYMMDD')) Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ORDER_RECEIVED_PIL_TS     , CAST('19000101' AS DATE FORMAT 'YYYYMMDD'))    <> Coalesce(ExtCur.ORDER_RECEIVED_PIL_TS     , CAST('19000101' AS DATE FORMAT 'YYYYMMDD')) Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUID                      , '-1')                                          <> Coalesce(ExtCur.CUID                      , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ORDER_STATUT              , '-1')                                          <> Coalesce(ExtCur.ORDER_STATUT              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ORDER_STATUT_TS           , CAST('19000101' AS DATE FORMAT 'YYYYMMDD'))    <> Coalesce(ExtCur.ORDER_STATUT_TS           , CAST('19000101' AS DATE FORMAT 'YYYYMMDD')) Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SELLER_LAST_NAME          , '-1')                                          <> Coalesce(ExtCur.SELLER_LAST_NAME          , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SELLER_FIRST_NAME         , '-1')                                          <> Coalesce(ExtCur.SELLER_FIRST_NAME         , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SALE_CHANNEL_DLC          , '-1')                                          <> Coalesce(ExtCur.SALE_CHANNEL_DLC          , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SALE_CHANNEL_ORDER        , '-1')                                          <> Coalesce(ExtCur.SALE_CHANNEL_ORDER        , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CODE_PARC_CLI             , '-1')                                          <> Coalesce(ExtCur.CODE_PARC_CLI             , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ORIGINE_DLC_DS            , '-1')                                          <> Coalesce(ExtCur.ORIGINE_DLC_DS            , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_TYPE             , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_TYPE             , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_SEG              , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_SEG              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_LAST_NAME        , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_LAST_NAME        , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_FIRST_NAME       , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_FIRST_NAME       , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_SIRET            , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_SIRET            , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.MISISDN                   , '-1')                                          <> Coalesce(ExtCur.MISISDN                   , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ND                        , '-1')                                          <> Coalesce(ExtCur.ND                        , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.NDIP                      , '-1')                                          <> Coalesce(ExtCur.NDIP                      , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_CAT              , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_CAT              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_AGENCE           , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_AGENCE           , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CUSTOMER_ZIPCODE          , '-1')                                          <> Coalesce(ExtCur.CUSTOMER_ZIPCODE          , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.VOLUME                    , -1)                                            <> Coalesce(ExtCur.VOLUME                    , -1)                                         Then 1 Else 0 End
              + Case When Coalesce(ExtDay.VALEUR                    , '-1')                                          <> Coalesce(ExtCur.VALEUR                    , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CA                        , '-1')                                          <> Coalesce(ExtCur.CA                        , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.STATUT_CSO                , '-1')                                          <> Coalesce(ExtCur.STATUT_CSO                , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.STATUT_CSO_DS             , '-1')                                          <> Coalesce(ExtCur.STATUT_CSO_DS             , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.COMMENTAIRE_DS            , '-1')                                          <> Coalesce(ExtCur.COMMENTAIRE_DS            , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.TEAM_DLC_DES              , '-1')                                          <> Coalesce(ExtCur.TEAM_DLC_DES              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.TEAM_ORDER_DES            , '-1')                                          <> Coalesce(ExtCur.TEAM_ORDER_DES            , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ACT_CD                    , '-1')                                          <> Coalesce(ExtCur.ACT_CD                    , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ACT_TYPE_COMMANDE_ID      , '-1')                                          <> Coalesce(ExtCur.ACT_TYPE_COMMANDE_ID      , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.TYPE_COMMANDE_INI         , '-1')                                          <> Coalesce(ExtCur.TYPE_COMMANDE_INI         , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CODE_COMMANDE_FIN         , '-1')                                          <> Coalesce(ExtCur.CODE_COMMANDE_FIN         , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.TYPE_COMMANDE_FIN         , '-1')                                          <> Coalesce(ExtCur.TYPE_COMMANDE_FIN         , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CODE_PRODUCT_FIN          , '-1')                                          <> Coalesce(ExtCur.CODE_PRODUCT_FIN          , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.PRODUCT_DSC_FIN           , '-1')                                          <> Coalesce(ExtCur.PRODUCT_DSC_FIN           , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SEGMENT_COM_FIN           , '-1')                                          <> Coalesce(ExtCur.SEGMENT_COM_FIN           , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CODE_PRODUCT_INI          , '-1')                                          <> Coalesce(ExtCur.CODE_PRODUCT_INI          , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.PRODUCT_DSC_INI           , '-1')                                          <> Coalesce(ExtCur.PRODUCT_DSC_INI           , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SEGMENT_COM_INI           , '-1')                                          <> Coalesce(ExtCur.SEGMENT_COM_INI           , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CODE_MIGR_INI             , '-1')                                          <> Coalesce(ExtCur.CODE_MIGR_INI             , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.DSC_MIGR_INI              , '-1')                                          <> Coalesce(ExtCur.DSC_MIGR_INI              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.CODE_MIGR_FIN             , '-1')                                          <> Coalesce(ExtCur.CODE_MIGR_FIN             , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.DSC_MIGR_FIN              , '-1')                                          <> Coalesce(ExtCur.DSC_MIGR_FIN              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ID_FREGATE                , '-1')                                          <> Coalesce(ExtCur.ID_FREGATE                , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.DT_CHECK_PARC             , CAST('19000101' AS DATE FORMAT 'YYYYMMDD'))    <> Coalesce(ExtCur.DT_CHECK_PARC             , CAST('19000101' AS DATE FORMAT 'YYYYMMDD')) Then 1 Else 0 End
              + Case When Coalesce(ExtDay.DT_END_PARC               , CAST('19000101' AS DATE FORMAT 'YYYYMMDD'))    <> Coalesce(ExtCur.DT_END_PARC               , CAST('19000101' AS DATE FORMAT 'YYYYMMDD')) Then 1 Else 0 End
              + Case When Coalesce(ExtDay.END_PARC_DSC              , '-1')                                          <> Coalesce(ExtCur.END_PARC_DSC              , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.TAUX_PERENNITE            , '-1')                                          <> Coalesce(ExtCur.TAUX_PERENNITE            , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.DELAIS_PERENNITE          , '-1')                                          <> Coalesce(ExtCur.DELAIS_PERENNITE          , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.OSCAR_VALUE               , '#')                                           <> Coalesce(ExtCur.OSCAR_VALUE               , '#')                                        Then 1 Else 0 End
              + Case When Coalesce(ExtDay.DUREE_ENG                 , '-1')                                          <> Coalesce(ExtCur.DUREE_ENG                 , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.IMEI                      , '-1')                                          <> Coalesce(ExtCur.IMEI                      , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.EAN                       , '-1')                                          <> Coalesce(ExtCur.EAN                       , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.SIM                       , -1)                                            <> Coalesce(ExtCur.SIM                       , -1)                                         Then 1 Else 0 End
              + Case When Coalesce(ExtDay.ID_PARSIFAL               , '-1')                                          <> Coalesce(ExtCur.ID_PARSIFAL               , '-1')                                       Then 1 Else 0 End
              + Case When Coalesce(ExtDay.MOTIF_DLC_DS              , '-1')                                          <> Coalesce(ExtCur.MOTIF_DLC_DS              , '-1')                                       Then 1 Else 0 End
            ) > 0
            Then '${P_PIL_428}'                                                                     -- Vraie Modification
       Else '${P_PIL_429}'                                                                          -- Fausse Modification
  End                    as FLAG_ETAT_GRV,
  ExtCur.ACTION_ACTE     as ACTION_ACTE
From
  ${KNB_PCO_TMP}.ACT_T_PVC_DAY                                  ExtDay
  Left Outer Join ${KNB_PCO_VM}.ACT_F_PVC_CUR                   ExtCur
    On    ExtDay.Acte_ID = ExtCur.ACTE_ID 
  Left Outer Join ${KNB_PCO_VM}.ACT_F_ACTE_SENT_PVC             ActSent
    On    ExtDay.ACTE_ID = ActSent.ACTE_ID
;
.if errorcode <> 0 then .quit 1

Update CIB
From
    ${KNB_PCO_TMP}.ACT_T_PVC_DAY                           As CIB,
    ${KNB_TERADATA_USER}.VOL_LISTE_ID_EXT_PVC              As SRC
Set
  FLAG_ETAT_GRV = SRC.FLAG_ETAT_GRV ,
  ACTION_ACTE = Case
                  --When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_427}' AND (CIB.SOURCE_ID = '${P_PIL_243}') AND CIB.STATUT_CSO <> 2 THEN 1 -- Supprimé à la demande de Vincent COPPOLA. Cf. mail du 31/12/2013
                  --When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_427}' AND (CIB.SOURCE_ID = '${P_PIL_243}') AND CIB.STATUT_CSO = 2 THEN 5 -- Supprimé à la demande de Vincent COPPOLA. Cf. mail du 31/12/2013
                    When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_427}' Then 1 
                    When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_430}' AND (CIB.ACTE_STATUT = 6) THEN 5       -- Ajouté à la demande de Vincent COPPOLA. Cf. mail du 31/12/2013 
                    When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_430}' AND (SRC.ACTION_ACTE = 5) THEN 7       -- La modification des actes deja supprimes a tort               
                    When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_430}' AND (CIB.SOURCE_ID = '${P_PIL_243}') AND CIB.STATUT_CSO <> 2 THEN 3 
                    When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_430}' AND (CIB.SOURCE_ID = '${P_PIL_243}') AND CIB.STATUT_CSO = 2 THEN 5
                    When SUBSTR(SRC.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_430}' Then 3
                End
Where
  (1=1)
  And CIB.ACTE_ID = SRC.ACTE_ID
;
.if errorcode <> 0 then .quit 1


-- Réinjection des Actes Supprimés présents lors de l'extraction 
Insert Into ${KNB_PCO_TMP}.ACT_T_PVC_DAY
(
  EXT_DT                        ,
  EXT_SOURCE_ID                 ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  CUID                          ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  SALE_CHANNEL_DLC              ,
  SALE_CHANNEL_ORDER            ,
  CODE_PARC_CLI                 ,
  ORIGINE_DLC_DS                ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_SIRET                ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  VOLUME                        ,
  VALEUR                        ,
  CA                            ,
  STATUT_CSO                    ,
  STATUT_CSO_DS                 ,
  COMMENTAIRE_DS                ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  ACT_CD                        ,
  ACT_TYPE_COMMANDE_ID          ,
  TYPE_COMMANDE_INI             ,
  CODE_COMMANDE_FIN             ,
  TYPE_COMMANDE_FIN             ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  ID_FREGATE                    ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENNITE                ,
  DELAIS_PERENNITE              ,
  OSCAR_VALUE                   ,
  DUREE_ENG                     ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  ID_PARSIFAL                   ,
  MOTIF_DLC_DS                  ,
  FLAG_ETAT_GRV                 ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN 
)
SELECT 
  ExtCur.EXT_DT                     as EXT_DT                        ,
  ExtCur.EXT_SOURCE_ID              as EXT_SOURCE_ID                 ,
  ExtCur.ACTE_ID                    as ACTE_ID                       ,
  ExtCur.ACTE_ID_EXTERNE            as ACTE_ID_EXTERNE               ,
  ExtCur.ACTE_ID_CONTACTE           as ACTE_ID_CONTACTE              ,
  ExtCur.ACTE_ID_DETAIL_CONTACTE    as ACTE_ID_DETAIL_CONTACTE       ,
  ExtCur.ACTE_ID_COMMANDE_REFERENCE as ACTE_ID_COMMANDE_REFERENCE    ,
  ExtCur.SOURCE_ID                  as SOURCE_ID                     ,
  ExtCur.ACTE_STATUT                as ACTE_STATUT                   ,
  5                                 as ACTION_ACTE                   ,
  ExtCur.ORDER_DEPOSIT_TS           as ORDER_DEPOSIT_TS              ,
  ExtCur.ORDER_RECEIVED_PIL_TS      as ORDER_RECEIVED_PIL_TS         ,
  ExtCur.ORDER_MAJ_PIL_TS           as ORDER_MAJ_PIL_TS              ,
  ExtCur.CUID                       as CUID                          ,
  ExtCur.ORDER_STATUT               as ORDER_STATUT                  ,
  ExtCur.ORDER_STATUT_TS            as ORDER_STATUT_TS               ,
  ExtCur.SELLER_LAST_NAME           as SELLER_LAST_NAME              ,
  ExtCur.SELLER_FIRST_NAME          as SELLER_FIRST_NAME             ,
  ExtCur.SALE_CHANNEL_DLC           as SALE_CHANNEL_DLC              ,
  ExtCur.SALE_CHANNEL_ORDER         as SALE_CHANNEL_ORDER            ,
  ExtCur.CODE_PARC_CLI              as CODE_PARC_CLI                 ,
  ExtCur.ORIGINE_DLC_DS             as ORIGINE_DLC_DS                ,
  ExtCur.CUSTOMER_TYPE              as CUSTOMER_TYPE                 ,
  ExtCur.CUSTOMER_SEG               as CUSTOMER_SEG                  ,
  ExtCur.CUSTOMER_LAST_NAME         as CUSTOMER_LAST_NAME            ,
  ExtCur.CUSTOMER_FIRST_NAME        as CUSTOMER_FIRST_NAME           ,
  ExtCur.CUSTOMER_SIRET             as CUSTOMER_SIRET                ,
  ExtCur.MISISDN                    as MISISDN                       ,
  ExtCur.ND                         as ND                            ,
  ExtCur.NDIP                       as NDIP                          ,
  ExtCur.CUSTOMER_CAT               as CUSTOMER_CAT                  ,
  ExtCur.CUSTOMER_AGENCE            as CUSTOMER_AGENCE               ,
  ExtCur.CUSTOMER_ZIPCODE           as CUSTOMER_ZIPCODE              ,
  ExtCur.VOLUME                     as VOLUME                        ,
  ExtCur.VALEUR                     as VALEUR                        ,
  ExtCur.CA                         as CA                            ,
  Case
      When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) In ('6', '7') 
        Then Null
      Else Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD, '5') 
  End                               as STATUT_CSO                    ,
  Case 
      When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) In ('6', '7') 
        Then 'A contrôler'
      When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) = '5' 
        Then 'Valide AUTO'
      When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) = '4' 
        Then 'Non controlé'
      When Coalesce(SRC_AU.CHECK_LOC_STATUS_CD,SRC_AU.CHECK_NAT_STATUS_CD,SRC_AU.CHECK_INITIAL_STATUS_CD) = '2' 
        Then 'Non Valide'
      Else 
        Coalesce(SRC_AU.CHECK_LOC_STATUS_LN,SRC_AU.CHECK_NAT_STATUS_LN, 'Valide AUTO')
  End                               as STATUT_CSO_DS                 ,
  Coalesce(SRC_AU.CHECK_LOC_COMMENT,SRC_AU.CHECK_NAT_COMMENT,ExtCur.COMMENTAIRE_DS)    as COMMENTAIRE_DS                ,
  ExtCur.TEAM_DLC_DES               as TEAM_DLC_DES                  ,
  ExtCur.TEAM_ORDER_DES             as TEAM_ORDER_DES                ,
  ExtCur.ACT_CD                     as ACT_CD                        ,
  ExtCur.ACT_TYPE_COMMANDE_ID       as ACT_TYPE_COMMANDE_ID          ,
  ExtCur.TYPE_COMMANDE_INI          as TYPE_COMMANDE_INI             ,
  ExtCur.CODE_COMMANDE_FIN          as CODE_COMMANDE_FIN             ,
  ExtCur.TYPE_COMMANDE_FIN          as TYPE_COMMANDE_FIN             ,
  ExtCur.CODE_PRODUCT_FIN           as CODE_PRODUCT_FIN              ,
  ExtCur.PRODUCT_DSC_FIN            as PRODUCT_DSC_FIN               ,
  ExtCur.SEGMENT_COM_FIN            as SEGMENT_COM_FIN               ,
  ExtCur.CODE_PRODUCT_INI           as CODE_PRODUCT_INI              ,
  ExtCur.PRODUCT_DSC_INI            as PRODUCT_DSC_INI               ,
  ExtCur.SEGMENT_COM_INI            as SEGMENT_COM_INI               ,
  ExtCur.CODE_MIGR_INI              as CODE_MIGR_INI                 ,
  ExtCur.DSC_MIGR_INI               as DSC_MIGR_INI                  ,
  ExtCur.CODE_MIGR_FIN              as CODE_MIGR_FIN                 ,
  ExtCur.DSC_MIGR_FIN               as DSC_MIGR_FIN                  ,
  ExtCur.ID_FREGATE                 as ID_FREGATE                    ,
  ExtCur.DT_CHECK_PARC              as DT_CHECK_PARC                 ,
  ExtCur.DT_END_PARC                as DT_END_PARC                   ,
  ExtCur.END_PARC_DSC               as END_PARC_DSC                  ,
  ExtCur.TAUX_PERENNITE             as TAUX_PERENNITE                ,
  ExtCur.DELAIS_PERENNITE           as DELAIS_PERENNITE              ,
  ExtCur.OSCAR_VALUE                as OSCAR_VALUE                   ,
  ExtCur.DUREE_ENG                  as DUREE_ENG                     ,
  ExtCur.IMEI                       as IMEI                          ,
  ExtCur.EAN                        as EAN                           ,
  ExtCur.SIM                        as SIM                           ,
  ExtCur.ID_PARSIFAL                as ID_PARSIFAL                   ,
  ExtCur.MOTIF_DLC_DS               as MOTIF_DLC_DS                  ,
  Case When SUBSTR(ExtCur.FLAG_ETAT_GRV, 1, 1) = '${P_PIL_433}' THEN '${P_PIL_432}'
       Else '${P_PIL_431}'
  End                               as FLAG_ETAT_GRV                 ,
  ExtCur.CREATION_TS                as CREATION_TS                   ,
  Current_timestamp(0)              as LAST_MODIF_TS                 ,
  1                                 as FRESH_IN                      ,
  1                                 as COHERENCE_IN 
FROM
  ${KNB_PCO_VM}.ACT_F_PVC_CUR  As ExtCur
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED  As SRC_AU
  On ExtCur.ACTE_ID = SRC_AU.ACTE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
  On  SRC_AU.ACT_PERIODE_ID                              = EtatPeriode.PERIODE_ID
  And EtatPeriode.CURRENT_IN                           = 1
  And EtatPeriode.FRESH_IN                             = 1
  And EtatPeriode.CLOSURE_DT                           Is Null
Where
  (1=1)
  -- la periode n est pas close
  And ( EtatPeriode.PERIODE_STATUS is Null Or EtatPeriode.PERIODE_STATUS = 'O' )
  And Not Exists
     (
        Select
          1
        From
          ${KNB_PCO_TMP}.ACT_T_PVC_DAY          As ExtDay
        Where
          (1=1)
          And ExtDay.ACTE_ID = ExtCur.ACTE_ID
      )
;
.if errorcode <> 0 then .quit 1


.quit 0

