-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Cold_Alimentation_Step5_FusionRepriseSocle_MOB.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de fusion entre les enrichissements placements et le socle placement Mobile
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 21/05/2015      YZH         Pilcom Digital - Nouveaux champs DMC
-- 07/07/2015      MDE         Modif : Ajout Enrichissement CUSTOMER_DOSSIER_NU_ADV QC788
-- 23/12/2015      OCH         Modif : Ajout Enrichissement WEBPART/EDO
-- 28/03/2017      MDE         Evol : ajout CID/PID/FIRST 
-- 27/11/2017      MEL         Ajout indicateur IOBSP
-- 13/07/2018      LMU         Modification des IOBSP
-- 30/08/2018      JCR         Correction EDO_IOBSP
-- 21/02/2019      SSI         Alimentation Champs ORG_AGENT_IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 31/07/2020      EVI         PILCOM-386 : Refonte Digital - Enrichissement SOFT via 6PO
-- 06/08/2020      JCR         Enrichissement VAD pour SOFTM et SOFTP sur CUSTOMER_DOSSIER_NU_ADV et CUSTOMER_CLIENT_NU_ADV
-- 21/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
-- 23/03/2021      EVI         PILCOM-801 : REFONTE DIGITAL - Fiabilisation recherche DMC
-- 15/04/2021      EVI         PILCOM-886 : Modification alimentation CLIENT_NU/DOSSIER_NU via VAD
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------
--  DELETE WORKING TABLES
----------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_C_MOB all;
.if errorcode <> 0 then .quit 1

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_MOB_6PO all;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------
--  REFONTE DIGITAL : Enrichissement Canal SOFT depuis 6PO
----------------------------------------------------------
-- consitution de la table temporaire 6PO pour l'enrichissement du canal 



-- Alimentation des commandes MyShop
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_MOB_6PO
(
EXTERNAL_ORDER_ID ,
ORDR_CREATN_DT    ,
ORDR_ORGN_CD      ,
TYPE_PF           ,
EXTERNAL_ORDER_ID_SANS_33G
)
Select 
RefSpo.ORDR_ID                                            as EXTERNAL_ORDER_ID  ,
Cast (RefSpo.ORDR_CREATN_DT As Date FORMAT 'YYYY-MM-DD')  as ORDR_CREATN_DT     ,
RefSpo.ORDR_MSH_ORGN_DS                                   as ORDR_ORGN_CD       ,
'${P_PIL_630}'                                                  as TYPE_PF            ,
Case When RefSpo.ORDR_ID Like '33G%'
  Then substring(EXTERNAL_ORDER_ID, 4, length (EXTERNAL_ORDER_ID)) -- On enleve le 33G
End                     as EXTERNAL_ORDER_ID_SANS_33G

From ${KNB_SPO_DM_GLB}.ORD_F_ORDR_BSKT_MSH_OL_D_VM RefSpo
Inner join ${KNB_SPO_DM_GLB}.ORD_F_ARTCL_BASKT_MSH_OL Basket
  On Basket.ORDR_ID = RefSpo.ORDR_ID
Where
  1=1
  And RefSpo.CURRENT_IN     = 1
  And Basket.ACTN_CATGR_CD  In (${L_PIL_142})
  And (
        ( RefSpo.ORDR_CREATN_DT >= Current_Date - 7 )
      Or
        ( RefSpo.ORDR_CREATN_DT >= '${KNB_PILCOM_PLACEMENT_BORNE_INF}')
      )
;
.if errorcode <> 0 then .quit 1

-- Alimentation des commandes MyShopDOM
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_MOB_6PO
(
EXTERNAL_ORDER_ID ,
ORDR_CREATN_DT    ,
ORDR_ORGN_CD      ,
TYPE_PF           ,
EXTERNAL_ORDER_ID_SANS_33G
)
Select 
Substr(RefSpo.ORDR_ID,4)                                  as EXTERNAL_ORDER_ID  ,
Cast (RefSpo.ORDR_CREATN_DT As Date FORMAT 'YYYY-MM-DD')  as ORDR_CREATN_DT     ,
RefSpo.ORDR_ORGN_DS                                       as ORDR_ORGN_CD       ,
'${P_PIL_631}'                                               as TYPE_PF            ,
Null                                                      as EXTERNAL_ORDER_ID_SANS_33G

From ${KNB_SPO_DM_GLB}.ORD_F_ORDR_GLBL_MSH_OL_D_VM RefSpo
Inner join ${KNB_SPO_DM_GLB}.ORD_F_BSKT_GLBL_MSH_OL_D_VM Basket
  On Basket.ORDR_ID = RefSpo.ORDR_ID
Where
  1=1
  And RefSpo.CURRENT_IN           = 1
  And TRIM(Basket.ACTN_CATGR_CD)  In (${L_PIL_142})
  And (
        ( RefSpo.ORDR_CREATN_DT >= Current_Date - 7 )
      Or
        ( RefSpo.ORDR_CREATN_DT >= '${KNB_PILCOM_PLACEMENT_BORNE_INF}')
      )
;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_MOB_6PO;
.if errorcode <> 0 then .quit 1;

----------------------------------------------------------
--  PLACEMENT SOFT MOB : Alimentation
----------------------------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_C_MOB
(  
  ACTE_ID                       ,
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  TYPE_PRODUCT                  ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_DEPOSIT_DT              ,
  VAD_ORDER_ID                  ,
  ORDER_DEPOSIT_TS              ,
  ORDER_VALIDATION_TS           ,
  ORDER_DELIVERY_TS             ,
  AGENT_ID                      ,
  ORG_NOM                       ,
  ORG_PRENOM                    ,
  ORG_SOURCE_ENRI               ,
  DISTRBTN_CHANNL_ID            ,
  STORE_NAME                    ,
  EDO_ID                        ,
  FLAG_PLT_CONV                 ,
  FLAG_TEAM_MKT                 ,
  FLAG_TYPE_CMP                 ,
  TYPE_EDO                      ,
  NETWRK_TYP_EDO_ID             ,
  FLAG_TYPE_GEO                 ,
  FLAG_TYPE_CPT_NTK             ,
  FLAG_TYPE_PTN_NTK             ,
  MOTV_ORDR_ID                  ,
  ORDER_TYPE_CD                 ,
  ORDER_TYPE_ID                 ,
  CANCEL_MOTV_DS                ,
  ACTE_OPERTR_ID_OT             ,
  CUSTOMER_CIVILITY             ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_MARKET_SEG           ,
  CUSTOMER_SIRET                ,
  CUSTOMER_BSS_ID               ,
  CUSTOMER_FGT_ID               ,
  CUSTOMER_ND                   ,
  CUSTOMER_CPT_FAC_FGT          ,
  CUSTOMER_CLIENT_NU_ADV        ,
  CUSTOMER_DOSSIER_NU_ADV       ,
  CUSTOMER_BO_ID                ,
  CUSTOMER_ND_AR                ,
  SERVICE_ACCESS_ID             ,
  TYPE_ENRI_AS                  ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  PAR_DEPRTMNT_ID               ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  ORG_AGENT_IOBSP               ,
  ORG_EDO_IOBSP                 ,
  PAR_BU_CD                     ,
  PAR_POSTAL_CD                 ,
  PAR_INSEE_CD                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_IRIS2000_CD               ,
  PAR_FIBER_IN                  ,
  REDIRECTION_CD                ,
  CONVERGENT_IN                 ,
  PRESFACT_CO_PRE_ADV           ,
  OFFRE_ACC_PCA_PRE             ,
  SEG_COM_ID_PCA_PRE_DT_DEB     ,
  SEG_COM_ID_PCA_PRE_DT_FIN     ,
  PAR_TAC_CD                    ,
  PAR_IMEI_CD                   ,
  PAR_IMSI_CD                   ,
  PAR_EXTERNAL_PARTY_ID         ,
  PAR_SCORE_NU_INT              ,
  PAR_SCORE_IN_INT              ,
  PAR_TRESHOLD_NU_INT           ,
  PAR_SCORE_NU_MOB              ,
  PAR_SCORE_IN_MOB              ,
  PAR_TRESHOLD_NU_MOB           ,
  CONTRCT_DT_SIGN_PREC_INT      ,
  CONTRCT_DT_FIN_PREC_INT       ,
  CONTRCT_DT_DEB_SIGN_POST_INT  ,
  CONTRCT_DT_FIN_SIGN_POST_INT  ,
  DUREE_ENGAGEMENT_INT          ,
  TYPE_DUR_ENGAGEMENT_INT       ,
  CONTRCT_DT_SIGN_PREC_MOB      ,
  CONTRCT_DT_FIN_PREC_MOB       ,
  CONTRCT_DT_SIGN_POST_MOB      ,
  CONTRCT_DUREE_ENG_MOB         ,
  CONTRCT_UNIT_ENG_MOB          ,
  RESIL_INT_DT                  ,
  RESIL_INT_MOTIF               ,
  RESIL_INT_MOTIF_DS            ,
  RESIL_MOB_DT                  ,
  RESIL_MOB_MOTIF               ,
  RESIL_MOB_MOTIF_DS            ,
  INSTALL_ADDRESS_STREET        ,
  INSTALL_ADDRESS_ZIPCODE       ,
  INSTALL_ADDRESS_CITY          ,
  INSTALL_ADDRESS_COUNTRY       ,
  INSTALL_REGIONAL_DIRCTN_ID    ,
  CONTACT_CIVILITY              ,
  CONTACT_LAST_NAME             ,
  CONTACT_FIRST_NAME            ,
  CONTACT_MOBILE_NUMBER         ,
  CONTACT_MAIL_ADDRESS          ,
  CONTACT_ADDRESS_STREET        ,
  CONTACT_ADDRESS_ZIPCODE       ,
  CONTACT_ADDRESS_CITY          ,
  CONTACT_ADDRESS_COUNTRY       ,
  SHIPMENT_ADDRESS_RELAY_ID     ,
  SHIPMENT_ADDRESS_STREET       ,
  SHIPMENT_ADDRESS_ZIPCODE      ,
  SHIPMENT_ADDRESS_CITY         ,
  SHIPMENT_ADDRESS_COUNTRY      ,
  BO_AGENT_ID                   ,
  ORDER_LINE_EXTERNAL_ID        ,
  EXT_OPER_ID                   ,
  PRESFACT_CO_OFFRE_OPT         ,
  PRESFACT_CO_OFFRE_OPT_DS      ,
  OSCAR_VALUE_NU                ,
  ORDER_COMPLETED               ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT ,
  FLAG_FIRST_RECEPTION_PSF      ,
  ORDER_LAST_STATUT_CD          ,
  ORDER_LAST_STATUT_MODIF_TS    ,
  ORDER_FIRST_STATUT_CD         ,
  ORDER_FIRST_STATUT_MODIF_TS   ,
  ENR6PO_ORDR_ORGN              ,
  ENR6PO_TYPE_PF                ,
  QUEUE_TS                      ,
  RUN_ID                        ,
  STREAMING_TS                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  HOT_IN                        ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  Socle.ACTE_ID                                                                                                 as ACTE_ID                        ,
  Socle.EXTERNAL_ORDER_ID                                                                                       as EXTERNAL_ORDER_ID              ,
  Socle.ORDER_STATUS_CD                                                                                         as ORDER_STATUS_CD                ,
  Socle.STATUS_MODIF_TS                                                                                         as STATUS_MODIF_TS                ,
  Socle.INTRNL_SOURCE_ID                                                                                        as INTRNL_SOURCE_ID               ,
  Socle.TYPE_SOURCE_ID                                                                                          as TYPE_SOURCE_ID                 ,
  Socle.TYPE_PRODUCT                                                                                            as TYPE_PRODUCT                   ,
  Socle.OPERATOR_PROVIDER_ID                                                                                    as OPERATOR_PROVIDER_ID           ,
  Socle.ORDER_DEPOSIT_DT                                                                                        as ORDER_DEPOSIT_DT               ,
  Coalesce(RefIdSoft.VAD_ORDER_ID,Socle.VAD_ORDER_ID)                                                           as VAD_ORDER_ID                   ,
  Socle.ORDER_DEPOSIT_TS                                                                                        as ORDER_DEPOSIT_TS               ,
  Socle.ORDER_VALIDATION_TS                                                                                     as ORDER_VALIDATION_TS            ,
  Socle.ORDER_DELIVERY_TS                                                                                       as ORDER_DELIVERY_TS              ,
  Socle.AGENT_ID                                                                                                as AGENT_ID                       ,
  --Attributs sur les noms / Prénom du conseiller
  Coalesce(Conseiller.ORG_NOM,Socle.ORG_NOM)                                                                    as ORG_NOM                        ,
  Coalesce(Conseiller.ORG_PRENOM,Socle.ORG_PRENOM)                                                              as ORG_PRENOM                     ,
  Coalesce(Conseiller.ORG_SOURCE_ENRI,Socle.ORG_SOURCE_ENRI)                                                    as ORG_SOURCE_ENRI                ,
  Socle.DISTRBTN_CHANNL_ID                                                                                      as DISTRBTN_CHANNL_ID             ,
  Socle.STORE_NAME                                                                                              as STORE_NAME                     ,
  --Organisation O3
  Coalesce(OrgO3.EDO_ID,Socle.EDO_ID)                                                                           as EDO_ID                         ,
  Coalesce(OrgO3.FLAG_PLT_CONV,Socle.FLAG_PLT_CONV,0)                                                           as FLAG_PLT_CONV                  ,
  Coalesce(FlagMarket.FLAG_TEAM_MKT,Socle.FLAG_TEAM_MKT,0)                                                      as FLAG_TEAM_MKT                  ,
  Coalesce(FlagMarket.FLAG_TYPE_CMP,Socle.FLAG_TYPE_CMP,'#')                                                    as FLAG_TYPE_CMP                  ,
  Coalesce(OrgO3.TYPE_EDO,Socle.TYPE_EDO)                                                                       as TYPE_EDO                       ,
  OrgO3.NETWRK_TYP_EDO_ID                                                                                       as NETWRK_TYP_EDO_ID              ,
  OrgO3.FLAG_TYPE_GEO                                                                                           as FLAG_TYPE_GEO                  ,
  OrgO3.FLAG_TYPE_CPT_NTK                                                                                       as FLAG_TYPE_CPT_NTK              ,
  OrgO3.FLAG_TYPE_PTN_NTK                                                                                       as FLAG_TYPE_PTN_NTK              ,
  Socle.MOTV_ORDR_ID                                                                                            as MOTV_ORDR_ID                   ,
  Socle.ORDER_TYPE_CD                                                                                           as ORDER_TYPE_CD                  ,
  Socle.ORDER_TYPE_ID                                                                                           as ORDER_TYPE_ID                  ,
  Socle.CANCEL_MOTV_DS                                                                                          as CANCEL_MOTV_DS                 ,
  Socle.ACTE_OPERTR_ID_OT                                                                                       as ACTE_OPERTR_ID_OT              ,
  Socle.CUSTOMER_CIVILITY                                                                                       as CUSTOMER_CIVILITY              ,
  Socle.CUSTOMER_LAST_NAME                                                                                      as CUSTOMER_LAST_NAME             ,
  Socle.CUSTOMER_FIRST_NAME                                                                                     as CUSTOMER_FIRST_NAME            ,
  Socle.CUSTOMER_MARKET_SEG                                                                                     as CUSTOMER_MARKET_SEG            ,
  Socle.CUSTOMER_SIRET                                                                                          as CUSTOMER_SIRET                 ,
  Coalesce(RefIdSoft.CUSTOMER_BSS_ID,Socle.CUSTOMER_BSS_ID)                                                     as CUSTOMER_BSS_ID                ,
  Coalesce(RefIdSoft.CUSTOMER_FGT_ID,Socle.CUSTOMER_FGT_ID)                                                     as CUSTOMER_FGT_ID                ,
  Socle.CUSTOMER_ND                                                                                             as CUSTOMER_ND                    ,
  Coalesce(RefIdSoft.CUSTOMER_CPT_FAC_FGT,Socle.CUSTOMER_CPT_FAC_FGT)                                           as CUSTOMER_CPT_FAC_FGT           ,
  Case 
    When Socle.ACTE_OPERTR_ID_OT = 'CREAT' 
      Then Coalesce(RefIdSoft.CUSTOMER_CLIENT_NU_ADV,Socle.CUSTOMER_CLIENT_NU_ADV)
    Else Coalesce(ClientNu.CUSTOMER_CLIENT_NU_ADV,Socle.CUSTOMER_CLIENT_NU_ADV,RefIdSoft.CUSTOMER_CLIENT_NU_ADV)  
  End                                                                                                           as CUSTOMER_CLIENT_NU_ADV         ,
  Case 
    When Socle.ACTE_OPERTR_ID_OT = 'CREAT' 
      Then Coalesce(RefIdSoft.CUSTOMER_DOSSIER_NU_ADV,Socle.CUSTOMER_DOSSIER_NU_ADV)
    Else Coalesce(DossierNu.CUSTOMER_DOSSIER_NU_ADV,DossierNub.CUSTOMER_DOSSIER_NU_ADV,Socle.CUSTOMER_DOSSIER_NU_ADV,RefIdSoft.CUSTOMER_DOSSIER_NU_ADV)
  End                                                                                                           as CUSTOMER_DOSSIER_NU_ADV        ,
  Socle.CUSTOMER_BO_ID                                                                                          as CUSTOMER_BO_ID                 ,
  Coalesce(RefIdSoft.CUSTOMER_ND_AR,Socle.CUSTOMER_ND_AR)                                                       as CUSTOMER_ND_AR                 ,
  --AS de la commande
  Coalesce(RefAs.SERVICE_ACCESS_ID,Socle.SERVICE_ACCESS_ID)                                                     as SERVICE_ACCESS_ID              ,
  --Type d'enrichissement de l'AS
  Coalesce(RefAs.TYPE_ENRI,Socle.TYPE_ENRI_AS)                                                                  as TYPE_ENRI_AS                   ,
  --Attribut DMC
  LineDMC.LINE_ID                                                                                               as LINE_ID                        ,
  LineDMC.MASTER_LINE_ID                                                                                        as MASTER_LINE_ID                 ,
  LineDMC.PAR_DEPRTMNT_ID                                                                                       as PAR_DEPRTMNT_ID                ,
   --
  LineDMC.PAR_CID_ID                                                                                            as  PAR_CID_ID                    ,
  LineDMC.PAR_PID_ID                                                                                            as  PAR_PID_ID                    ,
  LineDMC.PAR_FIRST_IN                                                                                          as  PAR_FIRST_IN                  ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                                                                         as  ORG_AGENT_IOBSP         ,
  case when  EdoOBK.EDO_ID is null
          Then 'N'
          Else 'O'
  End                                                                                                           as ORG_EDO_IOBSP                  ,
  --
  GeoBU.BU_CD                                                                                                   as PAR_BU_CD                      ,
  LineDMC.PAR_POSTAL_CD                                                                                         as PAR_POSTAL_CD                  ,
  LineDMC.PAR_INSEE_CD                                                                                          as PAR_INSEE_CD                   ,
  Iris.PAR_GEO_MACROZONE                                                                                        as PAR_GEO_MACROZONE              ,
  LineDMC.PAR_UNIFIED_PARTY_ID                                                                                  as PAR_UNIFIED_PARTY_ID           ,
  LineDMC.PAR_PARTY_REGRPMNT_ID                                                                                 as PAR_PARTY_REGRPMNT_ID          ,
  Iris.PAR_IRIS2000_CD                                                                                          as PAR_IRIS2000_CD                ,
  Fibr.PAR_FIBER_IN                                                                                             as PAR_FIBER_IN                   ,
  Null                                                                                                          as REDIRECTION_CD                 ,
  --Convergence DMC
  Coalesce(ConvDMC.CONVERGENT_IN,Socle.CONVERGENT_IN)                                                           as CONVERGENT_IN                  ,
  --Prestation Précédante ADV
  Coalesce(ParcPreADV.PRESFACT_CO_PRECED,Socle.PRESFACT_CO_PRE_ADV)                                             as PRESFACT_CO_PRE_ADV            ,
  --Offre Internet Précédant
  Coalesce(ParcPrePCA.SEG_COM_ID_PCA_PRE,Socle.OFFRE_ACC_PCA_PRE)                                               as OFFRE_ACC_PCA_PRE              ,
  Coalesce(ParcPrePCA.SEG_COM_ID_PCA_PRE_DT_DEB ,Socle.SEG_COM_ID_PCA_PRE_DT_DEB)                               as SEG_COM_ID_PCA_PRE_DT_DEB      ,
  Coalesce(ParcPrePCA.SEG_COM_ID_PCA_PRE_DT_FIN ,Socle.SEG_COM_ID_PCA_PRE_DT_FIN)                               as SEG_COM_ID_PCA_PRE_DT_FIN      ,
  --Enrichissement des attributs Du Mobiles :
  Coalesce(MobDMC.TAC_CD,Socle.PAR_TAC_CD)                                                                      as PAR_TAC_CD                     ,
  Coalesce(MobDMC.IMEI_CD,Socle.PAR_IMEI_CD)                                                                    as PAR_IMEI_CD                    ,
  Coalesce(ResMOBImsi.PAR_IMSI,MobDMC.IMSI_CD,Socle.PAR_IMSI_CD)                                                as PAR_IMSI_CD                    ,
  Coalesce(MobDMC.EXTERNAL_PARTY_ID,Socle.PAR_EXTERNAL_PARTY_ID)                                                as PAR_EXTERNAL_PARTY_ID          ,
  --Score du client Internet
  Coalesce(ScoreCliInt.PAR_SCORE_NU,Socle.PAR_SCORE_NU_INT)                                                     as PAR_SCORE_NU_INT               ,
  Coalesce(ScoreCliInt.PAR_SCORE_IN,Socle.PAR_SCORE_IN_INT)                                                     as PAR_SCORE_IN_INT               ,
  Coalesce(ScoreCliInt.PAR_TRESHOLD_NU,Socle.PAR_TRESHOLD_NU_INT)                                               as PAR_TRESHOLD_NU_INT            ,
  --Score du client Mobile
  Coalesce(ScoreCliMob.PAR_SCORE_NU,Socle.PAR_SCORE_NU_MOB)                                                     as PAR_SCORE_NU_MOB               ,
  Coalesce(ScoreCliMob.PAR_SCORE_IN,Socle.PAR_SCORE_IN_MOB)                                                     as PAR_SCORE_IN_MOB               ,
  Coalesce(ScoreCliMob.PAR_TRESHOLD_NU,Socle.PAR_TRESHOLD_NU_MOB)                                               as PAR_TRESHOLD_NU_MOB            ,
  --Date de début de Contrat précédant
  Coalesce(RefEngPre.CONTRCT_DT_SIGN_PREC,Socle.CONTRCT_DT_SIGN_PREC_INT)                                       as CONTRCT_DT_SIGN_PREC_INT       ,
  --Date de Fin de Contrat précédant
  Coalesce(RefEngPre.CONTRCT_DT_FIN_PREC,Socle.CONTRCT_DT_FIN_PREC_INT)                                         as CONTRCT_DT_FIN_PREC_INT        ,
  --Date début de Contat Post Commande
  Coalesce(RefEng.CONTRCT_DT_DEB_SIGN_POST,Socle.CONTRCT_DT_DEB_SIGN_POST_INT)                                  as CONTRCT_DT_DEB_SIGN_POST_INT   ,
  --Date Fin de Contat Post Commande
  Coalesce(RefEng.CONTRCT_DT_FIN_SIGN_POST,Socle.CONTRCT_DT_FIN_SIGN_POST_INT)                                  as CONTRCT_DT_FIN_SIGN_POST_INT   ,
   --Duree d'engagement Post Commande
  Coalesce(RefEng.DUREE_ENGAGEMENT,Socle.DUREE_ENGAGEMENT_INT)                                                  as DUREE_ENGAGEMENT_INT           ,
   --Type de durée d'engagement Post Commande
  Coalesce(RefEng.TYPE_DUR_ENGAGEMENT,Socle.TYPE_DUR_ENGAGEMENT_INT)                                            as TYPE_DUR_ENGAGEMENT_INT        ,
  --Attribut sur l'engagement Mobile :
  Coalesce(EngPreMob.CONTRCT_DT_SIGN_PREC,Socle.CONTRCT_DT_SIGN_PREC_MOB)                                       as CONTRCT_DT_SIGN_PREC_MOB       ,
  Coalesce(EngPreMob.CONTRCT_DT_FIN_PREC,Socle.CONTRCT_DT_FIN_PREC_MOB)                                         as CONTRCT_DT_FIN_PREC_MOB        ,
  Coalesce(EngMob.CONTRCT_DT_SIGN_POST,Socle.CONTRCT_DT_SIGN_POST_MOB)                                          as CONTRCT_DT_SIGN_POST_MOB       ,
  Coalesce(EngMob.CONTRCT_DUREE_ENG,Socle.CONTRCT_DUREE_ENG_MOB)                                                as CONTRCT_DUREE_ENG_MOB          ,
  Coalesce(EngMob.CONTRCT_UNIT_ENG,Socle.CONTRCT_UNIT_ENG_MOB)                                                  as CONTRCT_UNIT_ENG_MOB           ,
  --Indicateur de résiliation Internet
  Coalesce(ResInt.RESIL_INT_DT,Socle.RESIL_INT_DT)                                                              as RESIL_INT_DT                   ,
  Coalesce(ResInt.RESIL_INT_MOTIF,Socle.RESIL_INT_MOTIF)                                                        as RESIL_INT_MOTIF                ,
  Coalesce(ResInt.RESIL_INT_MOTIF_DS,Socle.RESIL_INT_MOTIF_DS)                                                  as RESIL_INT_MOTIF_DS             ,
  --Indicateur de résiliation Mobile
  Case  When ResMOBImsi.EXTERNAL_ORDER_ID Is Not Null
          Then  ResMOBImsi.DOSSIER_DATE_RESIL
        Else    Socle.RESIL_MOB_DT
  End                                                                                                           as RESIL_MOB_DT                   ,
  Case  When ResMOBImsi.EXTERNAL_ORDER_ID Is Not Null
          Then  ResMOBImsi.DOSSIER_TYPE_RESIL
        Else    Socle.RESIL_MOB_MOTIF
  End                                                                                                           as RESIL_MOB_MOTIF                ,
  Case  When ResMOBImsi.EXTERNAL_ORDER_ID Is Not Null
          Then  ResMOBImsi.DOSSIER_MOTIF_RESIL
        Else    Socle.RESIL_MOB_MOTIF_DS
  End                                                                                                           as RESIL_MOB_MOTIF_DS             ,
  Socle.INSTALL_ADDRESS_STREET                                                                                  as INSTALL_ADDRESS_STREET         ,
  Socle.INSTALL_ADDRESS_ZIPCODE                                                                                 as INSTALL_ADDRESS_ZIPCODE        ,
  Socle.INSTALL_ADDRESS_CITY                                                                                    as INSTALL_ADDRESS_CITY           ,
  Socle.INSTALL_ADDRESS_COUNTRY                                                                                 as INSTALL_ADDRESS_COUNTRY        ,
  Socle.INSTALL_REGIONAL_DIRCTN_ID                                                                              as INSTALL_REGIONAL_DIRCTN_ID     ,
  Socle.CONTACT_CIVILITY                                                                                        as CONTACT_CIVILITY               ,
  Socle.CONTACT_LAST_NAME                                                                                       as CONTACT_LAST_NAME              ,
  Socle.CONTACT_FIRST_NAME                                                                                      as CONTACT_FIRST_NAME             ,
  Socle.CONTACT_MOBILE_NUMBER                                                                                   as CONTACT_MOBILE_NUMBER          ,
  Socle.CONTACT_MAIL_ADDRESS                                                                                    as CONTACT_MAIL_ADDRESS           ,
  Socle.CONTACT_ADDRESS_STREET                                                                                  as CONTACT_ADDRESS_STREET         ,
  Socle.CONTACT_ADDRESS_ZIPCODE                                                                                 as CONTACT_ADDRESS_ZIPCODE        ,
  Socle.CONTACT_ADDRESS_CITY                                                                                    as CONTACT_ADDRESS_CITY           ,
  Socle.CONTACT_ADDRESS_COUNTRY                                                                                 as CONTACT_ADDRESS_COUNTRY        ,
  Socle.SHIPMENT_ADDRESS_RELAY_ID                                                                               as SHIPMENT_ADDRESS_RELAY_ID      ,
  Socle.SHIPMENT_ADDRESS_STREET                                                                                 as SHIPMENT_ADDRESS_STREET        ,
  Socle.SHIPMENT_ADDRESS_ZIPCODE                                                                                as SHIPMENT_ADDRESS_ZIPCODE       ,
  Socle.SHIPMENT_ADDRESS_CITY                                                                                   as SHIPMENT_ADDRESS_CITY          ,
  Socle.SHIPMENT_ADDRESS_COUNTRY                                                                                as SHIPMENT_ADDRESS_COUNTRY       ,
  Socle.BO_AGENT_ID                                                                                             as BO_AGENT_ID                    ,
  Socle.ORDER_LINE_EXTERNAL_ID                                                                                  as ORDER_LINE_EXTERNAL_ID         ,
  Socle.EXT_OPER_ID                                                                                             as EXT_OPER_ID                    ,
  Socle.PRESFACT_CO_OFFRE_OPT                                                                                   as PRESFACT_CO_OFFRE_OPT          ,
  Socle.PRESFACT_CO_OFFRE_OPT_DS                                                                                as PRESFACT_CO_OFFRE_OPT_DS       ,
  --On met le code OSCAR
  Coalesce(CodeOscar.OSCAR_SEGEMENT,Socle.OSCAR_VALUE_NU)                                                       as OSCAR_VALUE_NU                 ,
  Socle.ORDER_COMPLETED                                                                                         as ORDER_COMPLETED                ,
  Socle.FLAG_FIRST_RECEPTION_COM                                                                                as FLAG_FIRST_RECEPTION_COM       ,
  Socle.FLAG_FIRST_RECEPTION_COM_STAT                                                                           as FLAG_FIRST_RECEPTION_COM_STAT  ,
  RefIdSoft.FLAG_FIRST_RECEPTION_PSF                                                                            as FLAG_FIRST_RECEPTION_PSF       ,
  RefIdSoft.LAST_ORDER_STATUS_CD                                                                                as ORDER_LAST_STATUT_CD           ,
  RefIdSoft.LAST_STATUS_MODIF_TS                                                                                as ORDER_LAST_STATUT_MODIF_TS     ,
  RefIdSoft.FIRST_ORDER_STATUS_CD                                                                               as ORDER_FIRST_STATUT_CD          ,
  RefIdSoft.FIRST_STATUS_MODIF_TS                                                                               as ORDER_FIRST_STATUT_MODIF_TS    ,
  Coalesce(Socle.ENR6PO_ORDR_ORGN,SPO_MSH.ORDR_ORGN_CD,SPO_NEMO.ORDR_ORGN_CD)                                   as ENR6PO_ORDR_ORGN               ,
  Coalesce(Socle.ENR6PO_TYPE_PF,SPO_MSH.TYPE_PF,SPO_NEMO.TYPE_PF)                                               as ENR6PO_TYPE_PF                 ,
  Socle.QUEUE_TS                                                                                                as QUEUE_TS                       ,
  Socle.RUN_ID                                                                                                  as RUN_ID                         ,
  Socle.STREAMING_TS                                                                                            as STREAMING_TS                   ,
  Socle.CREATION_TS                                                                                             as CREATION_TS                    ,
  Socle.LAST_MODIF_TS                                                                                           as LAST_MODIF_TS                  ,
  --On valorise maintenat le HOT à 0
  '0'                                                                                                           as HOT_IN                         ,
  Socle.FRESH_IN                                                                                                as FRESH_IN                       ,
  Socle.COHERENCE_IN                                                                                            as COHERENCE_IN                   
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_REFIDCD  RefIdSoft
  --On va dans le socle pour récupérer les ID Acte dans le socle
  Inner Join  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_MOB Socle
    On    RefIdSoft.EXTERNAL_ORDER_ID = Socle.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_STATUS_CD   = Socle.ORDER_STATUS_CD
      And RefIdSoft.STATUS_MODIF_TS   = Socle.STATUS_MODIF_TS
      And RefIdSoft.ORDER_DEPOSIT_DT  = Socle.ORDER_DEPOSIT_DT
  --Récupération des AS
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_AS RefAs
    On    RefIdSoft.EXTERNAL_ORDER_ID = RefAs.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = RefAs.ORDER_DEPOSIT_DT
  --Récupération de l'engagement de la commande
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENG RefEng
    On    RefIdSoft.EXTERNAL_ORDER_ID = RefEng.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = RefEng.ORDER_DEPOSIT_DT
  --Récupération de l'engagement précédant
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENG_PRE RefEngPre
    On    RefIdSoft.EXTERNAL_ORDER_ID = RefEngPre.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = RefEngPre.ORDER_DEPOSIT_DT
  --Récupération de l'Id Parsifal
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_PSFIDP IdPSF
    On    RefIdSoft.EXTERNAL_ORDER_ID = IdPSF.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = IdPSF.ORDER_DEPOSIT_DT
  --Récupération du client NU
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_CLIENT ClientNu
    On    RefIdSoft.EXTERNAL_ORDER_ID = ClientNu.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ClientNu.ORDER_DEPOSIT_DT
  --Récupération du DOSSIER NU
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_DOSSIER DossierNu
    On    RefIdSoft.EXTERNAL_ORDER_ID = DossierNu.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = DossierNu.ORDER_DEPOSIT_DT
       --Récupération du DOSSIER NU_B
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_NMDOSB DossierNuB
    On    RefIdSoft.EXTERNAL_ORDER_ID = DossierNuB.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = DossierNuB.ORDER_DEPOSIT_DT
  --Récupération Id O3
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_O3 OrgO3
    On    RefIdSoft.EXTERNAL_ORDER_ID = OrgO3.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_STATUS_CD   = OrgO3.ORDER_STATUS_CD
      And RefIdSoft.STATUS_MODIF_TS   = OrgO3.STATUS_MODIF_TS
      And RefIdSoft.ORDER_DEPOSIT_DT  = OrgO3.ORDER_DEPOSIT_DT
  --On récupère le code OSCAR
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_OSCAR CodeOscar
    On    RefIdSoft.EXTERNAL_ORDER_ID = CodeOscar.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = CodeOscar.ORDER_DEPOSIT_DT
  --On recupère les attributs DMC :
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_DMC LineDMC
    On    RefIdSoft.EXTERNAL_ORDER_ID = LineDMC.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = LineDMC.ORDER_DEPOSIT_DT
      And LineDMC.TYPE_SOURCE         = 'MOB'  
  --On recupère le code DO de la BU
  Left Outer Join ${KNB_DMC_VM_V}.GEO_R_BUSINESS_UNIT GeoBU
    On    LineDMC.PAR_DEPRTMNT_ID         = GeoBU.DEPT_CD 
  --On récupère le code Iris      
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_IRIS Iris
    On    RefIdSoft.EXTERNAL_ORDER_ID = Iris.EXTERNAL_ORDER_ID
    And   RefIdSoft.ORDER_DEPOSIT_DT  = Iris.ORDER_DEPOSIT_DT    
      And Iris.TYPE_SOURCE            = 'MOB'  
  --On récupère l'indicateur Fibre
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_FIBR Fibr
    On    RefIdSoft.EXTERNAL_ORDER_ID = Fibr.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = Fibr.ORDER_DEPOSIT_DT       
      And Fibr.TYPE_SOURCE            = 'MOB'  
  --On recupère les attributs Convergence DMC :
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_DMC_CV ConvDMC
    On    RefIdSoft.EXTERNAL_ORDER_ID = ConvDMC.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ConvDMC.ORDER_DEPOSIT_DT
      And ConvDMC.TYPE_SOURCE         = 'MOB'  
  --On récupère la prestation ADV avant la vente
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_PARCADV ParcPreADV
    On    RefIdSoft.EXTERNAL_ORDER_ID = ParcPreADV.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ParcPreADV.ORDER_DEPOSIT_DT
  --On récupère L'offre d'access PCA précédant 
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_OLDOC ParcPrePCA
    On    RefIdSoft.EXTERNAL_ORDER_ID = ParcPrePCA.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ParcPrePCA.ORDER_DEPOSIT_DT
  --On récupère le score du client Internet au moment de la vente
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_SC_INT ScoreCliInt
    On    RefIdSoft.EXTERNAL_ORDER_ID = ScoreCliInt.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ScoreCliInt.ORDER_DEPOSIT_DT
      And ScoreCliInt.TYPE_SOURCE     = 'MOB'  
  --On récupère le score du client Mobile au moment de la vente
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_SCCLI ScoreCliMob
    On    RefIdSoft.EXTERNAL_ORDER_ID = ScoreCliMob.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ScoreCliMob.ORDER_DEPOSIT_DT
  --On récupère les attributs du conseiller
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_CONSEIL Conseiller
    On    RefIdSoft.EXTERNAL_ORDER_ID = Conseiller.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_STATUS_CD   = Conseiller.ORDER_STATUS_CD
      And RefIdSoft.STATUS_MODIF_TS   = Conseiller.STATUS_MODIF_TS
      And RefIdSoft.ORDER_DEPOSIT_DT  = Conseiller.ORDER_DEPOSIT_DT
  -- On récupère l'engagement Précédant
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENGPMOB EngPreMob
    On    RefIdSoft.EXTERNAL_ORDER_ID = EngPreMob.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = EngPreMob.ORDER_DEPOSIT_DT
  -- On récupère l'engagement
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_ENGNMOB EngMob
    On    RefIdSoft.EXTERNAL_ORDER_ID = EngMob.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = EngMob.ORDER_DEPOSIT_DT
  -- On récupère les données des Teams Marketting :
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_MKT FlagMarket
    On    RefIdSoft.EXTERNAL_ORDER_ID = FlagMarket.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_STATUS_CD   = FlagMarket.ORDER_STATUS_CD
      And RefIdSoft.STATUS_MODIF_TS   = FlagMarket.STATUS_MODIF_TS
      And RefIdSoft.ORDER_DEPOSIT_DT  = FlagMarket.ORDER_DEPOSIT_DT
  --On recupère les attributs Mobile Internet DMC :
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_INFMOB MobDMC
    On    RefIdSoft.EXTERNAL_ORDER_ID = MobDMC.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = MobDMC.ORDER_DEPOSIT_DT
      And MobDMC.TYPE_SOURCE          = 'MOB'  
  --On recupère les attributs de résiliation Internet :
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_RESINT ResInt
    On    RefIdSoft.EXTERNAL_ORDER_ID = ResInt.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ResInt.ORDER_DEPOSIT_DT
  --Amélioration du calcul des IMSI et résiliation :
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_IMSI ResMOBImsi
    On    RefIdSoft.EXTERNAL_ORDER_ID = ResMOBImsi.EXTERNAL_ORDER_ID
      And RefIdSoft.ORDER_DEPOSIT_DT  = ResMOBImsi.ORDER_DEPOSIT_DT
  --- Indicateur IOBSP
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
    On  Coalesce(OrgO3.EDO_ID,Socle.EDO_ID)  =   EdoOBK.EDO_ID
      And RefIdSoft.ORDER_DEPOSIT_DT                            >=  EdoOBK.START_VAL_AXS_DT
      And EdoOBK.VAL_AXS_CLSSF_ID                               In ('${P_PIL_163}') --(ORANGEBANK)
      And EdoOBK.CURRENT_IN                                     =   1 
  Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
    On Socle.AGENT_ID             =   CuidOBK.AGENT_ID 
      AND Socle.ORDER_DEPOSIT_DT  >=  CuidOBK.HABILL_BEGIN_DT 
      AND Socle.ORDER_DEPOSIT_DT  <   Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
  -- On va chercher l'enrichissement 6PO pour Myshop
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_MOB_6PO SPO_MSH
    On    Socle.EXTERNAL_ORDER_ID   =   SPO_MSH.EXTERNAL_ORDER_ID_SANS_33G
      And Socle.DISTRBTN_CHANNL_ID  =   'SCC'
      And Socle.ORDER_DEPOSIT_DT    =   SPO_MSH.ORDR_CREATN_DT
      And SPO_MSH.TYPE_PF           =   '${P_PIL_630}'
--On va chercher l'enrichissement 6PO pour Nemo (MyShopDOM)
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_MOB_6PO SPO_NEMO
    On    Socle.EXTERNAL_ORDER_ID           =   SPO_NEMO.EXTERNAL_ORDER_ID
      And Socle.DISTRBTN_CHANNL_ID          =   'SCC'
      And Socle.ORDER_DEPOSIT_DT            =   SPO_NEMO.ORDR_CREATN_DT
      And SPO_NEMO.TYPE_PF                  =   '${P_PIL_631}'
Where
  Socle.FRESH_IN=1
  Qualify Row_number() over (Partition By Socle.ACTE_ID, Socle.ORDER_DEPOSIT_DT Order By Socle.ORDER_DEPOSIT_TS asc)=1
;
.if errorcode <> 0 then .quit 1




Collect stat on ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_C_MOB;
.if errorcode <> 0 then .quit 1

.quit 0




