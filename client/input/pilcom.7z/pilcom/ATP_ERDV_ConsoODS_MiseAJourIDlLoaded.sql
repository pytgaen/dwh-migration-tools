-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_ConsoODS_MiseAJourIDlLoaded.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de Mise à jour du flag complétude ODS
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 17/12/2014      YZH         Creation
--------------------------------------------------------------------------------


--On met à jour la table ODS pour dire que les Data bien été Traité
Update TabToUp
From
   ${DatabaseODS}.ORD_O_ORDER_ERDV_COM TabToUp,
   ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD RefId
Set
  ORDER_COMPLETED_IN=1
Where
  (1=1)
  And TabToUp.MSG_ID = RefId.MSG_ID
;
.if errorcode <> 0 then .quit 1


