-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_GEN_Alimentation_CommandePSF_Step3_PSF_REFCOM_OA.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/04/2014      HFO         Creation
-- 22/01/2015      HFO         MODIFICATION
-- 23/01/2015      HFO         Mise en norme suite Patch  G13R00C22P01 correction Post MEP S052015
-- 02/07/2015       GMA         Modification Pour ajouter le Delete Insert En MS
--------------------------------------------------------------------------------

.set width 2500;
--Creation table des OA

CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA
(
  ORDR_ID                           BIGINT                                   NOT NULL      ,
  TYPE_ORDR_CD                      VARCHAR(4)                                             ,
  STAT_MVT                          VARCHAR(2)                                             ,
  COMPST_OFFR_ID                    VARCHAR(13)                                            ,
  ATOMIC_OFFR_ID                    VARCHAR(60)                                            ,
  FUNCTN_ID                         VARCHAR(15)                                            ,
  FUNCTN_VALUE_ID                   VARCHAR(18)                                            ,
  ORDR_DT                           DATE FORMAT 'YYYY/MM/DD'                               ,
  ACCES_SERVICE_ID                  BIGINT                                                 ,
  PRODUCT_TYPE                      VARCHAR(4)                                             ,
  INST_PROD_DT                      DATE FORMAT 'YYYY/MM/DD'                               ,
  START_DT                          DATE FORMAT 'YYYY/MM/DD'                               ,
  END_DT                            DATE FORMAT 'YYYY/MM/DD'                                
)
PRIMARY INDEX ( ORDR_ID , COMPST_OFFR_ID, ATOMIC_OFFR_ID) 
ON COMMIT PRESERVE ROWS
;
.if errorcode <> 0 then .quit 1


--Etape 1 : On alimente les OA


Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA
(
  ORDR_ID                 ,
  TYPE_ORDR_CD            ,
  STAT_MVT                ,
  COMPST_OFFR_ID          ,
  ATOMIC_OFFR_ID          ,
  FUNCTN_ID               ,
  FUNCTN_VALUE_ID         ,
  ORDR_DT                 ,
  ACCES_SERVICE_ID        ,
  PRODUCT_TYPE            ,
  INST_PROD_DT            ,
  START_DT                ,
  END_DT                   
)

Select 
  Tmp.ORDR_ID                                                                     As ORDR_ID                ,
  Case  When Tmp.TYPE_ORDR_CD='INI' And Tmp.OLD_COMPST_OFFR_ID Is Not Null
          Then 'A'
        When Tmp.TYPE_ORDR_CD='INI' And Tmp.OLD_COMPST_OFFR_ID Is Null
          Then 'M'
        When Tmp.TYPE_ORDR_CD='ADD'
          Then 'A'
        When Tmp.TYPE_ORDR_CD='RMV'
          Then 'S'
        Else Tmp.TYPE_ORDR_CD
  End                                                                             As TYPE_ORDR_CD           ,
  Tmp.STAT_MVT                                                                    As STAT_MVT               ,
  Case  When Tmp.TYPE_ORDR_CD='RMV' And Tmp.OLD_COMPST_OFFR_ID Is Not Null
          Then Tmp.OLD_COMPST_OFFR_ID
        Else Tmp.COMPST_OFFR_ID
  End                                                                             As COMPST_OFFR_ID         ,
  Tmp.ATOMIC_OFFR_ID                                                              AS ATOMIC_OFFR_ID         ,
  Tmp.FUNCTN_ID                                                                   As FUNCTN_ID              ,
  Tmp.FUNCTN_VALUE_ID                                                             As FUNCTN_VALUE_ID        ,
  Tmp.ORDR_DT                                                                     As ORDR_DT                ,
  Tmp.ACCES_SERVICE_ID                                                            As ACCES_SERVICE_ID       ,
  Tmp.PRODUCT_TYPE                                                                As PRODUCT_TYPE           ,
  Tmp.INST_PROD_DT                                                                As INST_PROD_DT           ,
  Tmp.START_DT                                                                    As START_DT               ,
  Tmp.END_DT                                                                      As END_DT                  

From
(
  Select
    Cmd.ORDR_ID                                                                   As ORDR_ID                ,
    Case  When Count(Distinct CmdLc.ORDR_LINE_ACT_CD) = 1 And Max (CmdLc.ORDR_LINE_ACT_CD) In ('CHG','MIG')
            Then 'INI'
          When Count(Distinct CmdLc.ORDR_LINE_ACT_CD)= 1 
            Then Max (CmdLc.ORDR_LINE_ACT_CD)
          Else 'INI'
    End                                                                           As TYPE_ORDR_CD           ,
    --Calcul du mouvement
    Cmd.STATT_CD                                                                  As STAT_MVT               ,
    Cmd.COMPST_OFFR_RPS_ID                                                        As COMPST_OFFR_ID         ,
    Cmd.OLD_COMPST_OFFR_RPS_ID                                                    As OLD_COMPST_OFFR_ID     ,
    CmdLc.PRODUCT_ID_RPS                                                          As ATOMIC_OFFR_ID         ,
    '-1'                                                                          As FUNCTN_ID              ,
    '-1'                                                                          As FUNCTN_VALUE_ID        ,
    Cmd.ORDR_DT                                                                   As ORDR_DT                ,
    Cmd.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID       ,
    'OA'                                                                          As PRODUCT_TYPE           ,
    CmdLc.INST_PROD_DT                                                              As INST_PROD_DT         ,
    CmdLc.START_DT                                                                  As START_DT             ,
    CmdLc.END_DT                                                                    As END_DT                
  From 
    ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD  Cmd 
    Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD CmdLc 
    On Cmd.Ordr_id=CmdLc.Ordr_id
  Where
    (1=1)
    And CmdLc.PRODUCT_ID_RPS is not Null
    And SubStr(Trim(CmdLc.PRODUCT_ID_RPS),1,2) Not In ('OC','GO')
  Group By 
    Cmd.ORDR_ID                 ,
    STAT_MVT                    ,
    Cmd.COMPST_OFFR_RPS_ID      ,
    Cmd.OLD_COMPST_OFFR_RPS_ID  ,
    CmdLc.PRODUCT_ID_RPS        ,
    Cmd.ORDR_DT                 ,
    Cmd.ACCES_SERVICE_ID        ,
    CmdLc.INST_PROD_DT          ,
    CmdLc.START_DT              ,
    CmdLc.END_DT                 
  ) Tmp


 ;Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA
(
  ORDR_ID                 ,
  TYPE_ORDR_CD            ,
  STAT_MVT                ,
  COMPST_OFFR_ID          ,
  ATOMIC_OFFR_ID          ,
  FUNCTN_ID               ,
  FUNCTN_VALUE_ID         ,
  ORDR_DT                 ,
  ACCES_SERVICE_ID        ,
  PRODUCT_TYPE            ,
  INST_PROD_DT            ,
  START_DT                ,
  END_DT                  
)

Select 
  Tmp.ORDR_ID                                                                     As ORDR_ID                ,
  'S'                                                                             AS TYPE_ORDR_CD           ,
  Tmp.STAT_MVT                                                                    As STAT_MVT               ,
  Tmp.OLD_COMPST_OFFR_ID                                                          As COMPST_OFFR_ID         ,
  Tmp.ATOMIC_OFFR_ID                                                              AS ATOMIC_OFFR_ID         ,
  Tmp.FUNCTN_ID                                                                   As FUNCTN_ID              ,
  Tmp.FUNCTN_VALUE_ID                                                             As FUNCTN_VALUE_ID,
  Tmp.ORDR_DT                                                                     As ORDR_DT                ,
  Tmp.ACCES_SERVICE_ID                                                            As ACCES_SERVICE_ID       ,
  Tmp.PRODUCT_TYPE                                                                As PRODUCT_TYPE           ,
  Tmp.INST_PROD_DT                                                                As INST_PROD_DT           ,
  Tmp.START_DT                                                                    As START_DT               ,
  Tmp.END_DT                                                                      As END_DT                  

From
  (
    Select
      Cmd.ORDR_ID                                                                 As ORDR_ID                ,
      Case  When Count(Distinct CmdLc.ORDR_LINE_ACT_CD) = 1 And Max (CmdLc.ORDR_LINE_ACT_CD)='CHG'
              Then 'INI'
            When Count(Distinct CmdLc.ORDR_LINE_ACT_CD)= 1 
              Then Max (CmdLc.ORDR_LINE_ACT_CD)
            Else 'INI'
      End                                                                         As TYPE_ORDR_CD           ,
    --Calcul du mouvement
      Cmd.STATT_CD                                                                As STAT_MVT               ,
      Cmd.COMPST_OFFR_RPS_ID                                                      As COMPST_OFFR_ID         ,
      Cmd.OLD_COMPST_OFFR_RPS_ID                                                  As OLD_COMPST_OFFR_ID     ,
      CmdLc.PRODUCT_ID_RPS                                                        As ATOMIC_OFFR_ID         ,
      '-1'                                                                        As FUNCTN_ID              ,
      '-1'                                                                        As FUNCTN_VALUE_ID        ,
      Cmd.ORDR_DT                                                                 As ORDR_DT                ,
      Cmd.ACCES_SERVICE_ID                                                        As ACCES_SERVICE_ID       ,
      'OA'                                                                        As PRODUCT_TYPE           ,
      CmdLc.INST_PROD_DT                                                            As INST_PROD_DT         ,
      CmdLc.START_DT                                                                As START_DT             ,
      CmdLc.END_DT                                                                  As END_DT                
    From 
      ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD  Cmd
      Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD CmdLc 
        On    Cmd.Ordr_id=CmdLc.Ordr_id
    Where
      (1=1)
      And Cmd.OLD_COMPST_OFFR_RPS_ID Is Not Null
      And CmdLc.ATTRIBUTE_RPS_ID is not Null
    Group By 
      Cmd.ORDR_ID                 ,
      Cmd.COMPST_OFFR_RPS_ID      ,
      Cmd.OLD_COMPST_OFFR_RPS_ID  ,
      STAT_MVT                    ,
      CmdLc.PRODUCT_ID_RPS        ,
      Cmd.ORDR_DT                 ,
      Cmd.ACCES_SERVICE_ID        ,
      CmdLc.INST_PROD_DT          ,
      CmdLc.START_DT              ,
      CmdLc.END_DT                 
  ) Tmp
  Where
    (1=1)
    --On ne gère que les INI
    And Tmp.TYPE_ORDR_CD='INI'
;
.if errorcode <> 0 then .quit 1;

--Calcul des statistiques
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1



CREATE Volatile TABLE ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA
(
  ACCES_SERVICE_ID                                      BIGINT                    ,
  ORDR_ID                                NOT NULL       BIGINT                    ,
  COMPST_OFFR_ID                         NOT NULL       VARCHAR(13)               ,
  ATOMIC_OFFR_ID                         NOT NULL       VARCHAR(60)               ,
  SEG_COM_ID                                            VARCHAR(64)               ,
  TYPE_SERVICE                                          VARCHAR(20)               ,
  TYPE_ORDR_CD                                          VARCHAR(4)                ,
  STAT_MVT                                              VARCHAR(2)                ,
  PRODUCT_TYPE                                          VARCHAR(4)                ,
  START_COMM_DT                                         DATE FORMAT 'YYYY/MM/DD'  ,
  END_COMM_DT                                           DATE FORMAT 'YYYY/MM/DD'  ,
  INST_PROD_DT                                          DATE FORMAT 'YYYY/MM/DD'  ,
  START_DT                                              DATE FORMAT 'YYYY/MM/DD'  ,
  END_DT                                                DATE FORMAT 'YYYY/MM/DD'  ,
  ORDR_DT                                               DATE FORMAT 'YYYY/MM/DD'   
)
PRIMARY INDEX ( ORDR_ID, COMPST_OFFR_ID , ATOMIC_OFFR_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


--Jointure des OA avec le catalogue, pour ressostir les segments 
  
Insert Into  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA
( 
  ACCES_SERVICE_ID                     ,
  ORDR_ID                              ,
  COMPST_OFFR_ID                       ,
  ATOMIC_OFFR_ID                       ,
  SEG_COM_ID                           ,
  TYPE_SERVICE                         ,
  TYPE_ORDR_CD                         ,
  STAT_MVT                             ,
  PRODUCT_TYPE                         ,
  START_COMM_DT                        ,
  END_COMM_DT                          ,
  INST_PROD_DT                         ,
  START_DT                             ,
  END_DT                               ,
  ORDR_DT                               
)
  
  Select
  CmdOA.ACCES_SERVICE_ID                                                                As ACCES_SERVICE_ID   ,
  CmdOA.ORDR_ID                                                                         As ORDR_ID            ,
  RefCatalogue.COMPST_OFFR_ID                                                           As COMPST_OFFR_ID     ,
  RefCatalogue.ATOMIC_OFFR_ID                                                           As ATOMIC_OFFR_ID     ,
  RefCatalogue.SEG_COM_ID                                                               As SEG_COM_ID         ,
  RefCatalogue.TYPE_SERVICE                                                             As TYPE_SERVICE       ,
  CmdOA.TYPE_ORDR_CD                                                                    As TYPE_ORDR_CD       ,
  CmdOA.STAT_MVT                                                                        As STAT_MVT           ,
  CmdOA.PRODUCT_TYPE                                                                    As PRODUCT_TYPE       ,
  RefCatalogue.START_COMM_DT                                                            As START_COMM_DT      ,
  RefCatalogue.END_COMM_DT                                                              As END_COMM_DT        ,
  CmdOA.INST_PROD_DT                                                                    As INST_PROD_DT       ,
  CmdOA.START_DT                                                                        As START_DT           ,
  CmdOA.END_DT                                                                          As END_DT             ,
  CmdOA.ORDR_DT                                                                         As ORDR_DT             
From
  ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA CmdOA
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_GEN_INT_CAT_RPS RefCatalogue
      On    CmdOA.COMPST_OFFR_ID = RefCatalogue.COMPST_OFFR_ID
      And  CmdOA.ATOMIC_OFFR_ID = RefCatalogue.ATOMIC_OFFR_ID
      --And RefCatalogue.ATOMIC_OFFR_ID= '-1'
       And RefCatalogue.FUNCTN_ID= '-1'
       And RefCatalogue.FUNCTN_VALUE_ID= '-1'
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1


--On supprime les maintiens
Delete from  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Where TYPE_ORDR_CD = 'M';
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1



CREATE Volatile TABLE ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS
(
  ORDR_ID                                NOT NULL       BIGINT      ,
  COMPST_OFFR_ID                         NOT NULL       VARCHAR(13) ,
  ATOMIC_OFFR_ID                         NOT NULL       VARCHAR(60) ,
  SEG_COM_ID                                            VARCHAR(64)  
  )
PRIMARY INDEX ( ORDR_ID, COMPST_OFFR_ID, ATOMIC_OFFR_ID)
On Commit Preserve Rows 
;
.if errorcode <> 0 then .quit 1

--On sélectionne les Ajout et suppression sur le même segment  pour suppresion
Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS
(
  ORDR_ID           ,
  COMPST_OFFR_ID    ,
  ATOMIC_OFFR_ID    ,
  SEG_COM_ID         
)
Select
  Distinct
  ORDR_ID           ,
  COMPST_OFFR_ID    ,
  ATOMIC_OFFR_ID    ,
  SEG_COM_ID         
From
   ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA CmdOA
Where 
  CmdOA.TYPE_ORDR_CD In ('A','S')
Qualify count(*) over (partition by   CmdOA.ORDR_ID,  CmdOA.SEG_COM_ID  )>1
;
.if errorcode <> 0 then .quit 1



Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1

--Suppression des ajout et suppression sur le même segement
Delete
From ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA  Tab1
Where exists
  (
    Select
      1
    From ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS  Tab2
    Where
      (1=1)
      And Tab1.ORDR_ID        = Tab2.ORDR_ID
      And Tab1.SEG_COM_ID     = Tab2.SEG_COM_ID
  )
;
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA Column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1





Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM;
.if errorcode <> 0 then .quit 1
Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE;
.if errorcode <> 0 then .quit 1

--Insertion dans le référentiel
Delete From ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE Where PRODUCT_TYPE='OA'
;Insert Into ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE
(
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
)
Select
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
From ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA refcomOA
Where
  (1=1)
  And refcomOA.TYPE_SERVICE in (${L_PIL_018})
  --And refcomOA.TYPE_SERVICE in ('OFFCONV', 'OFFINT', 'ACCRTC')
  --A Supp
  And refcomOA.SEG_COM_ID   Not Like 'RTC%'
;
.if errorcode <> 0 then .quit 1


Delete From ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM Where PRODUCT_TYPE='OA';
;Insert Into ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM
(
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
)
Select
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                 
From ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA
;
.if errorcode <> 0 then .quit 1

Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM;
.if errorcode <> 0 then .quit 1
Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE;
.if errorcode <> 0 then .quit 1

-- Vidage les tables Volatiles

Delete From ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_OA All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_OA All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_OA_AS All;
.if errorcode <> 0 then .quit 1