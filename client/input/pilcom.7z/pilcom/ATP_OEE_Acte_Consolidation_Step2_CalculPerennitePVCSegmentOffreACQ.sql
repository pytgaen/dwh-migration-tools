-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Acte_Consolidation_Step2_CalculPerennitePVCSegmentOffreACQ.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/11/2013      XKN         Creation
-- 27/03/2014      AID         Indus
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEG_OT All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEG_OT
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PAR_IMSI                ,
  SEG_COM_ID              ,
  TYPE_SERVICE            ,
  TYPE_COMMANDE           ,
  TYPE_OT_SO              
)
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.INT_DEPOSIT_DT                   as INT_DEPOSIT_DT         ,
  Acte.PAR_IMSI                         as PAR_IMSI               ,
  Acte.SEG_COM_ID                       as SEG_COM_ID             ,
  Acte.TYPE_SERVICE                     as TYPE_SERVICE           ,
  Acte.TYPE_COMMANDE                    as TYPE_COMMANDE          ,
  Acte.TYPE_OT_SO                       as TYPE_OT_SO             
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.INT_W_ACTE_OEE_EXRACT Acte
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID             Not In ('NS','OPTTECH','OPT_INC')
  And Acte.TYPE_OT_SO             in ('OT')
  And Acte.PAR_IMSI               Is Not Null
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEG_OT;
.if errorcode <> 0 then .quit 1



-------------------------------------------------------------------------------------------
--Step 2 :  On realise la recherche en parc sur le même segment pour gérer les livraisons
-------------------------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT (
  ACTE_ID                                         Bigint                  Not Null      ,
  INT_DEPOSIT_DT                                  Date Format 'YYYYMMDD'  Not Null      ,
  PAR_IMSI                                        Varchar(15)             Not Null      ,
  SEG_COM_ID                                      Varchar(64)                           ,
  TYPE_SERVICE                                    Varchar(20)                           ,
  REALZTN_DT                                      Date Format 'YYYYMMDD'                ,
  CANCELLNG_DT                                    Date Format 'YYYYMMDD'                ,
  INDIC_SEEK                                      Char(1)                               
)
Primary Index (
  PAR_IMSI
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Column(PAR_IMSI);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Column(INDIC_SEEK);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Column(CANCELLNG_DT);
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------------
----- Il y a 3 cas : 1 - Soit le segment trouvé est pérenne => INDIC_SEEK = P
-----                2 - Le Segment est retrouvé en parc mais Cloturé => INDIC_SEEK = S
-----                3 - Le Segment n'est pas retrouvé en parc => Pas Présent dans la table 
----------------------------------------------------------------------------------------------------

Insert into ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  PAR_IMSI              ,
  SEG_COM_ID            ,
  TYPE_SERVICE          ,
  REALZTN_DT            ,
  CANCELLNG_DT          ,
  INDIC_SEEK            
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.INT_DEPOSIT_DT          as INT_DEPOSIT_DT     ,
  Refid.PAR_IMSI                as PAR_IMSI           ,
  Refid.SEG_COM_ID              as SEG_COM_ID         ,
  Refid.TYPE_SERVICE            as TYPE_SERVICE       ,
  --On récupère les dates  D'entrée et fin de parc
  ParcSeg.PARC_BEGIN_DT         as REALZTN_DT         ,
  ParcSeg.PARC_END_DT           as CANCELLNG_DT       ,
  Case  When ParcSeg.PARC_END_DT = '29991231'
          --Dans le cas où le segment est Ouvert alors il est pérenne pas besoin de faire de nouvelle recherche
          Then  'P'
        Else    'S'
  End                           as INDIC_SEEK         
From
  ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEG_OT Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_OT ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  --On vérifie que le segment a bien été créé apres la commande
  And Refid.INT_DEPOSIT_DT  <= ParcSeg.PARC_BEGIN_DT
Qualify Row_Number() Over (Partition by Refid.ACTE_ID Order by ParcSeg.PARC_BEGIN_DT Asc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Column(PAR_IMSI);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Column(INDIC_SEEK);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Column(CANCELLNG_DT);
.if errorcode <> 0 then .quit 1

--Pour les lignes En "P" On peut s'arreter la 

-------------------------------------------------------------------------------------------
--Step 3 :  On realise une nouvelle recherche en parc si le segment est non pérenne dans le temps
--          Cas des lignes à S
-------------------------------------------------------------------------------------------



Create Volatile Table ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT (
  ACTE_ID                       Bigint                  Not Null      ,
  INT_DEPOSIT_DT                Date Format 'YYYYMMDD'  Not Null      ,
  PAR_IMSI                      Varchar(15)             Not Null      ,
  SEG_COM_ID                    Varchar(64)                           ,
  TYPE_SERVICE                  Varchar(20)                           ,
  SEG_COM_ID_FIND               Varchar(64)                           ,
  REALZTN_DT                    Date Format 'YYYYMMDD'                ,
  CANCELLNG_DT                  Date Format 'YYYYMMDD'                ,
  NB_DAY_IN_PARC_SEG            Integer                               ,
  SEG_COM_ID_NEXT               Varchar(64)                           ,
  DATE_IN_PARC_NEXT             Date Format 'YYYYMMDD'                ,
  NB_DAY_OUT_PARC_CUR_NEXT      Integer                               ,
  DATE_OUT_PARC_NEXT            Date Format 'YYYYMMDD'                ,
  DATE_IN_PARC_FINAL            Date Format 'YYYYMMDD'                ,
  DATE_OUT_PARC_FINAL           Date Format 'YYYYMMDD'                ,
  NB_IN_OUT_PARC                Integer                               ,
  NB_DAY_OUT_PARC               Integer                               ,
  DUREE_TOTAL                   Integer                               ,
  NB_DAY_PARC_TOTAL             Integer                               ,
  POURCENTAGE_PRES_PARC         Decimal(15,2)                         ,
  DEB_PERENNITE                 Date Format 'YYYYMMDD'                ,
  FIN_PERENNITE                 Date Format 'YYYYMMDD'                ,
  FIN_PER_SEG                   Varchar(64)                           ,
  FIN_LAST_SEG                  Varchar(64)                           
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT      Between Date '2008-01-01' And Date '2030-12-31' Each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT Column(INT_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT Column(PARTITION);
.if errorcode <> 0 then .quit 1



Insert into ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT
(
  ACTE_ID                       ,
  INT_DEPOSIT_DT                ,
  PAR_IMSI                      ,
  SEG_COM_ID                    ,
  TYPE_SERVICE                  ,
  SEG_COM_ID_FIND               ,
  REALZTN_DT                    ,
  CANCELLNG_DT                  ,
  NB_DAY_IN_PARC_SEG            ,
  SEG_COM_ID_NEXT               ,
  DATE_IN_PARC_NEXT             ,
  NB_DAY_OUT_PARC_CUR_NEXT      ,
  DATE_OUT_PARC_NEXT            ,
  DATE_IN_PARC_FINAL            ,
  DATE_OUT_PARC_FINAL           ,
  NB_IN_OUT_PARC                ,
  NB_DAY_OUT_PARC               ,
  DUREE_TOTAL                   ,
  NB_DAY_PARC_TOTAL             ,
  POURCENTAGE_PRES_PARC         ,
  DEB_PERENNITE                 ,
  FIN_PERENNITE                 ,
  FIN_PER_SEG                   ,
  FIN_LAST_SEG                  
)
Select
  CalculFinal.ACTE_ID                                                       as ACTE_ID                      ,
  CalculFinal.INT_DEPOSIT_DT                                                as INT_DEPOSIT_DT               ,
  CalculFinal.PAR_IMSI                                                      as PAR_IMSI                     ,
  CalculFinal.SEG_COM_ID                                                    as SEG_COM_ID                   ,
  CalculFinal.TYPE_SERVICE                                                  as TYPE_SERVICE                 ,
  --Date de début du segment en parc
  CalculFinal.SEG_COM_ID                                                    as SEG_COM_ID_FIND              ,
  CalculFinal.REALZTN_DT_SEG                                                as REALZTN_DT                   ,
  CalculFinal.CANCELLNG_DT_SEG                                              as CANCELLNG_DT                 ,
  CalculFinal.NB_DAY_IN_PARC_SEG                                            as NB_DAY_IN_PARC_SEG           ,
  --Date de début du next Segment en parc
  CalculFinal.SEG_COM_ID_NEXT                                               as SEG_COM_ID_NEXT              ,
  CalculFinal.REALZTN_DT                                                    as DATE_IN_PARC_NEXT            ,
  CalculFinal.NB_DAY_OUT_PARC_CUR_NEXT                                      as NB_DAY_OUT_PARC_CUR_NEXT     ,
  CalculFinal.CANCELLNG_DT                                                  as DATE_OUT_PARC_NEXT           ,
  CalculFinal.DATE_IN_PARC_FINAL                                            as DATE_IN_PARC_FINAL           ,
  CalculFinal.DATE_OUT_PARC_FINAL                                           as DATE_OUT_PARC_FINAL          ,
  CalculFinal.NB_IN_OUT_PARC                                                as NB_IN_OUT_PARC               ,
  CalculFinal.NB_DAY_OUT_PARC                                               as NB_DAY_OUT_PARC              ,
  CalculFinal.DUREE_TOTAL                                                   as DUREE_TOTAL                  ,
  CalculFinal.NB_DAY_PARC_TOTAL                                             as NB_DAY_PARC_TOTAL            ,
  CalculFinal.POURCENTAGE_PRES_PARC                                         as POURCENTAGE_PRES_PARC        ,
  CalculFinal.DEB_PERENNITE                                                 as DEB_PERENNITE                ,
  Coalesce( CalculFinal.FIN_PERENNITE,
            Cast('99991231' as date Format 'YYYYMMDD'))                     as FIN_PERENNITE                ,
  Coalesce( Max(CalculFinal.FIN_PER_SEG) Over (Partition by CalculFinal.ACTE_ID),
            CalculFinal.SEG_COM_ID)                                         as FIN_PER_SEG                  ,
  CalculFinal.FIN_LAST_SEG                                                  as FIN_LAST_SEG                 
From
  (
    Select
      Tmp.ACTE_ID                                                                     as ACTE_ID                  ,
      Tmp.INT_DEPOSIT_DT                                                              as INT_DEPOSIT_DT           ,
      Tmp.PAR_IMSI                                                                    as PAR_IMSI                 ,
      Tmp.SEG_COM_ID                                                                  as SEG_COM_ID               ,
      Tmp.TYPE_SERVICE                                                                as TYPE_SERVICE             ,
      Tmp.REALZTN_DT_SEG                                                              as REALZTN_DT_SEG           ,
      Tmp.CANCELLNG_DT_SEG                                                            as CANCELLNG_DT_SEG         ,
      Case  When Tmp.CANCELLNG_DT_SEG = '29991231'
              Then 999999
            Else (Tmp.CANCELLNG_DT_SEG - Tmp.REALZTN_DT_SEG)
      End                                                                             as NB_DAY_IN_PARC_SEG       ,
      Tmp.SEG_COM_ID_NEW                                                              as SEG_COM_ID_NEXT          ,
      Tmp.REALZTN_DT                                                                  as REALZTN_DT               ,
      Tmp.CANCELLNG_DT                                                                as CANCELLNG_DT             ,
      Case  When Tmp.CANCELLNG_DT = '29991231'
              Then 999999
            Else (Tmp.CANCELLNG_DT - Tmp.REALZTN_DT)
      End                                                                             as NB_DAY_IN_PARC           ,
      Tmp.DATE_IN_PARC_NEXT                                                           as DATE_IN_PARC_NEXT        ,
      Case  When Tmp.CANCELLNG_DT_SEG = '29991231'
              Then 999999
            Else (Tmp.REALZTN_DT - Tmp.CANCELLNG_DT_SEG)
      End                                                                             as NB_DAY_OUT_PARC_CUR_NEXT ,
      Tmp.DATE_OUT_PARC_NEXT                                                          as DATE_OUT_PARC_NEXT       ,
      Tmp.DATE_IN_PARC_FINAL                                                          as DATE_IN_PARC_FINAL       ,
      Tmp.DATE_OUT_PARC_FINAL                                                         as DATE_OUT_PARC_FINAL      ,
      --Indicateur le nombre de fois ou le client apres l'acte à fait une entrée sortie de parc
      Max(NUMBER_LINE)      Over (Partition by Tmp.ACTE_ID)                           as NB_IN_OUT_PARC           ,
      --Indicateur le nombre de jour que le client à passer out du parc
      Sum(NB_DAY_OUT_PARC_TMP)  Over (Partition by Tmp.ACTE_ID) + NB_OUT_PARC_FIRST   as NB_DAY_OUT_PARC          ,
      Case  When DATE_OUT_PARC_FINAL = '29991231'
              --Dans le cas de la valeur par défaut alors on met la date courrante
              Then (Current_date - Tmp.REALZTN_DT_SEG)
            When CANCELLNG_DT = '29991231'
              Then (Current_date - Tmp.REALZTN_DT_SEG)
              --Sinon on prend la date de fin de parc
            Else  (Coalesce(Tmp.DATE_OUT_PARC_FINAL,Tmp.CANCELLNG_DT,Tmp.CANCELLNG_DT_SEG)  - Tmp.REALZTN_DT_SEG)
      End                                                                             as DUREE_TOTAL              ,
      (DUREE_TOTAL - NB_DAY_OUT_PARC)                                                 as NB_DAY_PARC_TOTAL        ,
      Case  When DUREE_TOTAL = 0
              Then 0
            Else  Cast(NB_DAY_PARC_TOTAL as decimal(15,2))*100 / DUREE_TOTAL
      End                                                                             as POURCENTAGE_PRES_PARC    ,
      Min(DEB_PERENNITE)  Over (Partition by Tmp.ACTE_ID)                             as DEB_PERENNITE            ,
      Max(FIN_PERENNITE)   Over (Partition by Tmp.ACTE_ID)                            as FIN_PERENNITE            ,
      Case  When PERENNITE_F='P' And NUMBER_LINE = Max(NUMBER_LINE_F) Over (  Partition by  Tmp.ACTE_ID   order by    Tmp.NUMBER_LINE asc )
              Then Tmp.SEG_COM_ID_NEXT
            Else Null
      End                                                                             as FIN_PER_SEG              ,
      Max(Tmp.LAST_SEG_FIND)   Over (Partition by Tmp.ACTE_ID)                        as FIN_LAST_SEG             ,
      Tmp.NUMBER_LINE                                                                 as NUMBER_LINE              
    From
    (
        Select
          TmpCalc.ACTE_ID                 as ACTE_ID            ,
          TmpCalc.INT_DEPOSIT_DT          as INT_DEPOSIT_DT     ,
          TmpCalc.PAR_IMSI                as PAR_IMSI           ,
          TmpCalc.SEG_COM_ID              as SEG_COM_ID         ,
          TmpCalc.TYPE_SERVICE            as TYPE_SERVICE       ,
          TmpCalc.REALZTN_DT_SEG          as REALZTN_DT_SEG     ,
          TmpCalc.CANCELLNG_DT_SEG        as CANCELLNG_DT_SEG   ,
          TmpCalc.SEG_COM_ID_NEW          as SEG_COM_ID_NEW     ,
          TmpCalc.REALZTN_DT              as REALZTN_DT         ,
          TmpCalc.CANCELLNG_DT            as CANCELLNG_DT       ,
          --On calcule ici si la pérennité lors du 1er volet est possible
          Max(TmpCalc.PER_SEG_NEXT) Over (  Partition by  TmpCalc.ACTE_ID   
                                    )     as PER_SEG_NEXT_F     ,
          TmpCalc.NB_OUT_PARC_FIRST       as NB_OUT_PARC_FIRST  ,
          TmpCalc.FIRST_IN_PARK           as FIRST_IN_PARK      ,
          TmpCalc.DATE_IN_PARC_NEXT       as DATE_IN_PARC_NEXT  ,
          TmpCalc.NB_DAY_OUT_PARC_TMP     as NB_DAY_OUT_PARC_TMP,
          TmpCalc.DATE_OUT_PARC_NEXT      as DATE_OUT_PARC_NEXT ,
          TmpCalc.DATE_IN_PARC_FINAL      as DATE_IN_PARC_FINAL ,
          TmpCalc.DATE_OUT_PARC_FINAL     as DATE_OUT_PARC_FINAL,
          TmpCalc.NUMBER_LINE             as NUMBER_LINE        ,
          TmpCalc.PERENNITE               as PERENNITE          ,
          --Ici si une fois on a eu N dans les lignes précédantes alors on ne calcule plus
          Min(TmpCalc.PERENNITE) Over (  Partition by  TmpCalc.ACTE_ID           
                                          order by    TmpCalc.NUMBER_LINE asc Rows Unbounded Preceding
                                      )   as PERENNITE_F  ,
          --Calcul des indicateurs de date de début et fin sur le segment
          Case  When Coalesce(PER_SEG_NEXT_F,'-1') <> 'P'
                  Then TmpCalc.REALZTN_DT_SEG
                When PERENNITE_F  ='P'
                  Then TmpCalc.REALZTN_DT_SEG
                Else Null
          End                             as DEB_PERENNITE      ,
          Case  When Coalesce(PER_SEG_NEXT_F,'-1') <> 'P'
                  Then TmpCalc.CANCELLNG_DT_SEG
                When PERENNITE_F  = 'P'
                  Then DATE_OUT_PARC_NEXT
                Else Null
          End                             as FIN_PERENNITE      ,
          --Calcul des indicateurs  sur le segment :
          Case  When Coalesce(PER_SEG_NEXT_F,'-1') <> 'P'
                  Then 1
                When PERENNITE_F='P'
                  Then NUMBER_LINE
                Else Null
          End                             as NUMBER_LINE_F       ,
          Case  When Coalesce(PER_SEG_NEXT_F,'-1') <> 'P'
                  Then TmpCalc.SEG_COM_ID
                When PERENNITE_F='P'
                  Then TmpCalc.SEG_COM_ID_NEW
                Else Null
          End                             as SEG_COM_ID_NEXT     ,
          --Dernier Segment Trouvé en parc :
          Case  When NUMBER_LINE = Max(NUMBER_LINE) Over (  Partition by  ACTE_ID           
                                                            order by    TmpCalc.NUMBER_LINE asc
                                                         )
                  Then TmpCalc.SEG_COM_ID_NEW
                Else Null
          End                             as LAST_SEG_FIND      
        From
          (
            Select
              Refid.ACTE_ID                 as ACTE_ID            ,
              Refid.INT_DEPOSIT_DT          as INT_DEPOSIT_DT     ,
              Refid.PAR_IMSI                as PAR_IMSI           ,
              Refid.SEG_COM_ID              as SEG_COM_ID         ,
              Refid.TYPE_SERVICE            as TYPE_SERVICE       ,
              Refid.REALZTN_DT              as REALZTN_DT_SEG     ,
              Refid.CANCELLNG_DT            as CANCELLNG_DT_SEG   ,
              --On récupère les dates  D'entrée et fin de parc
              ParcSeg.SEG_COM_ID            as SEG_COM_ID_NEW     ,
              ParcSeg.PARC_BEGIN_DT         as REALZTN_DT         ,
              ParcSeg.PARC_END_DT           as CANCELLNG_DT       ,
              --On récupère la date de la 1ere entrée en parc
              Min(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    ACTE_ID           
                                                        order by    ParcSeg.PARC_BEGIN_DT asc
                                             )          as FIRST_IN_PARK,
              ---------
              --On qualifie Ici si les Segments sont éligibles ou non (On a continuité à +1 jour) Et si sa Commercialisation > Date de saisie
              Case  When   ---
                              NUMBER_LINE = 1
                        And   (FIRST_IN_PARK - Refid.CANCELLNG_DT) <= 1 
                        And   Refid.INT_DEPOSIT_DT      < ParcSeg.COM_BEGIN_DT
                      Then  'P'
                    When      NUMBER_LINE = 1
                      Then  'N'
                    Else    Null
              End                                       as PER_SEG_NEXT             ,
              (FIRST_IN_PARK - Refid.CANCELLNG_DT)      as NB_OUT_PARC_FIRST        ,
              --------------------------------------------
              --On récupère la date de réentré en parc suivant :
              Max(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    Refid.ACTE_ID           
                                                  order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                              )         as DATE_IN_PARC_NEXT  ,
              --On calcul le nombre de jour entre la date de fin de parc et sa réentré en parc
              Case  When DATE_IN_PARC_NEXT is Not Null And ParcSeg.PARC_END_DT is Not Null
                      Then (DATE_IN_PARC_NEXT - ParcSeg.PARC_END_DT)
                    Else 0
              End                                       as NB_DAY_OUT_PARC_TMP  ,
              Max(ParcSeg.PARC_END_DT) Over  (  Partition by    Refid.ACTE_ID           
                                                     order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                              )         as DATE_OUT_PARC_NEXT   ,
              --Calcul de la Date de Début de commercialisation dde prestation Suivante :
              Max(ParcSeg.COM_BEGIN_DT) Over  (  Partition by    ACTE_ID           
                                             order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                      )         as DATE_PREST_START_COM_NEXT  ,
             --Calcul Du segment Suivant
              Max(ParcSeg.SEG_COM_ID) Over  (  Partition by    ACTE_ID           
                                             order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                      )         as SEG_COM_ID_NEXT  ,
              Max(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    Refid.ACTE_ID           
                                                  order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 Following and Unbounded Following
                                            )           as DATE_IN_PARC_FINAL   ,
              Max(ParcSeg.PARC_END_DT) Over (  Partition by  Refid.ACTE_ID           
                                                  order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 Following and Unbounded Following
                                            )           as DATE_OUT_PARC_FINAL  ,
              --Numéro de ligne :
              Row_Number()              Over (  Partition by Refid.ACTE_ID
                                                  Order by ParcSeg.PARC_BEGIN_DT asc
                                             )          as NUMBER_LINE          ,
              --On test si on peut Fusionner car il y a pérennité :
              Case  When 
                            NB_DAY_OUT_PARC_TMP <= 1 
                        And DATE_PREST_START_COM_NEXT >= FIRST_IN_PARK
                      Then  'P'
                    Else    'N'
              End                                       as PERENNITE            
            From
              ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT Refid
              Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_OT ParcSeg
                On    Refid.PAR_IMSI                 = ParcSeg.DOSSIER_NU_IMSI
            Where
              (1=1)
              And Refid.CANCELLNG_DT      <=  ParcSeg.PARC_BEGIN_DT
              And Refid.REALZTN_DT        <   ParcSeg.PARC_BEGIN_DT
              And Refid.INDIC_SEEK        =   'S'
          )TmpCalc
      )Tmp
    Where
      (1=1)
  )CalculFinal
Where
  (1=1)
Qualify CalculFinal.NUMBER_LINE=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT Column(INT_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT Column(PARTITION);
.if errorcode <> 0 then .quit 1





--------------------------------------------------------------------------------------------------------------------
-- Step 4 : On va rechercher des infos dans le parc pour les Lignes où l'on à pas trouvé de segment :
--------------------------------------------------------------------------------------------------------------------


Create Volatile Table ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT (
  ACTE_ID                       Bigint                  Not Null      ,
  INT_DEPOSIT_DT                Date Format 'YYYYMMDD'  Not Null      ,
  PAR_IMSI                      Varchar(15)                           ,
  SEG_COM_ID                    Varchar(64)                           ,
  TYPE_SERVICE                  Varchar(20)                           ,
  SEG_COM_ID_FIND               Varchar(64)                           ,
  REALZTN_DT                    Date Format 'YYYYMMDD'                ,
  CANCELLNG_DT                  Date Format 'YYYYMMDD'                ,
  NB_DAY_IN_PARC_SEG            Integer                               ,
  SEG_COM_ID_NEXT               Varchar(64)                           ,
  DATE_IN_PARC_NEXT             Date Format 'YYYYMMDD'                ,
  NB_DAY_OUT_PARC_CUR_NEXT      Integer                               ,
  DATE_OUT_PARC_NEXT            Date Format 'YYYYMMDD'                ,
  DATE_IN_PARC_FINAL            Date Format 'YYYYMMDD'                ,
  DATE_OUT_PARC_FINAL           Date Format 'YYYYMMDD'                ,
  NB_IN_OUT_PARC                Integer                               ,
  NB_DAY_OUT_PARC               Integer                               ,
  DUREE_TOTAL                   Integer                               ,
  NB_DAY_PARC_TOTAL             Integer                               ,
  POURCENTAGE_PRES_PARC         Decimal(15,2)                         ,
  DEB_PERENNITE                 Date Format 'YYYYMMDD'                ,
  FIN_PERENNITE                 Date Format 'YYYYMMDD'                ,
  FIN_PER_SEG                   Varchar(64)                           ,
  FIN_LAST_SEG                  Varchar(64)                           
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT      Between Date '2008-01-01' And Date '2030-12-31' Each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT Column(INT_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT Column(PARTITION);
.if errorcode <> 0 then .quit 1


Insert into ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PAR_IMSI                    ,
  SEG_COM_ID                  ,
  TYPE_SERVICE                ,
  SEG_COM_ID_FIND             ,
  REALZTN_DT                  ,
  CANCELLNG_DT                ,
  NB_DAY_IN_PARC_SEG          ,
  DATE_IN_PARC_NEXT           ,
  NB_DAY_OUT_PARC_CUR_NEXT    ,
  DATE_OUT_PARC_NEXT          ,
  DATE_IN_PARC_FINAL          ,
  DATE_OUT_PARC_FINAL         ,
  NB_IN_OUT_PARC              ,
  NB_DAY_OUT_PARC             ,
  DUREE_TOTAL                 ,
  NB_DAY_PARC_TOTAL           ,
  POURCENTAGE_PRES_PARC       ,
  DEB_PERENNITE               ,
  FIN_PERENNITE               ,
  FIN_PER_SEG                 ,
  FIN_LAST_SEG                
)
Select
  CalculFinal.ACTE_ID                                                       as ACTE_ID                      ,
  CalculFinal.INT_DEPOSIT_DT                                                as INT_DEPOSIT_DT               ,
  CalculFinal.PAR_IMSI                                                      as PAR_IMSI                     ,
  CalculFinal.SEG_COM_ID                                                    as SEG_COM_ID                   ,
  CalculFinal.TYPE_SERVICE                                                  as TYPE_SERVICE                 ,
  CalculFinal.SEG_COM_ID_FIND                                               as SEG_COM_ID_FIND              ,
  CalculFinal.REALZTN_DT                                                    as REALZTN_DT                   ,
  CalculFinal.CANCELLNG_DT                                                  as CANCELLNG_DT                 ,
  CalculFinal.NB_DAY_IN_PARC                                                as NB_DAY_IN_PARC_SEG           ,
  CalculFinal.DATE_IN_PARC_NEXT                                             as DATE_IN_PARC_NEXT            ,
  CalculFinal.NB_DAY_OUT_PARC_CUR_NEXT                                      as NB_DAY_OUT_PARC_CUR_NEXT     ,
  CalculFinal.DATE_OUT_PARC_NEXT                                            as DATE_OUT_PARC_NEXT           ,
  CalculFinal.DATE_IN_PARC_FINAL                                            as DATE_IN_PARC_FINAL           ,
  CalculFinal.DATE_OUT_PARC_FINAL                                           as DATE_OUT_PARC_FINAL          ,
  CalculFinal.NB_IN_OUT_PARC                                                as NB_IN_OUT_PARC               ,
  CalculFinal.NB_DAY_OUT_PARC                                               as NB_DAY_OUT_PARC              ,
  CalculFinal.DUREE_TOTAL                                                   as DUREE_TOTAL                  ,
  CalculFinal.NB_DAY_PARC_TOTAL                                             as NB_DAY_PARC_TOTAL            ,
  CalculFinal.POURCENTAGE_PRES_PARC                                         as POURCENTAGE_PRES_PARC        ,
  CalculFinal.DEB_PERENNITE                                                 as DEB_PERENNITE                ,
  CalculFinal.FIN_PERENNITE                                                 as FIN_PERENNITE                ,
  max(CalculFinal.FIN_PER_SEG) Over (Partition by CalculFinal.ACTE_ID)      as FIN_PER_SEG                  ,
  CalculFinal.FIN_LAST_SEG                                                  as FIN_LAST_SEG                 
From
  (
    Select
      Tmp.ACTE_ID                                                                 as ACTE_ID                  ,
      Tmp.INT_DEPOSIT_DT                                                          as INT_DEPOSIT_DT           ,
      Tmp.PAR_IMSI                                                                as PAR_IMSI                 ,
      Tmp.SEG_COM_ID                                                              as SEG_COM_ID               ,
      Tmp.TYPE_SERVICE                                                            as TYPE_SERVICE             ,
      Tmp.SEG_COM_ID_FIND                                                         as SEG_COM_ID_FIND          ,
      Tmp.REALZTN_DT                                                              as REALZTN_DT               ,
      Tmp.CANCELLNG_DT                                                            as CANCELLNG_DT             ,
      Case  When Tmp.CANCELLNG_DT = '29991231'
              Then 999999
            Else (Tmp.CANCELLNG_DT - Tmp.REALZTN_DT)
      End                                                                         as NB_DAY_IN_PARC           ,
      Tmp.DATE_IN_PARC_NEXT                                                       as DATE_IN_PARC_NEXT        ,
      Tmp.NB_DAY_OUT_PARC_TMP                                                     as NB_DAY_OUT_PARC_CUR_NEXT ,
      Tmp.DATE_OUT_PARC_NEXT                                                      as DATE_OUT_PARC_NEXT       ,
      Tmp.DATE_IN_PARC_FINAL                                                      as DATE_IN_PARC_FINAL       ,
      Tmp.DATE_OUT_PARC_FINAL                                                     as DATE_OUT_PARC_FINAL      ,
      --Indicateur le nombre de fois ou le client apres l'acte à fait une entrée sortie de parc
      Max(NUMBER_LINE)      Over (Partition by Tmp.ACTE_ID)                       as NB_IN_OUT_PARC           ,
      --Indicateur le nombre de jour que le client à passer out du parc
      Sum(NB_DAY_OUT_PARC_TMP)  Over (Partition by Tmp.ACTE_ID)                   as NB_DAY_OUT_PARC          ,
      Case  When DATE_OUT_PARC_FINAL = '29991231'
              --Dans le cas de la valeur par défaut alors on met la date courrante
              Then (Current_date - Tmp.REALZTN_DT)
              --Sinon on prend la date de fin de parc
            Else  (Coalesce(Tmp.DATE_OUT_PARC_FINAL,Tmp.CANCELLNG_DT)  - Tmp.REALZTN_DT)
      End                                                                         as DUREE_TOTAL              ,
      (DUREE_TOTAL - NB_DAY_OUT_PARC)                                             as NB_DAY_PARC_TOTAL        ,
      Case  When DUREE_TOTAL = 0
              Then 0
            Else  Cast(NB_DAY_PARC_TOTAL as decimal(15,2))*100 / DUREE_TOTAL
      End                                                                         as POURCENTAGE_PRES_PARC    ,
      Min(DEB_PERENNITE)  Over (Partition by Tmp.ACTE_ID)                         as DEB_PERENNITE            ,
      Max(FIN_PERENNITE)   Over (Partition by Tmp.ACTE_ID)                        as FIN_PERENNITE            ,
      Case  When PERENNITE_F='P' And NUMBER_LINE = Max(NUMBER_LINE_F) Over (  Partition by  Tmp.ACTE_ID   order by    Tmp.NUMBER_LINE asc )
              Then Tmp.SEG_COM_ID_NEXT
            Else Null
      End                                                                         as FIN_PER_SEG              ,
      Max(Tmp.LAST_SEG_FIND)   Over (Partition by Tmp.ACTE_ID)                    as FIN_LAST_SEG             ,
      Tmp.NUMBER_LINE                                                             as NUMBER_LINE              
    From
    (
        Select
          TmpCalc.ACTE_ID                 as ACTE_ID            ,
          TmpCalc.INT_DEPOSIT_DT          as INT_DEPOSIT_DT     ,
          TmpCalc.PAR_IMSI                as PAR_IMSI           ,
          TmpCalc.SEG_COM_ID              as SEG_COM_ID         ,
          TmpCalc.TYPE_SERVICE            as TYPE_SERVICE       ,
          TmpCalc.SEG_COM_ID_FIND         as SEG_COM_ID_FIND    ,
          TmpCalc.REALZTN_DT              as REALZTN_DT         ,
          TmpCalc.CANCELLNG_DT            as CANCELLNG_DT       ,
          TmpCalc.FIRST_IN_PARK           as FIRST_IN_PARK      ,
          TmpCalc.DATE_IN_PARC_NEXT       as DATE_IN_PARC_NEXT  ,
          TmpCalc.NB_DAY_OUT_PARC_TMP     as NB_DAY_OUT_PARC_TMP,
          TmpCalc.DATE_OUT_PARC_NEXT      as DATE_OUT_PARC_NEXT ,
          TmpCalc.DATE_IN_PARC_FINAL      as DATE_IN_PARC_FINAL ,
          TmpCalc.DATE_OUT_PARC_FINAL     as DATE_OUT_PARC_FINAL,
          TmpCalc.NUMBER_LINE             as NUMBER_LINE        ,
          TmpCalc.PERENNITE               as PERENNITE          ,
          --Ici si une fois on a eu N dans les lignes précédantes alors on ne calcule plus
          Min(TmpCalc.PERENNITE) Over (  Partition by  TmpCalc.ACTE_ID           
                                          order by    TmpCalc.NUMBER_LINE asc Rows Unbounded Preceding
                                      )   as PERENNITE_F  ,
          --Calcul des indicateurs de date de début et fin sur le segment
          Case  When PERENNITE_F='P'
                  Then REALZTN_DT 
                Else Null
          End                             as DEB_PERENNITE      ,
          Case  When PERENNITE_F='P'
                  Then DATE_OUT_PARC_NEXT 
                Else Null
          End                             as FIN_PERENNITE      ,
          --Calcul des indicateurs  sur le segment :
          Case  When PERENNITE_F='P'
                  Then NUMBER_LINE
                Else Null
          End                             as NUMBER_LINE_F       ,
          Case  When PERENNITE_F='P'
                  Then TmpCalc.SEG_COM_ID_NEXT 
                Else Null
          End                             as SEG_COM_ID_NEXT     ,
          --Dernier Segment Trouvé en parc :
          Case  When NUMBER_LINE = Max(NUMBER_LINE) Over (  Partition by  ACTE_ID           
                                                            order by    TmpCalc.NUMBER_LINE asc
                                                         )
                  Then TmpCalc.SEG_COM_ID_FIND
                Else Null
          End                             as LAST_SEG_FIND      
        From
          (
            Select
              Refid.ACTE_ID                 as ACTE_ID            ,
              Refid.INT_DEPOSIT_DT          as INT_DEPOSIT_DT     ,
              Refid.PAR_IMSI                as PAR_IMSI           ,
              Refid.SEG_COM_ID              as SEG_COM_ID         ,
              Refid.TYPE_SERVICE            as TYPE_SERVICE       ,
              --On récupère les dates  D'entrée et fin de parc
              ParcSeg.SEG_COM_ID            as SEG_COM_ID_FIND    ,
              ParcSeg.PARC_BEGIN_DT         as REALZTN_DT         ,
              ParcSeg.PARC_END_DT           as CANCELLNG_DT       ,
              --On récupère la date de la 1ere entrée en parc
              Min(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    ACTE_ID           
                                              order by    ParcSeg.PARC_BEGIN_DT asc
                                             )          as FIRST_IN_PARK,
              --On récupère la date de réentré en parc suivant :
              Max(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    Refid.ACTE_ID           
                                                  order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                              )         as DATE_IN_PARC_NEXT  ,
              --On calcul le nombre de jour entre la date de fin de parc et sa réentré en parc
              Case  When DATE_IN_PARC_NEXT is Not Null And ParcSeg.PARC_END_DT is Not Null
                      Then (DATE_IN_PARC_NEXT - ParcSeg.PARC_END_DT)
                    Else 0
              End                                       as NB_DAY_OUT_PARC_TMP  ,
              Max(ParcSeg.PARC_END_DT) Over  (  Partition by    Refid.ACTE_ID           
                                                     order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                              )         as DATE_OUT_PARC_NEXT   ,
              --Calcul de la Date de Début de commercialisation dde prestation Suivante :
              Max(ParcSeg.COM_BEGIN_DT) Over  (  Partition by    ACTE_ID           
                                             order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                      )         as DATE_PREST_START_COM_NEXT  ,
             --Calcul Du segment Suivant
              Max(ParcSeg.SEG_COM_ID) Over  (  Partition by    ACTE_ID           
                                             order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                      )         as SEG_COM_ID_NEXT  ,
              Max(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    Refid.ACTE_ID           
                                                  order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 Following and Unbounded Following
                                            )           as DATE_IN_PARC_FINAL   ,
              Max(ParcSeg.PARC_END_DT) Over (  Partition by  Refid.ACTE_ID           
                                                  order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 Following and Unbounded Following
                                            )           as DATE_OUT_PARC_FINAL  ,
              --Numéro de ligne :
              Row_Number()              Over (  Partition by Refid.ACTE_ID
                                                  Order by ParcSeg.PARC_BEGIN_DT asc
                                             )          as NUMBER_LINE          ,
              --On test si on peut Fusionner car il y a pérennité :
              Case  When NB_DAY_OUT_PARC_TMP <= 1 And DATE_PREST_START_COM_NEXT >= FIRST_IN_PARK
                      Then  'P'
                    Else    'N'
              End                                       as PERENNITE            ,
              --On recherche ici Si c'est non pérenne alors on alimente pas le segment
              Case  When  PERENNITE ='N'
                      Then  Refid.SEG_COM_ID
                    Else Null
              End                                       as SEG_PER              
            From
              ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEG_OT Refid
              Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_OT ParcSeg
                On    Refid.PAR_IMSI                        = ParcSeg.DOSSIER_NU_IMSI
            Where
              (1=1)
              And Not Exists
              (
                Select
                  1
                From
                  ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT RefFind
                Where
                  (1=1)
                  And RefFind.ACTE_ID    =  Refid.ACTE_ID
              )
              And Refid.INT_DEPOSIT_DT           <=  ParcSeg.PARC_BEGIN_DT
              And Refid.INT_DEPOSIT_DT           >= '20130401'
          )TmpCalc
      )Tmp
    Where
      (1=1)
  )CalculFinal
Where
  (1=1)
Qualify CalculFinal.NUMBER_LINE=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT Column(INT_DEPOSIT_DT);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT Column(PARTITION);
.if errorcode <> 0 then .quit 1

--------------------------------------------------------------------------------------------------------------------
-- Step 5 : On Fusionne l'ensemble des lignes :
--------------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ All;
.if errorcode <> 0 then .quit 1




--On insert les lignes réouvertes
Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ
(
  ACTE_ID                         ,
  INT_DEPOSIT_DT                  ,
  PAR_IMSI                        ,
  SEG_COM_ID                      ,
  TYPE_SERVICE                    ,
  SEG_COM_ID_FIND                 ,
  REALZTN_DT                      ,
  CANCELLNG_DT                    ,
  NB_DAY_IN_PARC_SEG              ,
  SEG_COM_ID_NEXT                 ,
  DATE_IN_PARC_NEXT               ,
  NB_DAY_OUT_PARC_CUR_NEXT        ,
  DATE_OUT_PARC_NEXT              ,
  DATE_IN_PARC_FINAL              ,
  DATE_OUT_PARC_FINAL             ,
  NB_IN_OUT_PARC                  ,
  NB_DAY_OUT_PARC                 ,
  DUREE_TOTAL                     ,
  NB_DAY_PARC_TOTAL               ,
  POURCENTAGE_PRES_PARC           ,
  DEB_PERENNITE                   ,
  FIN_PERENNITE                   ,
  FIN_PER_SEG                     ,
  FIN_LAST_SEG                    ,
  TYPE_ENRI                       
)
Select
  ReOp.ACTE_ID                        as ACTE_ID                        ,
  ReOp.INT_DEPOSIT_DT                 as INT_DEPOSIT_DT                 ,
  ReOp.PAR_IMSI                       as PAR_IMSI                       ,
  ReOp.SEG_COM_ID                     as SEG_COM_ID                     ,
  ReOp.TYPE_SERVICE                   as TYPE_SERVICE                   ,
  ReOp.SEG_COM_ID_FIND                as SEG_COM_ID_FIND                ,
  ReOp.REALZTN_DT                     as REALZTN_DT                     ,
  ReOp.CANCELLNG_DT                   as CANCELLNG_DT                   ,
  ReOp.NB_DAY_IN_PARC_SEG             as NB_DAY_IN_PARC_SEG             ,
  ReOp.SEG_COM_ID_NEXT                as SEG_COM_ID_NEXT                ,
  ReOp.DATE_IN_PARC_NEXT              as DATE_IN_PARC_NEXT              ,
  ReOp.NB_DAY_OUT_PARC_CUR_NEXT       as NB_DAY_OUT_PARC_CUR_NEXT       ,
  ReOp.DATE_OUT_PARC_NEXT             as DATE_OUT_PARC_NEXT             ,
  ReOp.DATE_IN_PARC_FINAL             as DATE_IN_PARC_FINAL             ,
  ReOp.DATE_OUT_PARC_FINAL            as DATE_OUT_PARC_FINAL            ,
  ReOp.NB_IN_OUT_PARC                 as NB_IN_OUT_PARC                 ,
  ReOp.NB_DAY_OUT_PARC                as NB_DAY_OUT_PARC                ,
  ReOp.DUREE_TOTAL                    as DUREE_TOTAL                    ,
  ReOp.NB_DAY_PARC_TOTAL              as NB_DAY_PARC_TOTAL              ,
  ReOp.POURCENTAGE_PRES_PARC          as POURCENTAGE_PRES_PARC          ,
  ReOp.DEB_PERENNITE                  as DEB_PERENNITE                  ,
  ReOp.FIN_PERENNITE                  as FIN_PERENNITE                  ,
  ReOp.FIN_PER_SEG                    as FIN_PER_SEG                    ,
  ReOp.FIN_LAST_SEG                   as FIN_LAST_SEG                   ,
  'R'                                 as TYPE_ENRI                      
From
  ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_REOPEN_OT ReOp
;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ;
.if errorcode <> 0 then .quit 1

--On insert les lignes pérennes non existante par la suite
Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ
(
  ACTE_ID                         ,
  INT_DEPOSIT_DT                  ,
  PAR_IMSI                        ,
  SEG_COM_ID                      ,
  TYPE_SERVICE                    ,
  SEG_COM_ID_FIND                 ,
  REALZTN_DT                      ,
  CANCELLNG_DT                    ,
  NB_DAY_IN_PARC_SEG              ,
  SEG_COM_ID_NEXT                 ,
  DATE_IN_PARC_NEXT               ,
  NB_DAY_OUT_PARC_CUR_NEXT        ,
  DATE_OUT_PARC_NEXT              ,
  DATE_IN_PARC_FINAL              ,
  DATE_OUT_PARC_FINAL             ,
  NB_IN_OUT_PARC                  ,
  NB_DAY_OUT_PARC                 ,
  DUREE_TOTAL                     ,
  NB_DAY_PARC_TOTAL               ,
  POURCENTAGE_PRES_PARC           ,
  DEB_PERENNITE                   ,
  FIN_PERENNITE                   ,
  FIN_PER_SEG                     ,
  FIN_LAST_SEG                    ,
  TYPE_ENRI                       
)
Select
  PerI.ACTE_ID                        as ACTE_ID                        ,
  PerI.INT_DEPOSIT_DT                 as INT_DEPOSIT_DT                 ,
  PerI.PAR_IMSI                       as PAR_IMSI                       ,
  PerI.SEG_COM_ID                     as SEG_COM_ID                     ,
  PerI.TYPE_SERVICE                   as TYPE_SERVICE                   ,
  PerI.SEG_COM_ID                     as SEG_COM_ID_FIND                ,
  PerI.REALZTN_DT                     as REALZTN_DT                     ,
  PerI.CANCELLNG_DT                   as CANCELLNG_DT                   ,
  Case  When  PerI.CANCELLNG_DT = '29991231'
          Then  999999
        Else (PerI.CANCELLNG_DT - PerI.REALZTN_DT)
  End                                 as NB_DAY_IN_PARC_SEG             ,
  Null                                as SEG_COM_ID_NEXT                ,
  Null                                as DATE_IN_PARC_NEXT              ,
  Null                                as NB_DAY_OUT_PARC_CUR_NEXT       ,
  Null                                as DATE_OUT_PARC_NEXT             ,
  Null                                as DATE_IN_PARC_FINAL             ,
  Null                                as DATE_OUT_PARC_FINAL            ,
  1                                   as NB_IN_OUT_PARC                 ,
  0                                   as NB_DAY_OUT_PARC                ,
  Case  When PerI.CANCELLNG_DT = '29991231'
          Then Current_Date - PerI.REALZTN_DT
        Else (PerI.CANCELLNG_DT - PerI.REALZTN_DT)
  End                                 as DUREE_TOTAL                    ,
  Case  When PerI.CANCELLNG_DT = '29991231'
          Then Current_Date - PerI.REALZTN_DT
        Else (PerI.CANCELLNG_DT - PerI.REALZTN_DT)
  End                                 as NB_DAY_PARC_TOTAL              ,
  100                                 as POURCENTAGE_PRES_PARC          ,
  PerI.REALZTN_DT                     as DEB_PERENNITE                  ,
  PerI.CANCELLNG_DT                   as FIN_PERENNITE                  ,
  PerI.SEG_COM_ID                     as FIN_PER_SEG                    ,
  PerI.SEG_COM_ID                     as FIN_LAST_SEG                   ,
  'S'                                 as TYPE_ENRI                      
From
  ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_OT PerI
Where
  (1=1)
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ RefId
      Where
        (1=1)
        And   PerI.ACTE_ID            = RefId.ACTE_ID
        And   PerI.INT_DEPOSIT_DT     = RefId.INT_DEPOSIT_DT
    )
;
.if errorcode <> 0 then .quit 1


Collect Stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ;
.if errorcode <> 0 then .quit 1

--On insert les lignes non livrées sur le segment mais on a trouvé apres un produit
Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ
(
  ACTE_ID                         ,
  INT_DEPOSIT_DT                  ,
  PAR_IMSI                        ,
  SEG_COM_ID                      ,
  TYPE_SERVICE                    ,
  SEG_COM_ID_FIND                 ,
  REALZTN_DT                      ,
  CANCELLNG_DT                    ,
  NB_DAY_IN_PARC_SEG              ,
  SEG_COM_ID_NEXT                 ,
  DATE_IN_PARC_NEXT               ,
  NB_DAY_OUT_PARC_CUR_NEXT        ,
  DATE_OUT_PARC_NEXT              ,
  DATE_IN_PARC_FINAL              ,
  DATE_OUT_PARC_FINAL             ,
  NB_IN_OUT_PARC                  ,
  NB_DAY_OUT_PARC                 ,
  DUREE_TOTAL                     ,
  NB_DAY_PARC_TOTAL               ,
  POURCENTAGE_PRES_PARC           ,
  DEB_PERENNITE                   ,
  FIN_PERENNITE                   ,
  FIN_PER_SEG                     ,
  FIN_LAST_SEG                    ,
  TYPE_ENRI                       
)
Select
  NoLi.ACTE_ID                        as ACTE_ID                        ,
  NoLi.INT_DEPOSIT_DT                 as INT_DEPOSIT_DT                 ,
  NoLi.PAR_IMSI                       as PAR_IMSI                       ,
  NoLi.SEG_COM_ID                     as SEG_COM_ID                     ,
  NoLi.TYPE_SERVICE                   as TYPE_SERVICE                   ,
  NoLi.SEG_COM_ID_FIND                as SEG_COM_ID_FIND                ,
  NoLi.REALZTN_DT                     as REALZTN_DT                     ,
  NoLi.CANCELLNG_DT                   as CANCELLNG_DT                   ,
  NoLi.NB_DAY_IN_PARC_SEG             as NB_DAY_IN_PARC_SEG             ,
  NoLi.SEG_COM_ID_NEXT                as SEG_COM_ID_NEXT                ,
  NoLi.DATE_IN_PARC_NEXT              as DATE_IN_PARC_NEXT              ,
  NoLi.NB_DAY_OUT_PARC_CUR_NEXT       as NB_DAY_OUT_PARC_CUR_NEXT       ,
  NoLi.DATE_OUT_PARC_NEXT             as DATE_OUT_PARC_NEXT             ,
  NoLi.DATE_IN_PARC_FINAL             as DATE_IN_PARC_FINAL             ,
  NoLi.DATE_OUT_PARC_FINAL            as DATE_OUT_PARC_FINAL            ,
  NoLi.NB_IN_OUT_PARC                 as NB_IN_OUT_PARC                 ,
  NoLi.NB_DAY_OUT_PARC                as NB_DAY_OUT_PARC                ,
  NoLi.DUREE_TOTAL                    as DUREE_TOTAL                    ,
  NoLi.NB_DAY_PARC_TOTAL              as NB_DAY_PARC_TOTAL              ,
  NoLi.POURCENTAGE_PRES_PARC          as POURCENTAGE_PRES_PARC          ,
  NoLi.DEB_PERENNITE                  as DEB_PERENNITE                  ,
  NoLi.FIN_PERENNITE                  as FIN_PERENNITE                  ,
  NoLi.FIN_PER_SEG                    as FIN_PER_SEG                    ,
  NoLi.FIN_LAST_SEG                   as FIN_LAST_SEG                   ,
  'B'                                 as TYPE_ENRI                      
From
  ${KNB_TERADATA_USER}.INT_V_OEE_PER_SEG_NOLIVR_OT NoLi
;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ;
.if errorcode <> 0 then .quit 1


--On insert les lignes dont on a rien trouvé :

Insert into ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ
(
  ACTE_ID                         ,
  INT_DEPOSIT_DT                  ,
  PAR_IMSI                        ,
  SEG_COM_ID                      ,
  TYPE_SERVICE                    ,
  SEG_COM_ID_FIND                 ,
  REALZTN_DT                      ,
  CANCELLNG_DT                    ,
  NB_DAY_IN_PARC_SEG              ,
  SEG_COM_ID_NEXT                 ,
  DATE_IN_PARC_NEXT               ,
  NB_DAY_OUT_PARC_CUR_NEXT        ,
  DATE_OUT_PARC_NEXT              ,
  DATE_IN_PARC_FINAL              ,
  DATE_OUT_PARC_FINAL             ,
  NB_IN_OUT_PARC                  ,
  NB_DAY_OUT_PARC                 ,
  DUREE_TOTAL                     ,
  NB_DAY_PARC_TOTAL               ,
  POURCENTAGE_PRES_PARC           ,
  DEB_PERENNITE                   ,
  FIN_PERENNITE                   ,
  FIN_PER_SEG                     ,
  FIN_LAST_SEG                    ,
  TYPE_ENRI                       
)
Select
  LiId.ACTE_ID                        as ACTE_ID                        ,
  LiId.INT_DEPOSIT_DT                 as INT_DEPOSIT_DT                 ,
  LiId.PAR_IMSI                       as PAR_IMSI                       ,
  LiId.SEG_COM_ID                     as SEG_COM_ID                     ,
  LiId.TYPE_SERVICE                   as TYPE_SERVICE                   ,
  Null                                as SEG_COM_ID_FIND                ,
  Null                                as REALZTN_DT                     ,
  Null                                as CANCELLNG_DT                   ,
  Null                                as NB_DAY_IN_PARC_SEG             ,
  Null                                as SEG_COM_ID_NEXT                ,
  Null                                as DATE_IN_PARC_NEXT              ,
  Null                                as NB_DAY_OUT_PARC_CUR_NEXT       ,
  Null                                as DATE_OUT_PARC_NEXT             ,
  Null                                as DATE_IN_PARC_FINAL             ,
  Null                                as DATE_OUT_PARC_FINAL            ,
  Null                                as NB_IN_OUT_PARC                 ,
  Null                                as NB_DAY_OUT_PARC                ,
  Null                                as DUREE_TOTAL                    ,
  Null                                as NB_DAY_PARC_TOTAL              ,
  Null                                as POURCENTAGE_PRES_PARC          ,
  Null                                as DEB_PERENNITE                  ,
  Null                                as FIN_PERENNITE                  ,
  Null                                as FIN_PER_SEG                    ,
  Null                                as FIN_LAST_SEG                   ,
  'N'                                 as TYPE_ENRI                      
From
  ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEEK_SEG_OT LiId
Where
  (1=1)
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ RefId
      Where
        (1=1)
        And   LiId.ACTE_ID            = RefId.ACTE_ID
        And   LiId.INT_DEPOSIT_DT     = RefId.INT_DEPOSIT_DT
    )
;
.if errorcode <> 0 then .quit 1


Collect Stat on ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_OT_ACQ;
.if errorcode <> 0 then .quit 1





.quit 0


