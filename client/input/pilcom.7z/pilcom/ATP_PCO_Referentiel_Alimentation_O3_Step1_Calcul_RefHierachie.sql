-- $HEADER: mm2pco/current/sql/ATP_PCO_Referentiel_Alimentation_O3_Step1_Calcul_RefHierachie.sql 13_05#2 20-DEC-2016 16:15:09 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_Referentiel_Alimentation_O3_Step1_Calcul_RefHierachie.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul de la hierachie d'un EDO
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


--Delete :
-----------------------------
Delete from ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_TYPE_EDO all;
.if ErrorCode <> 0 Then .Quit 1;

Insert into ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_TYPE_EDO
(
  EDO_ID                ,
  LIBEL_EDO_NIV1        ,
  EDO_ID_NIV2           ,
  LIBEL_EDO_NIV2        ,
  OPEN_DT_NIV2          ,
  CLOSE_DT_NIV2         ,
  START_LINK_DT_NIV2    ,
  END_LINK_DT_NIV2      ,
  EDO_ID_NIV3           ,
  LIBEL_EDO_NIV3        ,
  OPEN_DT_NIV3          ,
  CLOSE_DT_NIV3         ,
  START_LINK_DT_NIV3    ,
  END_LINK_DT_NIV3      
)
Select
  Niv1.EDO_ID                                                                     as EDO_ID             ,
  Niv1.EDO_DS                                                                     as LIBEL_EDO_NIV1     ,
  Niv2.EDO_ID                                                                     as EDO_ID_NIV2        ,
  Niv2.EDO_DS                                                                     as LIBEL_EDO_NIV2     ,
  Niv2.OPEN_DT                                                                    as OPEN_DT_NIV2       ,
  Coalesce(Niv2.CLOSE_DT, Cast('31/12/9999' As Date Format 'DD/MM/YYYY'))         as CLOSE_DT_NIV2      ,
  Ln2.START_LINK_DT                                                               as START_LINK_DT_NIV2 ,
  Coalesce( Ln2.END_LINK_DT, Cast('31/12/9999' As Date Format 'DD/MM/YYYY'))      as END_LINK_DT_NIV2   ,
  Niv3.EDO_ID                                                                     as EDO_ID_NIV3        ,
  Niv3.EDO_DS                                                                     as LIBEL_EDO_NIV3     ,
  Niv3.OPEN_DT                                                                    as OPEN_DT_NIV3       ,
  Coalesce(Niv3.CLOSE_DT, Cast('31/12/9999' As Date Format 'DD/MM/YYYY'))         as CLOSE_DT_NIV3      ,
  Ln3.START_LINK_DT                                                               as START_LINK_DT_NIV3 ,
  Coalesce( Ln3.END_LINK_DT, Cast('31/12/9999' As Date Format 'DD/MM/YYYY'))      as END_LINK_DT_NIV3   
From
  ${KNB_SOC_O3}.V_ORG_F_EDO Niv1
  Inner Join ${KNB_SOC_O3}.V_ORG_F_LINK_EDO Ln2
    On    Niv1.EDO_ID       = Ln2.EDO_ID
      And Ln2.ROL_LINK_CD   = 'HIR'
      And Ln2.CURRENT_IN    = 1
      And Ln2.CLOSURE_DT    Is Null
  Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO Niv2
    On  Ln2.EDO_FATHR_ID    = Niv2.EDO_ID
      And Niv2.CURRENT_IN   = 1
      And Niv2.CLOSURE_DT   Is Null
  Inner Join ${KNB_SOC_O3}.V_ORG_F_LINK_EDO Ln3
    On    Niv2.EDO_ID       = Ln3.EDO_ID
      And Ln3.ROL_LINK_CD   = 'HIR'
      And Ln3.CURRENT_IN    = 1
      And Ln3.CLOSURE_DT    Is Null
  Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO Niv3
    On  Ln3.EDO_FATHR_ID    = Niv3.EDO_ID
      And Niv3.CURRENT_IN   = 1
      And Niv3.CLOSURE_DT   Is Null
Where
  (1=1)
  And Niv1.CURRENT_IN   = 1
  And Niv1.CLOSURE_DT   Is Null
;
.if ErrorCode <> 0 Then .Quit 1;

----------------


--On collecte les stats sur la table 
Collect Stat On ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_TYPE_EDO;
.if ErrorCode <> 0 Then .Quit 1;


.quit 0


