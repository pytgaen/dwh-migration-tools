-- $HEADER: mm2pco/current/sql/ATP_ETASK_Referentiel_Alimentation_Step2_EnrichissementO3.sql 13_05#12 13-AVR-2017 08:51:24 FQJR5800
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ETASK_Referentiel_Alimentation_Step2_EnrichissementO3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  Recadrage ORGA 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 10/04/2015      MDE         Creation
-- 27/05/2016      MDE         Evol : ETASK AD/SC
-- 13/02/2017      HOB         Correctif:Calcul du Canal pour des boutiques SS agents
-- 10/04/2017      JCR         Modif: ajout restriction dans le quickwin priorité SC QC 1641
--------------------------------------------------------------------------------

.set width 2500;
     
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3 All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP  AD                                                ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3  
(
  EXTERNAL_ORDER_ID          ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  DISTRBTN_CHANNL_ID         ,
  STORE_NM                   ,
  ACTIVITY                   ,
  FLAG_PLT_CONV_NB           ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_TYPE_PTN_NTK          ,
  FLAG_PLT_SCH_IN            ,
  FLAG_AD_SC                 
)
Select
  ETK.EXTERNAL_ORDER_ID                   AS EXTERNAL_ORDER_ID                       ,
  ETK.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT                        ,
  ORG.CUID                                AS AGENT_ID                                ,
  ORG.EDO_ID                              As EDO_ID                                  ,
  ORG.TYPE_EDO                            As TYPE_EDO_ID                             ,
  ORG.DISTRBTN_CHANNL_ID                  As DISTRBTN_CHANNL_ID                      ,
  ORG.STORE_NM                            As STORE_NM                                ,
  ORG.ACTIVITY                            As ACTIVITY                                ,
  ORG.FLAG_PLT_CONV_NB                    As FLAG_PLT_CONV_NB                        ,
  ORG.FLAG_TYPE_GEO_CD                    As FLAG_TYPE_GEO_CD                        ,
  ORG.FLAG_TYPE_CPT_NTK_NU                As FLAG_TYPE_CPT_NTK                       ,
  ORG.NETWRK_TYP_EDO_ID                   As NETWRK_TYP_EDO_ID                       ,
  Case  When Substr(ETK.STORE_NM, 3, 3)='MOB'
          Then 'MobiStore'
        When Substr(ETK.STORE_NM, 3, 3)='PHS'
          Then 'GDT'
  End                                      As FLAG_TYPE_PTN_NTK                      ,
  NULL                                     As FLAG_PLT_SCH_IN                        ,
  1                                        As FLAG_AD_SC 
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK As ETK
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_AD_EDO As ORG
        On    ETK.AGENT_ID      =   ORG.CUID
        And ETK.ORDER_DEPOSIT_TS      >=  ORG.DT_DEBUT
        And ETK.ORDER_DEPOSIT_TS      <=   ORG.DT_FIN
Where
    (1=1)
    And ORG.EDO_ID Is Not Null
-- Verification qu’il n’y a rien dans le QW SC avec une date de debut posterieure au QW AD 
    And Not Exists ( 
        Select 
        1 
        From ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORGSC
        where  ETK.AGENT_ID              =     ORGSC.CUID
        And ETK.ORDER_DEPOSIT_TS      >=    ORGSC.DT_DEBUT
        And ETK.ORDER_DEPOSIT_TS      <=    ORGSC.DT_FIN
        And ORGSC.DT_DEBUT            >     ORG.DT_DEBUT
    )
Qualify Row_number() over (Partition by ETK.EXTERNAL_ORDER_ID,ETK.ORDER_DEPOSIT_DT Order By  ORG.DT_DEBUT Desc, ORG.EDO_ID Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 3 : Alimentation de la table TMP  SC                                                ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3  
(
  EXTERNAL_ORDER_ID          ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  DISTRBTN_CHANNL_ID         ,
  STORE_NM                   ,
  ACTIVITY                   ,
  FLAG_PLT_SCH_IN            ,
  FLAG_PLT_CONV_NB           ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_TYPE_PTN_NTK          ,
  PRIO                       ,
  FLAG_AD_SC                 
)
Select
  ETK.EXTERNAL_ORDER_ID                   AS EXTERNAL_ORDER_ID         ,
  ETK.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT          ,
  ORG.CUID                                AS AGENT_ID                  ,
  ORG.EDO_ID_EQUI_RAT                     As EDO_ID                    ,
  ORG.FLAG_HIER_EQUI_RAT                  As TYPE_EDO_ID               ,
  NULL                                    As DISTRBTN_CHANNL_ID        ,
  NULL                                    As STORE_NM                  , 
  NULL                                    As ACTIVITY                  ,
  ORG.FLAG_SCH_EQUI_RAT                   As FLAG_PLT_SCH_IN           ,
  ORG.FLAG_PLT_CONV_EQUI_RAT              As FLAG_PLT_CONV_NB          ,
  NULL                                    As FLAG_TYPE_GEO_CD          ,
  NULL                                    As FLAG_TYPE_CPT_NTK         ,
  NULL                                    As NETWRK_TYP_EDO_ID         ,
  NULL                                    As FLAG_TYPE_PTN_NTK         ,
  Case  When ORG.SOURCE = 'MCRM'
          Then 1
        When ORG.SOURCE = 'POCC'
          Then 2
        When ORG.SOURCE = 'HRF'
          Then 3
        When ORG.SOURCE = 'RFOR'
          Then 4
        When ORG.SOURCE = 'EDL'
          Then 5
        When ORG.SOURCE = 'OEE'
          Then 6
        Else 7
  End                                     As PRIO                    ,
    0                                     As FLAG_AD_SC              
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK As ETK
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORG
        On    ETK.AGENT_ID      =   ORG.CUID
        And ETK.ORDER_DEPOSIT_TS      >=  ORG.DT_DEBUT
        And ETK.ORDER_DEPOSIT_TS      <=   ORG.DT_FIN
Where
   (1=1)
  And ORG.EDO_ID_EQUI_RAT Is Not Null
  And 
  not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3 AD
       where    
         ETK.EXTERNAL_ORDER_ID=AD.EXTERNAL_ORDER_ID
      )
Qualify Row_number() over (Partition by ETK.EXTERNAL_ORDER_ID,ETK.ORDER_DEPOSIT_DT Order By PRIO Asc , ORG.DT_DEBUT Desc, ORG.EDO_ID_EQUI_RAT Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 5 : Alimentation de la table TMP /Calcul Indicateurs 
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3
(
  EXTERNAL_ORDER_ID          ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  DISTRBTN_CHANNL_ID         ,
  ACTIVITY                   ,
  STORE_NM                   ,
  FLAG_PLT_CONV_NB           ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_TYPE_PTN_NTK          ,
  FLAG_PLT_SCH_IN            ,
  FLAG_AD_SC                 
)

Select
  RefId.EXTERNAL_ORDER_ID                                                  AS EXTERNAL_ORDER_ID                       ,
  Cast(RefId.ORDER_DEPOSIT_DT as DATE FORMAT 'YYYYMMDD')                   AS ORDER_DEPOSIT_DT                        ,
  RefId.AGENT_ID                                                           AS AGENT_ID                                ,
  RefO3.EDO_ID                                                             As EDO_ID                                  ,
  RefO3.TYPE_EDO                                                           As TYPE_EDO_ID                             ,
  CanalEdo.DISTRBTN_CHANNL_ID                                              As DISTRBTN_CHANNL_ID                      ,
  NULL                                                                     As ACTIVITY                                ,
  RefId.STORE_NM                                                           As STORE_NM                                ,
  Case When CanalConv.EDO_ID is not Null 
     Then 1 
    Else 0
  End                                                                      As FLAG_PLT_CONV_NB                        ,
  RefO3.FLAG_TYPE_GEO                                                      As FLAG_TYPE_GEO_CD                        ,
  RefO3.FLAG_TYPE_CPT_NTK                                                  As FLAG_TYPE_CPT_NTK                       ,
  RefO3.NETWRK_TYP_EDO_ID                                                  As NETWRK_TYP_EDO_ID                       ,
  RefO3.FLAG_TYPE_PTN_NTK                                                  As FLAG_TYPE_PTN_NTK                       ,
  Case When CanalSCH.EDO_ID is not Null 
     Then 1 
    Else 0  
  End                                                                     As FLAG_PLT_SCH_IN                         ,
  Case
    When CanalPAP.EDO_ID is not Null then '4'
    When RefO3.FLAG_PLT_AD = 1 Then '2'
    When RefO3.FLAG_PLT_AD = 0 Then '3'
    Else Null
  End                                                                      As FLAG_AD_SC
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK_1 As RefId
  Inner Join ${KNB_PCO_TMP}.CAT_W_NSH_REFO3_JOUR As RefO3
        On RefId.STORE_NM =  RefO3.EXTNL_VAL_COD_CD  
        And RefId.ORDER_DEPOSIT_DT    Between RefO3.START_EXTNL_VAL_DT And Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Left Outer Join
    (
      Select
        EDO_ID                As  EDO_ID                                   ,
        VAL_AXS_CLSSF_ID      As DISTRBTN_CHANNL_ID                         
             From
           ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
       Where
                 (1=1)
                 And EdoAx.FRESH_IN              = 1
                 And EdoAx.CURRENT_IN            = 1
                 And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By VAL_AXS_CLSSF_ID Asc)=1
      ) CanalEdo
      On  RefO3.EDO_ID   = CanalEdo.EDO_ID
  Left Outer Join
    (
      Select
        EDO_ID                As  EDO_ID                                   
             From
           ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
       Where
         (1=1)
         And EdoAx.VAL_AXS_CLSSF_ID = 'PAP'
         And EdoAx.FRESH_IN              = 1
         And EdoAx.CURRENT_IN            = 1
         And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By VAL_AXS_CLSSF_ID Asc)=1
      ) CanalPAP
      On  RefO3.EDO_ID   = CanalPAP.EDO_ID
  Left Outer Join
    (
      Select
        EDO_ID                As  EDO_ID                                   
             From
           ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
       Where
         (1=1)
         And EdoAx.VAL_AXS_CLSSF_ID in ('SOSH','OPEN')
         And EdoAx.FRESH_IN              = 1
         And EdoAx.CURRENT_IN            = 1
         And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By VAL_AXS_CLSSF_ID Asc)=1
      ) CanalConv
      On  RefO3.EDO_ID   = CanalConv.EDO_ID
  Left Outer Join
    (
      Select
        EDO_ID                As  EDO_ID                                   
             From
           ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
       Where
         (1=1)
         And EdoAx.VAL_AXS_CLSSF_ID in ('GSCR','1014')
         And EdoAx.FRESH_IN              = 1
         And EdoAx.CURRENT_IN            = 1
         And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By VAL_AXS_CLSSF_ID Asc)=1
      ) CanalSCH
      On  RefO3.EDO_ID   = CanalSCH.EDO_ID
 Where
   (1=1)
    And Not Exists
    (
      
      Select
        1
      From
        ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3 O3
      Where
         RefId.EXTERNAL_ORDER_ID=O3.EXTERNAL_ORDER_ID
         And O3.FLAG_AD_SC Is not   Null	
     
      )
				And RefID.STORE_NM NOT LIKE 'PDV%'
                           
  Qualify Row_Number() Over(Partition by RefId.EXTERNAL_ORDER_ID,RefId.ORDER_DEPOSIT_DT
                          Order by      RefO3.START_EXTNL_VAL_DT Desc                                 ,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc )=1                         
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 6 : Alimentation de la table -> ONline pour calcul Hier                          ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3  
(
  EXTERNAL_ORDER_ID          ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     
)
Select
  ETK.EXTERNAL_ORDER_ID                   AS EXTERNAL_ORDER_ID         ,
  ETK.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT          ,
  Null                                    AS AGENT_ID                  ,
  ETK.EDO_ID                              As EDO_ID                    
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK As ETK
 Where
   (1=1)
  And  ETK.EDO_ID is Not  null 
  And 
  not  exists (
    sel 1
     from   ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3 O3
       where    
         ETK.EXTERNAL_ORDER_ID=O3.EXTERNAL_ORDER_ID
      )
Qualify Row_number() over (Partition by ETK.EXTERNAL_ORDER_ID,ETK.ORDER_DEPOSIT_DT Order By ETK.ORDER_DEPOSIT_TS asc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 7 : Delete de la table TMP    Calcul Hier                                        ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_HIER_O3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 8 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_HIER_O3 
(
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_DT            ,
  AGENT_ID                    ,
  UNIFIED_SHOP_CD             ,
  ORG_TEAM_LEVEL_1_CD         ,
  ORG_TEAM_LEVEL_1_DS         ,
  ORG_TEAM_LEVEL_2_CD         ,
  ORG_TEAM_LEVEL_2_DS         ,
  ORG_TEAM_LEVEL_3_CD         ,
  ORG_TEAM_LEVEL_3_DS         ,
  ORG_TEAM_LEVEL_4_CD         ,
  ORG_TEAM_LEVEL_4_DS         ,
  WORK_TEAM_LEVEL_1_CD        ,
  WORK_TEAM_LEVEL_1_DS        ,
  WORK_TEAM_LEVEL_2_CD        ,
  WORK_TEAM_LEVEL_2_DS        ,
  WORK_TEAM_LEVEL_3_CD        ,
  WORK_TEAM_LEVEL_3_DS        ,
  WORK_TEAM_LEVEL_4_CD        ,
  WORK_TEAM_LEVEL_4_DS

)
Select
  ETK.EXTERNAL_ORDER_ID                     AS EXTERNAL_ORDER_ID           ,
  ETK.ORDER_DEPOSIT_DT                      AS ORDER_DEPOSIT_DT            ,
  ETK.AGENT_ID                              As AGENT_ID                    ,
  RefPDV.EXTNL_VAL_COD_CD                   As UNIFIED_SHOP_CD             ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As ORG_TEAM_LEVEL_1_CD         ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As ORG_TEAM_LEVEL_1_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As ORG_TEAM_LEVEL_2_CD         ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As ORG_TEAM_LEVEL_2_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As ORG_TEAM_LEVEL_3_CD         ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As ORG_TEAM_LEVEL_3_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As ORG_TEAM_LEVEL_4_CD         ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As ORG_TEAM_LEVEL_4_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As WORK_TEAM_LEVEL_1_CD        ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As WORK_TEAM_LEVEL_1_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As WORK_TEAM_LEVEL_2_CD        ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As WORK_TEAM_LEVEL_2_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As WORK_TEAM_LEVEL_3_CD        ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As WORK_TEAM_LEVEL_3_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As WORK_TEAM_LEVEL_4_CD        ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As WORK_TEAM_LEVEL_4_DS
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_O3 ETK   
  --On jointe dans l'orga Hierarchique
  Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL WLvl1
    On    ETK.EDO_ID                 =   WLvl1.ORG_TEAM_LEVEL_1_CD
      And ETK.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_1_START_DT
      And ETK.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_1_END_DT
      And ETK.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_2_START_DT
      And ETK.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_2_END_DT
      And ETK.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_3_START_DT
      And ETK.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_3_END_DT
      And ETK.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_4_START_DT
      And ETK.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_4_END_DT
  Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPDV
    On ETK.EDO_ID                       =   RefPDV.EDO_ID
      And RefPDV.CURRENT_IN             =   1
      And RefPDV.CLOSURE_DT             Is Null
      And RefPDV.EXTNL_COD_CD           =   'ADV'
Where
  (1=1)
Qualify Row_Number() Over (Partition By ETK.EXTERNAL_ORDER_ID,ETK.ORDER_DEPOSIT_DT Order By           WLvl1.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_REF_ETK_EDO_HIER_O3;
.if errorcode <> 0 then .quit 1


.quit 0





