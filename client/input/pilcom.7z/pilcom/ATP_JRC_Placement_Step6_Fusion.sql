--$HEADER:   %HEADER%
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_JRC_Placement_Step5_Fusion.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de Fusion Interaction Enrichissement Canal 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/08/2018       HOB        Creation
-- 24/09/2018       TCL        modif UNIFIED_SHOP_CD
-- 07/01/2019       JCR        Modif pour Humain Digital sprint 1 (Service Client)
-- 14/07/2019       JCR        Prise en compte des interactions sorties des filtres (EXCLUSION).
-- 13/08/2019       GRH        Ajout du champ  CID_ID                      
-- 01/03/2021       EVI        PILCOM-815 : H&D - Ajout source H2H
----------------------------------------------------------------------------------------------
.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.INT_T_PLACEMENT_JRC All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Table des placements                                             ----
----------------------------------------------------------------------------------------------
  Insert Into ${KNB_PCO_TMP}.INT_T_PLACEMENT_JRC
  (  
     ACTE_ID                   ,
     EXTERNAL_ACTE_ID          ,
     INTRCTN_ID                ,
     SOURCE_INTRCTN_ID         ,
     KEYGEN_CD                 ,
     INTRCTN_TS                ,
     INTRCTN_DT                ,
     EXCLUSION_FLAG            ,
     EXCLUSION_DT              ,
     TYPE_SOURCE_ID            ,
     INTRNL_SOURCE_ID          ,
     APPLI_SOURCE_ID           ,
     UNIFIED_PARTY_ID          ,
     PID_ID                    ,
     CID_ID                    ,
     INT_OPRTR_ID              ,
     OPRTR_TEAM_HIERCH_ID      ,
     ORG_AGENT_IOBSP           ,
     OPRTR_TEAM_ACTVT_ID       ,
     UNVRS_CD                  ,
     DIRCTN_CD                 ,
     CHANL_CD                  ,
     MEDIA_CD                  ,
     ORIGN_CD                  ,
     WAY_CD                    ,
     REASN_CD                  ,
     REASN_DETL_CD             ,
     CONCLSN_CD                ,
     ORG_SPE_CANAL_ID_MACRO    ,
     ORG_SPE_CANAL_ID          ,
     ORG_REM_CHANNEL_CD        ,
     ORG_CHANNEL_CD            ,
     ORG_SUB_CHANNEL_CD        ,
     ORG_SUB_SUB_CHANNEL_CD    ,
     ORG_GT_ACTIVITY           ,
     ORG_FIDELISATION          ,
     ORG_WEB_ACTIVITY          ,
     ORG_AUTO_ACTIVITY         ,
     ORG_EDO_IOBSP             ,
     ORG_EDO_ID                ,
     ORG_TEAM_TYPE_ID          ,
     UNIFIED_SHOP_CD           ,
     ORG_TEAM_LEVEL_1_CD       ,
     ORG_TEAM_LEVEL_1_DS       ,
     ORG_TEAM_LEVEL_2_CD       ,
     ORG_TEAM_LEVEL_2_DS       ,
     ORG_TEAM_LEVEL_3_CD       ,
     ORG_TEAM_LEVEL_3_DS       ,
     ORG_TEAM_LEVEL_4_CD       ,
     ORG_TEAM_LEVEL_4_DS       ,
     WORK_TEAM_LEVEL_1_CD      ,
     WORK_TEAM_LEVEL_1_DS      ,
     WORK_TEAM_LEVEL_2_CD      ,
     WORK_TEAM_LEVEL_2_DS      ,
     WORK_TEAM_LEVEL_3_CD      ,
     WORK_TEAM_LEVEL_3_DS      ,
     WORK_TEAM_LEVEL_4_CD      ,
     WORK_TEAM_LEVEL_4_DS      ,
     CREATION_TS               ,
     LAST_MODIF_TS             ,
     FRESH_IN                  ,
     COHERENCE_IN
    )
  Select
     Placement.ACTE_ID                                                              as ACTE_ID                   ,
     Placement.EXTERNAL_ACTE_ID                                                     as EXTERNAL_ACTE_ID          ,
     Placement.INTRCTN_ID                                                           as INTRCTN_ID                ,
     Placement.SOURCE_INTRCTN_ID                                                    as SOURCE_INTRCTN_ID         ,
     Placement.KEYGEN_CD                                                            as KEYGEN_CD                 ,
     Placement.INTRCTN_TS                                                           as INTRCTN_TS                ,
     Placement.INTRCTN_DT                                                           as INTRCTN_DT                ,
     Placement.EXCLUSION_FLAG                                                       as EXCLUSION_FLAG            ,
     Placement.EXCLUSION_DT                                                         as EXCLUSION_DT              ,
     Placement.TYPE_SOURCE_ID                                                       as TYPE_SOURCE_ID            ,
     Placement.INTRNL_SOURCE_ID                                                     as INTRNL_SOURCE_ID          ,
     Placement.APPLI_SOURCE_ID                                                      as APPLI_SOURCE_ID           ,
     Placement.UNIFIED_PARTY_ID                                                     as UNIFIED_PARTY_ID          ,
     Placement.PID_ID                                                               as PID_ID                    ,
     Placement.CID_ID                                                               as CID_ID                    ,
     Placement.INT_OPRTR_ID                                                         as INT_OPRTR_ID              ,
     Placement.OPRTR_TEAM_HIERCH_ID                                                 as OPRTR_TEAM_HIERCH_ID      ,
     Case  When CuidOBK.AGENT_ID is Null
        Then '0'
      When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
        Then '3'
        Else   '2'
     End                                                                            as ORG_AGENT_IOBSP           ,
     Placement.OPRTR_TEAM_ACTVT_ID                                                  as OPRTR_TEAM_ACTVT_ID       ,
     Placement.UNVRS_CD                                                             as UNVRS_CD                  ,
     Placement.DIRCTN_CD                                                            as DIRCTN_CD                 ,
     Placement.CHANL_CD                                                             as CHANL_CD                  ,
     Placement.MEDIA_CD                                                             as MEDIA_CD                  ,
     Placement.ORIGN_CD                                                             as ORIGN_CD                  ,
     Placement.WAY_CD                                                               as WAY_CD                    ,
     Placement.REASN_CD                                                             as REASN_CD                  ,
     Placement.REASN_DETL_CD                                                        as REASN_DETL_CD             ,
     Placement.CONCLSN_CD                                                           as CONCLSN_CD                ,
     Placement.ORG_SPE_CANAL_ID_MACRO                                               as ORG_SPE_CANAL_ID_MACRO    ,
     Placement.ORG_SPE_CANAL_ID                                                     as ORG_SPE_CANAL_ID          ,
     Coalesce(Channel.ORG_REM_CHANNEL_CD,Placement.ORG_REM_CHANNEL_CD  )            as ORG_REM_CHANNEL_CD        ,
     Coalesce(Channel.ORG_CHANNEL_CD,Placement.ORG_CHANNEL_CD )                     as ORG_CHANNEL_CD            ,
     Coalesce(Channel.ORG_SUB_CHANNEL_CD,Placement.ORG_SUB_CHANNEL_CD )             as ORG_SUB_CHANNEL_CD        ,
     Coalesce(Channel.ORG_SUB_SUB_CHANNEL_CD,Placement.ORG_SUB_SUB_CHANNEL_CD )     as ORG_SUB_SUB_CHANNEL_CD    ,
     Coalesce(Channel.ORG_GT_ACTIVITY,Placement.ORG_GT_ACTIVITY )                   as ORG_GT_ACTIVITY           ,
     Coalesce(Channel.ORG_FIDELISATION,Placement.ORG_FIDELISATION )                 as ORG_FIDELISATION          ,
     Coalesce(Channel.ORG_WEB_ACTIVITY,Placement.ORG_WEB_ACTIVITY )                 as ORG_WEB_ACTIVITY          ,
     Coalesce(Channel.ORG_AUTO_ACTIVITY,Placement.ORG_AUTO_ACTIVITY )               as ORG_AUTO_ACTIVITY         ,
     Case When  EdoOBK.EDO_ID is Not null
       Then 'O'
       Else 'N'
     End                                                                            as ORG_EDO_IOBSP             ,
     Placement.ORG_EDO_ID                                                           as ORG_EDO_ID                ,
     Coalesce(Channel.ORG_TEAM_TYPE_ID,Placement.ORG_TEAM_TYPE_ID )                 as ORG_TEAM_TYPE_ID          ,
     Case When Placement.APPLI_SOURCE_ID = '98I' 
          Then Placement.OPRTR_TEAM_HIERCH_ID
        When Placement.APPLI_SOURCE_ID In ( 'CHO', 'OEE' )
          Then Coalesce (Placement.OPRTR_TEAM_ACTVT_ID ,Placement.OPRTR_TEAM_HIERCH_ID)
        When Placement.APPLI_SOURCE_ID In ( 'MCR','H2H' )
          Then EdoLnk.EXTNL_VAL_COD_CD
        Else 'Null'
     End                                                                            as UNIFIED_SHOP_CD           ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_1_CD,Placement.ORG_TEAM_LEVEL_1_CD)          as ORG_TEAM_LEVEL_1_CD       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_1_DS,Placement.ORG_TEAM_LEVEL_1_DS)          as ORG_TEAM_LEVEL_1_DS       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_2_CD,Placement.ORG_TEAM_LEVEL_2_CD)          as ORG_TEAM_LEVEL_2_CD       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_2_DS,Placement.ORG_TEAM_LEVEL_2_DS)          as ORG_TEAM_LEVEL_2_DS       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_3_CD,Placement.ORG_TEAM_LEVEL_3_CD)          as ORG_TEAM_LEVEL_3_CD       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_3_DS,Placement.ORG_TEAM_LEVEL_3_DS)          as ORG_TEAM_LEVEL_3_DS       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_4_CD,Placement.ORG_TEAM_LEVEL_4_CD)          as ORG_TEAM_LEVEL_4_CD       ,
     Coalesce(HierO3Org.ORG_TEAM_LEVEL_4_DS,Placement.ORG_TEAM_LEVEL_4_DS)          as ORG_TEAM_LEVEL_4_DS       ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_1_CD,Placement.WORK_TEAM_LEVEL_1_CD)       as WORK_TEAM_LEVEL_1_CD      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_1_DS,Placement.WORK_TEAM_LEVEL_1_DS)       as WORK_TEAM_LEVEL_1_DS      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_2_CD,Placement.WORK_TEAM_LEVEL_2_CD)       as WORK_TEAM_LEVEL_2_CD      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_2_DS,Placement.WORK_TEAM_LEVEL_2_DS)       as WORK_TEAM_LEVEL_2_DS      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_3_CD,Placement.WORK_TEAM_LEVEL_3_CD)       as WORK_TEAM_LEVEL_3_CD      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_3_DS,Placement.WORK_TEAM_LEVEL_3_DS)       as WORK_TEAM_LEVEL_3_DS      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_4_CD,Placement.WORK_TEAM_LEVEL_4_CD)       as WORK_TEAM_LEVEL_4_CD      ,
     Coalesce(HierO3Work.WORK_TEAM_LEVEL_4_DS,Placement.WORK_TEAM_LEVEL_4_DS)       as WORK_TEAM_LEVEL_4_DS      ,
     Placement.CREATION_TS                                                          as CREATION_TS               ,
     Placement.LAST_MODIF_TS                                                        as LAST_MODIF_TS             ,
     Placement.FRESH_IN                                                             as FRESH_IN                  ,
     Placement.COHERENCE_IN                                                         as COHERENCE_IN               
 From ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1  Placement 
       Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL Channel
        On    Placement.ACTE_ID       = Channel.ACTE_ID
        And   Placement.INTRCTN_DT    = Channel.INTRCTN_DT
        
        
       Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_HIERO3_ORG HierO3Org
        On    Placement.ACTE_ID       = HierO3Org.ACTE_ID
        And   Placement.INTRCTN_DT    = HierO3Org.INTRCTN_DT
        
        
       Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_HIERO3_WORK HierO3Work
        On    Placement.ACTE_ID       = HierO3Work.ACTE_ID
        And   Placement.INTRCTN_DT    = HierO3Work.INTRCTN_DT
        
        
       Left Outer Join  ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK EdoLnk
        On Placement.ORG_EDO_ID       =   EdoLnk.EDO_ID
        And Placement.INTRCTN_DT      >=  EdoLnk.START_EXTNL_VAL_DT
        And Placement.INTRCTN_DT      <   EdoLnk.END_EXTNL_VAL_DT
        And EdoLnk.EXTNL_COD_CD  = 'ADV' 
        
        
     Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK                                                     
      On  Placement.INT_OPRTR_ID=CuidOBK.AGENT_ID                                                              
      AND Placement.INTRCTN_DT >= CuidOBK.HABILL_BEGIN_DT                                                      
      AND Placement.INTRCTN_DT < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
      
      
    Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On  Placement.ORG_EDO_ID   = EdoOBK.EDO_ID
      And Placement.INTRCTN_DT  >= EdoOBK.START_VAL_AXS_DT
      And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN = 1 --('ORANGEBANK')
       
       
       
Where
  (1=1)
    Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.INTRCTN_DT Order By Placement.INTRCTN_TS asc)=1


; 
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.INT_T_PLACEMENT_JRC  ;
.if errorcode <> 0 then .quit 1
