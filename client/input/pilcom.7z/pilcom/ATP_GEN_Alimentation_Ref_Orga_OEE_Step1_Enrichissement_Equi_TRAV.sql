-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GEN_Alimentation_Ref_Orga_OEE_Step1_Enrichissement_Equi_TRAV.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 10/06/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_OEE All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_OEE(
  UPPER_ID_FT,
  CSLORGA_DT_DEB,
  TRAV_ORGA_EQUI_CO_GRP,
  EDO_ID_EQUI_TRAV,
  FLAG_SCH_EQUI_TRAV,
  FLAG_EDO_TRAV,
  FLAG_PLT_CONV_TRAV
)

Select 
  OEE.CUID                                           as UPPER_ID_FT            ,
  OEE.DT_DEBUT                                       as CSLORGA_DT_DEB         ,
  null                                               as TRAV_ORGA_EQUI_CO_GRP ,
  OEE.EDO_ID_EQUI_TRAV                               as EDO_ID_EQUI_TRAV       ,
  Case  When RefEdoAVSC.EDO_ID Is Not Null
          Then 1
        Else   0
  End                                                 as FLAG_SCH_EQUI_TRAV     ,
  Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
          Then  'INT' --'${P_PIL_235}'
        Else    'EXT' --'${P_PIL_236}'
  End                                                 as FLAG_EDO_TRAV          ,
  Case  --Si on trouve une correspondance alors c'est un plateau convergent
        When RefEdoConv.EDO_ID Is Not Null
          Then  1
        Else    0
  End                                                 as FLAG_PLT_CONV_TRAV
From 
  ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_OEE as OEE
    left outer join
      ${KNB_COM_SOC}.V_ORG_F_EDO RefEdo
      on RefEdo.EDO_ID = OEE.EDO_ID_EQUI_TRAV
        And RefEdo.CURRENT_IN     = 1
          And RefEdo.CLOSURE_DT     Is Null
            Left Outer Join
              (
              --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
                Select
                    EDO_ID
                  From
                    ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
                  Where
                    (1=1)
                    And EdoAx.VAL_AXS_CLSSF_ID  In (${L_PIL_110})
                    And EdoAx.FRESH_IN          = 1
                    And EdoAx.CURRENT_IN        = 1
                    And EdoAx.CLOSURE_DT        Is Null
                  Group By
                    EDO_ID
              ) RefEdoConv
              On  RefEdo.EDO_ID   = RefEdoConv.EDO_ID
                  Left Outer Join
                  (
                    --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
                    Select
                      EDO_ID
                    From
                      ${KNB_COM_SOC}.V_ORG_F_AXS_EDO EdoAx
                    Where
                      (1=1)
                      And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113})
                      And EdoAx.FRESH_IN          = 1
                      And EdoAx.CURRENT_IN        = 1
                      And EdoAx.CLOSURE_DT        Is Null
                    Group By
                      EDO_ID
                  ) RefEdoAVSC
                  On  RefEdo.EDO_ID             = RefEdoAVSC.EDO_ID
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_OEE;
.if errorcode <> 0 then .quit 1
