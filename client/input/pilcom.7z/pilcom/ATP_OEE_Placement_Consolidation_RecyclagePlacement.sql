-- $HEADER:   mm2pco/current/sql/ATP_OEE_Placement_Consolidation_RecyclagePlacement.sql 2 19-JUN-2015 14:27:07 KSDP8750
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Placement_Consolidation_RecyclagePlacement.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de Recyclage Placement
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
-- 11/04/2016      MDE         Evol  : profondeur calcul 100 jrs
-- 27/12/2016      HLA         Modification:(Ajout Champ VA)
--------------------------------------------------------------------------------

.set width 2500;



Merge Into  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 Tmp
Using
      (
        Select
          Soc.ACTE_ID                     as ACTE_ID                      ,
          Soc.DEMANDE_ID                  as DEMANDE_ID                   ,
          Soc.EXTERNAL_INT_ID             as EXTERNAL_INT_ID              ,
          Soc.INT_DEPOSIT_TS              as INT_DEPOSIT_TS               ,
          Soc.INT_DEPOSIT_DT              as INT_DEPOSIT_DT               ,
          Soc.OPERATOR_PROVIDER_ID        as OPERATOR_PROVIDER_ID         ,
          Soc.RESOLU_ID                   as RESOLU_ID                    ,
          Soc.CONCLU_ID                   as CONCLU_ID                    ,
          Soc.SSCONCLU_ID                 as SSCONCLU_ID                  ,
          Soc.TYPE_COMMANDE               as TYPE_COMMANDE                ,
          Soc.PLTF_CO                     as PLTF_CO                      ,
          Soc.INTRNL_SOURCE_ID            as INTRNL_SOURCE_ID             ,
          Soc.CONSEIL_XI_CREA             as CONSEIL_XI_CREA              ,
          Soc.CONSEIL_XI_RESP             as CONSEIL_XI_RESP              ,
          Soc.INT_MODIF_TS                as INT_MODIF_TS                 ,
          Soc.IN_CLIDOS                   as IN_CLIDOS                    ,
          Soc.TYPE_OT_SO                  as TYPE_OT_SO                   ,
          Soc.CANALDEM                    as CANALDEM                     ,
          Soc.INT_REASON_CD               as INT_REASON_CD                ,
          Soc.CLIENT_NU                   as CLIENT_NU                    ,
          Soc.CLIENT_NU_NEW_PORTE         as CLIENT_NU_NEW_PORTE          ,
          Soc.DOSSIER_NU                  as DOSSIER_NU                   ,
          Soc.DOSSIER_NU_NEW_PORTE        as DOSSIER_NU_NEW_PORTE         ,
          Soc.DOSSIER_DATE_ACTIV          as DOSSIER_DATE_ACTIV           ,
          Soc.DOSSIER_DATE_RESIL          as DOSSIER_DATE_RESIL           ,
          Soc.DOSSIER_TYPE_RESIL          as DOSSIER_TYPE_RESIL           ,
          Soc.DOSSIER_MOTIF_RESIL         as DOSSIER_MOTIF_RESIL          ,
          Soc.DMC_LINE_ID                 as DMC_LINE_ID                  ,
          Soc.DMC_MASTER_LINE_ID          as DMC_MASTER_LINE_ID           ,
          Soc.PAR_DEPRTMNT_ID             as PAR_DEPRTMNT_ID              ,
          Soc.PAR_POSTAL_CD               as PAR_POSTAL_CD                ,
          Soc.PAR_INSEE_NB                as PAR_INSEE_NB                 ,
          Soc.PAR_BU_CD                   as PAR_BU_CD                    ,
          soc.PAR_GEO_MACROZONE           as PAR_GEO_MACROZONE            ,
          soc.PAR_UNIFIED_PARTY_ID        as PAR_UNIFIED_PARTY_ID         ,
          soc.PAR_PARTY_REGRPMNT_ID       as PAR_PARTY_REGRPMNT_ID        ,
          Soc.PAR_IRIS2000_CD             as PAR_IRIS2000_CD              ,
          Soc.PAR_FIBER_IN                as PAR_FIBER_IN                 ,
          Soc.DMC_LINE_TYPE               as DMC_LINE_TYPE                ,
          Soc.DMC_ACTIVATION_DT           as DMC_ACTIVATION_DT            ,
          Soc.DMC_CONVERGENT_IN           as DMC_CONVERGENT_IN            ,
          Soc.DMC_LINE_ID_INT             as DMC_LINE_ID_INT              ,
          Soc.DMC_LINE_TYPE_INT           as DMC_LINE_TYPE_INT            ,
          Soc.DMC_ACTIVATION_DT_INT       as DMC_ACTIVATION_DT_INT        ,
          Soc.DMC_SERVICE_ACCESS_ID       as DMC_SERVICE_ACCESS_ID        ,
          Soc.OFFRE_INT_PRE               as OFFRE_INT_PRE                ,
          Soc.PRESFACT_CO_PRECED          as PRESFACT_CO_PRECED           ,
          Soc.EVENMT_LB                   as EVENMT_LB                    ,
          Soc.EVENMT_LB_APPLI             as EVENMT_LB_APPLI              ,
          Soc.PRESFACT_CO_OFFRE_OPT_ACQ   as PRESFACT_CO_OFFRE_OPT_ACQ    ,
          Soc.INB_PRESFACT_ACQ_ADV        as INB_PRESFACT_ACQ_ADV         ,
          Soc.INB_PRESFACT_ACQ_AGAP       as INB_PRESFACT_ACQ_AGAP        ,
          Soc.PARC_DT_DEBUT               as PARC_DT_DEBUT                ,
          Soc.PARC_DT_FIN                 as PARC_DT_FIN                  ,
          Soc.ORDAGD_DT_CONF              as ORDAGD_DT_CONF               ,
          Soc.CONTRCT_DT_SIGN_PREC        as CONTRCT_DT_SIGN_PREC         ,
          Soc.CONTRCT_DT_FIN_PREC         as CONTRCT_DT_FIN_PREC          ,
          Soc.CONTRCT_DT_SIGN_POST        as CONTRCT_DT_SIGN_POST         ,
          Soc.CONTRCT_DUREE_ENG           as CONTRCT_DUREE_ENG            ,
          Soc.CONTRCT_UNIT_ENG            as CONTRCT_UNIT_ENG             ,
          Soc.EDO_ID                      as EDO_ID                       ,
          Soc.FLAG_PLT_CONV               as FLAG_PLT_CONV                ,
          Soc.FLAG_PLT_SCH                as FLAG_PLT_SCH                 ,
          Soc.FLAG_TEAM_MKT               as FLAG_TEAM_MKT                ,
          Soc.FLAG_TYPE_CMP               as FLAG_TYPE_CMP                ,
          Soc.TYPE_EDO                    as TYPE_EDO                     ,
          Soc.EDO_ID_HIER                 as EDO_ID_HIER                  ,
          Soc.TYPE_EDO_HIER               as TYPE_EDO_HIER                ,
          -- on Implémente ici le recyclage à J-1, pour gérer la désynchro
          -- Avec l'orga POC
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_REF_TRAV
          End                             as ORG_REF_TRAV                 ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_AGENT_ID
          End                             as ORG_AGENT_ID                 ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_POC_XI
          End                             as ORG_POC_XI                   ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else Soc.ORG_NOM
          End                             as ORG_NOM                      ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else Soc.ORG_PRENOM
          End                             as ORG_PRENOM                   ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else Soc.ORG_GROUPE_ID
          End                             as ORG_GROUPE_ID                ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else Soc.ORG_GROUPE_ID_HIER
          End                             as ORG_GROUPE_ID_HIER           ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_ACTVT_REEL
          End                             as ORG_ACTVT_REEL               ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_RESP_REF_TRAV
          End                             as ORG_RESP_REF_TRAV            ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_RESP_AGENT_ID
          End                             as ORG_RESP_AGENT_ID            ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_RESP_XI
          End                             as ORG_RESP_XI                  ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -2)
                  Then  Null
                Else  Soc.ORG_RESP_ACTVT_REEL
          End                             as ORG_RESP_ACTVT_REEL          ,
          Soc.PAR_LASTNAME                as PAR_LASTNAME                 ,
          Soc.PAR_FIRSTNAME               as PAR_FIRSTNAME                ,
          Soc.PAR_TYPE                    as PAR_TYPE                     ,
          Case  When Soc.INT_DEPOSIT_DT <= (Current_Date -200)
                  Then  Null
                Else Soc.PAR_IMSI
          End                             as PAR_IMSI                     ,
          Soc.PAR_EMAIL                   as PAR_EMAIL                    ,
          Soc.PAR_BILL_ADRESS_1           as PAR_BILL_ADRESS_1            ,
          Soc.PAR_BILL_ADRESS_2           as PAR_BILL_ADRESS_2            ,
          Soc.PAR_BILL_ADRESS_3           as PAR_BILL_ADRESS_3            ,
          Soc.PAR_BILL_ADRESS_4           as PAR_BILL_ADRESS_4            ,
          Soc.PAR_BILL_VILLE              as PAR_BILL_VILLE               ,
          Soc.PAR_BILL_CD_POSTAL          as PAR_BILL_CD_POSTAL           ,
          Soc.PAR_INSEE_CD                as PAR_INSEE_CD                 ,
          Soc.PAR_DO                      as PAR_DO                       ,
          Soc.PAR_USCM                    as PAR_USCM                     ,
          Soc.PAR_USCM_DS                 as PAR_USCM_DS                  ,
          Soc.PAR_USCM_USCM_DS            as PAR_USCM_USCM_DS             ,
          Soc.PAR_USCM_REGUSCM            as PAR_USCM_REGUSCM             ,
          Soc.PAR_USCM_REGUSCM_DS         as PAR_USCM_REGUSCM_DS          ,
          Soc.PAR_AID                     as PAR_AID                      ,
          Soc.PAR_ND                      as PAR_ND                       ,
          Soc.PAR_MOB_IMEI                as PAR_MOB_IMEI                 ,
          Soc.PAR_MOB_TAC                 as PAR_MOB_TAC                  ,
          Soc.PAR_MOB_SIM                 as PAR_MOB_SIM                  ,
          Soc.PAR_SCORE_NU                as PAR_SCORE_NU                 ,
          Soc.PAR_SCORE_IN                as PAR_SCORE_IN                 ,
          Soc.PAR_TRESHOLD_NU             as PAR_TRESHOLD_NU              ,
          Soc.PAR_SCORE_NU_INT            as PAR_SCORE_NU_INT             ,
          Soc.PAR_SCORE_IN_INT            as PAR_SCORE_IN_INT             ,
          Soc.PAR_TRESHOLD_NU_INT         as PAR_TRESHOLD_NU_INT          ,
		  Soc.PTVENTE_XI                  as PTVENTE_XI 	              ,
          Soc.PDV_EXT                     as PDV_EXT                      ,
          Soc.CLOSURE_DT                  as CLOSURE_DT
        From
          ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_OEE Soc
        Where
          (1=1)
          --On réinjecte dans le socle toutes les données Récente (Sup à 100 jours)
          And Soc.INT_DEPOSIT_DT >= (Current_Date -${P_PIL_539})
      ) SocPl
      On    Tmp.ACTE_ID           = SocPl.ACTE_ID
        And Tmp.INT_DEPOSIT_DT    = SocPl.INT_DEPOSIT_DT
When Matched Then
-- Si ça marche, on met à jour :
  Update Set
    CANALDEM                      = SocPl.CANALDEM                    ,
    INT_REASON_CD                 = SocPl.INT_REASON_CD               ,
    CLIENT_NU                     = SocPl.CLIENT_NU                   ,
    CLIENT_NU_NEW_PORTE           = SocPl.CLIENT_NU_NEW_PORTE         ,
    DOSSIER_NU                    = SocPl.DOSSIER_NU                  ,
    DOSSIER_NU_NEW_PORTE          = SocPl.DOSSIER_NU_NEW_PORTE        ,
    DOSSIER_DATE_ACTIV            = SocPl.DOSSIER_DATE_ACTIV          ,
    DOSSIER_DATE_RESIL            = SocPl.DOSSIER_DATE_RESIL          ,
    DOSSIER_TYPE_RESIL            = SocPl.DOSSIER_TYPE_RESIL          ,
    DOSSIER_MOTIF_RESIL           = SocPl.DOSSIER_MOTIF_RESIL         ,
    DMC_LINE_ID                   = SocPl.DMC_LINE_ID                 ,
    DMC_MASTER_LINE_ID            = SocPl.DMC_MASTER_LINE_ID          ,
    PAR_DEPRTMNT_ID               = SocPl.PAR_DEPRTMNT_ID             ,
    PAR_POSTAL_CD                 = SocPl.PAR_POSTAL_CD               ,
    PAR_INSEE_NB                  = SocPl.PAR_INSEE_NB                ,
    PAR_BU_CD                     = SocPl.PAR_BU_CD                   ,
    PAR_GEO_MACROZONE             = SocPl.PAR_GEO_MACROZONE           ,
    PAR_UNIFIED_PARTY_ID          = SocPl.PAR_UNIFIED_PARTY_ID        ,
    PAR_PARTY_REGRPMNT_ID         = SocPl.PAR_PARTY_REGRPMNT_ID       ,
    PAR_IRIS2000_CD               = SocPl.PAR_IRIS2000_CD             ,
    PAR_FIBER_IN                  = SocPl.PAR_FIBER_IN                ,
    DMC_LINE_TYPE                 = SocPl.DMC_LINE_TYPE               ,
    DMC_ACTIVATION_DT             = SocPl.DMC_ACTIVATION_DT           ,
    DMC_CONVERGENT_IN             = SocPl.DMC_CONVERGENT_IN           ,
    DMC_LINE_ID_INT               = SocPl.DMC_LINE_ID_INT             ,
    DMC_LINE_TYPE_INT             = SocPl.DMC_LINE_TYPE_INT           ,
    DMC_ACTIVATION_DT_INT         = SocPl.DMC_ACTIVATION_DT_INT       ,
    DMC_SERVICE_ACCESS_ID         = SocPl.DMC_SERVICE_ACCESS_ID       ,
    OFFRE_INT_PRE                 = SocPl.OFFRE_INT_PRE               ,
    PRESFACT_CO_PRECED            = SocPl.PRESFACT_CO_PRECED          ,
    EVENMT_LB                     = SocPl.EVENMT_LB                   ,
    EVENMT_LB_APPLI               = SocPl.EVENMT_LB_APPLI             ,
    PRESFACT_CO_OFFRE_OPT_ACQ     = SocPl.PRESFACT_CO_OFFRE_OPT_ACQ   ,
    INB_PRESFACT_ACQ_ADV          = SocPl.INB_PRESFACT_ACQ_ADV        ,
    INB_PRESFACT_ACQ_AGAP         = SocPl.INB_PRESFACT_ACQ_AGAP       ,
    PARC_DT_DEBUT                 = SocPl.PARC_DT_DEBUT               ,
    PARC_DT_FIN                   = SocPl.PARC_DT_FIN                 ,
    ORDAGD_DT_CONF                = SocPl.ORDAGD_DT_CONF              ,
    CONTRCT_DT_SIGN_PREC          = SocPl.CONTRCT_DT_SIGN_PREC        ,
    CONTRCT_DT_FIN_PREC           = SocPl.CONTRCT_DT_FIN_PREC         ,
    CONTRCT_DT_SIGN_POST          = SocPl.CONTRCT_DT_SIGN_POST        ,
    CONTRCT_DUREE_ENG             = SocPl.CONTRCT_DUREE_ENG           ,
    CONTRCT_UNIT_ENG              = SocPl.CONTRCT_UNIT_ENG            ,
    EDO_ID                        = SocPl.EDO_ID                      ,
    FLAG_PLT_CONV                 = SocPl.FLAG_PLT_CONV               ,
    FLAG_PLT_SCH                  = SocPl.FLAG_PLT_SCH                ,
    FLAG_TEAM_MKT                 = SocPl.FLAG_TEAM_MKT               ,
    FLAG_TYPE_CMP                 = SocPl.FLAG_TYPE_CMP               ,
    TYPE_EDO                      = SocPl.TYPE_EDO                    ,
    EDO_ID_HIER                   = SocPl.EDO_ID_HIER                 ,
    TYPE_EDO_HIER                 = SocPl.TYPE_EDO_HIER               ,
    ORG_REF_TRAV                  = SocPl.ORG_REF_TRAV                ,
    ORG_AGENT_ID                  = SocPl.ORG_AGENT_ID                ,
    ORG_POC_XI                    = SocPl.ORG_POC_XI                  ,
    ORG_NOM                       = SocPl.ORG_NOM                     ,
    ORG_PRENOM                    = SocPl.ORG_PRENOM                  ,
    ORG_GROUPE_ID                 = SocPl.ORG_GROUPE_ID               ,
    ORG_GROUPE_ID_HIER            = SocPl.ORG_GROUPE_ID_HIER          ,
    ORG_ACTVT_REEL                = SocPl.ORG_ACTVT_REEL              ,
    --Pour les responsable en cas de mis à jour du socle on met à null
    ORG_RESP_REF_TRAV             = Case When SocPl.CONSEIL_XI_RESP = Tmp.CONSEIL_XI_RESP Then SocPl.ORG_RESP_REF_TRAV Else Null End  ,
    ORG_RESP_AGENT_ID             = Case When SocPl.CONSEIL_XI_RESP = Tmp.CONSEIL_XI_RESP Then SocPl.ORG_RESP_AGENT_ID Else Null End  ,
    ORG_RESP_XI                   = Case When SocPl.CONSEIL_XI_RESP = Tmp.CONSEIL_XI_RESP Then SocPl.ORG_RESP_XI Else Null End        ,
    ORG_RESP_ACTVT_REEL           = Case When SocPl.CONSEIL_XI_RESP = Tmp.CONSEIL_XI_RESP Then SocPl.ORG_RESP_ACTVT_REEL Else Null End,
    PAR_LASTNAME                  = SocPl.PAR_LASTNAME                ,
    PAR_FIRSTNAME                 = SocPl.PAR_FIRSTNAME               ,
    PAR_TYPE                      = SocPl.PAR_TYPE                    ,
    PAR_IMSI                      = SocPl.PAR_IMSI                    ,
    PAR_EMAIL                     = SocPl.PAR_EMAIL                   ,
    PAR_BILL_ADRESS_1             = SocPl.PAR_BILL_ADRESS_1           ,
    PAR_BILL_ADRESS_2             = SocPl.PAR_BILL_ADRESS_2           ,
    PAR_BILL_ADRESS_3             = SocPl.PAR_BILL_ADRESS_3           ,
    PAR_BILL_ADRESS_4             = SocPl.PAR_BILL_ADRESS_4           ,
    PAR_BILL_VILLE                = SocPl.PAR_BILL_VILLE              ,
    PAR_BILL_CD_POSTAL            = SocPl.PAR_BILL_CD_POSTAL          ,
    PAR_INSEE_CD                  = SocPl.PAR_INSEE_CD                ,
    PAR_DO                        = SocPl.PAR_DO                      ,
    PAR_USCM                      = SocPl.PAR_USCM                    ,
    PAR_USCM_DS                   = SocPl.PAR_USCM_DS                 ,
    PAR_USCM_USCM_DS              = SocPl.PAR_USCM_USCM_DS            ,
    PAR_USCM_REGUSCM              = SocPl.PAR_USCM_REGUSCM            ,
    PAR_USCM_REGUSCM_DS           = SocPl.PAR_USCM_REGUSCM_DS         ,
    PAR_AID                       = SocPl.PAR_AID                     ,
    PAR_ND                        = SocPl.PAR_ND                      ,
    PAR_MOB_IMEI                  = SocPl.PAR_MOB_IMEI                ,
    PAR_MOB_TAC                   = SocPl.PAR_MOB_TAC                 ,
    PAR_MOB_SIM                   = SocPl.PAR_MOB_SIM                 ,
    PAR_SCORE_NU                  = SocPl.PAR_SCORE_NU                ,
    PAR_SCORE_IN                  = SocPl.PAR_SCORE_IN                ,
    PAR_TRESHOLD_NU               = SocPl.PAR_TRESHOLD_NU             ,
    PAR_SCORE_NU_INT              = SocPl.PAR_SCORE_NU_INT            ,
    PAR_SCORE_IN_INT              = SocPl.PAR_SCORE_IN_INT            ,
    PTVENTE_XI                    = SocPl.PTVENTE_XI 	              ,
    PDV_EXT                        = SocPl.PDV_EXT                   ,
    PAR_TRESHOLD_NU_INT           = SocPl.PAR_TRESHOLD_NU_INT
-- Sinon on fait l'insert
When Not Matched Then
  Insert
  (
    SocPl.ACTE_ID                     ,
    SocPl.DEMANDE_ID                  ,
    SocPl.EXTERNAL_INT_ID             ,
    SocPl.INT_DEPOSIT_TS              ,
    SocPl.INT_DEPOSIT_DT              ,
    SocPl.OPERATOR_PROVIDER_ID        ,
    SocPl.RESOLU_ID                   ,
    SocPl.CONCLU_ID                   ,
    SocPl.SSCONCLU_ID                 ,
    SocPl.TYPE_COMMANDE               ,
    SocPl.PLTF_CO                     ,
    SocPl.INTRNL_SOURCE_ID            ,
    SocPl.CONSEIL_XI_CREA             ,
    SocPl.CONSEIL_XI_RESP             ,
    SocPl.INT_MODIF_TS                ,
    SocPl.IN_CLIDOS                   ,
    SocPl.TYPE_OT_SO                  ,
    SocPl.CANALDEM                    ,
    SocPl.INT_REASON_CD               ,
    SocPl.CLIENT_NU                   ,
    SocPl.CLIENT_NU_NEW_PORTE         ,
    SocPl.DOSSIER_NU                  ,
    SocPl.DOSSIER_NU_NEW_PORTE        ,
    SocPl.DOSSIER_DATE_ACTIV          ,
    SocPl.DOSSIER_DATE_RESIL          ,
    SocPl.DOSSIER_TYPE_RESIL          ,
    SocPl.DOSSIER_MOTIF_RESIL         ,
    SocPl.DMC_LINE_ID                 ,
    SocPl.DMC_MASTER_LINE_ID          ,
    SocPl.PAR_DEPRTMNT_ID             ,
    SocPl.PAR_POSTAL_CD               ,
    SocPl.PAR_INSEE_NB                ,
    SocPl.PAR_BU_CD                   ,
    SocPl.PAR_GEO_MACROZONE           ,
    SocPl.PAR_UNIFIED_PARTY_ID        ,
    SocPl.PAR_PARTY_REGRPMNT_ID       ,
    SocPl.PAR_IRIS2000_CD             ,
    SocPl.PAR_FIBER_IN                ,
    SocPl.DMC_LINE_TYPE               ,
    SocPl.DMC_ACTIVATION_DT           ,
    SocPl.DMC_CONVERGENT_IN           ,
    SocPl.DMC_LINE_ID_INT             ,
    SocPl.DMC_LINE_TYPE_INT           ,
    SocPl.DMC_ACTIVATION_DT_INT       ,
    SocPl.DMC_SERVICE_ACCESS_ID       ,
    SocPl.OFFRE_INT_PRE               ,
    SocPl.PRESFACT_CO_PRECED          ,
    SocPl.EVENMT_LB                   ,
    SocPl.EVENMT_LB_APPLI             ,
    SocPl.PRESFACT_CO_OFFRE_OPT_ACQ   ,
    SocPl.INB_PRESFACT_ACQ_ADV        ,
    SocPl.INB_PRESFACT_ACQ_AGAP       ,
    SocPl.PARC_DT_DEBUT               ,
    SocPl.PARC_DT_FIN                 ,
    SocPl.ORDAGD_DT_CONF              ,
    SocPl.CONTRCT_DT_SIGN_PREC        ,
    SocPl.CONTRCT_DT_FIN_PREC         ,
    SocPl.CONTRCT_DT_SIGN_POST        ,
    SocPl.CONTRCT_DUREE_ENG           ,
    SocPl.CONTRCT_UNIT_ENG            ,
    SocPl.EDO_ID                      ,
    SocPl.FLAG_PLT_CONV               ,
    SocPl.FLAG_PLT_SCH                ,
    SocPl.FLAG_TEAM_MKT               ,
    SocPl.FLAG_TYPE_CMP               ,
    SocPl.TYPE_EDO                    ,
    SocPl.EDO_ID_HIER                 ,
    SocPl.TYPE_EDO_HIER               ,
    SocPl.ORG_REF_TRAV                ,
    SocPl.ORG_AGENT_ID                ,
    SocPl.ORG_POC_XI                  ,
    SocPl.ORG_NOM                     ,
    SocPl.ORG_PRENOM                  ,
    SocPl.ORG_GROUPE_ID               ,
    SocPl.ORG_GROUPE_ID_HIER          ,
    SocPl.ORG_ACTVT_REEL              ,
    SocPl.ORG_RESP_REF_TRAV           ,
    SocPl.ORG_RESP_AGENT_ID           ,
    SocPl.ORG_RESP_XI                 ,
    SocPl.ORG_RESP_ACTVT_REEL         ,
    SocPl.PAR_LASTNAME                ,
    SocPl.PAR_FIRSTNAME               ,
    SocPl.PAR_TYPE                    ,
    SocPl.PAR_IMSI                    ,
    SocPl.PAR_EMAIL                   ,
    SocPl.PAR_BILL_ADRESS_1           ,
    SocPl.PAR_BILL_ADRESS_2           ,
    SocPl.PAR_BILL_ADRESS_3           ,
    SocPl.PAR_BILL_ADRESS_4           ,
    SocPl.PAR_BILL_VILLE              ,
    SocPl.PAR_BILL_CD_POSTAL          ,
    SocPl.PAR_INSEE_CD                ,
    SocPl.PAR_DO                      ,
    SocPl.PAR_USCM                    ,
    SocPl.PAR_USCM_DS                 ,
    SocPl.PAR_USCM_USCM_DS            ,
    SocPl.PAR_USCM_REGUSCM            ,
    SocPl.PAR_USCM_REGUSCM_DS         ,
    SocPl.PAR_AID                     ,
    SocPl.PAR_ND                      ,
    SocPl.PAR_MOB_IMEI                ,
    SocPl.PAR_MOB_TAC                 ,
    SocPl.PAR_MOB_SIM                 ,
    SocPl.PAR_SCORE_NU                ,
    SocPl.PAR_SCORE_IN                ,
    SocPl.PAR_TRESHOLD_NU             ,
    SocPl.PAR_SCORE_NU_INT            ,
    SocPl.PAR_SCORE_IN_INT            ,
    SocPl.PAR_TRESHOLD_NU_INT         ,
    SocPl.PTVENTE_XI                  ,
    SocPl.PDV_EXT                     ,
    SocPl.CLOSURE_DT
  )
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1;
.if errorcode <> 0 then .quit 1

.quit 0
~
~
~
~




