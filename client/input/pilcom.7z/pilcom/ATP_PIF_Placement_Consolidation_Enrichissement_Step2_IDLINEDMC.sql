--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step2_IDLINEDMC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- O1/08/2016      HLA         Creation
--------------------------------------------------------------------------------

.set width 2500;



----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC Avec PAR_ND
----------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC
(
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  DMC_LINE_ID          ,
  DMC_MASTER_LINE_ID   ,
  DMC_LINE_TYPE        ,
  DMC_ACTIVATION_DT    ,
  PAR_DEPRTMNT_ID      ,
  PAR_AID              ,
  MAIL_ADRESS          ,
  FIRST_NAME_NM        ,
  LAST_NAME_NM         ,
  POSTAL_CD            ,
  PAR_INSEE_NB         ,
  PAR_BU_CD
  
)
Select
  RefId.ACTE_ID                             AS  ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    AS  ORDER_DEPOSIT_DT       ,
  LineDmc.LINE_ID                           as  DMC_LINE_ID            ,
  LineDmc.LINE_ID                           as  DMC_MASTER_LINE_ID     ,
  LineDmc.LINE_TYPE                         as  DMC_LINE_TYPE          ,
  LineDmc.ACTIVATION_DT                     as  DMC_ACTIVATION_DT      ,
  Ldmc.DEPRTMNT_ID                          as  PAR_DEPRTMNT_ID        ,
  Ldmc.BSS_PARTY_EXTERNL_ID                 AS  PAR_AID                ,
  Ldmc.MAIL_ADRESS                          AS  MAIL_ADRESS            ,
  Ldmc.LAST_NAME_NM                         AS  FIRST_NAME_NM          ,
  Ldmc.FIRST_NAME_NM                        AS  LAST_NAME_NM           ,
  Ldmc.POSTAL_CD                            AS  POSTAL_CD              ,
  Ldmc.INSEE_NB                             as  PAR_INSEE_NB           ,
  Geo.BU_CD                                 as  PAR_BU_CD  
  
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 RefId


Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_LNK_AR LineDmc
  --Jointure Client/Dossier
 On RefId.SERVICE_ACCESS_ID = LineDmc.SERVICE_ACCESS_ID
 
Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On LineDmc.LINE_ID = Ldmc.LINE_ID
Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
Where 
  (1=1)

;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC;
.if errorcode <> 0 then .quit 1
/*
----------------------------------------------------------------------------
-- Etape 2 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC
(
  ACTE_ID              ,
  ORDER_DEPOSIT_DT       ,
  DMC_LINE_ID          ,
  DMC_MASTER_LINE_ID   ,
  DMC_LINE_TYPE        ,
  DMC_ACTIVATION_DT    ,
  PAR_DEPRTMNT_ID      ,
  PAR_AID              ,
  MAIL_ADRESS          ,
  FIRST_NAME_NM        ,
  LAST_NAME_NM         ,
  POSTAL_CD            ,
  PAR_INSEE_NB         ,
  PAR_BU_CD
  
)
Select
  RefId.ACTE_ID                             AS  ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                      AS  ORDER_DEPOSIT_DT         ,
  LineDmc.LINE_ID                           as  DMC_LINE_ID            ,
  LineDmc.LINE_ID                           as  DMC_MASTER_LINE_ID     ,
  LineDmc.LINE_TYPE                         as  DMC_LINE_TYPE          ,
  LineDmc.ACTIVATION_DT                     as  DMC_ACTIVATION_DT      ,
  Ldmc.DEPRTMNT_ID                          as  PAR_DEPRTMNT_ID        ,
  Ldmc.BSS_PARTY_EXTERNL_ID                 AS  PAR_AID                ,
  Ldmc.MAIL_ADRESS                          AS  MAIL_ADRESS            ,
  Ldmc.LAST_NAME_NM                         AS  FIRST_NAME_NM          ,
  Ldmc.FIRST_NAME_NM                        AS  LAST_NAME_NM           ,
  Ldmc.POSTAL_CD                            AS  POSTAL_CD              ,
  Ldmc.INSEE_NB                             as  PAR_INSEE_NB           ,
  Geo.BU_CD                                 as  PAR_BU_CD  
  
From 
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 RefId
     Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_LNK_AR LineDmc
     --Jointure Client/Dossier
     On RefId.DOSSIER_NU = LineDmc.RES_VALUE_DS
    And RefId.CLIENT_NU = LineDmc.ADV_CLIENT_NU
	--On RefIE.MOBILE
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On LineDmc.LINE_ID = Ldmc.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
Where
  (1=1)
  And Ldmc.CLOSURE_DT  Is Null
  And Not Exists 
  (
    Select
	   1
	From 
	 ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC RefIdExclu
	Where(1=1)
	  And   RefIdExclu.ACTE_ID           = RefId.ACTE_ID
      And   RefIdExclu.ORDER_DEPOSIT_DT    = RefId.ORDER_DEPOSIT_DT
      And   RefIdExclu.DMC_LINE_ID  Is Not Null
  )
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC;
.if errorcode <> 0 then .quit 1
*/
----------------------------------------------------------------------------
-- Etape 3 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  PAR_IRIS2000_CD
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC RefId
  Inner Join ${KNB_DMU_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
    on RefId.DMC_LINE_ID = LFIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by LFIBER.LAST_MODIF_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 4 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  PAR_FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
    on RefId.DMC_LINE_ID = FIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER;
.if errorcode <> 0 then .quit 1
