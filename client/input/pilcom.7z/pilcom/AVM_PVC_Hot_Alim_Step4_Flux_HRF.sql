--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_GRV_AlimHot_EXT_F_ACTE_GRV_HRF.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'extraction des actes a traiter
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 30/05/2013     CBR         Création
---------------------------------------------------------------------------------

.set width 5000

Insert Into ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT
(
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
)
Select
  ActeUni.RUN_ID                                                                            As RUN_ID                         ,
  ActeUni.ACTE_ID                                                                           As ACTE_ID                        ,
  Null                                                                                      As ACTE_ID_EXTERNE                ,
  ActeSrc.INT_ID                                                                            As ACTE_ID_CONTACTE               ,
  ActeSrc.INT_DETL_ID                                                                       As ACTE_ID_DETAIL_CONTACTE        ,
  Null                                                                                      As ACTE_ID_COMMANDE_REFERENCE     ,
  '${P_PIL_243}'                                                                            As SOURCE_ID                      ,
  --A chaud pour Rforce on insert que des type 3 : : Validé Pilcom MAIS incomplet SOFT
  3                                                                                         As ACTE_STATUT                    ,
  --A chaud pour Rforce on insert que des creation d'acte => 1 
  1                                                                                         As ACTION_ACTE                    ,
  ActeUni.ACT_TS                                                                            As ORDER_DEPOSIT_TS               ,
  Cast(SubString(Cast(ActeSrc.CREATION_TS As Char(22)) From 1 For 19) As Timestamp(0))      As ORDER_RECEIVED_PIL_TS          ,
  Cast(
        SubString(Cast(ActeUni.LAST_MODIF_TS As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ORDER_MAJ_PIL_TS               ,
  Null                                                                                      As ORDER_STATUT                   ,
  Null                                                                                      As ORDER_STATUT_TS                ,
  ActeUni.AGENT_ID_UPD                                                                      As CUID                           ,
  ActeUni.AGENT_LAST_NAME                                                                   As SELLER_LAST_NAME               ,
  ActeUni.AGENT_FIRST_NAME                                                                  As SELLER_FIRST_NAME              ,
  Case When ActeUni.ORG_CHANNEL_CD in ('CCO','SCH') Then Null
       Else Trim(Both From ActeSrc.EXTERNAL_TEAM_NM)
  End                                                                                       As TEAM_DLC_DES                   ,
  Null                                                                                      As TEAM_ORDER_DES                 ,
  ActeUni.ORG_REM_CHANNEL_CD                                                                As SALE_CHANNEL_DCL               ,
  ActeUni.ORG_REM_CHANNEL_CD                                                                As SALE_CHANNEL_ORDER             ,
  Null                                                                                      As SALE_ORIGINE                   ,
  Coalesce(ActeSrc.LAST_NAME_NM, 'IND')                                                     As CUSTOMER_LAST_NAME             ,
  ActeSrc.FIRST_NAME_NM                                                                     As CUSTOMER_FIRST_NAME            ,
  Null                                                                                      As MISISDN                        ,
  ActeUni.NDS_VALUE_DS                                                                      As ND                             ,
  Null                                                                                      As NDIP                           ,
  Null                                                                                      As CUSTOMER_PARC                  ,
  Null                                                                                      As CUSTOMER_TYPE                  ,
  Null                                                                                      As CUSTOMER_SEG                   ,
  ActeSrc.SIRET_CODE_CD                                                                     As CUSTOMER_SIRET                 ,
  Null                                                                                      As CUSTOMER_CAT                   ,
  Null                                                                                      As CUSTOMER_AGENCE                ,
  ActeUni.POSTAL_CD                                                                         As CUSTOMER_ZIPCODE               ,
  ActeSrc.FREG_PARTY_ID                                                                     As ID_FREGATE                     ,
  Null                                                                                      As IMEI                           ,
  Null                                                                                      As EAN                            ,
  Null                                                                                      As SIM                            ,
  Null                                                                                      As OSCAR_VALUE                    ,
  Null                                                                                      As DUREE_ENGMENT                  ,
  '1'                                                                                       As VOLUM                          ,
  Null                                                                                      As VAL                            ,
  Null                                                                                      As CA                             ,
  Null                                                                                      As CSO_MOTIF                      ,
  Null                                                                                      As CSO_MOTIF_DES                  ,
  Null                                                                                      As DESCRIPTION                    ,
  ActeUni.ACT_REM_ID                                                                        As ACTE_CODE                      ,
  Null                                                                                      As CODE_TYPE_ORDER                ,
  Null                                                                                      As TYPE_ORDER_INI                 ,
  Null                                                                                      As CODE_TYPE_ORDER_NEW            ,
  Null                                                                                      As TYPE_ORDER_NEW                 ,
  ActeUni.ACT_PRODUCT_ID_PRE                                                                As CODE_PRODUCT_INI               ,
  Cast(LibProduitPre.PRODUCT_DS As Varchar(50))                                             As PRODUCT_DSC_INI                ,
  ActeUni.ACT_SEG_COM_ID_PRE                                                                As SEGMENT_COM_INI                ,
  ActeUni.ACT_CODE_MIGR_PRE                                                                 As CODE_MIGR_INI                  ,
  Null                                                                                      As DSC_MIGR_INI                   ,
  ActeUni.ACT_PRODUCT_ID_FINAL                                                              As CODE_PRODUCT_FIN               ,
  Cast(LibProduit.PRODUCT_DS As Varchar(50))                                                As PRODUCT_DSC_FIN                ,
  ActeUni.ACT_SEG_COM_ID_FINAL                                                              As SEGMENT_COM_FIN                ,
  ActeUni.ACT_CODE_MIGR_FINAL                                                               As CODE_MIGR_FIN                  ,
  Null                                                                                      As DSC_MIGR_FIN                   ,
  Null                                                                                      As DT_CHECK_PARC                  ,
  Null                                                                                      As DT_END_PARC                    ,
  Null                                                                                      As END_PARC_DSC                   ,
  Null                                                                                      As TAUX_PERENITE                  ,
  Null                                                                                      As CC_PLACEMENT                   ,
  Null                                                                                      As DELAI_PRENEITE                 ,
  Null                                                                                      As QUEUE_TS                       ,
  Null                                                                                      As STREAMING_TS                   ,
  Cast(
        SubString(Cast(ActeUni.CREATION_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ACT_CREATION_TS                ,
  Current_Timestamp(0)                                                                      As EXT_CREATION_TS                ,
  ActeUni.HOT_IN                                                                            As HOT_IN                         
From
  ${KNB_PCO_TMP}.ACT_T_ACTE_SENT_PVC Delta 
  Inner Join  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ActeUni 
    On ActeUni.ACTE_ID  = Delta.ACTE_ID
      And ActeUni.ACT_DT  >= current_date - 20
  Inner Join ${KNB_PCO_VM}.V_INT_F_ACTE_HRF  ActeSrc 
    On ActeUni.ACTE_ID = ActeSrc.ACTE_ID_GEN
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduit
    On    ActeUni.ACT_PRODUCT_ID_FINAL      = LibProduit.PRODUCT_ID
      And LibProduit.CURRENT_IN             = 1
      And LibProduit.CLOSURE_DT             Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduitPre
    On    ActeUni.ACT_PRODUCT_ID_PRE        = LibProduitPre.PRODUCT_ID
      And LibProduitPre.CURRENT_IN          = 1
      And LibProduitPre.CLOSURE_DT          Is Null
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT;
.if errorcode <> 0 Then .quit 1;

