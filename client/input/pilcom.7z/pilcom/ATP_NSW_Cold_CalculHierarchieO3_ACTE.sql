-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_NSW_Cold_CalculHierarchieO3_ACTE.sql$
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de récupération de la hiérarchie de travail O3 pour le flux NSW
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 18/09/2015     OCH         Création
---------------------------------------------------------------------------------

.set width 2000;



Delete from ${KNB_PCO_TMP}.ORD_T_CALC_ACT_NSW_O3 all;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_T_CALC_ACT_NSW_O3
(
      ACTE_ID,
      DATE_SAISIE,
      WORK_TEAM_LEVEL_1_CD,
      WORK_TEAM_LEVEL_1_DS,
      WORK_TEAM_LEVEL_2_CD,
      WORK_TEAM_LEVEL_2_DS,
      WORK_TEAM_LEVEL_3_CD,
      WORK_TEAM_LEVEL_3_DS,
      WORK_TEAM_LEVEL_4_CD,
      WORK_TEAM_LEVEL_4_DS
 )
Select
      Placement.ACTE_ID,
      Placement.ORDER_DEPOSIT_DT,
      Hier_Hie.ORG_TEAM_LEVEL_1_CD,
      Hier_Hie.ORG_TEAM_LEVEL_1_DS,
      Hier_Hie.ORG_TEAM_LEVEL_2_CD,
      Hier_Hie.ORG_TEAM_LEVEL_2_DS,
      Hier_Hie.ORG_TEAM_LEVEL_3_CD,
      Hier_Hie.ORG_TEAM_LEVEL_3_DS,
      Hier_Hie.ORG_TEAM_LEVEL_4_CD,
      Hier_Hie.ORG_TEAM_LEVEL_4_DS
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_NSW Placement
  Left Outer Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL As Hier_Hie
    On    Placement.EDO_ID          = Hier_Hie.ORG_TEAM_LEVEL_1_CD
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_1_START_DT And Hier_Hie.ORG_TEAM_LEVEL_1_END_DT
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_2_START_DT And Hier_Hie.ORG_TEAM_LEVEL_2_END_DT
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_3_START_DT And Hier_Hie.ORG_TEAM_LEVEL_3_END_DT
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_4_START_DT And Hier_Hie.ORG_TEAM_LEVEL_4_END_DT
Where
  (1=1)
  And (     Placement.EDO_ID Is Not Null      )
Qualify Row_Number() Over(Partition by Placement.ACTE_ID Order By         Hier_Hie.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_4_CD Desc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect Stats On ${KNB_PCO_TMP}.ORD_T_CALC_ACT_NSW_O3;
.if errorcode <> 0 then .quit 1

