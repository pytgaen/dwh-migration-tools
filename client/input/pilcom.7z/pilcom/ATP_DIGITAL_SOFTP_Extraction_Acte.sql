--$HEADER:   %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DIGITAL_Extraction_Acte_SOFTP.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL  de la source Digital des actes SOFTP dans la table ORD_W_EXTRACT_SOFTP_DIGITAL  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 17/04/2019     GRH         Création
-- 30/04/2019     GRH         Ajout du champ "ACT_ACTE_FAMILLE_KPI"
-- 24/06/2019     JCR         Modif
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_W_EXTRACT_SOFTP_DIGITAL--
-----------------------------------  
Delete From ${KNB_PCO_TMP}.ORD_W_EXTRACT_SOFTP_DIGITAL;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_W_EXTRACT_SOFTP_DIGITAL 
(
  ACTE_ID                       ,
  ACT_DT                        ,
  INTRNL_SOURCE_ID              ,
  SOURCE_DS                     ,
  ACT_ACTE_FAMILLE_KPI          ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PID_ID                    ,
  PAR_CID_ID                    ,
  UNIFIED_SHOP_CD               ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS           
)
Select 
  SFP.ACTE_ID_GEN                                                           As ACTE_ID                         ,
  SFP.ORDER_DEPOSIT_DT                                                      As ACT_DT                          ,
  SFP.INTRNL_SOURCE_ID                                                      As INTRNL_SOURCE_ID                ,
  'SOFTP'                                                                   As SOURCE_DS                       ,
  SFP.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI            ,
  SFP.PAR_UNIFIED_PARTY_ID                                                  As PAR_UNIFIED_PARTY_ID            ,
  SFP.PAR_PID_ID                                                            As PAR_PID_ID                      ,
  SFP.PAR_CID_ID                                                            As PAR_CID_ID                      ,
  SFP.ORG_STORE_NAME                                                        As UNIFIED_SHOP_CD                 ,
   Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SFP.CPLT_ORG_REM_CHANNEL_CD,SFP.ORG_REM_CHANEL_CD)
      Else    SFP.ORG_REM_CHANEL_CD
  End                                                                       As ORG_REM_CHANNEL_CD              ,
  Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SFP.CPLT_ORG_CHANNEL_CD,SFP.ORG_CHANEL_CD)
        Else    SFP.ORG_CHANEL_CD
  End                                                                       As ORG_CHANNEL_CD                  ,
  Case When SFP.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SFP.CPLT_ORG_SUB_CHANNEL_CD,SFP.ORG_SUB_CHANEL_CD)
        Else    SFP.ORG_SUB_CHANEL_CD
  End                                                                       As ORG_SUB_CHANNEL_CD              ,
  Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SFP.CPLT_ORG_SUB_SUB_CHANNEL_CD,SFP.ORG_SUB_SUB_CHANEL_CD)
         Else SFP.ORG_SUB_SUB_CHANEL_CD
  End                                                                       As ORG_SUB_SUB_CHANEL_CD           ,
  Case When SFP.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SFP.CPLT_ORG_GT_ACTIVITY,SFP.ORG_GT_ACTIVITY)
        Else    SFP.ORG_GT_ACTIVITY
  End                                                                       As ORG_GT_ACTIVITY                 ,
  Case When SFP.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SFP.CPLT_ORG_FIDELISATION,SFP.ORG_FIDELISATION)
         Else    SFP.ORG_FIDELISATION
  End                                                                       As ORG_FIDELISATION                ,
  Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SFP.CPLT_ORG_WEB_ACTIVITY,SFP.ORG_WEB_ACTIVITY)
          Else    SFP.ORG_WEB_ACTIVITY
  End                                                                       As ORG_WEB_ACTIVITY                ,
  Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SFP.CPLT_ORG_AUTO_ACTIVITY,SFP.ORG_AUTO_ACTIVITY)
         Else    SFP.ORG_AUTO_ACTIVITY
  End                                                                       As ORG_AUTO_ACTIVITY               ,
  Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SFP.CPLT_ORG_EDO_ID,SFP.ORG_EDO_ID)
        Else SFP.ORG_EDO_ID
  End                                                                       As ORG_EDO_ID                      ,
 Case  When SFP.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SFP.CPLT_ORG_TYPE_EDO,SFP.ORG_TYPE_EDO)
        Else SFP.ORG_TYPE_EDO
  End                                                                       As ORG_TYPE_EDO                    ,

  TRIM(SFP.ORG_TEAM_LEVEL_1_CD)                                             As ORG_TEAM_LEVEL_1_CD             ,
  TRIM(SFP.ORG_TEAM_LEVEL_1_DS)                                             As ORG_TEAM_LEVEL_1_DS             ,
  TRIM(SFP.ORG_TEAM_LEVEL_2_CD)                                             As ORG_TEAM_LEVEL_2_CD             ,
  TRIM(SFP.ORG_TEAM_LEVEL_2_DS)                                             As ORG_TEAM_LEVEL_2_DS             ,
  TRIM(SFP.ORG_TEAM_LEVEL_3_CD)                                             As ORG_TEAM_LEVEL_3_CD             ,
  TRIM(SFP.ORG_TEAM_LEVEL_3_DS)                                             As ORG_TEAM_LEVEL_3_DS             ,
  TRIM(SFP.ORG_TEAM_LEVEL_4_CD)                                             As ORG_TEAM_LEVEL_4_CD             ,
  TRIM(SFP.ORG_TEAM_LEVEL_4_DS)                                             As ORG_TEAM_LEVEL_4_DS             ,
  TRIM(SFP.WORK_TEAM_LEVEL_1_CD)                                            As WORK_TEAM_LEVEL_1_CD            ,
  TRIM(SFP.WORK_TEAM_LEVEL_1_DS)                                            As WORK_TEAM_LEVEL_1_DS            ,
  TRIM(SFP.WORK_TEAM_LEVEL_2_CD)                                            As WORK_TEAM_LEVEL_2_CD            ,
  TRIM(SFP.WORK_TEAM_LEVEL_2_DS)                                            As WORK_TEAM_LEVEL_2_DS            ,
  TRIM(SFP.WORK_TEAM_LEVEL_3_CD)                                            As WORK_TEAM_LEVEL_3_CD            ,
  TRIM(SFP.WORK_TEAM_LEVEL_3_DS)                                            As WORK_TEAM_LEVEL_3_DS            ,
  TRIM(SFP.WORK_TEAM_LEVEL_4_CD)                                            As WORK_TEAM_LEVEL_4_CD            ,
  TRIM(SFP.WORK_TEAM_LEVEL_4_DS)                                            As WORK_TEAM_LEVEL_4_DS            

From ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_PCM As SFP 
Where (1=1) 
  And Substr(SFP.ACT_CD,1,3)    Not In (${L_PIL_036})
  And SFP.ACT_SEG_COM_ID_FINAL  <> '${P_PIL_295}'
  And SFP.ACT_CD                <> '${P_PIL_067}'
  And SFP.ORDER_DEPOSIT_DT      > '20130402'
  And SFP.HOT_IN                = 0
  And SFP.ORDER_DEPOSIT_DT      >= Current_date - 250
  And SFP.ORG_CHANEL_CD       In ('Online','DNU')
  And ((SFP.LAST_MODIF_TS >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' 
        And SFP.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}'
        ) 
      or SFP.ORDER_DEPOSIT_DT > Current_date - 15
      )
;

.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_W_EXTRACT_SOFTP_DIGITAL;
 if errorcode <> 0 then .quit 1;


