--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   INIT_AlimCold_ORD_F_ACTE_UNIFIED_ACT_FLAG_PVC_REM.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL mise à jour de calcul flag PVC REM
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 04/03/2015     OCH         Création
-------------------------------------------------------------------------------------------

.set width 2500;


Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_F_UNIFIED_PVC (
  ACTE_ID                       Bigint                  Not Null  ,
  ACT_DT                        Date Format 'YYYYMMDD'  Not Null  ,
  ACT_FLAG_PVC_REM              CHAR(1)                
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(ACT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_F_UNIFIED_PVC
(
  ACTE_ID             ,
  ACT_DT              ,
  ACT_FLAG_PVC_REM    
)
Select 
  UNI_T.ACTE_ID                                                                                 As ACTE_ID,
  UNI_T.ACT_DT                                                                                  As ACT_DT,
  Case  When  (   --Condition d'éligibilité
                  (1=1)
                  And UNI_T.MASTER_FLAG                 = 1
                  -- L'acte doit être rémunérable
                  And UNI_T.ACT_FLAG_ACT_REM            = 'O'
                  -- L'acte doit avoir un conseiller
                  And UNI_T.AGENT_ID_UPD                Is Not Null
                  --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                  And UNI_T.ORG_REM_CHANNEL_CD          In ('SCO','SCH','CCO','AD')
                  --Condition de vente conclue :
                  And UNI_T.CONCLDD_IN                  = 'O'
                  --L'acte ne doit pas être annulé
                  And UNI_T.ACT_CLOSURE_DT              Is Null
                  And UNI_T.ACT_END_UNIFIED_DT          Is Null

                  -- LEDO de type interne
                  And ( UNI_T.ORG_TYPE_EDO        = 'INT' Or UNI_T.ORG_TYPE_EDO  is Null )
               )
             Then  'O'
           Else   'N'
  End                                                                                          As ACT_FLAG_PVC_REM
From 
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED  UNI_T
;
.if errorcode <> 0 then .quit 1
Collect Stat on ${KNB_TERADATA_USER}.ORD_V_ACTE_F_UNIFIED_PVC Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat on ${KNB_TERADATA_USER}.ORD_V_ACTE_F_UNIFIED_PVC Column(PARTITION);
.if errorcode <> 0 then .quit 1

---Update :
Update RefID
From  
${KNB_PCO_VM}.ORD_F_ACTE_UNIFIED RefID ,
${KNB_TERADATA_USER}.ORD_V_ACTE_F_UNIFIED_PVC RefPVC
Set
  ACT_FLAG_PVC_REM  =  RefPVC.ACT_FLAG_PVC_REM
Where
  (1=1)
  And RefID.ACTE_ID=RefPVC.ACTE_ID
;
.if errorcode <> 0 then .quit 1

.quit 0

