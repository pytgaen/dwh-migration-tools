 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_SOFTI_CrossActes_CHO_ORD_T_ACTE_UNIFIED.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de croisement de la source SOFTI avec la source CHO
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/07/2013     XKN         Création
-- 28/03/2013     HFO         Ajout Croisement RVOI
-- 13/05/2014     HFO         MODIFICATION(AJout des WORK et HIER dans le croisement)
-- 11/09/2014     GMA         Stabilisation des RVOI
-- 13/11/2014     HZO         QC 848 et QC 663/724
-- 26/02/2015     HFO         incident   filtre manquant sur les offres avec le  MSISDN_ID ='0000000000'
-- 12/02/2017     HOB         CREATION QC 1598  (augmentation du délai de rapprochement RFO/CHO)
-- 14/12/2017     JCR         Modification : ajout IOBSP
-- 19/09/2018     JCR         Correction robots
-- 09/04/2019     SII         Modification les rapprochements historiques
-- 02/04/2020     EVI         PILCOM-393 : Modification Règle rapprochements SOFTI/CHO 
-- 22/06/2021     EVI         PILCOM-943 : Suppression Champs Obsolète VU
----------------------------------------------------------------------------------

.set width 5000

--------------------------------
-- Table : ORD_T_ACTE_UNIFIED --
--------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-- Identification Croisement Regle 1  -- Cas des Options

Create volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_MASTER(
      ACTE_ID                           BigInt                        ,
      INTRNL_SOURCE_ID                  SmallInt                      ,
      MSISDN_ID                         Char(10)                      ,
      ACT_DT                            Date Format 'YYYY-MM-DD'      ,
      ACT_TS                            Timestamp(0)                  ,
      ACT_SEG_COM_ID_FINAL              Varchar(64)                   ,
      REAL_ACTIVITY_CD                  Varchar(15)                   ,
      AGENT_ID                          Char(10)                      ,
      ORG_AGENT_IOBSP                   Char(1)                       ,
      AGENT_ID_UPD                      Char(10)                      ,
      AGENT_ID_UPD_DT                   Date FORMAT 'YYYY-MM-DD'      ,
      AGENT_FIRST_NAME                  Varchar(120)                  ,
      AGENT_LAST_NAME                   Varchar(120)                  ,
      ORG_SPE_CANAL_ID_MACRO            Varchar(20)                   ,
      ORG_SPE_CANAL_ID                  Char(10)                      ,
      ORIGIN_CD                         Char(20)                      ,
      REASON_CD                         Char(20)                      ,
      RESULT_CD                         Char(20)                      ,
      ORG_REM_CHANNEL_CD                Char(6)                       ,
      ORG_CHANNEL_CD                    Char(20)                      ,
      ORG_SUB_CHANNEL_CD                Varchar(30)                   ,
      ORG_SUB_SUB_CHANNEL_CD            Varchar(30)                   ,
      ORG_EDO_ID                        BigInt                        ,
      ORG_TYPE_EDO                      Char(3)                       ,
      ORG_EDO_IOBSP                     Char(1)                       ,
      ORG_FLAG_PLT_CONV                 ByteInt                       ,
      ORG_FLAG_TEAM_MKT                 ByteInt                       ,
      ORG_FLAG_TYPE_CMP                 Char(1)                       ,
      ORG_RESP_EDO_ID                   BigInt                        ,
      ORG_RESP_TYPE_EDO                 Char(3)                       ,
      ORG_RESP_FLAG_PLT_CONV            ByteInt                       ,
      ORG_GT_ACTIVITY                   Varchar(30)                   ,
      ORG_FIDELISATION                  Char(12)                      ,
      ORG_WEB_ACTIVITY                  Char(12)                      ,
      ORG_AUTO_ACTIVITY                 Char(12)                      ,
      ORG_TYPE_CD                       Char(7)                       ,
      ORG_TEAM_TYPE_ID                  Char(3)                       ,
      ORG_TEAM_LEVEL_1_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_1_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_2_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_2_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_3_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_3_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_4_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_4_DS               Varchar(60)                   ,
      WORK_TEAM_LEVEL_1_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_1_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_2_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_2_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_3_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_3_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_4_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_4_DS              Varchar(60)                   
)
Primary Index (
  MSISDN_ID                 ,
  ACT_DT                    ,
  ACT_SEG_COM_ID_FINAL      
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_MASTER
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  Null                            ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  Null                            ,
  Null                            ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
From
  ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTI MASTER
Where
  (1=1)
  And MASTER.INTRNL_SOURCE_ID = '1' 
  And MASTER.TYPE_SOURCE_ID In ( 'INT' )
  And MASTER.ORG_SPE_CANAL_ID  <> 'SCC'
  And MASTER.ACT_CLOSURE_DT Is Null 
  And MASTER.ACT_END_UNIFIED_DT Is Null 
  And MASTER.MSISDN_ID <>'0000000000'
  And MASTER.ACT_TYPE_SERVICE_FINAL In (${L_PIL_035})
  And MASTER.ACT_TYPE_SERVICE_FINAL <> ${L_PIL_014}
  And '${SourceTmp}' = 'MASTER'
;
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_MASTER
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED MASTER
Where
  (1=1)
  And MASTER.INTRNL_SOURCE_ID         = '1' 
  And MASTER.TYPE_SOURCE_ID           In ( 'INT' )
  And MASTER.ORG_SPE_CANAL_ID         <> 'SCC'
  And MASTER.ACT_CLOSURE_DT           Is Null
  And MASTER.ACT_END_UNIFIED_DT       Is Null 
  And MASTER.ACT_TYPE_SERVICE_FINAL   In (${L_PIL_035})
  And MASTER.ACT_TYPE_SERVICE_FINAL   <> ${L_PIL_014}
  And MASTER.MSISDN_ID                <>'0000000000'
  And MASTER.ACT_DT                   >= current_date - 230
  And '${SourceSoc}' = 'MASTER'
;
.if errorcode <> 0 then .quit 1;

Collect stat On ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_MASTER Column(MSISDN_ID,ACT_DT,ACT_SEG_COM_ID_FINAL);
.if errorcode <> 0 then .quit 1;




Create volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SLAVE(
      ACTE_ID                           BigInt                        ,
      INTRNL_SOURCE_ID                  SmallInt                      ,
      MSISDN_ID                         Char(10)                      ,
      ACT_DT                            Date Format 'YYYY-MM-DD'      ,
      ACT_TS                            Timestamp(0)                  ,
      ACT_SEG_COM_ID_FINAL              Varchar(64)                   ,
      REAL_ACTIVITY_CD                  Varchar(15)                   ,
      AGENT_ID                          Char(10)                      ,
      ORG_AGENT_IOBSP                   Char(1)                       ,
      AGENT_ID_UPD                      Char(10)                      ,
      AGENT_ID_UPD_DT                   Date FORMAT 'YYYY-MM-DD'      ,
      AGENT_FIRST_NAME                  Varchar(120)                  ,
      AGENT_LAST_NAME                   Varchar(120)                  ,
      ORG_SPE_CANAL_ID_MACRO            Varchar(20)                   ,
      ORG_SPE_CANAL_ID                  Char(10)                      ,
      ORIGIN_CD                         Char(20)                      ,
      REASON_CD                         Char(20)                      ,
      RESULT_CD                         Char(20)                      ,
      ORG_REM_CHANNEL_CD                Char(6)                       ,
      ORG_CHANNEL_CD                    Char(20)                      ,
      ORG_SUB_CHANNEL_CD                Varchar(30)                   ,
      ORG_SUB_SUB_CHANNEL_CD            Varchar(30)                   ,
      ORG_EDO_ID                        BigInt                        ,
      ORG_TYPE_EDO                      Char(3)                       ,
      ORG_EDO_IOBSP                     Char(1)                       ,
      ORG_FLAG_PLT_CONV                 ByteInt                       ,
      ORG_FLAG_TEAM_MKT                 ByteInt                       ,
      ORG_FLAG_TYPE_CMP                 Char(1)                       ,
      ORG_RESP_EDO_ID                   BigInt                        ,
      ORG_RESP_TYPE_EDO                 Char(3)                       ,
      ORG_RESP_FLAG_PLT_CONV            ByteInt                       ,
      ORG_GT_ACTIVITY                   Varchar(30)                   ,
      ORG_FIDELISATION                  Char(12)                      ,
      ORG_WEB_ACTIVITY                  Char(12)                      ,
      ORG_AUTO_ACTIVITY                 Char(12)                      ,
      ORG_TYPE_CD                       Char(7)                       ,
      ORG_TEAM_TYPE_ID                  Char(3)                       ,
      ORG_TEAM_LEVEL_1_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_1_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_2_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_2_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_3_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_3_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_4_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_4_DS               Varchar(60)                   ,
      WORK_TEAM_LEVEL_1_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_1_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_2_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_2_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_3_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_3_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_4_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_4_DS              Varchar(60)                   
)
Primary Index (
  MSISDN_ID                 ,
  ACT_DT                    ,
  ACT_SEG_COM_ID_FINAL      
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SLAVE
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  Null                            ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  Null                            ,
  Null                            ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
From
  ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO SLAVE
Where
  (1=1)
  And SLAVE.INTRNL_SOURCE_ID = '2' 
  And SLAVE.TYPE_SOURCE_ID In ( 'MOB' )
  And SLAVE.ACT_CLOSURE_DT Is Null 
  And SLAVE.ACT_END_UNIFIED_DT Is Null 
  And SLAVE.MSISDN_ID <>'0000000000'
  And SLAVE.ACT_TYPE_SERVICE_FINAL In (${L_PIL_035})
  And SLAVE.ACT_TYPE_SERVICE_FINAL <> ${L_PIL_014}
  And '${SourceTmp}' = 'SLAVE'
;
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SLAVE
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED SLAVE
Where
  (1=1)
  And SLAVE.INTRNL_SOURCE_ID         = '2' 
  And SLAVE.TYPE_SOURCE_ID           In ( 'MOB' )
  And SLAVE.ACT_CLOSURE_DT           Is Null
  And SLAVE.ACT_END_UNIFIED_DT       Is Null 
  And SLAVE.ACT_TYPE_SERVICE_FINAL   In (${L_PIL_035})
  And SLAVE.ACT_TYPE_SERVICE_FINAL   <> ${L_PIL_014}
  And SLAVE.MSISDN_ID                <>'0000000000'
  And SLAVE.ACT_DT                   >= current_date - 230
  And '${SourceSoc}'                 = 'SLAVE'
;
.if errorcode <> 0 then .quit 1;

Collect stat On ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SLAVE Column(MSISDN_ID,ACT_DT,ACT_SEG_COM_ID_FINAL);
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr}
(
  MASTER_ACTE_ID                  ,
  SLAVE_ACTE_ID                   ,
  MASTER_SOURCE_ID                ,
  SLAVE_SOURCE_ID                 ,
  RULE_ID                         ,
  MASTER_NB_FOUND                 ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_EDO_IOBSP                   ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            ,
  OFFSET                          ,
  OFFSET_SEC                      
)
Select 
  RES.MASTER_ACTE_ID                ,
  RES.SLAVE_ACTE_ID                 ,
  RES.MASTER_SOURCE_ID              ,
  RES.SLAVE_SOURCE_ID               ,
  RES.RULE_ID                       ,
  RES.MASTER_NB_FOUND               ,
  RES.REAL_ACTIVITY_CD              ,
  RES.AGENT_ID                      ,
  RES.ORG_AGENT_IOBSP               ,
  RES.AGENT_ID_UPD                  ,
  RES.AGENT_ID_UPD_DT               ,
  RES.AGENT_FIRST_NAME              ,
  RES.AGENT_LAST_NAME               ,
  RES.ORG_SPE_CANAL_ID_MACRO        ,
  RES.ORG_SPE_CANAL_ID              ,
  RES.ORIGIN_CD                     ,
  RES.REASON_CD                     ,
  RES.RESULT_CD                     ,
  RES.ORG_REM_CHANNEL_CD            ,
  RES.ORG_CHANNEL_CD                ,
  RES.ORG_SUB_CHANNEL_CD            ,
  RES.ORG_SUB_SUB_CHANNEL_CD        ,
  RES.ORG_EDO_ID                    ,
  RES.ORG_TYPE_EDO                  ,
  RES.ORG_FLAG_PLT_CONV             ,
  RES.ORG_FLAG_TEAM_MKT             ,
  RES.ORG_FLAG_TYPE_CMP             ,
  RES.ORG_RESP_EDO_ID               ,
  RES.ORG_RESP_TYPE_EDO             ,
  RES.ORG_RESP_FLAG_PLT_CONV        ,
  RES.ORG_GT_ACTIVITY               ,
  RES.ORG_FIDELISATION              ,
  RES.ORG_WEB_ACTIVITY              ,
  RES.ORG_AUTO_ACTIVITY             ,
  RES.ORG_TYPE_CD                   ,
  RES.ORG_AGENT_IOBSP               ,
  RES.ORG_TEAM_TYPE_ID              ,
  RES.ORG_TEAM_LEVEL_1_CD           ,
  RES.ORG_TEAM_LEVEL_1_DS           ,
  RES.ORG_TEAM_LEVEL_2_CD           ,
  RES.ORG_TEAM_LEVEL_2_DS           ,
  RES.ORG_TEAM_LEVEL_3_CD           ,
  RES.ORG_TEAM_LEVEL_3_DS           ,
  RES.ORG_TEAM_LEVEL_4_CD           ,
  RES.ORG_TEAM_LEVEL_4_DS           ,
  RES.WORK_TEAM_LEVEL_1_CD          ,
  RES.WORK_TEAM_LEVEL_1_DS          ,
  RES.WORK_TEAM_LEVEL_2_CD          ,
  RES.WORK_TEAM_LEVEL_2_DS          ,
  RES.WORK_TEAM_LEVEL_3_CD          ,
  RES.WORK_TEAM_LEVEL_3_DS          ,
  RES.WORK_TEAM_LEVEL_4_CD          ,
  RES.WORK_TEAM_LEVEL_4_DS          ,
  RES.OFFSET                        ,
  RES.OFFSET_SEC                    
From 
(
  Select
    MASTER.ACTE_ID                                                                            As MASTER_ACTE_ID,
    SLAVE.ACTE_ID                                                                             As SLAVE_ACTE_ID,
    MASTER.INTRNL_SOURCE_ID                                                                   As MASTER_SOURCE_ID,
    SLAVE.INTRNL_SOURCE_ID                                                                    As SLAVE_SOURCE_ID,
    ${P_PIL_410}                                                                              As RULE_ID,
    Count(*) Over (Partition By SLAVE.ACTE_ID)                                                As MASTER_NB_FOUND, 
    SLAVE.REAL_ACTIVITY_CD                                                                    As REAL_ACTIVITY_CD,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.AGENT_ID
         ELSE MASTER.AGENT_ID
    END                                                                                       AS AGENT_ID ,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.ORG_AGENT_IOBSP
         ELSE MASTER.ORG_AGENT_IOBSP
    END                                                                                       AS ORG_AGENT_IOBSP ,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.AGENT_ID_UPD
         ELSE MASTER.AGENT_ID_UPD
    END                                                                                       AS AGENT_ID_UPD ,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.AGENT_ID_UPD_DT
         ELSE MASTER.AGENT_ID_UPD_DT
    END                                                                                       AS AGENT_ID_UPD_DT ,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.AGENT_FIRST_NAME
         ELSE MASTER.AGENT_FIRST_NAME
    END                                                                                       AS AGENT_FIRST_NAME ,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.AGENT_LAST_NAME
         ELSE MASTER.AGENT_LAST_NAME
    END                                                                                       AS AGENT_LAST_NAME ,
    SLAVE.ORG_SPE_CANAL_ID_MACRO                                                              As ORG_SPE_CANAL_ID_MACRO,
    COALESCE(MASTER.ORG_SPE_CANAL_ID, SLAVE.ORG_SPE_CANAL_ID)                                 AS ORG_SPE_CANAL_ID,
    SLAVE.ORIGIN_CD                                                                           As ORIGIN_CD,
    SLAVE.REASON_CD                                                                           As REASON_CD,
    SLAVE.RESULT_CD                                                                           As RESULT_CD,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
         THEN SLAVE.ORG_REM_CHANNEL_CD
         ELSE COALESCE(SLAVE.ORG_REM_CHANNEL_CD, MASTER.ORG_REM_CHANNEL_CD)
    END                                                                                       As ORG_REM_CHANNEL_CD,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_CHANNEL_CD
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
            Then SLAVE.ORG_CHANNEL_CD
         Else MASTER.ORG_CHANNEL_CD
    END                                                                                       As ORG_CHANNEL_CD,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_SUB_CHANNEL_CD
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
            Then SLAVE.ORG_SUB_CHANNEL_CD
         Else MASTER.ORG_SUB_CHANNEL_CD
    END                                                                                       As ORG_SUB_CHANNEL_CD,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_SUB_SUB_CHANNEL_CD
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_SUB_SUB_CHANNEL_CD
         Else MASTER.ORG_SUB_SUB_CHANNEL_CD 
    END                                                                                       As ORG_SUB_SUB_CHANNEL_CD,
      --Calcul de l'EDO
    COALESCE(SLAVE.ORG_EDO_ID,MASTER.ORG_EDO_ID)                                              As ORG_EDO_ID,
    CASE WHEN SLAVE.ORG_EDO_ID IS NOT NULL
       THEN SLAVE.ORG_TYPE_EDO 
       ELSE MASTER.ORG_TYPE_EDO
       END                                                                                                                                                      As ORG_TYPE_EDO, 
    SLAVE.ORG_EDO_IOBSP                                                                       As ORG_EDO_IOBSP, 
    SLAVE.ORG_FLAG_PLT_CONV                                                                   As ORG_FLAG_PLT_CONV, 
    SLAVE.ORG_FLAG_TEAM_MKT                                                                   As ORG_FLAG_TEAM_MKT, 
    SLAVE.ORG_FLAG_TYPE_CMP                                                                   As ORG_FLAG_TYPE_CMP, 
    SLAVE.ORG_RESP_EDO_ID                                                                     As ORG_RESP_EDO_ID, 
    SLAVE.ORG_RESP_TYPE_EDO                                                                   As ORG_RESP_TYPE_EDO, 
    SLAVE.ORG_RESP_FLAG_PLT_CONV                                                              As ORG_RESP_FLAG_PLT_CONV,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_GT_ACTIVITY
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
            Then SLAVE.ORG_GT_ACTIVITY
         Else MASTER.ORG_GT_ACTIVITY
    END                                                                                       As ORG_GT_ACTIVITY,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_FIDELISATION
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
            Then SLAVE.ORG_FIDELISATION
         Else MASTER.ORG_FIDELISATION
    END                                                                                       As ORG_FIDELISATION,
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_WEB_ACTIVITY
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
            Then SLAVE.ORG_WEB_ACTIVITY
         Else MASTER.ORG_WEB_ACTIVITY
    END                                                                                       As ORG_WEB_ACTIVITY,  
    CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
            THEN SLAVE.ORG_AUTO_ACTIVITY
         When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_AUTO_ACTIVITY
         Else MASTER.ORG_AUTO_ACTIVITY
    END                                                                                       As ORG_AUTO_ACTIVITY,
    -- Calcule Hierar
    Coalesce(SLAVE.ORG_TYPE_CD,MASTER.ORG_TYPE_CD)                                            As ORG_TYPE_CD,
    Coalesce(SLAVE.ORG_TEAM_TYPE_ID,MASTER.ORG_TEAM_TYPE_ID)                                  As ORG_TEAM_TYPE_ID,
    Coalesce(SLAVE.ORG_TEAM_LEVEL_1_CD,MASTER.ORG_TEAM_LEVEL_1_CD)                            As ORG_TEAM_LEVEL_1_CD,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_1_DS
          Else MASTER.ORG_TEAM_LEVEL_1_DS
    End                                                                                       As ORG_TEAM_LEVEL_1_DS,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_2_CD
          Else MASTER.ORG_TEAM_LEVEL_2_CD
    End                                                                                       As ORG_TEAM_LEVEL_2_CD,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_2_DS
          Else MASTER.ORG_TEAM_LEVEL_2_DS
    End                                                                                       As ORG_TEAM_LEVEL_2_DS,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_3_CD
          Else MASTER.ORG_TEAM_LEVEL_3_CD
    End                                                                                       As ORG_TEAM_LEVEL_3_CD,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_3_DS
          Else MASTER.ORG_TEAM_LEVEL_3_DS
    End                                                                                       As ORG_TEAM_LEVEL_3_DS,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_4_CD
          Else MASTER.ORG_TEAM_LEVEL_4_CD
    End                                                                                       As ORG_TEAM_LEVEL_4_CD,
    Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.ORG_TEAM_LEVEL_4_DS
          Else MASTER.ORG_TEAM_LEVEL_4_DS
    End                                                                                       As ORG_TEAM_LEVEL_4_DS,
    --Fin hierar
    -- Calcule H1
    Coalesce(SLAVE.WORK_TEAM_LEVEL_1_CD,MASTER.WORK_TEAM_LEVEL_1_CD)                          As WORK_TEAM_LEVEL_1_CD,
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_1_DS
          Else MASTER.WORK_TEAM_LEVEL_1_DS
    End                                                                                       As WORK_TEAM_LEVEL_1_DS,
    -- Calcul H2
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_2_CD
          Else MASTER.WORK_TEAM_LEVEL_2_CD
    End                                                                                       As WORK_TEAM_LEVEL_2_CD,
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_2_DS
          Else MASTER.WORK_TEAM_LEVEL_2_DS
    End                                                                                       As WORK_TEAM_LEVEL_2_DS,
    --Calcul H3
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_3_CD
          Else MASTER.WORK_TEAM_LEVEL_3_CD
    End                                                                                       As WORK_TEAM_LEVEL_3_CD,
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_3_DS
          Else MASTER.WORK_TEAM_LEVEL_3_DS
    End                                                                                       As WORK_TEAM_LEVEL_3_DS,
    --calcul H4
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_4_CD
          Else MASTER.WORK_TEAM_LEVEL_4_CD
    End                                                                                       As WORK_TEAM_LEVEL_4_CD,
    Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
            Then SLAVE.WORK_TEAM_LEVEL_4_DS
          Else MASTER.WORK_TEAM_LEVEL_4_DS
    End                                                                                       As WORK_TEAM_LEVEL_4_DS,
    Abs((MASTER.ACT_TS - SLAVE.ACT_TS) Day(4) To Second)                                      As DIFF_TS, 
    (Extract(Day From DIFF_TS) * 86400) + (Extract(Hour From DIFF_TS) * 3600) + 
    (Extract(Minute From DIFF_TS) * 60) + Extract(Second From DIFF_TS)                        As OFFSET_SEC,
    MASTER.ACT_DT - SLAVE.ACT_DT                                                              As OFFSET 
  From
    ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_MASTER MASTER
    Inner join ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SLAVE SLAVE
      On    MASTER.MSISDN_ID                = SLAVE.MSISDN_ID
        And MASTER.ACT_DT                   = SLAVE.ACT_DT
        And MASTER.ACT_SEG_COM_ID_FINAL     = SLAVE.ACT_SEG_COM_ID_FINAL 
  Where
    (1=1)
  Qualify Row_Number() Over(Partition By SLAVE.ACTE_ID Order By OFFSET_SEC Asc, MASTER.ACTE_ID Asc) = 1
)RES;
.if errorcode <> 0 then .quit 1;



Drop Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_MASTER;
.if errorcode <> 0 then .quit 1;
Drop Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SLAVE;
.if errorcode <> 0 then .quit 1;


--------------------------------------------------------------------------------------------------------------------------------------------
-- Identification Croisement Regle 2  -- Offres
--------------------------------------------------------------------------------------------------------------------------------------------







Create volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_CHORUS(
      ACTE_ID                           BigInt                        ,
      INTRNL_SOURCE_ID                  SmallInt                      ,
      MSISDN_ID                         Char(10)                      ,
      PRODUCT_CHO                       Varchar(20)                   ,
      ACT_DT                            Date Format 'YYYY-MM-DD'      ,
      ACT_TS                            Timestamp(0)                  ,
      ACT_SEG_COM_ID_FINAL              Varchar(64)                   ,
      REAL_ACTIVITY_CD                  Varchar(15)                   ,
      AGENT_ID                          Char(10)                      ,
      ORG_AGENT_IOBSP                   Char(1)                       ,
      AGENT_ID_UPD                      Char(10)                      ,
      AGENT_ID_UPD_DT                   Date FORMAT 'YYYY-MM-DD'      ,
      AGENT_FIRST_NAME                  Varchar(120)                  ,
      AGENT_LAST_NAME                   Varchar(120)                  ,
      ORG_SPE_CANAL_ID_MACRO            Varchar(20)                   ,
      ORG_SPE_CANAL_ID                  Char(10)                      ,
      ORIGIN_CD                         Char(20)                      ,
      REASON_CD                         Char(20)                      ,
      RESULT_CD                         Char(20)                      ,
      ORG_REM_CHANNEL_CD                Char(6)                       ,
      ORG_CHANNEL_CD                    Char(20)                      ,
      ORG_SUB_CHANNEL_CD                Varchar(30)                   ,
      ORG_SUB_SUB_CHANNEL_CD            Varchar(30)                   ,
      ORG_EDO_ID                        BigInt                        ,
      ORG_TYPE_EDO                      Char(3)                       ,
      ORG_EDO_IOBSP                     Char(1)                       ,
      ORG_FLAG_PLT_CONV                 ByteInt                       ,
      ORG_FLAG_TEAM_MKT                 ByteInt                       ,
      ORG_FLAG_TYPE_CMP                 Char(1)                       ,
      ORG_RESP_EDO_ID                   BigInt                        ,
      ORG_RESP_TYPE_EDO                 Char(3)                       ,
      ORG_RESP_FLAG_PLT_CONV            ByteInt                       ,
      ORG_GT_ACTIVITY                   Varchar(30)                   ,
      ORG_FIDELISATION                  Char(12)                      ,
      ORG_WEB_ACTIVITY                  Char(12)                      ,
      ORG_AUTO_ACTIVITY                 Char(12)                      ,
      ORG_TYPE_CD                       Char(7)                       ,
      ORG_TEAM_TYPE_ID                  Char(3)                       ,
      ORG_TEAM_LEVEL_1_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_1_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_2_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_2_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_3_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_3_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_4_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_4_DS               Varchar(60)                   ,
      WORK_TEAM_LEVEL_1_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_1_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_2_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_2_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_3_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_3_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_4_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_4_DS              Varchar(60)                   
)
Primary Index (
  MSISDN_ID                 ,
  PRODUCT_CHO               
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_CHORUS
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  PRODUCT_CHO                     ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  CHOTMP.ACTE_ID                          as ACTE_ID                      ,
  CHOTMP.INTRNL_SOURCE_ID                 as INTRNL_SOURCE_ID             ,
  CHOTMP.MSISDN_ID                        as MSISDN_ID                    ,
  DEGMT.PRODUCT_CHO                       as PRODUCT_CHO                  ,
  CHOTMP.ACT_DT                           as ACT_DT                       ,
  CHOTMP.ACT_TS                           as ACT_TS                       ,
  CHOTMP.ACT_SEG_COM_ID_FINAL             as ACT_SEG_COM_ID_FINAL         ,
  Null                                    as REAL_ACTIVITY_CD             ,
  CHOTMP.AGENT_ID                         as AGENT_ID                     ,
  CHOTMP.ORG_AGENT_IOBSP                  as ORG_AGENT_IOBSP              ,
  CHOTMP.AGENT_ID_UPD                     as AGENT_ID_UPD                 ,
  CHOTMP.AGENT_ID_UPD_DT                  as AGENT_ID_UPD_DT              ,
  CHOTMP.AGENT_FIRST_NAME                 as AGENT_FIRST_NAME             ,
  CHOTMP.AGENT_LAST_NAME                  as AGENT_LAST_NAME              ,
  CHOTMP.ORG_SPE_CANAL_ID_MACRO           as ORG_SPE_CANAL_ID_MACRO       ,
  CHOTMP.ORG_SPE_CANAL_ID                 as ORG_SPE_CANAL_ID             ,
  CHOTMP.ORIGIN_CD                        as ORIGIN_CD                    ,
  Null                                    as REASON_CD                    ,
  Null                                    as RESULT_CD                    ,
  CHOTMP.ORG_REM_CHANNEL_CD               as ORG_REM_CHANNEL_CD           ,
  CHOTMP.ORG_CHANNEL_CD                   as ORG_CHANNEL_CD               ,
  CHOTMP.ORG_SUB_CHANNEL_CD               as ORG_SUB_CHANNEL_CD           ,
  CHOTMP.ORG_SUB_SUB_CHANNEL_CD           as ORG_SUB_SUB_CHANNEL_CD       ,
  CHOTMP.ORG_EDO_ID                       as ORG_EDO_ID                   ,
  CHOTMP.ORG_TYPE_EDO                     as ORG_TYPE_EDO                 ,
  CHOTMP.ORG_EDO_IOBSP                    as ORG_EDO_IOBSP                ,
  CHOTMP.ORG_FLAG_PLT_CONV                as ORG_FLAG_PLT_CONV            ,
  CHOTMP.ORG_FLAG_TEAM_MKT                as ORG_FLAG_TEAM_MKT            ,
  CHOTMP.ORG_FLAG_TYPE_CMP                as ORG_FLAG_TYPE_CMP            ,
  CHOTMP.ORG_RESP_EDO_ID                  as ORG_RESP_EDO_ID              ,
  CHOTMP.ORG_RESP_TYPE_EDO                as ORG_RESP_TYPE_EDO            ,
  CHOTMP.ORG_RESP_FLAG_PLT_CONV           as ORG_RESP_FLAG_PLT_CONV       ,
  CHOTMP.ORG_GT_ACTIVITY                  as ORG_GT_ACTIVITY              ,
  CHOTMP.ORG_FIDELISATION                 as ORG_FIDELISATION             ,
  CHOTMP.ORG_WEB_ACTIVITY                 as ORG_WEB_ACTIVITY             ,
  CHOTMP.ORG_AUTO_ACTIVITY                as ORG_AUTO_ACTIVITY            ,
  CHOTMP.ORG_TYPE_CD                      as ORG_TYPE_CD                  ,
  CHOTMP.ORG_TEAM_TYPE_ID                 as ORG_TEAM_TYPE_ID             ,
  CHOTMP.ORG_TEAM_LEVEL_1_CD              as ORG_TEAM_LEVEL_1_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_1_DS              as ORG_TEAM_LEVEL_1_DS          ,
  CHOTMP.ORG_TEAM_LEVEL_2_CD              as ORG_TEAM_LEVEL_2_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_2_DS              as ORG_TEAM_LEVEL_2_DS          ,
  CHOTMP.ORG_TEAM_LEVEL_3_CD              as ORG_TEAM_LEVEL_3_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_3_DS              as ORG_TEAM_LEVEL_3_DS          ,
  CHOTMP.ORG_TEAM_LEVEL_4_CD              as ORG_TEAM_LEVEL_4_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_4_DS              as ORG_TEAM_LEVEL_4_DS          ,
  CHOTMP.WORK_TEAM_LEVEL_1_CD             as WORK_TEAM_LEVEL_1_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_1_DS             as WORK_TEAM_LEVEL_1_DS         ,
  CHOTMP.WORK_TEAM_LEVEL_2_CD             as WORK_TEAM_LEVEL_2_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_2_DS             as WORK_TEAM_LEVEL_2_DS         ,
  CHOTMP.WORK_TEAM_LEVEL_3_CD             as WORK_TEAM_LEVEL_3_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_3_DS             as WORK_TEAM_LEVEL_3_DS         ,
  CHOTMP.WORK_TEAM_LEVEL_4_CD             as WORK_TEAM_LEVEL_4_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_4_DS             as WORK_TEAM_LEVEL_4_DS         
From
  ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO               CHOTMP
  Inner Join ${KNB_PCO_VM}.V_INT_F_ACTE_CHO           CHO
     On   CHOTMP.ACTE_ID                  = CHO.ACTE_ID
      And CHOTMP.ACT_DT                   = CHO.INT_DEPOSIT_DT
  Inner Join ${KNB_COM_SOC}.V_CAT_R_PILCOM_PROD_DEGMT                 AS DEGMT
     On   CHO.OTO_OFFER_CD                = DEGMT.PRODUCT_CHO
Where
  (1=1)
  And CHOTMP.INTRNL_SOURCE_ID             = '2'
  And CHOTMP.TYPE_SOURCE_ID               In ('MOB')
  And CHOTMP.ACT_CLOSURE_DT               Is Null
  And CHOTMP.ACT_END_UNIFIED_DT           Is Null
  And CHOTMP.ACT_TYPE_SERVICE_FINAL       In (${L_PIL_014})
  And CHOTMP.MSISDN_ID                    <>'0000000000'
  And '${SourceAlim}' = 'CHO'
;
.if errorcode <> 0 then .quit 1;






Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_CHORUS
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  PRODUCT_CHO                     ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  CHOSOC.ACTE_ID                          as ACTE_ID                      ,
  CHOSOC.INTRNL_SOURCE_ID                 as INTRNL_SOURCE_ID             ,
  CHOSOC.MSISDN_ID                        as MSISDN_ID                    ,
  DEGMT.PRODUCT_CHO                       as PRODUCT_CHO                  ,
  CHOSOC.ACT_DT                           as ACT_DT                       ,
  CHOSOC.ACT_TS                           as ACT_TS                       ,
  CHOSOC.ACT_SEG_COM_ID_FINAL             as ACT_SEG_COM_ID_FINAL         ,
  CHOSOC.REAL_ACTIVITY_CD                 as REAL_ACTIVITY_CD             ,
  CHOSOC.AGENT_ID                         as AGENT_ID                     ,
  CHOSOC.ORG_AGENT_IOBSP                  as ORG_AGENT_IOBSP              ,
  CHOSOC.AGENT_ID_UPD                     as AGENT_ID_UPD                 ,
  CHOSOC.AGENT_ID_UPD_DT                  as AGENT_ID_UPD_DT              ,
  CHOSOC.AGENT_FIRST_NAME                 as AGENT_FIRST_NAME             ,
  CHOSOC.AGENT_LAST_NAME                  as AGENT_LAST_NAME              ,
  CHOSOC.ORG_SPE_CANAL_ID_MACRO           as ORG_SPE_CANAL_ID_MACRO       ,
  CHOSOC.ORG_SPE_CANAL_ID                 as ORG_SPE_CANAL_ID             ,
  CHOSOC.ORIGIN_CD                        as ORIGIN_CD                    ,
  CHOSOC.REASON_CD                        as REASON_CD                    ,
  CHOSOC.RESULT_CD                        as RESULT_CD                    ,
  CHOSOC.ORG_REM_CHANNEL_CD               as ORG_REM_CHANNEL_CD           ,
  CHOSOC.ORG_CHANNEL_CD                   as ORG_CHANNEL_CD               ,
  CHOSOC.ORG_SUB_CHANNEL_CD               as ORG_SUB_CHANNEL_CD           ,
  CHOSOC.ORG_SUB_SUB_CHANNEL_CD           as ORG_SUB_SUB_CHANNEL_CD       ,
  CHOSOC.ORG_EDO_ID                       as ORG_EDO_ID                   ,
  CHOSOC.ORG_TYPE_EDO                     as ORG_TYPE_EDO                 ,
  CHOSOC.ORG_EDO_IOBSP                    as ORG_EDO_IOBSP                ,
  CHOSOC.ORG_FLAG_PLT_CONV                as ORG_FLAG_PLT_CONV            ,
  CHOSOC.ORG_FLAG_TEAM_MKT                as ORG_FLAG_TEAM_MKT            ,
  CHOSOC.ORG_FLAG_TYPE_CMP                as ORG_FLAG_TYPE_CMP            ,
  CHOSOC.ORG_RESP_EDO_ID                  as ORG_RESP_EDO_ID              ,
  CHOSOC.ORG_RESP_TYPE_EDO                as ORG_RESP_TYPE_EDO            ,
  CHOSOC.ORG_RESP_FLAG_PLT_CONV           as ORG_RESP_FLAG_PLT_CONV       ,
  CHOSOC.ORG_GT_ACTIVITY                  as ORG_GT_ACTIVITY              ,
  CHOSOC.ORG_FIDELISATION                 as ORG_FIDELISATION             ,
  CHOSOC.ORG_WEB_ACTIVITY                 as ORG_WEB_ACTIVITY             ,
  CHOSOC.ORG_AUTO_ACTIVITY                as ORG_AUTO_ACTIVITY            ,
  CHOSOC.ORG_TYPE_CD                      as ORG_TYPE_CD                  ,
  CHOSOC.ORG_TEAM_TYPE_ID                 as ORG_TEAM_TYPE_ID             ,
  CHOSOC.ORG_TEAM_LEVEL_1_CD              as ORG_TEAM_LEVEL_1_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_1_DS              as ORG_TEAM_LEVEL_1_DS          ,
  CHOSOC.ORG_TEAM_LEVEL_2_CD              as ORG_TEAM_LEVEL_2_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_2_DS              as ORG_TEAM_LEVEL_2_DS          ,
  CHOSOC.ORG_TEAM_LEVEL_3_CD              as ORG_TEAM_LEVEL_3_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_3_DS              as ORG_TEAM_LEVEL_3_DS          ,
  CHOSOC.ORG_TEAM_LEVEL_4_CD              as ORG_TEAM_LEVEL_4_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_4_DS              as ORG_TEAM_LEVEL_4_DS          ,
  CHOSOC.WORK_TEAM_LEVEL_1_CD             as WORK_TEAM_LEVEL_1_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_1_DS             as WORK_TEAM_LEVEL_1_DS         ,
  CHOSOC.WORK_TEAM_LEVEL_2_CD             as WORK_TEAM_LEVEL_2_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_2_DS             as WORK_TEAM_LEVEL_2_DS         ,
  CHOSOC.WORK_TEAM_LEVEL_3_CD             as WORK_TEAM_LEVEL_3_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_3_DS             as WORK_TEAM_LEVEL_3_DS         ,
  CHOSOC.WORK_TEAM_LEVEL_4_CD             as WORK_TEAM_LEVEL_4_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_4_DS             as WORK_TEAM_LEVEL_4_DS         
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED                  CHOSOC
  Inner Join ${KNB_PCO_VM}.V_INT_F_ACTE_CHO           CHO
     On   CHOSOC.ACTE_ID                  = CHO.ACTE_ID
      And CHOSOC.ACT_DT                   = CHO.INT_DEPOSIT_DT
  Inner Join ${KNB_COM_SOC}.V_CAT_R_PILCOM_PROD_DEGMT                 AS DEGMT
     On   CHO.OTO_OFFER_CD                = DEGMT.PRODUCT_CHO
Where
  (1=1)
  And CHOSOC.INTRNL_SOURCE_ID             = '2'
  And CHOSOC.TYPE_SOURCE_ID               In ('MOB')
  And CHOSOC.ACT_CLOSURE_DT               Is Null
  And CHOSOC.ACT_END_UNIFIED_DT           Is Null
  And CHOSOC.ACT_TYPE_SERVICE_FINAL       In (${L_PIL_014})
  And CHOSOC.MSISDN_ID                    <>'0000000000'
  And CHOSOC.ACT_DT                       >= (Current_date -250)
  And '${SourceAlim}' = 'SOFTI'
;
.if errorcode <> 0 then .quit 1;


Collect Stat On ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_CHORUS Column(MSISDN_ID,PRODUCT_CHO);
.if errorcode <> 0 then .quit 1;






Create volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SOFTI(
      ACTE_ID                           BigInt                        ,
      INTRNL_SOURCE_ID                  SmallInt                      ,
      MSISDN_ID                         Char(10)                      ,
      PRODUCT_CHO                       Varchar(20)                   ,
      ACT_DT                            Date Format 'YYYY-MM-DD'      ,
      ACT_TS                            Timestamp(0)                  ,
      ACT_SEG_COM_ID_FINAL              Varchar(64)                   ,
      REAL_ACTIVITY_CD                  Varchar(15)                   ,
      AGENT_ID                          Char(10)                      ,
      ORG_AGENT_IOBSP                   Char(1)                       ,
      AGENT_ID_UPD                      Char(10)                      ,
      AGENT_ID_UPD_DT                   Date FORMAT 'YYYY-MM-DD'      ,
      AGENT_FIRST_NAME                  Varchar(120)                  ,
      AGENT_LAST_NAME                   Varchar(120)                  ,
      ORG_SPE_CANAL_ID_MACRO            Varchar(20)                   ,
      ORG_SPE_CANAL_ID                  Char(10)                      ,
      ORIGIN_CD                         Char(20)                      ,
      REASON_CD                         Char(20)                      ,
      RESULT_CD                         Char(20)                      ,
      ORG_REM_CHANNEL_CD                Char(6)                       ,
      ORG_CHANNEL_CD                    Char(20)                      ,
      ORG_SUB_CHANNEL_CD                Varchar(30)                   ,
      ORG_SUB_SUB_CHANNEL_CD            Varchar(30)                   ,
      ORG_EDO_ID                        BigInt                        ,
      ORG_TYPE_EDO                      Char(3)                       ,
      ORG_EDO_IOBSP                     Char(1)                       ,
      ORG_FLAG_PLT_CONV                 ByteInt                       ,
      ORG_FLAG_TEAM_MKT                 ByteInt                       ,
      ORG_FLAG_TYPE_CMP                 Char(1)                       ,
      ORG_RESP_EDO_ID                   BigInt                        ,
      ORG_RESP_TYPE_EDO                 Char(3)                       ,
      ORG_RESP_FLAG_PLT_CONV            ByteInt                       ,
      ORG_GT_ACTIVITY                   Varchar(30)                   ,
      ORG_FIDELISATION                  Char(12)                      ,
      ORG_WEB_ACTIVITY                  Char(12)                      ,
      ORG_AUTO_ACTIVITY                 Char(12)                      ,
      ORG_TYPE_CD                       Char(7)                       ,
      ORG_TEAM_TYPE_ID                  Char(3)                       ,
      ORG_TEAM_LEVEL_1_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_1_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_2_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_2_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_3_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_3_DS               Varchar(60)                   ,
      ORG_TEAM_LEVEL_4_CD               Varchar(18)                   ,
      ORG_TEAM_LEVEL_4_DS               Varchar(60)                   ,
      WORK_TEAM_LEVEL_1_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_1_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_2_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_2_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_3_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_3_DS              Varchar(60)                   ,
      WORK_TEAM_LEVEL_4_CD              Varchar(18)                   ,
      WORK_TEAM_LEVEL_4_DS              Varchar(60)                   
)
Primary Index (
  MSISDN_ID                 ,
  ACT_DT                    ,
  ACT_SEG_COM_ID_FINAL      
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1;









Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SOFTI
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  PRODUCT_CHO                     ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  CHOTMP.ACTE_ID                          as ACTE_ID                      ,
  CHOTMP.INTRNL_SOURCE_ID                 as INTRNL_SOURCE_ID             ,
  CHOTMP.MSISDN_ID                        as MSISDN_ID                    ,
  DEGMT.PRODUCT_CHO                       as PRODUCT_CHO                  ,
  CHOTMP.ACT_DT                           as ACT_DT                       ,
  CHOTMP.ACT_TS                           as ACT_TS                       ,
  CHOTMP.ACT_SEG_COM_ID_FINAL             as ACT_SEG_COM_ID_FINAL         ,
  Null                                    as REAL_ACTIVITY_CD             ,
  CHOTMP.AGENT_ID                         as AGENT_ID                     ,
  CHOTMP.ORG_AGENT_IOBSP                  as ORG_AGENT_IOBSP              ,
  CHOTMP.AGENT_ID_UPD                     as AGENT_ID_UPD                 ,
  CHOTMP.AGENT_ID_UPD_DT                  as AGENT_ID_UPD_DT              ,
  CHOTMP.AGENT_FIRST_NAME                 as AGENT_FIRST_NAME             ,
  CHOTMP.AGENT_LAST_NAME                  as AGENT_LAST_NAME              ,
  CHOTMP.ORG_SPE_CANAL_ID_MACRO           as ORG_SPE_CANAL_ID_MACRO       ,
  CHOTMP.ORG_SPE_CANAL_ID                 as ORG_SPE_CANAL_ID             ,
  CHOTMP.ORIGIN_CD                        as ORIGIN_CD                    ,
  Null                                    as REASON_CD                    ,
  Null                                    as RESULT_CD                    ,
  CHOTMP.ORG_REM_CHANNEL_CD               as ORG_REM_CHANNEL_CD           ,
  CHOTMP.ORG_CHANNEL_CD                   as ORG_CHANNEL_CD               ,
  CHOTMP.ORG_SUB_CHANNEL_CD               as ORG_SUB_CHANNEL_CD           ,
  CHOTMP.ORG_SUB_SUB_CHANNEL_CD           as ORG_SUB_SUB_CHANNEL_CD       ,
  CHOTMP.ORG_EDO_ID                       as ORG_EDO_ID                   ,
  CHOTMP.ORG_TYPE_EDO                     as ORG_TYPE_EDO                 ,
  CHOTMP.ORG_EDO_IOBSP                    as ORG_EDO_IOBSP                ,
  CHOTMP.ORG_FLAG_PLT_CONV                as ORG_FLAG_PLT_CONV            ,
  CHOTMP.ORG_FLAG_TEAM_MKT                as ORG_FLAG_TEAM_MKT            ,
  CHOTMP.ORG_FLAG_TYPE_CMP                as ORG_FLAG_TYPE_CMP            ,
  CHOTMP.ORG_RESP_EDO_ID                  as ORG_RESP_EDO_ID              ,
  CHOTMP.ORG_RESP_TYPE_EDO                as ORG_RESP_TYPE_EDO            ,
  CHOTMP.ORG_RESP_FLAG_PLT_CONV           as ORG_RESP_FLAG_PLT_CONV       ,
  CHOTMP.ORG_GT_ACTIVITY                  as ORG_GT_ACTIVITY              ,
  CHOTMP.ORG_FIDELISATION                 as ORG_FIDELISATION             ,
  CHOTMP.ORG_WEB_ACTIVITY                 as ORG_WEB_ACTIVITY             ,
  CHOTMP.ORG_AUTO_ACTIVITY                as ORG_AUTO_ACTIVITY            ,
  CHOTMP.ORG_TYPE_CD                      as ORG_TYPE_CD                  ,
  CHOTMP.ORG_TEAM_TYPE_ID                 as ORG_TEAM_TYPE_ID             ,
  CHOTMP.ORG_TEAM_LEVEL_1_CD              as ORG_TEAM_LEVEL_1_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_1_DS              as ORG_TEAM_LEVEL_1_DS          ,
  CHOTMP.ORG_TEAM_LEVEL_2_CD              as ORG_TEAM_LEVEL_2_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_2_DS              as ORG_TEAM_LEVEL_2_DS          ,
  CHOTMP.ORG_TEAM_LEVEL_3_CD              as ORG_TEAM_LEVEL_3_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_3_DS              as ORG_TEAM_LEVEL_3_DS          ,
  CHOTMP.ORG_TEAM_LEVEL_4_CD              as ORG_TEAM_LEVEL_4_CD          ,
  CHOTMP.ORG_TEAM_LEVEL_4_DS              as ORG_TEAM_LEVEL_4_DS          ,
  CHOTMP.WORK_TEAM_LEVEL_1_CD             as WORK_TEAM_LEVEL_1_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_1_DS             as WORK_TEAM_LEVEL_1_DS         ,
  CHOTMP.WORK_TEAM_LEVEL_2_CD             as WORK_TEAM_LEVEL_2_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_2_DS             as WORK_TEAM_LEVEL_2_DS         ,
  CHOTMP.WORK_TEAM_LEVEL_3_CD             as WORK_TEAM_LEVEL_3_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_3_DS             as WORK_TEAM_LEVEL_3_DS         ,
  CHOTMP.WORK_TEAM_LEVEL_4_CD             as WORK_TEAM_LEVEL_4_CD         ,
  CHOTMP.WORK_TEAM_LEVEL_4_DS             as WORK_TEAM_LEVEL_4_DS         
From
  ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTI                        CHOTMP
  Inner Join ${KNB_PCO_TMP}.CAT_T_PILCOM_PROD_DEGMT_O            DEGMT_O
    On    CHOTMP.ACT_PRODUCT_ID_FINAL     = DEGMT_O.PRODUCT_ID_OPEN
      And CHOTMP.ACT_PERIODE_ID           = DEGMT_O.PERIODE_ID
  Inner Join ${KNB_COM_SOC}.V_CAT_R_PILCOM_PROD_DEGMT            DEGMT
    On    DEGMT_O.COMPST_OFFR_ID          = DEGMT.COMPST_OFFR_ID
      And DEGMT_O.ATOMIC_OFFR_ID          = DEGMT.ATOMIC_OFFR_ID
      And DEGMT_O.FUNCTN_ID               = DEGMT.FUNCTN_ID
Where
  (1=1)
  And CHOTMP.INTRNL_SOURCE_ID             = '1'
  And CHOTMP.TYPE_SOURCE_ID               In ( 'INT' )
  And CHOTMP.ORG_SPE_CANAL_ID             <> 'SCC'
  And CHOTMP.ACT_CLOSURE_DT               Is Null
  And CHOTMP.ACT_END_UNIFIED_DT           Is Null
  And CHOTMP.ACT_TYPE_SERVICE_FINAL       In (${L_PIL_018})
  And CHOTMP.ACT_OPER_ID_FINAL            <> 'RMV'
  And CHOTMP.MSISDN_ID                    <>'0000000000'
  And '${SourceAlim}' = 'SOFTI'
;
.if errorcode <> 0 then .quit 1;




Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SOFTI
(
  ACTE_ID                         ,
  INTRNL_SOURCE_ID                ,
  MSISDN_ID                       ,
  PRODUCT_CHO                     ,
  ACT_DT                          ,
  ACT_TS                          ,
  ACT_SEG_COM_ID_FINAL            ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            
)
Select
  CHOSOC.ACTE_ID                          as ACTE_ID                      ,
  CHOSOC.INTRNL_SOURCE_ID                 as INTRNL_SOURCE_ID             ,
  CHOSOC.MSISDN_ID                        as MSISDN_ID                    ,
  DEGMT.PRODUCT_CHO                       as PRODUCT_CHO                  ,
  CHOSOC.ACT_DT                           as ACT_DT                       ,
  CHOSOC.ACT_TS                           as ACT_TS                       ,
  CHOSOC.ACT_SEG_COM_ID_FINAL             as ACT_SEG_COM_ID_FINAL         ,
  CHOSOC.REAL_ACTIVITY_CD                 as REAL_ACTIVITY_CD             ,
  CHOSOC.AGENT_ID                         as AGENT_ID                     ,
  CHOSOC.ORG_AGENT_IOBSP                  as ORG_AGENT_IOBSP              ,
  CHOSOC.AGENT_ID_UPD                     as AGENT_ID_UPD                 ,
  CHOSOC.AGENT_ID_UPD_DT                  as AGENT_ID_UPD_DT              ,
  CHOSOC.AGENT_FIRST_NAME                 as AGENT_FIRST_NAME             ,
  CHOSOC.AGENT_LAST_NAME                  as AGENT_LAST_NAME              ,
  CHOSOC.ORG_SPE_CANAL_ID_MACRO           as ORG_SPE_CANAL_ID_MACRO       ,
  CHOSOC.ORG_SPE_CANAL_ID                 as ORG_SPE_CANAL_ID             ,
  CHOSOC.ORIGIN_CD                        as ORIGIN_CD                    ,
  CHOSOC.REASON_CD                        as REASON_CD                    ,
  CHOSOC.RESULT_CD                        as RESULT_CD                    ,
  CHOSOC.ORG_REM_CHANNEL_CD               as ORG_REM_CHANNEL_CD           ,
  CHOSOC.ORG_CHANNEL_CD                   as ORG_CHANNEL_CD               ,
  CHOSOC.ORG_SUB_CHANNEL_CD               as ORG_SUB_CHANNEL_CD           ,
  CHOSOC.ORG_SUB_SUB_CHANNEL_CD           as ORG_SUB_SUB_CHANNEL_CD       ,
  CHOSOC.ORG_EDO_ID                       as ORG_EDO_ID                   ,
  CHOSOC.ORG_TYPE_EDO                     as ORG_TYPE_EDO                 ,
  CHOSOC.ORG_EDO_IOBSP                    as ORG_EDO_IOBSP                ,
  CHOSOC.ORG_FLAG_PLT_CONV                as ORG_FLAG_PLT_CONV            ,
  CHOSOC.ORG_FLAG_TEAM_MKT                as ORG_FLAG_TEAM_MKT            ,
  CHOSOC.ORG_FLAG_TYPE_CMP                as ORG_FLAG_TYPE_CMP            ,
  CHOSOC.ORG_RESP_EDO_ID                  as ORG_RESP_EDO_ID              ,
  CHOSOC.ORG_RESP_TYPE_EDO                as ORG_RESP_TYPE_EDO            ,
  CHOSOC.ORG_RESP_FLAG_PLT_CONV           as ORG_RESP_FLAG_PLT_CONV       ,
  CHOSOC.ORG_GT_ACTIVITY                  as ORG_GT_ACTIVITY              ,
  CHOSOC.ORG_FIDELISATION                 as ORG_FIDELISATION             ,
  CHOSOC.ORG_WEB_ACTIVITY                 as ORG_WEB_ACTIVITY             ,
  CHOSOC.ORG_AUTO_ACTIVITY                as ORG_AUTO_ACTIVITY            ,
  CHOSOC.ORG_TYPE_CD                      as ORG_TYPE_CD                  ,
  CHOSOC.ORG_TEAM_TYPE_ID                 as ORG_TEAM_TYPE_ID             ,
  CHOSOC.ORG_TEAM_LEVEL_1_CD              as ORG_TEAM_LEVEL_1_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_1_DS              as ORG_TEAM_LEVEL_1_DS          ,
  CHOSOC.ORG_TEAM_LEVEL_2_CD              as ORG_TEAM_LEVEL_2_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_2_DS              as ORG_TEAM_LEVEL_2_DS          ,
  CHOSOC.ORG_TEAM_LEVEL_3_CD              as ORG_TEAM_LEVEL_3_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_3_DS              as ORG_TEAM_LEVEL_3_DS          ,
  CHOSOC.ORG_TEAM_LEVEL_4_CD              as ORG_TEAM_LEVEL_4_CD          ,
  CHOSOC.ORG_TEAM_LEVEL_4_DS              as ORG_TEAM_LEVEL_4_DS          ,
  CHOSOC.WORK_TEAM_LEVEL_1_CD             as WORK_TEAM_LEVEL_1_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_1_DS             as WORK_TEAM_LEVEL_1_DS         ,
  CHOSOC.WORK_TEAM_LEVEL_2_CD             as WORK_TEAM_LEVEL_2_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_2_DS             as WORK_TEAM_LEVEL_2_DS         ,
  CHOSOC.WORK_TEAM_LEVEL_3_CD             as WORK_TEAM_LEVEL_3_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_3_DS             as WORK_TEAM_LEVEL_3_DS         ,
  CHOSOC.WORK_TEAM_LEVEL_4_CD             as WORK_TEAM_LEVEL_4_CD         ,
  CHOSOC.WORK_TEAM_LEVEL_4_DS             as WORK_TEAM_LEVEL_4_DS         
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED                              CHOSOC
  Inner Join ${KNB_PCO_TMP}.CAT_T_PILCOM_PROD_DEGMT_O             DEGMT_O
    On    CHOSOC.ACT_PRODUCT_ID_FINAL     = DEGMT_O.PRODUCT_ID_OPEN
      And CHOSOC.ACT_PERIODE_ID           = DEGMT_O.PERIODE_ID
  Inner Join ${KNB_COM_SOC}.V_CAT_R_PILCOM_PROD_DEGMT             DEGMT
    On    DEGMT_O.COMPST_OFFR_ID          = DEGMT.COMPST_OFFR_ID
      And DEGMT_O.ATOMIC_OFFR_ID          = DEGMT.ATOMIC_OFFR_ID
      And DEGMT_O.FUNCTN_ID               = DEGMT.FUNCTN_ID
Where
  (1=1)
  And CHOSOC.INTRNL_SOURCE_ID             = '1'
  And CHOSOC.TYPE_SOURCE_ID               In ( 'INT' )
  And CHOSOC.ORG_SPE_CANAL_ID             <> 'SCC'
  And CHOSOC.ACT_CLOSURE_DT               Is Null
  And CHOSOC.ACT_END_UNIFIED_DT           Is Null
  And CHOSOC.ACT_TYPE_SERVICE_FINAL       In (${L_PIL_018})
  And CHOSOC.ACT_OPER_ID_FINAL            <> 'RMV'
  And CHOSOC.MSISDN_ID                    <>'0000000000'
  And CHOSOC.ACT_DT                       >= (Current_date -250)
  And '${SourceAlim}' = 'CHO'
;
.if errorcode <> 0 then .quit 1;




Collect Stat On ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SOFTI Column(MSISDN_ID,PRODUCT_CHO);
.if errorcode <> 0 then .quit 1;








Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
(
  MASTER_ACTE_ID                  ,
  SLAVE_ACTE_ID                   ,
  MASTER_SOURCE_ID                ,
  SLAVE_SOURCE_ID                 ,
  RULE_ID                         ,
  MASTER_NB_FOUND                 ,
  REAL_ACTIVITY_CD                ,
  AGENT_ID                        ,
  ORG_AGENT_IOBSP                 ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            ,
  OFFSET                          ,
  OFFSET_SEC                      
)
Select
  C.MASTER_ACTE_ID                ,
  C.SLAVE_ACTE_ID                 ,
  C.MASTER_SOURCE_ID              ,
  C.SLAVE_SOURCE_ID               ,
  C.RULE_ID                       ,
  C.MASTER_NB_FOUND               ,
  C.REAL_ACTIVITY_CD              ,
  C.AGENT_ID                      ,
  C.ORG_AGENT_IOBSP               ,
  C.AGENT_ID_UPD                  ,
  C.AGENT_ID_UPD_DT               ,
  C.AGENT_FIRST_NAME              ,
  C.AGENT_LAST_NAME               ,
  C.ORG_SPE_CANAL_ID_MACRO        ,
  C.ORG_SPE_CANAL_ID              ,
  C.ORIGIN_CD                     ,
  C.REASON_CD                     ,
  C.RESULT_CD                     ,
  C.ORG_REM_CHANNEL_CD            ,
  C.ORG_CHANNEL_CD                ,
  C.ORG_SUB_CHANNEL_CD            ,
  C.ORG_SUB_SUB_CHANNEL_CD        ,
  C.ORG_EDO_ID                    ,
  C.ORG_TYPE_EDO                  ,
  C.ORG_AGENT_IOBSP               ,
  C.ORG_FLAG_PLT_CONV             ,
  C.ORG_FLAG_TEAM_MKT             ,
  C.ORG_FLAG_TYPE_CMP             ,
  C.ORG_RESP_EDO_ID               ,
  C.ORG_RESP_TYPE_EDO             ,
  C.ORG_RESP_FLAG_PLT_CONV        ,
  C.ORG_GT_ACTIVITY               ,
  C.ORG_FIDELISATION              ,
  C.ORG_WEB_ACTIVITY              ,
  C.ORG_AUTO_ACTIVITY             ,
  C.ORG_TYPE_CD                   ,
  C.ORG_TEAM_TYPE_ID              ,
  C.ORG_TEAM_LEVEL_1_CD           ,
  C.ORG_TEAM_LEVEL_1_DS           ,
  C.ORG_TEAM_LEVEL_2_CD           ,
  C.ORG_TEAM_LEVEL_2_DS           ,
  C.ORG_TEAM_LEVEL_3_CD           ,
  C.ORG_TEAM_LEVEL_3_DS           ,
  C.ORG_TEAM_LEVEL_4_CD           ,
  C.ORG_TEAM_LEVEL_4_DS           ,
  C.WORK_TEAM_LEVEL_1_CD          ,
  C.WORK_TEAM_LEVEL_1_DS          ,
  C.WORK_TEAM_LEVEL_2_CD          ,
  C.WORK_TEAM_LEVEL_2_DS          ,
  C.WORK_TEAM_LEVEL_3_CD          ,
  C.WORK_TEAM_LEVEL_3_DS          ,
  C.WORK_TEAM_LEVEL_4_CD          ,
  C.WORK_TEAM_LEVEL_4_DS          ,
  C.OFFSET                        ,
  C.OFFSET_SEC                    
From
  (
    Select
      RES.MASTER_ACTE_ID                ,
      RES.SLAVE_ACTE_ID                 ,
      RES.MASTER_SOURCE_ID              ,
      RES.SLAVE_SOURCE_ID               ,
      RES.RULE_ID                       ,
      RES.MASTER_NB_FOUND               ,
      RES.REAL_ACTIVITY_CD              ,
      RES.AGENT_ID                      ,
      RES.ORG_AGENT_IOBSP               ,
      RES.AGENT_ID_UPD                  ,
      RES.AGENT_ID_UPD_DT               ,
      RES.AGENT_FIRST_NAME              ,
      RES.AGENT_LAST_NAME               ,
      RES.ORG_SPE_CANAL_ID_MACRO        ,
      RES.ORG_SPE_CANAL_ID              ,
      RES.ORIGIN_CD                     ,
      RES.REASON_CD                     ,
      RES.RESULT_CD                     ,
      RES.ORG_REM_CHANNEL_CD            ,
      RES.ORG_CHANNEL_CD                ,
      RES.ORG_SUB_CHANNEL_CD            ,
      RES.ORG_SUB_SUB_CHANNEL_CD        ,
      RES.ORG_EDO_ID                    ,
      RES.ORG_TYPE_EDO                  ,
      RES.ORG_EDO_IOBSP                 ,
      RES.ORG_FLAG_PLT_CONV             ,
      RES.ORG_FLAG_TEAM_MKT             ,
      RES.ORG_FLAG_TYPE_CMP             ,
      RES.ORG_RESP_EDO_ID               ,
      RES.ORG_RESP_TYPE_EDO             ,
      RES.ORG_RESP_FLAG_PLT_CONV        ,
      RES.ORG_GT_ACTIVITY               ,
      RES.ORG_FIDELISATION              ,
      RES.ORG_WEB_ACTIVITY              ,
      RES.ORG_AUTO_ACTIVITY             ,
      RES.ORG_TYPE_CD                   ,
      RES.ORG_TEAM_TYPE_ID              ,
      RES.ORG_TEAM_LEVEL_1_CD           ,
      RES.ORG_TEAM_LEVEL_1_DS           ,
      RES.ORG_TEAM_LEVEL_2_CD           ,
      RES.ORG_TEAM_LEVEL_2_DS           ,
      RES.ORG_TEAM_LEVEL_3_CD           ,
      RES.ORG_TEAM_LEVEL_3_DS           ,
      RES.ORG_TEAM_LEVEL_4_CD           ,
      RES.ORG_TEAM_LEVEL_4_DS           ,
      RES.WORK_TEAM_LEVEL_1_CD          ,
      RES.WORK_TEAM_LEVEL_1_DS          ,
      RES.WORK_TEAM_LEVEL_2_CD          ,
      RES.WORK_TEAM_LEVEL_2_DS          ,
      RES.WORK_TEAM_LEVEL_3_CD          ,
      RES.WORK_TEAM_LEVEL_3_DS          ,
      RES.WORK_TEAM_LEVEL_4_CD          ,
      RES.WORK_TEAM_LEVEL_4_DS          ,
      RES.OFFSET                        ,
      RES.OFFSET_SEC                     
    From
      (
        Select
          MASTER.ACTE_ID                                                               AS MASTER_ACTE_ID,
          SLAVE.ACTE_ID                                                                AS SLAVE_ACTE_ID,
          MASTER.INTRNL_SOURCE_ID                                                      AS MASTER_SOURCE_ID,
          SLAVE.INTRNL_SOURCE_ID                                                       AS SLAVE_SOURCE_ID,
          MASTER.ACT_SEG_COM_ID_FINAL                                                  AS MASTER_SEG_ID,
          SLAVE.ACT_SEG_COM_ID_FINAL                                                   AS SLAVE_SEG_ID,
          ${P_PIL_411}                                                                 AS RULE_ID,
          COUNT(*) OVER (PARTITION BY SLAVE.ACTE_ID)                                   AS MASTER_NB_FOUND, 
          SLAVE.REAL_ACTIVITY_CD                                                       AS REAL_ACTIVITY_CD,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.AGENT_ID
               ELSE MASTER.AGENT_ID
          END                                                                          AS AGENT_ID ,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.ORG_AGENT_IOBSP
               ELSE MASTER.ORG_AGENT_IOBSP
          END                                                                          AS ORG_AGENT_IOBSP ,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.AGENT_ID_UPD
               ELSE MASTER.AGENT_ID_UPD
          END                                                                          AS AGENT_ID_UPD ,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.AGENT_ID_UPD_DT
               ELSE MASTER.AGENT_ID_UPD_DT
          END                                                                          AS AGENT_ID_UPD_DT ,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.AGENT_FIRST_NAME
               ELSE MASTER.AGENT_FIRST_NAME
          END                                                                          AS AGENT_FIRST_NAME ,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.AGENT_LAST_NAME
               ELSE MASTER.AGENT_LAST_NAME
          END                                                                          AS AGENT_LAST_NAME ,
          SLAVE.ORG_SPE_CANAL_ID_MACRO                                                 As ORG_SPE_CANAL_ID_MACRO,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
               THEN SLAVE.ORG_SPE_CANAL_ID
               ELSE COALESCE(MASTER.ORG_SPE_CANAL_ID, SLAVE.ORG_SPE_CANAL_ID)
          END                                                                          AS ORG_SPE_CANAL_ID,
          SLAVE.ORIGIN_CD                                                              AS ORIGIN_CD,
          SLAVE.REASON_CD                                                              AS REASON_CD,
          SLAVE.RESULT_CD                                                              AS RESULT_CD,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_REM_CHANNEL_CD
               ELSE COALESCE(SLAVE.ORG_REM_CHANNEL_CD, MASTER.ORG_REM_CHANNEL_CD)
          END                                                                          AS ORG_REM_CHANNEL_CD,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_CHANNEL_CD
               When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                  Then SLAVE.ORG_CHANNEL_CD
               Else MASTER.ORG_CHANNEL_CD
          END                                                                          AS ORG_CHANNEL_CD,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_SUB_CHANNEL_CD
              When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                  Then SLAVE.ORG_SUB_CHANNEL_CD
              Else MASTER.ORG_SUB_CHANNEL_CD
          END                                                                          AS ORG_SUB_CHANNEL_CD,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_SUB_SUB_CHANNEL_CD
                When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                  Then SLAVE.ORG_SUB_SUB_CHANNEL_CD
                Else MASTER.ORG_SUB_SUB_CHANNEL_CD 
          END                                                                          AS ORG_SUB_SUB_CHANNEL_CD,
            --Calcul de l'EDO
          COALESCE(SLAVE.ORG_EDO_ID,MASTER.ORG_EDO_ID)                                              As ORG_EDO_ID,
                CASE WHEN SLAVE.ORG_EDO_ID IS NOT NULL
                THEN SLAVE.ORG_TYPE_EDO 
                ELSE MASTER.ORG_TYPE_EDO
                END                                                                                                                                                      As ORG_TYPE_EDO,
          SLAVE.ORG_EDO_IOBSP                                                                       As ORG_EDO_IOBSP, 
          SLAVE.ORG_FLAG_PLT_CONV                                                                   As ORG_FLAG_PLT_CONV, 
          SLAVE.ORG_FLAG_TEAM_MKT                                                                   As ORG_FLAG_TEAM_MKT, 
          SLAVE.ORG_FLAG_TYPE_CMP                                                                   As ORG_FLAG_TYPE_CMP, 
          SLAVE.ORG_RESP_EDO_ID                                                                     As ORG_RESP_EDO_ID, 
          SLAVE.ORG_RESP_TYPE_EDO                                                                   As ORG_RESP_TYPE_EDO, 
          SLAVE.ORG_RESP_FLAG_PLT_CONV                                                              As ORG_RESP_FLAG_PLT_CONV,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_GT_ACTIVITY
               When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                  Then SLAVE.ORG_GT_ACTIVITY
               Else MASTER.ORG_GT_ACTIVITY
          END                                                                          AS ORG_GT_ACTIVITY,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                    THEN SLAVE.ORG_FIDELISATION
               When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                    Then SLAVE.ORG_FIDELISATION
               Else MASTER.ORG_FIDELISATION
          END                                                                          AS ORG_FIDELISATION,
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_WEB_ACTIVITY
               When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                  Then SLAVE.ORG_WEB_ACTIVITY
               Else MASTER.ORG_WEB_ACTIVITY
          END                                                                          AS ORG_WEB_ACTIVITY,  
          CASE WHEN MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
                  THEN SLAVE.ORG_AUTO_ACTIVITY
               When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
                  Then SLAVE.ORG_AUTO_ACTIVITY
               Else MASTER.ORG_AUTO_ACTIVITY
          END                                                                          AS ORG_AUTO_ACTIVITY,
              -- Calcule Hierar
          Coalesce(SLAVE.ORG_TYPE_CD,MASTER.ORG_TYPE_CD)                               As ORG_TYPE_CD,
          Coalesce(SLAVE.ORG_TEAM_TYPE_ID,MASTER.ORG_TEAM_TYPE_ID)                     As ORG_TEAM_TYPE_ID,
          Coalesce(SLAVE.ORG_TEAM_LEVEL_1_CD,MASTER.ORG_TEAM_LEVEL_1_CD)                            As ORG_TEAM_LEVEL_1_CD,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_1_DS
                Else MASTER.ORG_TEAM_LEVEL_1_DS
          End                                                                                       As ORG_TEAM_LEVEL_1_DS,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_2_CD
                Else MASTER.ORG_TEAM_LEVEL_2_CD
          End                                                                                       As ORG_TEAM_LEVEL_2_CD,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_2_DS
                Else MASTER.ORG_TEAM_LEVEL_2_DS
          End                                                                                       As ORG_TEAM_LEVEL_2_DS,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_3_CD
                Else MASTER.ORG_TEAM_LEVEL_3_CD
          End                                                                                       As ORG_TEAM_LEVEL_3_CD,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_3_DS
                Else MASTER.ORG_TEAM_LEVEL_3_DS
          End                                                                                       As ORG_TEAM_LEVEL_3_DS,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_4_CD
                Else MASTER.ORG_TEAM_LEVEL_4_CD
          End                                                                                       As ORG_TEAM_LEVEL_4_CD,
          Case  When SLAVE.ORG_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.ORG_TEAM_LEVEL_4_DS
                Else MASTER.ORG_TEAM_LEVEL_4_DS
          End                                                                                       As ORG_TEAM_LEVEL_4_DS,
          --Fin hierar
          -- Calcule H1
          Coalesce(SLAVE.WORK_TEAM_LEVEL_1_CD,MASTER.WORK_TEAM_LEVEL_1_CD)             As WORK_TEAM_LEVEL_1_CD,
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_1_DS
                Else MASTER.WORK_TEAM_LEVEL_1_DS
          End                                                                          As WORK_TEAM_LEVEL_1_DS,
          -- Calcul H2
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_2_CD
                Else MASTER.WORK_TEAM_LEVEL_2_CD
          End                                                                          As WORK_TEAM_LEVEL_2_CD,
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_2_DS
                Else MASTER.WORK_TEAM_LEVEL_2_DS
          End                                                                          As WORK_TEAM_LEVEL_2_DS,
          --Calcul H3
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_3_CD
                Else MASTER.WORK_TEAM_LEVEL_3_CD
          End                                                                          As WORK_TEAM_LEVEL_3_CD,
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_3_DS
                Else MASTER.WORK_TEAM_LEVEL_3_DS
          End                                                                          As WORK_TEAM_LEVEL_3_DS,
          --calcul H4
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_4_CD
                Else MASTER.WORK_TEAM_LEVEL_4_CD
          End                                                                          As WORK_TEAM_LEVEL_4_CD,
          Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
                  Then SLAVE.WORK_TEAM_LEVEL_4_DS
                Else MASTER.WORK_TEAM_LEVEL_4_DS
          End                                                                          As WORK_TEAM_LEVEL_4_DS,
          ABS((MASTER.ACT_TS - SLAVE.ACT_TS) DAY(4) TO SECOND)                         AS DIFF_TS, 
          (EXTRACT(DAY FROM DIFF_TS) * 86400) + (EXTRACT(HOUR FROM DIFF_TS) * 3600) + 
          (EXTRACT(MINUTE FROM DIFF_TS) * 60) + EXTRACT(SECOND FROM DIFF_TS)           AS OFFSET_SEC,
          MASTER.ACT_DT - SLAVE.ACT_DT                                                 AS OFFSET 
        From
          ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SOFTI                MASTER
          Inner Join ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_CHORUS       SLAVE
            On    MASTER.MSISDN_ID          = SLAVE.MSISDN_ID
              And MASTER.PRODUCT_CHO        = SLAVE.PRODUCT_CHO
              And MASTER.ACT_DT             >= (SLAVE.ACT_DT - ${P_PIL_160})
              AND MASTER.ACT_DT             <= (SLAVE.ACT_DT + ${P_PIL_160}) 
      )RES
  ) AS C
 
QUALIFY ROW_NUMBER() OVER(PARTITION BY SLAVE_ACTE_ID ORDER BY OFFSET_SEC ASC, MASTER_ACTE_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1;



Collect Stats On ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;



Drop Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_CHORUS;
.if errorcode <> 0 then .quit 1;
Drop Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CROSS_CS_SOFTI;
.if errorcode <> 0 then .quit 1;


--------------------------------------------------------------------------------------------------------------------------------------------
-- Alimentation des maîtres ou esclaves dans le TMP 
--------------------------------------------------------------------------------------------------------------------------------------------




-- Alimentation des maîtres ou esclaves dans le TMP 

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} 
(
  ACTE_ID
, OPERATOR_PROVIDER_ID
, INTRNL_SOURCE_ID
, TYPE_SOURCE_ID
, MASTER_ACTE_ID
, MASTER_INTRNL_SOURCE_ID
, MASTER_FLAG
, MASTER_NB_FOUND
, CPLT_ACTE_ID
, CPLT_INTRNL_SOURCE_ID
, CPLT_IN
, RULE_ID
, OFFSET_NB
, ACT_TYPE
, ORDER_EXTERNAL_ID
, STATUS_CD
, ACT_UNIFIED_STATUS_CD
, ACT_TS
, ACT_DT
, ACT_HH
, ACT_LAST_UPD_TS
, ACT_PRODUCT_ID_PRE
, ACT_SEG_COM_ID_PRE
, ACT_SEG_COM_AGG_ID_PRE
, ACT_CODE_MIGR_PRE
, ACT_OPER_ID_PRE
, ACT_PRODUCT_ID_FINAL
, ACT_SEG_COM_ID_FINAL
, ACT_SEG_COM_AGG_ID_FINAL
, ACT_CODE_MIGR_FINAL
, ACT_OPER_ID_FINAL
, ACT_TYPE_SERVICE_FINAL
, ACT_TYPE_COMMANDE_ID
, ACT_DELTA_TARIF
, ACT_CD
, ACT_REM_ID
, ACT_FLAG_ACT_REM
, ACT_FLAG_PEC_PERPVC
, ACT_FLAG_PVC_REM
, ACT_ACTE_VALO
, ACT_ACTE_FAMILLE_KPI
, ACT_PERIODE_ID
, ACT_PERIODE_STATUS
, ACT_PERIODE_CLOSURE_DT
, ORIGIN_CD
, AGENT_ID
, AGENT_ID_UPD
, AGENT_ID_UPD_DT
, ORG_AGENT_IOBSP
, AGENT_FIRST_NAME
, AGENT_LAST_NAME
, UNIFIED_SHOP_CD
, ORG_SPE_CANAL_ID_MACRO
, ORG_SPE_CANAL_ID
, ORG_REM_CHANNEL_CD
, ORG_CHANNEL_CD
, ORG_SUB_CHANNEL_CD
, ORG_SUB_SUB_CHANNEL_CD
, ORG_GT_ACTIVITY
, ORG_FIDELISATION
, ORG_WEB_ACTIVITY
, ORG_AUTO_ACTIVITY
, ORG_EDO_ID
, ORG_TYPE_EDO
, ORG_EDO_IOBSP
, ORG_FLAG_PLT_CONV
, ORG_FLAG_TEAM_MKT
, ORG_FLAG_TYPE_CMP
, ORG_RESP_EDO_ID
, ORG_RESP_TYPE_EDO
, ORG_RESP_FLAG_PLT_CONV
, ACTIVITY_CD
, ACTIVITY_GROUPNG_CD
, AUTO_ACTIVITY_IN
, ORG_TYPE_CD
, ORG_TEAM_TYPE_ID
, ORG_TEAM_LEVEL_1_CD
, ORG_TEAM_LEVEL_1_DS
, ORG_TEAM_LEVEL_2_CD
, ORG_TEAM_LEVEL_2_DS
, ORG_TEAM_LEVEL_3_CD
, ORG_TEAM_LEVEL_3_DS
, ORG_TEAM_LEVEL_4_CD
, ORG_TEAM_LEVEL_4_DS
, WORK_TEAM_LEVEL_1_CD
, WORK_TEAM_LEVEL_1_DS
, WORK_TEAM_LEVEL_2_CD
, WORK_TEAM_LEVEL_2_DS
, WORK_TEAM_LEVEL_3_CD
, WORK_TEAM_LEVEL_3_DS
, WORK_TEAM_LEVEL_4_CD
, WORK_TEAM_LEVEL_4_DS
, CONFIRMATION_IN
, CONCLDD_IN
, COMPTTN_IN
, COMPTTN_ID
, PERNNT_IN
, PERNNT_END_DT
, PERNNT_MOTIF
, PERNNT_CALC_END_DT
, MIGRA_DT
, MIGRA_NEXT_OFFRE
, PRES_SEGMENT_IN_PARK_BEFORE_IN
, SEGMENT_DELIVERY_IN_PARK_DT
, ORDER_CANCELING_DT
, LINE_ID
, MASTER_LINE_ID
, CUST_TYPE_CD
, MSISDN_ID
, NDS_VALUE_DS
, EXTERNAL_PARTY_ID
, RES_VALUE_DS
, PAR_ACCES_SERVICE
, TAC_CD
, IMEI_CD
, IMSI_CD
, HOM_START_DT
, MOB_START_DT
, I_SCORE_VALUE
, I_SCORE_TRESHOLD
, I_SCORE_IN
, M_SCORE_VALUE
, M_SCORE_TRESHOLD
, M_SCORE_IN
, OSCAR_VALUE
, CUST_BU_TYPE_CD
, CUST_BU_CD
, ADDRESS_TYPE
, ADDRESS_CONCAT_NM
, POSTAL_CD
, INSEE_CD
, BU_CD
, DEPARTMNT_ID
, PAR_GEO_MACROZONE
, PAR_UNIFIED_PARTY_ID
, PAR_PARTY_REGRPMNT_ID
, PAR_CID_ID
, PAR_PID_ID
, PAR_FIRST_IN
, PAR_IRIS2000_CD
, COMMARTICLE_RP_REFPRIX_CD
, ACT_CA_LINE_AM
, ACT_CA_TTC_AM
, EAN_CD
, SIM_CD
, SIM_EAN_CD
, ORG_RESP_ID
, EAN_PREVIOUS_CD
, TAC_PREVIOUS_CD
, IMEI_PREVIOUS_CD
, PCM_PREVIOUS_OFFRE_CD
, PCM_COMMTMNT_PERIOD_NU
, PCM_LEVEL_POINT_NU
, PCM_OFFRE_CD
, PCM_EFFCTV_NEXT_OFFRE_DT
, PCM_TYPE_OFFRE_MOBILE_CD
, PCM_POINT_UTIL_NU
, PCM_BALANCE_POINT_NU
, PCM_STATUT_POINT_CD
, PCM_POINT_DUE_NU
, PAR_ELIGIBLE_FIBER_IN
, CHECK_INITIAL_STATUS_CD
, CHECK_NAT_STATUS_CD
, CHECK_NAT_COMMENT
, CHECK_NAT_STATUS_LN
, CHECK_LOC_STATUS_CD
, CHECK_LOC_COMMENT
, CHECK_LOC_STATUS_LN
, CHECK_VALIDT_DT
, ACT_END_UNIFIED_DT
, ACT_END_UNIFIED_DS
, ACT_CLOSURE_DT
, ACT_CLOSURE_DS
, HOT_IN
, RUN_ID
, CREATION_TS
, LAST_MODIF_TS
, FRESH_IN
, COHERENCE_IN)
Select
  SOC.ACTE_ID
, SOC.OPERATOR_PROVIDER_ID
, SOC.INTRNL_SOURCE_ID
, SOC.TYPE_SOURCE_ID
, SOC.MASTER_ACTE_ID
, SOC.MASTER_INTRNL_SOURCE_ID
, SOC.MASTER_FLAG
, SOC.MASTER_NB_FOUND
, SOC.CPLT_ACTE_ID
, SOC.CPLT_INTRNL_SOURCE_ID
, SOC.CPLT_IN
, SOC.RULE_ID
, SOC.OFFSET_NB
, SOC.ACT_TYPE
, SOC.ORDER_EXTERNAL_ID
, SOC.STATUS_CD
, SOC.ACT_UNIFIED_STATUS_CD
, SOC.ACT_TS
, SOC.ACT_DT
, SOC.ACT_HH
, SOC.ACT_LAST_UPD_TS
, SOC.ACT_PRODUCT_ID_PRE
, SOC.ACT_SEG_COM_ID_PRE
, SOC.ACT_SEG_COM_AGG_ID_PRE
, SOC.ACT_CODE_MIGR_PRE
, SOC.ACT_OPER_ID_PRE
, SOC.ACT_PRODUCT_ID_FINAL
, SOC.ACT_SEG_COM_ID_FINAL
, SOC.ACT_SEG_COM_AGG_ID_FINAL
, SOC.ACT_CODE_MIGR_FINAL
, SOC.ACT_OPER_ID_FINAL
, SOC.ACT_TYPE_SERVICE_FINAL
, SOC.ACT_TYPE_COMMANDE_ID
, SOC.ACT_DELTA_TARIF
, SOC.ACT_CD
, SOC.ACT_REM_ID
, SOC.ACT_FLAG_ACT_REM
, SOC.ACT_FLAG_PEC_PERPVC
, SOC.ACT_FLAG_PVC_REM
, SOC.ACT_ACTE_VALO
, SOC.ACT_ACTE_FAMILLE_KPI
, SOC.ACT_PERIODE_ID
, SOC.ACT_PERIODE_STATUS
, SOC.ACT_PERIODE_CLOSURE_DT
, SOC.ORIGIN_CD
, SOC.AGENT_ID
, SOC.AGENT_ID_UPD
, SOC.AGENT_ID_UPD_DT
, SOC.ORG_AGENT_IOBSP
, SOC.AGENT_FIRST_NAME
, SOC.AGENT_LAST_NAME
, SOC.UNIFIED_SHOP_CD
, SOC.ORG_SPE_CANAL_ID_MACRO
, SOC.ORG_SPE_CANAL_ID
, SOC.ORG_REM_CHANNEL_CD
, SOC.ORG_CHANNEL_CD
, SOC.ORG_SUB_CHANNEL_CD
, SOC.ORG_SUB_SUB_CHANNEL_CD
, SOC.ORG_GT_ACTIVITY
, SOC.ORG_FIDELISATION
, SOC.ORG_WEB_ACTIVITY
, SOC.ORG_AUTO_ACTIVITY
, SOC.ORG_EDO_ID
, SOC.ORG_TYPE_EDO
, SOC.ORG_EDO_IOBSP
, SOC.ORG_FLAG_PLT_CONV
, SOC.ORG_FLAG_TEAM_MKT
, SOC.ORG_FLAG_TYPE_CMP
, SOC.ORG_RESP_EDO_ID
, SOC.ORG_RESP_TYPE_EDO
, SOC.ORG_RESP_FLAG_PLT_CONV
, SOC.ACTIVITY_CD
, SOC.ACTIVITY_GROUPNG_CD
, SOC.AUTO_ACTIVITY_IN
, SOC.ORG_TYPE_CD
, SOC.ORG_TEAM_TYPE_ID
, SOC.ORG_TEAM_LEVEL_1_CD
, SOC.ORG_TEAM_LEVEL_1_DS
, SOC.ORG_TEAM_LEVEL_2_CD
, SOC.ORG_TEAM_LEVEL_2_DS
, SOC.ORG_TEAM_LEVEL_3_CD
, SOC.ORG_TEAM_LEVEL_3_DS
, SOC.ORG_TEAM_LEVEL_4_CD
, SOC.ORG_TEAM_LEVEL_4_DS
, SOC.WORK_TEAM_LEVEL_1_CD
, SOC.WORK_TEAM_LEVEL_1_DS
, SOC.WORK_TEAM_LEVEL_2_CD
, SOC.WORK_TEAM_LEVEL_2_DS
, SOC.WORK_TEAM_LEVEL_3_CD
, SOC.WORK_TEAM_LEVEL_3_DS
, SOC.WORK_TEAM_LEVEL_4_CD
, SOC.WORK_TEAM_LEVEL_4_DS
, SOC.CONFIRMATION_IN
, SOC.CONCLDD_IN
, SOC.COMPTTN_IN
, SOC.COMPTTN_ID
, SOC.PERNNT_IN
, SOC.PERNNT_END_DT
, SOC.PERNNT_MOTIF
, SOC.PERNNT_CALC_END_DT
, SOC.MIGRA_DT
, SOC.MIGRA_NEXT_OFFRE
, SOC.PRES_SEGMENT_IN_PARK_BEFORE_IN
, SOC.SEGMENT_DELIVERY_IN_PARK_DT
, SOC.ORDER_CANCELING_DT
, SOC.LINE_ID
, SOC.MASTER_LINE_ID
, SOC.CUST_TYPE_CD
, SOC.MSISDN_ID
, SOC.NDS_VALUE_DS
, SOC.EXTERNAL_PARTY_ID
, SOC.RES_VALUE_DS
, SOC.PAR_ACCES_SERVICE
, SOC.TAC_CD
, SOC.IMEI_CD
, SOC.IMSI_CD
, SOC.HOM_START_DT
, SOC.MOB_START_DT
, SOC.I_SCORE_VALUE
, SOC.I_SCORE_TRESHOLD
, SOC.I_SCORE_IN
, SOC.M_SCORE_VALUE
, SOC.M_SCORE_TRESHOLD
, SOC.M_SCORE_IN
, SOC.OSCAR_VALUE
, SOC.CUST_BU_TYPE_CD
, SOC.CUST_BU_CD
, SOC.ADDRESS_TYPE
, SOC.ADDRESS_CONCAT_NM
, SOC.POSTAL_CD
, SOC.INSEE_CD
, SOC.BU_CD
, SOC.DEPARTMNT_ID
, SOC.PAR_GEO_MACROZONE
, SOC.PAR_UNIFIED_PARTY_ID
, SOC.PAR_PARTY_REGRPMNT_ID
, SOC.PAR_CID_ID
, SOC.PAR_PID_ID
, SOC.PAR_FIRST_IN
, SOC.PAR_IRIS2000_CD
, SOC.COMMARTICLE_RP_REFPRIX_CD
, SOC.ACT_CA_LINE_AM
, SOC.ACT_CA_TTC_AM
, SOC.EAN_CD
, SOC.SIM_CD
, SOC.SIM_EAN_CD
, SOC.ORG_RESP_ID
, SOC.EAN_PREVIOUS_CD
, SOC.TAC_PREVIOUS_CD
, SOC.IMEI_PREVIOUS_CD
, SOC.PCM_PREVIOUS_OFFRE_CD
, SOC.PCM_COMMTMNT_PERIOD_NU
, SOC.PCM_LEVEL_POINT_NU
, SOC.PCM_OFFRE_CD
, SOC.PCM_EFFCTV_NEXT_OFFRE_DT
, SOC.PCM_TYPE_OFFRE_MOBILE_CD
, SOC.PCM_POINT_UTIL_NU
, SOC.PCM_BALANCE_POINT_NU
, SOC.PCM_STATUT_POINT_CD
, SOC.PCM_POINT_DUE_NU
, SOC.PAR_ELIGIBLE_FIBER_IN
, SOC.CHECK_INITIAL_STATUS_CD
, SOC.CHECK_NAT_STATUS_CD
, SOC.CHECK_NAT_COMMENT
, SOC.CHECK_NAT_STATUS_LN
, SOC.CHECK_LOC_STATUS_CD
, SOC.CHECK_LOC_COMMENT
, SOC.CHECK_LOC_STATUS_LN
, SOC.CHECK_VALIDT_DT
, SOC.ACT_END_UNIFIED_DT
, SOC.ACT_END_UNIFIED_DS
, SOC.ACT_CLOSURE_DT
, SOC.ACT_CLOSURE_DS
, SOC.HOT_IN
, SOC.RUN_ID
, SOC.CREATION_TS
, SOC.LAST_MODIF_TS
, SOC.FRESH_IN
, SOC.COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED SOC 
Inner Join 
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
) SRC
   On  SOC.ACTE_ID = SRC.${SourceSoc}_ACTE_ID 
  And SOC.INTRNL_SOURCE_ID = '${SourceEnrId}' 
  And SOC.TYPE_SOURCE_ID In ( '${SourceEnrTyp}' )
Qualify Row_Number() Over (Partition by SOC.ACTE_ID Order by SOC.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1;

-- Enrichissement Esclave depuis maître

Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
     ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} SRC
Set
  MASTER_ACTE_ID = SRC.MASTER_ACTE_ID,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID,
  MASTER_FLAG = ${P_PIL_355},
  MASTER_NB_FOUND = SRC.MASTER_NB_FOUND,
  RULE_ID = SRC.RULE_ID,
  OFFSET_NB = SRC.OFFSET,
  CPLT_ACTE_ID = Null,
  CPLT_INTRNL_SOURCE_ID = Null,
  CPLT_IN = '${P_PIL_388}' 
Where (1=1)
  And CIB.ACTE_ID = SRC.SLAVE_ACTE_ID;
.if errorcode <> 0 then .quit 1;

-- Enrichissement Maître non Omnicanal

Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(

  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET Asc, OFFSET_SEC Asc ) = 1
) SRC
Set
  MASTER_ACTE_ID          = SRC.MASTER_ACTE_ID            ,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID          ,
  MASTER_FLAG             = ${P_PIL_354}                  ,
  RULE_ID                 = SRC.RULE_ID                   ,
  OFFSET_NB               = SRC.OFFSET                    ,
  CPLT_ACTE_ID            = SRC.SLAVE_ACTE_ID             ,
  CPLT_INTRNL_SOURCE_ID   = SRC.SLAVE_SOURCE_ID           ,
  CPLT_IN                 = '${P_PIL_356}'                ,
  AGENT_ID                = SRC.AGENT_ID                  ,
  ORG_AGENT_IOBSP         = SRC.ORG_AGENT_IOBSP           ,
  AGENT_ID_UPD            = SRC.AGENT_ID_UPD              ,
  AGENT_ID_UPD_DT         = SRC.AGENT_ID_UPD_DT           ,
  AGENT_FIRST_NAME        = SRC.AGENT_FIRST_NAME          ,
  AGENT_LAST_NAME         = SRC.AGENT_LAST_NAME           ,
  ORG_SPE_CANAL_ID_MACRO  = SRC.ORG_SPE_CANAL_ID_MACRO    ,
  ORG_SPE_CANAL_ID        = SRC.ORG_SPE_CANAL_ID          ,
  ORIGIN_CD               = SRC.ORIGIN_CD                 ,
  ORG_REM_CHANNEL_CD      = SRC.ORG_REM_CHANNEL_CD        ,
  ORG_CHANNEL_CD          = SRC.ORG_CHANNEL_CD            ,
  ORG_SUB_CHANNEL_CD      = SRC.ORG_SUB_CHANNEL_CD        ,
  ORG_EDO_ID              = SRC.ORG_EDO_ID                ,
  ORG_TYPE_EDO            = SRC.ORG_TYPE_EDO              ,
  ORG_EDO_IOBSP           = SRC.ORG_EDO_IOBSP             ,
  ORG_FLAG_PLT_CONV       = SRC.ORG_FLAG_PLT_CONV         ,
  ORG_FLAG_TEAM_MKT       = SRC.ORG_FLAG_TEAM_MKT         ,
  ORG_FLAG_TYPE_CMP       = SRC.ORG_FLAG_TYPE_CMP         ,
  ORG_RESP_EDO_ID         = SRC.ORG_RESP_EDO_ID           ,
  ORG_RESP_TYPE_EDO       = SRC.ORG_RESP_TYPE_EDO         ,
  ORG_RESP_FLAG_PLT_CONV  = SRC.ORG_RESP_FLAG_PLT_CONV    ,
  ORG_SUB_SUB_CHANNEL_CD  = SRC.ORG_SUB_SUB_CHANNEL_CD    ,
  ORG_GT_ACTIVITY         = SRC.ORG_GT_ACTIVITY           ,
  ORG_FIDELISATION        = SRC.ORG_FIDELISATION          ,
  ORG_WEB_ACTIVITY        = SRC.ORG_WEB_ACTIVITY          ,
  ORG_AUTO_ACTIVITY       = SRC.ORG_AUTO_ACTIVITY         ,
  ORG_TYPE_CD             = SRC.ORG_TYPE_CD               ,
  ORG_TEAM_TYPE_ID        = SRC.ORG_TEAM_TYPE_ID          ,
  ORG_TEAM_LEVEL_1_CD     = SRC.ORG_TEAM_LEVEL_1_CD       ,
  ORG_TEAM_LEVEL_1_DS     = SRC.ORG_TEAM_LEVEL_1_DS       ,
  ORG_TEAM_LEVEL_2_CD     = SRC.ORG_TEAM_LEVEL_2_CD       ,
  ORG_TEAM_LEVEL_2_DS     = SRC.ORG_TEAM_LEVEL_2_DS       ,
  ORG_TEAM_LEVEL_3_CD     = SRC.ORG_TEAM_LEVEL_3_CD       ,
  ORG_TEAM_LEVEL_3_DS     = SRC.ORG_TEAM_LEVEL_3_DS       ,
  ORG_TEAM_LEVEL_4_CD     = SRC.ORG_TEAM_LEVEL_4_CD       ,
  ORG_TEAM_LEVEL_4_DS     = SRC.ORG_TEAM_LEVEL_4_DS       ,
  WORK_TEAM_LEVEL_1_CD    = SRC.WORK_TEAM_LEVEL_1_CD      ,
  WORK_TEAM_LEVEL_1_DS    = SRC.WORK_TEAM_LEVEL_1_DS      ,
  WORK_TEAM_LEVEL_2_CD    = SRC.WORK_TEAM_LEVEL_2_CD      ,
  WORK_TEAM_LEVEL_2_DS    = SRC.WORK_TEAM_LEVEL_2_DS      ,
  WORK_TEAM_LEVEL_3_CD    = SRC.WORK_TEAM_LEVEL_3_CD      ,
  WORK_TEAM_LEVEL_3_DS    = SRC.WORK_TEAM_LEVEL_3_DS      ,
  WORK_TEAM_LEVEL_4_CD    = SRC.WORK_TEAM_LEVEL_4_CD      ,
  WORK_TEAM_LEVEL_4_DS    = SRC.WORK_TEAM_LEVEL_4_DS      
Where (1=1)
  And CIB.ACTE_ID           =   SRC.MASTER_ACTE_ID
  And CIB.ORG_WEB_ACTIVITY  <>  'Omnicanal';
.if errorcode <> 0 then .quit 1;


-- Enrichissement Maître Omnicanal
Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(

  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET Asc, OFFSET_SEC Asc ) = 1
) SRC
Set
  MASTER_ACTE_ID          = SRC.MASTER_ACTE_ID            ,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID          ,
  MASTER_FLAG             = ${P_PIL_354}                  ,
  RULE_ID                 = SRC.RULE_ID                   ,
  OFFSET_NB               = SRC.OFFSET                    ,
  CPLT_ACTE_ID            = SRC.SLAVE_ACTE_ID             ,
  CPLT_INTRNL_SOURCE_ID   = SRC.SLAVE_SOURCE_ID           ,
  CPLT_IN                 = '${P_PIL_356}'                

Where (1=1)
  And CIB.ACTE_ID           =   SRC.MASTER_ACTE_ID
  And CIB.ORG_WEB_ACTIVITY  =   'Omnicanal';
.if errorcode <> 0 then .quit 1;




-- Enrichissement Maître RVOI QC 449

-- Pour être complet on réinjecte les commandes soft RVOI à croiser
------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim}
(
  ACTE_ID
, OPERATOR_PROVIDER_ID
, INTRNL_SOURCE_ID
, TYPE_SOURCE_ID
, MASTER_ACTE_ID
, MASTER_INTRNL_SOURCE_ID
, MASTER_FLAG
, MASTER_NB_FOUND
, CPLT_ACTE_ID
, CPLT_INTRNL_SOURCE_ID
, CPLT_IN
, RULE_ID
, OFFSET_NB
, ACT_TYPE
, ORDER_EXTERNAL_ID
, STATUS_CD
, ACT_UNIFIED_STATUS_CD
, ACT_TS
, ACT_DT
, ACT_HH
, ACT_LAST_UPD_TS
, ACT_PRODUCT_ID_PRE
, ACT_SEG_COM_ID_PRE
, ACT_SEG_COM_AGG_ID_PRE
, ACT_CODE_MIGR_PRE
, ACT_OPER_ID_PRE
, ACT_PRODUCT_ID_FINAL
, ACT_SEG_COM_ID_FINAL
, ACT_SEG_COM_AGG_ID_FINAL
, ACT_CODE_MIGR_FINAL
, ACT_OPER_ID_FINAL
, ACT_TYPE_SERVICE_FINAL
, ACT_TYPE_COMMANDE_ID
, ACT_DELTA_TARIF
, ACT_CD
, ACT_REM_ID
, ACT_FLAG_ACT_REM
, ACT_FLAG_PEC_PERPVC
, ACT_FLAG_PVC_REM
, ACT_ACTE_VALO
, ACT_ACTE_FAMILLE_KPI
, ACT_PERIODE_ID
, ACT_PERIODE_STATUS
, ACT_PERIODE_CLOSURE_DT
, ORIGIN_CD
, AGENT_ID
, AGENT_ID_UPD
, AGENT_ID_UPD_DT
, ORG_AGENT_IOBSP
, AGENT_FIRST_NAME
, AGENT_LAST_NAME
, UNIFIED_SHOP_CD
, ORG_SPE_CANAL_ID_MACRO
, ORG_SPE_CANAL_ID
, ORG_REM_CHANNEL_CD
, ORG_CHANNEL_CD
, ORG_SUB_CHANNEL_CD
, ORG_SUB_SUB_CHANNEL_CD
, ORG_GT_ACTIVITY
, ORG_FIDELISATION
, ORG_WEB_ACTIVITY
, ORG_AUTO_ACTIVITY
, ORG_EDO_ID
, ORG_TYPE_EDO
, ORG_EDO_IOBSP
, ORG_FLAG_PLT_CONV
, ORG_FLAG_TEAM_MKT
, ORG_FLAG_TYPE_CMP
, ORG_RESP_EDO_ID
, ORG_RESP_TYPE_EDO
, ORG_RESP_FLAG_PLT_CONV
, ACTIVITY_CD
, ACTIVITY_GROUPNG_CD
, AUTO_ACTIVITY_IN
, ORG_TYPE_CD
, ORG_TEAM_TYPE_ID
, ORG_TEAM_LEVEL_1_CD
, ORG_TEAM_LEVEL_1_DS
, ORG_TEAM_LEVEL_2_CD
, ORG_TEAM_LEVEL_2_DS
, ORG_TEAM_LEVEL_3_CD
, ORG_TEAM_LEVEL_3_DS
, ORG_TEAM_LEVEL_4_CD
, ORG_TEAM_LEVEL_4_DS
, WORK_TEAM_LEVEL_1_CD
, WORK_TEAM_LEVEL_1_DS
, WORK_TEAM_LEVEL_2_CD
, WORK_TEAM_LEVEL_2_DS
, WORK_TEAM_LEVEL_3_CD
, WORK_TEAM_LEVEL_3_DS
, WORK_TEAM_LEVEL_4_CD
, WORK_TEAM_LEVEL_4_DS
, CONFIRMATION_IN
, CONCLDD_IN
, COMPTTN_IN
, COMPTTN_ID
, PERNNT_IN
, PERNNT_END_DT
, PERNNT_MOTIF
, PERNNT_CALC_END_DT
, MIGRA_DT
, MIGRA_NEXT_OFFRE
, PRES_SEGMENT_IN_PARK_BEFORE_IN
, SEGMENT_DELIVERY_IN_PARK_DT
, ORDER_CANCELING_DT
, LINE_ID
, MASTER_LINE_ID
, CUST_TYPE_CD
, MSISDN_ID
, NDS_VALUE_DS
, EXTERNAL_PARTY_ID
, RES_VALUE_DS
, PAR_ACCES_SERVICE
, TAC_CD
, IMEI_CD
, IMSI_CD
, HOM_START_DT
, MOB_START_DT
, I_SCORE_VALUE
, I_SCORE_TRESHOLD
, I_SCORE_IN
, M_SCORE_VALUE
, M_SCORE_TRESHOLD
, M_SCORE_IN
, OSCAR_VALUE
, CUST_BU_TYPE_CD
, CUST_BU_CD
, ADDRESS_TYPE
, ADDRESS_CONCAT_NM
, POSTAL_CD
, INSEE_CD
, BU_CD
, DEPARTMNT_ID
, PAR_GEO_MACROZONE
, PAR_UNIFIED_PARTY_ID
, PAR_PARTY_REGRPMNT_ID
, PAR_CID_ID
, PAR_PID_ID
, PAR_FIRST_IN
, PAR_IRIS2000_CD
, COMMARTICLE_RP_REFPRIX_CD
, ACT_CA_LINE_AM
, ACT_CA_TTC_AM
, EAN_CD
, SIM_CD
, SIM_EAN_CD
, ORG_RESP_ID
, EAN_PREVIOUS_CD
, TAC_PREVIOUS_CD
, IMEI_PREVIOUS_CD
, PCM_PREVIOUS_OFFRE_CD
, PCM_COMMTMNT_PERIOD_NU
, PCM_LEVEL_POINT_NU
, PCM_OFFRE_CD
, PCM_EFFCTV_NEXT_OFFRE_DT
, PCM_TYPE_OFFRE_MOBILE_CD
, PCM_POINT_UTIL_NU
, PCM_BALANCE_POINT_NU
, PCM_STATUT_POINT_CD
, PCM_POINT_DUE_NU
, PAR_ELIGIBLE_FIBER_IN
, CHECK_INITIAL_STATUS_CD
, CHECK_NAT_STATUS_CD
, CHECK_NAT_COMMENT
, CHECK_NAT_STATUS_LN
, CHECK_LOC_STATUS_CD
, CHECK_LOC_COMMENT
, CHECK_LOC_STATUS_LN
, CHECK_VALIDT_DT
, ACT_END_UNIFIED_DT
, ACT_END_UNIFIED_DS
, ACT_CLOSURE_DT
, ACT_CLOSURE_DS
, HOT_IN
, RUN_ID
, CREATION_TS
, LAST_MODIF_TS
, FRESH_IN
, COHERENCE_IN)
Select
  SOC.ACTE_ID
, SOC.OPERATOR_PROVIDER_ID
, SOC.INTRNL_SOURCE_ID
, SOC.TYPE_SOURCE_ID
, SOC.MASTER_ACTE_ID
, SOC.MASTER_INTRNL_SOURCE_ID
, SOC.MASTER_FLAG
, SOC.MASTER_NB_FOUND
, SOC.CPLT_ACTE_ID
, SOC.CPLT_INTRNL_SOURCE_ID
, SOC.CPLT_IN
, SOC.RULE_ID
, SOC.OFFSET_NB
, SOC.ACT_TYPE
, SOC.ORDER_EXTERNAL_ID
, SOC.STATUS_CD
, SOC.ACT_UNIFIED_STATUS_CD
, SOC.ACT_TS
, SOC.ACT_DT
, SOC.ACT_HH
, SOC.ACT_LAST_UPD_TS
, SOC.ACT_PRODUCT_ID_PRE
, SOC.ACT_SEG_COM_ID_PRE
, SOC.ACT_SEG_COM_AGG_ID_PRE
, SOC.ACT_CODE_MIGR_PRE
, SOC.ACT_OPER_ID_PRE
, SOC.ACT_PRODUCT_ID_FINAL
, SOC.ACT_SEG_COM_ID_FINAL
, SOC.ACT_SEG_COM_AGG_ID_FINAL
, SOC.ACT_CODE_MIGR_FINAL
, SOC.ACT_OPER_ID_FINAL
, SOC.ACT_TYPE_SERVICE_FINAL
, SOC.ACT_TYPE_COMMANDE_ID
, SOC.ACT_DELTA_TARIF
, SOC.ACT_CD
, SOC.ACT_REM_ID
, SOC.ACT_FLAG_ACT_REM
, SOC.ACT_FLAG_PEC_PERPVC
, SOC.ACT_FLAG_PVC_REM
, SOC.ACT_ACTE_VALO
, SOC.ACT_ACTE_FAMILLE_KPI
, SOC.ACT_PERIODE_ID
, SOC.ACT_PERIODE_STATUS
, SOC.ACT_PERIODE_CLOSURE_DT
, SOC.ORIGIN_CD
, SOC.AGENT_ID
, SOC.AGENT_ID_UPD
, SOC.AGENT_ID_UPD_DT
, SOC.ORG_AGENT_IOBSP
, SOC.AGENT_FIRST_NAME
, SOC.AGENT_LAST_NAME
, SOC.UNIFIED_SHOP_CD
, SOC.ORG_SPE_CANAL_ID_MACRO
, SOC.ORG_SPE_CANAL_ID
, SOC.ORG_REM_CHANNEL_CD
, SOC.ORG_CHANNEL_CD
, SOC.ORG_SUB_CHANNEL_CD
, SOC.ORG_SUB_SUB_CHANNEL_CD
, SOC.ORG_GT_ACTIVITY
, SOC.ORG_FIDELISATION
, SOC.ORG_WEB_ACTIVITY
, SOC.ORG_AUTO_ACTIVITY
, SOC.ORG_EDO_ID
, SOC.ORG_TYPE_EDO
, SOC.ORG_EDO_IOBSP
, SOC.ORG_FLAG_PLT_CONV
, SOC.ORG_FLAG_TEAM_MKT
, SOC.ORG_FLAG_TYPE_CMP
, SOC.ORG_RESP_EDO_ID
, SOC.ORG_RESP_TYPE_EDO
, SOC.ORG_RESP_FLAG_PLT_CONV
, SOC.ACTIVITY_CD
, SOC.ACTIVITY_GROUPNG_CD
, SOC.AUTO_ACTIVITY_IN
, SOC.ORG_TYPE_CD
, SOC.ORG_TEAM_TYPE_ID
, SOC.ORG_TEAM_LEVEL_1_CD
, SOC.ORG_TEAM_LEVEL_1_DS
, SOC.ORG_TEAM_LEVEL_2_CD
, SOC.ORG_TEAM_LEVEL_2_DS
, SOC.ORG_TEAM_LEVEL_3_CD
, SOC.ORG_TEAM_LEVEL_3_DS
, SOC.ORG_TEAM_LEVEL_4_CD
, SOC.ORG_TEAM_LEVEL_4_DS
, SOC.WORK_TEAM_LEVEL_1_CD
, SOC.WORK_TEAM_LEVEL_1_DS
, SOC.WORK_TEAM_LEVEL_2_CD
, SOC.WORK_TEAM_LEVEL_2_DS
, SOC.WORK_TEAM_LEVEL_3_CD
, SOC.WORK_TEAM_LEVEL_3_DS
, SOC.WORK_TEAM_LEVEL_4_CD
, SOC.WORK_TEAM_LEVEL_4_DS
, SOC.CONFIRMATION_IN
, SOC.CONCLDD_IN
, SOC.COMPTTN_IN
, SOC.COMPTTN_ID
, SOC.PERNNT_IN
, SOC.PERNNT_END_DT
, SOC.PERNNT_MOTIF
, SOC.PERNNT_CALC_END_DT
, SOC.MIGRA_DT
, SOC.MIGRA_NEXT_OFFRE
, SOC.PRES_SEGMENT_IN_PARK_BEFORE_IN
, SOC.SEGMENT_DELIVERY_IN_PARK_DT
, SOC.ORDER_CANCELING_DT
, SOC.LINE_ID
, SOC.MASTER_LINE_ID
, SOC.CUST_TYPE_CD
, SOC.MSISDN_ID
, SOC.NDS_VALUE_DS
, SOC.EXTERNAL_PARTY_ID
, SOC.RES_VALUE_DS
, SOC.PAR_ACCES_SERVICE
, SOC.TAC_CD
, SOC.IMEI_CD
, SOC.IMSI_CD
, SOC.HOM_START_DT
, SOC.MOB_START_DT
, SOC.I_SCORE_VALUE
, SOC.I_SCORE_TRESHOLD
, SOC.I_SCORE_IN
, SOC.M_SCORE_VALUE
, SOC.M_SCORE_TRESHOLD
, SOC.M_SCORE_IN
, SOC.OSCAR_VALUE
, SOC.CUST_BU_TYPE_CD
, SOC.CUST_BU_CD
, SOC.ADDRESS_TYPE
, SOC.ADDRESS_CONCAT_NM
, SOC.POSTAL_CD
, SOC.INSEE_CD
, SOC.BU_CD
, SOC.DEPARTMNT_ID
, SOC.PAR_GEO_MACROZONE
, SOC.PAR_UNIFIED_PARTY_ID
, SOC.PAR_PARTY_REGRPMNT_ID
, SOC.PAR_CID_ID
, SOC.PAR_PID_ID
, SOC.PAR_FIRST_IN
, SOC.PAR_IRIS2000_CD
, SOC.COMMARTICLE_RP_REFPRIX_CD
, SOC.ACT_CA_LINE_AM
, SOC.ACT_CA_TTC_AM
, SOC.EAN_CD
, SOC.SIM_CD
, SOC.SIM_EAN_CD
, SOC.ORG_RESP_ID
, SOC.EAN_PREVIOUS_CD
, SOC.TAC_PREVIOUS_CD
, SOC.IMEI_PREVIOUS_CD
, SOC.PCM_PREVIOUS_OFFRE_CD
, SOC.PCM_COMMTMNT_PERIOD_NU
, SOC.PCM_LEVEL_POINT_NU
, SOC.PCM_OFFRE_CD
, SOC.PCM_EFFCTV_NEXT_OFFRE_DT
, SOC.PCM_TYPE_OFFRE_MOBILE_CD
, SOC.PCM_POINT_UTIL_NU
, SOC.PCM_BALANCE_POINT_NU
, SOC.PCM_STATUT_POINT_CD
, SOC.PCM_POINT_DUE_NU
, SOC.PAR_ELIGIBLE_FIBER_IN
, SOC.CHECK_INITIAL_STATUS_CD
, SOC.CHECK_NAT_STATUS_CD
, SOC.CHECK_NAT_COMMENT
, SOC.CHECK_NAT_STATUS_LN
, SOC.CHECK_LOC_STATUS_CD
, SOC.CHECK_LOC_COMMENT
, SOC.CHECK_LOC_STATUS_LN
, SOC.CHECK_VALIDT_DT
, SOC.ACT_END_UNIFIED_DT
, SOC.ACT_END_UNIFIED_DS
, SOC.ACT_CLOSURE_DT
, SOC.ACT_CLOSURE_DS
, SOC.HOT_IN
, SOC.RUN_ID
, SOC.CREATION_TS
, SOC.LAST_MODIF_TS
, SOC.FRESH_IN
, SOC.COHERENCE_IN
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED SOC
Where
  (1=1)
  -- On selectionne les commandes SOFT pour les enrichissement RVPO
  And SOC.INTRNL_SOURCE_ID                  =1
  And SOC.MSISDN_ID                         Is Not Null
  And SOC.ORG_SPE_CANAL_ID                  In (${L_PIL_047})
  And SubStr(SOC.ACT_SEG_COM_ID_PRE,1,4)    In ('IOPE','SOSH')
  And SubStr(SOC.ACT_SEG_COM_ID_FINAL,1,4)  In ('LB_Z','LB_P')
  And SOC.AGENT_ID_UPD                      Is Null
  And SOC.ACT_DT                            >= (Current_Date -200)
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} Tmp
    Where
      (1=1)
      And SOC.ACTE_ID     = Tmp.ACTE_ID
  )
Qualify Row_Number() Over (Partition by SOC.ACTE_ID Order by SOC.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1;



Update Soft2
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} Soft2,
(
  Select 
    Soft.ACTE_ID                                                                As ACTE_ID_SOFT               ,
    Cho.ACTE_ID                                                                 As ACTE_ID                    ,
    Cho.AGENT_ID                                                                As AGENT_ID                   ,
    Cho.ORG_AGENT_IOBSP                                                         As ORG_AGENT_IOBSP            ,
    Cho.AGENT_ID_UPD                                                            As AGENT_ID_UPD               ,
    Cho.AGENT_ID_UPD_DT                                                         As AGENT_ID_UPD_DT            ,
    Cho.AGENT_FIRST_NAME                                                        As AGENT_FIRST_NAME           ,
    Cho.AGENT_LAST_NAME                                                         As AGENT_LAST_NAME            ,
    Cho.ORG_SPE_CANAL_ID_MACRO                                                  As ORG_SPE_CANAL_ID_MACRO     ,
    Cho.ORG_SPE_CANAL_ID                                                        As ORG_SPE_CANAL_ID           ,
    Cho.ORIGIN_CD                                                               As ORIGIN_CD                  ,
    Cho.ORG_REM_CHANNEL_CD                                                      As ORG_REM_CHANNEL_CD         ,
    Cho.ORG_CHANNEL_CD                                                          As ORG_CHANNEL_CD             ,
    Cho.ORG_SUB_CHANNEL_CD                                                      As ORG_SUB_CHANNEL_CD         ,
    Cho.ORG_SUB_SUB_CHANNEL_CD                                                  As ORG_SUB_SUB_CHANNEL_CD     ,
    Cho.ORG_EDO_ID                                                              As ORG_EDO_ID                 ,
    Cho.ORG_TYPE_EDO                                                            As ORG_TYPE_EDO               ,
    Cho.ORG_EDO_IOBSP                                                           As ORG_EDO_IOBSP              ,
    Cho.ORG_FLAG_PLT_CONV                                                       As ORG_FLAG_PLT_CONV          ,
    Cho.ORG_FLAG_TEAM_MKT                                                       As ORG_FLAG_TEAM_MKT          ,
    Cho.ORG_FLAG_TYPE_CMP                                                       As ORG_FLAG_TYPE_CMP          ,
    Cho.ORG_RESP_EDO_ID                                                         As ORG_RESP_EDO_ID            ,
    Cho.ORG_RESP_TYPE_EDO                                                       As ORG_RESP_TYPE_EDO          ,
    Cho.ORG_RESP_FLAG_PLT_CONV                                                  As ORG_RESP_FLAG_PLT_CONV     ,
    Cho.ORG_GT_ACTIVITY                                                         As ORG_GT_ACTIVITY            ,
    Cho.ORG_FIDELISATION                                                        As ORG_FIDELISATION           ,
    Cho.ORG_WEB_ACTIVITY                                                        As ORG_WEB_ACTIVITY           ,
    Cho.ORG_AUTO_ACTIVITY                                                       As ORG_AUTO_ACTIVITY          ,
    Cho.ORG_TYPE_CD                                                             As ORG_TYPE_CD                ,
    Cho.ORG_TEAM_TYPE_ID                                                        As ORG_TEAM_TYPE_ID           ,
    Cho.ORG_TEAM_LEVEL_1_CD                                                     As ORG_TEAM_LEVEL_1_CD        ,
    Cho.ORG_TEAM_LEVEL_1_DS                                                     As ORG_TEAM_LEVEL_1_DS        ,
    Cho.ORG_TEAM_LEVEL_2_CD                                                     As ORG_TEAM_LEVEL_2_CD        ,
    Cho.ORG_TEAM_LEVEL_2_DS                                                     As ORG_TEAM_LEVEL_2_DS        ,
    Cho.ORG_TEAM_LEVEL_3_CD                                                     As ORG_TEAM_LEVEL_3_CD        ,
    Cho.ORG_TEAM_LEVEL_3_DS                                                     As ORG_TEAM_LEVEL_3_DS        ,
    Cho.ORG_TEAM_LEVEL_4_CD                                                     As ORG_TEAM_LEVEL_4_CD        ,
    Cho.ORG_TEAM_LEVEL_4_DS                                                     As ORG_TEAM_LEVEL_4_DS        ,
    Cho.WORK_TEAM_LEVEL_1_CD                                                    As WORK_TEAM_LEVEL_1_CD       ,
    Cho.WORK_TEAM_LEVEL_1_DS                                                    As WORK_TEAM_LEVEL_1_DS       ,
    Cho.WORK_TEAM_LEVEL_2_CD                                                    As WORK_TEAM_LEVEL_2_CD       ,
    Cho.WORK_TEAM_LEVEL_2_DS                                                    As WORK_TEAM_LEVEL_2_DS       ,
    Cho.WORK_TEAM_LEVEL_3_CD                                                    As WORK_TEAM_LEVEL_3_CD       ,
    Cho.WORK_TEAM_LEVEL_3_DS                                                    As WORK_TEAM_LEVEL_3_DS       ,
    Cho.WORK_TEAM_LEVEL_4_CD                                                    As WORK_TEAM_LEVEL_4_CD       ,
    Cho.WORK_TEAM_LEVEL_4_DS                                                    As WORK_TEAM_LEVEL_4_DS       ,
    Cho.INTRNL_SOURCE_ID                                                        As INTRNL_SOURCE_ID       
  From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED  cho
  Inner join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Soft
  On Soft.MSISDN_ID=Cho.MSISDN_ID
  --Avec une date à plus ou moins 48h de lacte Soft
  And abs(Soft.ACT_DT - Cho.ACT_DT) <= 2
  Where (1=1)
    And cho.INTRNL_SOURCE_ID=2 
    And substr(cho.ACT_SEG_COM_ID_PRE,1,4) in ('OPEN','SOSH')  
    And Soft.INTRNL_SOURCE_ID=1 
    And Soft.ORG_SPE_CANAL_ID IN (${L_PIL_047})
    And substr(Soft.ACT_SEG_COM_ID_PRE,1,4) in ('IOPE','SOSH')
    And substr(Soft.ACT_SEG_COM_ID_FINAL,1,4) in ('LB_Z','LB_P')
    And Soft.AGENT_ID_UPD Is Null
  QUALIFY ROW_NUMBER() OVER(PARTITION BY Soft.ACTE_ID ORDER BY abs(Soft.ACT_DT- Cho.ACT_DT) ASC) = 1
) Cho2
Set
  CPLT_ACTE_ID            =Cho2.ACTE_ID                     ,
  CPLT_IN                 = '${P_PIL_356}'                  ,
  --A voir le Numero de la règle
  RULE_ID                 = 40                              ,
  AGENT_ID                = Cho2.AGENT_ID                   ,
  ORG_AGENT_IOBSP         = Cho2.ORG_AGENT_IOBSP            ,
  AGENT_ID_UPD            = Cho2.AGENT_ID_UPD               ,
  AGENT_ID_UPD_DT         = Cho2.AGENT_ID_UPD_DT            ,
  AGENT_FIRST_NAME        = Cho2.AGENT_FIRST_NAME           ,
  AGENT_LAST_NAME         = Cho2.AGENT_LAST_NAME            ,
  ORG_SPE_CANAL_ID_MACRO  = Cho2.ORG_SPE_CANAL_ID_MACRO     ,
  ORG_SPE_CANAL_ID        = Cho2.ORG_SPE_CANAL_ID           ,
  ORIGIN_CD               = Cho2.ORIGIN_CD                  ,
  ORG_REM_CHANNEL_CD      = Cho2.ORG_REM_CHANNEL_CD         ,
  ORG_CHANNEL_CD          = Cho2.ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD      = Cho2.ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD  = Cho2.ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_EDO_ID              = Cho2.ORG_EDO_ID                 ,
  ORG_TYPE_EDO            = Cho2.ORG_TYPE_EDO               ,
  ORG_EDO_IOBSP           = Cho2.ORG_EDO_IOBSP              ,
  ORG_FLAG_PLT_CONV       = Cho2.ORG_FLAG_PLT_CONV          ,
  ORG_FLAG_TEAM_MKT       = Cho2.ORG_FLAG_TEAM_MKT          ,
  ORG_FLAG_TYPE_CMP       = Cho2.ORG_FLAG_TYPE_CMP          ,
  ORG_RESP_EDO_ID         = Cho2.ORG_RESP_EDO_ID            ,
  ORG_RESP_TYPE_EDO       = Cho2.ORG_RESP_TYPE_EDO          ,
  ORG_RESP_FLAG_PLT_CONV  = Cho2.ORG_RESP_FLAG_PLT_CONV     ,
  ORG_GT_ACTIVITY         = Cho2.ORG_GT_ACTIVITY            ,
  ORG_FIDELISATION        = Cho2.ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY        = Cho2.ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY       = Cho2.ORG_AUTO_ACTIVITY          ,
  ORG_TYPE_CD             = Cho2.ORG_TYPE_CD                ,
  ORG_TEAM_TYPE_ID        = Cho2.ORG_TEAM_TYPE_ID           ,
  ORG_TEAM_LEVEL_1_CD     = Cho2.ORG_TEAM_LEVEL_1_CD        ,
  ORG_TEAM_LEVEL_1_DS     = Cho2.ORG_TEAM_LEVEL_1_DS        ,
  ORG_TEAM_LEVEL_2_CD     = Cho2.ORG_TEAM_LEVEL_2_CD        ,
  ORG_TEAM_LEVEL_2_DS     = Cho2.ORG_TEAM_LEVEL_2_DS        ,
  ORG_TEAM_LEVEL_3_CD     = Cho2.ORG_TEAM_LEVEL_3_CD        ,
  ORG_TEAM_LEVEL_3_DS     = Cho2.ORG_TEAM_LEVEL_3_DS        ,
  ORG_TEAM_LEVEL_4_CD     = Cho2.ORG_TEAM_LEVEL_4_CD        ,
  ORG_TEAM_LEVEL_4_DS     = Cho2.ORG_TEAM_LEVEL_4_DS        ,
  WORK_TEAM_LEVEL_1_CD    = Cho2.WORK_TEAM_LEVEL_1_CD       ,
  WORK_TEAM_LEVEL_1_DS    = Cho2.WORK_TEAM_LEVEL_1_DS       ,
  WORK_TEAM_LEVEL_2_CD    = Cho2.WORK_TEAM_LEVEL_2_CD       ,
  WORK_TEAM_LEVEL_2_DS    = Cho2.WORK_TEAM_LEVEL_2_DS       ,
  WORK_TEAM_LEVEL_3_CD    = Cho2.WORK_TEAM_LEVEL_3_CD       ,
  WORK_TEAM_LEVEL_3_DS    = Cho2.WORK_TEAM_LEVEL_3_DS       ,
  WORK_TEAM_LEVEL_4_CD    = Cho2.WORK_TEAM_LEVEL_4_CD       ,
  WORK_TEAM_LEVEL_4_DS    = Cho2.WORK_TEAM_LEVEL_4_DS       ,
  CPLT_INTRNL_SOURCE_ID   = Cho2.INTRNL_SOURCE_ID
  
Where (1=1)
And Soft2.ACTE_ID=Cho2.ACTE_ID_SOFT
;
.if errorcode <> 0 then .quit 1;

.quit 0
