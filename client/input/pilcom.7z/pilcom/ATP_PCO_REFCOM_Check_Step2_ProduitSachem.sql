 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ProduitSachem.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des produits Sachem
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000



--Identification des produits AGC
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'AGC'                                                         As SOURCE_ID              ,
  'SACHEM'                                                      As CATALOG_ID             ,
  'Produit Externe manquant ; ( TYPE_PRODUIT - PRODUCT_ID - PRODUCT_ID_SEC ) ; ( '
        ||Coalesce(Trim(Placement.PRODUCT_TYPE),'')
        ||' - '
        ||Coalesce(Trim(Placement.EXTERNAL_PRODUCT_ID),'')
        ||' - '
        ||Coalesce(Trim(Placement.EXTERNAL_PRODUCT_ID_SEC),'ND')
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.EXT_PRODUCT_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.EXT_PRODUCT_DS,''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  (
    Select
      Placement.PRODUCT_TYPE                    As PRODUCT_TYPE               ,
      Placement.EXTERNAL_PRODUCT_ID             As EXTERNAL_PRODUCT_ID        ,
      Placement.EXTERNAL_PRODUCT_ID_SEC         As EXTERNAL_PRODUCT_ID_SEC    ,
      Null                                      As EXT_PRODUCT_DS             ,
      Count(*)                                  As VolumeCas                  ,
      Min(Placement.ORDER_DEPOSIT_DT)           As DateMinRecue               ,
      Max(Placement.ORDER_DEPOSIT_DT)           As DateMaxRecue               
    From
      ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_AGC_PRP Placement
    Where
      (1=1)
      And Placement.PRODUCT_TYPE            Is Not Null
      And Placement.ORDER_DEPOSIT_DT        >= Current_date -30
    Group by
      PRODUCT_TYPE            ,
      EXTERNAL_PRODUCT_ID     ,
      EXTERNAL_PRODUCT_ID_SEC ,
      EXT_PRODUCT_DS          
  ) Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_SACH Catalogue
    On    Placement.PRODUCT_TYPE                            = Catalogue.TYPE_PRODUIT
      And Placement.EXTERNAL_PRODUCT_ID                     = Catalogue.EXT_PRODUCT_ID
      And Coalesce(Placement.EXTERNAL_PRODUCT_ID_SEC,'ND')  = Catalogue.EXT_PRODUCT_ID_SEC
      And Catalogue.CURRENT_IN                              = 1
      And Catalogue.CLOSURE_DT                              Is Null
      And Catalogue.PERIODE_ID                              =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Catalogue.TYPE_PRODUIT            Is Null
;
.if errorcode <> 0 Then .quit 1




--Identification des produits SelfCare
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'SFC'                                                         As SOURCE_ID              ,
  'SACHEM'                                                      As CATALOG_ID             ,
  'Produit Externe manquant ; ( TYPE_PRODUIT - EXT_PRODUCT_ID ) ; ( SO - '
        ||Coalesce(Trim(Placement.EXTERNAL_PRODUCT_ID),'')
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.EXT_PRODUCT_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.EXT_PRODUCT_DS,''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  (
    Select
      Placement.TYPE_OT_SO                      As PRODUCT_TYPE               ,
      Placement.OFFRE_OPT_ACQ                   As EXTERNAL_PRODUCT_ID        ,
      'NR'                                      As EXTERNAL_PRODUCT_ID_SEC    ,
      Null                                      As EXT_PRODUCT_DS             ,
      Count(*)                                  As VolumeCas                  ,
      Min(Placement.ORD_DEPOSIT_DT)             As DateMinRecue               ,
      Max(Placement.ORD_DEPOSIT_DT)             As DateMaxRecue               
    From
      ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_CAR Placement
    Where
      (1=1)
      And Placement.OFFRE_OPT_ACQ           Is Not Null
      And Placement.ORD_DEPOSIT_DT          >= Current_date -30
      And Placement.TYPE_OT_SO              = 'BP'
    Group by
      PRODUCT_TYPE            ,
      EXTERNAL_PRODUCT_ID     ,
      EXTERNAL_PRODUCT_ID_SEC ,
      EXT_PRODUCT_DS          
  ) Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_SACH Catalogue
    On    Placement.EXTERNAL_PRODUCT_ID                     = Catalogue.EXT_PRODUCT_ID
      And Catalogue.TYPE_PRODUIT                            = 'SO'
      And Catalogue.CURRENT_IN                              = 1
      And Catalogue.CLOSURE_DT                              Is Null
      And Catalogue.PERIODE_ID                              =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Catalogue.TYPE_PRODUIT            Is Null
;
.if errorcode <> 0 Then .quit 1



-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1




.quit 0
