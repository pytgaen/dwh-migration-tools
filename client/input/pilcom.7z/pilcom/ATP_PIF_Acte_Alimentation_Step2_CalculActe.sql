--$HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_PIF_Acte_Alimentation_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 11/08/2016      HLA         Creation
-- 24/10/2016      HLA         Modification(lot 2)
-- 12/12/2017      HOB         Alimentation IOBSP 
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_PIF All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_PIF
(
   ACTE_ID                       ,
   ACTE_ID_GEN                   ,
   INTRNL_SOURCE_ID              ,
   PIF_ORDER_ID                  ,
   ORDER_DEPOSIT_TS              ,
   ORDER_DEPOSIT_DT              ,
   PIF_CANAL_ID,
   PIF_CANAL_DS                  ,
   PIF_DOSSIER_NUMBER_DS         ,
   PIF_SELLR_SHOP_ID               ,
   PIF_CANCEL_DS                  ,
   PIF_CANCEL_DT                   ,
   SERVICE_ACCESS_ID             ,
   ACT_PRODUCT_ID_FINAL          ,
   ACT_SEG_COM_ID_FINAL          ,
   ACT_TYPE_COMMANDE_ID          ,
   ACT_UNITE_CD                   ,
   ACT_TYPE_SERVICE_FINAL        ,
   ACT_CD                        ,
   ACT_REM_ID                    ,
   ACT_FLAG_ACT_REM              ,
   ACT_FLAG_PEC_PERPVC           ,
   ACT_ACTE_VALO                 ,
   ACT_ACTE_FAMILLE_KPI          ,
   ACT_PERIODE_ID                ,
   ACT_PERIODE_STATUS            ,
   ACT_PERIODE_CLOSURE_DT        ,
   CLIENT_NU                     ,
   CLIENT_NU_NEW_PORTE           ,
   DELIVERY_ONTIME_IN            ,
   DELIVERY_DEAD_LINE_NU         ,
   DOSSIER_NU                    ,
   DOSSIER_NU_NEW_PORTE          ,
   DMC_LINE_ID                   ,
   DMC_MASTER_LINE_ID            ,
   DMC_LINE_TYPE                 ,
   DMC_ACTIVATION_DT             ,
   PAR_DEPRTMNT_ID               ,
   PAR_POSTAL_CD                 ,
   PAR_INSEE_NB                  ,
   PAR_BU_CD                     ,
   PAR_CID_ID                    ,
   PAR_PID_ID                    ,
   PAR_FIRST_IN                  ,
   PAR_IRIS2000_CD               ,
   PAR_GEO_MACROZONE             ,
   PAR_FIBER_IN                  ,
   EDO_ID                        ,
   TYPE_EDO_ID                   ,
   ORG_AGENT_IOBSP               ,
   ORG_EDO_IOBSP                 ,
   PAR_LASTNAME                  ,
   PAR_FIRSTNAME                 ,
   PAR_EMAIL                     ,
   PAR_BILL_CD_POSTAL            ,
   PAR_FIXE_DS                   ,
   PAR_AID                       ,
   PAR_ND                        ,
   PAR_MOBILE_DS                 ,
   MSISDN_ID                     ,
   PAR_REGRPMNT_ID               ,
   PAR_UNIFIED_PARTY_ID          ,
   DISTRBTN_CHANNL_ID            ,
   ACTIVITY                      ,
   FLAG_PLT_SCH_IN               ,
   FLAG_PLT_CONV_NB              ,
   FLAG_TYPE_GEO_CD              ,
   FLAG_TYPE_CPT_NTK             ,
   NETWRK_TYP_EDO_ID             ,
   FLAG_TYPE_PTN_NTK             ,
   FLAG_AD_SC                    ,
   UNIFIED_SHOP_CD               ,
   ORG_AGENT_ID                         ,
   ORG_NOM                              ,
   ORG_PRENOM                          ,
   FLAG_HD                       ,
   ORG_CHANNEL_CD                ,
   ORG_SUB_CHANNEL_CD            ,
   ORG_SUB_SUB_CHANNEL_CD        ,
   ORG_GT_ACTIVITY               ,
   ORG_FIDELISATION              ,
   ORG_WEB_ACTIVITY              ,
   ORG_AUTO_ACTIVITY             ,
   ORG_REM_CHANEL_CD             ,
   ORG_TEAM_LEVEL_1_CD           ,
   ORG_TEAM_LEVEL_1_DS           ,
   ORG_TEAM_LEVEL_2_CD           ,
   ORG_TEAM_LEVEL_2_DS           ,
   ORG_TEAM_LEVEL_3_CD           ,
   ORG_TEAM_LEVEL_3_DS           ,
   ORG_TEAM_LEVEL_4_CD           ,
   ORG_TEAM_LEVEL_4_DS           ,
   WORK_TEAM_LEVEL_1_CD          ,
   WORK_TEAM_LEVEL_1_DS          ,
   WORK_TEAM_LEVEL_2_CD          ,
   WORK_TEAM_LEVEL_2_DS          ,
   WORK_TEAM_LEVEL_3_CD          ,
   WORK_TEAM_LEVEL_3_DS          ,
   WORK_TEAM_LEVEL_4_CD          ,
   WORK_TEAM_LEVEL_4_DS          ,
   DATE_CREATE_TS                     ,
   DATE_ELIG_TS                            ,
   DATE_TRANS_TS                   ,
   DATE_REM_TS                       ,
   ORDER_CANCELLING_DT               ,
   PERENNITE_END_DT              ,
   COMPTTN_IN                    ,
   COMPTTN_ID                    ,
   SOURCE_FRESH_TS                    ,
   CLOSURE_DT                    ,
   CREATION_TS                   ,
   LAST_MODIF_TS                 ,
   FRESH_IN                      ,
   COHERENCE_IN                       
  )
 
 Select                                                                                                   
   Placement.ACTE_ID                                                    As  ACTE_ID                      ,
   Placement.ACTE_ID                                                    As  ACTE_ID_GEN                  ,
   Placement.INTRNL_SOURCE_ID                                           As  INTRNL_SOURCE_ID             ,
   Placement.PIF_ORDER_ID                                               As  PIF_ORDER_ID                 ,
   PreCalc.ACT_TS                                                       As  ORDER_DEPOSIT_TS             ,
   Cast(PreCalc.ACT_TS as date format 'YYYY/MM/DD')                     As  ORDER_DEPOSIT_DT             ,
   --Cast(PreCalc.ORDER_DEPOSIT_DT  as timestamp(0))                      As  ORDER_DEPOSIT_TS             ,
   --PreCalc.ORDER_DEPOSIT_DT                                             As  ORDER_DEPOSIT_DT             ,
   '4'                                                                  As  PIF_CANAL_ID                ,     
   Placement.PIF_CANAL_DS                                               As  PIF_CANAL_DS                 ,
   Placement.PIF_DOSSIER_NUMBER_DS                                      As  PIF_DOSSIER_NUMBER_DS        ,
   Placement.PIF_SELLR_SHOP_ID                                          As  PIF_SELLR_SHOP_ID                ,
   Placement.PIF_CANCEL_DS                                              As  PIF_CANCEL_DS                  ,
   Placement.PIF_CANCEL_DT                                              As  PIF_CANCEL_DT                   ,
   Placement.SERVICE_ACCESS_ID                                          As  SERVICE_ACCESS_ID            ,
   Mat.PRODUCT_ID                                                       As  ACT_PRODUCT_ID_FINAL         ,
   Mat.SEG_COM_ID_FINAL                                                 As  ACT_SEG_COM_ID_FINAL         ,
  -- Mat.SEG_COM_AGG_ID                                                   As  ACT_SEG_COM_AGG_ID_FINAL     ,
  -- Mat.CODE_MIGRATION                                                   As  ACT_CODE_MIGR_FINAL          ,
  -- Mat.MIGRATION_REGROUPEMENT_ID                                        As  ACT_MIGRATION_REGROUPEMENT_ID,
  -- Mat.MIGRATION_POSSIBLE                                                As  ACT_MIGRATION_POSSIBLE       ,
   Mat.TYPE_COMMANDE_ID                                                as  ACT_TYPE_COMMANDE_ID          ,
   Mat.unite_cd                                                        as ACT_UNITE_CD                    ,
   PreCalc.TYPE_SERVICE                                                As  ACT_TYPE_SERVICE_FINAL        ,
   Case 
      When Mat.ACTE_ID is Not Null then Mat.ACTE_ID
      When PreCalc.PERIODE_ID = ${P_PIL_049} Then '${P_PIL_217}' 
      When Mat.PRODUCT_ID = '${P_PIL_223}' Then '${P_PIL_224}'
      When PreCalc.SEG_COM_ID in ('NS') Then '${P_PIL_221}'
      Else '${P_PIL_220}' 
    End                                                                as  ACT_CD                       ,
   Mat.ACTE_REM_ID                                                     as  ACT_REM_ID                   ,
   Mat.FLAG_ACT_REM                                                    as  ACT_FLAG_ACT_REM             ,
   Mat.FLAG_PEC_PERPVC                                                 as  ACT_FLAG_PEC_PERPVC          ,
   Coalesce(Mat.ACTE_VALO,0)                                           as  ACT_ACTE_VALO                ,
   Mat.ACTE_FAMILLE_KPI                                                as  ACT_ACTE_FAMILLE_KPI         ,
   Mat.PERIODE_ID                                                      as  ACT_PERIODE_ID               ,
   Coalesce(EtatPeriode.PERIODE_STATUS,'O')                            as  ACT_PERIODE_STATUS           ,
   EtatPeriode.PERIODE_CLOSURE_DT                                      as  ACT_PERIODE_CLOSURE_DT       ,
   Placement.CLIENT_NU                                                 as  CLIENT_NU                    ,
   Placement.CLIENT_NU_NEW_PORTE                                       as  CLIENT_NU_NEW_PORTE          ,
   --Calcul si la livraison à eu lieu dans les temps :                                                
   'NA'                                                                as  DELIVERY_ONTIME_IN           ,
   Coalesce(Delais.DELAIS,-1)                                          as  DELIVERY_DEAD_LINE_NU        ,
   Placement.DOSSIER_NU                                                as  DOSSIER_NU                   ,
   Placement.DOSSIER_NU_NEW_PORTE                                      as  DOSSIER_NU_NEW_PORTE         ,
   Placement.DMC_LINE_ID                                               As  DMC_LINE_ID                  ,
   Placement.DMC_MASTER_LINE_ID                                        As  DMC_MASTER_LINE_ID           ,
   Placement.DMC_LINE_TYPE                                             As  DMC_LINE_TYPE                ,
   Placement.DMC_ACTIVATION_DT                                         As  DMC_ACTIVATION_DT            ,
   Placement.PAR_DEPRTMNT_ID                                           As  PAR_DEPRTMNT_ID              ,
   Placement.POSTAL_CD                                                 As  PAR_POSTAL_CD                ,
   Placement.PAR_INSEE_NB                                              As  PAR_INSEE_NB                 ,
   Placement.PAR_BU_CD                                                 As  PAR_BU_CD                    ,
   Placement.PAR_CID_ID                                                As  PAR_CID_ID                   ,
   Placement.PAR_PID_ID                                                As  PAR_PID_ID                   ,
   Placement.PAR_FIRST_IN                                              As  PAR_FIRST_IN                 ,
   Placement.PAR_IRIS2000_CD                                           As  PAR_IRIS2000_CD              ,
   Placement.PAR_GEO_MACROZONE                                         As  PAR_GEO_MACROZONE            ,
   Placement.PAR_FIBER_IN                                              As  PAR_FIBER_IN                 ,
   Placement.EDO_ID                                                    As  EDO_ID                       ,
   Placement.TYPE_EDO_ID                                               As  TYPE_EDO_ID                  ,
   Placement.ORG_AGENT_IOBSP                                           As  ORG_AGENT_IOBSP              ,
   Placement.ORG_EDO_IOBSP                                             As  ORG_EDO_IOBSP                ,
   Coalesce(Placement.PAR_LASTNAME,Placement.LAST_NAME_NM)             as  PAR_LASTNAME                 ,
   Coalesce(Placement.PAR_FIRSTNAME,Placement.LAST_NAME_NM)            as  PAR_FIRSTNAME                ,
   Coalesce( Placement.MAIL_ADRESS,Placement.PAR_EMAIL)                as  PAR_EMAIL                           ,
   Placement.POSTAL_CD                                                 as  PAR_BILL_CD_POSTAL           ,
   Placement.PAR_FIXE_DS                                               As  PAR_FIXE_DS                  ,
   Placement.PAR_AID                                                   As  PAR_AID                      ,
   Placement.PAR_ND_DS                                                 As  PAR_ND                       ,
   Placement.PAR_MOBILE_DS                                             As  PAR_MOBILE_DS                ,
   Placement.MSISDN_ID                                                 As  MSISDN_ID                    ,
   Placement.PAR_REGRPMNT_ID                                           As  PAR_REGRPMNT_ID              ,
   Placement.PAR_UNIFIED_PARTY_ID                                      As  PAR_UNIFIED_PARTY_ID         ,
   Placement.DISTRBTN_CHANNL_ID                                        As  DISTRBTN_CHANNL_ID           ,
   Placement.ACTIVITY                                                  As  ACTIVITY                     ,
   Placement.FLAG_PLT_SCH_IN                                           As  FLAG_PLT_SCH_IN              ,
   Placement.FLAG_PLT_CONV_NB                                          As  FLAG_PLT_CONV_NB             ,
   Placement.FLAG_TYPE_GEO_CD                                          As  FLAG_TYPE_GEO_CD             ,
   Placement.FLAG_TYPE_CPT_NTK                                         As  FLAG_TYPE_CPT_NTK            ,
   Placement.NETWRK_TYP_EDO_ID                                         As  NETWRK_TYP_EDO_ID            ,
   Placement.FLAG_TYPE_PTN_NTK                                         As  FLAG_TYPE_PTN_NTK            ,
   Placement.FLAG_AD_SC                                                As  FLAG_AD_SC                   ,
   Placement.UNIFIED_SHOP_CD                                              As  UNIFIED_SHOP_CD              ,
   Placement.ORG_AGENT_ID                                              As  ORG_AGENT_ID                        ,
   Placement.ORG_NOM                                                   As  ORG_NOM                             ,
   Placement.ORG_PRENOM                                                As  ORG_PRENOM                             ,
   Mat.HUMAINDIGITAL                                                   as FLAG_HD                       ,
   Placement.ORG_CHANNEL_CD                                            As  ORG_CHANNEL_CD               ,
   Placement.ORG_SUB_CHANNEL_CD                                        As  ORG_SUB_CHANNEL_CD           ,
   Placement.ORG_SUB_SUB_CHANNEL_CD                                    As  ORG_SUB_SUB_CHANNEL_CD       ,
   Placement.ORG_GT_ACTIVITY                                           As  ORG_GT_ACTIVITY              ,
   Placement.ORG_FIDELISATION                                          As  ORG_FIDELISATION             ,
   Placement.ORG_WEB_ACTIVITY                                          As  ORG_WEB_ACTIVITY             ,
   Placement.ORG_AUTO_ACTIVITY                                         As  ORG_AUTO_ACTIVITY            ,
   Placement.ORG_REM_CHANNEL_CD                                        As  ORG_REM_CHANEL_CD            ,
   Trim(Placement.ORG_TEAM_LEVEL_1_CD)                                 as  ORG_TEAM_LEVEL_1_CD          ,
   Placement.ORG_TEAM_LEVEL_1_DS                                       as  ORG_TEAM_LEVEL_1_DS          ,
   Trim(Placement.ORG_TEAM_LEVEL_2_CD)                                 as  ORG_TEAM_LEVEL_2_CD          ,
   Placement.ORG_TEAM_LEVEL_2_DS                                       as  ORG_TEAM_LEVEL_2_DS          ,
   Trim(Placement.ORG_TEAM_LEVEL_3_CD)                                 as  ORG_TEAM_LEVEL_3_CD          ,
   Placement.ORG_TEAM_LEVEL_3_DS                                       as  ORG_TEAM_LEVEL_3_DS          ,
   Trim(Placement.ORG_TEAM_LEVEL_4_CD)                                 as  ORG_TEAM_LEVEL_4_CD          ,
   Placement.ORG_TEAM_LEVEL_4_DS                                       as  ORG_TEAM_LEVEL_4_DS          ,
   trim(CAST(Placement.WORK_TEAM_LEVEL_1_CD AS VARCHAR(18)))           as  WORK_TEAM_LEVEL_1_CD         ,
   Placement.WORK_TEAM_LEVEL_1_DS                                      as  WORK_TEAM_LEVEL_1_DS         ,
   trim(CAST(Placement.WORK_TEAM_LEVEL_2_CD AS VARCHAR(18)))           as  WORK_TEAM_LEVEL_2_CD         ,
   Placement.WORK_TEAM_LEVEL_2_DS                                      as  WORK_TEAM_LEVEL_2_DS         ,
   CAST(Placement.WORK_TEAM_LEVEL_3_CD AS VARCHAR(18))                 as  WORK_TEAM_LEVEL_3_CD         ,
   Placement.WORK_TEAM_LEVEL_3_DS                                      as  WORK_TEAM_LEVEL_3_DS         ,
   CAST(Placement.WORK_TEAM_LEVEL_4_CD AS VARCHAR(18))                 as  WORK_TEAM_LEVEL_4_CD         ,
   Placement.WORK_TEAM_LEVEL_4_DS                                      as  WORK_TEAM_LEVEL_4_DS         ,
   Placement.DATE_CREATE_TS                                            As  DATE_CREATE_TS                    ,
   Placement.DATE_ELIG_TS                                              As  DATE_ELIG_TS                           ,
   Placement.DATE_TRANS_TS                                             As  DATE_TRANS_TS                   ,
   Placement.DATE_REM_TS                                               As  DATE_REM_TS                        ,
   Placement.ORDER_CANCELLING_DT                                       As  ORDER_CANCELLING_DT              ,
   Placement.PERENNITE_END_DT                                          As  PERENNITE_END_DT             ,
   Placement.COMPTTN_IN                                                             As  COMPTTN_IN                   ,
   Placement.COMPTTN_ID                                                              As  COMPTTN_ID                   ,
   Placement.SOURCE_FRESH_TS                                           As  SOURCE_FRESH_TS                   ,
   Null                                                                As  CLOSURE_DT                   ,
   Current_timestamp(0)                                                As  CREATION_TS                  ,
   Current_timestamp(0)                                                As  LAST_MODIF_TS                ,
   1                                                                   As  FRESH_IN                     ,
   0                                                                   As  COHERENCE_IN                      
  From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_PIF Placement
  
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_PIF_EXT PreCalc
    On    Placement.ACTE_ID          = PreCalc.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT = PreCalc.ORDER_DEPOSIT_DT
       
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_MATRICE_PIF Mat
    --On rÃ©interprete ici les commandes qui Ã©tait en ADP et qui sorte en aquisition => On le remet en maintient
    On     PreCalc.TYPE_COMMANDE_ID                = Mat.TYPE_COMMANDE_ID
      And  PreCalc.SEG_COM_ID                      = Mat.SEG_COM_ID_FINAL
      And  PreCalc.PERIODE_ID                      = Mat.PERIODE_ID
        And '#'                                     = Mat.SEG_COM_ID_INI
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On    PreCalc.TYPE_COMMANDE_ID           = Delais.TYPE_COMMANDE_ID
      And PreCalc.TYPE_SERVICE               = Delais.TYPE_SERVICE
      And PreCalc.PERIODE_ID                 = Delais.PERIODE_ID
      And Delais.FRESH_IN                    = 1
      And Delais.CURRENT_IN                  = 1
      And Delais.CLOSURE_DT                  Is Null
      
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    PreCalc.PERIODE_ID                  = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN              = 1
      And EtatPeriode.FRESH_IN                = 1
      And EtatPeriode.CLOSURE_DT              Is Null   

          
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_PIF;
.if errorcode <> 0 then .quit 1

          