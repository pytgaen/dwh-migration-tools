-- $HEADER: mm2pco/current/sql/ATP_MD2_Placement_Hot_FusionEnrichi_Step1.sql 13_05#3 09-JAN-2017 17:57:01 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_MD2_Placement_Hot_FusionEnrichi_Step1.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/08/2014      MDE         Creation
-- 16/10/2014      HFO         MODIFICATION( correction  alim champs PRESFACT_CO_OFFRE_OPT_ACQ )
-- 11/06/2015      MDE         MODIFICATION( correction  mapping alim champs FLAG_PLT_CONV et FLAG_PLT_SCH )
-- 30/12/2016      HOB         Modif : Ajout Champs Ventes ASS
-- 06/01/2017      JCR         Modification QC 1235 : changement typage des commandes

--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_2 all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_2
(
  ACTE_ID                     ,
  DEMANDE_ID                  ,
  EXTERNAL_INT_ID             ,
  INT_DEPOSIT_TS              ,
  INT_DEPOSIT_DT              ,
  OPERATOR_PROVIDER_ID        ,
  RESOLU_ID                   ,
  CONCLU_ID                   ,
  SSCONCLU_ID                 ,
  TYPE_COMMANDE               ,
  PLTF_CO                     ,
  INTRNL_SOURCE_ID            ,
  SOLDOFF_SRC_CD              ,
  RSFCOMMENTAIRE_DS           ,
  PRODUCT_ID                  ,
  OTO_OFFER_CD                ,
  OTO_OFFER_TYPE_CD           ,
  LOGIN_CREA                  ,
  LOGIN_RESP                  ,
  INT_MODIF_TS                ,
  CANALVENTE                  ,
  OTO_OSCAR_VALUE_NU          ,
  PRODUIT_PRINCIPAL_CHO       ,
  IN_CLIDOS                   ,
  TYPE_OT_SO                  ,
  CANALDEM                    ,
  CANALDEM_MTHD               ,
  INT_REASON_CD               ,
  CLIENT_NU                   ,
  CLIENT_NU_NEW_PORTE         ,
  DOSSIER_NU                  ,
  DOSSIER_NU_NEW_PORTE        ,
  DOSSIER_DATE_ACTIV          ,
  DOSSIER_DATE_RESIL          ,
  DOSSIER_TYPE_RESIL          ,
  DOSSIER_MOTIF_RESIL         ,
  DMC_LINE_ID                 ,
  DMC_MASTER_LINE_ID          ,
  PAR_GEO_MACROZONE           ,
  PAR_UNIFIED_PARTY_ID        ,
  PAR_PARTY_REGRPMNT_ID       ,
  DMC_LINE_TYPE               ,
  DMC_ACTIVATION_DT           ,
  DMC_CONVERGENT_IN           ,
  DMC_LINE_ID_INT             ,
  DMC_LINE_TYPE_INT           ,
  DMC_ACTIVATION_DT_INT       ,
  DMC_SERVICE_ACCESS_ID       ,
  OFFRE_INT_PRE               ,
  PRESFACT_CO_PRECED          ,
  PRESFACT_CO_OFFRE_OPT_ACQ   ,
  INB_PRESFACT_ACQ_ADV        ,
  INB_PRESFACT_ACQ_AGAP       ,
  PARC_DT_DEBUT               ,
  PARC_DT_FIN                 ,
  ORDAGD_DT_CONF              ,
  CONTRCT_DT_SIGN_PREC        ,
  CONTRCT_DT_FIN_PREC         ,
  CONTRCT_DT_SIGN_POST        ,
  CONTRCT_DUREE_ENG           ,
  CONTRCT_UNIT_ENG            ,
  EDO_ID                      ,
  FLAG_PLT_CONV               ,
  FLAG_PLT_SCH                ,
  FLAG_TEAM_MKT               ,
  FLAG_TYPE_CMP               ,
  TYPE_EDO                    ,
  EDO_ID_HIER                 ,
  TYPE_EDO_HIER               ,
  ORG_REF_TRAV                ,
  ORG_AGENT_ID                ,
  ORG_POC_XI                  ,
  ORG_NOM                     ,
  ORG_PRENOM                  ,
  ORG_GROUPE_ID               ,
  ORG_GROUPE_ID_HIER          ,
  ORG_ACTVT_REEL              ,
  ORG_RESP_REF_TRAV           ,
  ORG_RESP_AGENT_ID           ,
  ORG_RESP_XI                 ,
  ORG_RESP_ACTVT_REEL         ,
  PAR_LASTNAME                ,
  PAR_FIRSTNAME               ,
  PAR_TYPE                    ,
  PAR_IMSI                    ,
  PAR_EMAIL                   ,
  PAR_BILL_ADRESS_1           ,
  PAR_BILL_ADRESS_2           ,
  PAR_BILL_ADRESS_3           ,
  PAR_BILL_ADRESS_4           ,
  PAR_BILL_VILLE              ,
  PAR_BILL_CD_POSTAL          ,
  PAR_INSEE_CD                ,
  PAR_DO                      ,
  PAR_USCM                    ,
  PAR_USCM_DS                 ,
  PAR_USCM_USCM_DS            ,
  PAR_USCM_REGUSCM            ,
  PAR_USCM_REGUSCM_DS         ,
  PAR_AID                     ,
  PAR_ND                      ,
  PAR_MOB_IMEI                ,
  PAR_MOB_TAC                 ,
  PAR_MOB_SIM                 ,
  PAR_SCORE_NU_MOB            ,
  PAR_SCORE_IN_MOB            ,
  PAR_TRESHOLD_NU_MOB         ,
  PAR_SCORE_NU_INT            ,
  PAR_SCORE_IN_INT            ,
  PAR_TRESHOLD_NU_INT         ,
  FLAG_MAINT_INT_FALSE
)
Select
  Commande.ACTE_ID                                                            as ACTE_ID                    ,
  Commande.DEMANDE_ID                                                         as DEMANDE_ID                 ,
  Commande.EXTERNAL_INT_ID                                                    as EXTERNAL_INT_ID            ,
  Commande.INT_DEPOSIT_TS                                                     as INT_DEPOSIT_TS             ,
  Commande.INT_DEPOSIT_DT                                                     as INT_DEPOSIT_DT             ,
  Coalesce(ClientDos.OPERATOR_PROVIDER_ID,Commande.OPERATOR_PROVIDER_ID)      as OPERATOR_PROVIDER_ID       ,
  Commande.RESOLU_ID                                                          as RESOLU_ID                  ,
  Commande.CONCLU_ID                                                          as CONCLU_ID                  ,
  NULL                                                                        as SSCONCLU_ID                ,
  Commande.TYPE_COMMANDE                                                      as TYPE_COMMANDE              ,
  Commande.PLTF_CO                                                            as PLTF_CO                    ,
  Commande.INTRNL_SOURCE_ID                                                   as INTRNL_SOURCE_ID           ,
  Commande.SOLDOFF_SRC_CD                                                     as SOLDOFF_SRC_CD             ,
  Commande.RSFCOMMENTAIRE_DS                                                  as RSFCOMMENTAIRE_DS          ,
  Commande.PRODUCT_ID                                                         as PRODUCT_ID                 ,
  Commande.OTO_OFFER_CD                                                       as OTO_OFFER_CD               ,
  Commande.OTO_OFFER_TYPE_CD                                                  as OTO_OFFER_TYPE_CD          ,
  Commande.LOGIN_CREA                                                         as LOGIN_CREA                 ,
  Commande.LOGIN_RESP                                                         as LOGIN_RESP                 ,
  Commande.INT_MODIF_TS                                                       as INT_MODIF_TS               ,
  Commande.CANALVENTE                                                         as CANALVENTE                 ,
  Commande.OTO_OSCAR_VALUE_NU                                                 as OTO_OSCAR_VALUE_NU         ,
  Coalesce(ClientDos.PRODUIT_PRINCIPAL_CHOH,Commande.PRODUIT_PRINCIPAL_CHOH)   as PRODUIT_PRINCIPAL_CHO      ,
  Commande.IN_CLIDOS                                                          as IN_CLIDOS                  ,
  Commande.TYPE_OT_SO                                                         as TYPE_OT_SO                 ,
  Coalesce(CanalDem.CANALDEM,Commande.CANALDEM)                               as CANALDEM                   ,
  Coalesce(CanalDem.CANALDEM_MTHD,Commande.CANALDEM_MTHD)                     as CANALDEM_MTHD              ,
  Coalesce(CanalDem.INT_REASON_CD,Commande.INT_REASON_CD)                     as INT_REASON_CD              ,
  --Enrichissement du client dossier + la portabilité + Statut Dossier
  Coalesce(ClientDos.CLIENT_NU,ClientDos.CLIENT_NU,Commande.CLIENT_NU)        as CLIENT_NU                  ,
  NULL                                                                        as CLIENT_NU_NEW_PORTE        ,
  Coalesce(ClientDos.DOSSIER_NU,ClientDos.DOSSIER_NU,Commande.DOSSIER_NU)     as DOSSIER_NU                 ,
  NULL                                                                        as DOSSIER_NU_NEW_PORTE       ,
  Coalesce(NumIMSI.DOSSIER_DATE_ACTIV,Commande.DOSSIER_DATE_ACTIV)            as DOSSIER_DATE_ACTIV         ,
  Coalesce(NumIMSI.DOSSIER_DATE_RESIL,Commande.DOSSIER_DATE_RESIL)            as DOSSIER_DATE_RESIL         ,
  Coalesce(NumIMSI.DOSSIER_TYPE_RESIL,Commande.DOSSIER_TYPE_RESIL)            as DOSSIER_TYPE_RESIL         ,
  Coalesce(NumIMSI.DOSSIER_MOTIF_RESIL,Commande.DOSSIER_MOTIF_RESIL)          as DOSSIER_MOTIF_RESIL        ,
  Commande.DMC_LINE_ID                                                        as DMC_LINE_ID                ,
  Null                                                                        as DMC_MASTER_LINE_ID         ,
  Null                                                                        as PAR_GEO_MACROZONE           ,
  Null                                                                        as PAR_UNIFIED_PARTY_ID        ,            
  Null                                                                        as PAR_PARTY_REGRPMNT_ID       ,
  Null                                                                        as DMC_LINE_TYPE              ,
  Null                                                                        as DMC_ACTIVATION_DT          ,
  Null                                                                        as DMC_CONVERGENT_IN          ,
  Null                                                                        as DMC_LINE_ID_INT            ,
  Null                                                                        as DMC_LINE_TYPE_INT          ,
  Null                                                                        as DMC_ACTIVATION_DT_INT      ,
  Null                                                                        as DMC_SERVICE_ACCESS_ID      ,
  Null                                                                        as OFFRE_INT_PRE              ,
  Coalesce(PARCPRE.PRESFACT_CO_PRECED,Commande.PRESFACT_CO_PRECED)            as PRESFACT_CO_PRECED         ,
  --On place Ici Le code de l'option ou offre acquise
  Coalesce(SousConclu.SSCONCLU_ID,Commande.SSCONCLU_ID)                       as PRESFACT_CO_OFFRE_OPT_ACQ  ,
  Commande.INB_PRESFACT_ACQ_ADV                                               as INB_PRESFACT_ACQ_ADV       ,
  Commande.INB_PRESFACT_ACQ_AGAP                                              as INB_PRESFACT_ACQ_AGAP      ,
  Commande.PARC_DT_DEBUT                                                      as PARC_DT_DEBUT              ,
  Commande.PARC_DT_FIN                                                        as PARC_DT_FIN                ,
  Commande.ORDAGD_DT_CONF                                                     as ORDAGD_DT_CONF             ,
  Commande.CONTRCT_DT_SIGN_PREC                                               as CONTRCT_DT_SIGN_PREC       ,
  Commande.CONTRCT_DT_FIN_PREC                                                as CONTRCT_DT_FIN_PREC        ,
  Commande.CONTRCT_DT_SIGN_POST                                               as CONTRCT_DT_SIGN_POST       ,
  Commande.CONTRCT_DUREE_ENG                                                  as CONTRCT_DUREE_ENG          ,
  Commande.CONTRCT_UNIT_ENG                                                   as CONTRCT_UNIT_ENG           ,
  VEND_O3.EDO_ID                                                              as EDO_ID                     ,
  VEND_O3.FLAG_PLT_CONV                                                       as FLAG_PLT_CONV              ,
  VEND_O3.FLAG_PLT_SCH                                                        as FLAG_PLT_SCH               ,
  Commande.FLAG_TEAM_MKT                                                      as FLAG_TEAM_MKT              ,
  Commande.FLAG_TYPE_CMP                                                      as FLAG_TYPE_CMP              ,
  VEND_O3.TYPE_EDO                                                            as TYPE_EDO                   ,
  VEND_O3.EDO_ID                                                              as EDO_ID_HIER                ,
  VEND_O3.TYPE_EDO                                                            as TYPE_EDO_HIER              ,
  NULL                                                                        as ORG_REF_TRAV               ,
  NULL                                                                        as ORG_AGENT_ID               ,
  NULL                                                                        as ORG_POC_XI                 ,
  NULL                                                                        as ORG_NOM                    ,
  NULL                                                                        as ORG_PRENOM                 ,
  NULL                                                                        as ORG_GROUPE_ID              ,
  NULL                                                                        as ORG_GROUPE_ID_HIER         ,
  NULL                                                                        as ORG_ACTVT_REEL             ,
  NULL                                                                        as ORG_RESP_REF_TRAV          ,
  NULL                                                                        as ORG_RESP_AGENT_ID          ,
  NULL                                                                        as ORG_RESP_XI                ,
  NULL                                                                        as ORG_RESP_ACTVT_REEL        ,
  Commande.PAR_LASTNAME                                                       as PAR_LASTNAME               ,
  Commande.PAR_FIRSTNAME                                                      as PAR_FIRSTNAME              ,
  Commande.PAR_TYPE                                                           as PAR_TYPE                   ,
  Coalesce(NumIMSI.PAR_IMSI,Commande.PAR_IMSI)                                as PAR_IMSI                   ,
  Commande.PAR_EMAIL                                                          as PAR_EMAIL                  ,
  Commande.PAR_BILL_ADRESS_1                                                  as PAR_BILL_ADRESS_1          ,
  Commande.PAR_BILL_ADRESS_2                                                  as PAR_BILL_ADRESS_2          ,
  Commande.PAR_BILL_ADRESS_3                                                  as PAR_BILL_ADRESS_3          ,
  Commande.PAR_BILL_ADRESS_4                                                  as PAR_BILL_ADRESS_4          ,
  Commande.PAR_BILL_VILLE                                                     as PAR_BILL_VILLE             ,
  Commande.PAR_BILL_CD_POSTAL                                                 as PAR_BILL_CD_POSTAL         ,
  Commande.PAR_INSEE_CD                                                       as PAR_INSEE_CD               ,
  Commande.PAR_DO                                                             as PAR_DO                     ,
  Commande.PAR_USCM                                                           as PAR_USCM                   ,
  Commande.PAR_USCM_DS                                                        as PAR_USCM_DS                ,
  Commande.PAR_USCM_USCM_DS                                                   as PAR_USCM_USCM_DS           ,
  Commande.PAR_USCM_REGUSCM                                                   as PAR_USCM_REGUSCM           ,
  Commande.PAR_USCM_REGUSCM_DS                                                as PAR_USCM_REGUSCM_DS        ,
  Commande.PAR_AID                                                            as PAR_AID                    ,
  Commande.PAR_ND                                                             as PAR_ND                     ,
  Commande.PAR_MOB_IMEI                                                       as PAR_MOB_IMEI               ,
  Commande.PAR_MOB_TAC                                                        as PAR_MOB_TAC                ,
  Commande.PAR_MOB_SIM                                                        as PAR_MOB_SIM                ,
  Null                                                                        as PAR_SCORE_NU_MOB           ,
  Null                                                                        as PAR_SCORE_IN_MOB           ,
  Null                                                                        as PAR_TRESHOLD_NU_MOB        ,
  Null                                                                        as PAR_SCORE_NU_INT           ,
  Null                                                                        as PAR_SCORE_IN_INT           ,
  Null                                                                        as PAR_TRESHOLD_NU_INT        ,
  Null                                                                        as FLAG_MAINT_INT_FALSE
From 
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_1 Commande
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIDOSS ClientDos
    On    Commande.ACTE_ID        = ClientDos.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClientDos.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CANALDEM CanalDem
    On    Commande.ACTE_ID        = CanalDem.ACTE_ID
      And Commande.INT_DEPOSIT_DT = CanalDem.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_CLIIMSI NumIMSI
    On    Commande.ACTE_ID        = NumIMSI.ACTE_ID
      And Commande.INT_DEPOSIT_DT = NumIMSI.INT_DEPOSIT_DT
Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_VEND_O3 VEND_O3
    On    Commande.ACTE_ID        = VEND_O3.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VEND_O3.INT_DEPOSIT_DT
Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_PARCPRE PARCPRE
    On    Commande.ACTE_ID        = PARCPRE.ACTE_ID
      And Commande.INT_DEPOSIT_DT = PARCPRE.INT_DEPOSIT_DT
Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_SSCONCLU SousConclu
    On    Commande.ACTE_ID        = SousConclu.ACTE_ID
      And Commande.INT_DEPOSIT_DT = SousConclu.INT_DEPOSIT_DT
      ;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_2;
.if errorcode <> 0 then .quit 1

.quit 0
