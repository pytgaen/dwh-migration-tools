-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCM_Anticip_Acte_Alim_Step3_CalculActe.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.${ReferentielPrefix}ACT_T_PCM
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     CDR         Création
-- 13/11/2013     YZH         Modification sur les champs WORK_TEAM_LEVEL_X_CD, suite au problème de troncation
-- 09/04/2014     AID         Evol
-- 05/07/2016     GMA         Modif sur l'ajout du multicanal
-- 09/12/2016     HOB         Modif Ajout Champs VA
-- 28/12/2016     JCR         Modif Ajout Champs VA
-- 07/05/2018     LMU         Modification dans le cadres des RCS
-- 25/09/2019     EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF
-- 15/04/2020     YAB         Modification de l'alimentation ACT_DELTA_TARIF KPI2020 
 
---------------------------------------------------------------------------------

.set width 2000;


-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.ORD_T_ACTE_PCM
-- **************************************************************
Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_PCM_A All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_PCM_A
(
  ACTE_ID                       ,
  ACTE_ID_GEN                   ,
  ORDER_OPER_ID                 ,
  ORDER_DEPOSIT_DT              ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_EXTERNAL_ID             ,
  TYPE_COMMANDE                 , -- RCS
  TB_TYPEBCR                    , -- RCS
  INDCARTESIM                   , -- RCS
  INTRNL_SOURCE_ID              ,
  ORDER_REF_EXTERNAL_ID         ,
  ORDER_MOTV_ID                 ,
  ORDER_MOTIF_DS                ,
  ORDER_SALE_PRICE              ,
  OTO_OSCAR_VALUE_NU            ,
  ACT_OPER_ID_FINAL             ,
  ORDER_STATUT_CD               ,
  ORDER_STATUT_MODIF_TS         ,
  ORDER_LAST_STATUT_CD          ,
  ORDER_LAST_STATUT_MODIF_TS    ,
  PAR_MOB_EAN                   ,
  PAR_MOB_IMEI                  ,
  PAR_MOB_TAC                   ,
  PAR_SCORE_IN                  ,
  PAR_SCORE_NU                  ,
  PAR_TRESHOLD_NU               ,
  CONTRCT_DT_SIGN_PREC          ,
  CONTRCT_DT_FIN_PREC           ,
  CONTRCT_DT_SIGN_POST          ,
  CONTRCT_DUREE_ENG             ,
  CONTRCT_UNIT_ENG              ,
  INB_PRESFACT_CO               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_PRODUCT_DS_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_DS_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_UNITE_CD                  ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  RCS_MOTIV_INVC_CD             , -- RCS
  RCS_ENR_ACTE_ID               , -- RCS
  ORG_CANAL_ID                  ,
  ORIG_DEM                      ,
  CANALDEM_MTHD                 ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_MACRO_LB            ,
  FLAG_HD                       ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_REM_CHANNEL_CD            ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_STORE_NAME                ,
  ORG_REF_TRAV                  ,
  ORG_AGENT_ID                  ,
  ORG_RESP_AGENT_ID             ,
  ORG_AGENT_ID_UPD              ,
  ORG_AGENT_ID_UPD_DT           ,
  ORG_AGENT_LAST_NAME           ,
  ORG_AGENT_FIRST_NAME          ,
  ORG_ACTVT_REEL                ,
  ORG_POC_XI                    ,
  ORG_NOM                       ,
  ORG_PRENOM                    ,
  ORG_GROUPE_ID                 ,
  ORG_RESP_REF_TRAV             ,
  ORG_RESP_XI                   ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  PAR_EXTERNAL_PARTY_FREG_ID    ,
  PAR_PARTY_KNB_FREG_ID         ,
  PAR_TERMINTN_VALUE_DS         ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_BSS_ID          ,
  PAR_ACCES_SERVICE             ,
  PAR_ADV_CLIENT_NU             ,
  PAR_ADV_DOSSIER_NU            ,
  DMC_LINE_ID                   ,
  DMC_MASTER_LINE_ID            ,
  DMC_LINE_TYPE                 ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  PAR_SIRET                     ,
  PAR_EMAIL                     ,
  PAR_IMSI                      ,
  PAR_BILL_ADRESS_1             ,
  PAR_BILL_ADRESS_2             ,
  PAR_BILL_ADRESS_3             ,
  PAR_BILL_ADRESS_4             ,
  PAR_BILL_CD_POSTAL            ,
  INSEE_CD                      ,
  PAR_MARKET_SEG                ,
  PAR_TYPE                      ,
  PAR_DO                        ,
  PAR_ND                        ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  PERENNITE_PVC_IN              ,
  PERENNITE_PVC_FIN_DT          ,
  PERENNITE_PVC_CALC_FIN_DT     ,
  STATUT_NON_CONCLU             ,
  SEG_PRES_PARC_COMMANDE        ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  RESIL_INT_DT                  ,
  RESIL_INT_MOTIF               ,
  RESIL_INT_MOTIF_DS            ,
  ORDER_CANCELING_DT            ,
  SEG_COM_ID_LAST_PER           ,
  SEG_COM_ID_SOLD               ,
  SEG_COM_ID_FIND               ,
  SEG_FIND_LIVR_DT              ,
  SEG_FIND_CANCEL_DT            ,
  SEG_COM_ID_NEXT_PARC          ,
  SEG_NEXT_PARC_LIVR_DT         ,
  SEG_NEXT_PARC_CANCEL_DT       ,
  SEG_COM_ID_FINAL_PARC         ,
  SEG_FINAL_PARC_LIVR_DT        ,
  SEG_FINAL_PARC_CANCEL_DT      ,
  SEG_COM_ID_LAST_IN_PARC       ,
  NB_IN_OUT_PARC                ,
  POURCENTAGE_PRES_PARC         ,
  SEG_COM_ID_ORDER_ID           ,
  SEG_ORDER_DT                  ,
  SEG_CANCEL_DT                 ,
  SEG_COM_ID_NEXT_ORDER         ,
  SEG_NEXT_ORDER_DT             ,
  SEG_NEXT_CANCEL_DT            ,
  SEG_COM_ID_FINAL_ORDER        ,
  SEG_FINAL_ORDER_DT            ,
  SEG_FINAL_ORDER_CANCEL_DT     ,
  DELIVERY_ONTIME_IN            ,
  DELIVERY_DEAD_LINE_NU         ,
  PAR_USCM                      ,
  PAR_USCM_DS                   ,
  PAR_USCM_USCM_DS              ,
  PAR_USCM_REGUSCM              ,
  PAR_USCM_REGUSCM_DS           ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CHECK_LOC_COMMENT             ,
  CHECK_NAT_COMMENT             ,
  CHECK_VALIDT_DT               ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_INITIAL_STATUS_CD       ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRL_SOURCE_ID          ,
  CPLT_EXT_INT_ID               ,
  CPLT_EXT_INT_DELT_ID          ,
  CPLT_RESOLU_ID                ,
  CPLT_CONCLU_ID                ,
  CPLT_INT_ORIGIN_CD            ,
  CPLT_INT_REASON_CD            ,
  CPLT_INT_RESULT_CD            ,
  CPLT_ORG_REM_CHANNEL_CD       ,
  CPLT_ORG_CHANNEL_CD           ,
  CPLT_ORG_SUB_CHANNEL_CD       ,
  CPLT_ORG_SUB_SUB_CHANNEL_CD   ,
  CPLT_ORG_GT_ACTIVITY          ,
  CPLT_ORG_FIDELISATION         ,
  CPLT_ORG_WEB_ACTIVITY         ,
  CPLT_ORG_AUTO_ACTIVITY        ,
  CPLT_ORG_AGENT_ID             ,
  CPLT_ORG_TEAM_LEVEL_1_CD      ,
  CPLT_ORG_TEAM_LEVEL_1_DS      ,
  CPLT_ORG_TEAM_LEVEL_2_CD      ,
  CPLT_ORG_TEAM_LEVEL_2_DS      ,
  CPLT_ORG_TEAM_LEVEL_3_CD      ,
  CPLT_ORG_TEAM_LEVEL_3_DS      ,
  CPLT_ORG_TEAM_LEVEL_4_CD      ,
  CPLT_ORG_TEAM_LEVEL_4_DS      ,
  CPLT_WORK_TEAM_LEVEL_1_CD     ,
  CPLT_WORK_TEAM_LEVEL_1_DS     ,
  CPLT_WORK_TEAM_LEVEL_2_CD     ,
  CPLT_WORK_TEAM_LEVEL_2_DS     ,
  CPLT_WORK_TEAM_LEVEL_3_CD     ,
  CPLT_WORK_TEAM_LEVEL_3_DS     ,
  CPLT_WORK_TEAM_LEVEL_4_CD     ,
  CPLT_WORK_TEAM_LEVEL_4_DS     ,
  CLOSURE_DT                    ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  ,
  RUN_ID                        ,
  HOT_IN                        
)
Select
  Placement.ACTE_ID                                                 as ACTE_ID                        ,
  Placement.ACTE_ID                                                 as ACTE_ID_GEN                    ,
  Null                                                              as ORDER_OPER_ID                  ,
  Placement.DATESAISIEBCR                                           as ORDER_DEPOSIT_DT               ,
  '${P_PIL_056}'                                                    as OPERATOR_PROVIDER_ID           ,
  trim(Cast(Placement.ID_BCR as decimal(8) Format '----------9'))   as ORDER_EXTERNAL_ID              ,
  Null                                                              as TYPE_COMMANDE                  ,
  Null                                                              as TB_TYPEBCR                     ,
  Null                                                              as INDCARTESIM                    ,
  ${IdSourceInterne}                                                as INTRNL_SOURCE_ID               ,
  Null                                                              as ORDER_REF_EXTERNAL_ID          ,
  Null                                                              as ORDER_MOTV_ID                  ,
  '${P_PIL_320}'                                                    as ORDER_MOTIF_DS                 ,
  Null                                                              as ORDER_SALE_PRICE               ,
  Placement.SEGMENTVALEURCLIENT                                     as OTO_OSCAR_VALUE_NU             ,
  '${P_PIL_005}'                                                    as ACT_OPER_ID_FINAL              ,
  Placement.STATUTBCR_CO                                            as ORDER_STATUT_CD                ,
  Null                                                              as ORDER_STATUT_MODIF_TS          ,
  Null                                                              as ORDER_LAST_STATUT_CD           ,
  Null                                                              as ORDER_LAST_STATUT_MODIF_TS     ,
  Cast(Placement.REFARTICLE as Varchar(30))                         as PAR_MOB_EAN                    ,
  Placement.NUMEROIMEI                                              as PAR_MOB_IMEI                   ,
  Placement.CODE_TAC                                                as PAR_MOB_TAC                    ,
  Coalesce(Placement.PAR_SCORE_IN,9)                                as PAR_SCORE_IN                   ,
  Coalesce(Placement.PAR_SCORE_NU,0)                                as PAR_SCORE_NU                   ,
  Coalesce(Placement.PAR_TRESHOLD_NU,99999)                         as PAR_TRESHOLD_NU                ,
  Placement.CONTRCT_DT_SIGN_PREC                                    as CONTRCT_DT_SIGN_PREC           ,
  Placement.CONTRCT_DT_FIN_PREC                                     as CONTRCT_DT_FIN_PREC            ,
  Placement.CONTRCT_DT_SIGN_POST                                    as CONTRCT_DT_SIGN_POST           ,
  Placement.CONTRCT_DUREE_ENG                                       as CONTRCT_DUREE_ENG              ,
  Placement.CONTRCT_UNIT_ENG                                        as CONTRCT_UNIT_ENG               ,
  Null                                                              as INB_PRESFACT_CO                ,
  Null                                                              as ACT_PRODUCT_ID_PRE             ,
  Null                                                              as ACT_PRODUCT_DS_PRE             ,
  Null                                                              as ACT_SEG_COM_ID_PRE             ,
  Null                                                              as ACT_SEG_COM_AGG_ID_PRE         ,
  Null                                                              as ACT_CODE_MIGR_PRE              ,
  Null                                                              as ACT_OPER_ID_PRE                ,
  PreCalcPCM.PRODUCT_ID                                             as ACT_PRODUCT_ID_FINAL           ,
  Null                                                              as ACT_PRODUCT_DS_FINAL           ,
  PreCalcPCM.SEG_COM_ID                                             as ACT_SEG_COM_ID_FINAL           ,
  PreCalcPCM.SEG_COM_AGG_ID                                         as ACT_SEG_COM_AGG_ID_FINAL       ,
  RefMig.CODE_MIGRATION                                             as ACT_CODE_MIGR_FINAL            ,
  Null                                                              as ACT_TYPE_SERVICE_FINAL         ,
  PreCalcPCM.EXT_PRODUCT_ID                                         as ACT_TYPE_COMMANDE_ID           ,
  CASE
    -- Unite = CA  
    WHEN Acte.UNITE_CD ='${P_PIL_490}' 
         THEN   Null
    -- Unite = NB  
    WHEN Acte.UNITE_CD ='${P_PIL_620}' 
         Then case 
                 When ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
                  Then Coalesce(EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT,0) 
                  Else Null
              End
    -- Unite = MKT
    WHEN Acte.UNITE_CD ='${P_PIL_623}' 
         THEN   Acte.CA_MARKETING
    -- Unite = CA_CALIPSO (TMX)  
    WHEN Acte.UNITE_CD ='${P_PIL_622}' 
         THEN   Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0) 
    ELSE Null
  END                                                               as ACT_DELTA_TARIF                ,         
  Acte.UNITE_CD                                                     as ACT_UNITE_CD                   ,
  Case 
    When Mat.ACTE_ID is Not Null then Mat.ACTE_ID
    When PreCalcPCM.PERIODE_ID = ${P_PIL_049} Then '${P_PIL_217}' 
    When PreCalcPCM.PRODUCT_ID = '${P_PIL_223}' Then '${P_PIL_224}'
    When PreCalcPCM.SEG_COM_ID in ('NS') Then '${P_PIL_221}'
    Else '${P_PIL_220}' 
  End                                                               as ACT_CD                         ,
  Coalesce(Acte.ACTE_REM_ID,'${P_PIL_067}')                         as ACT_REM_ID                     ,
  Coalesce(Acte.FLAG_ACT_REM,'N')                                   as ACT_FLAG_ACT_REM               ,
  Coalesce(Acte.FLAG_PEC_PERPVC,'N')                                as ACT_FLAG_PEC_PERPVC            ,
  CASE
    -- Unite = CA  
    WHEN Acte.UNITE_CD ='${P_PIL_490}' 
         THEN   Null
    -- Unite = NB  
    WHEN Acte.UNITE_CD ='${P_PIL_620}' 
         THEN   Coalesce(Acte.ACTE_VALO, 0)
    -- Unite = MKT / TMX
    WHEN Acte.UNITE_CD IN ( '${P_PIL_623}','${P_PIL_622}' )
         THEN   ( ACT_DELTA_TARIF * Acte.TAUX_MARGE )
    ELSE Null
  END                                                               as ACT_ACTE_VALO                  ,
  Coalesce(Acte.ACTE_FAMILLE_KPI,'NON PARAM')                       as ACT_ACTE_FAMILLE_KPI           ,
  PreCalcPCM.PERIODE_ID                                             as ACT_PERIODE_ID                 ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                          as ACT_PERIODE_STATUS             ,
  EtatPeriode.PERIODE_CLOSURE_DT                                    as ACT_PERIODE_CLOSURE_DT         ,
  Null                                                              as RCS_MOTIV_INVC_CD              ,
  Null                                                              as RCS_ENR_ACTE_ID                ,
  Placement.CD_CANALDIST                                            as ORG_CANAL_ID                   ,
  --On alimente l'origine de la demande que si elle est corrigée sinon on
  --l'alimentera avec la valeur des placements dans la vue SC
  OrigineVente.ORIG_DEM                                             as ORIG_DEM                       ,
  Null                                                              as CANALDEM_MTHD                  ,
  CanalVenteMacroPrem.ORG_CANAL_ID_MACRO                            as ORG_CANAL_ID_MACRO,
  CanalVenteMacroPrem.ORG_CANAL_MACRO_LB                            as ORG_CANAL_MACRO_LB             ,
  RefKPI.HUMAINDIGITAL                                              as FLAG_HD                        ,
  --Calcul du canal de vente Macro
  Coalesce(OrgChannelPcm.ORG_CHANNEL_CD,'NONPARAM')                 as ORG_CHANNEL_CD                 ,
  --Sous Canal
  Case  When Placement.CD_CANALDIST = '2' And OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then  Case  When Placement.FLAG_TYPE_CPT_NTK Is Not Null
                        Then 'RC'
                      When Placement.FLAG_TYPE_PTN_NTK Is Not Null
                        Then 'RP'
                      Else OrgChannelPcm.ORG_SUB_CHANNEL_CD
                End
        When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                               as ORG_SUB_CHANNEL_CD             ,
  --Sous-Sous-Canal
  Case  When Placement.CD_CANALDIST = '2' And OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then  Case  When Placement.FLAG_TYPE_CPT_NTK Is Not Null
                        Then Placement.FLAG_TYPE_CPT_NTK
                      When Placement.FLAG_TYPE_PTN_NTK Is Not Null And Placement.FLAG_TYPE_GEO Is Not Null
                        Then 'DOM'
                      When Placement.FLAG_TYPE_PTN_NTK Is Not Null
                        Then 'Metropole'
                      Else OrgChannelPcm.ORG_SUB_SUB_CHANNEL_CD
                End
        When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_SUB_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                               as ORG_SUB_SUB_CHANNEL_CD         ,
  --Canal de Rem
  Case  When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_REM_CHANNEL_CD
        Else 'NONPARAM'
  End                                                               as ORG_REM_CHANNEL_CD             ,
   --Activité
  Case  When Placement.CD_CANALDIST = '2' And OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then  Case  When Placement.FLAG_TYPE_CPT_NTK Is Not Null
                        Then 'Reseau Concurrent'
                      When Placement.FLAG_TYPE_PTN_NTK Is Not Null
                        Then Placement.FLAG_TYPE_PTN_NTK
                      Else OrgChannelPcm.ORG_GT_ACTIVITY
                End
        When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_GT_ACTIVITY
        Else 'NONPARAM'
  End                                                               as ORG_GT_ACTIVITY                ,
  --Fidelisaion
  Case  When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_FIDELISATION
        Else 'NONPARAM'
  End                                                               as ORG_FIDELISATION               ,
  --Activité Web                                                    
  Case  When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_WEB_ACTIVITY
        Else 'E'
  End                                                               as ORG_WEB_ACTIVITY               ,
  --Activité Automatique                                            
  Case  When OrgChannelPcm.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelPcm.ORG_AUTO_ACTIVITY
        Else 'E'
  End                                                               as ORG_AUTO_ACTIVITY              ,
  Placement.EDO_ID                                                  as ORG_EDO_ID                     ,
  Placement.TYPE_EDO                                                as ORG_TYPE_EDO                   ,
  Placement.FLAG_PLT_CONV                                           as ORG_FLAG_PLT_CONV              ,
  Null                                                              as ORG_FLAG_TEAM_MKT              ,
  Placement.FLAG_TYPE_CMP                                           as ORG_FLAG_TYPE_CMP              ,
  Placement.PV_POINTVENTE                                           as ORG_STORE_NAME                 ,
  Placement.ORG_REF_TRAV                                            as ORG_REF_TRAV                   ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.IDENTIFIANT_FT)         as ORG_AGENT_ID                   ,
  Cast('NC' as Char(10))                                            as ORG_RESP_AGENT_ID              ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.IDENTIFIANT_FT)         as ORG_AGENT_ID_UPD               ,
  Null                                                              as ORG_AGENT_ID_UPD_DT            ,
  Placement.ORG_NOM                                                 as ORG_AGENT_LAST_NAME            ,
  Placement.ORG_PRENOM                                              as ORG_AGENT_FIRST_NAME           ,
  Coalesce(Placement.ORG_ACTVT_REEL,'INCO')                         as ORG_ACTVT_REEL                 ,
  Coalesce(Placement.ORG_POC_XI,0)                                  as ORG_POC_XI                     ,
  Placement.ORG_NOM                                                 as ORG_NOM                        ,
  Placement.ORG_PRENOM                                              as ORG_PRENOM                     ,
  Placement.ORG_GROUPE_ID                                           as ORG_GROUPE_ID                  ,
  Cast(null as char (7))                                            as ORG_RESP_REF_TRAV              ,
  Cast(0 as Decimal(10))                                            as ORG_RESP_XI                    ,
  Null                                                              as ORG_RESP_EDO_ID                ,
  Null                                                              as ORG_RESP_TYPE_EDO              ,
  Null                                                              as ORG_RESP_FLAG_PLT_CONV         ,
  Null                                                              as ORG_TEAM_LEVEL_1_CD            ,
  Null                                                              as ORG_TEAM_LEVEL_1_DS            ,
  Null                                                              as ORG_TEAM_LEVEL_2_CD            ,
  Null                                                              as ORG_TEAM_LEVEL_2_DS            ,
  Null                                                              as ORG_TEAM_LEVEL_3_CD            ,
  Null                                                              as ORG_TEAM_LEVEL_3_DS            ,
  Null                                                              as ORG_TEAM_LEVEL_4_CD            ,
  Null                                                              as ORG_TEAM_LEVEL_4_DS            ,
  CAST(HierO3.WORK_TEAM_LEVEL_1_CD AS VARCHAR(18))                  as WORK_TEAM_LEVEL_1_CD           ,
  HierO3.WORK_TEAM_LEVEL_1_DS                                       as WORK_TEAM_LEVEL_1_DS           ,
  CAST(HierO3.WORK_TEAM_LEVEL_2_CD AS VARCHAR(18))                  as WORK_TEAM_LEVEL_2_CD           ,
  HierO3.WORK_TEAM_LEVEL_2_DS                                       as WORK_TEAM_LEVEL_2_DS           ,
  CAST(HierO3.WORK_TEAM_LEVEL_3_CD AS VARCHAR(18))                  as WORK_TEAM_LEVEL_3_CD           ,
  HierO3.WORK_TEAM_LEVEL_3_DS                                       as WORK_TEAM_LEVEL_3_DS           ,
  CAST(HierO3.WORK_TEAM_LEVEL_4_CD AS VARCHAR(18))                  as WORK_TEAM_LEVEL_4_CD           ,
  HierO3.WORK_TEAM_LEVEL_4_DS                                       as WORK_TEAM_LEVEL_4_DS           ,
  Null                                                              as PAR_EXTERNAL_PARTY_FREG_ID     ,
  Null                                                              as PAR_PARTY_KNB_FREG_ID          ,
  Placement.ND                                                      as PAR_TERMINTN_VALUE_DS          ,
  Placement.AID                                                     as PAR_EXTERNAL_PARTY_BSS_ID      ,
  Null                                                              as PAR_PARTY_KNB_BSS_ID           ,
  Null                                                              as PAR_ACCES_SERVICE              ,
  Placement.CLIENT_NU                                               as PAR_ADV_CLIENT_NU              ,
  Placement.DOSSIER_NU                                              as PAR_ADV_DOSSIER_NU             ,
  Placement.DMC_LINE_ID                                             as DMC_LINE_ID                    ,
  Placement.DMC_MASTER_LINE_ID                                      as DMC_MASTER_LINE_ID             ,
  Null                                                              as DMC_LINE_TYPE                  ,
  Placement.PAR_GEO_MACROZONE                                       as PAR_GEO_MACROZONE              ,
  Placement.PAR_UNIFIED_PARTY_ID                                    as PAR_UNIFIED_PARTY_ID           ,
  Placement.PAR_PARTY_REGRPMNT_ID                                   as PAR_PARTY_REGRPMNT_ID          ,
  Placement.PAR_LASTNAME                                            as PAR_LASTNAME                   ,
  Placement.PAR_FIRSTNAME                                           as PAR_FIRSTNAME                  ,
  Null                                                              as PAR_SIRET                      ,
  Placement.PAR_EMAIL                                               as PAR_EMAIL                      ,
  Placement.PAR_IMSI                                                as PAR_IMSI                       ,
  Placement.PAR_BILL_ADRESS_1                                       as PAR_BILL_ADRESS_1              ,
  Placement.PAR_BILL_ADRESS_2                                       as PAR_BILL_ADRESS_2              ,
  Placement.PAR_BILL_ADRESS_3                                       as PAR_BILL_ADRESS_3              ,
  Placement.PAR_BILL_ADRESS_4                                       as PAR_BILL_ADRESS_4              ,
  Placement.PAR_BILL_CD_POSTAL                                      as PAR_BILL_CD_POSTAL             ,
  Null                                                              as INSEE_CD                       ,
  Null                                                              as PAR_MARKET_SEG                 ,
  Placement.PAR_TYPE                                                as PAR_TYPE                       ,
  Placement.PAR_DO                                                  as PAR_DO                         ,
  Coalesce(Placement.ND, '0000000000')                              as PAR_ND                         ,
  Null                                                              as CONFIRMATION_IN                ,
  Null                                                              as CONFIRMATION_DT                ,
  Null                                                              as CONFIRMATION_CALC_FIN_DT       ,
  Null                                                              as DELIVERY_IN                    ,
  Null                                                              as DELIVERY_DT                    ,
  Null                                                              as DELIVERY_CALC_FIN_DT           ,
  Null                                                              as PERENNITE_IN                   ,
  Null                                                              as PERENNITE_FIN_DT               ,
  Null                                                              as PERENNITE_CALC_FIN_DT          ,
  Null                                                              as PERENNITE_PVC_IN               ,
  Null                                                              as PERENNITE_PVC_FIN_DT           ,
  Null                                                              as PERENNITE_PVC_CALC_FIN_DT      ,
  Placement.STATUT_NON_CONCLU                                       as STATUT_NON_CONCLU              ,
  Null                                                              as SEG_PRES_PARC_COMMANDE         ,
  Null                                                              as MIGRA_DT                       ,
  Null                                                              as MIGRA_NEXT_OFFRE               ,
  Null                                                              as RESIL_INT_DT                   ,
  Null                                                              as RESIL_INT_MOTIF                ,
  Null                                                              as RESIL_INT_MOTIF_DS             ,
  Null                                                              as ORDER_CANCELING_DT             ,
  Null                                                              as SEG_COM_ID_LAST_PER            ,
  Null                                                              as SEG_COM_ID_SOLD                ,
  Null                                                              as SEG_COM_ID_FIND                ,
  Null                                                              as SEG_FIND_LIVR_DT               ,
  Null                                                              as SEG_FIND_CANCEL_DT             ,
  Null                                                              as SEG_COM_ID_NEXT_PARC           ,
  Null                                                              as SEG_NEXT_PARC_LIVR_DT          ,
  Null                                                              as SEG_NEXT_PARC_CANCEL_DT        ,
  Null                                                              as SEG_COM_ID_FINAL_PARC          ,
  Null                                                              as SEG_FINAL_PARC_LIVR_DT         ,
  Null                                                              as SEG_FINAL_PARC_CANCEL_DT       ,
  Null                                                              as SEG_COM_ID_LAST_IN_PARC        ,
  Null                                                              as NB_IN_OUT_PARC                 ,
  Null                                                              as POURCENTAGE_PRES_PARC          ,
  Null                                                              as SEG_COM_ID_ORDER_ID            ,
  Null                                                              as SEG_ORDER_DT                   ,
  Null                                                              as SEG_CANCEL_DT                  ,
  Null                                                              as SEG_COM_ID_NEXT_ORDER          ,
  Null                                                              as SEG_NEXT_ORDER_DT              ,
  Null                                                              as SEG_NEXT_CANCEL_DT             ,
  Null                                                              as SEG_COM_ID_FINAL_ORDER         ,
  Null                                                              as SEG_FINAL_ORDER_DT             ,
  Null                                                              as SEG_FINAL_ORDER_CANCEL_DT      ,
  --Calcul si la livraison à eu lieu dans les temps :                                                
  'NA'                                                              as DELIVERY_ONTIME_IN             ,
  Coalesce(Delais.DELAIS,-1)                                        as DELIVERY_DEAD_LINE_NU          ,
  Placement.USCM_CO_ADV                                             as PAR_USCM                       ,
  USCM.USCM_LL                                                      as PAR_USCM_DS                    ,
  USCM.USCM_LL_USCM                                                 as PAR_USCM_USCM_DS               ,
  USCM.USCM_CO_REGUSCM                                              as PAR_USCM_REGUSCM               ,
  USCM.USCM_LB_REGUSCM                                              as PAR_USCM_REGUSCM_DS            ,
  Null                                                              as CONCURENCE_IN                  ,
  Null                                                              as CONCURENCE_CONCLU_IN           ,
  Null                                                              as CONCURENCE_ID                  ,
  Null                                                              as CHECK_LOC_COMMENT              ,
  Null                                                              as CHECK_NAT_COMMENT              ,
  Null                                                              as CHECK_VALIDT_DT                ,
  Null                                                              as CHECK_LOC_STATUS_LN            ,
  Null                                                              as CHECK_NAT_STATUS_LN            ,
  Null                                                              as CHECK_LOC_STATUS_CD            ,
  Null                                                              as CHECK_NAT_STATUS_CD            ,
  Null                                                              as CHECK_INITIAL_STATUS_CD        ,
  Null                                                              as CPLT_ACTE_ID                   ,
  Null                                                              as CPLT_INTRL_SOURCE_ID           ,
  Null                                                              as CPLT_EXT_INT_ID                ,
  Null                                                              as CPLT_EXT_INT_DELT_ID           ,
  Null                                                              as CPLT_RESOLU_ID                 ,
  Null                                                              as CPLT_CONCLU_ID                 ,
  Null                                                              as CPLT_INT_ORIGIN_CD             ,
  Null                                                              as CPLT_INT_REASON_CD             ,
  Null                                                              as CPLT_INT_RESULT_CD             ,
  Null                                                              as CPLT_ORG_REM_CHANNEL_CD        ,
  Null                                                              as CPLT_ORG_CHANNEL_CD            ,
  Null                                                              as CPLT_ORG_SUB_CHANNEL_CD        ,
  Null                                                              as CPLT_ORG_SUB_SUB_CHANNEL_CD    ,
  Null                                                              as CPLT_ORG_GT_ACTIVITY           ,
  Null                                                              as CPLT_ORG_FIDELISATION          ,
  Null                                                              as CPLT_ORG_WEB_ACTIVITY          ,
  Null                                                              as CPLT_ORG_AUTO_ACTIVITY         ,
  Null                                                              as CPLT_ORG_AGENT_ID              ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_1_CD       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_1_DS       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_2_CD       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_2_DS       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_3_CD       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_3_DS       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_4_CD       ,
  Null                                                              as CPLT_ORG_TEAM_LEVEL_4_DS       ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_1_CD      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_1_DS      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_2_CD      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_2_DS      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_3_CD      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_3_DS      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_4_CD      ,
  Null                                                              as CPLT_WORK_TEAM_LEVEL_4_DS      ,
  Placement.CLOSURE_DT                                              as CLOSURE_DT                     ,
  '${KNB_BATCH_DATE}'                                               as CREATION_TS                    ,
  '${KNB_BATCH_DATE}'                                               as LAST_MODIF_TS                  ,
  1                                                                 as FRESH_IN                       ,
  0                                                                 as COHERENCE_IN                   ,
  ${KNB_VACATION_RUN_ID}                                            as RUN_ID                         ,
  1                                                                 as HOT_IN                         
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_A Placement
  Inner Join ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM PreCalcPCM
    On    Placement.ACTE_ID       = PreCalcPCM.ACTE_ID
      And Placement.DATESAISIEBCR = PreCalcPCM.DATESAISIEBCR
  --Jointure pour récupérer la hierarchie O3:
  Left Outer Join ${KNB_PCO_TMP}.ORD_T_CALC_ACT_PCM_O3 HierO3
    On    Placement.ACTE_ID       = HierO3.ACTE_ID
      And Placement.DATESAISIEBCR = HierO3.DATE_SAISIE
    --Jointure récupérer les infos de la table des matrices
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM Mat
    On   PreCalcPCM.EXT_PRODUCT_ID              = Mat.TYPE_COMMANDE_ID
      And PreCalcPCM.SEG_COM_ID                 = Mat.SEG_COM_ID_FINAL
      And Trim(PreCalcPCM.SEGMENTVALEURCLIENT)  = Trim(Mat.CATEGORIE_CLIENT_ID)
      And PreCalcPCM.PERIODE_ID                 = Mat.PERIODE_ID
      And Mat.FRESH_IN                          = 1
      And Mat.CURRENT_IN                        = 1
      And Mat.CLOSURE_DT                        Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
    On    Acte.ACTE_ID                           = Mat.ACTE_ID
      And Acte.PERIODE_ID                        = Mat.PERIODE_ID
      And Acte.FRESH_IN                          = 1
      And Acte.CURRENT_IN                        = 1
      And Acte.CLOSURE_DT                        Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefMig
    On    RefMig.SEG_COM_ID                     = PreCalcPCM.SEG_COM_ID
      And RefMig.PERIODE_ID                     = PreCalcPCM.PERIODE_ID
      And RefMig.CURRENT_IN                     = 1
      And RefMig.FRESH_IN                       = 1
      And RefMig.CLOSURE_DT                     Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On   PreCalcPCM.EXT_PRODUCT_ID              = Delais.TYPE_COMMANDE_ID
      And PreCalcPCM.TYPE_SERVICE               = Delais.TYPE_SERVICE
      And PreCalcPCM.PERIODE_ID                 = Delais.PERIODE_ID
      And Delais.FRESH_IN                       = 1
      And Delais.CURRENT_IN                     = 1
      And Delais.CLOSURE_DT                     Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_ORIG_DEM OrigineVente
    On    Placement.ORG_REF_TRAV                = OrigineVente.ORG_REF_TRAV
      And Placement.ORG_GROUPE_ID               = OrigineVente.ORG_GROUPE_ID
      And Placement.DATESAISIEBCR               >= OrigineVente.GRP_DT_DEB
      And Placement.DATESAISIEBCR               <= OrigineVente.GRP_DT_FIN
      And OrigineVente.APPLI_SOURCE_ID          = 'PCM'
      And OrigineVente.FRESH_IN                 = 1
      And OrigineVente.CURRENT_IN               = 1
      And OrigineVente.CLOSURE_DT               is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_CANAL_VENTE CanalVenteMacroPrem
    On    OrigineVente.ORIG_DEM                 = CanalVenteMacroPrem.ORIG_DEM
      And CanalVenteMacroPrem.FRESH_IN          = 1
      And CanalVenteMacroPrem.CURRENT_IN        = 1
      And CanalVenteMacroPrem.CLOSURE_DT        is Null
  Left Outer Join ${KNB_IBU_SOC}.V_TDUSCM USCM
    On    Placement.USCM_CO_ADV                = USCM.USCM_CO
      And USCM.FRESH_IN           = 1
      And USCM.CURRENT_IN         = 1
      And USCM.CLOSURE_DT         is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_PCM OrgChannelPcm
    On    Placement.CD_CANALDIST                             = OrgChannelPcm.CD_CANALDIST
      And Placement.FLAG_PLT_CONV                            = OrgChannelPcm.FLAG_PLT_CONV
      And COALESCE(Placement.FLAG_TYPE_CMP, '${P_PIL_418}')  = OrgChannelPcm.ORG_FLAG_TYPE_CMP
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    PreCalcPCM.PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                              = 1
      And EtatPeriode.FRESH_IN                                = 1
      And EtatPeriode.CLOSURE_DT                              Is Null
  -- KPI2020
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM  RefKPI
    On    RefKPI.PERIODE_ID                                   = Acte.PERIODE_ID
     And  RefKPI.FAMILLE_KPI_ID                               = Acte.ACTE_FAMILLE_KPI
     And  RefKPI.CURRENT_IN                                   = 1
     And  RefKPI.CLOSURE_DT                                   Is Null
  -- KPI2020 : Jointure Referentiel CALIPSO
  Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB
     On EAN_Canal_WEB.EAN_CD = Substr(Placement.REFARTICLE,1,13)
     And Placement.DATESAISIEBCR Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM
     On  EAN_Canal_DOM.EAN_CD = Substr(Placement.REFARTICLE,1,13)
     And Placement.DATESAISIEBCR Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'

Where
  (1=1)
  And Placement.DATESAISIEBCR>='20080101'
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_PCM_A;
.if errorcode <> 0 then .quit 1

