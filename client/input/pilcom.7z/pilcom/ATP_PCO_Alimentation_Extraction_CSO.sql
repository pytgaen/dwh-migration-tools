-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_PCO_Alimentation_Extraction_CSO.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table d'extraction à destination de CSO ${KNB_PCO_SOC}.${ReferentielPrefix}EXT_T_ACTE_CSO
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 11/06/2013     XKN         Création
-- 27/05/2013     AID         Indus
-- 21/07/2014     HFO         Modification (ajout des nouveaux champs)
-- 02/08/2014     GMA         Correction suite a des doublons
-- 12/09/2014     KBH         Modification Pour l'extraction CSO AD
-- 22/09/2014     KBH         Ajout des suffix sur la base COM_O
-- 07/10/2014     HZO         Ajout des test d'erreur et Correction du nom de tables
-- 24/11/2014     KBH         Modification des code et libellé statut CSO pour AD 
-- 20/01/2015     HFO         Modification (CSO : statut initial Pilcom à 7 => incorrect)
-- 26/01/2015     YZH         Modification (Ajout eRDV & SAVI)
-- 30/01/2015     OCH         Modification (Ajout CRS)
-- 05/02/2015     MDE         Modification : Ajout ETASK
-- 04/07/2016     MDE         Modification : Supprimer extraction cso ETASK
-- 06/10/2019    ITA          PILCOM_661 : Suppression de la partie TMS
---------------------------------------------------------------------------------

.set width 2000;

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_VM}.EXT_T_ACTE_CSO
-- **************************************************************

Delete From ${KNB_PCO_TMP}.EXT_T_ACTE_CSO All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                       As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  SF.ORDER_OPER_ID                                          As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  SF.ORDER_MOTIF_DS                                         As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  SF.ORDER_STATUT_CD                                        As ORDER_STATUT_CD                ,
  SF.ORG_CANAL_ID_MACRO                                     As ORG_CANAL_ID_MACRO             ,
  SF.ORG_CANAL_ID                                           As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  SF.PAR_EXTERNAL_PARTY_BSS_ID                              As PAR_EXTERNAL_PARTY_BSS_ID      ,
  SF.PAR_PARTY_KNB_FREG_ID                                  As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                       As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                      As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT As SF
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_400}
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_048},${L_PIL_107})  
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                               As ACTE_ID                     ,
  AU.MASTER_ACTE_ID                                        As MASTER_ACTE_ID              ,
  AU.CPLT_ACTE_ID                                          As CPLT_ACTE_ID                ,
  AU.INTRNL_SOURCE_ID                                      As INTRNL_SOURCE_ID            ,
  CATR.ACTE_DS                                             As ACTE_DS                     ,
  CATR.ACTE_REM_DS                                         As ACTE_REM_DS                 ,
  CATR.ACTE_VALO                                           As ACTE_VALO                   ,
  CATRKPI.FAMILLE_KPI_LIB                                  As FAMILLE_KPI_LIB             ,
  CATRKPI.KPI_LIB                                          As KPI_LIB                     ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                      As PRODUIT_DS                  ,
  SC.APPLI_SOURCE_ID                                       As APPLI_SOURCE_ID             ,
  SF.ORDER_OPER_ID                                         As ORDER_OPER_ID               ,
  AU.ACT_TS                                                As ACT_TS                      ,
  AU.ACT_PRODUCT_ID_FINAL                                  As ACT_PRODUCT_ID_FINAL        ,
  AU.ACT_PRODUCT_ID_PRE                                    As ACT_PRODUCT_ID_PRE          ,
  AU.ACT_TYPE_COMMANDE_ID                                  As ACT_TYPE_COMMANDE_ID        ,
  SF.ORDER_MOTIF_DS                                        As ORDER_MOTIF_DS              ,
  AU.OPERATOR_PROVIDER_ID                                  As OPERATOR_PROVIDER_ID        ,
  SF.ORDER_STATUT_CD                                       As ORDER_STATUT_CD             ,
  SF.ORG_CANAL_ID_MACRO                                    As ORG_CANAL_ID_MACRO          ,
  SF.ORG_CANAL_ID                                          As ORG_CANAL_ID                ,
  AU.ORG_REM_CHANNEL_CD                                    As ORG_REM_CHANNEL_CD          ,
  AU.UNIFIED_SHOP_CD                                       As UNIFIED_SHOP_CD             ,
  AU.AGENT_ID                                              As AGENT_ID                    ,
  AU.AGENT_ID_UPD                                          As AGENT_ID_UPD                ,
  AU.AGENT_ID_UPD_DT                                       As AGENT_ID_UPD_DT             ,
  AU.REAL_ACTIVITY_CD                                      As REAL_ACTIVITY_CD            ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                  As AGENT_FIRST_NAME            ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                   As AGENT_LAST_NAME             ,
  AU.WORK_TEAM_LEVEL_1_CD                                  As WORK_TEAM_LEVEL_1_CD        ,
  AU.WORK_TEAM_LEVEL_1_DS                                  As WORK_TEAM_LEVEL_1_DS        ,
  AU.WORK_TEAM_LEVEL_2_DS                                  As WORK_TEAM_LEVEL_2_DS        ,
  AU.WORK_TEAM_LEVEL_3_DS                                  As WORK_TEAM_LEVEL_3_DS        ,
  AU.WORK_TEAM_LEVEL_4_DS                                  As WORK_TEAM_LEVEL_4_DS        ,
  AU.MSISDN_ID                                             As MSISDN_ID                   ,
  SF.PAR_EXTERNAL_PARTY_BSS_ID                             As PAR_EXTERNAL_PARTY_BSS_ID   ,
  SF.PAR_PARTY_KNB_FREG_ID                                 As PAR_PARTY_KNB_FREG_ID       ,
  AU.NDS_VALUE_DS                                          As NDS_VALUE_DS                ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                      As PAR_LASTNAME                ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                     As PAR_FIRSTNAME               ,
  AU.ACT_SEG_COM_ID_FINAL                                  As ACT_SEG_COM_ID_FINAL        ,
  AU.ACT_CD                                                As ACT_CD                      ,
  AU.ACT_PERIODE_ID                                        As ACT_PERIODE_ID              ,
  AU.OSCAR_VALUE                                           As OSCAR_VALUE                 ,
  AU.CONFIRMATION_IN                                       As CONFIRMATION_IN             ,
  AU.CONFIRMATION_DT                                       As CONFIRMATION_DT             ,
  AU.CONFIRMATION_CALC_FIN_DT                              As CONFIRMATION_CALC_FIN_DT    ,
  AU.DELIVERY_IN                                           As DELIVERY_IN                 ,
  AU.DELIVERY_DT                                           As DELIVERY_DT                 ,
  AU.DELIVERY_CALC_FIN_DT                                  As DELIVERY_CALC_FIN_DT        ,
  AU.PERENNITE_IN                                          As PERENNITE_IN                ,
  AU.PERENNITE_FIN_DT                                      As PERENNITE_FIN_DT            ,
  AU.PERENNITE_CALC_FIN_DT                                 As PERENNITE_CALC_FIN_DT       ,
  AU.CONCURENCE_IN                                         As CONCURENCE_IN               ,
  AU.CONCURENCE_CONCLU_IN                                  As CONCURENCE_CONCLU_IN        ,
  AU.CONCURENCE_ID                                         As CONCURENCE_ID               ,
  AU.CONCLDD_IN                                            As CONCLDD_IN                  ,
  AU.RESULT_CD                                             As RESULT_CD                   ,
  ORI.ORIGIN_DS                                            As ORIGIN_DS                   ,
  REA.REASON_DS                                            As REASON_DS                   ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})       As CHECK_INITIAL_STATUS_CD     ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')            As CHECK_INITIAL_STATUS_LN     ,
  Null                                                     As CHECK_NAT_STATUS_CD         ,
  Null                                                     As CHECK_NAT_COMMENT           ,
  Null                                                     As CHECK_NAT_STATUS_LN         ,
  Null                                                     As CHECK_LOC_STATUS_CD         ,
  Null                                                     As CHECK_LOC_COMMENT           ,
  Null                                                     As CHECK_LOC_STATUS_LN         ,
  Null                                                     As CHECK_VALIDT_DT             ,
  '${KNB_BATCH_DATE}'                                      As CHECK_EXTRACT_TS            ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                  As CHECK_MONTH_DT              ,
  '${KNB_BATCH_DATE}'                                      As CREATION_TS                 ,
  Null                                                     As LAST_MODIF_TS               ,
  Null                                                     As CLOSURE_DT                  ,
  Null                                                     As AUTHOR_CD                   ,
  1                                                        As CURRENT_IN                  ,
  1                                                        As FRESH_IN                    ,
  0                                                        As COHERENCE_IN                
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB As SF
    On AU.ACTE_ID                   = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On   AU.INTRNL_SOURCE_ID        = SC.INTRNL_SOURCE_ID
    And SC.CURRENT_IN               = 1
    And SC.CLOSURE_DT               Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On    AU.ORIGIN_CD              = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID       = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN            = 1
      And ORI.CLOSURE_DT            Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD              = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID       = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN            = 1
      And REA.CLOSURE_DT            Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On AU.CHECK_INITIAL_STATUS_CD   = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN            = 1
      And CSO.CLOSURE_DT            Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_400}
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_048},${L_PIL_107}) 
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                               As ACTE_ID                     ,
  AU.MASTER_ACTE_ID                                        As MASTER_ACTE_ID              ,
  AU.CPLT_ACTE_ID                                          As CPLT_ACTE_ID                ,
  AU.INTRNL_SOURCE_ID                                      As INTRNL_SOURCE_ID            ,
  CATR.ACTE_DS                                             As ACTE_DS                     ,
  CATR.ACTE_REM_DS                                         As ACTE_REM_DS                 ,
  CATR.ACTE_VALO                                           As ACTE_VALO                   ,
  CATRKPI.FAMILLE_KPI_LIB                                  As FAMILLE_KPI_LIB             ,
  CATRKPI.KPI_LIB                                          As KPI_LIB                     ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                      As PRODUIT_DS                  ,
  SC.APPLI_SOURCE_ID                                       As APPLI_SOURCE_ID             ,
  Null                                                     As ORDER_OPER_ID               ,
  AU.ACT_TS                                                As ACT_TS                      ,
  AU.ACT_PRODUCT_ID_FINAL                                  As ACT_PRODUCT_ID_FINAL        ,
  AU.ACT_PRODUCT_ID_PRE                                    As ACT_PRODUCT_ID_PRE          ,
  AU.ACT_TYPE_COMMANDE_ID                                  As ACT_TYPE_COMMANDE_ID        ,
  SF.ORDER_MOTIF_DS                                        As ORDER_MOTIF_DS              ,
  AU.OPERATOR_PROVIDER_ID                                  As OPERATOR_PROVIDER_ID        ,
  SF.ORDER_STATUT_CD                                       As ORDER_STATUT_CD             ,
  SF.ORG_CANAL_ID_MACRO                                    As ORG_CANAL_ID_MACRO          ,
  SF.ORG_CANAL_ID                                          As ORG_CANAL_ID                ,
  AU.ORG_REM_CHANNEL_CD                                    As ORG_REM_CHANNEL_CD          ,
  AU.UNIFIED_SHOP_CD                                       As UNIFIED_SHOP_CD             ,
  AU.AGENT_ID                                              As AGENT_ID                    ,
  AU.AGENT_ID_UPD                                          As AGENT_ID_UPD                ,
  AU.AGENT_ID_UPD_DT                                       As AGENT_ID_UPD_DT             ,
  AU.REAL_ACTIVITY_CD                                      As REAL_ACTIVITY_CD            ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                  As AGENT_FIRST_NAME            ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                   As AGENT_LAST_NAME             ,
  AU.WORK_TEAM_LEVEL_1_CD                                  As WORK_TEAM_LEVEL_1_CD        ,
  AU.WORK_TEAM_LEVEL_1_DS                                  As WORK_TEAM_LEVEL_1_DS        ,
  AU.WORK_TEAM_LEVEL_2_DS                                  As WORK_TEAM_LEVEL_2_DS        ,
  AU.WORK_TEAM_LEVEL_3_DS                                  As WORK_TEAM_LEVEL_3_DS        ,
  AU.WORK_TEAM_LEVEL_4_DS                                  As WORK_TEAM_LEVEL_4_DS        ,
  AU.MSISDN_ID                                             As MSISDN_ID                   ,
  SF.PAR_EXTERNAL_PARTY_BSS_ID                             As PAR_EXTERNAL_PARTY_BSS_ID   ,
  SF.PAR_PARTY_KNB_FREG_ID                                 As PAR_PARTY_KNB_FREG_ID       ,
  AU.NDS_VALUE_DS                                          As NDS_VALUE_DS                ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                      As PAR_LASTNAME                ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                     As PAR_FIRSTNAME               ,
  AU.ACT_SEG_COM_ID_FINAL                                  As ACT_SEG_COM_ID_FINAL        ,
  AU.ACT_CD                                                As ACT_CD                      ,
  AU.ACT_PERIODE_ID                                        As ACT_PERIODE_ID              ,
  AU.OSCAR_VALUE                                           As OSCAR_VALUE                 ,
  AU.CONFIRMATION_IN                                       As CONFIRMATION_IN             ,
  AU.CONFIRMATION_DT                                       As CONFIRMATION_DT             ,
  AU.CONFIRMATION_CALC_FIN_DT                              As CONFIRMATION_CALC_FIN_DT    ,
  AU.DELIVERY_IN                                           As DELIVERY_IN                 ,
  AU.DELIVERY_DT                                           As DELIVERY_DT                 ,
  AU.DELIVERY_CALC_FIN_DT                                  As DELIVERY_CALC_FIN_DT        ,
  AU.PERENNITE_IN                                          As PERENNITE_IN                ,
  AU.PERENNITE_FIN_DT                                      As PERENNITE_FIN_DT            ,
  AU.PERENNITE_CALC_FIN_DT                                 As PERENNITE_CALC_FIN_DT       ,
  AU.CONCURENCE_IN                                         As CONCURENCE_IN               ,
  AU.CONCURENCE_CONCLU_IN                                  As CONCURENCE_CONCLU_IN        ,
  AU.CONCURENCE_ID                                         As CONCURENCE_ID               ,
  AU.CONCLDD_IN                                            As CONCLDD_IN                  ,
  AU.RESULT_CD                                             As RESULT_CD                   ,
  ORI.ORIGIN_DS                                            As ORIGIN_DS                   ,
  REA.REASON_DS                                            As REASON_DS                   ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})       As CHECK_INITIAL_STATUS_CD     ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')            As CHECK_INITIAL_STATUS_LN     ,
  Null                                                     As CHECK_NAT_STATUS_CD         ,
  Null                                                     As CHECK_NAT_COMMENT           ,
  Null                                                     As CHECK_NAT_STATUS_LN         ,
  Null                                                     As CHECK_LOC_STATUS_CD         ,
  Null                                                     As CHECK_LOC_COMMENT           ,
  Null                                                     As CHECK_LOC_STATUS_LN         ,
  Null                                                     As CHECK_VALIDT_DT             ,
  '${KNB_BATCH_DATE}'                                      As CHECK_EXTRACT_TS            ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                  As CHECK_MONTH_DT              ,
  '${KNB_BATCH_DATE}'                                      As CREATION_TS                 ,
  Null                                                     As LAST_MODIF_TS               ,
  Null                                                     As CLOSURE_DT                  ,
  Null                                                     As AUTHOR_CD                   ,
  1                                                        As CURRENT_IN                  ,
  1                                                        As FRESH_IN                    ,
  0                                                        As COHERENCE_IN                
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_PCM As SF
    On    AU.ACTE_ID                  = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID         = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN               = 1
      And SC.CLOSURE_DT               Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                   = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN              = 1
      And ORI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID         = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN              = 1
      And REA.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On AU.CHECK_INITIAL_STATUS_CD     = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN              = 1
      And CSO.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_400}
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_048},${L_PIL_107})
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  HF.FREG_PARTY_ID                           As PAR_EXTERNAL_PARTY_BSS_ID       ,
  CASE WHEN COM_O${KNB_SUFFIX}.IsNumber(HF.RES_VALUE_DS) = 0 THEN -1 
      ELSE HF.RES_VALUE_DS 
  END                                        As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  TD_SYSFNLIB.Oreplace(HF.LAST_NAME_NM, ';', ' ')        As PAR_LASTNAME                    ,
  TD_SYSFNLIB.Oreplace(HF.FIRST_NAME_NM, ';', ' ')       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  --CASE WHEN AU.MASTER_ACTE_ID = AU.ACTE_ID THEN ${P_PIL_406}
  --    ELSE ${P_PIL_404}
  --END
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})  As CHECK_INITIAL_STATUS_CD        ,
  CASE WHEN AU.MASTER_ACTE_ID = AU.ACTE_ID THEN '${P_PIL_407}'
      ELSE '${P_PIL_405}'
  END                                          As CHECK_INITIAL_STATUS_LN       ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_INT_F_ACTE_HRF As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
      And HF.INT_TYPE             = 0
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_401}  
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_048},${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux AD  TMS PILCOM_661 : suppression de la partie TMS
/*
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  Null                                       As PAR_LASTNAME                    ,
  Null                                       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_TMS As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_452}  
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1
*/

-- Insertion pour flux Bestar
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  Null                                       As PAR_LASTNAME                    ,
  Null                                       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_BESTAR As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_406} 
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux ERC
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANEL_CD                           As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  TD_SYSFNLIB.Oreplace(HF.LAST_NAME_NM, ';', ' ')        As PAR_LASTNAME                    ,
  TD_SYSFNLIB.Oreplace(HF.FIRST_NAME_NM, ';', ' ')       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_ERC As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_457} 
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux EXF
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANEL_CD                           As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  TD_SYSFNLIB.Oreplace(HF.PAR_LAST_NAME_CUSTOMER_NM, ';', ' ')        As PAR_LASTNAME                    ,
  TD_SYSFNLIB.Oreplace(HF.PAR_FIRST_NAME_CUSTOMER_NM, ';', ' ')       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_EXF As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_411}  
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux NEWSHOP
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  TD_SYSFNLIB.Oreplace(HF.PAR_LASTNAME, ';', ' ')        As PAR_LASTNAME                    ,
  TD_SYSFNLIB.Oreplace(HF.PAR_FIRSTNAME, ';', ' ')       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_NEWSHOP As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_399} 
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux DPVC
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  Null                                       As PAR_LASTNAME                    ,
  Null                                       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_404})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_405}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM AU.ACT_DT) +1   As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_DECLAR_PVC As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_458}  
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;  
.if errorcode <> 0 then .quit 1

-- Insertion pour flux AGC
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                       As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  Null                                                      As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  Null                                                      As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  'N/A'                                                     As ORDER_STATUT_CD                ,
  SF.ORG_CHANNEL_CD                                         As ORG_CANAL_ID_MACRO             ,
  Null                                                      As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  Null                                                      As PAR_EXTERNAL_PARTY_BSS_ID      ,
  Null                                                      As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                       As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                      As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_MOB As SF
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_409}
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_107})
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                       As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  Null                                                      As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  Null                                                      As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  'N/A'                                                     As ORDER_STATUT_CD                ,
  SF.ORG_CHANNEL_CD                                         As ORG_CANAL_ID_MACRO             ,
  Null                                                      As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  Null                                                      As PAR_EXTERNAL_PARTY_BSS_ID      ,
  Null                                                      As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                       As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                      As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_PCM As SF
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_409}
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_107})
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                       As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  Null                                                      As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  Null                                                      As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  'N/A'                                                     As ORDER_STATUT_CD                ,
  SF.ORG_CHANNEL_CD                                         As ORG_CANAL_ID_MACRO             ,
  Null                                                      As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  Null                                                      As PAR_EXTERNAL_PARTY_BSS_ID      ,
  Null                                                      As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                       As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                      As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_PRP As SF
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_409} 
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_107})
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0

;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux PCM
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  Null                                       As PAR_LASTNAME                    ,
  Null                                       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  --CASE WHEN AU.MASTER_ACTE_ID = AU.ACTE_ID THEN ${P_PIL_406}
  --    ELSE ${P_PIL_404}
  --END
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})  As CHECK_INITIAL_STATUS_CD        ,
  CASE WHEN AU.MASTER_ACTE_ID = AU.ACTE_ID THEN '${P_PIL_407}'
      ELSE '${P_PIL_405}'
  END                                          As CHECK_INITIAL_STATUS_LN       ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_363}  
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;
.if errorcode <> 0 then .quit 1

-- Insertion pour flux VAD
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                 As ACTE_ID                         ,
  AU.MASTER_ACTE_ID                          As MASTER_ACTE_ID                  ,
  AU.CPLT_ACTE_ID                            As CPLT_ACTE_ID                    ,
  AU.INTRNL_SOURCE_ID                        As INTRNL_SOURCE_ID                ,
  CATR.ACTE_DS                               As ACTE_DS                         ,
  CATR.ACTE_REM_DS                           As ACTE_REM_DS                     ,
  CATR.ACTE_VALO                             As ACTE_VALO                       ,
  CATRKPI.FAMILLE_KPI_LIB                    As FAMILLE_KPI_LIB                 ,
  CATRKPI.KPI_LIB                            As KPI_LIB                         ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                        As PRODUIT_DS                      ,
  SC.APPLI_SOURCE_ID                         As APPLI_SOURCE_ID                 ,
  Null                                       As ORDER_OPER_ID                   ,
  AU.ACT_TS                                  As ACT_TS                          ,
  AU.ACT_PRODUCT_ID_FINAL                    As ACT_PRODUCT_ID_FINAL            ,
  AU.ACT_PRODUCT_ID_PRE                      As ACT_PRODUCT_ID_PRE              ,
  AU.ACT_TYPE_COMMANDE_ID                    As ACT_TYPE_COMMANDE_ID            ,
  Null                                       As ORDER_MOTIF_DS                  ,
  AU.OPERATOR_PROVIDER_ID                    As OPERATOR_PROVIDER_ID            ,
  'N/A'                                      As ORDER_STATUT_CD                 ,
  HF.ORG_CHANNEL_CD                          As ORG_CANAL_ID_MACRO              ,
  Null                                       As ORG_CANAL_ID                    ,
  AU.ORG_REM_CHANNEL_CD                      As ORG_REM_CHANNEL_CD              ,
  AU.UNIFIED_SHOP_CD                         As UNIFIED_SHOP_CD                 ,
  AU.AGENT_ID                                As AGENT_ID                        ,
  AU.AGENT_ID_UPD                            As AGENT_ID_UPD                    ,
  AU.AGENT_ID_UPD_DT                         As AGENT_ID_UPD_DT                 ,
  AU.REAL_ACTIVITY_CD                        As REAL_ACTIVITY_CD                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')    As AGENT_FIRST_NAME                ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')     As AGENT_LAST_NAME                 ,
  AU.WORK_TEAM_LEVEL_1_CD                    As WORK_TEAM_LEVEL_1_CD            ,
  AU.WORK_TEAM_LEVEL_1_DS                    As WORK_TEAM_LEVEL_1_DS            ,
  AU.WORK_TEAM_LEVEL_2_DS                    As WORK_TEAM_LEVEL_2_DS            ,
  AU.WORK_TEAM_LEVEL_3_DS                    As WORK_TEAM_LEVEL_3_DS            ,
  AU.WORK_TEAM_LEVEL_4_DS                    As WORK_TEAM_LEVEL_4_DS            ,
  AU.MSISDN_ID                               As MSISDN_ID                       ,
  Null                                       As PAR_EXTERNAL_PARTY_BSS_ID       ,
  Null                                       As PAR_PARTY_KNB_FREG_ID           ,
  AU.NDS_VALUE_DS                            As NDS_VALUE_DS                    ,
  Null                                       As PAR_LASTNAME                    ,
  Null                                       As PAR_FIRSTNAME                   ,
  AU.ACT_SEG_COM_ID_FINAL                    As ACT_SEG_COM_ID_FINAL            ,
  AU.ACT_CD                                  As ACT_CD                          ,
  AU.ACT_PERIODE_ID                          As ACT_PERIODE_ID                  ,
  AU.OSCAR_VALUE                             As OSCAR_VALUE                     ,
  AU.CONFIRMATION_IN                         As CONFIRMATION_IN                 ,
  AU.CONFIRMATION_DT                         As CONFIRMATION_DT                 ,
  AU.CONFIRMATION_CALC_FIN_DT                As CONFIRMATION_CALC_FIN_DT        ,
  AU.DELIVERY_IN                             As DELIVERY_IN                     ,
  AU.DELIVERY_DT                             As DELIVERY_DT                     ,
  AU.DELIVERY_CALC_FIN_DT                    As DELIVERY_CALC_FIN_DT            ,
  AU.PERENNITE_IN                            As PERENNITE_IN                    ,
  AU.PERENNITE_FIN_DT                        As PERENNITE_FIN_DT                ,
  AU.PERENNITE_CALC_FIN_DT                   As PERENNITE_CALC_FIN_DT           ,
  AU.CONCURENCE_IN                           As CONCURENCE_IN                   ,
  AU.CONCURENCE_CONCLU_IN                    As CONCURENCE_CONCLU_IN            ,
  AU.CONCURENCE_ID                           As CONCURENCE_ID                   ,
  AU.CONCLDD_IN                              As CONCLDD_IN                      ,
  AU.RESULT_CD                               As RESULT_CD                       ,
  ORI.ORIGIN_DS                              As ORIGIN_DS                       ,
  REA.REASON_DS                              As REASON_DS                       ,
  --CASE WHEN AU.MASTER_ACTE_ID = AU.ACTE_ID THEN ${P_PIL_406}
  --    ELSE ${P_PIL_404}
  --END
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})    As CHECK_INITIAL_STATUS_CD        ,
  CASE WHEN AU.MASTER_ACTE_ID = AU.ACTE_ID THEN '${P_PIL_407}'
      ELSE '${P_PIL_405}'
  END                                          As CHECK_INITIAL_STATUS_LN       ,
  Null                                         As CHECK_NAT_STATUS_CD           ,
  Null                                         As CHECK_NAT_COMMENT             ,
  Null                                         As CHECK_NAT_STATUS_LN           ,
  Null                                         As CHECK_LOC_STATUS_CD           ,
  Null                                         As CHECK_LOC_COMMENT             ,
  Null                                         As CHECK_LOC_STATUS_LN           ,
  Null                                         As CHECK_VALIDT_DT               ,
  '${KNB_BATCH_DATE}'                          As CHECK_EXTRACT_TS              ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1      As CHECK_MONTH_DT                ,
  '${KNB_BATCH_DATE}'                          As CREATION_TS                   ,
  Null                                         As LAST_MODIF_TS                 ,
  Null                                         As CLOSURE_DT                    ,
  Null                                         As AUTHOR_CD                     ,
  1                                            As CURRENT_IN                    ,
  1                                            As FRESH_IN                      ,
  0                                            As COHERENCE_IN                  
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU  
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_VAD As HF
    On    AU.ACTE_ID              = HF.ACTE_ID_GEN 
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On AU.INTRNL_SOURCE_ID = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN           = 1
      And SC.CLOSURE_DT           Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
    On AU.ORIGIN_CD                 = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID     = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN          = 1
      And ORI.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On AU.REASON_CD               = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID     = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN          = 1
      And REA.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID         = ${P_PIL_364}  
  And AU.ACT_DT                   Between CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And CAST('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')   
  And AU.CHECK_VALIDT_DT          Is Null
  And AU.ACT_END_UNIFIED_DT       Is Null
  And AU.ACT_CLOSURE_DT           Is Null
  And AU.ACT_FLAG_ACT_REM         = 'O'
  And AU.ORG_REM_CHANNEL_CD       In (${L_PIL_107})
  And AU.MASTER_FLAG              = 1
  And AU.HOT_IN                   = 0
;

.if errorcode <> 0 then .quit 1





-- Extration eRDV
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Null                                                      As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  Null                                                      As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  Null                                                      As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  'N/A'                                                     As ORDER_STATUT_CD                ,
  SF.ORG_CHANNEL_CD                                         As ORG_CANAL_ID_MACRO             ,
  Null                                                      As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  Null                                                      As PAR_EXTERNAL_PARTY_BSS_ID      ,
  Null                                                      As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.CONTACT_LAST_NAME_NM, ';', ' ')               As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.CONTACT_FIRST_NAME_NM, ';', ' ')              As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_ERDV As SF
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = ${P_PIL_480}
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_107})
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1



-- COLLECTE DE STATS
Collect stat on ${KNB_PCO_TMP}.EXT_T_ACTE_CSO;
.if errorcode <> 0 then .quit 1

-- Extration CRS
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Null                                                      As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  Null                                                      As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  Null                                                      As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  'N/A'                                                     As ORDER_STATUT_CD                ,
  SF.ORG_CHANEL_CD                                          As ORG_CANAL_ID_MACRO             ,
  Null                                                      As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  Null                                                      As PAR_EXTERNAL_PARTY_BSS_ID      ,
  Null                                                      As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LAST_NAME_CUSTOMER_NM, ';', ' ')          As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRST_NAME_CUSTOMER_NM, ';', ' ')         As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_CRS As SF
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = 18
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_107})
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1


-- COLLECTE DE STATS
Collect stat on ${KNB_PCO_TMP}.EXT_T_ACTE_CSO;
.if errorcode <> 0 then .quit 1

-- Extration ETASK
/*
Insert Into ${KNB_PCO_TMP}.EXT_T_ACTE_CSO
(
  ACTE_ID                       ,
  MASTER_ACTE_ID                ,
  CPLT_ACTE_ID                  ,
  INTRNL_SOURCE_ID              ,
  ACTE_DS                       ,
  ACTE_REM_DS                   ,
  ACTE_VALO                     ,
  FAMILLE_KPI_LIB               ,
  KPI_LIB                       ,
  PRODUIT_DS                    ,
  APPLI_SOURCE_ID               ,
  ORDER_OPER_ID                 ,
  ACT_TS                        ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_TYPE_COMMANDE_ID          ,
  ORDER_MOTIF_DS                ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_STATUT_CD               ,
  ORG_CANAL_ID_MACRO            ,
  ORG_CANAL_ID                  ,
  ORG_REM_CHANNEL_CD            ,
  UNIFIED_SHOP_CD               ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  REAL_ACTIVITY_CD              ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_DS          ,
  MSISDN_ID                     ,
  PAR_EXTERNAL_PARTY_BSS_ID     ,
  PAR_PARTY_KNB_FREG_ID         ,
  NDS_VALUE_DS                  ,
  PAR_LASTNAME                  ,
  PAR_FIRSTNAME                 ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_CD                        ,
  ACT_PERIODE_ID                ,
  OSCAR_VALUE                   ,
  CONFIRMATION_IN               ,
  CONFIRMATION_DT               ,
  CONFIRMATION_CALC_FIN_DT      ,
  DELIVERY_IN                   ,
  DELIVERY_DT                   ,
  DELIVERY_CALC_FIN_DT          ,
  PERENNITE_IN                  ,
  PERENNITE_FIN_DT              ,
  PERENNITE_CALC_FIN_DT         ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 ,
  CONCLDD_IN                    ,
  RESULT_CD                     ,
  ORIGIN_DS                     ,
  REASON_DS                     ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_INITIAL_STATUS_LN       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  CHECK_EXTRACT_TS              ,
  CHECK_MONTH_DT                ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  CLOSURE_DT                    ,
  AUTHOR_CD                     ,
  CURRENT_IN                    ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  AU.ACTE_ID                                                As ACTE_ID                        ,
  AU.MASTER_ACTE_ID                                         As MASTER_ACTE_ID                 ,
  AU.CPLT_ACTE_ID                                           As CPLT_ACTE_ID                   ,
  AU.INTRNL_SOURCE_ID                                       As INTRNL_SOURCE_ID               ,
  CATR.ACTE_DS                                              As ACTE_DS                        ,
  CATR.ACTE_REM_DS                                          As ACTE_REM_DS                    ,
  CATR.ACTE_VALO                                            As ACTE_VALO                      ,
  CATRKPI.FAMILLE_KPI_LIB                                   As FAMILLE_KPI_LIB                ,
  CATRKPI.KPI_LIB                                           As KPI_LIB                        ,
  Case When AU.INTRNL_SOURCE_ID=11
        Then CATRFO.PRODUIT_DS
      Else Null
  End                                                       As PRODUIT_DS                     ,
  SC.APPLI_SOURCE_ID                                        As APPLI_SOURCE_ID                ,
  SF.ORDER_OPER_ID                                          As ORDER_OPER_ID                  ,
  AU.ACT_TS                                                 As ACT_TS                         ,
  AU.ACT_PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL           ,
  AU.ACT_PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE             ,
  AU.ACT_TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID           ,
  SF.ORDER_MOTIF_DS                                         As ORDER_MOTIF_DS                 ,
  AU.OPERATOR_PROVIDER_ID                                   As OPERATOR_PROVIDER_ID           ,
  SF.ORDER_STATUT_CD                                        As ORDER_STATUT_CD                ,
  SF.ORG_CANAL_ID_MACRO                                     As ORG_CANAL_ID_MACRO             ,
  SF.ORG_CANAL_ID                                           As ORG_CANAL_ID                   ,
  AU.ORG_REM_CHANNEL_CD                                     As ORG_REM_CHANNEL_CD             ,
  AU.UNIFIED_SHOP_CD                                        As UNIFIED_SHOP_CD                ,
  AU.AGENT_ID                                               As AGENT_ID                       ,
  AU.AGENT_ID_UPD                                           As AGENT_ID_UPD                   ,
  AU.AGENT_ID_UPD_DT                                        As AGENT_ID_UPD_DT                ,
  AU.REAL_ACTIVITY_CD                                       As REAL_ACTIVITY_CD               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_FIRST_NAME, ';', ' ')                   As AGENT_FIRST_NAME               ,
  TD_SYSFNLIB.Oreplace(AU.AGENT_LAST_NAME, ';', ' ')                    As AGENT_LAST_NAME                ,
  AU.WORK_TEAM_LEVEL_1_CD                                   As WORK_TEAM_LEVEL_1_CD           ,
  AU.WORK_TEAM_LEVEL_1_DS                                   As WORK_TEAM_LEVEL_1_DS           ,
  AU.WORK_TEAM_LEVEL_2_DS                                   As WORK_TEAM_LEVEL_2_DS           ,
  AU.WORK_TEAM_LEVEL_3_DS                                   As WORK_TEAM_LEVEL_3_DS           ,
  AU.WORK_TEAM_LEVEL_4_DS                                   As WORK_TEAM_LEVEL_4_DS           ,
  AU.MSISDN_ID                                              As MSISDN_ID                      ,
  SF.PAR_EXTERNAL_PARTY_BSS_ID                              As PAR_EXTERNAL_PARTY_BSS_ID      ,
  SF.PAR_PARTY_KNB_FREG_ID                                  As PAR_PARTY_KNB_FREG_ID          ,
  AU.NDS_VALUE_DS                                           As NDS_VALUE_DS                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_LASTNAME, ';', ' ')                       As PAR_LASTNAME                   ,
  TD_SYSFNLIB.Oreplace(SF.PAR_FIRSTNAME, ';', ' ')                      As PAR_FIRSTNAME                  ,
  AU.ACT_SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL           ,
  AU.ACT_CD                                                 As ACT_CD                         ,
  AU.ACT_PERIODE_ID                                         As ACT_PERIODE_ID                 ,
  AU.OSCAR_VALUE                                            As OSCAR_VALUE                    ,
  AU.CONFIRMATION_IN                                        As CONFIRMATION_IN                ,
  AU.CONFIRMATION_DT                                        As CONFIRMATION_DT                ,
  AU.CONFIRMATION_CALC_FIN_DT                               As CONFIRMATION_CALC_FIN_DT       ,
  AU.DELIVERY_IN                                            As DELIVERY_IN                    ,
  AU.DELIVERY_DT                                            As DELIVERY_DT                    ,
  AU.DELIVERY_CALC_FIN_DT                                   As DELIVERY_CALC_FIN_DT           ,
  AU.PERENNITE_IN                                           As PERENNITE_IN                   ,
  AU.PERENNITE_FIN_DT                                       As PERENNITE_FIN_DT               ,
  AU.PERENNITE_CALC_FIN_DT                                  As PERENNITE_CALC_FIN_DT          ,
  AU.CONCURENCE_IN                                          As CONCURENCE_IN                  ,
  AU.CONCURENCE_CONCLU_IN                                   As CONCURENCE_CONCLU_IN           ,
  AU.CONCURENCE_ID                                          As CONCURENCE_ID                  ,
  AU.CONCLDD_IN                                             As CONCLDD_IN                     ,
  AU.RESULT_CD                                              As RESULT_CD                      ,
  ORI.ORIGIN_DS                                             As ORIGIN_DS                      ,
  REA.REASON_DS                                             As REASON_DS                      ,
  COALESCE(AU.CHECK_INITIAL_STATUS_CD, ${P_PIL_402})        As CHECK_INITIAL_STATUS_CD        ,
  COALESCE(CSO.CHECK_STATUS_LN, '${P_PIL_403}')             As CHECK_INITIAL_STATUS_LN        ,
  Null                                                      As CHECK_NAT_STATUS_CD            ,
  Null                                                      As CHECK_NAT_COMMENT              ,
  Null                                                      As CHECK_NAT_STATUS_LN            ,
  Null                                                      As CHECK_LOC_STATUS_CD            ,
  Null                                                      As CHECK_LOC_COMMENT              ,
  Null                                                      As CHECK_LOC_STATUS_LN            ,
  Null                                                      As CHECK_VALIDT_DT                ,
  '${KNB_BATCH_DATE}'                                       As CHECK_EXTRACT_TS               ,
  AU.ACT_DT - EXTRACT(DAY FROM ACT_DT) +1                   As CHECK_MONTH_DT                 ,
  '${KNB_BATCH_DATE}'                                       As CREATION_TS                    ,
  Null                                                      As LAST_MODIF_TS                  ,
  Null                                                      As CLOSURE_DT                     ,
  Null                                                      As AUTHOR_CD                      ,
  1                                                         As CURRENT_IN                     ,
  1                                                         As FRESH_IN                       ,
  0                                                         As COHERENCE_IN                   
FROM
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As AU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_ETASK_INT As SF            
    On AU.ACTE_ID                         = SF.ACTE_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE As SC
    On    AU.INTRNL_SOURCE_ID             = SC.INTRNL_SOURCE_ID
      And SC.CURRENT_IN                   = 1
      And SC.CLOSURE_DT                   Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_ORIGIN As ORI
   On     AU.ORIGIN_CD                    = ORI.ORIGIN_CODE
      And AU.INTRNL_SOURCE_ID             = ORI.INTRNL_SOURCE_ID
      And ORI.CURRENT_IN                  = 1
      And ORI.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_INT_R_REASON As REA
    On    AU.REASON_CD                    = REA.REASON_CODE
      And AU.INTRNL_SOURCE_ID             = REA.INTRNL_SOURCE_ID
      And REA.CURRENT_IN                  = 1
      And REA.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORD_R_CSO As CSO
    On    AU.CHECK_INITIAL_STATUS_CD      = CSO.CHECK_STATUS_CD
      And CSO.CURRENT_IN                  = 1
      And CSO.CLOSURE_DT                  Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM As CATRKPI
    On    AU.ACT_PERIODE_ID               = CATRKPI.PERIODE_ID
      And AU.ACT_ACTE_FAMILLE_KPI         = CATRKPI.FAMILLE_KPI_ID
      And CATRKPI.CURRENT_IN              = 1
      And CATRKPI.CLOSURE_DT              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE CATRFO
    On    AU.ACT_PERIODE_ID               = CATRFO.PERIODE_ID
      And AU.ACT_PRODUCT_ID_FINAL         = CATRFO.PRODUCT_ID
      And CATRFO.CURRENT_IN               = 1
      And CATRFO.CLOSURE_DT               Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM As CATR
    On    AU.ACT_CD                       = CATR.ACTE_ID
      And AU.ACT_PERIODE_ID               = CATR.PERIODE_ID
      And CATR.CURRENT_IN                 =1
      And CATR.CLOSURE_DT                 Is Null
Where
  (1=1)
  And AU.INTRNL_SOURCE_ID       = 16
  And AU.CHECK_VALIDT_DT        Is Null
  And AU.ACT_DT                 Between Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_INF}' As DATE FORMAT'YYYYMMDD') And Cast('${KNB_PILCOM_EXTRACT_FRESH_BORNE_MAX}' As DATE FORMAT'YYYYMMDD')
  And AU.ACT_END_UNIFIED_DT     Is Null
  And AU.ACT_CLOSURE_DT         Is Null
  And AU.ACT_FLAG_ACT_REM       = 'O'
  And AU.ORG_REM_CHANNEL_CD     In (${L_PIL_048},${L_PIL_107})  
  And AU.MASTER_FLAG            = 1
  And AU.HOT_IN                 = 0
;
.if errorcode <> 0 then .quit 1

-- COLLECTE DE STATS
Collect stat on ${KNB_PCO_TMP}.EXT_T_ACTE_CSO;
.if errorcode <> 0 then .quit 1
  */

.quit 0

