-- $HEADER: mm2pco/current/sql/ATP_PIF_Placement_Consolidation_Enrichissement_Step1_CUID.sql 13_05#1 20-SEP-2016 10:54:59 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Cold_Enrichissement_CUID.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'alimentation de la table de travail pour enrichir les attributs de Conseiller PIF
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 01/08/2016      HLA           Creation
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CUID All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CUID
(
  ACTE_ID                         ,
  ORDER_DEPOSIT_DT                ,
  ORG_AGENT_ID                    ,
  ORG_NOM                         ,
  ORG_PRENOM
)
Select
  Placement.ACTE_ID                                                             AS ACTE_ID                        ,
  Placement.ORDER_DEPOSIT_DT                                                    AS ORDER_DEPOSIT_DT               ,
  Placement.ORG_AGENT_ID                                                        AS ORG_AGENT_ID                   ,
  Coalesce(RefConseiller.LAST_NAME_NM,Placement.PAR_LASTNAME )                  AS ORG_NOM                        ,
  Coalesce(RefConseiller.FIRST_NAME_NM,Placement.PAR_FIRSTNAME )                AS ORG_PRENOM                      
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 Placement
Inner Join ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefConseiller
    On  Placement.ORG_AGENT_ID = RefConseiller.AGENT_CUID
      And RefConseiller.CURRENT_IN  = 1
      And RefConseiller.CLOSURE_DT  is null
Where
  (1=1)
Qualify row_number() over (Partition By Placement.ACTE_ID Order By RefConseiller.LAST_NAME_NM desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CUID;
.if errorcode <> 0 then .quit 1

.quit 0

