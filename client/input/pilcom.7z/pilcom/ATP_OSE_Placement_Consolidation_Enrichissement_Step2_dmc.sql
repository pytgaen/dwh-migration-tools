--$HEADER:   mm2pco/current/sql/ATP_OSE_Placement_Consolidation_Enrichissement_Step1_dmc.sql 13_05#6 31-JAN-2019 16:53:33 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_OSE_Placement_Consolidation_Enrichissement_Step1_dmc.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 25/07/2018       LMU         Creation
-- 17/09/2018       JCR         Modif
--------------------------------------------------------------------------------


.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_DMC all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_DMC
(
ACTE_ID                      ,
ORDER_DEPOSIT_DT             ,
DMC_MASTER_LINE_ID           ,
DMC_CUST_TYPE_CD             ,
DMC_NDS_VALUE_DS             ,
DMC_MSISDN_ID                ,
DMC_EXTERNAL_PARTY_ID        ,
DMC_RES_VALUE_DS             ,
DMC_SERVICE_ACCESS_ID        ,
DMC_LINE_TYPE                ,
DMC_START_DT                 ,
DMC_ACTIVATION_DT            ,
DMC_POSTAL_CD                ,
PAR_INSEE_NB                 ,
DMC_DEPRTMNT_ID              ,
PAR_UNIFIED_PARTY_ID         ,
PAR_PARTY_REGRPMNT_ID        ,
PAR_CID_ID                   ,
PAR_PID_ID                   ,
PAR_FIBER_IN                 ,
PAR_FIRST_IN                 ,
PAR_BU_CD                    
)
Select 
  Placement.ACTE_ID                 as ACTE_ID                      ,
  Placement.ORDER_DEPOSIT_DT        as ORDER_DEPOSIT_DT             ,
  Ldmc.MASTER_LINE_ID               as DMC_MASTER_LINE_ID           ,
  Ldmc.TYPE_CD                      as DMC_CUST_TYPE_CD             ,
  Ldmc.TERMINTN_VALUE_DS            as DMC_NDS_VALUE_DS             ,
  Ldmc.MOBILE_PHONE_NU              as DMC_MSISDN_ID                ,
  Ldmc.EXTERNAL_PARTY_ID            as DMC_EXTERNAL_PARTY_ID        ,
  Ldmc.RES_VALUE_DS                 as DMC_RES_VALUE_DS             ,
  Ldmc.SERVICE_ACCESS_ID            as DMC_SERVICE_ACCESS_ID        ,
  Ldmc.LINE_TYPE_CD                 as DMC_LINE_TYPE                ,
  Ldmc.LINE_START_DT                as DMC_START_DT                 ,
  Ldmc.ACTIVATION_DT                as DMC_ACTIVATION_DT            ,
  Ldmc.POSTAL_CD                    as DMC_POSTAL_CD                ,
  Ldmc.INSEE_NB                     as PAR_INSEE_NB                 ,
  Ldmc.DEPRTMNT_ID                  as DMC_DEPRTMNT_ID              ,
  Ldmc.UNIFIED_PARTY_ID             as PAR_UNIFIED_PARTY_ID         ,
  Ldmc.PARTY_REGRPMNT_ID            as PAR_PARTY_REGRPMNT_ID        ,
  Ldmc.CID_ID                       as PAR_CID_ID                   ,
  Ldmc.PID_ID                       as PAR_PID_ID                   ,
  Ldmc.FIBER_IN                     as PAR_FIBER_IN                 ,
  Lfirst.FIRST_IN                   as PAR_FIRST_IN                 ,
  Geo.BU_CD                         as PAR_BU_CD                     
  
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 Placement
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_ACH Ldmc
    On    Placement.EXTRNL_SUB_LINE_ID    = Ldmc.LINE_ID
    And   Placement.EXTRNL_LINE_ID_DT + 1 >=  Ldmc.START_DT
    And   Placement.EXTRNL_LINE_ID_DT + 1 <   Ldmc.END_DT
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_FIRST_VM Lfirst
    On    Ldmc.MASTER_LINE_ID             =    Lfirst.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT Geo
    On    Geo.DEPT_CD                     =    Ldmc.DEPRTMNT_ID
  Where (1=1)
  And Placement.DMC_MASTER_LINE_ID is null

Qualify Row_Number() over (Partition by Placement.ACTE_ID 
                           Order by coalesce(Ldmc.BUSINESS_OFFER_END_DT, Ldmc.END_DT) desc,
                                   coalesce(Ldmc.BUSINESS_OFFER_BEGIN_DT, Ldmc.START_DT) desc, 
                                   Ldmc.LINE_ID desc) = 1
;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 2 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_IRIS
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_MASTER_LINE_ID        ,
  PAR_IRIS2000_CD           ,
  PAR_GEO_MACROZONE         
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_MASTER_LINE_ID                        as DMC_MASTER_LINE_ID         ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD            ,
  LFIBER.RESERV_4                                 AS PAR_GEO_MACROZONE          
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_DMC RefId
  Inner Join ${KNB_DMU_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
    on RefId.DMC_MASTER_LINE_ID = LFIBER.LINE_ID
  Where (1=1)
  And RefId.DMC_MASTER_LINE_ID is null
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT 
                           Order by LFIBER.LAST_MODIF_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_IRIS;
.if errorcode <> 0 then .quit 1


