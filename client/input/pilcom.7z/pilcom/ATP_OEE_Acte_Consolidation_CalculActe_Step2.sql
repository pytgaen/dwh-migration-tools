-- $HEADER:  mm2pco/current/sql/ATP_OEE_Acte_Consolidation_CalculActe_Step2.sql 13_05#9 06-DEC-2017 17:12:20 CLHH1829
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Acte_Consolidation_CalculActe_Step2.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
-- 07/06/2015      AOU         Multicanal
-- 23/05/2016      HLA         Axe Canal
-- 19/12/2016      HOB         Ajout Champs VA
-- 30/11/2017      MEL         IOBSP
--------------------------------------------------------------------------------

.set width 2500;




Delete from ${KNB_PCO_TMP}.INT_T_ACTE_OEE all;
.if errorcode <> 0 then .quit 1


.set width 2000;


-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.ACT_T_KC
-- **************************************************************
Delete From ${KNB_PCO_TMP}.INT_T_ACTE_OEE All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_OEE
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                               ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_FLAG_PEC_PERPVC                       ,
  ACT_ACTE_VALO                             ,
  ACT_ACTE_FAMILLE_KPI                      ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID                              ,
  ORIG_DEM                                  ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO                        ,
  ORG_CANAL_MACRO_LB                        ,
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         ,
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,
  DOSSIER_NU                                ,
  CLIENT_NU                                 ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  PAR_DEPRTMNT_ID                           ,
  PAR_POSTAL_CD                             ,
  PAR_INSEE_NB                              ,
  PAR_BU_CD                                 ,
  PAR_GEO_MACROZONE                         ,
  PAR_UNIFIED_PARTY_ID                      ,
  PAR_PARTY_REGRPMNT_ID                     ,
  PAR_CID_ID                                ,
  PAR_PID_ID                                ,
  PAR_FIRST_IN                              ,
  ORG_AGENT_IOBSP                           ,
  ORG_EDO_IOBSP                             ,
  PAR_IRIS2000_CD                           ,
  PAR_FIBER_IN                              ,
  DMC_LINE_TYPE                             ,
  DMC_ACTIVATION_DT                         ,
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU                              ,
  PAR_SCORE_IN                              ,
  PAR_TRESHOLD_NU                           ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,  
  PERENNITE_PVC_FIN_DT                      ,  
  PERENNITE_PVC_CALC_FIN_DT                 ,  
  SEG_PRES_PARC_COMMANDE                    ,  
  MIGRA_DT                                  ,  
  MIGRA_NEXT_OFFRE                          ,  
  RESIL_INT_DT                              ,  
  RESIL_INT_MOTIF                           ,  
  RESIL_INT_MOTIF_DS                        ,  
  SEG_COM_ID_LAST_PER                       ,  
  SEG_COM_ID_SOLD                           ,  
  SEG_COM_ID_FIND                           ,  
  SEG_FIND_LIVR_DT                          ,  
  SEG_FIND_CANCEL_DT                        ,  
  SEG_COM_ID_NEXT_PARC                      ,  
  SEG_NEXT_PARC_LIVR_DT                     ,  
  SEG_NEXT_PARC_CANCEL_DT                   ,  
  SEG_COM_ID_FINAL_PARC                     ,  
  SEG_FINAL_PARC_LIVR_DT                    ,  
  SEG_FINAL_PARC_CANCEL_DT                  ,  
  SEG_COM_ID_LAST_IN_PARC                   ,  
  NB_IN_OUT_PARC                            ,  
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              
)
Select
  Placement.ACTE_ID                                                                     as ACTE_ID                                ,
  Placement.ACTE_ID                                                                     as ACTE_ID_GEN                            ,
  Placement.DEMANDE_ID                                                                  as DEMANDE_ID                             ,
  Placement.EXTERNAL_INT_ID                                                             as EXTERNAL_INT_ID                        ,
  Placement.INT_DEPOSIT_TS                                                              as INT_DEPOSIT_TS                         ,
  Placement.INT_DEPOSIT_DT                                                              as INT_DEPOSIT_DT                         ,
  Placement.OPERATOR_PROVIDER_ID                                                        as OPERATOR_PROVIDER_ID                   ,
  Placement.RESOLU_ID                                                                   as RESOLU_ID                              ,
  Placement.CONCLU_ID                                                                   as CONCLU_ID                              ,
  Placement.SSCONCLU_ID                                                                 as SSCONCLU_ID                            ,
  Placement.INT_MODIF_TS                                                                as INT_MODIF_TS                           ,
  --Information sur la source :
  Placement.PLTF_CO                                                                     as PLTF_CO                                ,
  Placement.INTRNL_SOURCE_ID                                                            as INTRNL_SOURCE_ID                       ,
  --Info de OEErus
  Null                                                                                  as SOLDOFF_SRC_CD                         ,
  Null                                                                                  as OTO_OFFER_CD                           ,
  Null                                                                                  as OTO_OFFER_TYPE_CD                      ,
  --Information LiÃ©e aux produit et acte :
  --produit precedant :
  RefId.PRODUCT_ID_PRE                                                                  as ACT_PRODUCT_ID_PRE                     ,
  RefId.SEG_COM_ID_PRE                                                                  as ACT_SEG_COM_ID_PRE                     ,
  RefId.SEG_COM_AGG_ID_PRE                                                              as ACT_SEG_COM_AGG_ID_PRE                 ,
  RefId.CODE_MIGR_PRE                                                                   as ACT_CODE_MIGR_PRE                      ,
  --Produit Vendu :
  RefId.PRODUCT_ID_FINAL                                                                as ACT_PRODUCT_ID_FINAL,
  Coalesce(RefPer.TYPE_OT_SO,Placement.TYPE_OT_SO)                                      as TYPE_OT_SO                             ,
  Coalesce(RefPer.IN_CLIDOS,Placement.IN_CLIDOS)                                        as IN_CLIDOS                              ,
  RefId.SEG_COM_ID_FINAL                                                                as ACT_SEG_COM_ID_FINAL                   ,
  RefId.SEG_COM_AGG_ID_FINAL                                                            as ACT_SEG_COM_AGG_ID_FINAL               ,
  RefId.CODE_MIGR_FINAL                                                                 as ACT_CODE_MIGR_FINAL                    ,
  RefId.TYPE_SERVICE_FINAL                                                              as ACT_TYPE_SERVICE_FINAL                 ,
  --Calcul de l'acte :
  RefId.TYPE_COMMANDE_ID                                                                as ACT_TYPE_COMMANDE_ID                   ,
  RefId.DELTA_TARIF                                                                     as ACT_DELTA_TARIF                        ,
  --Calcul de l'acte avec les diffÃ©rents cas de rejets :
  Case  When  MatSC.ACTE_ID Is Not Null
          Then  MatSC.ACTE_ID
        --Cas de rejet sur les pÃ©riodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  RefId.PERIODE_ID      = ${P_PIL_049}
          Then  '${P_PIL_217}'
        -- c'est un nouveau produit paramÃ©trÃ©, donc les anciennes pÃ©riodes ne le connnaissent pas
        When RefId.SEG_COM_ID_FINAL in ('${P_PIL_022}')
          Then '${P_PIL_323}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        When RefId.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        --Cas de rejet sur le produit prÃ©cÃ©dant, Produit Non retrouvÃ© dans Pilcom et qu'il s'agit d'un OT -> ERR_ACTE_INCO_PRESTA_PRE_CALC_PILCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_215}' And Coalesce(RefPer.TYPE_OT_SO,Placement.TYPE_OT_SO) ='OT'
          Then  '${P_PIL_218}'
        --Cas de rejet sur le produit prÃ©cÃ©dant, Produit Non retrouvÃ© dans RefCom et qu'il s'agit d'un OT-> ERR_ACTE_INCO_PRESTA_PRE_REFCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_216}' And Coalesce(RefPer.TYPE_OT_SO,Placement.TYPE_OT_SO) ='OT'
          Then  '${P_PIL_219}'
        --Si la migration de l'init vers le final n'est pas paramÃ©trÃ©e -> ERR_ACTE_INCO_MIGR_NON_PARAM_REFCOM
        When  RefId.CODE_MIGR_PRE  Is Not Null And RefId.CODE_MIGR_FINAL Is Not Null And RefId.TYPE_COMMANDE_ID ='${P_PIL_045}'
          Then  '${P_PIL_222}'
        --Sinon c'est un problÃ¨me dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                                                   as ACT_CD                                 ,
  Coalesce(RefActeSC.ACTE_REM_ID,'${P_PIL_067}')                                        as ACT_REM_ID                             ,
  Coalesce(RefActeSC.FLAG_ACT_REM,'N')                                                  as ACT_FLAG_ACT_REM                       ,
  Coalesce(RefActeSC.FLAG_PEC_PERPVC,'N')                                               as ACT_FLAG_PEC_PERPVC                    ,
  Coalesce(RefActeSC.ACTE_VALO,0)                                                       as ACT_ACTE_VALO                          ,
  Coalesce(RefActeSC.ACTE_FAMILLE_KPI,'NON PARAM')                                      as ACT_ACTE_FAMILLE_KPI                   ,
  RefId.PERIODE_ID                                                                      as ACT_PERIODE_ID                         ,
  Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                                             as ACT_PERIODE_STATUS                     ,
  EtatPeriode.PERIODE_CLOSURE_DT                                                        as ACT_PERIODE_CLOSURE_DT                 ,
  --Information sur le code prestation retrouvÃ© en parc
  Coalesce(RefPer.INB_PRESFACT_ACQ_ADV,Placement.INB_PRESFACT_ACQ_ADV)                  as INB_PRESFACT_ACQ_ADV                   ,
  Coalesce(RefPer.INB_PRESFACT_ACQ_AGAP,Placement.INB_PRESFACT_ACQ_AGAP)                as INB_PRESFACT_ACQ_AGAP                  ,
  Coalesce(RefPer.SEG_PARC_DT_DEBUT,Placement.PARC_DT_DEBUT)                            as SEG_PARC_DT_DEBUT                      ,
  --Infos sur le canal de vente
  'APS'                                                                                 as ORG_CANAL_ID                           ,
  Coalesce(OrigineVente.ORIG_DEM,Placement.CANALDEM)                                    as ORIG_DEM                               ,
  Null                                                                                  as CANALDEM_MTHD                          ,
  CanalVenteMacroPrem.ORG_CANAL_ID_MACRO                                                as ORG_CANAL_ID_MACRO                     ,
  CanalVenteMacroPrem.ORG_CANAL_MACRO_LB                                                as ORG_CANAL_MACRO_LB                     ,
  --Alimentation Orga
  RefO3.ORG_CHANEL_CD                                                                   as ORG_CHANNEL_CD                         ,
  RefO3.ORG_SUB_CHANEL_CD                                                               as ORG_SUB_CHANNEL_CD                     ,
  RefO3.ORG_SUB_SUB_CHANEL_CD                                              				as ORG_SUB_SUB_CHANNEL_CD                 ,
  RefO3.ORG_REM_CHANEL_CD                                           				    as ORG_REM_CHANNEL_CD                     ,
  RefO3.ORG_GT_ACTIVITY                                           						as ORG_GT_ACTIVITY                        ,
  RefO3.ORG_FIDELISATION                                          				    	as ORG_FIDELISATION                       ,
  RefO3.ORG_WEB_ACTIVITY                                           					    as ORG_WEB_ACTIVITY                       ,
  RefO3.ORG_AUTO_ACTIVITY                                           					as ORG_AUTO_ACTIVITY                      ,
  RefO3.EDO_ID                                           					            as ORG_EDO_ID                             ,
  RefO3.TYPE_EDO                                           						        as ORG_TYPE_EDO                           ,
  Placement.FLAG_PLT_CONV                                                               as ORG_FLAG_PLT_CONV                      ,
  Placement.FLAG_TEAM_MKT                                                               as ORG_FLAG_TEAM_MKT                      ,
  Placement.FLAG_TYPE_CMP                                                               as ORG_FLAG_TYPE_CMP                      ,
  Placement.EDO_ID_HIER                                                                 as ORG_EDO_ID_HIER                        ,
  Placement.TYPE_EDO_HIER                                                               as ORG_TYPE_EDO_HIER                      ,
  Placement.ORG_REF_TRAV                                                                as ORG_REF_TRAV                           ,
  Placement.ORG_AGENT_ID                                                                as ORG_AGENT_ID                           ,
  Placement.ORG_POC_XI                                                                  as ORG_POC_XI                             ,
  Placement.ORG_NOM                                                                     as ORG_NOM                                ,
  Placement.ORG_PRENOM                                                                  as ORG_PRENOM                             ,
  Placement.ORG_GROUPE_ID                                                               as ORG_GROUPE_ID                          ,
  Placement.ORG_GROUPE_ID_HIER                                                          as ORG_GROUPE_ID_HIER                     ,
  Placement.ORG_ACTVT_REEL                                                              as ORG_ACTVT_REEL                         ,
  Placement.ORG_RESP_REF_TRAV                                                           as ORG_RESP_REF_TRAV                      ,
  Placement.ORG_RESP_AGENT_ID                                                           as ORG_RESP_AGENT_ID                      ,
  Placement.ORG_RESP_XI                                                                 as ORG_RESP_XI                            ,
  Null                                                                                  as ORG_RESP_EDO_ID                        ,
  Null                                                                                  as ORG_RESP_TYPE_EDO                      ,
  Null                                                                                  as ORG_RESP_FLAG_PLT_CONV                 ,
  Trim(RefO3.ORG_TEAM_LEVEL_1_CD)                                                       as ORG_TEAM_LEVEL_1_CD                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_1_DS)                                                       as ORG_TEAM_LEVEL_1_DS                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_2_CD)                                                       as ORG_TEAM_LEVEL_2_CD                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_2_DS)                                                       as ORG_TEAM_LEVEL_2_DS                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_3_CD)                                                       as ORG_TEAM_LEVEL_3_CD                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_3_DS)                                                       as ORG_TEAM_LEVEL_3_DS                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_4_CD)                                                       as ORG_TEAM_LEVEL_4_CD                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_4_DS)                                                       as ORG_TEAM_LEVEL_4_DS                    ,
  Trim(RefO3.WORK_TEAM_LEVEL_1_CD)                                                      as WORK_TEAM_LEVEL_1_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_1_DS)                                                      as WORK_TEAM_LEVEL_1_DS                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_2_CD)                                                      as WORK_TEAM_LEVEL_2_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_2_DS)                                                      as WORK_TEAM_LEVEL_2_DS                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_3_CD)                                                      as WORK_TEAM_LEVEL_3_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_3_DS)                                                      as WORK_TEAM_LEVEL_3_DS                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_4_CD)                                                      as WORK_TEAM_LEVEL_4_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_4_DS)                                                      as WORK_TEAM_LEVEL_4_DS                   ,
  --Information client
  Placement.DOSSIER_NU                                                                  as DOSSIER_NU                             ,
  Placement.CLIENT_NU                                                                   as CLIENT_NU                              ,
  Placement.DMC_LINE_ID                                                                 as DMC_LINE_ID                            ,
  Placement.DMC_MASTER_LINE_ID                                                          as DMC_MASTER_LINE_ID                     ,
  Placement.PAR_DEPRTMNT_ID                                                             as PAR_DEPRTMNT_ID                        ,
  Placement.PAR_POSTAL_CD                                                               as PAR_POSTAL_CD                          ,
  Placement.PAR_INSEE_NB                                                                as PAR_INSEE_NB                           ,
  Placement.PAR_BU_CD                                                                   as PAR_BU_CD                              ,
  Placement.PAR_GEO_MACROZONE	                                                        as PAR_GEO_MACROZONE ,
  Placement.PAR_UNIFIED_PARTY_ID                                                        as PAR_UNIFIED_PARTY_ID ,
  Placement.PAR_PARTY_REGRPMNT_ID                                                       as PAR_PARTY_REGRPMNT_ID,
  Placement.PAR_CID_ID                                                                  as PAR_CID_ID                             ,
  Placement.PAR_PID_ID                                                                  as PAR_PID_ID                             ,
  Placement.PAR_FIRST_IN                                                                as PAR_FIRST_IN                           ,
  Placement.ORG_AGENT_IOBSP                                                             as ORG_AGENT_IOBSP                        ,
  Placement.ORG_EDO_IOBSP                                                               as ORG_EDO_IOBSP                          ,
  Placement.PAR_IRIS2000_CD                                                             as PAR_IRIS2000_CD                        ,
  Placement.PAR_FIBER_IN                                                                as PAR_FIBER_IN                           ,
  Placement.DMC_LINE_TYPE                                                               as DMC_LINE_TYPE                          ,
  Placement.DMC_ACTIVATION_DT                                                           as DMC_ACTIVATION_DT                      ,
  Placement.DMC_CONVERGENT_IN                                                           as DMC_CONVERGENT_IN                      ,
  Placement.DMC_LINE_ID_INT                                                             as DMC_LINE_ID_INT                        ,
  Placement.DMC_LINE_TYPE_INT                                                           as DMC_LINE_TYPE_INT                      ,
  Placement.DMC_ACTIVATION_DT_INT                                                       as DMC_ACTIVATION_DT_INT                  ,
  Placement.DMC_SERVICE_ACCESS_ID                                                       as DMC_SERVICE_ACCESS_ID                  ,
  Placement.OFFRE_INT_PRE                                                               as OFFRE_INT_PRE                          ,
  Null                                                                                  as OTO_OSCAR_VALUE_NU                     ,
  Placement.PAR_LASTNAME                                                                as PAR_LASTNAME                           ,
  Placement.PAR_FIRSTNAME                                                               as PAR_FIRSTNAME                          ,
  Placement.PAR_TYPE                                                                    as PAR_TYPE                               ,
  Placement.PAR_IMSI                                                                    as PAR_IMSI                               ,
  Placement.PAR_EMAIL                                                                   as PAR_EMAIL                              ,
  Placement.PAR_BILL_ADRESS_1                                                           as PAR_BILL_ADRESS_1                      ,
  Placement.PAR_BILL_ADRESS_2                                                           as PAR_BILL_ADRESS_2                      ,
  Placement.PAR_BILL_ADRESS_3                                                           as PAR_BILL_ADRESS_3                      ,
  Placement.PAR_BILL_ADRESS_4                                                           as PAR_BILL_ADRESS_4                      ,
  Placement.PAR_BILL_VILLE                                                              as PAR_BILL_VILLE                         ,
  Placement.PAR_BILL_CD_POSTAL                                                          as PAR_BILL_CD_POSTAL                     ,
  Placement.PAR_INSEE_CD                                                                as PAR_INSEE_CD                           ,
  Placement.PAR_DO                                                                      as PAR_DO                                 ,
  Placement.PAR_USCM                                                                    as PAR_USCM                               ,
  Placement.PAR_USCM_DS                                                                 as PAR_USCM_DS                            ,
  Placement.PAR_USCM_USCM_DS                                                            as PAR_USCM_USCM_DS                       ,
  Placement.PAR_USCM_REGUSCM                                                            as PAR_USCM_REGUSCM                       ,
  Placement.PAR_USCM_REGUSCM_DS                                                         as PAR_USCM_REGUSCM_DS                    ,
  Placement.PAR_AID                                                                     as PAR_AID                                ,
  Placement.PAR_ND                                                                      as PAR_ND                                 ,
  Placement.PAR_MOB_IMEI                                                                as PAR_MOB_IMEI                           ,
  Placement.PAR_MOB_TAC                                                                 as PAR_MOB_TAC                            ,
  Placement.PAR_MOB_SIM                                                                 as PAR_MOB_SIM                            ,
  --Segementation client :
  Placement.PAR_SCORE_NU                                                                as PAR_SCORE_NU                           ,
  Placement.PAR_SCORE_IN                                                                as PAR_SCORE_IN                           ,
  Placement.PAR_TRESHOLD_NU                                                             as PAR_TRESHOLD_NU                        ,
  Placement.PAR_SCORE_NU_INT                                                            as PAR_SCORE_NU_INT                       ,
  Placement.PAR_SCORE_IN_INT                                                            as PAR_SCORE_IN_INT                       ,
  Placement.PAR_TRESHOLD_NU_INT                                                         as PAR_TRESHOLD_NU_INT                    ,
  --Contrat Avec le client :
  Placement.CONTRCT_DT_SIGN_PREC                                                        as CONTRCT_DT_SIGN_PREC                   ,
  Placement.CONTRCT_DT_FIN_PREC                                                         as CONTRCT_DT_FIN_PREC                    ,
  Placement.CONTRCT_DT_SIGN_POST                                                        as CONTRCT_DT_SIGN_POST                   ,
  Placement.CONTRCT_DUREE_ENG                                                           as CONTRCT_DUREE_ENG                      ,
  Placement.CONTRCT_UNIT_ENG                                                            as CONTRCT_UNIT_ENG                       ,
    --Attributs de pÃ©rÃ©nitÃ©   :
  RefPer.CONFIRMATION_IN                                                                as CONFIRMATION_IN                        ,
  RefPer.CONFIRMATION_DT                                                                as CONFIRMATION_DT                        ,
  RefPer.CONFIRMATION_CALC_FIN_DT                                                       as CONFIRMATION_CALC_FIN_DT               ,
  RefPer.DELIVERY_IN                                                                    as DELIVERY_IN                            ,
  RefPer.DELIVERY_DT                                                                    as DELIVERY_DT                            ,
  RefPer.DELIVERY_CALC_FIN_DT                                                           as DELIVERY_CALC_FIN_DT                   ,
  RefPer.PERENNITE_IN                                                                   as PERENNITE_IN                           ,
  RefPer.PERENNITE_FIN_DT                                                               as PERENNITE_FIN_DT                       ,
  RefPer.PERENNITE_CALC_FIN_DT                                                          as PERENNITE_CALC_FIN_DT                  ,
  PerPVC.PERENNITE_PVC_IN                                                               as PERENNITE_PVC_IN                       ,
  PerPVC.PERENNITE_PVC_FIN_DT                                                           as PERENNITE_PVC_FIN_DT                   ,
  PerPVC.PERENNITE_PVC_CALC_FIN_DT                                                      as PERENNITE_PVC_CALC_FIN_DT              ,
  Case  --Si le segment est dÃ©jÃ  en parc alors on positionne le flag Ã  Oui
        When PerDejPres.ACTE_ID Is Not Null 
          Then  1
        Else    0
  End                                                                                   as SEG_PRES_PARC_COMMANDE                 ,
  PerPVC.SEG_NEXT_PARC_LIVR_DT                                                          as MIGRA_DT                               ,
  PerPVC.SEG_COM_ID_NEXT_PARC                                                           as MIGRA_NEXT_OFFRE                       ,
  Placement.DOSSIER_DATE_RESIL                                                          as RESIL_INT_DT                           ,
  Placement.DOSSIER_TYPE_RESIL                                                          as RESIL_INT_MOTIF                        ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as RESIL_INT_MOTIF_DS                     ,
  PerPVC.SEG_COM_ID_LAST_PER                                                            as SEG_COM_ID_LAST_PER                    ,
  PerPVC.SEG_COM_ID_SOLD                                                                as SEG_COM_ID_SOLD                        ,
  PerPVC.SEG_COM_ID_FIND                                                                as SEG_COM_ID_FIND                        ,
  PerPVC.SEG_FIND_LIVR_DT                                                               as SEG_FIND_LIVR_DT                       ,
  PerPVC.SEG_FIND_CANCEL_DT                                                             as SEG_FIND_CANCEL_DT                     ,
  PerPVC.SEG_COM_ID_NEXT_PARC                                                           as SEG_COM_ID_NEXT_PARC                   ,
  PerPVC.SEG_NEXT_PARC_LIVR_DT                                                          as SEG_NEXT_PARC_LIVR_DT                  ,
  PerPVC.SEG_NEXT_PARC_CANCEL_DT                                                        as SEG_NEXT_PARC_CANCEL_DT                ,
  PerPVC.SEG_COM_ID_FINAL_PARC                                                          as SEG_COM_ID_FINAL_PARC                  ,
  PerPVC.SEG_FINAL_PARC_LIVR_DT                                                         as SEG_FINAL_PARC_LIVR_DT                 ,
  PerPVC.SEG_FINAL_PARC_CANCEL_DT                                                       as SEG_FINAL_PARC_CANCEL_DT               ,
  PerPVC.SEG_COM_ID_LAST_IN_PARC                                                        as SEG_COM_ID_LAST_IN_PARC                ,
  PerPVC.NB_IN_OUT_PARC                                                                 as NB_IN_OUT_PARC                         ,
  PerPVC.POURCENTAGE_PRES_PARC                                                          as POURCENTAGE_PRES_PARC                  ,
  --Calcul si la livraison Ã  eu lieu dans les temps :
  Case  When RefPer.DELIVERY_DT is Null
          Then 'NA'
        When Delais.DELAIS is Null 
          --Dans le cas oÃ¹ le delais est null alors on a pas pu Ã©valuer : NC
          Then 'NC'
        When ( Placement.INT_DEPOSIT_DT + Cast(Delais.DELAIS as interval day(4))) >= RefPer.DELIVERY_DT
          -- Dans le cas oÃ¹ on est dans le dÃ©lais :
          Then  'O'
          --Sinon on n'est pas dans les clous
        Else    'N'
  End                                                                                   as DELIVERY_ONTIME_IN                     ,
  'NA'                                                                                  as CONCURENCE_IN                          ,
  'NA'                                                                                  as CONCURENCE_CONCLU_IN                   ,
  Null                                                                                  as CONCURENCE_ID                          ,
  Null                                                                                  as CLOSURE_DT                             ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                            ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS                          ,
  1                                                                                     as FRESH_IN                               ,
  0                                                                                     as COHERENCE_IN                           
From
  ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_OEE Placement
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_CALC RefId
    On    Placement.ACTE_ID                             = RefId.ACTE_ID
      And Placement.INT_DEPOSIT_DT                      = RefId.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM MatSC
    On    RefId.TYPE_COMMANDE_ID                        = MatSC.TYPE_COMMANDE_ID
      And RefId.SEG_COM_ID_FINAL                        = MatSC.SEG_COM_ID_FINAL
      And Coalesce(RefId.SEG_COM_ID_PRE,'${P_PIL_211}') = MatSC.SEG_COM_ID_INI
      And RefId.PERIODE_ID                              = MatSC.PERIODE_ID
      And MatSC.CATEGORIE_CLIENT_ID                     = 'SC' --CatÃ©gorie Oscar
      And MatSC.FRESH_IN                                = 1
      And MatSC.CURRENT_IN                              = 1
      And MatSC.CLOSURE_DT                              is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM    RefActeSC
    On    MatSC.ACTE_ID                                 = RefActeSC.ACTE_ID
      And MatSC.PERIODE_ID                              = RefActeSC.PERIODE_ID
      And RefActeSC.FRESH_IN                            = 1
      And RefActeSC.CURRENT_IN                          = 1
      And RefActeSC.CLOSURE_DT                          Is Null
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_PER RefPer
    On    RefPer.ACTE_ID                                = RefId.ACTE_ID
      And RefPer.INT_DEPOSIT_DT                         = RefId.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On    RefId.TYPE_COMMANDE_ID                        = Delais.TYPE_COMMANDE_ID
      And RefId.TYPE_SERVICE_FINAL                      = Delais.TYPE_SERVICE
      And RefId.PERIODE_ID                              = Delais.PERIODE_ID
      And Delais.FRESH_IN                               = 1
      And Delais.CURRENT_IN                             = 1
      And Delais.CLOSURE_DT                     is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_ORIG_DEM OrigineVente
    On    Placement.ORG_REF_TRAV                        =  OrigineVente.ORG_REF_TRAV
      And Placement.ORG_GROUPE_ID                       =  OrigineVente.ORG_GROUPE_ID
      And Placement.PLTF_CO                             =  OrigineVente.APPLI_SOURCE_ID
      And Placement.INT_DEPOSIT_DT                      >= OrigineVente.GRP_DT_DEB
      And Placement.INT_DEPOSIT_DT                      <= OrigineVente.GRP_DT_FIN
      And OrigineVente.FRESH_IN                         =  1
      And OrigineVente.CURRENT_IN                       =  1
      And OrigineVente.CLOSURE_DT                       is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_CANAL_VENTE CanalVenteMacroPrem
    On    OrigineVente.ORIG_DEM                         = CanalVenteMacroPrem.ORIG_DEM
      And CanalVenteMacroPrem.FRESH_IN                  = 1
      And CanalVenteMacroPrem.CURRENT_IN                = 1
      And CanalVenteMacroPrem.CLOSURE_DT                is Null
	  
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_O3 RefO3
    On    Placement.ACTE_ID        = RefO3.ACTE_ID
      And Placement.INT_DEPOSIT_DT = RefO3.INT_DEPOSIT_DT
	  
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_PER_FULL PerPVC
    On    Placement.ACTE_ID        = PerPVC.ACTE_ID
      And Placement.INT_DEPOSIT_DT = PerPVC.INT_DEPOSIT_DT
	  
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_DEJPRES PerDejPres
    On    Placement.ACTE_ID        = PerDejPres.ACTE_ID
      And Placement.INT_DEPOSIT_DT = PerDejPres.INT_DEPOSIT_DT
	  
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    RefId.PERIODE_ID                                    = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                                = 1
      And EtatPeriode.FRESH_IN                                  = 1
      And EtatPeriode.CLOSURE_DT                                Is Null
Where
      (
        --On veut suivre les produits :
            --Qui sont sur une pÃ©riode valable :
                RefId.PERIODE_ID  <> ${P_PIL_049}
            --Et qui sont sur un segment suivi
            And RefId.SEG_COM_ID_FINAL not in ('${P_PIL_022}','${P_PIL_295}')
      )
;Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_OEE
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                             ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_FLAG_PEC_PERPVC                       ,
  ACT_ACTE_VALO                             ,
  ACT_ACTE_FAMILLE_KPI                      ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID                              ,
  ORIG_DEM                                  ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO                        ,
  ORG_CANAL_MACRO_LB                        ,
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         ,
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,
  DOSSIER_NU                                ,
  CLIENT_NU                                 ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  PAR_DEPRTMNT_ID                           ,
  PAR_POSTAL_CD                             ,
  PAR_INSEE_NB                              ,
  PAR_BU_CD                                 ,
  PAR_GEO_MACROZONE ,
	 PAR_UNIFIED_PARTY_ID ,
	 PAR_PARTY_REGRPMNT_ID,
  PAR_IRIS2000_CD                           ,
  DMC_LINE_TYPE                             ,
  DMC_ACTIVATION_DT                         ,
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU                              ,
  PAR_SCORE_IN                              ,
  PAR_TRESHOLD_NU                           ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,  
  PERENNITE_PVC_FIN_DT                      ,  
  PERENNITE_PVC_CALC_FIN_DT                 ,  
  SEG_PRES_PARC_COMMANDE                    ,  
  MIGRA_DT                                  ,  
  MIGRA_NEXT_OFFRE                          ,  
  RESIL_INT_DT                              ,  
  RESIL_INT_MOTIF                           ,  
  RESIL_INT_MOTIF_DS                        ,  
  SEG_COM_ID_LAST_PER                       ,  
  SEG_COM_ID_SOLD                           ,  
  SEG_COM_ID_FIND                           ,  
  SEG_FIND_LIVR_DT                          ,  
  SEG_FIND_CANCEL_DT                        ,  
  SEG_COM_ID_NEXT_PARC                      ,  
  SEG_NEXT_PARC_LIVR_DT                     ,  
  SEG_NEXT_PARC_CANCEL_DT                   ,  
  SEG_COM_ID_FINAL_PARC                     ,  
  SEG_FINAL_PARC_LIVR_DT                    ,  
  SEG_FINAL_PARC_CANCEL_DT                  ,  
  SEG_COM_ID_LAST_IN_PARC                   ,  
  NB_IN_OUT_PARC                            ,  
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              
)
Select
  Placement.ACTE_ID                                                                     as ACTE_ID                                ,
  Placement.ACTE_ID                                                                     as ACTE_ID_GEN                            ,
  Placement.DEMANDE_ID                                                                  as DEMANDE_ID                             ,
  Placement.EXTERNAL_INT_ID                                                             as EXTERNAL_INT_ID                        ,
  Placement.INT_DEPOSIT_TS                                                              as INT_DEPOSIT_TS                         ,
  Placement.INT_DEPOSIT_DT                                                              as INT_DEPOSIT_DT                         ,
  Placement.OPERATOR_PROVIDER_ID                                                        as OPERATOR_PROVIDER_ID                   ,
  Placement.RESOLU_ID                                                                   as RESOLU_ID                              ,
  Placement.CONCLU_ID                                                                   as CONCLU_ID                              ,
  Placement.SSCONCLU_ID                                                                 as SSCONCLU_ID                            ,
  Placement.INT_MODIF_TS                                                                as INT_MODIF_TS                           ,
  --Information sur la source :
  Placement.PLTF_CO                                                                     as PLTF_CO                                ,
  Placement.INTRNL_SOURCE_ID                                                            as INTRNL_SOURCE_ID                       ,
  --Info de OEErus
  Null                                                                                  as SOLDOFF_SRC_CD                         ,
  Null                                                                                  as OTO_OFFER_CD                           ,
  Null                                                                                  as OTO_OFFER_TYPE_CD                      ,
  --Information LiÃ©e aux produit et acte :
  --produit precedant :
  RefId.PRODUCT_ID_PRE                                                                  as ACT_PRODUCT_ID_PRE                     ,
  RefId.SEG_COM_ID_PRE                                                                  as ACT_SEG_COM_ID_PRE                     ,
  RefId.SEG_COM_AGG_ID_PRE                                                              as ACT_SEG_COM_AGG_ID_PRE                 ,
  RefId.CODE_MIGR_PRE                                                                   as ACT_CODE_MIGR_PRE                      ,
  --Produit Vendu :
  RefId.PRODUCT_ID_FINAL                                                                as ACT_PRODUCT_ID_FINAL,
  Coalesce(RefPer.TYPE_OT_SO,Placement.TYPE_OT_SO)                                      as TYPE_OT_SO                             ,
  Coalesce(RefPer.IN_CLIDOS,Placement.IN_CLIDOS)                                        as IN_CLIDOS                              ,
  RefId.SEG_COM_ID_FINAL                                                                as ACT_SEG_COM_ID_FINAL                   ,
  RefId.SEG_COM_AGG_ID_FINAL                                                            as ACT_SEG_COM_AGG_ID_FINAL               ,
  RefId.CODE_MIGR_FINAL                                                                 as ACT_CODE_MIGR_FINAL                    ,
  RefId.TYPE_SERVICE_FINAL                                                              as ACT_TYPE_SERVICE_FINAL                 ,
  --Calcul de l'acte :
  RefId.TYPE_COMMANDE_ID                                                                as ACT_TYPE_COMMANDE_ID                   ,
  RefId.DELTA_TARIF                                                                     as ACT_DELTA_TARIF                        ,
  --Calcul de l'acte avec les diffÃ©rents cas de rejets :
  Case  --Cas de rejet sur les pÃ©riodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  RefId.PERIODE_ID      = ${P_PIL_049}
          Then  '${P_PIL_217}'
        -- c'est un nouveau produit paramÃ©trÃ©, donc les anciennes pÃ©riodes ne le connnaissent pas
        When RefId.SEG_COM_ID_FINAL in ('${P_PIL_022}')
          Then '${P_PIL_323}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        When RefId.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        --Cas de rejet sur le produit prÃ©cÃ©dant, Produit Non retrouvÃ© dans Pilcom et qu'il s'agit d'un OT -> ERR_ACTE_INCO_PRESTA_PRE_CALC_PILCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_215}' And Coalesce(RefPer.TYPE_OT_SO,Placement.TYPE_OT_SO) ='OT'
          Then  '${P_PIL_218}'
        --Cas de rejet sur le produit prÃ©cÃ©dant, Produit Non retrouvÃ© dans RefCom et qu'il s'agit d'un OT-> ERR_ACTE_INCO_PRESTA_PRE_REFCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_216}' And Coalesce(RefPer.TYPE_OT_SO,Placement.TYPE_OT_SO) ='OT'
          Then  '${P_PIL_219}'
        --Si la migration de l'init vers le final n'est pas paramÃ©trÃ©e -> ERR_ACTE_INCO_MIGR_NON_PARAM_REFCOM
        When  RefId.CODE_MIGR_PRE  Is Not Null And RefId.CODE_MIGR_FINAL Is Not Null And RefId.TYPE_COMMANDE_ID ='${P_PIL_045}'
          Then  '${P_PIL_222}'
        --Sinon c'est un problÃ¨me dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                                                   as ACT_CD                                 ,
  '${P_PIL_067}'                                                                        as ACT_REM_ID                             ,
  'N'                                                                                   as ACT_FLAG_ACT_REM                       ,
  'N'                                                                                   as ACT_FLAG_PEC_PERPVC                    ,
  0                                                                                     as ACT_ACTE_VALO                          ,
  'NON PARAM'                                                                           as ACT_ACTE_FAMILLE_KPI                   ,
  RefId.PERIODE_ID                                                                      as ACT_PERIODE_ID                         ,
  Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                                             as ACT_PERIODE_STATUS                     ,
  EtatPeriode.PERIODE_CLOSURE_DT                                                        as ACT_PERIODE_CLOSURE_DT                 ,
  --Information sur le code prestation retrouvÃ© en parc
  Coalesce(RefPer.INB_PRESFACT_ACQ_ADV,Placement.INB_PRESFACT_ACQ_ADV)                  as INB_PRESFACT_ACQ_ADV                   ,
  Coalesce(RefPer.INB_PRESFACT_ACQ_AGAP,Placement.INB_PRESFACT_ACQ_AGAP)                as INB_PRESFACT_ACQ_AGAP                  ,
  Coalesce(RefPer.SEG_PARC_DT_DEBUT,Placement.PARC_DT_DEBUT)                            as SEG_PARC_DT_DEBUT                      ,
  --Infos sur le canal de vente
  'APS'                                                                                 as ORG_CANAL_ID                           ,
  Coalesce(OrigineVente.ORIG_DEM,Placement.CANALDEM)                                    as ORIG_DEM                               ,
  Null                                                                                  as CANALDEM_MTHD                          ,
  CanalVenteMacroPrem.ORG_CANAL_ID_MACRO                                                as ORG_CANAL_ID_MACRO                     ,
  CanalVenteMacroPrem.ORG_CANAL_MACRO_LB                                                as ORG_CANAL_MACRO_LB                     ,
  --Alimentation Orga
  RefO3.ORG_CHANEL_CD                                                                   as ORG_CHANNEL_CD                         ,
  RefO3.ORG_SUB_CHANEL_CD                                                               as ORG_SUB_CHANNEL_CD                     ,
  RefO3.ORG_SUB_SUB_CHANEL_CD                                           				as ORG_SUB_SUB_CHANNEL_CD                 ,
  RefO3.ORG_REM_CHANEL_CD                                           				    as ORG_REM_CHANNEL_CD                     ,
  RefO3.ORG_GT_ACTIVITY                                           						as ORG_GT_ACTIVITY                        ,
  RefO3.ORG_FIDELISATION                                          				    	as ORG_FIDELISATION                       ,
  RefO3.ORG_WEB_ACTIVITY                                           					    as ORG_WEB_ACTIVITY                       ,
  RefO3.ORG_AUTO_ACTIVITY                                           					as ORG_AUTO_ACTIVITY                      ,
  RefO3.EDO_ID                                           					            as ORG_EDO_ID                             ,
  RefO3.TYPE_EDO                                                                        as ORG_TYPE_EDO                           ,
  Placement.FLAG_PLT_CONV                                                               as ORG_FLAG_PLT_CONV                      ,
  Placement.FLAG_TEAM_MKT                                                               as ORG_FLAG_TEAM_MKT                      ,
  Placement.FLAG_TYPE_CMP                                                               as ORG_FLAG_TYPE_CMP                      ,
  Placement.EDO_ID_HIER                                                                 as ORG_EDO_ID_HIER                        ,
  Placement.TYPE_EDO_HIER                                                               as ORG_TYPE_EDO_HIER                      ,
  Placement.ORG_REF_TRAV                                                                as ORG_REF_TRAV                           ,
  Placement.ORG_AGENT_ID                                                                as ORG_AGENT_ID                           ,
  Placement.ORG_POC_XI                                                                  as ORG_POC_XI                             ,
  Placement.ORG_NOM                                                                     as ORG_NOM                                ,
  Placement.ORG_PRENOM                                                                  as ORG_PRENOM                             ,
  Placement.ORG_GROUPE_ID                                                               as ORG_GROUPE_ID                          ,
  Placement.ORG_GROUPE_ID_HIER                                                          as ORG_GROUPE_ID_HIER                     ,
  Placement.ORG_ACTVT_REEL                                                              as ORG_ACTVT_REEL                         ,
  Placement.ORG_RESP_REF_TRAV                                                           as ORG_RESP_REF_TRAV                      ,
  Placement.ORG_RESP_AGENT_ID                                                           as ORG_RESP_AGENT_ID                      ,
  Placement.ORG_RESP_XI                                                                 as ORG_RESP_XI                            ,
  Null                                                                                  as ORG_RESP_EDO_ID                        ,
  Null                                                                                  as ORG_RESP_TYPE_EDO                      ,
  Null                                                                                  as ORG_RESP_FLAG_PLT_CONV                 ,
  Trim(RefO3.ORG_TEAM_LEVEL_1_CD)                                                      as ORG_TEAM_LEVEL_1_CD                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_1_DS)                                                      as ORG_TEAM_LEVEL_1_DS                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_2_CD)                                                      as ORG_TEAM_LEVEL_2_CD                    , 
  Trim(RefO3.ORG_TEAM_LEVEL_2_DS)                                                      as ORG_TEAM_LEVEL_2_DS                    , 
  Trim(RefO3.ORG_TEAM_LEVEL_3_CD)                                                      as ORG_TEAM_LEVEL_3_CD                    , 
  Trim(RefO3.ORG_TEAM_LEVEL_3_DS)                                                      as ORG_TEAM_LEVEL_3_DS                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_4_CD)                                                      as ORG_TEAM_LEVEL_4_CD                    ,
  Trim(RefO3.ORG_TEAM_LEVEL_4_DS)                                                      as ORG_TEAM_LEVEL_4_DS                    ,
  Trim(RefO3.WORK_TEAM_LEVEL_1_CD)                                                     as WORK_TEAM_LEVEL_1_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_1_DS)                                                     as WORK_TEAM_LEVEL_1_DS                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_2_CD)                                                     as WORK_TEAM_LEVEL_2_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_2_DS)                                                     as WORK_TEAM_LEVEL_2_DS                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_3_CD)                                                     as WORK_TEAM_LEVEL_3_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_3_DS)                                                     as WORK_TEAM_LEVEL_3_DS                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_4_CD)                                                     as WORK_TEAM_LEVEL_4_CD                   ,
  Trim(RefO3.WORK_TEAM_LEVEL_4_DS)                                                     as WORK_TEAM_LEVEL_4_DS                   ,
  --Information client
  Placement.DOSSIER_NU                                                                  as DOSSIER_NU                             ,
  Placement.CLIENT_NU                                                                   as CLIENT_NU                              ,
  Placement.DMC_LINE_ID                                                                 as DMC_LINE_ID                            ,
  Placement.DMC_MASTER_LINE_ID                                                          as DMC_MASTER_LINE_ID                     ,
  Placement.PAR_DEPRTMNT_ID                                                             as PAR_DEPRTMNT_ID                        ,
  Placement.PAR_POSTAL_CD                                                               as PAR_POSTAL_CD                          ,
  Placement.PAR_INSEE_NB                                                                as PAR_INSEE_NB                           ,
  Placement.PAR_BU_CD                                                                   as PAR_BU_CD                              ,
  Placement.PAR_GEO_MACROZONE	                                                          as PAR_GEO_MACROZONE ,
	Placement.PAR_UNIFIED_PARTY_ID                                                        as  PAR_UNIFIED_PARTY_ID ,
	Placement.PAR_PARTY_REGRPMNT_ID                                                       as PAR_PARTY_REGRPMNT_ID,
  Placement.PAR_IRIS2000_CD                                                             as PAR_IRIS2000_CD                        ,
  Placement.DMC_LINE_TYPE                                                               as DMC_LINE_TYPE                          ,
  Placement.DMC_ACTIVATION_DT                                                           as DMC_ACTIVATION_DT                      ,
  Placement.DMC_CONVERGENT_IN                                                           as DMC_CONVERGENT_IN                      ,
  Placement.DMC_LINE_ID_INT                                                             as DMC_LINE_ID_INT                        ,
  Placement.DMC_LINE_TYPE_INT                                                           as DMC_LINE_TYPE_INT                      ,
  Placement.DMC_ACTIVATION_DT_INT                                                       as DMC_ACTIVATION_DT_INT                  ,
  Placement.DMC_SERVICE_ACCESS_ID                                                       as DMC_SERVICE_ACCESS_ID                  ,
  Placement.OFFRE_INT_PRE                                                               as OFFRE_INT_PRE                          ,
  Null                                                                                  as OTO_OSCAR_VALUE_NU                     ,
  Placement.PAR_LASTNAME                                                                as PAR_LASTNAME                           ,
  Placement.PAR_FIRSTNAME                                                               as PAR_FIRSTNAME                          ,
  Placement.PAR_TYPE                                                                    as PAR_TYPE                               ,
  Placement.PAR_IMSI                                                                    as PAR_IMSI                               ,
  Placement.PAR_EMAIL                                                                   as PAR_EMAIL                              ,
  Placement.PAR_BILL_ADRESS_1                                                           as PAR_BILL_ADRESS_1                      ,
  Placement.PAR_BILL_ADRESS_2                                                           as PAR_BILL_ADRESS_2                      ,
  Placement.PAR_BILL_ADRESS_3                                                           as PAR_BILL_ADRESS_3                      ,
  Placement.PAR_BILL_ADRESS_4                                                           as PAR_BILL_ADRESS_4                      ,
  Placement.PAR_BILL_VILLE                                                              as PAR_BILL_VILLE                         ,
  Placement.PAR_BILL_CD_POSTAL                                                          as PAR_BILL_CD_POSTAL                     ,
  Placement.PAR_INSEE_CD                                                                as PAR_INSEE_CD                           ,
  Placement.PAR_DO                                                                      as PAR_DO                                 ,
  Placement.PAR_USCM                                                                    as PAR_USCM                               ,
  Placement.PAR_USCM_DS                                                                 as PAR_USCM_DS                            ,
  Placement.PAR_USCM_USCM_DS                                                            as PAR_USCM_USCM_DS                       ,
  Placement.PAR_USCM_REGUSCM                                                            as PAR_USCM_REGUSCM                       ,
  Placement.PAR_USCM_REGUSCM_DS                                                         as PAR_USCM_REGUSCM_DS                    ,
  Placement.PAR_AID                                                                     as PAR_AID                                ,
  Placement.PAR_ND                                                                      as PAR_ND                                 ,
  Placement.PAR_MOB_IMEI                                                                as PAR_MOB_IMEI                           ,
  Placement.PAR_MOB_TAC                                                                 as PAR_MOB_TAC                            ,
  Placement.PAR_MOB_SIM                                                                 as PAR_MOB_SIM                            ,
  --Segementation client :
  Placement.PAR_SCORE_NU                                                                as PAR_SCORE_NU                           ,
  Placement.PAR_SCORE_IN                                                                as PAR_SCORE_IN                           ,
  Placement.PAR_TRESHOLD_NU                                                             as PAR_TRESHOLD_NU                        ,
  Placement.PAR_SCORE_NU_INT                                                            as PAR_SCORE_NU_INT                       ,
  Placement.PAR_SCORE_IN_INT                                                            as PAR_SCORE_IN_INT                       ,
  Placement.PAR_TRESHOLD_NU_INT                                                         as PAR_TRESHOLD_NU_INT                    ,
  --Contrat Avec le client :
  Placement.CONTRCT_DT_SIGN_PREC                                                        as CONTRCT_DT_SIGN_PREC                   ,
  Placement.CONTRCT_DT_FIN_PREC                                                         as CONTRCT_DT_FIN_PREC                    ,
  Placement.CONTRCT_DT_SIGN_POST                                                        as CONTRCT_DT_SIGN_POST                   ,
  Placement.CONTRCT_DUREE_ENG                                                           as CONTRCT_DUREE_ENG                      ,
  Placement.CONTRCT_UNIT_ENG                                                            as CONTRCT_UNIT_ENG                       ,
  --Attributs de pÃ©rÃ©nitÃ©   :
  RefPer.CONFIRMATION_IN                                                                as CONFIRMATION_IN                        ,
  RefPer.CONFIRMATION_DT                                                                as CONFIRMATION_DT                        ,
  RefPer.CONFIRMATION_CALC_FIN_DT                                                       as CONFIRMATION_CALC_FIN_DT               ,
  RefPer.DELIVERY_IN                                                                    as DELIVERY_IN                            ,
  RefPer.DELIVERY_DT                                                                    as DELIVERY_DT                            ,
  RefPer.DELIVERY_CALC_FIN_DT                                                           as DELIVERY_CALC_FIN_DT                   ,
  RefPer.PERENNITE_IN                                                                   as PERENNITE_IN                           ,
  RefPer.PERENNITE_FIN_DT                                                               as PERENNITE_FIN_DT                       ,
  RefPer.PERENNITE_CALC_FIN_DT                                                          as PERENNITE_CALC_FIN_DT                  ,
  PerPVC.PERENNITE_PVC_IN                                                               as PERENNITE_PVC_IN                       ,
  PerPVC.PERENNITE_PVC_FIN_DT                                                           as PERENNITE_PVC_FIN_DT                   ,
  PerPVC.PERENNITE_PVC_CALC_FIN_DT                                                      as PERENNITE_PVC_CALC_FIN_DT              ,
  Case  --Si le segment est dÃ©jÃ  en parc alors on positionne le flag Ã  Oui
        When PerDejPres.ACTE_ID Is Not Null 
          Then  1
        Else    0
  End                                                                                   as SEG_PRES_PARC_COMMANDE                 ,
  PerPVC.SEG_NEXT_PARC_LIVR_DT                                                          as MIGRA_DT                               ,
  PerPVC.SEG_COM_ID_NEXT_PARC                                                           as MIGRA_NEXT_OFFRE                       ,
  Placement.DOSSIER_DATE_RESIL                                                          as RESIL_INT_DT                           ,
  Placement.DOSSIER_TYPE_RESIL                                                          as RESIL_INT_MOTIF                        ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as RESIL_INT_MOTIF_DS                     ,
  PerPVC.SEG_COM_ID_LAST_PER                                                            as SEG_COM_ID_LAST_PER                    ,
  PerPVC.SEG_COM_ID_SOLD                                                                as SEG_COM_ID_SOLD                        ,
  PerPVC.SEG_COM_ID_FIND                                                                as SEG_COM_ID_FIND                        ,
  PerPVC.SEG_FIND_LIVR_DT                                                               as SEG_FIND_LIVR_DT                       ,
  PerPVC.SEG_FIND_CANCEL_DT                                                             as SEG_FIND_CANCEL_DT                     ,
  PerPVC.SEG_COM_ID_NEXT_PARC                                                           as SEG_COM_ID_NEXT_PARC                   ,
  PerPVC.SEG_NEXT_PARC_LIVR_DT                                                          as SEG_NEXT_PARC_LIVR_DT                  ,
  PerPVC.SEG_NEXT_PARC_CANCEL_DT                                                        as SEG_NEXT_PARC_CANCEL_DT                ,
  PerPVC.SEG_COM_ID_FINAL_PARC                                                          as SEG_COM_ID_FINAL_PARC                  ,
  PerPVC.SEG_FINAL_PARC_LIVR_DT                                                         as SEG_FINAL_PARC_LIVR_DT                 ,
  PerPVC.SEG_FINAL_PARC_CANCEL_DT                                                       as SEG_FINAL_PARC_CANCEL_DT               ,
  PerPVC.SEG_COM_ID_LAST_IN_PARC                                                        as SEG_COM_ID_LAST_IN_PARC                ,
  PerPVC.NB_IN_OUT_PARC                                                                 as NB_IN_OUT_PARC                         ,
  PerPVC.POURCENTAGE_PRES_PARC                                                          as POURCENTAGE_PRES_PARC                  ,      
  --Calcul si la livraison Ã  eu lieu dans les temps :
  Case  When RefPer.DELIVERY_DT is Null
          Then 'NA'
        When Delais.DELAIS is Null 
          --Dans le cas oÃ¹ le delais est null alors on a pas pu Ã©valuer : NC
          Then 'NC'
        When ( Placement.INT_DEPOSIT_DT + Cast(Delais.DELAIS as interval day(4))) >= RefPer.DELIVERY_DT
          -- Dans le cas oÃ¹ on est dans le dÃ©lais :
          Then  'O'
          --Sinon on n'est pas dans les clous
        Else    'N'
  End                                                                                   as DELIVERY_ONTIME_IN                     ,
  'NA'                                                                                  as CONCURENCE_IN                          ,
  'NA'                                                                                  as CONCURENCE_CONCLU_IN                   ,
  Null                                                                                  as CONCURENCE_ID                          ,
  Null                                                                                  as CLOSURE_DT                             ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                            ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS                          ,
  1                                                                                     as FRESH_IN                               ,
  0                                                                                     as COHERENCE_IN                           
From
  ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_OEE Placement
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_CALC RefId
    On    Placement.ACTE_ID                             = RefId.ACTE_ID
      And Placement.INT_DEPOSIT_DT                      = RefId.INT_DEPOSIT_DT
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_PER RefPer
    On    RefPer.ACTE_ID                                = RefId.ACTE_ID
      And RefPer.INT_DEPOSIT_DT                         = RefId.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On    RefId.TYPE_COMMANDE_ID                        = Delais.TYPE_COMMANDE_ID
      And RefId.TYPE_SERVICE_FINAL                      = Delais.TYPE_SERVICE
      And RefId.PERIODE_ID                              = Delais.PERIODE_ID
      And Delais.FRESH_IN                               = 1
      And Delais.CURRENT_IN                             = 1
      And Delais.CLOSURE_DT                     is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_ORIG_DEM OrigineVente
    On    Placement.ORG_REF_TRAV                        =  OrigineVente.ORG_REF_TRAV
      And Placement.ORG_GROUPE_ID                       =  OrigineVente.ORG_GROUPE_ID
      And Placement.PLTF_CO                             =  OrigineVente.APPLI_SOURCE_ID
      And Placement.INT_DEPOSIT_DT                      >= OrigineVente.GRP_DT_DEB
      And Placement.INT_DEPOSIT_DT                      <= OrigineVente.GRP_DT_FIN
      And OrigineVente.FRESH_IN                         =  1
      And OrigineVente.CURRENT_IN                       =  1
      And OrigineVente.CLOSURE_DT                       is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_CANAL_VENTE CanalVenteMacroPrem
    On    OrigineVente.ORIG_DEM                         = CanalVenteMacroPrem.ORIG_DEM
      And CanalVenteMacroPrem.FRESH_IN                  = 1
      And CanalVenteMacroPrem.CURRENT_IN                = 1
      And CanalVenteMacroPrem.CLOSURE_DT                is Null
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_O3 RefO3
    On    Placement.ACTE_ID        = RefO3.ACTE_ID
      And Placement.INT_DEPOSIT_DT = RefO3.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_PER_FULL PerPVC
    On    Placement.ACTE_ID        = PerPVC.ACTE_ID
      And Placement.INT_DEPOSIT_DT = PerPVC.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_OEE_SEG_DEJPRES PerDejPres
    On    Placement.ACTE_ID        = PerDejPres.ACTE_ID
      And Placement.INT_DEPOSIT_DT = PerDejPres.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    RefId.PERIODE_ID                                    = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                                = 1
      And EtatPeriode.FRESH_IN                                  = 1
      And EtatPeriode.CLOSURE_DT                                Is Null
        
Where
      (
        --On veut suivre les produits :
            --Qui ne sont pas sur une pÃ©riode valable :
                RefId.PERIODE_ID = ${P_PIL_049}
            --ou qui ne sont pas sur un segment suivi
            or RefId.SEG_COM_ID_FINAL in ('${P_PIL_022}','${P_PIL_295}')
      )
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_T_ACTE_OEE;
.if errorcode <> 0 then .quit 1



--On insert les lignes en closure DT dans le cas ou le placement Ã  changer de Resolution / Conclusion
-- Il n'est plus forcement Ã©ligible au passage Ã  l'acte et donc il faut le supprimer


Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_OEE
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                               ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_FLAG_PEC_PERPVC                       ,
  ACT_ACTE_VALO                             ,
  ACT_ACTE_FAMILLE_KPI                      ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID                              ,
  ORIG_DEM                                  ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO                        ,
  ORG_CANAL_MACRO_LB                        ,
  ORG_CHANNEL_CD                            , 
  ORG_SUB_CHANNEL_CD                        , 
  ORG_SUB_SUB_CHANNEL_CD                    , 
  ORG_REM_CHANNEL_CD                        , 
  ORG_GT_ACTIVITY                           , 
  ORG_FIDELISATION                          , 
  ORG_WEB_ACTIVITY                          , 
  ORG_AUTO_ACTIVITY                         , 
  ORG_EDO_ID                                , 
  ORG_TYPE_EDO                              , 
  ORG_FLAG_PLT_CONV                         , 
  ORG_FLAG_TEAM_MKT                         , 
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         , 
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,
  DOSSIER_NU                                ,
  CLIENT_NU                                 ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  DMC_LINE_TYPE                             ,
  DMC_ACTIVATION_DT                         ,
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU                              ,
  PAR_SCORE_IN                              ,
  PAR_TRESHOLD_NU                           ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,  
  PERENNITE_PVC_FIN_DT                      ,  
  PERENNITE_PVC_CALC_FIN_DT                 ,  
  SEG_PRES_PARC_COMMANDE                    ,  
  MIGRA_DT                                  ,  
  MIGRA_NEXT_OFFRE                          ,  
  RESIL_INT_DT                              ,  
  RESIL_INT_MOTIF                           ,  
  RESIL_INT_MOTIF_DS                        ,  
  SEG_COM_ID_LAST_PER                       ,  
  SEG_COM_ID_SOLD                           ,  
  SEG_COM_ID_FIND                           ,  
  SEG_FIND_LIVR_DT                          ,  
  SEG_FIND_CANCEL_DT                        ,  
  SEG_COM_ID_NEXT_PARC                      ,  
  SEG_NEXT_PARC_LIVR_DT                     ,  
  SEG_NEXT_PARC_CANCEL_DT                   ,  
  SEG_COM_ID_FINAL_PARC                     ,  
  SEG_FINAL_PARC_LIVR_DT                    ,  
  SEG_FINAL_PARC_CANCEL_DT                  ,  
  SEG_COM_ID_LAST_IN_PARC                   ,  
  NB_IN_OUT_PARC                            ,  
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              
)
Select
  Soc.ACTE_ID                               as ACTE_ID                              ,
  Soc.ACTE_ID_GEN                           as ACTE_ID_GEN                           ,
  Soc.DEMANDE_ID                            as DEMANDE_ID                           ,
  Soc.EXTERNAL_INT_ID                       as EXTERNAL_INT_ID                      ,
  Soc.INT_DEPOSIT_TS                        as INT_DEPOSIT_TS                       ,
  Soc.INT_DEPOSIT_DT                        as INT_DEPOSIT_DT                       ,
  Soc.OPERATOR_PROVIDER_ID                  as OPERATOR_PROVIDER_ID                 ,
  Soc.RESOLU_ID                             as RESOLU_ID                            ,
  Soc.CONCLU_ID                             as CONCLU_ID                            ,
  Soc.SSCONCLU_ID                           as SSCONCLU_ID                          ,
  Soc.INT_MODIF_TS                          as INT_MODIF_TS                         ,
  Soc.PLTF_CO                               as PLTF_CO                              ,
  Soc.INTRNL_SOURCE_ID                      as INTRNL_SOURCE_ID                     ,
  Soc.SOLDOFF_SRC_CD                        as SOLDOFF_SRC_CD                       ,
  Soc.OTO_OFFER_CD                          as OTO_OFFER_CD                         ,
  Soc.OTO_OFFER_TYPE_CD                     as OTO_OFFER_TYPE_CD                    ,
  Soc.ACT_PRODUCT_ID_PRE                    as ACT_PRODUCT_ID_PRE                   ,
  Soc.ACT_SEG_COM_ID_PRE                    as ACT_SEG_COM_ID_PRE                   ,
  Soc.ACT_SEG_COM_AGG_ID_PRE                as ACT_SEG_COM_AGG_ID_PRE               ,
  Soc.ACT_CODE_MIGR_PRE                     as ACT_CODE_MIGR_PRE                    ,
  Soc.ACT_PRODUCT_ID_FINAL                  as ACT_PRODUCT_ID_FINAL                 ,
  Soc.TYPE_OT_SO                            as TYPE_OT_SO                           ,
  Soc.IN_CLIDOS                             as IN_CLIDOS                            ,
  Soc.ACT_SEG_COM_ID_FINAL                  as ACT_SEG_COM_ID_FINAL                 ,
  Soc.ACT_SEG_COM_AGG_ID_FINAL              as ACT_SEG_COM_AGG_ID_FINAL             ,
  Soc.ACT_CODE_MIGR_FINAL                   as ACT_CODE_MIGR_FINAL                  ,
  Soc.ACT_TYPE_SERVICE_FINAL                as ACT_TYPE_SERVICE_FINAL               ,
  Soc.ACT_TYPE_COMMANDE_ID                  as ACT_TYPE_COMMANDE_ID                 ,
  Soc.ACT_DELTA_TARIF                       as ACT_DELTA_TARIF                      ,
  Soc.ACT_CD                                as ACT_CD                               ,
  Soc.ACT_REM_ID                            as ACT_REM_ID                           ,
  Soc.ACT_FLAG_ACT_REM                      as ACT_FLAG_ACT_REM                     ,
  Soc.ACT_FLAG_PEC_PERPVC                   as ACT_FLAG_PEC_PERPVC                  ,
  Soc.ACT_ACTE_VALO                         as ACT_ACTE_VALO                        ,
  Soc.ACT_ACTE_FAMILLE_KPI                  as ACT_ACTE_FAMILLE_KPI                 ,
  Soc.ACT_PERIODE_ID                        as ACT_PERIODE_ID                       ,
  Soc.ACT_PERIODE_STATUS                    as ACT_PERIODE_STATUS                   ,
  Soc.ACT_PERIODE_CLOSURE_DT                as ACT_PERIODE_CLOSURE_DT               ,
  Soc.INB_PRESFACT_ACQ_ADV                  as INB_PRESFACT_ACQ_ADV                 ,
  Soc.INB_PRESFACT_ACQ_AGAP                 as INB_PRESFACT_ACQ_AGAP                ,
  Soc.SEG_PARC_DT_DEBUT                     as SEG_PARC_DT_DEBUT                    ,
  Soc.ORG_CANAL_ID                          as ORG_CANAL_ID                         ,
  Soc.ORIG_DEM                              as ORIG_DEM                             ,
  Soc.CANALDEM_MTHD                         as CANALDEM_MTHD                        ,
  Soc.ORG_CANAL_ID_MACRO                    as ORG_CANAL_ID_MACRO                   ,
  Soc.ORG_CANAL_MACRO_LB                    as ORG_CANAL_MACRO_LB                   ,
  Soc.ORG_CHANNEL_CD                        as ORG_CHANNEL_CD                       ,
  Soc.ORG_SUB_CHANNEL_CD                    as ORG_SUB_CHANNEL_CD                   ,
  Soc.ORG_SUB_SUB_CHANNEL_CD                as ORG_SUB_SUB_CHANNEL_CD               ,
  Soc.ORG_REM_CHANNEL_CD                    as ORG_REM_CHANNEL_CD                   ,
  Soc.ORG_GT_ACTIVITY                       as ORG_GT_ACTIVITY                      ,
  Soc.ORG_FIDELISATION                      as ORG_FIDELISATION                     ,
  Soc.ORG_WEB_ACTIVITY                      as ORG_WEB_ACTIVITY                     ,
  Soc.ORG_AUTO_ACTIVITY                     as ORG_AUTO_ACTIVITY                    ,
  Soc.ORG_EDO_ID                            as ORG_EDO_ID                           ,
  Soc.ORG_TYPE_EDO                          as ORG_TYPE_EDO                         ,
  Soc.ORG_FLAG_PLT_CONV                     as ORG_FLAG_PLT_CONV                    ,
  Soc.ORG_FLAG_TEAM_MKT                     as ORG_FLAG_TEAM_MKT                    ,
  Soc.ORG_FLAG_TYPE_CMP                     as ORG_FLAG_TYPE_CMP                    ,
  Soc.ORG_EDO_ID_HIER                       as ORG_EDO_ID_HIER                      ,
  Soc.ORG_TYPE_EDO_HIER                     as ORG_TYPE_EDO_HIER                    ,
  Soc.ORG_REF_TRAV                          as ORG_REF_TRAV                         ,
  Soc.ORG_AGENT_ID                          as ORG_AGENT_ID                         ,
  Soc.ORG_POC_XI                            as ORG_POC_XI                           ,
  Soc.ORG_NOM                               as ORG_NOM                              ,
  Soc.ORG_PRENOM                            as ORG_PRENOM                           ,
  Soc.ORG_GROUPE_ID                         as ORG_GROUPE_ID                        ,
  Soc.ORG_GROUPE_ID_HIER                    as ORG_GROUPE_ID_HIER                   ,
  Soc.ORG_ACTVT_REEL                        as ORG_ACTVT_REEL                       ,
  Soc.ORG_RESP_REF_TRAV                     as ORG_RESP_REF_TRAV                    ,
  Soc.ORG_RESP_AGENT_ID                     as ORG_RESP_AGENT_ID                    ,
  Soc.ORG_RESP_XI                           as ORG_RESP_XI                          ,
  Soc.ORG_RESP_EDO_ID                       as ORG_RESP_EDO_ID                      ,
  Soc.ORG_RESP_TYPE_EDO                     as ORG_RESP_TYPE_EDO                    ,
  Soc.ORG_RESP_FLAG_PLT_CONV                as ORG_RESP_FLAG_PLT_CONV               ,
  Soc.ORG_TEAM_LEVEL_1_CD                   as ORG_TEAM_LEVEL_1_CD                  ,
  Soc.ORG_TEAM_LEVEL_1_DS                   as ORG_TEAM_LEVEL_1_DS                  ,
  Soc.ORG_TEAM_LEVEL_2_CD                   as ORG_TEAM_LEVEL_2_CD                  ,
  Soc.ORG_TEAM_LEVEL_2_DS                   as ORG_TEAM_LEVEL_2_DS                  ,
  Soc.ORG_TEAM_LEVEL_3_CD                   as ORG_TEAM_LEVEL_3_CD                  ,
  Soc.ORG_TEAM_LEVEL_3_DS                   as ORG_TEAM_LEVEL_3_DS                  ,
  Soc.ORG_TEAM_LEVEL_4_CD                   as ORG_TEAM_LEVEL_4_CD                  ,
  Soc.ORG_TEAM_LEVEL_4_DS                   as ORG_TEAM_LEVEL_4_DS                  ,
  Soc.WORK_TEAM_LEVEL_1_CD                  as WORK_TEAM_LEVEL_1_CD                 ,
  Soc.WORK_TEAM_LEVEL_1_DS                  as WORK_TEAM_LEVEL_1_DS                 ,
  Soc.WORK_TEAM_LEVEL_2_CD                  as WORK_TEAM_LEVEL_2_CD                 ,
  Soc.WORK_TEAM_LEVEL_2_DS                  as WORK_TEAM_LEVEL_2_DS                 ,
  Soc.WORK_TEAM_LEVEL_3_CD                  as WORK_TEAM_LEVEL_3_CD                 ,
  Soc.WORK_TEAM_LEVEL_3_DS                  as WORK_TEAM_LEVEL_3_DS                 ,
  Soc.WORK_TEAM_LEVEL_4_CD                  as WORK_TEAM_LEVEL_4_CD                 ,
  Soc.WORK_TEAM_LEVEL_4_DS                  as WORK_TEAM_LEVEL_4_DS                 ,
  Soc.DOSSIER_NU                            as DOSSIER_NU                           ,
  Soc.CLIENT_NU                             as CLIENT_NU                            ,
  Soc.DMC_LINE_ID                           as DMC_LINE_ID                          ,
  Soc.DMC_MASTER_LINE_ID                    as DMC_MASTER_LINE_ID                   ,
  Soc.DMC_LINE_TYPE                         as DMC_LINE_TYPE                        ,
  Soc.DMC_ACTIVATION_DT                     as DMC_ACTIVATION_DT                    ,
  Soc.DMC_CONVERGENT_IN                     as DMC_CONVERGENT_IN                    ,
  Soc.DMC_LINE_ID_INT                       as DMC_LINE_ID_INT                      ,
  Soc.DMC_LINE_TYPE_INT                     as DMC_LINE_TYPE_INT                    ,
  Soc.DMC_ACTIVATION_DT_INT                 as DMC_ACTIVATION_DT_INT                ,
  Soc.DMC_SERVICE_ACCESS_ID                 as DMC_SERVICE_ACCESS_ID                ,
  Soc.OFFRE_INT_PRE                         as OFFRE_INT_PRE                        ,
  Soc.OTO_OSCAR_VALUE_NU                    as OTO_OSCAR_VALUE_NU                   ,
  Soc.PAR_LASTNAME                          as PAR_LASTNAME                         ,
  Soc.PAR_FIRSTNAME                         as PAR_FIRSTNAME                        ,
  Soc.PAR_TYPE                              as PAR_TYPE                             ,
  Soc.PAR_IMSI                              as PAR_IMSI                             ,
  Soc.PAR_EMAIL                             as PAR_EMAIL                            ,
  Soc.PAR_BILL_ADRESS_1                     as PAR_BILL_ADRESS_1                    ,
  Soc.PAR_BILL_ADRESS_2                     as PAR_BILL_ADRESS_2                    ,
  Soc.PAR_BILL_ADRESS_3                     as PAR_BILL_ADRESS_3                    ,
  Soc.PAR_BILL_ADRESS_4                     as PAR_BILL_ADRESS_4                    ,
  Soc.PAR_BILL_VILLE                        as PAR_BILL_VILLE                       ,
  Soc.PAR_BILL_CD_POSTAL                    as PAR_BILL_CD_POSTAL                   ,
  Soc.PAR_INSEE_CD                          as PAR_INSEE_CD                         ,
  Soc.PAR_DO                                as PAR_DO                               ,
  Soc.PAR_USCM                              as PAR_USCM                             ,
  Soc.PAR_USCM_DS                           as PAR_USCM_DS                          ,
  Soc.PAR_USCM_USCM_DS                      as PAR_USCM_USCM_DS                     ,
  Soc.PAR_USCM_REGUSCM                      as PAR_USCM_REGUSCM                     ,
  Soc.PAR_USCM_REGUSCM_DS                   as PAR_USCM_REGUSCM_DS                  ,
  Soc.PAR_AID                               as PAR_AID                              ,
  Soc.PAR_ND                                as PAR_ND                               ,
  Soc.PAR_MOB_IMEI                          as PAR_MOB_IMEI                         ,
  Soc.PAR_MOB_TAC                           as PAR_MOB_TAC                          ,
  Soc.PAR_MOB_SIM                           as PAR_MOB_SIM                          ,
  Soc.PAR_SCORE_NU                          as PAR_SCORE_NU                         ,
  Soc.PAR_SCORE_IN                          as PAR_SCORE_IN                         ,
  Soc.PAR_TRESHOLD_NU                       as PAR_TRESHOLD_NU                      ,
  Soc.PAR_SCORE_NU_INT                      as PAR_SCORE_NU_INT                     ,
  Soc.PAR_SCORE_IN_INT                      as PAR_SCORE_IN_INT                     ,
  Soc.PAR_TRESHOLD_NU_INT                   as PAR_TRESHOLD_NU_INT                  ,
  Soc.CONTRCT_DT_SIGN_PREC                  as CONTRCT_DT_SIGN_PREC                 ,
  Soc.CONTRCT_DT_FIN_PREC                   as CONTRCT_DT_FIN_PREC                  ,
  Soc.CONTRCT_DT_SIGN_POST                  as CONTRCT_DT_SIGN_POST                 ,
  Soc.CONTRCT_DUREE_ENG                     as CONTRCT_DUREE_ENG                    ,
  Soc.CONTRCT_UNIT_ENG                      as CONTRCT_UNIT_ENG                     ,
  Soc.CONFIRMATION_IN                       as CONFIRMATION_IN                      ,
  Soc.CONFIRMATION_DT                       as CONFIRMATION_DT                      ,
  Soc.CONFIRMATION_CALC_FIN_DT              as CONFIRMATION_CALC_FIN_DT             ,
  Soc.DELIVERY_IN                           as DELIVERY_IN                          ,
  Soc.DELIVERY_DT                           as DELIVERY_DT                          ,
  Soc.DELIVERY_CALC_FIN_DT                  as DELIVERY_CALC_FIN_DT                 ,
  Soc.PERENNITE_IN                          as PERENNITE_IN                         ,
  Soc.PERENNITE_FIN_DT                      as PERENNITE_FIN_DT                     ,
  Soc.PERENNITE_CALC_FIN_DT                 as PERENNITE_CALC_FIN_DT                ,
  Soc.PERENNITE_PVC_IN                      as PERENNITE_PVC_IN                     ,
  Soc.PERENNITE_PVC_FIN_DT                  as PERENNITE_PVC_FIN_DT                 ,
  Soc.PERENNITE_PVC_CALC_FIN_DT             as PERENNITE_PVC_CALC_FIN_DT            ,
  Soc.SEG_PRES_PARC_COMMANDE                as SEG_PRES_PARC_COMMANDE               ,
  Soc.MIGRA_DT                              as MIGRA_DT                             ,
  Soc.MIGRA_NEXT_OFFRE                      as MIGRA_NEXT_OFFRE                     ,
  Soc.RESIL_INT_DT                          as RESIL_INT_DT                         ,
  Soc.RESIL_INT_MOTIF                       as RESIL_INT_MOTIF                      ,
  Soc.RESIL_INT_MOTIF_DS                    as RESIL_INT_MOTIF_DS                   ,
  Soc.SEG_COM_ID_LAST_PER                   as SEG_COM_ID_LAST_PER                  ,
  Soc.SEG_COM_ID_SOLD                       as SEG_COM_ID_SOLD                      ,
  Soc.SEG_COM_ID_FIND                       as SEG_COM_ID_FIND                      ,
  Soc.SEG_FIND_LIVR_DT                      as SEG_FIND_LIVR_DT                     ,
  Soc.SEG_FIND_CANCEL_DT                    as SEG_FIND_CANCEL_DT                   ,
  Soc.SEG_COM_ID_NEXT_PARC                  as SEG_COM_ID_NEXT_PARC                 ,
  Soc.SEG_NEXT_PARC_LIVR_DT                 as SEG_NEXT_PARC_LIVR_DT                ,
  Soc.SEG_NEXT_PARC_CANCEL_DT               as SEG_NEXT_PARC_CANCEL_DT              ,
  Soc.SEG_COM_ID_FINAL_PARC                 as SEG_COM_ID_FINAL_PARC                ,
  Soc.SEG_FINAL_PARC_LIVR_DT                as SEG_FINAL_PARC_LIVR_DT               ,
  Soc.SEG_FINAL_PARC_CANCEL_DT              as SEG_FINAL_PARC_CANCEL_DT             ,
  Soc.SEG_COM_ID_LAST_IN_PARC               as SEG_COM_ID_LAST_IN_PARC              ,
  Soc.NB_IN_OUT_PARC                        as NB_IN_OUT_PARC                       ,
  Soc.POURCENTAGE_PRES_PARC                 as POURCENTAGE_PRES_PARC                ,
  Soc.DELIVERY_ONTIME_IN                    as DELIVERY_ONTIME_IN                   ,
  Soc.CONCURENCE_IN                         as CONCURENCE_IN                        ,
  Soc.CONCURENCE_CONCLU_IN                  as CONCURENCE_CONCLU_IN                 ,
  Soc.CONCURENCE_ID                         as CONCURENCE_ID                        ,
  Current_Date                              as CLOSURE_DT                           ,
  Soc.CREATION_TS                           as CREATION_TS                          ,
  Soc.LAST_MODIF_TS                         as LAST_MODIF_TS                        ,
  Soc.FRESH_IN                              as FRESH_IN                             ,
  Soc.COHERENCE_IN                          as COHERENCE_IN                         
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_OEE Soc
Where
  (1=1)
  And Soc.INT_DEPOSIT_DT  >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
  And Soc.CLOSURE_DT      Is Null
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.INT_T_ACTE_OEE Tmp
    Where
      (1=1)
      And Soc.ACTE_ID         = Tmp.ACTE_ID
      And Soc.INT_DEPOSIT_DT  = Tmp.INT_DEPOSIT_DT
  )
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_T_ACTE_OEE;
.if errorcode <> 0 then .quit 1


.quit 0

