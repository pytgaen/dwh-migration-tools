--$HEADER:   mm2pco/current/sql/ATP_ADV_Placement_Step6_Fusion_Final.sql 13_05#7 26-JUN-2019 11:38:33 NNGS2043
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ADV_Placement_Step6_Fusion_Final.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'extraction  ADV
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 31/07/2018      HOB         Creation
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP 
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table temporaire avec les différents Enrichissement                              ----
----------------------------------------------------------------------------------------------

   Insert Into ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV
   (
     ACTE_ID                   ,
     EXTERNAL_ORDR_ID          ,
     TYPE_SOURCE_ID            ,
     INTRNL_SOURCE_ID          ,
     ORDER_DEPOSIT_TS          ,
     ORDER_DEPOSIT_DT          ,
     RCS_ENR_ACTE_ID           ,
     ORDR_TYP_CD               ,
     EXTRNL_ORIGN_CD           ,
     EXTRNL_OPSRV_DS           ,
     EXTRNL_OPSRV_CD           ,
     EXTRNL_OPSRV_TYP_CD       ,
     EXTRNL_LINE_NU_CD         ,
     OPSRV_BILL_DT             ,
     OPSRV_TARIF_PREST         ,
     OPSRV_END_DT              ,
     OPSRV_STATUS_CD           ,
     DISCNT_TYPE_CD            ,
     DISCNT_RATE_CD            ,
     DISCNT_AMNT               ,
     OPSRV_REPAID_IN           ,
     OPSRV_AMNT                ,
     MSISDN_ID                 ,
     DMC_CUST_TYPE_CD          ,
     DMC_NDS_VALUE_DS          ,
     DMC_RES_VALUE_DS          ,
     PAR_CLIENT_NU             ,
     DMC_LINE_ID               ,
     DMC_MASTER_LINE_ID        ,
     DMC_LINE_TYPE             ,
     DMC_ACTIVATION_DT         ,
     PAR_INSEE_NB              ,
     PAR_BU_CD                 ,
     DMC_CONVERGENT_IN         ,
     PAR_FIBER_IN              ,
     PAR_GEO_MACROZONE         ,
     PAR_UNIFIED_PARTY_ID      ,
     PAR_PARTY_REGRPMNT_ID     ,
     PAR_IRIS2000_CD           ,
     PAR_PID_ID                ,
     PAR_CID_ID                ,
     PAR_FIRST_IN              ,
     ADDRESS_CONCAT_NM         ,
     ADDRESS_TYPE              ,
     SERVICE_ACCESS_ID         ,
     PAR_DEPRTMNT_ID           ,
     PAR_POSTAL_CD             ,
     DMC_CUST_BU_CD            ,
     RCS_AGENT_ID              ,
     RCS_NOM                   ,
     RCS_PRENOM                ,
     ORG_AGENT_IOBSP           ,
     EDO_ID                    ,
     TYPE_EDO_ID               ,
     ORG_EDO_IOBSP             ,
     DISTRBTN_CHANNL_ID        ,
     FLAG_PLT_CONV_NB          ,
     ORG_CHANNEL_CD            ,
     ORG_SUB_CHANNEL_CD        ,
     ORG_SUB_SUB_CHANNEL_CD    ,
     ORG_GT_ACTIVITY           ,
     ORG_FIDELISATION          ,
     ORG_WEB_ACTIVITY          ,
     ORG_AUTO_ACTIVITY         ,
     ORG_REM_CHANNEL_CD        ,
     ORG_TEAM_LEVEL_1_CD       ,
     ORG_TEAM_LEVEL_1_DS       ,
     ORG_TEAM_LEVEL_2_CD       ,
     ORG_TEAM_LEVEL_2_DS       ,
     ORG_TEAM_LEVEL_3_CD       ,
     ORG_TEAM_LEVEL_3_DS       ,
     ORG_TEAM_LEVEL_4_CD       ,
     ORG_TEAM_LEVEL_4_DS       ,
     WORK_TEAM_LEVEL_1_CD      ,
     WORK_TEAM_LEVEL_1_DS      ,
     WORK_TEAM_LEVEL_2_CD      ,
     WORK_TEAM_LEVEL_2_DS      ,
     WORK_TEAM_LEVEL_3_CD      ,
     WORK_TEAM_LEVEL_3_DS      ,
     WORK_TEAM_LEVEL_4_CD      ,
     WORK_TEAM_LEVEL_4_DS      ,
     CREATION_TS               ,
     LAST_MODIF_TS             ,
     FRESH_IN                  ,
     COHERENCE_IN
   )
   Select
  Placement.ACTE_ID                                                                               As ACTE_ID               ,
  Placement.EXTERNAL_ACTE_ID                                                                      As EXTERNAL_ORDR_ID      ,
  Placement.TYPE_SOURCE_ID                                                                        As TYPE_SOURCE_ID        ,
  Placement.INTRNL_SOURCE_ID                                                                      As INTRNL_SOURCE_ID      ,
  Placement.ORDER_DEPOSIT_TS                                                                      As ORDER_DEPOSIT_TS      ,
  Placement.ORDER_DEPOSIT_DT                                                                      As ORDER_DEPOSIT_DT      ,
  Coalesce(RefINIT.RCS_ENR_ACTE_ID,Placement.RCS_ENR_ACTE_ID)                                     As RCS_ENR_ACTE_ID       ,
  'ACQ'                                                                                           As ORDR_TYP_CD           ,
  Placement.EXTRNL_ORIGN_CD                                                                       As EXTRNL_ORIGN_CD       ,
  Placement.EXTRNL_OPSRV_DS                                                                       As EXTRNL_OPSRV_DS       ,
  Placement.EXTRNL_OPSRV_CD                                                                       As EXTRNL_OPSRV_CD       ,
  Placement.EXTRNL_OPSRV_TYP_CD                                                                   As EXTRNL_OPSRV_TYP_CD   ,
  Placement.EXTRNL_LINE_NU_CD                                                                     As EXTRNL_LINE_NU_CD     ,
  Placement.OPSRV_BILL_DT                                                                         As OPSRV_BILL_DT         ,
  Placement.OPSRV_TARIF_PREST                                                                     As OPSRV_TARIF_PREST     ,
  Placement.OPSRV_END_DT                                                                          As OPSRV_END_DT          ,
  Placement.OPSRV_STATUS_CD                                                                       As OPSRV_STATUS_CD       ,
  Placement.DISCNT_TYPE_CD                                                                        As DISCNT_TYPE_CD        ,
  Placement.DISCNT_RATE_CD                                                                        As DISCNT_RATE_CD        ,
  Placement.DISCNT_AMNT                                                                           As DISCNT_AMNT           ,
  Placement.OPSRV_REPAID_IN                                                                       As OPSRV_REPAID_IN       ,
  Placement.OPSRV_AMNT                                                                            As OPSRV_AMNT            ,
  Placement.MSISDN_ID                                                                             As MSISDN_ID             ,
  Coalesce(RefDMC.DMC_CUST_TYPE_CD,Placement.DMC_CUST_TYPE_CD)                                    As DMC_CUST_TYPE_CD      ,
  Coalesce(RefDMC.DMC_NDS_VALUE_DS,Placement.DMC_NDS_VALUE_DS)                                    As DMC_NDS_VALUE_DS      ,
  Coalesce(RefDMC.DMC_RES_VALUE_DS,Placement.DMC_RES_VALUE_DS)                                    As DMC_RES_VALUE_DS      ,
  Placement.PAR_CLIENT_NU                                                                         As PAR_CLIENT_NU         ,
  Coalesce(RefDMC.DMC_LINE_ID,Placement.DMC_LINE_ID)                                              As DMC_LINE_ID           ,
  Coalesce(RefDMC.DMC_MASTER_LINE_ID,Placement.DMC_MASTER_LINE_ID)                                As DMC_MASTER_LINE_ID    ,
  Coalesce(RefDMC.DMC_LINE_TYPE,Placement.DMC_LINE_TYPE)                                          As DMC_LINE_TYPE         ,
  Coalesce(RefDMC.DMC_ACTIVATION_DT,Placement.DMC_ACTIVATION_DT)                                  As DMC_ACTIVATION_DT     ,
  Coalesce(RefDMC.PAR_INSEE_NB,Placement.PAR_INSEE_NB )                                           As PAR_INSEE_NB          ,
  Coalesce(RefDMC.PAR_BU_CD,Placement.PAR_BU_CD)                                                  As PAR_BU_CD             ,
  Coalesce(RefDMC.DMC_CONVERGENT_IN,Placement.DMC_CONVERGENT_IN)                                  As DMC_CONVERGENT_IN     ,
  Coalesce(RefDMC.PAR_FIBER_IN ,Placement.PAR_FIBER_IN)                                           As PAR_FIBER_IN          ,
  Coalesce(RefIRIS.PAR_GEO_MACROZONE,Placement.PAR_GEO_MACROZONE)                                 As PAR_GEO_MACROZONE     ,
  Coalesce(RefDMC.PAR_UNIFIED_PARTY_ID,Placement.PAR_UNIFIED_PARTY_ID)                            As PAR_UNIFIED_PARTY_ID  ,
  Coalesce(RefDMC.PAR_PARTY_REGRPMNT_ID,Placement.PAR_PARTY_REGRPMNT_ID)                          As PAR_PARTY_REGRPMNT_ID ,
  Coalesce(RefIRIS.PAR_IRIS2000_CD,Placement.PAR_IRIS2000_CD)                                     As PAR_IRIS2000_CD       ,
  Coalesce(RefDMC.PAR_PID_ID,Placement.PAR_PID_ID)                                                As PAR_PID_ID            ,
  Coalesce(RefDMC.PAR_CID_ID,Placement.PAR_CID_ID)                                                As PAR_CID_ID            ,
  Coalesce(RefDMC.PAR_FIRST_IN,Placement.PAR_FIRST_IN)                                            As PAR_FIRST_IN          ,
  Coalesce(RefDMC.ADDRESS_CONCAT_NM,Placement.ADDRESS_CONCAT_NM)                                  As ADDRESS_CONCAT_NM     ,
  Coalesce(RefDMC.ADDRESS_TYPE, Placement.ADDRESS_TYPE)                                           As ADDRESS_TYPE          ,
  Null                                                                                            As SERVICE_ACCESS_ID     ,
  Coalesce(RefDMC.PAR_DEPRTMNT_ID,Placement.PAR_DEPRTMNT_ID)                                      As PAR_DEPRTMNT_ID       ,
  Coalesce(RefDMC.PAR_POSTAL_CD,Placement.PAR_POSTAL_CD)                                          As PAR_POSTAL_CD         ,
  Coalesce(RefDMC.DMC_CUST_BU_CD,Placement.DMC_CUST_BU_CD)                                        As DMC_CUST_BU_CD        ,
  Coalesce(RefINIT.RCS_AGENT_ID,Placement.RCS_AGENT_ID)                                           As RCS_AGENT_ID          ,
  Coalesce(RefINIT.RCS_NOM ,Placement.RCS_NOM)                                                    As RCS_NOM               ,
  Coalesce(RefINIT.RCS_PRENOM,Placement.RCS_PRENOM)                                               As RCS_PRENOM            ,
      Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
      End                                                                                         AS ORG_AGENT_IOBSP       ,
  Coalesce(RefINIT.EDO_ID ,Placement.EDO_ID)                                                      As EDO_ID                ,
  Coalesce(RefINIT.TYPE_EDO_ID,Placement.TYPE_EDO_ID)                                             As TYPE_EDO_ID           ,
  Case When  EdoOBK.EDO_ID is Not null
            Then 'O'
            Else 'N'
  End                                                                                             As ORG_EDO_IOBSP         ,
  Coalesce(RefINIT.DISTRBTN_CHANNL_ID,Placement.DISTRBTN_CHANNL_ID)                               As DISTRBTN_CHANNL_ID    ,
  Coalesce(RefINIT.FLAG_PLT_CONV_NB ,Placement.FLAG_PLT_CONV_NB)                                  As FLAG_PLT_CONV_NB      ,
  Coalesce(RefINIT.ORG_CHANNEL_CD,Placement.ORG_CHANNEL_CD)                                       As ORG_CHANNEL_CD        ,
  Coalesce(RefINIT.ORG_SUB_CHANNEL_CD ,Placement.ORG_SUB_CHANNEL_CD)                              As ORG_SUB_CHANNEL_CD    ,
  Coalesce(RefINIT.ORG_SUB_SUB_CHANNEL_CD,Placement.ORG_SUB_SUB_CHANNEL_CD)                       As ORG_SUB_SUB_CHANNEL_CD,
  Coalesce(RefINIT.ORG_GT_ACTIVITY , Placement.ORG_GT_ACTIVITY)                                   As ORG_GT_ACTIVITY       ,
  Coalesce(RefINIT.ORG_FIDELISATION , Placement.ORG_FIDELISATION)                                 As ORG_FIDELISATION      ,
  Coalesce(RefINIT.ORG_WEB_ACTIVITY, Placement.ORG_WEB_ACTIVITY)                                  As ORG_WEB_ACTIVITY      ,
  Coalesce(RefINIT.ORG_AUTO_ACTIVITY, Placement.ORG_AUTO_ACTIVITY)                                As ORG_AUTO_ACTIVITY     ,
  Coalesce(RefINIT.ORG_REM_CHANNEL_CD , Placement.ORG_REM_CHANNEL_CD)                             As ORG_REM_CHANNEL_CD    ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_1_CD , Placement.ORG_TEAM_LEVEL_1_CD)                           As ORG_TEAM_LEVEL_1_CD   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_1_DS , Placement.ORG_TEAM_LEVEL_1_DS)                           As ORG_TEAM_LEVEL_1_DS   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_2_CD , Placement.ORG_TEAM_LEVEL_2_CD)                           As ORG_TEAM_LEVEL_2_CD   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_2_DS , Placement.ORG_TEAM_LEVEL_2_DS)                           As ORG_TEAM_LEVEL_2_DS   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_3_CD ,Placement.ORG_TEAM_LEVEL_3_CD)                            As ORG_TEAM_LEVEL_3_CD   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_3_DS ,Placement.ORG_TEAM_LEVEL_3_DS)                            As ORG_TEAM_LEVEL_3_DS   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_4_CD ,Placement.ORG_TEAM_LEVEL_4_CD)                            As ORG_TEAM_LEVEL_4_CD   ,
  Coalesce(RefINIT.ORG_TEAM_LEVEL_4_DS ,Placement.ORG_TEAM_LEVEL_4_DS)                            As ORG_TEAM_LEVEL_4_DS   ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_1_CD ,Placement.WORK_TEAM_LEVEL_1_CD)                          As WORK_TEAM_LEVEL_1_CD  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_1_DS ,Placement.WORK_TEAM_LEVEL_1_DS)                          As WORK_TEAM_LEVEL_1_DS  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_2_CD ,Placement.WORK_TEAM_LEVEL_2_CD)                          As WORK_TEAM_LEVEL_2_CD  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_2_DS ,Placement.WORK_TEAM_LEVEL_2_DS)                          As WORK_TEAM_LEVEL_2_DS  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_3_CD ,Placement.WORK_TEAM_LEVEL_3_CD)                          As WORK_TEAM_LEVEL_3_CD  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_3_DS ,Placement.WORK_TEAM_LEVEL_3_DS)                          As WORK_TEAM_LEVEL_3_DS  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_4_CD ,Placement.WORK_TEAM_LEVEL_4_CD)                          As WORK_TEAM_LEVEL_4_CD  ,
  Coalesce(RefINIT.WORK_TEAM_LEVEL_4_DS ,Placement.WORK_TEAM_LEVEL_4_DS)                          As WORK_TEAM_LEVEL_4_DS  ,
  Placement.CREATION_TS                                                                           As CREATION_TS           ,
  Placement.LAST_MODIF_TS                                                                         As LAST_MODIF_TS         ,
  Placement.FRESH_IN                                                                              As FRESH_IN              ,
  Placement.COHERENCE_IN                                                                          As COHERENCE_IN
   From ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV_1  Placement    
   Left Outer Join ${KNB_PCO_TMP}.BIL_W_PLACEMENT_ADV_DMC RefDMC
       On    Placement.ACTE_ID           = RefDMC.ACTE_ID
      And  Placement.ORDER_DEPOSIT_DT    = RefDMC.ORDER_DEPOSIT_DT
   Left Outer Join ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV_INIT RefINIT
       On    Placement.ACTE_ID           = RefINIT.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT     = RefINIT.ORDER_DEPOSIT_DT
      And RefINIT.RCS_ENR_ACTE_ID        Is Not Null
   Left Outer Join ${KNB_PCO_TMP}.BIL_W_PLACEMENT_ADV_IRIS RefIRIS 
       On    Placement.ACTE_ID           = RefIRIS.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT     = RefIRIS.ORDER_DEPOSIT_DT
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    Placement.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT   >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID      in ('${P_PIL_163}')   And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On       Placement.RCS_AGENT_ID    = CuidOBK.AGENT_ID
        And  Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT
        And   Placement.ORDER_DEPOSIT_DT < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))


Where
  (1=1)
    Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By Placement.ORDER_DEPOSIT_TS asc)=1
;

.if errorcode <> 0 then .quit 1                                       
Collect Stat On ${KNB_PCO_TMP}.BIL_T_PLACEMENT_ADV;             
.if errorcode <> 0 then .quit 1                                       

.quit 0
