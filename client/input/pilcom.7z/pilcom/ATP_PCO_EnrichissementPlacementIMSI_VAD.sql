-- $HEADER:   %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:ATP_PCO_EnrichissementPlacementIMSI_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2011     CDR         Création
-- 06/02/2014     AID         Indus
-- 03/08/2015     YZH         QC 1100 (stabilisation perennite )
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_IMSI All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------
-- On va recherché le numéro IMSI du client
-------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_IMSI
(
  ACTE_ID                   ,
  DATE_SAISIE               ,
  PAR_IMSI                  
)
Select
  Inter.ACTE_ID                     as ACTE_ID                ,
  Inter.DATE_SAISIE                 as DATE_SAISIE            ,
  DossierCli.DOSSIER_NU_IMSI        as PAR_IMSI               
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER DossierCli
    On    Inter.DOSSIER_NU        = DossierCli.DOSSIER_NU
      And Inter.CLIENT_NU         = DossierCli.DOSSIER_CLIENT_NU
Where
  (1=1)
  And (Inter.PAR_IMSI Is Null)
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by DossierCli.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1



Collect Stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_IMSI;
.if errorcode <> 0 then .quit 1


-------------------------------------------------------------------
-- Recherche de la résiliation du dossier
-------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.COM_V_PLACEMENT_VAD_IMSI(
  ACTE_ID               Bigint                  Not null  ,
  DATE_SAISIE           Date Format 'YYYYMMDD'  Not null  ,
  PAR_IMSI              Varchar(15)                       
)
Primary Index (
  PAR_IMSI
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1



--On alimente le IMSI avec la derniere Occurrence
Insert into ${KNB_TERADATA_USER}.COM_V_PLACEMENT_VAD_IMSI
(
  ACTE_ID               ,
  DATE_SAISIE           ,
  PAR_IMSI              
)
Select
  Tmp.ACTE_ID                 as ACTE_ID          ,
  Tmp.DATE_SAISIE             as DATE_SAISIE      ,
  Tmp.PAR_IMSI                as PAR_IMSI         
From
  (
      Select
        RefId.ACTE_ID             as ACTE_ID          ,
        RefId.DATE_SAISIE         as DATE_SAISIE      ,
        RefId.PAR_IMSI            as PAR_IMSI         ,
        1                         as PRIORITY         
      From
        ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_IMSI RefId
    Union All
      Select
        RefId.ACTE_ID             as ACTE_ID          ,
        RefId.DATE_SAISIE         as DATE_SAISIE      ,
        RefId.PAR_IMSI            as PAR_IMSI         ,
        2                         as PRIORITY         
      From
        ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER RefId
      Where
        (1=1)
        And RefId.PAR_IMSI    Is Not Null
  )Tmp
Qualify Row_Number() Over (Partition By Tmp.ACTE_ID Order By Tmp.PRIORITY Asc)=1
;
.if errorcode <> 0 then .quit 1



Collect Stat On ${KNB_TERADATA_USER}.COM_V_PLACEMENT_VAD_IMSI Column(PAR_IMSI);
.if errorcode <> 0 then .quit 1



--Suppression
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESDOSIMSI All;
.if errorcode <> 0 then .quit 1

--On fait le calcul

Insert Into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESDOSIMSI
(
  ACTE_ID                     ,
  PAR_IMSI                    ,
  DATE_RESIL_DOS              ,
  CO_RESILDOS                 ,
  DOSSIER_MOTIF_RESIL         
)
Select
  Tmp.ACTE_ID                     as ACTE_ID                    ,
  Tmp.PAR_IMSI                    as PAR_IMSI                   ,
  Tmp.DATE_RESIL_DOS              as DATE_RESIL_DOS             ,
  Tmp.CO_RESILDOS                 as CO_RESILDOS                ,
  Tmp.DOSSIER_MOTIF_RESIL         as DOSSIER_MOTIF_RESIL        
From
  (
    Select
      RefImsi.ACTE_ID                                                           as ACTE_ID                ,
      RefImsi.PAR_IMSI                                                          as PAR_IMSI               ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then Coalesce(Cast(Dossier.DOSSIER_DT_RESIL as Date Format 'YYYYMMDD'),Dossier.DOSSIER_DT_DER_CHGT)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DATE_RESIL_DOS         ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then Dossier.DOSSIER_CO_RESILDOS
            Else
              --Sinon on prend rien
              Null
      End                                                                       as CO_RESILDOS           ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend le Motif de Résil
              Then Dossier.DOSSIER_LL_MOTRESIL --Varchar(32)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DOSSIER_MOTIF_RESIL  ,
      Case  When   Dossier.DOSSIER_CO_STD in (60,70,90,99999) Or Dossier.CLOSURE_DT Is Not Null
              --On priorise les dossier actif
              Then  0
            Else
                    1
      End                                                                       as PRIORITY             ,
      Dossier.DOSSIER_DT_DER_CHGT                                               as DOSSIER_DT_DER_CHGT  ,
      Dossier.DOSSIER_DT_CREAT                                                  as DOSSIER_DT_CREAT     ,     
      Dossier.DOSSIER_LC_STD                                                    as DOSSIER_LC_STD
    From
      ${KNB_TERADATA_USER}.COM_V_PLACEMENT_VAD_IMSI RefImsi
      Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
        On    RefImsi.PAR_IMSI     = Dossier.DOSSIER_NU_IMSI
  )Tmp
Qualify Row_Number() Over (Partition By Tmp.ACTE_ID
                                      Order by  Tmp.PRIORITY              Desc  ,
                                                Tmp.DOSSIER_DT_DER_CHGT   Desc  ,
                                                Tmp.DOSSIER_DT_CREAT      Desc  ,
                                                Tmp.DOSSIER_LC_STD        Desc  ,
                                                Tmp.CO_RESILDOS           Desc  ,
                                                Tmp.DATE_RESIL_DOS        Asc  
                          )=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESDOSIMSI Column(ACTE_ID);
.if errorcode <> 0 then .quit 1



.quit 0
