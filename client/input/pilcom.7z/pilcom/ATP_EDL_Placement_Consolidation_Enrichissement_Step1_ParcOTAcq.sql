-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_Enrichissement_Step1_ParcOTAcq.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrichissement Parc OTA
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_PARC all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_PARC
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PRESFACT_CO_OFFRE_OPT_ACQ ,
  INB_PRESFACT_ACQ_ADV      ,
  INB_PRESFACT_ACQ_AGAP     ,
  PARC_DT_DEBUT             ,
  PARC_DT_FIN               
)
Select
  RefId.ACTE_ID                             as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT             ,
  Prestation.PRESFACT_CO_FORM               as PRESFACT_CO_OFFRE_OPT_ACQ  ,
  Prestation.PRESFACT_CO                    as INB_PRESFACT_ACQ_ADV       ,
  Prestation.PRESFACT_CO_FORM               as INB_PRESFACT_ACQ_AGAP      ,
  ParcADV.SRVFCDOS_DT_DEBUT                 as PARC_DT_DEBUT              ,
  ParcADV.SRVFCDOS_DT_FIN                   as PARC_DT_FIN                
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
    On    RefId.DOSSIER_NU                                    =   ParcADV.SRVFCDOS_DOSSIER_NU
      --Pour les clients vendant d'EDEL on passe du prépaid au postpaid donc changement de client nu
      And RefId.INT_DEPOSIT_DT                                <=  ParcADV.SRVFCDOS_DT_DEBUT
      --On récupère le paramétrage depuis la table des delais (!!car c'est du paramétrage stable)
      And (cast(RefId.INT_DEPOSIT_DT as date)+${DelaisMeg})   >= ParcADV.SRVFCDOS_DT_DEBUT
      And ParcADV.SRVFCDOS_CO_PROD                            <> '${P_PIL_062}'
  Inner Join ${KNB_IBU_SOC}.V_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO                        = Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT                          = '${P_PIL_065}'
      And Prestation.CURRENT_IN                               = 1
Where
  (1=1)
  --Filtre sur Indicom
  And RefId.IN_CLIDOS = '${P_PIL_059}' --Pour cet enrichissement on ne tient compte que des demandes de type Dossier
Qualify Row_Number() Over (Partition By RefId.ACTE_ID Order By ParcADV.SRVFCDOS_DT_DEBUT asc, ParcADV.CLOSURE_DT asc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_PARC;
.if errorcode <> 0 then .quit 1

.quit 0
