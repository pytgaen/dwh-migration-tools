-- $HEADER: mm2pco/current/sql/ATP_OSE_Placement_CalculDelta_Jour.sql 13_05#11 19-MAR-2019 14:45:26 NNGS2043
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_OSE_Placement_CalculDelta_Jour.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'extraction vers la table ORD_W_EXTRACT_OSE
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/07/2018       LMU          Creation
-- 17/09/2018       JCR          Modif
-- 24/01/2019       TCL          Modification
-- 15/02/2021       EVI          PILCOM-824 : Pilotage et Remunération des Actes RDV
----------------------------------------------------------------------------------------------



-----------------------------------------------------------------------------------------
-- a vérifier utilisation de FIRST_ORDER_DT ou FIRST_ORDER_TS selon remplissage
-----------------------------------------------------------------------------------------
-- Creer et configurer la table IHM de parametrage de la valeur SERV_PARTN_ID
-----------------------------------------------------------------------------------------


.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_EXTRACT_OSE All;
.if errorcode <> 0 then .quit 1




----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table temporaire                                          ----
----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
-- Etape 2.1 : Exteraction des INITs                                                      ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_EXTRACT_OSE
(
EXTERNAL_ACTE_ID             ,
TYPE_SOURCE_ID               ,
INTRNL_SOURCE_ID             ,
ORDER_DEPOSIT_TS             ,
ORDER_DEPOSIT_DT             ,
ORDER_CANCELING_TS           ,
ORDER_CANCELING_DT           ,
EXTRNL_SERV_PARTN_ID         ,
ORDER_TYP_CD                 ,
EXTRNL_OPSRV_CD              ,
EXTRNL_OFFR_PARTN_CD         ,
EXTRNL_ORDR_PARTN_ID         ,
EXTRNL_DEAL_PARTN_ID         ,
EXTRNL_CUST_PARTN_ID         ,
EXTRNL_STATUS_CD             ,
STATUS_UNIFIED_CD            ,
EXTRNL_SUB_PID               ,
EXTRNL_SUB_POSTAL_CD         ,
EXTRNL_SUB_LINE_ID           ,
EXTRNL_LINE_ID_DT            ,
ORG_CHANNL_CD_CMD            ,
ORG_AGENT_ID                 ,
EXTRNL_SHOP_ID               ,
EXTRNL_EDO_ID                ,
CREATION_TS                  ,
LAST_MODIF_TS                ,
FRESH_IN                     ,
COHERENCE_IN                 ,
HOT_IN                       
)
Select 
process_vm.DEAL_PARTN_ID ||'|'||'INIT'                                          as EXTERNAL_ACTE_ID      ,
${IdentifiantTechniqueSource}                                                   as TYPE_SOURCE_ID        ,
30                                                                              as INTRNL_SOURCE_ID      ,
process_vm.FIRST_ORDER_TS                                                       as ORDER_DEPOSIT_TS      ,
cast(process_vm.FIRST_ORDER_TS as DATE FORMAT 'YYYYMMDD')                       as ORDER_DEPOSIT_DT      ,
Case
  When process_vm.LAST_ORDER_STAT_CD in ('RT', 'AN')  -- Cas 1: Annulatipon RG 6
    Then process_vm.LAST_ORDER_TS
    Else Null
End                                                                             as ORDER_CANCELING_TS    ,
Case
  When process_vm.LAST_ORDER_STAT_CD in ('RT', 'AN')  -- Cas 1: Annulatipon RG 6
    Then cast(process_vm.LAST_ORDER_TS as DATE FORMAT 'YYYYMMDD')
    Else Null
End                                                                             as ORDER_CANCELING_DT    ,
process_vm.SERV_PARTN_ID                                                        as EXTRNL_SERV_PARTN_ID  ,
'INIT'                                                                          as ORDER_TYP_CD          ,
process_vm.SERVICE_ID                                                           as EXTRNL_OPSRV_CD       ,
process_vm.ORD_OFFR_PARTN_CD                                                    as EXTRNL_OFFR_PARTN_CD  ,
process_vm.ORDER_PARTN_ID                                                       as EXTRNL_ORDR_PARTN_ID  ,
process_vm.DEAL_PARTN_ID                                                        as EXTRNL_DEAL_PARTN_ID  ,
process_vm.CUST_PARTN_ID                                                        as EXTRNL_CUST_PARTN_ID  ,
Case
  When  process_vm.LAST_ORDER_STAT_CD in ('RT', 'AN')  -- Cas 1: Annulatipon RG 6
    Then process_vm.LAST_ORDER_STAT_CD
    Else process_vm.FIRST_ORDER_STAT_CD
End                                                                             as EXTRNL_STATUS_CD      ,
Case
  When process_vm.LAST_ORDER_STAT_CD = 'RT'
    Then 'Retractee'
  When process_vm.LAST_ORDER_STAT_CD = 'AN'
    Then 'Resiliee'
  Else 'Validee'
End                                                                             as STATUS_UNIFIED_CD     ,
process_vm.PID                                                                  as EXTRNL_SUB_PID        ,
process_vm.SUB_POSTAL_CD                                                        as EXTRNL_SUB_POSTAL_CD  ,
process_vm.LINE_ID                                                              as EXTRNL_SUB_LINE_ID    ,
cast(process_vm.FIRST_ORDER_TS as DATE FORMAT 'YYYYMMDD')                       as EXTRNL_LINE_ID_DT     ,
process_vm.CHANNL_CD                                                            as ORG_CHANNL_CD_CMD     ,
process_vm.AGENT_ID                                                             as ORG_AGENT_ID          ,
process_vm.SHOP_ID                                                              as EXTRNL_SHOP_ID        ,
process_vm.EDO_ID                                                               as EXTRNL_EDO_ID         ,
Current_timestamp(0)                                                            as CREATION_TS           ,
Current_timestamp(0)                                                            as LAST_MODIF_TS         ,
1                                                                               as FRESH_IN              ,
1                                                                               as COHERENCE_IN          ,
0                                                                               as HOT_IN                

From ${KNB_DMC_COM_CAP_VM_V}.B2B_F_PROCESS_VM process_vm
where 
(1=1)
And   process_vm.SERV_PARTN_ID      = 'O-MP' -- a mettre sous ihm
And   process_vm.CURRENT_IN         = 1
And  (  process_vm.LAST_MODIF_TS    > '${KNB_PILCOM_PLACEMENT_BORNE_INF}' -- date de derniere modification extraite   
      Or
      ( process_vm.CREATION_TS           >  '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
         And process_vm.CREATION_TS       <=  (Case when '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'= '1900-01-01 00:00:00' 
                                    Then current_timestamp(0)
                                    Else cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' as timestamp(0)) 
                                 End ) )
)    
And   process_vm.CREATION_TS >= cast('01032019' as date format 'DDMMYYYY')    
And  ( process_vm.LAST_ORDER_STAT_CD In ('SA', 'OK', 'RT', 'AN')
       Or 
         process_vm.FIRST_ORDER_STAT_CD = 'SA')
Qualify Row_Number() Over (Partition By EXTERNAL_ACTE_ID Order By CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1




---------------------------------------------------------------------------------------------
-- Etape 2.2 : Extraction des ACQs                                                       ----
---------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_EXTRACT_OSE
(
    EXTERNAL_ACTE_ID      ,
    TYPE_SOURCE_ID        ,
    INTRNL_SOURCE_ID      ,
    ORDER_DEPOSIT_TS      ,
    ORDER_DEPOSIT_DT      ,
    ORDER_CANCELING_DT    ,
    ORDER_CANCELING_TS    ,
    EXTRNL_SERV_PARTN_ID  ,
    ORDER_TYP_CD          ,
    EXTRNL_OPSRV_CD       ,
    EXTRNL_OFFR_PARTN_CD  ,
    EXTRNL_ORDR_PARTN_ID  ,
    EXTRNL_DEAL_PARTN_ID  ,
    EXTRNL_CUST_PARTN_ID  ,
    EXTRNL_STATUS_CD      ,
    STATUS_UNIFIED_CD     ,
    EXTRNL_SUB_PID        ,
    EXTRNL_SUB_POSTAL_CD  ,
    EXTRNL_SUB_LINE_ID    ,
    EXTRNL_LINE_ID_DT     ,
    ORG_CHANNL_CD_CMD     ,
    ORG_AGENT_ID          ,
    EXTRNL_SHOP_ID        ,
    EXTRNL_EDO_ID         ,
    CREATION_TS           ,
    LAST_MODIF_TS         ,
    FRESH_IN              ,
    COHERENCE_IN          ,
    HOT_IN                
)
Select 
process_vm.DEAL_PARTN_ID ||'|' ||'ACQ'                         as EXTERNAL_ACTE_ID      ,
${IdentifiantTechniqueSource}                                  as TYPE_SOURCE_ID        ,
30                                                             as INTRNL_SOURCE_ID      ,
process_vm.LAST_ORDER_TS                                      as ORDER_DEPOSIT_TS      ,
cast(process_vm.LAST_ORDER_TS as DATE FORMAT 'YYYYMMDD')      as ORDER_DEPOSIT_DT      ,
Null                                                           as ORDER_CANCELING_TS    ,
Null                                                           as ORDER_CANCELLING_DT   ,
process_vm.SERV_PARTN_ID                                       as EXTRNL_SERV_PARTN_ID  ,
'ACQ'                                                          as ORDER_TYP_CD          ,
process_vm.SERVICE_ID                                          as EXTRNL_OPSRV_CD       ,
process_vm.ORD_OFFR_PARTN_CD                                   as EXTRNL_OFFR_PARTN_CD  ,
process_vm.ORDER_PARTN_ID                                      as EXTRNL_ORDR_PARTN_ID  ,
process_vm.DEAL_PARTN_ID                                       as EXTRNL_DEAL_PARTN_ID  ,
process_vm.CUST_PARTN_ID                                       as EXTRNL_CUST_PARTN_ID  ,
process_vm.LAST_ORDER_STAT_CD                                  as EXTRNL_STATUS_CD      ,
'Installee'                                                    as STATUS_UNIFIED_CD     ,
process_vm.PID                                                 as EXTRNL_SUB_PID        ,
process_vm.SUB_POSTAL_CD                                       as EXTRNL_SUB_POSTAL_CD  ,
process_vm.LINE_ID                                             as EXTRNL_SUB_LINE_ID    ,
cast(process_vm.FIRST_ORDER_TS as DATE FORMAT 'YYYYMMDD')      as EXTRNL_LINE_ID_DT     ,
process_vm.CHANNL_CD                                           as ORG_CHANNL_CD_CMD     ,
process_vm.AGENT_ID                                            as ORG_AGENT_ID          ,
process_vm.SHOP_ID                                             as EXTRNL_SHOP_ID        ,
process_vm.EDO_ID                                              as EXTRNL_EDO_ID         ,
Current_timestamp(0)                                           as CREATION_TS           ,
Current_timestamp(0)                                           as LAST_MODIF_TS         ,
1                                                              as FRESH_IN              ,
1                                                              as COHERENCE_IN          ,
0                                                              as HOT_IN                

 From ${KNB_DMC_COM_CAP_VM_V}.B2B_F_PROCESS_VM process_vm
Where 
(1=1)
And   process_vm.SERV_PARTN_ID      = 'O-MP' -- a mettre sous ihm
And   process_vm.CURRENT_IN         = 1
And  (  process_vm.LAST_MODIF_TS    > '${KNB_PILCOM_PLACEMENT_BORNE_INF}' -- date de derniere modification extraite   
      Or
      ( process_vm.CREATION_TS           >  '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
         And process_vm.CREATION_TS       <=  (Case when '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'= '1900-01-01 00:00:00' 
                                    Then current_timestamp(0)
                                    Else cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' as timestamp(0)) 
                                 End ) )
)      
And   process_vm.CREATION_TS >= cast('01032019' as date format 'DDMMYYYY')
And   process_vm.LAST_ORDER_STAT_CD In ('OK') 
Qualify Row_Number() Over (Partition By EXTERNAL_ACTE_ID Order By CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1



---------------------------------------------------------------------------------------------
-- Etape 2.3 : Extraction des RDV                                                        ----
---------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_EXTRACT_OSE
(
    EXTERNAL_ACTE_ID      ,
    TYPE_SOURCE_ID        ,
    INTRNL_SOURCE_ID      ,
    ORDER_DEPOSIT_TS      ,
    ORDER_DEPOSIT_DT      ,
    ORDER_CANCELING_DT    ,
    ORDER_CANCELING_TS    ,
    EXTRNL_SERV_PARTN_ID  ,
    ORDER_TYP_CD          ,
    EXTRNL_OPSRV_CD       ,
    EXTRNL_OFFR_PARTN_CD  ,
    EXTRNL_ORDR_PARTN_ID  ,
    EXTRNL_DEAL_PARTN_ID  ,
    EXTRNL_CUST_PARTN_ID  ,
    EXTRNL_STATUS_CD      ,
    STATUS_UNIFIED_CD     ,
    EXTRNL_SUB_PID        ,
    EXTRNL_SUB_POSTAL_CD  ,
    EXTRNL_SUB_LINE_ID    ,
    EXTRNL_LINE_ID_DT     ,
    ORG_CHANNL_CD_CMD     ,
    ORG_AGENT_ID          ,
    EXTRNL_SHOP_ID        ,
    EXTRNL_EDO_ID         ,
    CREATION_TS           ,
    LAST_MODIF_TS         ,
    FRESH_IN              ,
    COHERENCE_IN          ,
    HOT_IN                
)
Select 
process_vm.DEAL_PARTN_ID ||'|' ||'RDV'                         as EXTERNAL_ACTE_ID      ,
${IdentifiantTechniqueSource}                                  as TYPE_SOURCE_ID        ,
30                                                             as INTRNL_SOURCE_ID      ,
process_vm.CFRD_ORDER_TS                                       as ORDER_DEPOSIT_TS      ,
cast(process_vm.CFRD_ORDER_TS as DATE FORMAT 'YYYYMMDD')       as ORDER_DEPOSIT_DT      ,
Null                                                           as ORDER_CANCELING_TS    ,
Null                                                           as ORDER_CANCELLING_DT   ,
process_vm.SERV_PARTN_ID                                       as EXTRNL_SERV_PARTN_ID  ,
'INIT'                                                         as ORDER_TYP_CD          ,
'OMP_OFFRE_RDV'                                                as EXTRNL_OPSRV_CD       ,
process_vm.ORD_OFFR_PARTN_CD                                   as EXTRNL_OFFR_PARTN_CD  ,
process_vm.ORDER_PARTN_ID                                      as EXTRNL_ORDR_PARTN_ID  ,
process_vm.DEAL_PARTN_ID                                       as EXTRNL_DEAL_PARTN_ID  ,
process_vm.CUST_PARTN_ID                                       as EXTRNL_CUST_PARTN_ID  ,
'RDV'                                                          as EXTRNL_STATUS_CD      ,
'RDV Confirme'                                                 as STATUS_UNIFIED_CD     ,
process_vm.PID                                                 as EXTRNL_SUB_PID        ,
process_vm.SUB_POSTAL_CD                                       as EXTRNL_SUB_POSTAL_CD  ,
process_vm.LINE_ID                                             as EXTRNL_SUB_LINE_ID    ,
cast(process_vm.FIRST_ORDER_TS as DATE FORMAT 'YYYYMMDD')      as EXTRNL_LINE_ID_DT     ,
process_vm.CHANNL_CD                                           as ORG_CHANNL_CD_CMD     ,
process_vm.AGENT_ID                                            as ORG_AGENT_ID          ,
process_vm.SHOP_ID                                             as EXTRNL_SHOP_ID        ,
process_vm.EDO_ID                                              as EXTRNL_EDO_ID         ,
Current_timestamp(0)                                           as CREATION_TS           ,
Current_timestamp(0)                                           as LAST_MODIF_TS         ,
1                                                              as FRESH_IN              ,
1                                                              as COHERENCE_IN          ,
0                                                              as HOT_IN                

 From ${KNB_DMC_COM_CAP_VM_V}.B2B_F_PROCESS_VM process_vm
Where 
(1=1)
And   process_vm.SERV_PARTN_ID      = 'O-MP' -- a mettre sous ihm
And   process_vm.CURRENT_IN         = 1
And  (  process_vm.LAST_MODIF_TS    > '${KNB_PILCOM_PLACEMENT_BORNE_INF}' -- date de derniere modification extraite   
      Or
      ( process_vm.CREATION_TS           >  '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
         And process_vm.CREATION_TS       <=  (Case when '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'= '1900-01-01 00:00:00' 
                                    Then current_timestamp(0)
                                    Else cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' as timestamp(0)) 
                                 End ) )
)  
And   process_vm.APPOINT_CFRD_CD    = 'RDV'
And   process_vm.CFRD_ORDER_TS     Is Not Null 
And   process_vm.CFRD_ORDER_TS     <= current_date
And   process_vm.CFRD_ORDER_TS     >= Cast('01/04/2021' As Date Format 'DD/MM/YYYY')
Qualify Row_Number() Over (Partition By EXTERNAL_ACTE_ID Order By CREATION_TS Desc)=1;
.if errorcode <> 0 then .quit 1




