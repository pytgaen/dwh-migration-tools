-- $HEADER: mm2pco/current/sql/ATP_PIF_Placement_Consolidation_FusionEnrichi_Step2.sql 13_05#11 26-JUN-2019 11:40:41 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_FusionEnrichi_Step2.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 26/07/2016      HLA         '
-- 09/10/2017      MEL         Ajout de l'alimentation des champs CID/PIF/FIRST
-- 12/12/2017      HOB         Alimentation IOBSP 
-- 01/03/2019      SSI         Alimentation Champs ORG_AGENT_IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 17/08/2021      BCH         PILCOM-833 : New PIF / Décom BOI
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_PIF All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_PIF
(
  ACTE_ID                               ,
  INTRNL_SOURCE_ID                      ,
  ORDER_DEPOSIT_DT                      ,
  ORDER_DEPOSIT_TS                      ,
  PIF_ORDER_ID                          ,
  PIF_CANAL_DS                          ,
  PIF_DOSSIER_NUMBER_DS                 ,
  PIF_SELLR_SHOP_ID                     ,
  PIF_CANCEL_DS                         ,
  PIF_CANCEL_DT                         ,
  PAR_LASTNAME                          ,
  PAR_FIRSTNAME                         ,
  PAR_EMAIL                             ,
  PAR_FIXE_DS                           ,
  PAR_ND_DS                             ,
  SERVICE_ACCESS_ID                     ,
  PAR_MOBILE_DS                         ,
  MSISDN_ID                             ,
  CREATN_TYP                            ,
  RAD                                   ,
  CLIENT_NU                             ,
  CLIENT_NU_NEW_PORTE                   ,
  DOSSIER_NU                            ,
  DOSSIER_NU_NEW_PORTE                  ,
  DOSSIER_DATE_ACTIV                    ,
  DOSSIER_DATE_RESIL                    ,
  DOSSIER_TYPE_RESIL                    ,
  DOSSIER_MOTIF_RESIL                   ,
  DOSSIER_NU_IMSI                       ,
  DMC_LINE_ID                           ,
  DMC_MASTER_LINE_ID                    ,
  DMC_LINE_TYPE                         ,
  DMC_ACTIVATION_DT                     ,
  PAR_DEPRTMNT_ID                       ,
  PAR_AID                               ,
  PAR_REGRPMNT_ID                       ,
  PAR_UNIFIED_PARTY_ID                  ,
  MAIL_ADRESS                           ,
  FIRST_NAME_NM                         ,
  LAST_NAME_NM                          ,
  POSTAL_CD                             ,
  PAR_INSEE_NB                          ,
  PAR_BU_CD                             ,
  PAR_CID_ID                            ,
  PAR_PID_ID                            ,
  PAR_FIRST_IN                          ,
  PAR_IRIS2000_CD                       ,
  PAR_GEO_MACROZONE                     ,
  PAR_FIBER_IN                          ,
  ORG_AGENT_ID                          ,
  ORG_NOM                               ,
  ORG_PRENOM                            ,
  EDO_ID                                ,
  TYPE_EDO_ID                           ,
  ORG_AGENT_IOBSP                       ,
  ORG_EDO_IOBSP                         ,
  DISTRBTN_CHANNL_ID                    ,
  ACTIVITY                              ,
  FLAG_PLT_SCH_IN                       ,
  FLAG_PLT_CONV_NB                      ,
  FLAG_TYPE_GEO_CD                      ,
  FLAG_TYPE_CPT_NTK                     ,
  NETWRK_TYP_EDO_ID                     ,
  FLAG_TYPE_PTN_NTK                     ,
  FLAG_AD_SC                            ,
  UNIFIED_SHOP_CD                       ,
  ORG_REM_CHANNEL_CD                    ,
  ORG_CHANNEL_CD                        ,
  ORG_SUB_CHANNEL_CD                    ,
  ORG_SUB_SUB_CHANNEL_CD                ,
  ORG_GT_ACTIVITY                       ,
  ORG_FIDELISATION                      ,
  ORG_WEB_ACTIVITY                      ,
  ORG_AUTO_ACTIVITY                     ,
  ORG_TEAM_LEVEL_1_CD                   ,
  ORG_TEAM_LEVEL_1_DS                   ,
  ORG_TEAM_LEVEL_2_CD                   ,
  ORG_TEAM_LEVEL_2_DS                   ,
  ORG_TEAM_LEVEL_3_CD                   ,
  ORG_TEAM_LEVEL_3_DS                   ,
  ORG_TEAM_LEVEL_4_CD                   ,
  ORG_TEAM_LEVEL_4_DS                   ,
  WORK_TEAM_LEVEL_1_CD                  ,
  WORK_TEAM_LEVEL_1_DS                  ,
  WORK_TEAM_LEVEL_2_CD                  ,
  WORK_TEAM_LEVEL_2_DS                  ,
  WORK_TEAM_LEVEL_3_CD                  ,
  WORK_TEAM_LEVEL_3_DS                  ,
  WORK_TEAM_LEVEL_4_CD                  ,
  WORK_TEAM_LEVEL_4_DS                  ,
  FIBR_ELIGBT_IN                        ,
  PARC_SEG_COM_ID                       ,
  PARC_REALZTN_DT                       ,
  PARC_CANCELLNG_DT                     ,
  ORD_SEG_COM_ID                        ,
  ORD_REALZTN_DT                        ,
  ORD_CANCELLNG_DT                      ,
  DATE_CREATE_TS                        ,
  DATE_ELIG_TS                          ,
  DATE_TRANS_TS                         ,
  DATE_REM_TS                           ,
  ORDER_CANCELLING_DT                   ,
  PERENNITE_END_DT                      ,
  COMPTTN_IN                            ,
  COMPTTN_ID                            ,
  SOURCE_FRESH_TS                       ,
  CREATION_TS                           ,
  LAST_MODIF_TS                         ,
  FRESH_IN                              ,
  COHERENCE_IN                          
)
Select
  Placement.ACTE_ID                                                                  AS  ACTE_ID                       ,
  Placement.INTRNL_SOURCE_ID                                                         AS  INTRNL_SOURC                  ,
  Cast(Placement.ORDER_DEPOSIT_TS As Date Format 'YYYYMMDD')                         AS  ORDER_DEPOSIT_DT              ,
  Placement.ORDER_DEPOSIT_TS                                                         AS  ORDER_DEPOSIT_TS              ,
  Placement.PIF_ORDER_ID                                                             AS  PIF_ORDER_ID                  ,
  Placement.PIF_CANAL_DS                                                             As  PIF_CANAL_DS                  ,
  Placement.PIF_DOSSIER_NUMBER_DS                                                    As  PIF_DOSSIER_NUMBER_DS         ,
  Placement.PIF_SELLR_SHOP_ID                                                        As  PIF_SELLR_SHOP_ID             ,
  Placement.PIF_CANCEL_DS                                                            As  PIF_CANCEL_DS                 ,
  Placement.PIF_CANCEL_DT                                                            As  PIF_CANCEL_DT                 ,
  Placement.PAR_LASTNAME                                                             As  PAR_LASTNAME                  ,
  Placement.PAR_FIRSTNAME                                                            As  PAR_FIRSTNAME                 ,
  Placement.PAR_EMAIL                                                                As  PAR_EMAIL                     ,
  Placement.PAR_FIXE_DS                                                              As  PAR_FIXE_DS                   ,
  Placement.PAR_ND_DS                                                                As  PAR_ND_DS                     ,
  Placement.SERVICE_ACCESS_ID                                                        AS  SERVICE_ACCESS_ID             ,
  Placement.PAR_MOBILE_DS                                                            As  PAR_MOBILE_DS                 ,
  Placement.MSISDN_ID                                                                As  MSISDN_ID                     ,
  Placement.CREATN_TYP                                                               As  CREATN_TYP                    ,
  Placement.RAD                                                                      As  RAD                           ,
  Placement.CLIENT_NU                                                                As  CLIENT_NU                     ,
  Placement.CLIENT_NU_NEW_PORTE                                                      As  CLIENT_NU_NEW_PORTE           ,
  Placement.DOSSIER_NU                                                               As  DOSSIER_NU                    ,
  Placement.DOSSIER_NU_NEW_PORTE                                                     As  DOSSIER_NU_NEW_PORTE          ,
  Placement.DOSSIER_DATE_ACTIV                                                       As  DOSSIER_DATE_ACTIV            ,
  Placement.DOSSIER_DATE_RESIL                                                       As  DOSSIER_DATE_RESIL            ,
  Placement.DOSSIER_TYPE_RESIL                                                       As  DOSSIER_TYPE_RESIL            ,
  Placement.DOSSIER_MOTIF_RESIL                                                      As  DOSSIER_MOTIF_RESIL           ,
  Placement.DOSSIER_NU_IMSI                                                          As  DOSSIER_NU_IMSI               ,
  Coalesce(IdDmcOrder.DMC_LINE_ID,Placement.DMC_LINE_ID         )                    As  DMC_LINE_ID                   ,
  Coalesce(IdDmcOrder.DMC_MASTER_LINE_ID,Placement.DMC_MASTER_LINE_ID  )             As  DMC_MASTER_LINE_ID            ,
  Coalesce(IdDmcOrder.DMC_LINE_TYPE,Placement.DMC_LINE_TYPE       )                  As  DMC_LINE_TYPE                 ,
  Coalesce(IdDmcOrder.DMC_ACTIVATION_DT,Placement.DMC_ACTIVATION_DT   )              As  DMC_ACTIVATION_DT             ,
  Coalesce(IdDmcOrder.PAR_DEPRTMNT_ID,Placement.PAR_DEPRTMNT_ID     )                As  PAR_DEPRTMNT_ID               ,
  Coalesce(IdDmcOrder.PAR_AID,Placement.PAR_AID             )                        As  PAR_AID                       ,
  Coalesce(IdDmcOrder.PAR_PARTY_REGRPMNT_ID,Placement.PAR_REGRPMNT_ID     )          As  PAR_REGRPMNT_ID               ,
  Coalesce(IdDmcOrder.PAR_UNIFIED_PARTY_ID,Placement.PAR_UNIFIED_PARTY_ID)           As  PAR_UNIFIED_PARTY_ID          ,
  Coalesce(IdDmcOrder.MAIL_ADRESS,Placement.MAIL_ADRESS         )                    As  MAIL_ADRESS                   ,
  Coalesce(IdDmcOrder.FIRST_NAME_NM,Placement.FIRST_NAME_NM       )                  As  FIRST_NAME_NM                 ,
  Coalesce(IdDmcOrder.LAST_NAME_NM,Placement.LAST_NAME_NM        )                   As  LAST_NAME_NM                  ,
  Coalesce(IdDmcOrder.POSTAL_CD,Placement.POSTAL_CD           )                      As  POSTAL_CD                     ,
  Coalesce(IdDmcOrder.PAR_INSEE_NB,Placement.PAR_INSEE_NB        )                   As  PAR_INSEE_NB                  ,
  Coalesce(IdDmcOrder.PAR_BU_CD,Placement.PAR_BU_CD           )                      As  PAR_BU_CD                     ,
  Coalesce(IdDmcOrder.PAR_CID_ID,Placement.PAR_CID_ID           )                    As  PAR_CID_ID                    ,
  Coalesce(IdDmcOrder.PAR_PID_ID,Placement.PAR_PID_ID           )                    As  PAR_PID_ID                    ,
  Coalesce(IdDmcOrder.PAR_FIRST_IN,Placement.PAR_FIRST_IN           )                As  PAR_FIRST_IN                  ,
  Coalesce(IRISOrder.PAR_IRIS2000_CD,Placement.PAR_IRIS2000_CD     )                 AS  PAR_IRIS2000_CD               ,
  Coalesce(IRISOrder.PAR_GEO_MACROZONE,Placement.PAR_GEO_MACROZONE   )               As  PAR_GEO_MACROZONE             ,
  Coalesce(FIBEROrder.PAR_FIBER_IN,Placement.PAR_FIBER_IN        )                   AS  PAR_FIBER_IN                  ,
  Placement.ORG_AGENT_ID                                                             As  ORG_AGENT_ID                  ,
  Placement.ORG_NOM                                                                  AS  ORG_NOM                       ,
  Placement.ORG_PRENOM                                                               AS  ORG_PRENOM                    ,
  Placement.EDO_ID                                                                   As  EDO_ID                        ,
  Placement.TYPE_EDO_ID                                                              As  TYPE_EDO_ID                   ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                                              as  ORG_AGENT_IOBSP               ,
  Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
  End                                                                                as ORG_EDO_IOBSP                  ,
  Placement.DISTRBTN_CHANNL_ID                                                       As  DISTRBTN_CHANNL_ID            ,
  Placement.ACTIVITY                                                                 As  ACTIVITY                      ,
  Placement.FLAG_PLT_SCH_IN                                                          As  FLAG_PLT_SCH_IN               ,
  Placement.FLAG_PLT_CONV_NB                                                         As  FLAG_PLT_CONV_NB              ,
  Placement.FLAG_TYPE_GEO_CD                                                         As  FLAG_TYPE_GEO_CD              ,
  Placement.FLAG_TYPE_CPT_NTK                                                        As  FLAG_TYPE_CPT_NTK             ,
  Placement.NETWRK_TYP_EDO_ID                                                        As  NETWRK_TYP_EDO_ID             ,
  Placement.FLAG_TYPE_PTN_NTK                                                        As  FLAG_TYPE_PTN_NTK             ,
  Placement.FLAG_AD_SC                                                               As  FLAG_AD_SC                    ,
  Placement.UNIFIED_SHOP_CD                                                          As  UNIFIED_SHOP_CD               ,
  Channel.ORG_REM_CHANNEL_CD                                                         As  ORG_REM_CHANNEL_CD            ,
  Channel.ORG_CHANNEL_CD                                                             As  ORG_CHANNEL_CD                ,
  Channel.ORG_SUB_CHANNEL_CD                                                         As  ORG_SUB_CHANNEL_CD            ,
  Channel.ORG_SUB_SUB_CHANNEL_CD                                                     As  ORG_SUB_SUB_CHANNEL_CD        ,
  Channel.ORG_GT_ACTIVITY                                                            As  ORG_GT_ACTIVITY               ,
  Channel.ORG_FIDELISATION                                                           As  ORG_FIDELISATION              ,
  Channel.ORG_WEB_ACTIVITY                                                           As  ORG_WEB_ACTIVITY              ,
  Channel.ORG_AUTO_ACTIVITY                                                          As  ORG_AUTO_ACTIVITY             ,
  Placement.ORG_TEAM_LEVEL_1_CD                                                      As  ORG_TEAM_LEVEL_1_CD           ,
  Placement.ORG_TEAM_LEVEL_1_DS                                                      As  ORG_TEAM_LEVEL_1_DS           ,
  Placement.ORG_TEAM_LEVEL_2_CD                                                      As  ORG_TEAM_LEVEL_2_CD           ,
  Placement.ORG_TEAM_LEVEL_2_DS                                                      As  ORG_TEAM_LEVEL_2_DS           ,
  Placement.ORG_TEAM_LEVEL_3_CD                                                      As  ORG_TEAM_LEVEL_3_CD           ,
  Placement.ORG_TEAM_LEVEL_3_DS                                                      As  ORG_TEAM_LEVEL_3_DS           ,
  Placement.ORG_TEAM_LEVEL_4_CD                                                      As  ORG_TEAM_LEVEL_4_CD           ,
  Placement.ORG_TEAM_LEVEL_4_DS                                                      As  ORG_TEAM_LEVEL_4_DS           ,
  Placement.WORK_TEAM_LEVEL_1_CD                                                     As  WORK_TEAM_LEVEL_1_CD          ,
  Placement.WORK_TEAM_LEVEL_1_DS                                                     As  WORK_TEAM_LEVEL_1_DS          ,
  Placement.WORK_TEAM_LEVEL_2_CD                                                     As  WORK_TEAM_LEVEL_2_CD          ,
  Placement.WORK_TEAM_LEVEL_2_DS                                                     As  WORK_TEAM_LEVEL_2_DS          ,
  Placement.WORK_TEAM_LEVEL_3_CD                                                     As  WORK_TEAM_LEVEL_3_CD          ,
  Placement.WORK_TEAM_LEVEL_3_DS                                                     As  WORK_TEAM_LEVEL_3_DS          ,
  Placement.WORK_TEAM_LEVEL_4_CD                                                     As  WORK_TEAM_LEVEL_4_CD          ,
  Placement.WORK_TEAM_LEVEL_4_DS                                                     As  WORK_TEAM_LEVEL_4_DS          ,
  Placement.FIBR_ELIGBT_IN                                                           As  FIBR_ELIGBT_IN                ,
  Coalesce(FibreACQ.PARC_SEG_COM_ID,Parc.PARC_SEG_COM_ID    )                        As  PARC_SEG_COM_ID               ,
  Coalesce(FibreACQ.PARC_REALZTN_DT,Parc.PARC_REALZTN_DT    )                        As  PARC_REALZTN_DT               ,
  Parc.PARC_CANCELLNG_DT                                                             As  PARC_CANCELLNG_DT             ,
  OrderC.ORD_SEG_COM_ID                                                              As  ORD_SEG_COM_ID                ,
  OrderC.ORD_REALZTN_DT                                                              As  ORD_REALZTN_DT                ,
  OrderC.ORD_CANCELLNG_DT                                                            As  ORD_CANCELLNG_DT              ,
  Placement.DATE_CREATE_TS                                                           As  DATE_CREATE_TS                ,
  Placement.DATE_ELIG_TS                                                             As  DATE_ELIG_TS                  ,
  Placement.DATE_TRANS_TS                                                            As  DATE_TRANS_TS                 ,
  Coalesce(FibreACQ.DATE_REM_TS,Placement.DATE_REM_TS)                               As  DATE_REM_TS                   ,
  Placement.ORDER_CANCELLING_DT                                                      As  ORDER_CANCELLING_DT           ,
  FibreACQ.PERENNITE_END_DT                                                          As  PERENNITE_END_DT              ,
  Placement.COMPTTN_IN                                                               As  COMPTTN_IN                    ,
  Placement.COMPTTN_ID                                                               As  COMPTTN_ID                    ,
  NULL                                                                               As  SOURCE_FRESH_TS               ,
  Current_timestamp(0)                                                               As  CREATION_TS                   ,
  Current_Timestamp(0)                                                               As  LAST_MODIF_TS                 ,
  1                                                                                  As  FRESH_IN                      ,
  1                                                                                  As  COHERENCE_IN                  
From
  --On prend tout le contenu
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 Placement
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBRE_PARC Parc
    On    Placement.ACTE_ID           = Parc.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = Parc.ORDER_DEPOSIT_DT 
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBRE_ORDER OrderC
    On    Placement.ACTE_ID           = OrderC.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = OrderC.ORDER_DEPOSIT_DT 
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CHANNEL Channel
    On    Placement.ACTE_ID           = Channel.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = Channel.ORDER_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER IdDmcOrder
    On    Placement.ACTE_ID           = IdDmcOrder.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = IdDmcOrder.ORDER_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS_ORDER IRISOrder
    On    Placement.ACTE_ID           = IRISOrder.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = IRISOrder.ORDER_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER_ORDER FIBEROrder
    On    Placement.ACTE_ID           = FIBEROrder.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = FIBEROrder.ORDER_DEPOSIT_DT 
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBRE_ACQ FibreACQ
    On    Placement.ACTE_ID           = FibreACQ.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = FibreACQ.ORDER_DEPOSIT_DT          
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    Placement.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Placement.ORG_AGENT_ID=CuidOBK.AGENT_ID
        And   Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
        And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))  
      
  Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By Placement.ORDER_DEPOSIT_TS asc)=1     

Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_PIF;
.if errorcode <> 0 then .quit 1

