-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ETASK_Referentiel_Alimentation_Enrichissement_Step2_Conseiller.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  d'enrichissement du conseiller/vendeur 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/11/2014      MDE          24/11/2014
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------
-- On va dans l'orga Calculée pour trouver le nom prénom du conseiller                    ----
----------------------------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.ORD_W_REF_ETK_CONSEIL all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_REF_ETK_CONSEIL
(
  EXTERNAL_ORDER_ID               ,
  ORDER_DEPOSIT_DT                ,
  AGENT_ID                        ,
  ORG_LAST_NAME_NM                ,
  ORG_FIRST_NAME_NM               ,
  ORG_SOURCE_ENRI_CD              
)
Select
  RefId.EXTERNAL_ORDER_ID                                                             as EXTERNAL_ORDER_ID              ,
  RefId.ORDER_DEPOSIT_DT                                                              as ORDER_DEPOSIT_DT               ,
  RefId.AGENT_ID                                                                      as AGENT_ID                       ,
  RefConseiller.LAST_NAME_NM                                                          as ORG_LAST_NAME_NM               ,
  RefConseiller.FIRST_NAME_NM                                                         as ORG_FIRST_NAME_NM              ,
  RefConseiller.SOURCE_CD                                                             as ORG_SOURCE_ENRI_CD              
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK  RefId
  Inner Join ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefConseiller
    On    RefId.AGENT_ID       = RefConseiller.AGENT_CUID
Where
  (1=1)
  And RefConseiller.CURRENT_IN    = 1
  And RefConseiller.CLOSURE_DT    Is Null
  Qualify row_number() over (Partition By RefId.EXTERNAL_ORDER_ID Order By RefConseiller.LAST_NAME_NM desc) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_REF_ETK_CONSEIL;
.if errorcode <> 0 then .quit 1

.quit 0

