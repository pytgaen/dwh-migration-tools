-- $HEADER: mm2pco/current/sql/ATP_SAU_Placement_Step1_Extraction.sql 13_05#9 20-MAR-2018 10:33:49 KRQJ9961
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SAU_Placement_Step1_Extraction.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'extraction SAVI SAU
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 16/05/2017      MDE         Creation
-- 20/03/2018      JCR         Changement variable de recalcul pour eviter adherence BPM
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAU_EXT All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table temporaire                                          ----
----------------------------------------------------------------------------------------------


 
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAU_EXT
(
  EXTERNAL_ACTE_ID                 ,
  EXTERNAL_ORDR_ID                 ,
  EXT_ORDR_LINE_NU                 ,
  ORDER_DEPOSIT_DT                 ,
  ORDER_DEPOSIT_TS                 ,
  TYPE_SOURCE_ID                   ,
  INTRNL_SOURCE_ID                 ,
  ORDER_STATUS                     ,
  ORDR_TYP_CD                      ,
  MOTIF_CD                         ,
  CODE_INTERNE_CD                  ,
  CODE_INTERNE_DS                  ,
  PRESTATION_CD                    ,
  OPSRV_EAN_CD                     ,
  PAR_MSISDN_ID                    ,
  PAR_NDS                          ,
  PAR_AID                          ,
  EXT_PRODUCT_PREVIOUS_ID          ,
  PREVIOUS_EAN_CD                  ,
  TERM_FAM_CD                      ,
  TERM_MODEL_DS                    ,
  TERM_IMEI_CD                     ,
  EXT_AGENT_ID                     ,
  ORG_AGENT_ID                     ,
  ORG_LAST_NAME_NM                 ,
  ORG_FIRST_NAME_NM                ,
  EXT_SHOP_ID                      ,
  EXT_SHOP_UNITE_CD                ,
  EXT_TYP_SHOP_CD                  ,
  EXT_SHOP_ADV_CD                  ,
  PAR_LASTNAME                     ,
  PAR_FIRSTNAME                    ,
  PAR_POSTAL_CD                    ,
  DMC_LINE_ID                      ,
  DMC_MASTER_LINE_ID               ,
  DMC_LINE_TYPE                    ,
  DMC_ACTIVATION_DT                ,
  PAR_INSEE_NB                     ,
  PAR_BU_CD                        ,
  CLIENT_NU                        ,
  DOSSIER_NU                       ,
  PAR_FIBER_IN                     ,
  PAR_GEO_MACROZONE                ,
  PAR_UNIFIED_PARTY_ID             ,
  PAR_PARTY_REGRPMNT_ID            ,
  PAR_IRIS2000_CD                  ,
  PAR_PID_ID                       ,
  PAR_CID_ID                       ,
  PAR_FIRST_IN                     ,
  SERVICE_ACCESS_ID                ,
  PAR_DEPRTMNT_ID                  ,
  CUST_BU_CD                       ,
  EDO_ID                           ,
  TYPE_EDO_ID                      ,
  DISTRBTN_CHANNL_ID               ,
  ACTIVITY                         ,
  FLAG_PLT_SCH_IN                  ,
  FLAG_PLT_CONV_NB                 ,
  FLAG_TYPE_GEO_CD                 ,
  FLAG_TYPE_CPT_NTK                ,
  NETWRK_TYP_EDO_ID                ,
  FLAG_TYPE_PTN_NTK                ,
  ORG_CHANNEL_CD                   ,
  ORG_SUB_CHANNEL_CD               ,
  ORG_SUB_SUB_CHANNEL_CD           ,
  ORG_GT_ACTIVITY                  ,
  ORG_FIDELISATION                 ,
  ORG_WEB_ACTIVITY                 ,
  ORG_AUTO_ACTIVITY                ,
  ORG_REM_CHANNEL_CD               ,
  ORG_TEAM_LEVEL_1_CD              ,
  ORG_TEAM_LEVEL_1_DS              ,
  ORG_TEAM_LEVEL_2_CD              ,
  ORG_TEAM_LEVEL_2_DS              ,
  ORG_TEAM_LEVEL_3_CD              ,
  ORG_TEAM_LEVEL_3_DS              ,
  ORG_TEAM_LEVEL_4_CD              ,
  ORG_TEAM_LEVEL_4_DS              ,
  WORK_TEAM_LEVEL_1_CD             ,
  WORK_TEAM_LEVEL_1_DS             ,
  WORK_TEAM_LEVEL_2_CD             ,
  WORK_TEAM_LEVEL_2_DS             ,
  WORK_TEAM_LEVEL_3_CD             ,
  WORK_TEAM_LEVEL_3_DS             ,
  WORK_TEAM_LEVEL_4_CD             ,
  WORK_TEAM_LEVEL_4_DS             ,
  CREATION_TS                      ,
  LAST_MODIF_TS                    ,
  FRESH_IN                         ,
  COHERENCE_IN

)
Select
   (Trim(SER.DOSSIER_CD)||'|'||Trim(SERV.ORDRE))                                                      As  EXTERNAL_ACTE_ID          ,
   SER.DOSSIER_CD                                                                                     As  EXTERNAL_ORDR_ID          ,
   SERV.ORDRE                                                                                         As  EXT_ORDR_LINE_NU          ,
   SER.DOSSIER_DT                                                                                     As  ORDER_DEPOSIT_DT          ,
   Cast(SER.DOSSIER_DT AS TimeStamp(0))                                                               As  ORDER_DEPOSIT_TS          ,
   ${IdentifiantTechniqueSource}                                                                      As  TYPE_SOURCE_ID            ,
   ${IdSourceInterne}                                                                                 As  INTRNL_SOURCE_ID          ,
   'TERMINATED'                                                                                       As  ORDER_STATUS              ,
  'REA'                                                                                               As  ORDR_TYP_CD               ,
  'SAU'                                                                                               As  MOTIF_CD                  ,
  SERV.REALISE_CD                                                                                     As  CODE_INTERNE_CD           ,
  SAV.PRESTATION_LB                                                                                   As  CODE_INTERNE_DS           ,
  SAV.PRESTATION_CD                                                                                   As  PRESTATION_CD             ,
  SAV.CODE_EAN                                                                                        As  OPSRV_EAN_CD              ,
  Case  When Substring(Trim(SER.CLIENT_ND) From 2 For 1)  in ('6','7')  
          Then SER.CLIENT_ND 
         Else Null 
  End                                                                                                 As PAR_MSISDN_ID               ,
  Case  When Substring(Trim(SER.CLIENT_ND) From 2 For 1)  in ('1','2','3','4','5')  
          Then SER.CLIENT_ND 
        Else Null 
  End                                                                                                 As  PAR_NDS                    ,
  SER.CLIENT_INTERNET_CD                                                                              As  PAR_AID                    ,
  SER.PANTERE_CD                                                                                      As  EXT_PRODUCT_PREVIOUS_ID    ,
  SER.EAN                                                                                             As  PREVIOUS_EAN_CD            ,
  SER.FAMILLE_CD                                                                                      As  TERM_FAM_CD                ,
  SER.MODELE_LB                                                                                       As  TERM_MODEL_DS              ,
  SER.IMEI                                                                                            As  TERM_IMEI_CD               ,
  SER.USER_CD                                                                                         As  EXT_AGENT_ID               ,
  USR.ID_ALLIANCE                                                                                     As  ORG_AGENT_ID               ,
  USR.NOM_USER                                                                                        As  ORG_LAST_NAME_NM           ,
  USR.PRENOM_USER                                                                                     As  ORG_FIRST_NAME_NM          ,
  SER.COMPTE_CD                                                                                       As  EXT_SHOP_ID                ,
  ORG.UNITE_CD                                                                                        As  EXT_SHOP_UNITE_CD          ,
  ORG.TYPE_COMPTE_CD                                                                                  As  EXT_TYP_SHOP_CD            ,
  ORG.CODE_ADV                                                                                        As  EXT_SHOP_ADV_CD            ,
  SER.CLIENT_NOM                                                                                      As  PAR_LASTNAME               ,
  SER.CLIENT_PRENOM                                                                                   As  PAR_FIRSTNAME              ,
  SER.CLIENT_CP                                                                                       As  PAR_POSTAL_CD              ,
   Null                                                                                               As  DMC_LINE_ID                ,
   Null                                                                                               As  DMC_MASTER_LINE_ID         ,
   Null                                                                                               As  DMC_LINE_TYPE              ,
   Null                                                                                               As  DMC_ACTIVATION_DT          ,
   Null                                                                                               As  PAR_INSEE_NB               ,
   Null                                                                                               As  PAR_BU_CD                  ,
   Case  When Substring(Trim(SER.CLIENT_ND) From 2 For 1)  in ('6','7')  
          Then SER.CLIENT_ND 
         Else Null 
   End                                                                                                As  CLIENT_NU                  ,
   Null                                                                                               As  DOSSIER_NU                 ,
   Null                                                                                               As  PAR_FIBER_IN               ,
   Null                                                                                               As  PAR_GEO_MACROZONE          ,
   Null                                                                                               As  PAR_UNIFIED_PARTY_ID       ,
   Null                                                                                               As  PAR_PARTY_REGRPMNT_ID      ,
   Null                                                                                               As  PAR_IRIS2000_CD            ,
   Null                                                                                               As  PAR_PID_ID                 ,
   Null                                                                                               As  PAR_CID_ID                 ,
   Null                                                                                               As  PAR_FIRST_IN               ,
   Null                                                                                               As  SERVICE_ACCESS_ID          ,
   Null                                                                                               As  PAR_DEPRTMNT_ID            ,
   Null                                                                                               As  CUST_BU_CD                 ,
   Null                                                                                               As  EDO_ID                     ,
   Null                                                                                               As  TYPE_EDO_ID                ,
   Null                                                                                               As  DISTRBTN_CHANNL_ID         ,
   Null                                                                                               As  ACTIVITY                   ,
   Null                                                                                               As  FLAG_PLT_SCH_IN            ,
   Null                                                                                               As  FLAG_PLT_CONV_NB           ,
   Null                                                                                               As  FLAG_TYPE_GEO_CD           ,
   Null                                                                                               As  FLAG_TYPE_CPT_NTK          ,
   Null                                                                                               As  NETWRK_TYP_EDO_ID          ,
   Null                                                                                               As  FLAG_TYPE_PTN_NTK          ,
   Null                                                                                               As  ORG_CHANNEL_CD             ,
   Null                                                                                               As  ORG_SUB_CHANNEL_CD         ,
   Null                                                                                               As  ORG_SUB_SUB_CHANNEL_CD     ,
   Null                                                                                               As  ORG_GT_ACTIVITY            ,
   Null                                                                                               As  ORG_FIDELISATION           ,
   Null                                                                                               As  ORG_WEB_ACTIVITY           ,
   Null                                                                                               As  ORG_AUTO_ACTIVITY          ,
   Null                                                                                               As  ORG_REM_CHANNEL_CD         ,
   Null                                                                                               As  ORG_TEAM_LEVEL_1_CD        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_1_DS        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_2_CD        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_2_DS        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_3_CD        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_3_DS        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_4_CD        ,
   Null                                                                                               As  ORG_TEAM_LEVEL_4_DS        ,
   Null                                                                                               As  WORK_TEAM_LEVEL_1_CD       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_1_DS       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_2_CD       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_2_DS       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_3_CD       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_3_DS       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_4_CD       ,
   Null                                                                                               As  WORK_TEAM_LEVEL_4_DS       ,
  Current_timestamp(0)                                                                                As  CREATION_TS                ,
  Current_Timestamp(0)                                                                                As  LAST_MODIF_TS              ,
  1                                                                                                   As  FRESH_IN                   ,
  1                                                                                                   As  COHERENCE_IN
  
 From 
    ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_SERV  SER
       Inner Join ${KNB_COM_SOC_V_PRS}.SAV_R_ORGA ORG
        on SER.COMPTE_CD  = ORG.COMPTE_CD 
       Left Outer Join ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_PERFORM_SERV SERV
         on SER.DOSSIER_CD = SERV.DOSSIER_CD
       Left Outer Join ${KNB_COM_SOC_V_PRS}.SAV_R_SERVICE SAV
         on SAV.PRESTATION_CD = SERV.REALISE_CD
       Left Outer Join ${KNB_COM_SOC_V_PRS}.SAV_R_USER USR
         on USR.USER_CD = SER.USER_CD
  Where 
 (1=1)
   And SER.COMPLET = 'oui'
   And ORG.UNITE_CD in ('AJ5','AJ6','AJ7','AJ9','AKH','BUV','DIR','DOM','SCEREUNION','TCJ')
   And  (( Cast(SER.DOSSIER_DT AS TimeStamp(0))     >  '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
          And Cast(SER.DOSSIER_DT AS TimeStamp(0))     <=  (CAse when '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'= '1900-01-01 00:00:00'
                                                            Then current_timestamp(0)
                                                             Else cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' As timestamp(0))
                                                           End ) )
          Or SER.DOSSIER_DT >= Current_Date - ${P_PIL_524} )
  Qualify Row_Number() Over (Partition By  SER.DOSSIER_CD,SERV.ORDRE  Order By   SER.DOSSIER_DT  Asc) = 1       ;
.if errorcode <> 0 then .quit 1                                       

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAU_EXT;             

.if errorcode <> 0 then .quit 1                                       

