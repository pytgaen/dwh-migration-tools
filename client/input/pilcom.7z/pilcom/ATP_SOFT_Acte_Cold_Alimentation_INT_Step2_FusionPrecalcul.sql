-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step1_Precalcul.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Pour des raisons de perf on extrait que les commandes éligible => Suivie pour le calcul ainsi que la pérénité
---------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI
(
  ACTE_ID                     ,
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_DT            ,
  TYPE_PRODUCT                ,
  EXT_OPER_ID                 ,
  PERIODE_ID                  ,
  PRODUCT_ID                  ,
  SEG_COM_ID                  ,
  SEG_COM_AGG_ID              ,
  TYPE_SERVICE                ,
  MIGRATION_REGROUPEMENT_ID   ,
  MIGRATION_POSSIBLE          ,
  CODE_MIGRATION              ,
  TARIF_HT                    ,
  OSCAR_VALUE_NU              ,
  PARSIFAL_PARC_ID            ,
  ORDR_ID_EFB                 ,
  PARSIFAL_ORDER_ID           ,
  EXT_OPER_ID_INIT            ,
  OFFR_TYPE_ID                ,
  SERVICE_ACCESS_ID           ,
  ACTE_OPERTR_ID_COMPST_OFFR  ,
  COMPST_OFFR_ID              ,
  ATOMIC_OFFR_ID              ,
  FUNCTN_ID                   ,
  FUNCTN_VALUE_ID             ,
  PARK_ID                     ,
  REALZTN_DT                  ,
  CONTRCT_DT                  ,
  CANCELLNG_DT                ,
  VALDTN_DT                   ,
  START_COMM_DT               ,
  END_COMM_DT                 
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.TYPE_PRODUCT                                          as TYPE_PRODUCT               ,
  Placement.EXT_OPER_ID                                           as EXT_OPER_ID                ,
  Placement.PERIODE_ID                                            as PERIODE_ID                 ,
  Placement.PRODUCT_ID                                            as PRODUCT_ID                 ,
  Placement.SEG_COM_ID                                            as SEG_COM_ID                 ,
  Placement.SEG_COM_AGG_ID                                        as SEG_COM_AGG_ID             ,
  Placement.TYPE_SERVICE                                          as TYPE_SERVICE               ,
  Placement.MIGRATION_REGROUPEMENT_ID                             as MIGRATION_REGROUPEMENT_ID  ,
  Placement.MIGRATION_POSSIBLE                                    as MIGRATION_POSSIBLE         ,
  Placement.CODE_MIGRATION                                        as CODE_MIGRATION             ,
  Placement.TARIF_HT                                              as TARIF_HT                   ,
  Placement.OSCAR_VALUE_NU                                        as OSCAR_VALUE_NU             ,
  Placement.PARSIFAL_PARC_ID                                      as PARSIFAL_PARC_ID           ,
  Placement.ORDR_ID_EFB                                           as ORDR_ID_EFB                ,
  Placement.PARSIFAL_ORDER_ID                                     as PARSIFAL_ORDER_ID          ,
  Placement.EXT_OPER_ID_INIT                                      as EXT_OPER_ID_INIT           ,
  Placement.OFFR_TYPE_ID                                          as OFFR_TYPE_ID               ,
  Placement.SERVICE_ACCESS_ID                                     as SERVICE_ACCESS_ID          ,
  Placement.ACTE_OPERTR_ID_COMPST_OFFR                            as ACTE_OPERTR_ID_COMPST_OFFR ,
  Placement.COMPST_OFFR_ID                                        as COMPST_OFFR_ID             ,
  Placement.ATOMIC_OFFR_ID                                        as ATOMIC_OFFR_ID             ,
  Placement.FUNCTN_ID                                             as FUNCTN_ID                  ,
  Placement.FUNCTN_VALUE_ID                                       as FUNCTN_VALUE_ID            ,
  RefParc.PARK_ID                                                 as PARK_ID                    ,
  RefParc.REALZTN_DT                                              as REALZTN_DT                 ,
  RefParc.CONTRCT_DT                                              as CONTRCT_DT                 ,
  RefParc.CANCELLNG_DT                                            as CANCELLNG_DT               ,
  RefValid.VALDTN_DT                                              as VALDTN_DT                  ,
  Placement.START_COMM_DT                                         as START_COMM_DT              ,
  Placement.END_COMM_DT                                           as END_COMM_DT                
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_PRECAL Placement
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_PER_CHECKED RefParc
    On    Placement.ACTE_ID             = RefParc.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT    = RefParc.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_VAL_CHECKED RefValid
    On    RefValid.ACTE_ID              = RefParc.ACTE_ID
      And RefValid.ORDER_DEPOSIT_DT     = RefParc.ORDER_DEPOSIT_DT
Where
  (1=1)
  And
    (
      --On veut suivre les produits :
          --Qui sont sur une période valable :
              Placement.PERIODE_ID  <> ${P_PIL_049}
          --Dont le produit est défini dans le référentiel 
          And Placement.PRODUCT_ID  Not in ('${P_PIL_223}')
          --Et qui sont sur un segment suivi
          And Placement.SEG_COM_ID  Not in ('${P_PIL_022}','${P_PIL_295}')
    )
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI;
.if errorcode <> 0 then .quit 1


.quit 0
