--$HEADER:   mm2pco/current/sql/AVM_PIF_AlimCold_ORD_T_ACTE_UNIFIED_VenteConclue.sql 13_05#3 21-AVR-2017 10:33:50 FDGX6201 
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_PIF_AlimCold_ORD_T_ACTE_UNIFIED_VenteConclue.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de mise à jour des arguments pour les PIF
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 19/09/2016     HLA         Création
-- 21/04/2017     HLA         Modification 
---------------------------------------------------------------------------------

.set width 5000
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_UNIFIED_PIF_VENTE_CONCLU_SPEC_${Source} (
  ACTE_ID                       Bigint                  Not Null  ,
  ACT_DT                        Date Format 'YYYYMMDD'  Not Null  ,
  ACT_FLAG_PVC_REM              CHAR(1)                ,
  AGENT_ID_UPD                  VARCHAR(15)               ,
  ACTE_VALO                     VARCHAR(100)            NOT NULL
)
Primary Index (

  ACTE_ID
)
Partition By RANGE_N(ACT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_UNIFIED_PIF_VENTE_CONCLU_SPEC_${Source}
(
  ACTE_ID             ,
  ACT_DT              ,
  ACT_FLAG_PVC_REM    ,
  AGENT_ID_UPD        ,
  ACTE_VALO            
)
Select 
  UNI_T.ACTE_ID                                                                                 As ACTE_ID ,
  UNI_T.ACT_DT                                                                                  As ACT_DT  ,
   Case When UNI_T.ACT_PERIODE_STATUS ='C' And  UNI_F.ACTE_ID is not Null
         Then  UNI_F.ACT_FLAG_PVC_REM   -- On fige le statut
        When UNI_T.ACT_PERIODE_STATUS ='C' And  UNI_F.ACTE_ID is Null
         Then 'N'     -- l'acte est arrive en retard
        When UNI_T.ACT_PERIODE_STATUS ='O' Or  UNI_T.ACT_PERIODE_STATUS is Null
          Then Case  When  (   --Condition d'éligibilité
                                         (1=1)
                                         And UNI_T.MASTER_FLAG                 = 1
                                         -- L'acte doit être rémunérable
                                         And UNI_T.ACT_FLAG_ACT_REM            = 'O'
                                         -- L'acte doit avoir un conseiller
                                         And UNI_T.AGENT_ID_UPD                Is Not Null
                                         --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                                         And UNI_T.ORG_REM_CHANNEL_CD          In (${L_PIL_043})
                                         --Condition de vente conclue :
                                         And UNI_T.CONCLDD_IN                  = 'O'
                                         --L'acte ne doit pas être annulé
                                         And UNI_T.ACT_CLOSURE_DT              Is Null
                                         And UNI_T.ACT_END_UNIFIED_DT          Is Null
   
                                         -- L’EDO de type interne
                                         And ( UNI_T.ORG_TYPE_EDO        = 'INT' Or UNI_T.ORG_TYPE_EDO  is Null )
                            )
                        Then  'O'
                          Else   'N'
                        End
   End                                                                                        As ACT_FLAG_PVC_REM,
   Case When UNI_T.ACT_PERIODE_STATUS ='C' And  UNI_F.ACTE_ID is not Null
          Then  UNI_F.AGENT_ID_UPD   -- On fige le statut
          Else UNI_T.AGENT_ID_UPD
   End                                                                                        As AGENT_ID_UPD    ,
  Case When UNI_T.ACT_PERIODE_STATUS ='C' And  UNI_F.ACTE_ID is not Null
        Then  UNI_F.ACT_ACTE_VALO   -- On fige le statut
        Else UNI_T.ACT_ACTE_VALO
       End                                                                                    As ACTE_VALO         
From
  ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${Source}  UNI_T
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED UNI_F
    On UNI_T.ACTE_ID   = UNI_F.ACTE_ID
      And UNI_T.ACT_DT = UNI_F.ACT_DT
;
.if errorcode <> 0 then .quit 1
Collect Stat on ${KNB_TERADATA_USER}.ORD_V_ACTE_UNIFIED_PIF_VENTE_CONCLU_SPEC_${Source} Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat on ${KNB_TERADATA_USER}.ORD_V_ACTE_UNIFIED_PIF_VENTE_CONCLU_SPEC_${Source} Column(PARTITION);
.if errorcode <> 0 then .quit 1

 ---Update :
Update RefID
From
${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${Source} RefID ,
${KNB_TERADATA_USER}.ORD_V_ACTE_UNIFIED_PIF_VENTE_CONCLU_SPEC_${Source} RefVCS
Set
  ACT_FLAG_PVC_REM  =  RefVCS.ACT_FLAG_PVC_REM ,
  AGENT_ID_UPD      =  RefVCS.AGENT_ID_UPD     ,
  ACT_ACTE_VALO     =  RefVCS.ACTE_VALO  (decimal(15,2))
Where
  (1=1)
  And RefID.ACTE_ID=RefVCS.ACTE_ID
;
.if errorcode <> 0 then .quit 1

 
