--$HEADER:   %HEADER%
---------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_BPM_Acte_Cold_Step1_Enrichissement_Refcom.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'enrichissement Matrice REFCOM
--
---------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 19/10/2016     ABO         Création
-- 22/03/2016     MDE         Calcul sur 6 mois (REFCOM) 
-- 02/07/2018     HOB         Calcul sur 12 mois (REFCOM )
-- 23/07/2018     HOB         Evole Carte Premium
-- 17/06/2020     EVI         PILCOM-425 : Carte Family
-- 07/08/2020     EVI         PILCOM-638 : Gestion Bundle
---------------------------------------------------------------------------------------

.set width 2000;


----------------------------------------------------------
--Alimentation : limitation des periodes
---------------------------------------------------------

Create Volatile Table ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM (
  PERIODE_ID               INTEGER                       Not null           ,
  PERIODE_DATE_DEB         DATE FORMAT 'YYYYMMDD'                           ,
  PERIODE_DATE_FIN         DATE FORMAT 'YYYYMMDD'                           ,
  FRESH_IN                 BYTEINT                                          ,
  CURRENT_IN               BYTEINT                                          ,
  CLOSURE_DT               DATE FORMAT 'YYYYMMDD'
)
Primary Index (PERIODE_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

-- Limitation des periodes sur 6 mois

Insert into ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM
(
  PERIODE_ID                   ,
  PERIODE_DATE_DEB             ,
  PERIODE_DATE_FIN             ,
  FRESH_IN                     ,
  CURRENT_IN                   ,
  CLOSURE_DT
)
Select
  RefPeriod.PERIODE_ID                          As PERIODE_ID             ,
  RefPeriod.PERIODE_DATE_DEB                    As PERIODE_DATE_DEB       ,
  RefPeriod.PERIODE_DATE_FIN                    As PERIODE_DATE_FIN       ,
  RefPeriod.FRESH_IN                            As FRESH_IN               ,
  RefPeriod.CURRENT_IN                          As CURRENT_IN             ,
  RefPeriod.CLOSURE_DT                          As CLOSURE_DT
  From
  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM RefPeriod
  Where
  (1=1)
    And RefPeriod.FRESH_IN                        = 1
    And RefPeriod.CURRENT_IN                      = 1
    And RefPeriod.CLOSURE_DT                      Is Null
    And RefPeriod.PERIODE_ID >=  (  Select
                                      min (MinRefPeriod.PERIODE_ID)
                                    From
                                    ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM MinRefPeriod
                                    Where
                                       (1=1)
                                         And MinRefPeriod.FRESH_IN                        = 1
                                         And MinRefPeriod.CURRENT_IN                      = 1
                                         And MinRefPeriod.CLOSURE_DT                      Is Null
                                         And ( MinRefPeriod.PERIODE_DATE_FIN  >=  add_months(current_date ,-12) And MinRefPeriod.PERIODE_DATE_DEB  <= add_months(current_date ,-12))
                                  )
;
.if errorcode <> 0 then .quit 1
Collect stat On ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM Column (PERIODE_ID);
.if errorcode <> 0 then .quit 1


-- **************************************************************
-- Delete de la table ORD_W_ACTE_MATREFCOM_C_BPM
-- **************************************************************

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_C_BPM All;
.if errorcode <> 0 then .quit 1


-- **************************************************************
-- Alimentation de la table ORD_W_ACTE_MATREFCOM_C_BPM
-- **************************************************************
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_C_BPM
(
  PRODUCT_ID               ,
  PERIODE_ID               ,
  TYPE_COMMANDE_ID         ,
  SEG_COM_ID_INI           ,
  SEG_COM_ID_FINAL         ,
  ACTE_ID                  ,
  ACTE_REM_ID              ,
  FLAG_ACT_REM             ,
  FLAG_PEC_PERPVC          ,
  ACTE_VALO                ,
  ACTE_FAMILLE_KPI         ,
  TAUX_MARGE               ,
  UNITE_CD                  ,
  HUMAINDIGITAL
)
Select
  RefCat.PRODUCT_ID               as PRODUCT_ID               ,
  Matrice.PERIODE_ID              as PERIODE_ID               ,
  Matrice.TYPE_COMMANDE_ID        as TYPE_COMMANDE_ID         ,
  Matrice.SEG_COM_ID_INI          as SEG_COM_ID_INI           ,
  Matrice.SEG_COM_ID_FINAL        as SEG_COM_ID_FINAL         ,
  Matrice.ACTE_ID                 as ACTE_ID                  ,
  Acte.ACTE_REM_ID                as ACTE_REM_ID              ,
  Acte.FLAG_ACT_REM               as FLAG_ACT_REM             ,
  Acte.FLAG_PEC_PERPVC            as FLAG_PEC_PERPVC          ,
  Acte.ACTE_VALO                  as ACTE_VALO                ,
  Acte.ACTE_FAMILLE_KPI           as ACTE_FAMILLE_KPI         ,
  Acte.TAUX_MARGE                 as TAUX_MARGE               ,
  Acte.UNITE_CD                   as UNITE_CD                 ,
  RefKPI.HUMAINDIGITAL            as HUMAINDIGITAL  
From
  ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM Matrice
    Inner Join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      Matrice.PERIODE_ID            = RefPeriod.PERIODE_ID
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
    On   Matrice.PERIODE_ID           = Acte.PERIODE_ID
     And Matrice.ACTE_ID              = Acte.ACTE_ID
     And Acte.CURRENT_IN              = 1
     And Acte.CLOSURE_DT              is null
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefCat
    On    Matrice.SEG_COM_ID_FINAL         =  RefCat.SEG_COM_ID
      And Matrice.PERIODE_ID               =  RefCat.PERIODE_ID
      And RefCat.CURRENT_IN                =  1
      And RefCat.CLOSURE_DT                is null
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM RefKPI
      On    RefKPI.PERIODE_ID              = Acte.PERIODE_ID
        And RefKPI.FAMILLE_KPI_ID          = Acte.ACTE_FAMILLE_KPI
        And RefKPI.CURRENT_IN              = 1
        And RefKPI.CLOSURE_DT              Is Null

Where  
  (1=1)
  And Matrice.CURRENT_IN                 =1
  And Matrice.CLOSURE_DT                 is null
  And Matrice.SEG_COM_ID_FINAL           in ('OBKSOUCMP','OBKINDCMP','OBKIND_SOUCMP','OBKINDOPTPRE','OBKSOUOPTPRE','OBKINDOPTFAM','OBKSOUOPTFAM'
                                            ,'OBKCPTIND','OBKCPTSTD','OBKCPTPRM','OBKPCKPRM')

Qualify Row_Number() Over (Partition by   Matrice.TYPE_COMMANDE_ID,
                                          Matrice.PERIODE_ID,
                                          Matrice.SEG_COM_ID_FINAL
                            Order by      RefCat.PRODUCT_ID asc
                          )=1
;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_MATREFCOM_C_BPM;
.if errorcode <> 0 then .quit 1



