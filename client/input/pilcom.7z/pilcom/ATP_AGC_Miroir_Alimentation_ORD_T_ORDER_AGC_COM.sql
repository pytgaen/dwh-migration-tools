-- $HEADER: mm2pco/current/sql/ATP_AGC_Miroir_Alimentation_ORD_T_ORDER_AGC_COM.sql 13_05#3 13-MAI-2019 10:12:30 LXQG9925
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_AGC_Miroir_Alimentation_ORD_T_ORDER_AGC_COM.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table de commandes AGC: ORD_T_ORDER_AGC_COM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/03/2014      YZH         Creation
-- 02/06/2016      HLA         Ajout Nouvaux Champs
--------------------------------------------------------------------------------

.set width 2500;




--Insertion dans la table des lignes de commandes :

--TODO PAramétrage

Delete from ${KNB_COM_TMP}.ORD_T_ORDER_AGC_COM all ;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_COM_TMP}.ORD_T_ORDER_AGC_COM
(
  CONTEXT_ID                  ,
  MAIN_MSISDN_ID              ,
  SECOND_MSISDN_ID            ,
  HOLDER_CIVILITY             ,
  HOLDER_LAST_NAME            ,
  HOLDER_FIRST_NAME           ,
  HOLDER_SIRET                ,
  HOLDER_ADDRESS_NM_1         ,
  HOLDER_ADDRESS_NM_2         ,
  HOLDER_ADDRESS_NM_3         ,
  HOLDER_ADDRRESS_NM_4        ,
  HOLDER_ADDRESS_POSTAL_CD    ,
  HOLDER_CITY                 ,
  HOLDER_BANK_CD              ,
  HOLDER_OFFICE_CD            ,
  HOLRDER_ACCOUNT_CD          ,
  HOLDER_RIB_KEY_CD           ,
  HOLDER_MAIL                 ,
  CUSTOMER_CLIENT_NU_ADV      ,
  CUSTOMER_MARKET_SEG         ,
  CUSTOMER_CIVILITY           ,
  CUSTOMER_LAST_NAME_NM       ,
  CUSTOMER_FIRST_NAME_NM      ,
  CUSTOMER_NAME_NM            ,
  CUSTOMER_SIRET              ,
  CUSTOMER_ADDRESS_1_NM       ,
  CUSTOMER_ADDRESS_2_NM       ,
  CUSTOMER_ADDRESS_3_NM       ,
  CUSTOMER_ADDRESS_4_NM       ,
  CUSTOMER_ADDRESS_POSTAL_CD  ,
  CUSTOMER_CITY               ,
  CUSTOMER_CATEGORIE          ,
  CUSTOMER_MAIL_CONTACT       ,
  CUSTOMER_MSISDN_CONTACT     ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  AGENT_ID                    ,
  AGENT_LAST_NAME_NM          ,
  AGENT_FIRST_NAME_NM         ,
  NB_LINE_ORDER               ,
  ORDER_COMPLETED             ,
  PID_ID                      ,
  ORDER_ROUTE_TYPE_DS         ,
  CUST_CARD_FEEDBACK_IND      ,
  ORDER_CUST_CARD_ROUTE_EXIT  ,
  QUEUE_TS                    ,
  RUN_ID                      ,
  STREAMING_TS                ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  HOT_IN                      ,
  FRESH_IN                    ,
  COHERENCE_IN
)

Select
  Com.CONTEXT_ID                              as CONTEXT_ID                               ,
  Com.MAIN_MSISDN_ID                          as MAIN_MSISDN_ID                           ,
  Com.SECOND_MSISDN_ID                        as SECOND_MSISDN_ID                         ,
  Com.HOLDER_CIVILITY                         as HOLDER_CIVILITY                          ,
  Com.HOLDER_LAST_NAME                        as HOLDER_LAST_NAME                         ,
  Com.HOLDER_FIRST_NAME                       as HOLDER_FIRST_NAME                        ,
  Com.HOLDER_SIRET                            as HOLDER_SIRET                             ,
  Com.HOLDER_ADDRESS_NM_1                     as HOLDER_ADDRESS_NM_1                      ,
  Com.HOLDER_ADDRESS_NM_2                     as HOLDER_ADDRESS_NM_2                      ,
  Com.HOLDER_ADDRESS_NM_3                     as HOLDER_ADDRESS_NM_3                      ,
  Com.HOLDER_ADDRRESS_NM_4                    as HOLDER_ADDRRESS_NM_4                     ,
  Com.HOLDER_ADDRESS_POSTAL_CD                as HOLDER_ADDRESS_POSTAL_CD                 ,
  Com.HOLDER_CITY                             as HOLDER_CITY                              ,
  Com.HOLDER_BANK_CD                          as HOLDER_BANK_CD                           ,
  Com.HOLDER_OFFICE_CD                        as HOLDER_OFFICE_CD                         ,
  Com.HOLRDER_ACCOUNT_CD                      as HOLRDER_ACCOUNT_CD                       ,
  Com.HOLDER_RIB_KEY_CD                       as HOLDER_RIB_KEY_CD                        ,
  Com.HOLDER_MAIL                             as HOLDER_MAIL                              ,
  Com.CUSTOMER_CLIENT_NU_ADV                  as CUSTOMER_CLIENT_NU_ADV                   ,
  Com.CUSTOMER_MARKET_SEG                     as CUSTOMER_MARKET_SEG                      ,
  Com.CUSTOMER_CIVILITY                       as CUSTOMER_CIVILITY                        ,
  Com.CUSTOMER_LAST_NAME_NM                   as CUSTOMER_LAST_NAME_NM                    ,
  Com.CUSTOMER_FIRST_NAME_NM                  as CUSTOMER_FIRST_NAME_NM                   ,
  Com.CUSTOMER_NAME_NM                        as CUSTOMER_NAME_NM                         ,
  Com.CUSTOMER_SIRET                          as CUSTOMER_SIRET                           ,
  Com.CUSTOMER_ADDRESS_1_NM                   as CUSTOMER_ADDRESS_1_NM                    ,
  Com.CUSTOMER_ADDRESS_2_NM                   as CUSTOMER_ADDRESS_2_NM                    ,
  Com.CUSTOMER_ADDRESS_3_NM                   as CUSTOMER_ADDRESS_3_NM                    ,
  Com.CUSTOMER_ADDRESS_4_NM                   as CUSTOMER_ADDRESS_4_NM                    ,
  Com.CUSTOMER_ADDRESS_POSTAL_CD              as CUSTOMER_ADDRESS_POSTAL_CD               ,
  Com.CUSTOMER_CITY                           as CUSTOMER_CITY                            ,
  Com.CUSTOMER_CATEGORIE                      as CUSTOMER_CATEGORIE                       ,
  Com.CUSTOMER_MAIL_CONTACT                   as CUSTOMER_MAIL_CONTACT                    ,
  Com.CUSTOMER_MSISDN_CONTACT                 as CUSTOMER_MSISDN_CONTACT                  ,
  Com.STORE_CD                                as STORE_CD                                 ,
  Com.ADV_STORE_CD                            as ADV_STORE_CD                             ,
  Com.AGENT_ID                                as AGENT_ID                                 ,
  Com.AGENT_LAST_NAME_NM                      as AGENT_LAST_NAME_NM                       ,
  Com.AGENT_FIRST_NAME_NM                     as AGENT_FIRST_NAME_NM                      ,
  Com.NB_LINE_ORDER                           as NB_LINE_ORDER                            ,
  Com.ORDER_COMPLETED                         as ORDER_COMPLETED                          ,
  Com.PID_ID                                  as PID_ID                                   ,
  Com.ORDER_ROUTE_TYPE_DS                     as ORDER_ROUTE_TYPE_DS                      ,
  Com.CUST_CARD_FEEDBACK_IND                  as CUST_CARD_FEEDBACK_IND                   ,
  Com.ORDER_CUST_CARD_ROUTE_EXIT              as ORDER_CUST_CARD_ROUTE_EXIT               ,
  Com.QUEUE_TS                                as QUEUE_TS                                 ,
  '${RUN_ID}'                                 as RUN_ID                                   ,
  Com.STREAMING_TS                            as STREAMING_TS                             ,
  Current_Timestamp(0)                        as CREATION_TS                              ,
  Null                                        as LAST_MODIF_TS                            ,
  1                                           as HOT_IN                                   ,
  1                                           as FRESH_IN                                 ,
  0                                           as COHERENCE_IN
From
  ${KNB_COM_TMP}.ORD_W_ORDER_AGC_COM Com
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_COM_TMP}.ORD_T_ORDER_AGC_COM;
.if errorcode <> 0 then .quit 1


