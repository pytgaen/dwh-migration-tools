--$HEADER: mm2pco/current/sql/ATP_NSW_Placement_Cold_Alimentation_CalculIDExterne.sql 13_05#1 23-OCT-2019 10:47:39 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSW_Placement_Hot_Alimentation_CalculIDExterne.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de calcul d'identifiant externe
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 06/01/2015      OCH         Creation
-- 28/12/2016      HLA         Modification EvoZoffres:( Nouveau parcours )
-- 18/09/2017      HOB         Nouveaux Parcours
-- 25/09/2018      TCL         Nouveau parcours 97
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_NSW_PLACEMENT_C_EXT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


-- Type terminaux
-- Insertion de donnees delta dans une table tampon placement
Insert Into ${KNB_PCO_TMP}.ORD_W_NSW_PLACEMENT_C_EXT
(
  EXTERNAL_ACTE_ID              ,
  APPLI_SOURCE_ID               ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  ORDR_ID                       ,
  TYPE_PRODUCT_CD               ,
  SUBSCRPTN_ID                  ,
  ORDR_TYPLG_DS                 ,
  ORDR_TYPLG_CD                 ,
  ORDR_CATGR_DS                 ,
  ORDR_CATGR_CD                 ,
  ORDR_CREATN_TS                ,
  ORDR_CREATN_DT                ,
  ORDR_END_DT                   ,
  ORDR_LAST_MODF_DT             ,
  ORDR_ORGN_DS                  ,
  ORDR_ORGN_CD                  ,
  ORDR_MSH_ORGN_DS              ,
  VAD_ID                        ,
  SCORNG_IN                     ,
  SCORNG_CD                     ,
  AGNT_ID                       ,
  AMNT_ORD_PAYED_AM             ,
  AMNT_MONTH_AM                 ,
  PHONE_ID                      ,
  SELLER_AGNT_ID                ,
  SHOP_NAME_DS                  ,
  SHOP_COD_DS                   ,
  SHOP_ADV_CODE_DS              ,
  BRAND_SHOP_DS                 ,
  SOFT_RESLT_PARSIFAL_ID        ,
  ETASK_RESLT_ETASK_ID          ,
  OPAL_ID                       ,
  MSISDN_DS                     ,
  RECHG_PROCH_IN                ,
  WEBPARTNR_ID                  ,
  MSISDN_RECHG_ID               ,
  MSISDN_ID                     ,
  CODFCTN_ORNG_DS               ,
  ARTCL_ID                      ,
  ARTCL_TYP_CD                  ,
  UNIT_PRIC_AM                  ,
  PRIC_AM                       ,
  PRIC_HT_AM                    ,
  OPTN_ACTVTN_DT                ,
  VALID_DURTN_DU                ,
  VALID_END_DT                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN
)
Select
  Trim(RefSPO.ORDR_ID)||'||'||Trim(RefSPO.ARTCL_ID)                                                          as EXTERNAL_ACTE_ID              ,
  --ApplicsourceID                                                                                                                            
  RefSPO.ORDR_ORGN_CD                                                                                        as APPLI_SOURCE_ID               ,
  --Appli source Interne                                                                                                                      
  ${IdSourceInterne}                                                                                         as INTRNL_SOURCE_ID              ,
  -- Param pour la table ID :                                                                                                                 
  ${IdentifiantTechniqueSource}                                                                               as TYPE_SOURCE_ID                ,
  Trim(RefSPO.ORDR_ID)                                                                                        as ORDR_ID                       ,
  RefSPO.TYPE_PRODUCT_CD                                                                                      as TYPE_PRODUCT_CD               ,
  RefSPO.SUBSCRPTN_ID                                                                                         as SUBSCRPTN_ID                  ,
  RefSpo.ORDR_TYPLG_DS                                                                                        as ORDR_TYPLG_DS                 ,
  RefSPO.ORDR_TYPLG_CD                                                                                        as ORDR_TYPLG_CD                 ,
  RefSPO.ORDR_CATGR_DS                                                                                        as ORDR_CATGR_DS                 ,
  RefSPO.ORDR_CATGR_CD                                                                                        as ORDR_CATGR_CD                 ,
  RefSPO.ORDR_CREATN_TS                                                                                       as ORDR_CREATN_TS                ,
  RefSPO.ORDR_CREATN_DT                                                                                       as ORDR_CREATN_DT                ,
  RefSPO.ORDR_END_DT                                                                                          as ORDR_END_DT                   ,
  RefSPO.ORDR_LAST_MODF_DT                                                                                    as ORDR_LAST_MODF_DT             ,
  RefSPO.ORDR_ORGN_DS                                                                                         as ORDR_ORGN_DS                  ,
  RefSPO.ORDR_ORGN_CD                                                                                         as ORDR_ORGN_CD                  ,
  RefSPO.ORDR_MSH_ORGN_DS                                                                                     as ORDR_MSH_ORGN_DS              ,
  RefSPO.VAD_ID                                                                                               as VAD_ID                        ,
  RefSPO.SCORNG_IN                                                                                            as SCORNG_IN                     ,
  RefSPO.SCORNG_CD                                                                                            as SCORNG_CD                     ,
  RefSPO.AGNT_ID                                                                                              as AGNT_ID                       ,
  RefSPO.AMNT_ORD_PAYED_AM                                                                                    as AMNT_ORD_PAYED_AM             ,
  RefSPO.AMNT_MONTH_AM                                                                                        as AMNT_MONTH_AM                 ,
  RefSPO.PHONE_ID                                                                                             as PHONE_ID                      ,
  RefSPO.SELLER_AGNT_ID                                                                                       as SELLER_AGNT_ID                ,
  RefSPO.SHOP_NAME_DS                                                                                         as SHOP_NAME_DS                  ,
  RefSPO.SHOP_COD_DS                                                                                          as SHOP_COD_DS                   ,
  RefSPO.SHOP_ADV_CODE_DS                                                                                     as SHOP_ADV_CODE_DS              ,
  RefSPO.BRAND_SHOP_DS                                                                                        as BRAND_SHOP_DS                 ,
  RefSPO.SOFT_RESLT_PARSIFAL_ID                                                                               as SOFT_RESLT_PARSIFAL_ID        ,
  RefSPO.ETASK_RESLT_ETASK_ID                                                                                 as ETASK_RESLT_ETASK_ID          ,
  RefSPO.OPAL_ID                                                                                              as OPAL_ID                       ,
  RefSPO.MSISDN_DS                                                                                            as MSISDN_DS                     ,
  RefSPO.RECHG_PROCH_IN                                                                                       as RECHG_PROCH_IN                ,
  RefSPO.WEBPARTNR_ID                                                                                         as WEBPARTNR_ID                  ,
  RefSPO.MSISDN_RECHG_ID                                                                                      as MSISDN_RECHG_ID               ,
  RefSPO.MSISDN_ID                                                                                            as MSISDN_ID                     ,
  RefSPO.CODFCTN_ORNG_DS                                                                                      as CODFCTN_ORNG_DS               ,
  Trim(RefSPO.ARTCL_ID)                                                                                       as ARTCL_ID                      ,
  RefSPO.ARTCL_TYP_CD                                                                                         as ARTCL_TYP_CD                  ,
  RefSPO.UNIT_PRIC_AM                                                                                         as UNIT_PRIC_AM                  ,
  RefSPO.PRIC_AM                                                                                              as PRIC_AM                       ,
  RefSPO.PRIC_HT_AM                                                                                           as PRIC_HT_AM                    ,
  RefSPO.OPTN_ACTVTN_DT                                                                                       as OPTN_ACTVTN_DT                ,
  RefSPO.VALID_DURTN_DU                                                                                       as VALID_DURTN_DU                ,
  RefSPO.VALID_END_DT                                                                                         as VALID_END_DT                  ,
  RefSPO.CREATION_TS                                                                                          as CREATION_TS                   ,
  RefSPO.LAST_MODIF_TS                                                                                        as LAST_MODIF_TS                 ,
  RefSPO.FRESH_IN                                                                                             as FRESH_IN                      ,
  RefSPO.COHERENCE_IN                                                                                         as COHERENCE_IN
From
  --On prend la table de delta extraite de ORD_F_SHOP_TO_WEB_OL_R_VM de la base SPO
  ${KNB_PCO_TMP}.ORD_W_ORDER_NSW_WEB_C_EXT RefSPO
Where
  (1=1)
 and RefSPO.TYPE_PRODUCT_CD = 'R'
 and RefSPO.ARTCL_ID is not Null
 Qualify Row_number() over (Partition By RefSPO.ORDR_ID,RefSPO.ARTCL_ID Order By RefSPO.ORDR_CREATN_TS asc)=1
;
.if errorcode <> 0 then .quit 1


----------------------------- les options ---------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_NSW_PLACEMENT_C_EXT
(
  EXTERNAL_ACTE_ID              ,
  APPLI_SOURCE_ID               ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  ORDR_ID                       ,
  TYPE_PRODUCT_CD               ,
  SUBSCRPTN_ID                  ,
  ORDR_TYPLG_DS                 ,
  ORDR_TYPLG_CD                 ,
  ORDR_CATGR_DS                 ,
  ORDR_CATGR_CD                 ,
  ORDR_CREATN_TS                ,
  ORDR_CREATN_DT                ,
  ORDR_END_DT                   ,
  ORDR_LAST_MODF_DT             ,
  ORDR_ORGN_DS                  ,
  ORDR_ORGN_CD                  ,
  ORDR_MSH_ORGN_DS              ,
  VAD_ID                        ,
  SCORNG_IN                     ,
  SCORNG_CD                     ,
  AGNT_ID                       ,
  AMNT_ORD_PAYED_AM             ,
  AMNT_MONTH_AM                 ,
  PHONE_ID                      ,
  SELLER_AGNT_ID                ,
  SHOP_NAME_DS                  ,
  SHOP_COD_DS                   ,
  SHOP_ADV_CODE_DS              ,
  BRAND_SHOP_DS                 ,
  SOFT_RESLT_PARSIFAL_ID        ,
  ETASK_RESLT_ETASK_ID          ,
  OPAL_ID                       ,
  MSISDN_DS                     ,
  RECHG_PROCH_IN                ,
  WEBPARTNR_ID                  ,
  MSISDN_RECHG_ID               ,
  MSISDN_ID                     ,
  CODFCTN_ORNG_DS               ,
  ARTCL_ID                      ,
  ARTCL_TYP_CD                  ,
  UNIT_PRIC_AM                  ,
  PRIC_AM                       ,
  PRIC_HT_AM                    ,
  OPTN_ACTVTN_DT                ,
  VALID_DURTN_DU                ,
  VALID_END_DT                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN
)
Select
  Trim(RefSPO.ORDR_ID)||'||'||Trim(RefSPO.CODFCTN_ORNG_DS)                                                    as EXTERNAL_ACTE_ID              ,
  --ApplicsourceID                                                                                                                             
  RefSPO.ORDR_ORGN_CD                                                                                         as APPLI_SOURCE_ID               ,
  --Appli source Interne                                                                                                                       
  ${IdSourceInterne}                                                                                          as INTRNL_SOURCE_ID              ,
  -- Param pour la table ID :                                                                                                                  
  ${IdentifiantTechniqueSource}                                                                               as TYPE_SOURCE_ID                ,
  RefSPO.ORDR_ID                                                                                              as ORDR_ID                       ,
  RefSPO.TYPE_PRODUCT_CD                                                                                      as TYPE_PRODUCT_CD               ,
  RefSPO.SUBSCRPTN_ID                                                                                         as SUBSCRPTN_ID                  ,
  RefSpo.ORDR_TYPLG_DS                                                                                        as ORDR_TYPLG_DS                 ,
  RefSPO.ORDR_TYPLG_CD                                                                                        as ORDR_TYPLG_CD                 ,
  RefSPO.ORDR_CATGR_DS                                                                                        as ORDR_CATGR_DS                 ,
  RefSPO.ORDR_CATGR_CD                                                                                        as ORDR_CATGR_CD                 ,
  RefSPO.ORDR_CREATN_TS                                                                                       as ORDR_CREATN_TS                ,
  RefSPO.ORDR_CREATN_DT                                                                                       as ORDR_CREATN_DT                ,
  RefSPO.ORDR_END_DT                                                                                          as ORDR_END_DT                   ,
  RefSPO.ORDR_LAST_MODF_DT                                                                                    as ORDR_LAST_MODF_DT             ,
  RefSPO.ORDR_ORGN_DS                                                                                         as ORDR_ORGN_DS                  ,
  RefSPO.ORDR_ORGN_CD                                                                                         as ORDR_ORGN_CD                  ,
  RefSPO.ORDR_MSH_ORGN_DS                                                                                     as ORDR_MSH_ORGN_DS              ,
  RefSPO.VAD_ID                                                                                               as VAD_ID                        ,
  RefSPO.SCORNG_IN                                                                                            as SCORNG_IN                     ,
  RefSPO.SCORNG_CD                                                                                            as SCORNG_CD                     ,
  RefSPO.AGNT_ID                                                                                              as AGNT_ID                       ,
  RefSPO.AMNT_ORD_PAYED_AM                                                                                    as AMNT_ORD_PAYED_AM             ,
  RefSPO.AMNT_MONTH_AM                                                                                        as AMNT_MONTH_AM                 ,
  RefSPO.PHONE_ID                                                                                             as PHONE_ID                      ,
  RefSPO.SELLER_AGNT_ID                                                                                       as SELLER_AGNT_ID                ,
  RefSPO.SHOP_NAME_DS                                                                                         as SHOP_NAME_DS                  ,
  RefSPO.SHOP_COD_DS                                                                                          as SHOP_COD_DS                   ,
  RefSPO.SHOP_ADV_CODE_DS                                                                                     as SHOP_ADV_CODE_DS              ,
  RefSPO.BRAND_SHOP_DS                                                                                        as BRAND_SHOP_DS                 ,
  RefSPO.SOFT_RESLT_PARSIFAL_ID                                                                               as SOFT_RESLT_PARSIFAL_ID        ,
  RefSPO.ETASK_RESLT_ETASK_ID                                                                                 as ETASK_RESLT_ETASK_ID          ,
  RefSPO.OPAL_ID                                                                                              as OPAL_ID                       ,
  RefSPO.MSISDN_DS                                                                                            as MSISDN_DS                     ,
  RefSPO.RECHG_PROCH_IN                                                                                       as RECHG_PROCH_IN                ,
  RefSPO.WEBPARTNR_ID                                                                                         as WEBPARTNR_ID                  ,
  RefSPO.MSISDN_RECHG_ID                                                                                      as MSISDN_RECHG_ID               ,
  RefSPO.MSISDN_ID                                                                                            as MSISDN_ID                     ,
  RefSPO.CODFCTN_ORNG_DS                                                                                      as CODFCTN_ORNG_DS               ,
  Trim(RefSPO.ARTCL_ID)                                                                                       as ARTCL_ID                      ,
  RefSPO.ARTCL_TYP_CD                                                                                         as ARTCL_TYP_CD                  ,
  RefSPO.UNIT_PRIC_AM                                                                                         as UNIT_PRIC_AM                  ,
  RefSPO.PRIC_AM                                                                                              as PRIC_AM                       ,
  RefSPO.PRIC_HT_AM                                                                                           as PRIC_HT_AM                    ,
  RefSPO.OPTN_ACTVTN_DT                                                                                       as OPTN_ACTVTN_DT                ,
  RefSPO.VALID_DURTN_DU                                                                                       as VALID_DURTN_DU                ,
  RefSPO.VALID_END_DT                                                                                         as VALID_END_DT                  ,
  RefSPO.CREATION_TS                                                                                          as CREATION_TS                   ,
  RefSPO.LAST_MODIF_TS                                                                                        as LAST_MODIF_TS                 ,
  RefSPO.FRESH_IN                                                                                             as FRESH_IN                      ,
  RefSPO.COHERENCE_IN                                                                                         as COHERENCE_IN
From
  --On prend la table de delta extraite de ORD_F_SHOP_TO_WEB_OL_R_VM de la base SPO
  ${KNB_PCO_TMP}.ORD_W_ORDER_NSW_WEB_C_EXT RefSPO
Where
  (1=1)
 and RefSPO.TYPE_PRODUCT_CD in ('R')
 and RefSPO.CODFCTN_ORNG_DS is not Null
 and RefSPO.ARTCL_ID is Null 
 Qualify Row_number() over (Partition By RefSPO.ORDR_ID,RefSPO.CODFCTN_ORNG_DS Order By RefSPO.ORDR_CREATN_TS asc)=1
;
.if errorcode <> 0 then .quit 1
