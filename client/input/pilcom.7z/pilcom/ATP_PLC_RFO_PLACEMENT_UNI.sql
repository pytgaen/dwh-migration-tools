-- $HEADER: mm2pco/current/sql/ATP_PLC_RFO_PLACEMENT_UNI.sql 13_05#7 05-AVR-2017 15:56:53 KRQJ9961
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_${RFORCE_SUFFIX}_PLACEMENT_UNI.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Perimetre RF - PLACEMENT - ENRICHISSEMENT PAR LES ATTRIBUTS CLIENT ISSUS DE DMC -
--
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/02/13        DARTIGUE    Creation
-- 18/02/16        MDE         Evol Digital
-- 12/01/16        HLA         Modification (Ventes associées)
-- 05/04/17        JCR         Modification (Ventes associées)
---------------------------------------------------------------------------------

.SET WIDTH 2000;

DELETE FROM      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI ALL;

.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM      ${KNB_PCO_TMP}.INT_T_PLACEMENT_${RFORCE_SUFFIX} ALL;

.IF ERRORCODE <> 0 THEN .QUIT 1;


DELETE FROM      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_IRIS ALL 
;

.IF ERRORCODE <> 0 THEN .QUIT 1;


DELETE FROM      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_FIBER  ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_BU  ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
-- PERIMETRE DES TRACAGES ASSOCIES A UN ACCES RESEAU VALORISE AVEC L'IDENTIFIANT AID BSS
                  (
                    ACTE_ID
                  , EXTERNAL_ACTE_ID
                  , TYPE_SOURCE_ID
                  , INT_ID
                  , INT_DETL_ID
                  , INT_TYPE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , INT_SRC
                  , INT_REASON
                  , INT_RESULT
                  , INT_DETL_SRC
                  , DRK_PARTY_ID
                  , FREG_PARTY_ID
                  , EUREKA_PARTY_ID
                  , PAR_PARC_CD
                  , PAR_WKNESS_SCO
                  , PAR_STORE_CD
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD
                  , ORG_CHANNEL_CD
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY               
                  , ORG_FIDELISATION              
                  , ORG_WEB_ACTIVITY              
                  , ORG_AUTO_ACTIVITY             
                  , ORG_EDO_ID                    
                  , ORG_EDO_DS                    
                  , ORG_TYPE_EDO                  
                  , ORG_FLAG_PLT_CONV             
                  , ORG_FLAG_TEAM_MKT             
                  , ORG_FLAG_TYPE_CMP             
                  , ORG_EDO_FATHR_ID_NIV1         
                  , ORG_EDO_FATHR_DS_NIV1         
                  , ORG_EDO_FATHR_ID_NIV2         
                  , ORG_EDO_FATHR_DS_NIV2         
                  , ORG_EDO_FATHR_ID_NIV3         
                  , ORG_EDO_FATHR_DS_NIV3         
                  , AUTO_ACTIVITY_IN
                  , ORG_TEAM_TYPE_ID
                  , AGENT_LOGIN_CD
                  , AGENT_FIRST_NAME
                  , AGENT_LAST_NAME
                  , EXTERNAL_TEAM_CD
                  , EXTERNAL_TEAM_NM
                  , O3_ACTIVE_TEAM_CD
                  , O3_RATTACHEMENT_TEAM_CD
                  , INT_DETL_HABLT
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID
                  , ID_FACADE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , EXTERNAL_GAM_PRODUCT_ID
                  , IND_GAM_TYPE
                  , NEW_OC_OCATID
                  , OLD_OC_OCATID
                  , LINE_ID
                  , MASTER_LINE_ID
                  , LINE_TYPE
                  , LINE_START_DT
                  , OPERATOR_PROVIDER_ID
                  , SERVICE_ACCESS_ID
                  , BUSINESS_OFFER_BEGIN_DT
                  , PARTY_KNB_ID
                  , TERMINTN_VALUE_DS
                  , EXTERNAL_SYSTEM_ID
                  , EXTERNAL_PARTY_ID
                  , FREG_PARTY_EXTERNL_ID
                  , BSS_PARTY_EXTERNL_ID
                  , RES_VALUE_DS
                  , UNIFIED_PARTY_ID
                  , PARTY_REGRPMNT_ID
                  , SIRET_CODE_CD
                  , LAST_NAME_NM
                  , FIRST_NAME_NM
                  , NAME_NM
                  , INST_ADDRESS1_NM
                  , INST_ADDRESS2_NM
                  , INST_ADDRESS3_NM
                  , INST_ADDRESS4_NM
                  , INST_ADDRESS5_NM
                  , INST_ADDRESS6_NM
                  , MAIN_ADDRESS1_NM
                  , MAIN_ADDRESS2_NM
                  , MAIN_ADDRESS3_NM
                  , MAIN_ADDRESS4_NM
                  , MAIN_ADDRESS5_NM
                  , MAIN_ADDRESS6_NM
                  , BILL_ADDRESS1_NM
                  , BILL_ADDRESS2_NM
                  , BILL_ADDRESS3_NM
                  , BILL_ADDRESS4_NM
                  , BILL_ADDRESS5_NM
                  , BILL_ADDRESS6_NM
                  , INSEE_NB
                  , POSTAL_CD
                  , DEPARTMNT_ID
                  , PAR_FIBER_IN
                  , PAR_GEO_MACROZONE  
                  , PAR_UNIFIED_PARTY_ID  
                  , PAR_PARTY_REGRPMNT_ID 
                  , PAR_IRIS2000_CD
                  , PAR_BU_CD
                  , CITY_LN
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE          
                  , IND_TECH_DMC_THRESHOLD      
                  , IND_DMC_THRESHOLD_TYPE      
                  , IND_DMC_THRESHOLD           
                  , IND_TECH_VMTIERS_THRES_T
                  , IND_TECH_VMTIERS_THRES           
                  , IND_TECH_SOC_TERMNTN_DUP    
                  , IND_TECH_SOC_TERMNTN_THRES_T
                  , IND_TECH_SOC_TERMNTN_THRES  
                  , IND_TECH_SOC_ADRSS_DUP      
                  , IND_TECH_SOC_ADRSS_THRES_T  
                  , IND_TECH_SOC_ADRSS_THRES    
                  , IND_TECH_KNB_AS_DUP
                  , RUN_ID         
                  )
SELECT             T.T_ACTE_ID                      AS ACTE_ID
                 , T.T_EXTERNAL_ACTE_ID             AS EXTERNAL_ACTE_ID
                 , T.T_TYPE_SOURCE_ID               AS TYPE_SOURCE_ID
                 , T.T_INT_ID                       AS INT_ID
                 , T.T_INT_DETL_ID                  AS INT_DETL_ID
                 , T.T_INT_TYPE                     AS INT_TYPE
                 , T.T_INT_CREATED_BY_TS            AS INT_CREATED_BY_TS
                 , T.T_INT_CREATED_BY_DT            AS INT_CREATED_BY_DT
                 , T.T_INT_SRC                      AS INT_SRC
                 , T.T_INT_RESULT                   AS INT_RESULT
                 , T.T_INT_REASON                   AS INT_REASON
                 , T.T_INT_DETL_SRC                 AS INT_DETL_SRC
                 , T.T_DRK_PARTY_ID                 AS DRK_PARTY_ID
                 , T.T_FREG_PARTY_ID                AS FREG_PARTY_ID
                 , T.T_EUREKA_PARTY_ID              AS EUREKA_PARTY_ID
                 , T.T_PAR_PARC_CD                  AS PAR_PARC_CD
                 , T.T_PAR_WKNESS_SCO               AS PAR_WKNESS_SCO
                 , T.T_PAR_STORE_CD                 AS PAR_STORE_CD
                 , T.T_REM_CHANNEL_CD               AS REM_CHANNEL_CD
                 , T.T_ORG_REM_CHANNEL_CD           AS ORG_REM_CHANNEL_CD
                 , T.T_ORG_CHANNEL_CD               AS ORG_CHANNEL_CD
                 , T.T_ORG_SUB_CHANNEL_CD           AS ORG_SUB_CHANNEL_CD
                 , T.T_ORG_SUB_SUB_CHANNEL_CD       AS ORG_SUB_SUB_CHANNEL_CD
                 , T.T_ACTIVITY_CD                  AS ACTIVITY_CD
                 , T.T_ORG_GT_ACTIVITY              AS ORG_GT_ACTIVITY      
                 , T.T_ORG_FIDELISATION             AS ORG_FIDELISATION     
                 , T.T_ORG_WEB_ACTIVITY             AS ORG_WEB_ACTIVITY     
                 , T.T_ORG_AUTO_ACTIVITY            AS ORG_AUTO_ACTIVITY    
                 , T.T_ORG_EDO_ID                   AS ORG_EDO_ID           
                 , T.T_ORG_EDO_DS                   AS ORG_EDO_DS           
                 , T.T_ORG_TYPE_EDO                 AS ORG_TYPE_EDO         
                 , T.T_ORG_FLAG_PLT_CONV            AS ORG_FLAG_PLT_CONV    
                 , T.T_ORG_FLAG_TEAM_MKT            AS ORG_FLAG_TEAM_MKT    
                 , T.T_ORG_FLAG_TYPE_CMP            AS ORG_FLAG_TYPE_CMP    
                 , T.T_ORG_EDO_FATHR_ID_NIV1        AS ORG_EDO_FATHR_ID_NIV1
                 , T.T_ORG_EDO_FATHR_DS_NIV1        AS ORG_EDO_FATHR_DS_NIV1
                 , T.T_ORG_EDO_FATHR_ID_NIV2        AS ORG_EDO_FATHR_ID_NIV2
                 , T.T_ORG_EDO_FATHR_DS_NIV2        AS ORG_EDO_FATHR_DS_NIV2
                 , T.T_ORG_EDO_FATHR_ID_NIV3        AS ORG_EDO_FATHR_ID_NIV3
                 , T.T_ORG_EDO_FATHR_DS_NIV3        AS ORG_EDO_FATHR_DS_NIV3
                 , T.T_AUTO_ACTIVITY_IN             AS AUTO_ACTIVITY_IN
                 , T.T_ORG_TEAM_TYPE_ID             AS ORG_TEAM_TYPE_ID
                 , T.T_AGENT_LOGIN_CD               AS AGENT_LOGIN_CD
                 , T.T_AGENT_FIRST_NAME             AS AGENT_FIRST_NAME
                 , T.T_AGENT_LAST_NAME              AS AGENT_LAST_NAME
                 , T.T_EXTERNAL_TEAM_CD             AS EXTERNAL_TEAM_CD
                 , T.T_EXTERNAL_TEAM_NM             AS EXTERNAL_TEAM_NM
                 , T.T_O3_ACTIVE_TEAM_CD            AS O3_ACTIVE_TEAM_CD
                 , T.T_O3_RATTACHEMENT_TEAM_CD      AS O3_RATTACHEMENT_TEAM_CD
                 , T.T_INT_DETL_HABLT               AS INT_DETL_HABLT
                 , T.T_INT_CANAL_VENTE              AS INT_CANAL_VENTE
                 , T.T_ORG_CANAL_ID                 AS ORG_CANAL_ID
                 , T.T_ID_FACADE                    AS ID_FACADE
                 , T.T_EXTERNAL_PRODUCT_ID_FINAL    AS EXTERNAL_PRODUCT_ID_FINAL
                 , T.T_EXTERNAL_GAM_PRODUCT_ID      AS EXTERNAL_GAM_PRODUCT_ID
                 , T.T_IND_GAM_TYPE                 AS IND_GAM_TYPE
                 , T.T_NEW_OC_OCATID                AS NEW_OC_OCATID
                 , T.T_OLD_OC_OCATID                AS OLD_OC_OCATID
                 , T.T_LINE_ID                      AS LINE_ID
                 , T.T_MASTER_LINE_ID               AS MASTER_LINE_ID
                 , T.T_LINE_TYPE                    AS LINE_TYPE
                 , T.T_LINE_START_DT                AS LINE_START_DT
                 , T.T_OPERATOR_PROVIDER_ID         AS OPERATOR_PROVIDER_ID
                 , T.T_SERVICE_ACCESS_ID            AS SERVICE_ACCESS_ID
                 , T.T_BUSINESS_OFFER_BEGIN_DT      AS BUSINESS_OFFER_BEGIN_DT
                 , T.T_PARTY_KNB_ID                 AS PARTY_KNB_ID
                 , T.T_TERMINTN_VALUE_DS            AS TERMINTN_VALUE_DS
                 , T.T_EXTERNAL_SYSTEM_ID           AS EXTERNAL_SYSTEM_ID
                 , T.T_EXTERNAL_PARTY_ID            AS EXTERNAL_PARTY_ID
                 , T.T_FREG_PARTY_EXTERNL_ID        AS FREG_PARTY_EXTERNL_ID
                 , T.T_BSS_PARTY_EXTERNL_ID         AS BSS_PARTY_EXTERNL_ID
                 , T.T_RES_VALUE_DS                 AS RES_VALUE_DS
                 , T.T_UNIFIED_PARTY_ID             AS UNIFIED_PARTY_ID
                 , T.T_PARTY_REGRPMNT_ID            AS PARTY_REGRPMNT_ID
                 , T.T_SIRET_CODE_CD                AS SIRET_CODE_CD
                 , T.T_LAST_NAME_NM                 AS LAST_NAME_NM
                 , T.T_FIRST_NAME_NM                AS FIRST_NAME_NM
                 , T.T_NAME_NM                      AS NAME_NM
                 , T.T_INST_ADDRESS1_NM             AS INST_ADDRESS1_NM
                 , T.T_INST_ADDRESS2_NM             AS INST_ADDRESS2_NM
                 , T.T_INST_ADDRESS3_NM             AS INST_ADDRESS3_NM
                 , T.T_INST_ADDRESS4_NM             AS INST_ADDRESS4_NM
                 , T.T_INST_ADDRESS5_NM             AS INST_ADDRESS5_NM
                 , T.T_INST_ADDRESS6_NM             AS INST_ADDRESS6_NM
                 , T.T_MAIN_ADDRESS1_NM             AS MAIN_ADDRESS1_NM
                 , T.T_MAIN_ADDRESS2_NM             AS MAIN_ADDRESS2_NM
                 , T.T_MAIN_ADDRESS3_NM             AS MAIN_ADDRESS3_NM
                 , T.T_MAIN_ADDRESS4_NM             AS MAIN_ADDRESS4_NM
                 , T.T_MAIN_ADDRESS5_NM             AS MAIN_ADDRESS5_NM
                 , T.T_MAIN_ADDRESS6_NM             AS MAIN_ADDRESS6_NM
                 , T.T_BILL_ADDRESS1_NM             AS BILL_ADDRESS1_NM
                 , T.T_BILL_ADDRESS2_NM             AS BILL_ADDRESS2_NM
                 , T.T_BILL_ADDRESS3_NM             AS BILL_ADDRESS3_NM
                 , T.T_BILL_ADDRESS4_NM             AS BILL_ADDRESS4_NM
                 , T.T_BILL_ADDRESS5_NM             AS BILL_ADDRESS5_NM
                 , T.T_BILL_ADDRESS6_NM             AS BILL_ADDRESS6_NM
                 , T.T_INSEE_NB                     AS INSEE_NB
                 , T.T_POSTAL_CD                    AS POSTAL_CD
                 , T.T_DEPARTMNT_ID                 AS DEPARTMNT_ID
                 , T.T_PAR_FIBER_IN                 AS PAR_FIBER_IN
                 , T.T_PAR_GEO_MACROZONE            AS PAR_GEO_MACROZONE    
                 , T.T_PAR_UNIFIED_PARTY_ID         AS PAR_UNIFIED_PARTY_ID 
                 , T.T_PAR_PARTY_REGRPMNT_ID        AS PAR_PARTY_REGRPMNT_ID
                 , T.T_PAR_IRIS2000_CD              AS PAR_IRIS2000_CD
                 , T.T_PAR_BU_CD                    AS PAR_BU_CD
                 , T.T_CITY_LN                      AS CITY_LN
                 , T.T_SCORE_VALUE                  AS SCORE_VALUE
                 , T.T_SCORE_THRESHOLD              AS SCORE_THRESHOLD
                 , T.T_SCORE_IN                     AS SCORE_IN
                 , T.T_TAC_ID                       AS TAC_ID
                 , T.T_IMEI_CD                      AS IMEI_CD
                 , T.T_IMSI_CD                      AS IMSI_CD
                 , T.T_IND_INT_RESULT_ERR           AS IND_INT_RESULT_ERR
                 , T.T_IND_DMC_COH_DOMAIN           AS IND_DMC_COH_DOMAIN
                 , T.T_IND_TECH_DMC_THRESHOLD_TYPE  AS IND_TECH_DMC_THRESHOLD_TYPE          
                 , T.T_IND_TECH_DMC_THRESHOLD       AS IND_TECH_DMC_THRESHOLD      
                 , T.T_IND_DMC_THRESHOLD_TYPE       AS IND_DMC_THRESHOLD_TYPE      
                 , T.T_IND_DMC_THRESHOLD            AS IND_DMC_THRESHOLD           
                 , T.T_IND_TECH_VMTIERS_THRES_T     AS IND_TECH_VMTIERS_THRES_T
                 , T.T_IND_TECH_VMTIERS_THRES       AS IND_TECH_VMTIERS_THRES           
                 , T.T_IND_TECH_SOC_TERMNTN_DUP     AS IND_TECH_SOC_TERMNTN_DUP    
                 , T.T_IND_TECH_SOC_TERMNTN_THRES_T AS IND_TECH_SOC_TERMNTN_THRES_T
                 , T.T_IND_TECH_SOC_TERMNTN_THRES   AS IND_TECH_SOC_TERMNTN_THRES  
                 , T.T_IND_TECH_SOC_ADRSS_DUP       AS IND_TECH_SOC_ADRSS_DUP      
                 , T.T_IND_TECH_SOC_ADRSS_THRES_T   AS IND_TECH_SOC_ADRSS_THRES_T  
                 , T.T_IND_TECH_SOC_ADRSS_THRES     AS IND_TECH_SOC_ADRSS_THRES    
                 , T.T_IND_TECH_KNB_AS_DUP          AS IND_TECH_KNB_AS_DUP
                 , T.T_RUN_ID                       AS RUN_ID         
FROM              (                                    
                    SELECT             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID                                                                               AS T_ACTE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                                      AS T_EXTERNAL_ACTE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.TYPE_SOURCE_ID                                                                        AS T_TYPE_SOURCE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_ID                                                                                AS T_INT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_ID                                                                           AS T_INT_DETL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_INT_TYPE                                                                          AS T_INT_TYPE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_TS                                                                     AS T_INT_CREATED_BY_TS
                                   ,   CAST(INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_TS AS DATE)                                                       AS T_INT_CREATED_BY_DT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_SRC                                                                               AS T_INT_SRC
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_RESULT                                                                            AS T_INT_RESULT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_REASON                                                                            AS T_INT_REASON
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_SRC                                                                          AS T_INT_DETL_SRC
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.DRK_PARTY_ID                                                                          AS T_DRK_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.FREG_PARTY_ID                                                                         AS T_FREG_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EUREKA_PARTY_ID                                                                       AS T_EUREKA_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_PARC_CD                                                                           AS T_PAR_PARC_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_WKNESS_SCO                                                                        AS T_PAR_WKNESS_SCO
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_STORE_CD                                                                          AS T_PAR_STORE_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.REM_CHANNEL_CD                                                                        AS T_REM_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_REM_CHANNEL_CD                                                                    AS T_ORG_REM_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_CHANNEL_CD                                                                        AS T_ORG_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_SUB_CHANNEL_CD                                                                    AS T_ORG_SUB_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_SUB_SUB_CHANNEL_CD                                                                AS T_ORG_SUB_SUB_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ACTIVITY_CD                                                                           AS T_ACTIVITY_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_GT_ACTIVITY                                                                       AS T_ORG_GT_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FIDELISATION                                                                      AS T_ORG_FIDELISATION
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_WEB_ACTIVITY                                                                      AS T_ORG_WEB_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_AUTO_ACTIVITY                                                                     AS T_ORG_AUTO_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_ID                                                                            AS T_ORG_EDO_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_DS                                                                            AS T_ORG_EDO_DS
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_TYPE_EDO                                                                          AS T_ORG_TYPE_EDO
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_PLT_CONV                                                                     AS T_ORG_FLAG_PLT_CONV
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_TEAM_MKT                                                                     AS T_ORG_FLAG_TEAM_MKT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_TYPE_CMP                                                                     AS T_ORG_FLAG_TYPE_CMP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV1                                                                 AS T_ORG_EDO_FATHR_ID_NIV1
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV1                                                                 AS T_ORG_EDO_FATHR_DS_NIV1
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV2                                                                 AS T_ORG_EDO_FATHR_ID_NIV2
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV2                                                                 AS T_ORG_EDO_FATHR_DS_NIV2
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV3                                                                 AS T_ORG_EDO_FATHR_ID_NIV3
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV3                                                                 AS T_ORG_EDO_FATHR_DS_NIV3
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AUTO_ACTIVITY_IN                                                                      AS T_AUTO_ACTIVITY_IN
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_TEAM_TYPE_ID                                                                      AS T_ORG_TEAM_TYPE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_LOGIN_CD                                                                        AS T_AGENT_LOGIN_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_FIRST_NAME                                                                      AS T_AGENT_FIRST_NAME
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_LAST_NAME                                                                       AS T_AGENT_LAST_NAME
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_TEAM_CD                                                                      AS T_EXTERNAL_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_TEAM_NM                                                                      AS T_EXTERNAL_TEAM_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.O3_ACTIVE_TEAM_CD                                                                     AS T_O3_ACTIVE_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.O3_RATTACHEMENT_TEAM_CD                                                               AS T_O3_RATTACHEMENT_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_HABLT                                                                        AS T_INT_DETL_HABLT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CANAL_VENTE                                                                       AS T_INT_CANAL_VENTE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_CANAL_ID                                                                          AS T_ORG_CANAL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ID_FACADE                                                                             AS T_ID_FACADE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_PRODUCT_ID_FINAL                                                             AS T_EXTERNAL_PRODUCT_ID_FINAL
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_GAM_PRODUCT_ID                                                               AS T_EXTERNAL_GAM_PRODUCT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_GAM_TYPE                                                                          AS T_IND_GAM_TYPE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.NEW_OC_OCATID                                                                         AS T_NEW_OC_OCATID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.OLD_OC_OCATID                                                                         AS T_OLD_OC_OCATID
                                   ,   PAR_H_AR_VM_HIST.LINE_ID                                                                                   AS T_LINE_ID
                                   ,   PAR_H_AR_VM_HIST.MASTER_LINE_ID                                                                            AS T_MASTER_LINE_ID
                                   ,   PAR_H_AR_VM_HIST.LINE_TYPE                                                                                 AS T_LINE_TYPE
                                   ,   PAR_H_AR_VM_HIST.START_DT                                                                                  AS T_LINE_START_DT
                                   ,   PAR_H_AR_VM_HIST.OPERATOR_PROVIDER_ID                                                                      AS T_OPERATOR_PROVIDER_ID
                                   ,   PAR_H_AR_VM_HIST.SERVICE_ACCESS_ID                                                                         AS T_SERVICE_ACCESS_ID
                                   ,   PAR_H_AR_VM_HIST.BUSINESS_OFFER_BEGIN_DT                                                                   AS T_BUSINESS_OFFER_BEGIN_DT
                                   ,   PAR_H_AR_VM_HIST.PARTY_KNB_ID                                                                              AS T_PARTY_KNB_ID
                                   ,   PAR_H_AR_VM_HIST.TERMINTN_VALUE_DS                                                                         AS T_TERMINTN_VALUE_DS
                                   ,   PAR_H_AR_VM_HIST.EXTERNAL_SYSTEM_ID                                                                        AS T_EXTERNAL_SYSTEM_ID
                                   ,   PAR_H_AR_VM_HIST.EXTERNAL_PARTY_ID                                                                         AS T_EXTERNAL_PARTY_ID
                                   ,   PAR_H_AR_VM_HIST.FREG_PARTY_EXTERNL_ID                                                                     AS T_FREG_PARTY_EXTERNL_ID
                                   ,   PAR_H_AR_VM_HIST.BSS_PARTY_EXTERNL_ID                                                                      AS BSS_PARTY_EXTERNL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.RES_VALUE_DS                                                                          AS T_RES_VALUE_DS
                                   ,   PAR_H_AR_VM_HIST.UNIFIED_PARTY_ID                                                                          AS T_UNIFIED_PARTY_ID
                                   ,   PAR_H_AR_VM_HIST.PARTY_REGRPMNT_ID                                                                         AS T_PARTY_REGRPMNT_ID
                                   ,   PAR_H_AR_VM_HIST.SIRET_CODE_CD                                                                             AS T_SIRET_CODE_CD
                                   ,   PAR_H_AR_VM_HIST.LAST_NAME_NM                                                                              AS T_LAST_NAME_NM
                                   ,   PAR_H_AR_VM_HIST.FIRST_NAME_NM                                                                             AS T_FIRST_NAME_NM
                                   ,   PAR_H_AR_VM_HIST.NAME_NM                                                                                   AS T_NAME_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS1_NM                                                                          AS T_INST_ADDRESS1_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS2_NM                                                                          AS T_INST_ADDRESS2_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS3_NM                                                                          AS T_INST_ADDRESS3_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS4_NM                                                                          AS T_INST_ADDRESS4_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS5_NM                                                                          AS T_INST_ADDRESS5_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS6_NM                                                                          AS T_INST_ADDRESS6_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS1_NM                                                                          AS T_MAIN_ADDRESS1_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS2_NM                                                                          AS T_MAIN_ADDRESS2_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS3_NM                                                                          AS T_MAIN_ADDRESS3_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS4_NM                                                                          AS T_MAIN_ADDRESS4_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS5_NM                                                                          AS T_MAIN_ADDRESS5_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS6_NM                                                                          AS T_MAIN_ADDRESS6_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS1_NM                                                                          AS T_BILL_ADDRESS1_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS2_NM                                                                          AS T_BILL_ADDRESS2_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS3_NM                                                                          AS T_BILL_ADDRESS3_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS4_NM                                                                          AS T_BILL_ADDRESS4_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS5_NM                                                                          AS T_BILL_ADDRESS5_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS6_NM                                                                          AS T_BILL_ADDRESS6_NM
                                   ,   PAR_H_AR_VM_HIST.INSEE_NB                                                                                  AS T_INSEE_NB
                                   ,   PAR_H_AR_VM_HIST.POSTAL_CD                                                                                 AS T_POSTAL_CD
                                   ,   PAR_H_AR_VM_HIST.DEPRTMNT_ID                                                                               AS T_DEPARTMNT_ID
                                   ,   NULL                                                                                                       AS T_PAR_FIBER_IN 
                                   ,   Null                                                                                                       As T_PAR_GEO_MACROZONE    
                                   ,   Null                                                                                                       As T_PAR_UNIFIED_PARTY_ID 
                                   ,   Null                                                                                                       As T_PAR_PARTY_REGRPMNT_ID
                                   ,   NULL                                                                                                       AS T_PAR_IRIS2000_CD                                
                                   ,   NULL                                                                                                       AS T_PAR_BU_CD
                                   ,   PAR_H_AR_VM_HIST.CITY_LN                                                                                   AS T_CITY_LN
                                   ,   NULL                                                                                                       AS T_SCORE_VALUE
                                   ,   NULL                                                                                                       AS T_SCORE_THRESHOLD
                                   ,   NULL                                                                                                       AS T_SCORE_IN
                                   ,   PAR_H_AR_VM_HIST.TAC_ID                                                                                    AS T_TAC_ID
                                   ,   PAR_H_AR_VM_HIST.IMEI_CD                                                                                   AS T_IMEI_CD
                                   ,   PAR_H_AR_VM_HIST.IMSI_CD                                                                                   AS T_IMSI_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_INT_RESULT_ERR                                                                    AS T_IND_INT_RESULT_ERR
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.IND_TECH_DMC_COH_DOMAIN                                                               AS T_IND_DMC_COH_DOMAIN
                                      -- ETAT DE LA LIGNE A L'INSTANT DU TRACAGE EST PRIVILEGIE
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT >=  PAR_H_AR_VM_HIST.VAL_START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT <   PAR_H_AR_VM_HIST.VAL_END_DT
                                            THEN ${P_PIL_350}
                                            ELSE 0
                                       END                                                                                                        AS T_IND_TECH_A
                                      -- DETERMINATION DE LA TYPOLOGIE D'ECART ENTRE LA DATE DU TRACAGE ET LA DATE DE DEBUT D'APPLICATION DMC
                                   ,   CASE T_IND_TECH_A WHEN ${P_PIL_350}
                                                         THEN ${P_PIL_350}
                                                         ELSE ${P_PIL_351}
                                       END                                                                                                        AS T_IND_TECH_DMC_THRESHOLD_TYPE
                                      -- DETERMINATION DE L'ECART ENTRE LA DATE DU TRACAGE ET LE DEBUT DE VALIDITE DE LA LIGNE DMC CONSIDEREE
                                   ,   CASE T_IND_TECH_A WHEN ${P_PIL_350}
                                                         THEN ${P_PIL_353}
                                                         ELSE
                                                         CASE WHEN (PAR_H_AR_VM_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT) > 120
                                                              THEN 120
                                                              ELSE PAR_H_AR_VM_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT
                                                         END
                                       END                                                                                                        AS T_IND_TECH_DMC_THRESHOLD 
                                      -- DETERMINATION DE LA CORRESPONDANCE ENTRE LA DATE DU TRACAGE ET LA PERIODE FONCTIONNELLE DE VALIDITE DE LA LIGNE 
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT >=  PAR_H_AR_VM_HIST.START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT <   PAR_H_AR_VM_HIST.END_DT
                                            THEN ${P_PIL_350}
                                            WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT < PAR_H_AR_VM_HIST.START_DT
                                            THEN ${P_PIL_351}
                                            ELSE ${P_PIL_352}
                                       END                                                                                                        AS T_IND_DMC_THRESHOLD_TYPE
                                   ,   CASE T_IND_DMC_THRESHOLD_TYPE  WHEN ${P_PIL_350}
                                                                      THEN ${P_PIL_353}
                                                                      WHEN ${P_PIL_351}
                                                                      THEN PAR_H_AR_VM_HIST.START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT
                                                                      ELSE INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_HIST.END_DT
                                       END                                                                                                        AS T_IND_DMC_THRESHOLD
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_VMTIERS_THRES_T
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_VMTIERS_THRES
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_TERMNTN_DUP    
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_TERMNTN_THRES_T
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_TERMNTN_THRES
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_ADRSS_DUP      
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_ADRSS_THRES_T  
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_ADRSS_THRES  
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_KNB_AS_DUP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.RUN_ID                                                                                AS T_RUN_ID
                    FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG
                    JOIN             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC
                    ON                 INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                               =         INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.EXTERNAL_ACTE_ID            
                    JOIN             ${KNB_DMC_VM_V}.PAR_H_AR_VM_HIST                                                                                PAR_H_AR_VM_HIST
                    ON                 1                                                                                                   =         1
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC._LINE_ID                                                                       =         PAR_H_AR_VM_HIST.LINE_ID
                     --
                     --
                    WHERE              1                                                                                                   =         1
                  -- SELECTION DES SEULES LIGNES INTERNET
                    AND                PAR_H_AR_VM_HIST.LINE_TYPE                                                                          =      '${P_PIL_308}'
                  -- SELECTION DES SEULS TRACAGES POUR LESQUELS L'ACCES RESEAU EST VALORISE AVEC L'AID BSS
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_RES_VALUE_DS_TYPE                                                          =         1
                  -- SELECTION DE L'ETAT DE LA LIGNE DMC CORRESPONDANT AUTANT QUE POSSIBLE A LA DATE DU TRACAGE
                    QUALIFY            ROW_NUMBER() OVER (
                                                           PARTITION BY INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID
                                                           ORDER BY     T_IND_TECH_A DESC
                                                         )                                                                                 =         1
                    
                  ) T (
                        T_ACTE_ID
                      , T_EXTERNAL_ACTE_ID
                      , T_TYPE_SOURCE_ID
                      , T_INT_ID
                      , T_INT_DETL_ID
                      , T_INT_TYPE
                      , T_INT_CREATED_BY_TS
                      , T_INT_CREATED_BY_DT
                      , T_INT_SRC
                      , T_INT_RESULT
                      , T_INT_REASON
                      , T_INT_DETL_SRC
                      , T_DRK_PARTY_ID
                      , T_FREG_PARTY_ID
                      , T_EUREKA_PARTY_ID
                      , T_PAR_PARC_CD
                      , T_PAR_WKNESS_SCO
                      , T_PAR_STORE_CD
                      , T_REM_CHANNEL_CD
                      , T_ORG_REM_CHANNEL_CD
                      , T_ORG_CHANNEL_CD
                      , T_ORG_SUB_CHANNEL_CD
                      , T_ORG_SUB_SUB_CHANNEL_CD
                      , T_ACTIVITY_CD
                      , T_ORG_GT_ACTIVITY      
                      , T_ORG_FIDELISATION     
                      , T_ORG_WEB_ACTIVITY     
                      , T_ORG_AUTO_ACTIVITY    
                      , T_ORG_EDO_ID           
                      , T_ORG_EDO_DS           
                      , T_ORG_TYPE_EDO         
                      , T_ORG_FLAG_PLT_CONV    
                      , T_ORG_FLAG_TEAM_MKT    
                      , T_ORG_FLAG_TYPE_CMP    
                      , T_ORG_EDO_FATHR_ID_NIV1
                      , T_ORG_EDO_FATHR_DS_NIV1
                      , T_ORG_EDO_FATHR_ID_NIV2
                      , T_ORG_EDO_FATHR_DS_NIV2
                      , T_ORG_EDO_FATHR_ID_NIV3
                      , T_ORG_EDO_FATHR_DS_NIV3
                      , T_AUTO_ACTIVITY_IN
                      , T_ORG_TEAM_TYPE_ID
                      , T_AGENT_LOGIN_CD
                      , T_AGENT_FIRST_NAME
                      , T_AGENT_LAST_NAME
                      , T_EXTERNAL_TEAM_CD
                      , T_EXTERNAL_TEAM_NM
                      , T_O3_ACTIVE_TEAM_CD
                      , T_O3_RATTACHEMENT_TEAM_CD
                      , T_INT_DETL_HABLT
                      , T_INT_CANAL_VENTE
                      , T_ORG_CANAL_ID
                      , T_ID_FACADE
                      , T_EXTERNAL_PRODUCT_ID_FINAL
                      , T_EXTERNAL_GAM_PRODUCT_ID
                      , T_IND_GAM_TYPE
                      , T_NEW_OC_OCATID
                      , T_OLD_OC_OCATID
                      , T_LINE_ID
                      , T_MASTER_LINE_ID
                      , T_LINE_TYPE
                      , T_LINE_START_DT
                      , T_OPERATOR_PROVIDER_ID
                      , T_SERVICE_ACCESS_ID
                      , T_BUSINESS_OFFER_BEGIN_DT
                      , T_PARTY_KNB_ID
                      , T_TERMINTN_VALUE_DS
                      , T_EXTERNAL_SYSTEM_ID
                      , T_EXTERNAL_PARTY_ID
                      , T_FREG_PARTY_EXTERNL_ID
                      , T_BSS_PARTY_EXTERNL_ID
                      , T_RES_VALUE_DS
                      , T_UNIFIED_PARTY_ID
                      , T_PARTY_REGRPMNT_ID
                      , T_SIRET_CODE_CD
                      , T_LAST_NAME_NM
                      , T_FIRST_NAME_NM
                      , T_NAME_NM
                      , T_INST_ADDRESS1_NM
                      , T_INST_ADDRESS2_NM
                      , T_INST_ADDRESS3_NM
                      , T_INST_ADDRESS4_NM
                      , T_INST_ADDRESS5_NM
                      , T_INST_ADDRESS6_NM
                      , T_MAIN_ADDRESS1_NM
                      , T_MAIN_ADDRESS2_NM
                      , T_MAIN_ADDRESS3_NM
                      , T_MAIN_ADDRESS4_NM
                      , T_MAIN_ADDRESS5_NM
                      , T_MAIN_ADDRESS6_NM
                      , T_BILL_ADDRESS1_NM
                      , T_BILL_ADDRESS2_NM
                      , T_BILL_ADDRESS3_NM
                      , T_BILL_ADDRESS4_NM
                      , T_BILL_ADDRESS5_NM
                      , T_BILL_ADDRESS6_NM
                      , T_INSEE_NB
                      , T_POSTAL_CD
                      , T_DEPARTMNT_ID
                      , T_PAR_FIBER_IN 
                      , T_PAR_GEO_MACROZONE    
                      , T_PAR_UNIFIED_PARTY_ID 
                      , T_PAR_PARTY_REGRPMNT_ID
                      , T_PAR_IRIS2000_CD
                      , T_PAR_BU_CD
                      , T_CITY_LN
                      , T_SCORE_VALUE
                      , T_SCORE_THRESHOLD
                      , T_SCORE_IN
                      , T_TAC_ID
                      , T_IMEI_CD
                      , T_IMSI_CD
                      , T_IND_INT_RESULT_ERR
                      , T_IND_DMC_COH_DOMAIN
                      , T_IND_TECH_A
                      , T_IND_TECH_DMC_THRESHOLD_TYPE
                      , T_IND_TECH_DMC_THRESHOLD
                      , T_IND_DMC_THRESHOLD_TYPE
                      , T_IND_DMC_THRESHOLD
                      , T_IND_TECH_VMTIERS_THRES_T
                      , T_IND_TECH_VMTIERS_THRES
                      , T_IND_TECH_SOC_TERMNTN_DUP    
                      , T_IND_TECH_SOC_TERMNTN_THRES_T
                      , T_IND_TECH_SOC_TERMNTN_THRES
                      , T_IND_TECH_SOC_ADRSS_DUP      
                      , T_IND_TECH_SOC_ADRSS_THRES_T  
                      , T_IND_TECH_SOC_ADRSS_THRES  
                      , T_IND_TECH_KNB_AS_DUP
                      , T_RUN_ID
                     )
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- MISE A JOUR DES SCORES

UPDATE ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
FROM              (
                    SELECT             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID                                                               AS T_ACTE_ID
                                     , PAR_H_AR_VM_CPLT_HIST.SCORE_VALUE_1                                                                        AS T_SCORE_VALUE
                                     , NULL                                                                                                       AS T_SCORE_THRESHOLD
                                     , PAR_H_AR_VM_CPLT_HIST.SCORE_TRESHOLD_1                                                                     AS T_SCORE_IN                                                 
                                     , CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT >=  PAR_H_AR_VM_CPLT_HIST.VAL_START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT <   PAR_H_AR_VM_CPLT_HIST.VAL_END_DT
                                            THEN ${P_PIL_350}
                                            ELSE 0
                                       END                                                                                                        AS T_IND_TECH_A
                    FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG
                    JOIN             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC
                    ON                 INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                               =         INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.EXTERNAL_ACTE_ID
                    JOIN             ${KNB_DMC_VM_V}.PAR_H_AR_VM_CPLT_HIST                                                                           PAR_H_AR_VM_CPLT_HIST
                    ON                 1                                                                                                   =         1
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC._LINE_ID                                                                       =         PAR_H_AR_VM_CPLT_HIST.LINE_ID
                    WHERE              1                                                                                                   =         1
                  -- SELECTION DES SEULES LIGNES INTERNET
                    AND                PAR_H_AR_VM_CPLT_HIST.LINE_TYPE                                                                     =      '${P_PIL_308}'
                  -- SELECTION DES SEULS TRACAGES POUR LESQUELS L'ACCES RESEAU EST VALORISE AVEC L'AID BSS
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_RES_VALUE_DS_TYPE                                                          =         1
                  -- SELECTION DE L'ETAT DE LA LIGNE DMC CORRESPONDANT AUTANT QUE POSSIBLE A LA DATE DU TRACAGE
                    QUALIFY            ROW_NUMBER() OVER (
                                                           PARTITION BY INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID
                                                           ORDER BY     T_IND_TECH_A DESC
                                                         )                                                                                 =         1
                  ) T (
                         T_ACTE_ID
                       , T_SCORE_VALUE
                       , T_SCORE_THRESHOLD
                       , T_SCORE_IN
                       , T_IND_TECH_A
                      )
SET                SCORE_VALUE         =         T.T_SCORE_VALUE
                 , SCORE_THRESHOLD     =         T.T_SCORE_THRESHOLD
                 , SCORE_IN            =         T.T_SCORE_IN
WHERE              1                   =         1
AND                ACTE_ID             =         T.T_ACTE_ID
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
-- PERIMETRE DES TRACAGES ASSOCIES A UN ACCES RESEAU VALORISE AVEC LE NDS ET AYANT UNE CORRESPONDANCE SUR LE DOMAINE LIGNE INTERNET
                  (
                    ACTE_ID
                  , EXTERNAL_ACTE_ID
                  , TYPE_SOURCE_ID
                  , INT_ID
                  , INT_DETL_ID
                  , INT_TYPE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , INT_SRC
                  , INT_REASON
                  , INT_RESULT
                  , INT_DETL_SRC
                  , DRK_PARTY_ID
                  , FREG_PARTY_ID
                  , EUREKA_PARTY_ID
                  , PAR_PARC_CD
                  , PAR_WKNESS_SCO
                  , PAR_STORE_CD
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD
                  , ORG_CHANNEL_CD
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY               
                  , ORG_FIDELISATION              
                  , ORG_WEB_ACTIVITY              
                  , ORG_AUTO_ACTIVITY             
                  , ORG_EDO_ID                    
                  , ORG_EDO_DS                    
                  , ORG_TYPE_EDO                  
                  , ORG_FLAG_PLT_CONV             
                  , ORG_FLAG_TEAM_MKT             
                  , ORG_FLAG_TYPE_CMP             
                  , ORG_EDO_FATHR_ID_NIV1         
                  , ORG_EDO_FATHR_DS_NIV1         
                  , ORG_EDO_FATHR_ID_NIV2         
                  , ORG_EDO_FATHR_DS_NIV2         
                  , ORG_EDO_FATHR_ID_NIV3         
                  , ORG_EDO_FATHR_DS_NIV3         
                  , AUTO_ACTIVITY_IN
                  , ORG_TEAM_TYPE_ID     
                  , AGENT_LOGIN_CD
                  , AGENT_FIRST_NAME
                  , AGENT_LAST_NAME
                  , EXTERNAL_TEAM_CD
                  , EXTERNAL_TEAM_NM
                  , O3_ACTIVE_TEAM_CD
                  , O3_RATTACHEMENT_TEAM_CD
                  , INT_DETL_HABLT
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID
                  , ID_FACADE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , EXTERNAL_GAM_PRODUCT_ID
                  , IND_GAM_TYPE
                  , NEW_OC_OCATID
                  , OLD_OC_OCATID
                  , LINE_ID
                  , MASTER_LINE_ID
                  , LINE_TYPE
                  , LINE_START_DT
                  , OPERATOR_PROVIDER_ID
                  , SERVICE_ACCESS_ID
                  , BUSINESS_OFFER_BEGIN_DT
                  , PARTY_KNB_ID
                  , TERMINTN_VALUE_DS
                  , EXTERNAL_SYSTEM_ID
                  , EXTERNAL_PARTY_ID
                  , FREG_PARTY_EXTERNL_ID
                  , BSS_PARTY_EXTERNL_ID
                  , RES_VALUE_DS
                  , UNIFIED_PARTY_ID
                  , PARTY_REGRPMNT_ID
                  , SIRET_CODE_CD
                  , LAST_NAME_NM
                  , FIRST_NAME_NM
                  , NAME_NM
                  , INST_ADDRESS1_NM
                  , INST_ADDRESS2_NM
                  , INST_ADDRESS3_NM
                  , INST_ADDRESS4_NM
                  , INST_ADDRESS5_NM
                  , INST_ADDRESS6_NM
                  , MAIN_ADDRESS1_NM
                  , MAIN_ADDRESS2_NM
                  , MAIN_ADDRESS3_NM
                  , MAIN_ADDRESS4_NM
                  , MAIN_ADDRESS5_NM
                  , MAIN_ADDRESS6_NM
                  , BILL_ADDRESS1_NM
                  , BILL_ADDRESS2_NM
                  , BILL_ADDRESS3_NM
                  , BILL_ADDRESS4_NM
                  , BILL_ADDRESS5_NM
                  , BILL_ADDRESS6_NM
                  , INSEE_NB
                  , POSTAL_CD
                  , DEPARTMNT_ID
                  , PAR_FIBER_IN
                  , PAR_GEO_MACROZONE    
                  , PAR_UNIFIED_PARTY_ID 
                  , PAR_PARTY_REGRPMNT_ID
                  , PAR_IRIS2000_CD
                  , PAR_BU_CD
                  , CITY_LN
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE          
                  , IND_TECH_DMC_THRESHOLD      
                  , IND_DMC_THRESHOLD_TYPE      
                  , IND_DMC_THRESHOLD           
                  , IND_TECH_VMTIERS_THRES_T
                  , IND_TECH_VMTIERS_THRES           
                  , IND_TECH_SOC_TERMNTN_DUP    
                  , IND_TECH_SOC_TERMNTN_THRES_T
                  , IND_TECH_SOC_TERMNTN_THRES  
                  , IND_TECH_SOC_ADRSS_DUP      
                  , IND_TECH_SOC_ADRSS_THRES_T  
                  , IND_TECH_SOC_ADRSS_THRES    
                  , IND_TECH_KNB_AS_DUP
                  , RUN_ID         
                  )
SELECT             T.T_ACTE_ID                      AS ACTE_ID
                 , T.T_EXTERNAL_ACTE_ID             AS EXTERNAL_ACTE_ID
                 , T.T_TYPE_SOURCE_ID               AS TYPE_SOURCE_ID
                 , T.T_INT_ID                       AS INT_ID
                 , T.T_INT_DETL_ID                  AS INT_DETL_ID
                 , T.T_INT_TYPE                     AS INT_TYPE
                 , T.T_INT_CREATED_BY_TS            AS INT_CREATED_BY_TS
                 , T.T_INT_CREATED_BY_DT            AS INT_CREATED_BY_DT
                 , T.T_INT_SRC                      AS INT_SRC
                 , T.T_INT_RESULT                   AS INT_RESULT
                 , T.T_INT_REASON                   AS INT_REASON
                 , T.T_INT_DETL_SRC                 AS INT_DETL_SRC
                 , T.T_DRK_PARTY_ID                 AS DRK_PARTY_ID
                 , T.T_FREG_PARTY_ID                AS FREG_PARTY_ID
                 , T.T_EUREKA_PARTY_ID              AS EUREKA_PARTY_ID
                 , T.T_PAR_PARC_CD                  AS PAR_PARC_CD
                 , T.T_PAR_WKNESS_SCO               AS PAR_WKNESS_SCO
                 , T.T_PAR_STORE_CD                 AS PAR_STORE_CD
                 , T.T_REM_CHANNEL_CD               AS REM_CHANNEL_CD
                 , T.T_ORG_REM_CHANNEL_CD           AS ORG_REM_CHANNEL_CD
                 , T.T_ORG_CHANNEL_CD               AS ORG_CHANNEL_CD
                 , T.T_ORG_SUB_CHANNEL_CD           AS ORG_SUB_CHANNEL_CD
                 , T.T_ORG_SUB_SUB_CHANNEL_CD       AS ORG_SUB_SUB_CHANNEL_CD
                 , T.T_ACTIVITY_CD                  AS ACTIVITY_CD
                 , T.T_ORG_GT_ACTIVITY              AS ORG_GT_ACTIVITY      
                 , T.T_ORG_FIDELISATION             AS ORG_FIDELISATION     
                 , T.T_ORG_WEB_ACTIVITY             AS ORG_WEB_ACTIVITY     
                 , T.T_ORG_AUTO_ACTIVITY            AS ORG_AUTO_ACTIVITY    
                 , T.T_ORG_EDO_ID                   AS ORG_EDO_ID           
                 , T.T_ORG_EDO_DS                   AS ORG_EDO_DS           
                 , T.T_ORG_TYPE_EDO                 AS ORG_TYPE_EDO         
                 , T.T_ORG_FLAG_PLT_CONV            AS ORG_FLAG_PLT_CONV    
                 , T.T_ORG_FLAG_TEAM_MKT            AS ORG_FLAG_TEAM_MKT    
                 , T.T_ORG_FLAG_TYPE_CMP            AS ORG_FLAG_TYPE_CMP    
                 , T.T_ORG_EDO_FATHR_ID_NIV1        AS ORG_EDO_FATHR_ID_NIV1
                 , T.T_ORG_EDO_FATHR_DS_NIV1        AS ORG_EDO_FATHR_DS_NIV1
                 , T.T_ORG_EDO_FATHR_ID_NIV2        AS ORG_EDO_FATHR_ID_NIV2
                 , T.T_ORG_EDO_FATHR_DS_NIV2        AS ORG_EDO_FATHR_DS_NIV2
                 , T.T_ORG_EDO_FATHR_ID_NIV3        AS ORG_EDO_FATHR_ID_NIV3
                 , T.T_ORG_EDO_FATHR_DS_NIV3        AS ORG_EDO_FATHR_DS_NIV3
                 , T.T_AUTO_ACTIVITY_IN             AS AUTO_ACTIVITY_IN
                 , T.T_ORG_TEAM_TYPE_ID             AS ORG_TEAM_TYPE_ID     
                 , T.T_AGENT_LOGIN_CD               AS AGENT_LOGIN_CD
                 , T.T_AGENT_FIRST_NAME             AS AGENT_FIRST_NAME
                 , T.T_AGENT_LAST_NAME              AS AGENT_LAST_NAME
                 , T.T_EXTERNAL_TEAM_CD             AS EXTERNAL_TEAM_CD
                 , T.T_EXTERNAL_TEAM_NM             AS EXTERNAL_TEAM_NM
                 , T.T_O3_ACTIVE_TEAM_CD            AS O3_ACTIVE_TEAM_CD
                 , T.T_O3_RATTACHEMENT_TEAM_CD      AS O3_RATTACHEMENT_TEAM_CD
                 , T.T_INT_DETL_HABLT               AS INT_DETL_HABLT
                 , T.T_INT_CANAL_VENTE              AS INT_CANAL_VENTE
                 , T.T_ORG_CANAL_ID                 AS ORG_CANAL_ID
                 , T.T_ID_FACADE                    AS ID_FACADE
                 , T.T_EXTERNAL_PRODUCT_ID_FINAL    AS EXTERNAL_PRODUCT_ID_FINAL
                 , T.T_EXTERNAL_GAM_PRODUCT_ID      AS EXTERNAL_GAM_PRODUCT_ID
                 , T.T_IND_GAM_TYPE                 AS IND_GAM_TYPE
                 , T.T_NEW_OC_OCATID                AS NEW_OC_OCATID
                 , T.T_OLD_OC_OCATID                AS OLD_OC_OCATID
                 , T.T_LINE_ID                      AS LINE_ID
                 , T.T_MASTER_LINE_ID               AS MASTER_LINE_ID
                 , T.T_LINE_TYPE                    AS LINE_TYPE
                 , T.T_LINE_START_DT                AS LINE_START_DT
                 , T.T_OPERATOR_PROVIDER_ID         AS OPERATOR_PROVIDER_ID
                 , T.T_SERVICE_ACCESS_ID            AS SERVICE_ACCESS_ID
                 , T.T_BUSINESS_OFFER_BEGIN_DT      AS BUSINESS_OFFER_BEGIN_DT
                 , T.T_PARTY_KNB_ID                 AS PARTY_KNB_ID
                 , T.T_TERMINTN_VALUE_DS            AS TERMINTN_VALUE_DS
                 , T.T_EXTERNAL_SYSTEM_ID           AS EXTERNAL_SYSTEM_ID
                 , T.T_EXTERNAL_PARTY_ID            AS EXTERNAL_PARTY_ID
                 , T.T_FREG_PARTY_EXTERNL_ID        AS FREG_PARTY_EXTERNL_ID
                 , T.T_BSS_PARTY_EXTERNL_ID         AS BSS_PARTY_EXTERNL_ID
                 , T.T_RES_VALUE_DS                 AS RES_VALUE_DS
                 , T.T_UNIFIED_PARTY_ID             AS UNIFIED_PARTY_ID
                 , T.T_PARTY_REGRPMNT_ID            AS PARTY_REGRPMNT_ID
                 , T.T_SIRET_CODE_CD                AS SIRET_CODE_CD
                 , T.T_LAST_NAME_NM                 AS LAST_NAME_NM
                 , T.T_FIRST_NAME_NM                AS FIRST_NAME_NM
                 , T.T_NAME_NM                      AS NAME_NM
                 , T.T_INST_ADDRESS1_NM             AS INST_ADDRESS1_NM
                 , T.T_INST_ADDRESS2_NM             AS INST_ADDRESS2_NM
                 , T.T_INST_ADDRESS3_NM             AS INST_ADDRESS3_NM
                 , T.T_INST_ADDRESS4_NM             AS INST_ADDRESS4_NM
                 , T.T_INST_ADDRESS5_NM             AS INST_ADDRESS5_NM
                 , T.T_INST_ADDRESS6_NM             AS INST_ADDRESS6_NM
                 , T.T_MAIN_ADDRESS1_NM             AS MAIN_ADDRESS1_NM
                 , T.T_MAIN_ADDRESS2_NM             AS MAIN_ADDRESS2_NM
                 , T.T_MAIN_ADDRESS3_NM             AS MAIN_ADDRESS3_NM
                 , T.T_MAIN_ADDRESS4_NM             AS MAIN_ADDRESS4_NM
                 , T.T_MAIN_ADDRESS5_NM             AS MAIN_ADDRESS5_NM
                 , T.T_MAIN_ADDRESS6_NM             AS MAIN_ADDRESS6_NM
                 , T.T_BILL_ADDRESS1_NM             AS BILL_ADDRESS1_NM
                 , T.T_BILL_ADDRESS2_NM             AS BILL_ADDRESS2_NM
                 , T.T_BILL_ADDRESS3_NM             AS BILL_ADDRESS3_NM
                 , T.T_BILL_ADDRESS4_NM             AS BILL_ADDRESS4_NM
                 , T.T_BILL_ADDRESS5_NM             AS BILL_ADDRESS5_NM
                 , T.T_BILL_ADDRESS6_NM             AS BILL_ADDRESS6_NM
                 , T.T_INSEE_NB                     AS INSEE_NB
                 , T.T_POSTAL_CD                    AS POSTAL_CD
                 , T.T_DEPARTMNT_ID                 AS DEPARTMNT_ID
                 , T.T_PAR_FIBER_IN                 AS PAR_FIBER_IN
                 , T.T_PAR_GEO_MACROZONE            As PAR_GEO_MACROZONE    
                 , T.T_PAR_UNIFIED_PARTY_ID         As PAR_UNIFIED_PARTY_ID 
                 , T.T_PAR_PARTY_REGRPMNT_ID        As PAR_PARTY_REGRPMNT_ID
                 , T.T_PAR_IRIS2000_CD              AS PAR_IRIS2000_CD
                 , T.T_PAR_BU_CD                    AS PAR_BU_CD
                 , T.T_CITY_LN                      AS CITY_LN
                 , T.T_SCORE_VALUE                  AS SCORE_VALUE
                 , T.T_SCORE_THRESHOLD              AS SCORE_THRESHOLD
                 , T.T_SCORE_IN                     AS SCORE_IN
                 , T.T_TAC_ID                       AS TAC_ID
                 , T.T_IMEI_CD                      AS IMEI_CD
                 , T.T_IMSI_CD                      AS IMSI_CD
                 , T.T_IND_INT_RESULT_ERR           AS IND_INT_RESULT_ERR 
                 , T.T_IND_DMC_COH_DOMAIN           AS IND_DMC_COH_DOMAIN
                 , T.T_IND_TECH_DMC_THRESHOLD_TYPE  AS IND_TECH_DMC_THRESHOLD_TYPE          
                 , T.T_IND_TECH_DMC_THRESHOLD       AS IND_TECH_DMC_THRESHOLD      
                 , T.T_IND_DMC_THRESHOLD_TYPE       AS IND_DMC_THRESHOLD_TYPE      
                 , T.T_IND_DMC_THRESHOLD            AS IND_DMC_THRESHOLD           
                 , T.T_IND_TECH_VMTIERS_THRES_T     AS IND_TECH_VMTIERS_THRES_T
                 , T.T_IND_TECH_VMTIERS_THRES       AS IND_TECH_VMTIERS_THRES           
                 , T.T_IND_TECH_SOC_TERMNTN_DUP     AS IND_TECH_SOC_TERMNTN_DUP    
                 , T.T_IND_TECH_SOC_TERMNTN_THRES_T AS IND_TECH_SOC_TERMNTN_THRES_T
                 , T.T_IND_TECH_SOC_TERMNTN_THRES   AS IND_TECH_SOC_TERMNTN_THRES  
                 , T.T_IND_TECH_SOC_ADRSS_DUP       AS IND_TECH_SOC_ADRSS_DUP      
                 , T.T_IND_TECH_SOC_ADRSS_THRES_T   AS IND_TECH_SOC_ADRSS_THRES_T  
                 , T.T_IND_TECH_SOC_ADRSS_THRES     AS IND_TECH_SOC_ADRSS_THRES    
                 , T.T_IND_TECH_KNB_AS_DUP          AS IND_TECH_KNB_AS_DUP
                 , T.T_RUN_ID                       AS RUN_ID         
FROM              (                                    
                    SELECT             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID                                                                               AS T_ACTE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                                      AS T_EXTERNAL_ACTE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.TYPE_SOURCE_ID                                                                        AS T_TYPE_SOURCE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_ID                                                                                AS T_INT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_ID                                                                           AS T_INT_DETL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_INT_TYPE                                                                          AS T_INT_TYPE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_TS                                                                     AS T_INT_CREATED_BY_TS
                                   ,   CAST(INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_TS AS DATE)                                                       AS T_INT_CREATED_BY_DT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_SRC                                                                               AS T_INT_SRC
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_RESULT                                                                            AS T_INT_RESULT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_REASON                                                                            AS T_INT_REASON
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_SRC                                                                          AS T_INT_DETL_SRC
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.DRK_PARTY_ID                                                                          AS T_DRK_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.FREG_PARTY_ID                                                                         AS T_FREG_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EUREKA_PARTY_ID                                                                       AS T_EUREKA_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_PARC_CD                                                                           AS T_PAR_PARC_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_WKNESS_SCO                                                                        AS T_PAR_WKNESS_SCO
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_STORE_CD                                                                          AS T_PAR_STORE_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.REM_CHANNEL_CD                                                                        AS T_REM_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_REM_CHANNEL_CD                                                                    AS T_ORG_REM_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_CHANNEL_CD                                                                        AS T_ORG_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_SUB_CHANNEL_CD                                                                    AS T_ORG_SUB_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_SUB_SUB_CHANNEL_CD                                                                AS T_ORG_SUB_SUB_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ACTIVITY_CD                                                                           AS T_ACTIVITY_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_GT_ACTIVITY                                                                       AS T_ORG_GT_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FIDELISATION                                                                      AS T_ORG_FIDELISATION
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_WEB_ACTIVITY                                                                      AS T_ORG_WEB_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_AUTO_ACTIVITY                                                                     AS T_ORG_AUTO_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_ID                                                                            AS T_ORG_EDO_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_DS                                                                            AS T_ORG_EDO_DS
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_TYPE_EDO                                                                          AS T_ORG_TYPE_EDO
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_PLT_CONV                                                                     AS T_ORG_FLAG_PLT_CONV
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_TEAM_MKT                                                                     AS T_ORG_FLAG_TEAM_MKT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_TYPE_CMP                                                                     AS T_ORG_FLAG_TYPE_CMP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV1                                                                 AS T_ORG_EDO_FATHR_ID_NIV1
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV1                                                                 AS T_ORG_EDO_FATHR_DS_NIV1
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV2                                                                 AS T_ORG_EDO_FATHR_ID_NIV2
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV2                                                                 AS T_ORG_EDO_FATHR_DS_NIV2
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV3                                                                 AS T_ORG_EDO_FATHR_ID_NIV3
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV3                                                                 AS T_ORG_EDO_FATHR_DS_NIV3
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AUTO_ACTIVITY_IN                                                                      AS T_AUTO_ACTIVITY_IN
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_TEAM_TYPE_ID                                                                      AS T_ORG_TEAM_TYPE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_LOGIN_CD                                                                        AS T_AGENT_LOGIN_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_FIRST_NAME                                                                      AS T_AGENT_FIRST_NAME
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_LAST_NAME                                                                       AS T_AGENT_LAST_NAME
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_TEAM_CD                                                                      AS T_EXTERNAL_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_TEAM_NM                                                                      AS T_EXTERNAL_TEAM_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.O3_ACTIVE_TEAM_CD                                                                     AS T_O3_ACTIVE_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.O3_RATTACHEMENT_TEAM_CD                                                               AS T_O3_RATTACHEMENT_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_HABLT                                                                        AS T_INT_DETL_HABLT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CANAL_VENTE                                                                       AS T_INT_CANAL_VENTE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_CANAL_ID                                                                          AS T_ORG_CANAL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ID_FACADE                                                                             AS T_ID_FACADE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_PRODUCT_ID_FINAL                                                             AS T_EXTERNAL_PRODUCT_ID_FINAL
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_GAM_PRODUCT_ID                                                               AS T_EXTERNAL_GAM_PRODUCT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_GAM_TYPE                                                                          AS T_IND_GAM_TYPE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.NEW_OC_OCATID                                                                         AS T_NEW_OC_OCATID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.OLD_OC_OCATID                                                                         AS T_OLD_OC_OCATID
                                   ,   PAR_H_AR_VM_HIST.LINE_ID                                                                                   AS T_LINE_ID
                                   ,   PAR_H_AR_VM_HIST.MASTER_LINE_ID                                                                            AS T_MASTER_LINE_ID
                                   ,   PAR_H_AR_VM_HIST.LINE_TYPE                                                                                 AS T_LINE_TYPE
                                   ,   PAR_H_AR_VM_HIST.START_DT                                                                                  AS T_LINE_START_DT
                                   ,   PAR_H_AR_VM_HIST.OPERATOR_PROVIDER_ID                                                                      AS T_OPERATOR_PROVIDER_ID
                                   ,   PAR_H_AR_VM_HIST.SERVICE_ACCESS_ID                                                                         AS T_SERVICE_ACCESS_ID
                                   ,   PAR_H_AR_VM_HIST.BUSINESS_OFFER_BEGIN_DT                                                                   AS T_BUSINESS_OFFER_BEGIN_DT
                                   ,   PAR_H_AR_VM_HIST.PARTY_KNB_ID                                                                              AS T_PARTY_KNB_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.RES_VALUE_DS                                                          AS T_TERMINTN_VALUE_DS
                                   ,   PAR_H_AR_VM_HIST.EXTERNAL_SYSTEM_ID                                                                        AS T_EXTERNAL_SYSTEM_ID
                                   ,   PAR_H_AR_VM_HIST.EXTERNAL_PARTY_ID                                                                         AS T_EXTERNAL_PARTY_ID
                                   ,   PAR_H_AR_VM_HIST.FREG_PARTY_EXTERNL_ID                                                                     AS T_FREG_PARTY_EXTERNL_ID
                                   ,   PAR_H_AR_VM_HIST.BSS_PARTY_EXTERNL_ID                                                                      AS T_BSS_PARTY_EXTERNL_ID
                                   ,   PAR_H_AR_VM_HIST.RES_VALUE_DS                                                                              AS T_RES_VALUE_DS
                                   ,   PAR_H_AR_VM_HIST.UNIFIED_PARTY_ID                                                                          AS T_UNIFIED_PARTY_ID
                                   ,   PAR_H_AR_VM_HIST.PARTY_REGRPMNT_ID                                                                         AS T_PARTY_REGRPMNT_ID
                                   ,   PAR_H_AR_VM_HIST.SIRET_CODE_CD                                                                             AS T_SIRET_CODE_CD
                                   ,   PAR_H_AR_VM_HIST.LAST_NAME_NM                                                                              AS T_LAST_NAME_NM
                                   ,   PAR_H_AR_VM_HIST.FIRST_NAME_NM                                                                             AS T_FIRST_NAME_NM
                                   ,   PAR_H_AR_VM_HIST.NAME_NM                                                                                   AS T_NAME_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS1_NM                                                                          AS T_INST_ADDRESS1_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS2_NM                                                                          AS T_INST_ADDRESS2_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS3_NM                                                                          AS T_INST_ADDRESS3_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS4_NM                                                                          AS T_INST_ADDRESS4_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS5_NM                                                                          AS T_INST_ADDRESS5_NM
                                   ,   PAR_H_AR_VM_HIST.INST_ADDRESS6_NM                                                                          AS T_INST_ADDRESS6_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS1_NM                                                                          AS T_MAIN_ADDRESS1_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS2_NM                                                                          AS T_MAIN_ADDRESS2_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS3_NM                                                                          AS T_MAIN_ADDRESS3_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS4_NM                                                                          AS T_MAIN_ADDRESS4_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS5_NM                                                                          AS T_MAIN_ADDRESS5_NM
                                   ,   PAR_H_AR_VM_HIST.MAIN_ADDRESS6_NM                                                                          AS T_MAIN_ADDRESS6_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS1_NM                                                                          AS T_BILL_ADDRESS1_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS2_NM                                                                          AS T_BILL_ADDRESS2_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS3_NM                                                                          AS T_BILL_ADDRESS3_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS4_NM                                                                          AS T_BILL_ADDRESS4_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS5_NM                                                                          AS T_BILL_ADDRESS5_NM
                                   ,   PAR_H_AR_VM_HIST.BILL_ADDRESS6_NM                                                                          AS T_BILL_ADDRESS6_NM
                                   ,   PAR_H_AR_VM_HIST.INSEE_NB                                                                                  AS T_INSEE_NB
                                   ,   PAR_H_AR_VM_HIST.POSTAL_CD                                                                                 AS T_POSTAL_CD
                                   ,   PAR_H_AR_VM_HIST.DEPRTMNT_ID                                                                               AS T_DEPARTMNT_ID
                                   ,   NULL                                                                                                       AS T_PAR_FIBER_IN 
                                   ,   Null                                                                                                       AS T_PAR_GEO_MACROZONE    
                                   ,   Null                                                                                                       AS T_PAR_UNIFIED_PARTY_ID 
                                   ,   Null                                                                                                       AS T_PAR_PARTY_REGRPMNT_ID
                                   ,   NULL                                                                                                       AS T_PAR_IRIS2000_CD                                
                                   ,   NULL                                                                                                       AS T_PAR_BU_CD      
                                   ,   PAR_H_AR_VM_HIST.CITY_LN                                                                                   AS T_CITY_LN
                                   ,   NULL                                                                                                       AS T_SCORE_VALUE
                                   ,   NULL                                                                                                       AS T_SCORE_THRESHOLD
                                   ,   NULL                                                                                                       AS T_SCORE_IN
                                   ,   PAR_H_AR_VM_HIST.TAC_ID                                                                                    AS T_TAC_ID
                                   ,   PAR_H_AR_VM_HIST.IMEI_CD                                                                                   AS T_IMEI_CD
                                   ,   PAR_H_AR_VM_HIST.IMSI_CD                                                                                   AS T_IMSI_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_INT_RESULT_ERR                                                    AS T_IND_INT_RESULT_ERR
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.IND_TECH_DMC_COH_DOMAIN                                               AS T_IND_DMC_COH_DOMAIN
                                      -- ETAT DE LA LIGNE A L'INSTANT DU TRACAGE EST PRIVILEGIE
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT >=  PAR_H_AR_VM_HIST.VAL_START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT <   PAR_H_AR_VM_HIST.VAL_END_DT
                                            THEN ${P_PIL_350}
                                            ELSE 0
                                       END                                                                                                        AS T_IND_TECH_A
                                      -- DETERMINATION DE LA TYPOLOGIE D'ECART ENTRE LA DATE DU TRACAGE ET LA DATE DE DEBUT D'APPLICATION DMC
                                   ,   CASE T_IND_TECH_A WHEN ${P_PIL_350}
                                                         THEN ${P_PIL_350}
                                                         ELSE CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT < PAR_H_AR_VM_HIST.VAL_START_DT
                                                                   THEN ${P_PIL_351}
                                                                   ELSE ${P_PIL_352}
                                                              END 
                                       END                                                                                                        AS T_IND_TECH_DMC_THRESHOLD_TYPE
                                      -- DETERMINATION DE L'ECART ENTRE LA DATE DU TRACAGE ET LE DEBUT DE VALIDITE DE LA LIGNE DMC CONSIDEREE
                                   ,   CASE T_IND_TECH_A WHEN ${P_PIL_350}
                                                         THEN ${P_PIL_353}
                                                         ELSE CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT < PAR_H_AR_VM_HIST.VAL_START_DT
                                                                   THEN CASE WHEN (PAR_H_AR_VM_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT) > 120
                                                                        THEN 120
                                                                        ELSE PAR_H_AR_VM_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT
                                                                        END
                                                                   ELSE
                                                                       CASE WHEN (INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_HIST.VAL_END_DT) > 120
                                                                       THEN 120
                                                                       ELSE INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_HIST.VAL_END_DT
                                                                       END
                                                              END  
                                       END                                                                                                        AS T_IND_TECH_DMC_THRESHOLD
                                      -- DETERMINATION DE LA CORRESPONDANCE ENTRE LA DATE DU TRACAGE ET LA PERIODE DE VALIDITE DE LA LIGNE 
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT >=  PAR_H_AR_VM_HIST.START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT <   PAR_H_AR_VM_HIST.END_DT
                                            THEN ${P_PIL_350}
                                            WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT < PAR_H_AR_VM_HIST.START_DT
                                            THEN ${P_PIL_351}
                                            ELSE ${P_PIL_352}
                                       END                                                                                                        AS T_IND_DMC_THRESHOLD_TYPE
                                   ,   CASE T_IND_DMC_THRESHOLD_TYPE  WHEN ${P_PIL_350}
                                                                      THEN ${P_PIL_353}
                                                                      WHEN ${P_PIL_351}
                                                                      THEN CASE WHEN (PAR_H_AR_VM_HIST.START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT) > 120
                                                                           THEN 120
                                                                           ELSE PAR_H_AR_VM_HIST.START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT
                                                                           END
                                                                      ELSE CASE WHEN (INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_HIST.END_DT) > 120
                                                                           THEN 120
                                                                           ELSE INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_HIST.END_DT
                                                                           END
                                       END                                                                                                        AS T_IND_DMC_THRESHOLD
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_VMTIERS_THRES_T
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_VMTIERS_THRES
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_TERMNTN_DUP    
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_TERMNTN_THRES_T
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_TERMNTN_THRES
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_ADRSS_DUP      
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_ADRSS_THRES_T  
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_SOC_ADRSS_THRES  
                                   , ${P_PIL_349}                                                                                                 AS T_IND_TECH_KNB_AS_DUP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.RUN_ID                                                                AS T_RUN_ID
                    FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG
                    JOIN             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC
                    ON                 INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                               =         INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.EXTERNAL_ACTE_ID
                    JOIN             ${KNB_DMC_VM_V}.PAR_H_AR_VM_HIST                                                                                PAR_H_AR_VM_HIST
                    ON                 1                                                                                                   =         1
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC._LINE_ID                                                                       =         PAR_H_AR_VM_HIST.LINE_ID
                    WHERE              1                                                                                                   =         1
                  -- SELECTION DES SEULES LIGNES INTERNET
                    AND                PAR_H_AR_VM_HIST.LINE_TYPE                                                                          =      '${P_PIL_308}'
                  -- SELECTION DES SEULS TRACAGES POUR LESQUELS L'ACCES RESEAU EST VALORISE AVEC LE NDS
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_RES_VALUE_DS_TYPE                                                          =         2
                  -- SELECTION DES SEULS TRACAGES AYANT UNE CORRESPONDANCE DANS LE DOMAINE LIGNE INTERNET
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.IND_TECH_2                                                                     =         1
                  -- SELECTION DE L'ETAT DE LA LIGNE DMC CORRESPONDANT AUTANT QUE POSSIBLE A LA DATE DU TRACAGE
                    QUALIFY            ROW_NUMBER() OVER (
                                                           PARTITION BY INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID
                                                           ORDER BY     T_IND_TECH_A DESC
                                                                      , T_IND_TECH_DMC_THRESHOLD ASC
                                                         )                                                                                 =         1
                    
                  ) T (
                        T_ACTE_ID
                      , T_EXTERNAL_ACTE_ID
                      , T_TYPE_SOURCE_ID
                      , T_INT_ID
                      , T_INT_DETL_ID
                      , T_INT_TYPE
                      , T_INT_CREATED_BY_TS
                      , T_INT_CREATED_BY_DT
                      , T_INT_SRC
                      , T_INT_RESULT
                      , T_INT_REASON
                      , T_INT_DETL_SRC
                      , T_DRK_PARTY_ID
                      , T_FREG_PARTY_ID
                      , T_EUREKA_PARTY_ID
                      , T_PAR_PARC_CD
                      , T_PAR_WKNESS_SCO
                      , T_PAR_STORE_CD
                      , T_REM_CHANNEL_CD
                      , T_ORG_REM_CHANNEL_CD
                      , T_ORG_CHANNEL_CD
                      , T_ORG_SUB_CHANNEL_CD
                      , T_ORG_SUB_SUB_CHANNEL_CD
                      , T_ACTIVITY_CD
                      , T_ORG_GT_ACTIVITY      
                      , T_ORG_FIDELISATION     
                      , T_ORG_WEB_ACTIVITY     
                      , T_ORG_AUTO_ACTIVITY    
                      , T_ORG_EDO_ID           
                      , T_ORG_EDO_DS           
                      , T_ORG_TYPE_EDO         
                      , T_ORG_FLAG_PLT_CONV    
                      , T_ORG_FLAG_TEAM_MKT    
                      , T_ORG_FLAG_TYPE_CMP    
                      , T_ORG_EDO_FATHR_ID_NIV1
                      , T_ORG_EDO_FATHR_DS_NIV1
                      , T_ORG_EDO_FATHR_ID_NIV2
                      , T_ORG_EDO_FATHR_DS_NIV2
                      , T_ORG_EDO_FATHR_ID_NIV3
                      , T_ORG_EDO_FATHR_DS_NIV3
                      , T_AUTO_ACTIVITY_IN
                      , T_ORG_TEAM_TYPE_ID
                      , T_AGENT_LOGIN_CD
                      , T_AGENT_FIRST_NAME
                      , T_AGENT_LAST_NAME
                      , T_EXTERNAL_TEAM_CD
                      , T_EXTERNAL_TEAM_NM
                      , T_O3_ACTIVE_TEAM_CD
                      , T_O3_RATTACHEMENT_TEAM_CD
                      , T_INT_DETL_HABLT
                      , T_INT_CANAL_VENTE
                      , T_ORG_CANAL_ID
                      , T_ID_FACADE
                      , T_EXTERNAL_PRODUCT_ID_FINAL
                      , T_EXTERNAL_GAM_PRODUCT_ID
                      , T_IND_GAM_TYPE
                      , T_NEW_OC_OCATID
                      , T_OLD_OC_OCATID
                      , T_LINE_ID
                      , T_MASTER_LINE_ID
                      , T_LINE_TYPE
                      , T_LINE_START_DT
                      , T_OPERATOR_PROVIDER_ID
                      , T_SERVICE_ACCESS_ID
                      , T_BUSINESS_OFFER_BEGIN_DT
                      , T_PARTY_KNB_ID
                      , T_TERMINTN_VALUE_DS
                      , T_EXTERNAL_SYSTEM_ID
                      , T_EXTERNAL_PARTY_ID
                      , T_FREG_PARTY_EXTERNL_ID
                      , T_BSS_PARTY_EXTERNL_ID
                      , T_RES_VALUE_DS
                      , T_UNIFIED_PARTY_ID
                      , T_PARTY_REGRPMNT_ID
                      , T_SIRET_CODE_CD
                      , T_LAST_NAME_NM
                      , T_FIRST_NAME_NM
                      , T_NAME_NM
                      , T_INST_ADDRESS1_NM
                      , T_INST_ADDRESS2_NM
                      , T_INST_ADDRESS3_NM
                      , T_INST_ADDRESS4_NM
                      , T_INST_ADDRESS5_NM
                      , T_INST_ADDRESS6_NM
                      , T_MAIN_ADDRESS1_NM
                      , T_MAIN_ADDRESS2_NM
                      , T_MAIN_ADDRESS3_NM
                      , T_MAIN_ADDRESS4_NM
                      , T_MAIN_ADDRESS5_NM
                      , T_MAIN_ADDRESS6_NM
                      , T_BILL_ADDRESS1_NM
                      , T_BILL_ADDRESS2_NM
                      , T_BILL_ADDRESS3_NM
                      , T_BILL_ADDRESS4_NM
                      , T_BILL_ADDRESS5_NM
                      , T_BILL_ADDRESS6_NM
                      , T_INSEE_NB
                      , T_POSTAL_CD
                      , T_DEPARTMNT_ID
                      , T_PAR_FIBER_IN 
                      , T_PAR_GEO_MACROZONE    
                      , T_PAR_UNIFIED_PARTY_ID 
                      , T_PAR_PARTY_REGRPMNT_ID
                      , T_PAR_IRIS2000_CD
                      , T_PAR_BU_CD
                      , T_CITY_LN
                      , T_SCORE_VALUE
                      , T_SCORE_THRESHOLD
                      , T_SCORE_IN
                      , T_TAC_ID
                      , T_IMEI_CD
                      , T_IMSI_CD
                      , T_IND_INT_RESULT_ERR
                      , T_IND_DMC_COH_DOMAIN
                      , T_IND_TECH_A
                      , T_IND_TECH_DMC_THRESHOLD_TYPE
                      , T_IND_TECH_DMC_THRESHOLD
                      , T_IND_DMC_THRESHOLD_TYPE
                      , T_IND_DMC_THRESHOLD
                      , T_IND_TECH_VMTIERS_THRES_T
                      , T_IND_TECH_VMTIERS_THRES
                      , T_IND_TECH_SOC_TERMNTN_DUP    
                      , T_IND_TECH_SOC_TERMNTN_THRES_T
                      , T_IND_TECH_SOC_TERMNTN_THRES
                      , T_IND_TECH_SOC_ADRSS_DUP      
                      , T_IND_TECH_SOC_ADRSS_THRES_T  
                      , T_IND_TECH_SOC_ADRSS_THRES  
                      , T_IND_TECH_KNB_AS_DUP
                      , T_RUN_ID
                     )
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- MISE A JOUR DES SCORES

UPDATE ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
FROM              (
                    SELECT             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID                                                               AS T_ACTE_ID
                                     , PAR_H_AR_VM_CPLT_HIST.SCORE_VALUE_1                                                                        AS T_SCORE_VALUE
                                     , NULL                                                                                                       AS T_SCORE_THRESHOLD
                                     , PAR_H_AR_VM_CPLT_HIST.SCORE_TRESHOLD_1                                                                     AS T_SCORE_IN                                                 
                                      -- ETAT DE LA LIGNE A L'INSTANT DU TRACAGE EST PRIVILEGIE
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT >=  PAR_H_AR_VM_CPLT_HIST.VAL_START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT <   PAR_H_AR_VM_CPLT_HIST.VAL_END_DT
                                            THEN ${P_PIL_350}
                                            ELSE 0
                                       END                                                                                                        AS T_IND_TECH_A
                                      -- DETERMINATION DE L'ECART ENTRE LA DATE DU TRACAGE ET LE DEBUT DE VALIDITE DE LA LIGNE DMC CONSIDEREE
                                   ,   CASE T_IND_TECH_A WHEN ${P_PIL_350}
                                                         THEN ${P_PIL_353}
                                                         ELSE CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT < PAR_H_AR_VM_CPLT_HIST.VAL_START_DT
                                                                   THEN
                                                                        CASE WHEN (PAR_H_AR_VM_CPLT_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT) > 120
                                                                        THEN 120
                                                                        ELSE PAR_H_AR_VM_CPLT_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT
                                                                        END
                                                                   ELSE
                                                                        CASE WHEN (INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_CPLT_HIST.VAL_END_DT) > 120
                                                                        THEN 120
                                                                        ELSE INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_DT - PAR_H_AR_VM_CPLT_HIST.VAL_END_DT
                                                                        END
                                                              END  
                                       END                                                                                                        AS T_IND_TECH_DMC_THRESHOLD
                    FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG
                    JOIN             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC
                    ON                 INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                               =         INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.EXTERNAL_ACTE_ID
                    JOIN             ${KNB_DMC_VM_V}.PAR_H_AR_VM_CPLT_HIST                                                                           PAR_H_AR_VM_CPLT_HIST
                    ON                 1                                                                                                   =         1
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC._LINE_ID                                                                       =         PAR_H_AR_VM_CPLT_HIST.LINE_ID
                    WHERE              1                                                                                                   =         1
                  -- SELECTION DES SEULES LIGNES INTERNET
                    AND                PAR_H_AR_VM_CPLT_HIST.LINE_TYPE                                                                     =      '${P_PIL_308}'
                  -- SELECTION DES SEULS TRACAGES POUR LESQUELS L'ACCES RESEAU EST VALORISE AVEC LE NDS
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_RES_VALUE_DS_TYPE                                                          =         2
                  -- SELECTION DES SEULS TRACAGES AYANT UNE CORRESPONDANCE DANS LE DOMAINE LIGNE INTERNET
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.IND_TECH_2                                                                     =         1
                  -- SELECTION DE L'ETAT DE LA LIGNE DMC CORRESPONDANT AUTANT QUE POSSIBLE A LA DATE DU TRACAGE
                    QUALIFY            ROW_NUMBER() OVER (
                                                           PARTITION BY INT_W_PLACEMENT_${RFORCE_SUFFIX}_DMC.ACTE_ID
                                                           ORDER BY     T_IND_TECH_A DESC
                                                                      , T_IND_TECH_DMC_THRESHOLD ASC
                                                         )                                                                                 =         1
                  ) T (
                         T_ACTE_ID
                       , T_SCORE_VALUE
                       , T_SCORE_THRESHOLD
                       , T_SCORE_IN
                       , T_IND_TECH_A
                       , T_IND_TECH_DMC_THRESHOLD
                      )
SET                SCORE_VALUE         =         T.T_SCORE_VALUE
                 , SCORE_THRESHOLD     =         T.T_SCORE_THRESHOLD
                 , SCORE_IN            =         T.T_SCORE_IN
WHERE              1                   =         1
AND                ACTE_ID             =         T.T_ACTE_ID
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
-- PERIMETRE DES TRACAGES ASSOCIES A UN ACCES RESEAU VALORISE AVEC LE NDS ET AYANT UNE CORRESPONDANCE SUR LE DOMAINE LIGNE RTC
                  (
                    ACTE_ID
                  , EXTERNAL_ACTE_ID
                  , TYPE_SOURCE_ID
                  , INT_ID
                  , INT_DETL_ID
                  , INT_TYPE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , INT_SRC
                  , INT_REASON
                  , INT_RESULT
                  , INT_DETL_SRC
                  , DRK_PARTY_ID
                  , FREG_PARTY_ID
                  , EUREKA_PARTY_ID
                  , PAR_PARC_CD
                  , PAR_WKNESS_SCO
                  , PAR_STORE_CD
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD
                  , ORG_CHANNEL_CD
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY               
                  , ORG_FIDELISATION              
                  , ORG_WEB_ACTIVITY              
                  , ORG_AUTO_ACTIVITY             
                  , ORG_EDO_ID                    
                  , ORG_EDO_DS                    
                  , ORG_TYPE_EDO                  
                  , ORG_FLAG_PLT_CONV             
                  , ORG_FLAG_TEAM_MKT             
                  , ORG_FLAG_TYPE_CMP             
                  , ORG_EDO_FATHR_ID_NIV1         
                  , ORG_EDO_FATHR_DS_NIV1         
                  , ORG_EDO_FATHR_ID_NIV2         
                  , ORG_EDO_FATHR_DS_NIV2         
                  , ORG_EDO_FATHR_ID_NIV3         
                  , ORG_EDO_FATHR_DS_NIV3         
                  , AUTO_ACTIVITY_IN
                  , ORG_TEAM_TYPE_ID     
                  , AGENT_LOGIN_CD
                  , AGENT_FIRST_NAME
                  , AGENT_LAST_NAME
                  , EXTERNAL_TEAM_CD
                  , EXTERNAL_TEAM_NM
                  , O3_ACTIVE_TEAM_CD
                  , O3_RATTACHEMENT_TEAM_CD
                  , INT_DETL_HABLT
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID
                  , ID_FACADE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , EXTERNAL_GAM_PRODUCT_ID
                  , IND_GAM_TYPE
                  , NEW_OC_OCATID
                  , OLD_OC_OCATID
                  , LINE_ID
                  , MASTER_LINE_ID
                  , LINE_TYPE
                  , LINE_START_DT
                  , OPERATOR_PROVIDER_ID
                  , SERVICE_ACCESS_ID
                  , BUSINESS_OFFER_BEGIN_DT
                  , PARTY_KNB_ID
                  , TERMINTN_VALUE_DS
                  , EXTERNAL_SYSTEM_ID
                  , EXTERNAL_PARTY_ID
                  , FREG_PARTY_EXTERNL_ID
                  , BSS_PARTY_EXTERNL_ID
                  , RES_VALUE_DS
                  , UNIFIED_PARTY_ID
                  , PARTY_REGRPMNT_ID
                  , SIRET_CODE_CD
                  , LAST_NAME_NM
                  , FIRST_NAME_NM
                  , NAME_NM
                  , INST_ADDRESS1_NM
                  , INST_ADDRESS2_NM
                  , INST_ADDRESS3_NM
                  , INST_ADDRESS4_NM
                  , INST_ADDRESS5_NM
                  , INST_ADDRESS6_NM
                  , MAIN_ADDRESS1_NM
                  , MAIN_ADDRESS2_NM
                  , MAIN_ADDRESS3_NM
                  , MAIN_ADDRESS4_NM
                  , MAIN_ADDRESS5_NM
                  , MAIN_ADDRESS6_NM
                  , BILL_ADDRESS1_NM
                  , BILL_ADDRESS2_NM
                  , BILL_ADDRESS3_NM
                  , BILL_ADDRESS4_NM
                  , BILL_ADDRESS5_NM
                  , BILL_ADDRESS6_NM
                  , INSEE_NB
                  , POSTAL_CD
                  , DEPARTMNT_ID
                  , PAR_FIBER_IN
                  , PAR_GEO_MACROZONE    
                  , PAR_UNIFIED_PARTY_ID 
                  , PAR_PARTY_REGRPMNT_ID
                  , PAR_IRIS2000_CD
                  , PAR_BU_CD
                  , CITY_LN
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE          
                  , IND_TECH_DMC_THRESHOLD      
                  , IND_DMC_THRESHOLD_TYPE      
                  , IND_DMC_THRESHOLD           
                  , IND_TECH_VMTIERS_THRES_T
                  , IND_TECH_VMTIERS_THRES           
                  , IND_TECH_SOC_TERMNTN_DUP    
                  , IND_TECH_SOC_TERMNTN_THRES_T
                  , IND_TECH_SOC_TERMNTN_THRES  
                  , IND_TECH_SOC_ADRSS_DUP      
                  , IND_TECH_SOC_ADRSS_THRES_T  
                  , IND_TECH_SOC_ADRSS_THRES    
                  , IND_TECH_KNB_AS_DUP
                  , RUN_ID
                  )
SELECT             T.T_ACTE_ID                      AS ACTE_ID
                 , T.T_EXTERNAL_ACTE_ID             AS EXTERNAL_ACTE_ID
                 , T.T_TYPE_SOURCE_ID               AS TYPE_SOURCE_ID
                 , T.T_INT_ID                       AS INT_ID
                 , T.T_INT_DETL_ID                  AS INT_DETL_ID
                 , T.T_INT_TYPE                     AS INT_TYPE
                 , T.T_INT_CREATED_BY_TS            AS INT_CREATED_BY_TS
                 , T.T_INT_CREATED_BY_DT            AS INT_CREATED_BY_DT
                 , T.T_INT_SRC                      AS INT_SRC
                 , T.T_INT_RESULT                   AS INT_RESULT
                 , T.T_INT_REASON                   AS INT_REASON
                 , T.T_INT_DETL_SRC                 AS INT_DETL_SRC
                 , T.T_DRK_PARTY_ID                 AS DRK_PARTY_ID
                 , T.T_FREG_PARTY_ID                AS FREG_PARTY_ID
                 , T.T_EUREKA_PARTY_ID              AS EUREKA_PARTY_ID
                 , T.T_PAR_PARC_CD                  AS PAR_PARC_CD
                 , T.T_PAR_WKNESS_SCO               AS PAR_WKNESS_SCO
                 , T.T_PAR_STORE_CD                 AS PAR_STORE_CD
                 , T.T_REM_CHANNEL_CD               AS REM_CHANNEL_CD
                 , T.T_ORG_REM_CHANNEL_CD           AS ORG_REM_CHANNEL_CD
                 , T.T_ORG_CHANNEL_CD               AS ORG_CHANNEL_CD
                 , T.T_ORG_SUB_CHANNEL_CD           AS ORG_SUB_CHANNEL_CD
                 , T.T_ORG_SUB_SUB_CHANNEL_CD       AS ORG_SUB_SUB_CHANNEL_CD
                 , T.T_ACTIVITY_CD                  AS ACTIVITY_CD
                 , T.T_ORG_GT_ACTIVITY              AS ORG_GT_ACTIVITY      
                 , T.T_ORG_FIDELISATION             AS ORG_FIDELISATION     
                 , T.T_ORG_WEB_ACTIVITY             AS ORG_WEB_ACTIVITY     
                 , T.T_ORG_AUTO_ACTIVITY            AS ORG_AUTO_ACTIVITY    
                 , T.T_ORG_EDO_ID                   AS ORG_EDO_ID           
                 , T.T_ORG_EDO_DS                   AS ORG_EDO_DS           
                 , T.T_ORG_TYPE_EDO                 AS ORG_TYPE_EDO         
                 , T.T_ORG_FLAG_PLT_CONV            AS ORG_FLAG_PLT_CONV    
                 , T.T_ORG_FLAG_TEAM_MKT            AS ORG_FLAG_TEAM_MKT    
                 , T.T_ORG_FLAG_TYPE_CMP            AS ORG_FLAG_TYPE_CMP    
                 , T.T_ORG_EDO_FATHR_ID_NIV1        AS ORG_EDO_FATHR_ID_NIV1
                 , T.T_ORG_EDO_FATHR_DS_NIV1        AS ORG_EDO_FATHR_DS_NIV1
                 , T.T_ORG_EDO_FATHR_ID_NIV2        AS ORG_EDO_FATHR_ID_NIV2
                 , T.T_ORG_EDO_FATHR_DS_NIV2        AS ORG_EDO_FATHR_DS_NIV2
                 , T.T_ORG_EDO_FATHR_ID_NIV3        AS ORG_EDO_FATHR_ID_NIV3
                 , T.T_ORG_EDO_FATHR_DS_NIV3        AS ORG_EDO_FATHR_DS_NIV3
                 , T.T_AUTO_ACTIVITY_IN             AS AUTO_ACTIVITY_IN
                 , T.T_ORG_TEAM_TYPE_ID             AS ORG_TEAM_TYPE_ID
                 , T.T_AGENT_LOGIN_CD               AS AGENT_LOGIN_CD
                 , T.T_AGENT_FIRST_NAME             AS AGENT_FIRST_NAME
                 , T.T_AGENT_LAST_NAME              AS AGENT_LAST_NAME
                 , T.T_EXTERNAL_TEAM_CD             AS EXTERNAL_TEAM_CD
                 , T.T_EXTERNAL_TEAM_NM             AS EXTERNAL_TEAM_NM
                 , T.T_O3_ACTIVE_TEAM_CD            AS O3_ACTIVE_TEAM_CD
                 , T.T_O3_RATTACHEMENT_TEAM_CD      AS O3_RATTACHEMENT_TEAM_CD
                 , T.T_INT_DETL_HABLT               AS INT_DETL_HABLT
                 , T.T_INT_CANAL_VENTE              AS INT_CANAL_VENTE
                 , T.T_ORG_CANAL_ID                 AS ORG_CANAL_ID
                 , T.T_ID_FACADE                    AS ID_FACADE
                 , T.T_EXTERNAL_PRODUCT_ID_FINAL    AS EXTERNAL_PRODUCT_ID_FINAL
                 , T.T_EXTERNAL_GAM_PRODUCT_ID      AS EXTERNAL_GAM_PRODUCT_ID
                 , T.T_IND_GAM_TYPE                 AS IND_GAM_TYPE
                 , T.T_NEW_OC_OCATID                AS NEW_OC_OCATID
                 , T.T_OLD_OC_OCATID                AS OLD_OC_OCATID
                 , T.T_LINE_ID                      AS LINE_ID
                 , T.T_MASTER_LINE_ID               AS MASTER_LINE_ID
                 , T.T_LINE_TYPE                    AS LINE_TYPE
                 , T.T_LINE_START_DT                AS LINE_START_DT
                 , T.T_OPERATOR_PROVIDER_ID         AS OPERATOR_PROVIDER_ID
                 , T.T_SERVICE_ACCESS_ID            AS SERVICE_ACCESS_ID
                 , T.T_BUSINESS_OFFER_BEGIN_DT      AS BUSINESS_OFFER_BEGIN_DT
                 , T.T_PARTY_KNB_ID                 AS PARTY_KNB_ID
                 , T.T_TERMINTN_VALUE_DS            AS TERMINTN_VALUE_DS
                 , T.T_EXTERNAL_SYSTEM_ID           AS EXTERNAL_SYSTEM_ID
                 , T.T_EXTERNAL_PARTY_ID            AS EXTERNAL_PARTY_ID
                 , T.T_FREG_PARTY_EXTERNL_ID        AS FREG_PARTY_EXTERNL_ID
                 , T.T_BSS_PARTY_EXTERNL_ID         AS BSS_PARTY_EXTERNL_ID
                 , T.T_RES_VALUE_DS                 AS RES_VALUE_DS
                 , T.T_UNIFIED_PARTY_ID             AS UNIFIED_PARTY_ID
                 , T.T_PARTY_REGRPMNT_ID            AS PARTY_REGRPMNT_ID
                 , T.T_SIRET_CODE_CD                AS SIRET_CODE_CD
                 , T.T_LAST_NAME_NM                 AS LAST_NAME_NM
                 , T.T_FIRST_NAME_NM                AS FIRST_NAME_NM
                 , T.T_NAME_NM                      AS NAME_NM
                 , T.T_INST_ADDRESS1_NM             AS INST_ADDRESS1_NM
                 , T.T_INST_ADDRESS2_NM             AS INST_ADDRESS2_NM
                 , T.T_INST_ADDRESS3_NM             AS INST_ADDRESS3_NM
                 , T.T_INST_ADDRESS4_NM             AS INST_ADDRESS4_NM
                 , T.T_INST_ADDRESS5_NM             AS INST_ADDRESS5_NM
                 , T.T_INST_ADDRESS6_NM             AS INST_ADDRESS6_NM
                 , T.T_MAIN_ADDRESS1_NM             AS MAIN_ADDRESS1_NM
                 , T.T_MAIN_ADDRESS2_NM             AS MAIN_ADDRESS2_NM
                 , T.T_MAIN_ADDRESS3_NM             AS MAIN_ADDRESS3_NM
                 , T.T_MAIN_ADDRESS4_NM             AS MAIN_ADDRESS4_NM
                 , T.T_MAIN_ADDRESS5_NM             AS MAIN_ADDRESS5_NM
                 , T.T_MAIN_ADDRESS6_NM             AS MAIN_ADDRESS6_NM
                 , T.T_BILL_ADDRESS1_NM             AS BILL_ADDRESS1_NM
                 , T.T_BILL_ADDRESS2_NM             AS BILL_ADDRESS2_NM
                 , T.T_BILL_ADDRESS3_NM             AS BILL_ADDRESS3_NM
                 , T.T_BILL_ADDRESS4_NM             AS BILL_ADDRESS4_NM
                 , T.T_BILL_ADDRESS5_NM             AS BILL_ADDRESS5_NM
                 , T.T_BILL_ADDRESS6_NM             AS BILL_ADDRESS6_NM
                 , T.T_INSEE_NB                     AS INSEE_NB
                 , T.T_POSTAL_CD                    AS POSTAL_CD
                 , T.T_DEPARTMNT_ID                 AS DEPARTMNT_ID
                 , T.T_PAR_FIBER_IN                 AS PAR_FIBER_IN
                 , T.T_PAR_GEO_MACROZONE            As PAR_GEO_MACROZONE    
                 , T.T_PAR_UNIFIED_PARTY_ID         As PAR_UNIFIED_PARTY_ID 
                 , T.T_PAR_PARTY_REGRPMNT_ID        As PAR_PARTY_REGRPMNT_ID
                 , T.T_PAR_IRIS2000_CD              AS PAR_IRIS2000_CD
                 , T.T_PAR_BU_CD                    AS PAR_BU_CD  
                 , T.T_CITY_LN                      AS CITY_LN
                 , T.T_SCORE_VALUE                  AS SCORE_VALUE
                 , T.T_SCORE_THRESHOLD              AS SCORE_THRESHOLD
                 , T.T_SCORE_IN                     AS SCORE_IN
                 , T.T_TAC_ID                       AS TAC_ID
                 , T.T_IMEI_CD                      AS IMEI_CD
                 , T.T_IMSI_CD                      AS IMSI_CD
                 , T.T_IND_INT_RESULT_ERR           AS IND_INT_RESULT_ERR
                 , T.T_IND_DMC_COH_DOMAIN           AS IND_DMC_COH_DOMAIN
                 , T.T_IND_TECH_DMC_THRESHOLD_TYPE  AS IND_TECH_DMC_THRESHOLD_TYPE          
                 , T.T_IND_TECH_DMC_THRESHOLD       AS IND_TECH_DMC_THRESHOLD      
                 , T.T_IND_DMC_THRESHOLD_TYPE       AS IND_DMC_THRESHOLD_TYPE      
                 , T.T_IND_DMC_THRESHOLD            AS IND_DMC_THRESHOLD
                 , T.T_IND_TECH_VMTIERS_THRES_T     AS IND_TECH_VMTIERS_THRES_T
                 , T.T_IND_TECH_VMTIERS_THRES       AS IND_TECH_VMTIERS_THRES           
                 , T.T_IND_TECH_SOC_TERMNTN_DUP     AS IND_TECH_SOC_TERMNTN_DUP    
                 , T.T_IND_TECH_SOC_TERMNTN_THRES_T AS IND_TECH_SOC_TERMNTN_THRES_T
                 , T.T_IND_TECH_SOC_TERMNTN_THRES   AS IND_TECH_SOC_TERMNTN_THRES  
                 , T.T_IND_TECH_SOC_ADRSS_DUP       AS IND_TECH_SOC_ADRSS_DUP      
                 , T.T_IND_TECH_SOC_ADRSS_THRES_T   AS IND_TECH_SOC_ADRSS_THRES_T  
                 , T.T_IND_TECH_SOC_ADRSS_THRES     AS IND_TECH_SOC_ADRSS_THRES    
                 , T.T_IND_TECH_KNB_AS_DUP          AS IND_TECH_KNB_AS_DUP
                 , T.T_RUN_ID                       AS RUN_ID         
FROM              (                                    
                    SELECT             INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ACTE_ID                                                                               AS T_ACTE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.EXTERNAL_ACTE_ID                                                                      AS T_EXTERNAL_ACTE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.TYPE_SOURCE_ID                                                                        AS T_TYPE_SOURCE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_ID                                                                                AS T_INT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_DETL_ID                                                                           AS T_INT_DETL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_TYPE                                                                              AS T_INT_TYPE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_TS                                                                     AS T_INT_CREATED_BY_TS
                                   ,   CAST(INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_TS AS DATE)                                                       AS T_INT_CREATED_BY_DT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_SRC                                                                               AS T_INT_SRC
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_RESULT                                                                            AS T_INT_RESULT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_REASON                                                                            AS T_INT_REASON
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_DETL_SRC                                                                          AS T_INT_DETL_SRC
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.DRK_PARTY_ID                                                                          AS T_DRK_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.FREG_PARTY_ID                                                                         AS T_FREG_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.EUREKA_PARTY_ID                                                                       AS T_EUREKA_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_PARC_CD                                                                           AS T_PAR_PARC_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_WKNESS_SCO                                                                        AS T_PAR_WKNESS_SCO
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_STORE_CD                                                                          AS T_PAR_STORE_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.REM_CHANNEL_CD                                                                        AS T_REM_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_REM_CHANNEL_CD                                                                    AS T_ORG_REM_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_CHANNEL_CD                                                                        AS T_ORG_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_SUB_CHANNEL_CD                                                                    AS T_ORG_SUB_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_SUB_SUB_CHANNEL_CD                                                                AS T_ORG_SUB_SUB_CHANNEL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ACTIVITY_CD                                                                           AS T_ACTIVITY_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_GT_ACTIVITY                                                                       AS T_ORG_GT_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_FIDELISATION                                                                      AS T_ORG_FIDELISATION
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_WEB_ACTIVITY                                                                      AS T_ORG_WEB_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_AUTO_ACTIVITY                                                                     AS T_ORG_AUTO_ACTIVITY
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_ID                                                                            AS T_ORG_EDO_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_DS                                                                            AS T_ORG_EDO_DS
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_TYPE_EDO                                                                          AS T_ORG_TYPE_EDO
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_FLAG_PLT_CONV                                                                     AS T_ORG_FLAG_PLT_CONV
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_FLAG_TEAM_MKT                                                                     AS T_ORG_FLAG_TEAM_MKT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_FLAG_TYPE_CMP                                                                     AS T_ORG_FLAG_TYPE_CMP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_FATHR_ID_NIV1                                                                 AS T_ORG_EDO_FATHR_ID_NIV1
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_FATHR_DS_NIV1                                                                 AS T_ORG_EDO_FATHR_DS_NIV1
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_FATHR_ID_NIV2                                                                 AS T_ORG_EDO_FATHR_ID_NIV2
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_FATHR_DS_NIV2                                                                 AS T_ORG_EDO_FATHR_DS_NIV2
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_FATHR_ID_NIV3                                                                 AS T_ORG_EDO_FATHR_ID_NIV3
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_EDO_FATHR_DS_NIV3                                                                 AS T_ORG_EDO_FATHR_DS_NIV3
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.AUTO_ACTIVITY_IN                                                                      AS T_AUTO_ACTIVITY_IN
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_TEAM_TYPE_ID                                                                      AS T_ORG_TEAM_TYPE_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.AGENT_LOGIN_CD                                                                        AS T_AGENT_LOGIN_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.AGENT_FIRST_NAME                                                                      AS T_AGENT_FIRST_NAME
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.AGENT_LAST_NAME                                                                       AS T_AGENT_LAST_NAME
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.EXTERNAL_TEAM_CD                                                                      AS T_EXTERNAL_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.EXTERNAL_TEAM_NM                                                                      AS T_EXTERNAL_TEAM_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.O3_ACTIVE_TEAM_CD                                                                     AS T_O3_ACTIVE_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.O3_RATTACHEMENT_TEAM_CD                                                               AS T_O3_RATTACHEMENT_TEAM_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_DETL_HABLT                                                                        AS T_INT_DETL_HABLT
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CANAL_VENTE                                                                       AS T_INT_CANAL_VENTE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ORG_CANAL_ID                                                                          AS T_ORG_CANAL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ID_FACADE                                                                             AS T_ID_FACADE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.EXTERNAL_PRODUCT_ID_FINAL                                                             AS T_EXTERNAL_PRODUCT_ID_FINAL
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.EXTERNAL_GAM_PRODUCT_ID                                                               AS T_EXTERNAL_GAM_PRODUCT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_GAM_TYPE                                                                          AS T_IND_GAM_TYPE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.NEW_OC_OCATID                                                                         AS T_NEW_OC_OCATID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.OLD_OC_OCATID                                                                         AS T_OLD_OC_OCATID
                                   ,   PAR_H_LNK_AR_HIST.LINE_ID                                                                                                  AS T_LINE_ID
                                   ,   PAR_H_LNK_AR_HIST.LINE_ID                                                                                                  AS T_MASTER_LINE_ID
                                   ,   PAR_H_LNK_AR_HIST.LINE_TYPE                                                                                                AS T_LINE_TYPE
                                   ,   PAR_H_LNK_AR_HIST.START_DT                                                                                                 AS T_LINE_START_DT
                                   ,   PAR_H_LNK_AR_HIST.OPERATOR_PROVIDER_ID                                                                                     AS T_OPERATOR_PROVIDER_ID
                                   ,   NULL                                                                                                                       AS T_SERVICE_ACCESS_ID
                                   ,   NULL                                                                                                                       AS T_BUSINESS_OFFER_BEGIN_DT
                                   ,   NULL                                                                                                                       AS T_PARTY_KNB_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.RES_VALUE_DS                                                                          AS T_TERMINTN_VALUE_DS
                                   ,   PAR_H_LNK_AR_HIST.EXTERNAL_SYSTEM_ID                                                                                       AS T_EXTERNAL_SYSTEM_ID
                                   ,   PAR_H_LNK_AR_HIST.EXTERNAL_PARTY_ID                                                                                        AS T_EXTERNAL_PARTY_ID
                                   ,   PAR_H_LNK_AR_HIST.EXTERNAL_PARTY_ID                                                                                        AS T_FREG_PARTY_EXTERNL_ID
                                   ,   NULL                                                                                                                       AS T_BSS_PARTY_EXTERNL_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.RES_VALUE_DS                                                                          AS T_RES_VALUE_DS
                                   ,   NULL                                                                                                                       AS T_UNIFIED_PARTY_ID
                                   ,   NULL                                                                                                                       AS T_PARTY_REGRPMNT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.SIRET_CODE_CD                                                                         AS T_SIRET_CODE_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.LAST_NAME_NM                                                                          AS T_LAST_NAME_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.FIRST_NAME_NM                                                                         AS T_FIRST_NAME_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.NAME_NM                                                                               AS T_NAME_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INST_ADDRESS1_NM                                                                      AS T_INST_ADDRESS1_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INST_ADDRESS2_NM                                                                      AS T_INST_ADDRESS2_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INST_ADDRESS3_NM                                                                      AS T_INST_ADDRESS3_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INST_ADDRESS4_NM                                                                      AS T_INST_ADDRESS4_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INST_ADDRESS5_NM                                                                      AS T_INST_ADDRESS5_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INST_ADDRESS6_NM                                                                      AS T_INST_ADDRESS6_NM
                                   ,   NULL                                                                                                                       AS T_MAIN_ADDRESS1_NM
                                   ,   NULL                                                                                                                       AS T_MAIN_ADDRESS2_NM
                                   ,   NULL                                                                                                                       AS T_MAIN_ADDRESS3_NM
                                   ,   NULL                                                                                                                       AS T_MAIN_ADDRESS4_NM
                                   ,   NULL                                                                                                                       AS T_MAIN_ADDRESS5_NM
                                   ,   NULL                                                                                                                       AS T_MAIN_ADDRESS6_NM
                                   ,   NULL                                                                                                                       AS T_BILL_ADDRESS1_NM
                                   ,   NULL                                                                                                                       AS T_BILL_ADDRESS2_NM
                                   ,   NULL                                                                                                                       AS T_BILL_ADDRESS3_NM
                                   ,   NULL                                                                                                                       AS T_BILL_ADDRESS4_NM
                                   ,   NULL                                                                                                                       AS T_BILL_ADDRESS5_NM
                                   ,   NULL                                                                                                                       AS T_BILL_ADDRESS6_NM
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INSEE_NB                                                                              AS T_INSEE_NB
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.POSTAL_CD                                                                             AS T_POSTAL_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.DEPARTMNT_ID                                                                          AS T_DEPARTMNT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_FIBER_IN                                                                          AS T_PAR_FIBER_IN
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_GEO_MACROZONE                                                                     AS T_PAR_GEO_MACROZONE
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_UNIFIED_PARTY_ID                                                                  AS T_PAR_UNIFIED_PARTY_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_PARTY_REGRPMNT_ID                                                                 AS  T_PAR_PARTY_REGRPMNT_ID
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_IRIS2000_CD                                                                       AS T_PAR_IRIS2000_CD      
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.PAR_BU_CD                                                                             AS T_PAR_BU_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.CITY_LN                                                                               AS T_CITY_LN
                                   ,   NULL                                                                                                                       AS T_SCORE_VALUE
                                   ,   NULL                                                                                                                       AS T_SCORE_THRESHOLD
                                   ,   NULL                                                                                                                       AS T_SCORE_IN
                                   ,   NULL                                                                                                                       AS T_TAC_ID
                                   ,   NULL                                                                                                                       AS T_IMEI_CD
                                   ,   NULL                                                                                                                       AS T_IMSI_CD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_INT_RESULT_ERR                                                                    AS T_IND_INT_RESULT_ERR
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_DMC_COH_DOMAIN                                                               AS T_IND_DMC_COH_DOMAIN
                                      -- ETAT DE LA LIGNE A L'INSTANT DU TRACAGE EST PRIVILEGIE
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT >=  PAR_H_LNK_AR_HIST.VAL_START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT <   PAR_H_LNK_AR_HIST.VAL_END_DT
                                            THEN 1
                                            ELSE 0
                                       END                                                                                                                        AS T_IND_TECH_A
                                      -- DETERMINATION DE LA TYPOLOGIE D'ECART ENTRE LA DATE DU TRACAGE ET LA DATE DE DEBUT D'APPLICATION DMC
                                   ,   CASE T_IND_TECH_A WHEN 1
                                                         THEN ${P_PIL_350}
                                                         ELSE CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT < PAR_H_LNK_AR_HIST.VAL_START_DT
                                                                   THEN ${P_PIL_351}
                                                                   ELSE ${P_PIL_352}
                                                              END 
                                       END                                                                                                                        AS T_IND_TECH_DMC_THRESHOLD_TYPE
                                      -- DETERMINATION DE L'ECART ENTRE LA DATE DU TRACAGE ET LE DEBUT DE VALIDITE DE LA LIGNE DMC CONSIDEREE
                                   ,   CASE T_IND_TECH_A WHEN 1
                                                         THEN ${P_PIL_353}
                                                         ELSE CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT < PAR_H_LNK_AR_HIST.VAL_START_DT
                                                                   THEN
                                                                       CASE WHEN (PAR_H_LNK_AR_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT) > 120
                                                                       THEN 120
                                                                       ELSE PAR_H_LNK_AR_HIST.VAL_START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT
                                                                       END
                                                                   ELSE
                                                                       CASE WHEN (INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT - PAR_H_LNK_AR_HIST.VAL_END_DT) > 120
                                                                       THEN 120
                                                                       ELSE INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT - PAR_H_LNK_AR_HIST.VAL_END_DT
                                                                       END
                                                              END
                                       END                                                                                                                        AS T_IND_TECH_DMC_THRESHOLD
                                      -- DETERMINATION DE LA CORRESPONDANCE ENTRE LA DATE DU TRACAGE ET LA PERIODE DE VALIDITE DE LA LIGNE 
                                   ,   CASE WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT >=  PAR_H_LNK_AR_HIST.START_DT
                                            AND  INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT <   PAR_H_LNK_AR_HIST.END_DT
                                            THEN ${P_PIL_350}
                                            WHEN INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT < PAR_H_LNK_AR_HIST.START_DT
                                            THEN ${P_PIL_351}
                                            ELSE ${P_PIL_352}
                                       END                                                                                                                        AS T_IND_DMC_THRESHOLD_TYPE
                                   ,   CASE T_IND_DMC_THRESHOLD_TYPE  WHEN ${P_PIL_350}
                                                                      THEN ${P_PIL_353}
                                                                      WHEN ${P_PIL_351}
                                                                      THEN CASE WHEN (PAR_H_LNK_AR_HIST.START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT) > 120
                                                                           THEN 120
                                                                           ELSE PAR_H_LNK_AR_HIST.START_DT - INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT
                                                                           END
                                                                      ELSE CASE WHEN (INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT - PAR_H_LNK_AR_HIST.END_DT) > 120
                                                                           THEN 120
                                                                           ELSE INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.INT_CREATED_BY_DT - PAR_H_LNK_AR_HIST.END_DT
                                                                           END
                                       END                                                                                                                        AS T_IND_DMC_THRESHOLD
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_VMTIERS_THRES_T                                                              AS T_IND_TECH_VMTIERS_THRES_T
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_VMTIERS_THRES                                                                AS IND_TECH_VMTIERS_THRES
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_SOC_TERMNTN_DUP                                                              AS T_IND_TECH_SOC_TERMNTN_DUP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_SOC_TERMNTN_THRES_T                                                          AS T_IND_TECH_SOC_TERMNTN_THRES_T
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_SOC_TERMNTN_THRES                                                            AS T_IND_TECH_SOC_TERMNTN_THRES
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_SOC_ADRSS_DUP                                                                AS T_IND_TECH_SOC_ADRSS_DUP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_SOC_ADRSS_THRES_T                                                            AS T_IND_TECH_SOC_ADRSS_THRES_T
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.IND_TECH_SOC_ADRSS_THRES                                                              AS T_IND_TECH_SOC_ADRSS_THRES
                                   , ${P_PIL_349}                                                                                                                 AS T_IND_TECH_KNB_AS_DUP
                                   ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.RUN_ID                                                                                AS T_RUN_ID
                    FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC
                    JOIN             ${KNB_DMC_VM_V}.PAR_H_LNK_AR_HIST                                                                                PAR_H_LNK_AR_HIST
                    ON                 1                                                                                                   =         1
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.FREG_PARTY_ID                                                                  =         PAR_H_LNK_AR_HIST.EXTERNAL_PARTY_ID
                    AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.RES_VALUE_DS                                                                   =         PAR_H_LNK_AR_HIST.RES_VALUE_DS
                    WHERE              1                                                                                                   =         1
                  -- SELECTION DES SEULES LIGNES FIXE
                    AND                PAR_H_LNK_AR_HIST.LINE_TYPE                                                                         =      '${P_PIL_300}'
                  -- SELECTION DE L'ETAT DE LA LIGNE DMC CORRESPONDANT AUTANT QUE POSSIBLE A LA DATE DU TRACAGE
                    QUALIFY            ROW_NUMBER() OVER (
                                                           PARTITION BY INT_W_PLACEMENT_${RFORCE_SUFFIX}_RTC.ACTE_ID
                                                           ORDER BY     T_IND_TECH_A DESC
                                                                      , T_IND_TECH_DMC_THRESHOLD ASC
                                                         )                                                                                 =         1
                    
                  ) T (
                        T_ACTE_ID
                      , T_EXTERNAL_ACTE_ID
                      , T_TYPE_SOURCE_ID
                      , T_INT_ID
                      , T_INT_DETL_ID
                      , T_INT_TYPE
                      , T_INT_CREATED_BY_TS
                      , T_INT_CREATED_BY_DT
                      , T_INT_SRC
                      , T_INT_RESULT
                      , T_INT_REASON
                      , T_INT_DETL_SRC
                      , T_DRK_PARTY_ID
                      , T_FREG_PARTY_ID
                      , T_EUREKA_PARTY_ID
                      , T_PAR_PARC_CD
                      , T_PAR_WKNESS_SCO
                      , T_PAR_STORE_CD
                      , T_REM_CHANNEL_CD
                      , T_ORG_REM_CHANNEL_CD
                      , T_ORG_CHANNEL_CD
                      , T_ORG_SUB_CHANNEL_CD
                      , T_ORG_SUB_SUB_CHANNEL_CD
                      , T_ACTIVITY_CD
                      , T_ORG_GT_ACTIVITY      
                      , T_ORG_FIDELISATION     
                      , T_ORG_WEB_ACTIVITY     
                      , T_ORG_AUTO_ACTIVITY    
                      , T_ORG_EDO_ID           
                      , T_ORG_EDO_DS           
                      , T_ORG_TYPE_EDO         
                      , T_ORG_FLAG_PLT_CONV    
                      , T_ORG_FLAG_TEAM_MKT    
                      , T_ORG_FLAG_TYPE_CMP    
                      , T_ORG_EDO_FATHR_ID_NIV1
                      , T_ORG_EDO_FATHR_DS_NIV1
                      , T_ORG_EDO_FATHR_ID_NIV2
                      , T_ORG_EDO_FATHR_DS_NIV2
                      , T_ORG_EDO_FATHR_ID_NIV3
                      , T_ORG_EDO_FATHR_DS_NIV3
                      , T_AUTO_ACTIVITY_IN
                      , T_ORG_TEAM_TYPE_ID
                      , T_AGENT_LOGIN_CD
                      , T_AGENT_FIRST_NAME
                      , T_AGENT_LAST_NAME
                      , T_EXTERNAL_TEAM_CD
                      , T_EXTERNAL_TEAM_NM
                      , T_O3_ACTIVE_TEAM_CD
                      , T_O3_RATTACHEMENT_TEAM_CD
                      , T_INT_DETL_HABLT
                      , T_INT_CANAL_VENTE
                      , T_ORG_CANAL_ID
                      , T_ID_FACADE
                      , T_EXTERNAL_PRODUCT_ID_FINAL
                      , T_EXTERNAL_GAM_PRODUCT_ID
                      , T_IND_GAM_TYPE
                      , T_NEW_OC_OCATID
                      , T_OLD_OC_OCATID
                      , T_LINE_ID
                      , T_MASTER_LINE_ID
                      , T_LINE_TYPE
                      , T_LINE_START_DT
                      , T_OPERATOR_PROVIDER_ID
                      , T_SERVICE_ACCESS_ID
                      , T_BUSINESS_OFFER_BEGIN_DT
                      , T_PARTY_KNB_ID
                      , T_TERMINTN_VALUE_DS
                      , T_EXTERNAL_SYSTEM_ID
                      , T_EXTERNAL_PARTY_ID
                      , T_FREG_PARTY_EXTERNL_ID
                      , T_BSS_PARTY_EXTERNL_ID
                      , T_RES_VALUE_DS
                      , T_UNIFIED_PARTY_ID
                      , T_PARTY_REGRPMNT_ID
                      , T_SIRET_CODE_CD
                      , T_LAST_NAME_NM
                      , T_FIRST_NAME_NM
                      , T_NAME_NM
                      , T_INST_ADDRESS1_NM
                      , T_INST_ADDRESS2_NM
                      , T_INST_ADDRESS3_NM
                      , T_INST_ADDRESS4_NM
                      , T_INST_ADDRESS5_NM
                      , T_INST_ADDRESS6_NM
                      , T_MAIN_ADDRESS1_NM
                      , T_MAIN_ADDRESS2_NM
                      , T_MAIN_ADDRESS3_NM
                      , T_MAIN_ADDRESS4_NM
                      , T_MAIN_ADDRESS5_NM
                      , T_MAIN_ADDRESS6_NM
                      , T_BILL_ADDRESS1_NM
                      , T_BILL_ADDRESS2_NM
                      , T_BILL_ADDRESS3_NM
                      , T_BILL_ADDRESS4_NM
                      , T_BILL_ADDRESS5_NM
                      , T_BILL_ADDRESS6_NM
                      , T_INSEE_NB
                      , T_POSTAL_CD
                      , T_DEPARTMNT_ID
                      , T_PAR_FIBER_IN 
                      , T_PAR_GEO_MACROZONE    
                      , T_PAR_UNIFIED_PARTY_ID 
                      , T_PAR_PARTY_REGRPMNT_ID
                      , T_PAR_IRIS2000_CD
                      , T_PAR_BU_CD
                      , T_CITY_LN
                      , T_SCORE_VALUE
                      , T_SCORE_THRESHOLD
                      , T_SCORE_IN
                      , T_TAC_ID
                      , T_IMEI_CD
                      , T_IMSI_CD
                      , T_IND_INT_RESULT_ERR
                      , T_IND_DMC_COH_DOMAIN
                      , T_IND_TECH_A
                      , T_IND_TECH_DMC_THRESHOLD_TYPE
                      , T_IND_TECH_DMC_THRESHOLD
                      , T_IND_DMC_THRESHOLD_TYPE
                      , T_IND_DMC_THRESHOLD
                      , T_IND_TECH_VMTIERS_THRES_T
                      , T_IND_TECH_VMTIERS_THRES
                      , T_IND_TECH_SOC_TERMNTN_DUP    
                      , T_IND_TECH_SOC_TERMNTN_THRES_T
                      , T_IND_TECH_SOC_TERMNTN_THRES
                      , T_IND_TECH_SOC_ADRSS_DUP      
                      , T_IND_TECH_SOC_ADRSS_THRES_T  
                      , T_IND_TECH_SOC_ADRSS_THRES  
                      , T_IND_TECH_KNB_AS_DUP
                      , T_RUN_ID
                     )
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
-- PERIMETRE DES TRACAGES EN ECHEC DE RAPPROCHEMENT AVEC LE DOMAINE DMC
                  (
                    ACTE_ID
                  , EXTERNAL_ACTE_ID
                  , TYPE_SOURCE_ID
                  , INT_ID
                  , INT_DETL_ID
                  , INT_TYPE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , INT_SRC
                  , INT_REASON
                  , INT_RESULT
                  , INT_DETL_SRC
                  , DRK_PARTY_ID
                  , FREG_PARTY_ID
                  , EUREKA_PARTY_ID
                  , PAR_PARC_CD
                  , PAR_WKNESS_SCO
                  , PAR_STORE_CD
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD
                  , ORG_CHANNEL_CD
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY               
                  , ORG_FIDELISATION              
                  , ORG_WEB_ACTIVITY              
                  , ORG_AUTO_ACTIVITY             
                  , ORG_EDO_ID                    
                  , ORG_EDO_DS                    
                  , ORG_TYPE_EDO                  
                  , ORG_FLAG_PLT_CONV             
                  , ORG_FLAG_TEAM_MKT             
                  , ORG_FLAG_TYPE_CMP             
                  , ORG_EDO_FATHR_ID_NIV1         
                  , ORG_EDO_FATHR_DS_NIV1         
                  , ORG_EDO_FATHR_ID_NIV2         
                  , ORG_EDO_FATHR_DS_NIV2         
                  , ORG_EDO_FATHR_ID_NIV3         
                  , ORG_EDO_FATHR_DS_NIV3         
                  , AUTO_ACTIVITY_IN
                  , ORG_TEAM_TYPE_ID     
                  , AGENT_LOGIN_CD
                  , AGENT_FIRST_NAME
                  , AGENT_LAST_NAME
                  , EXTERNAL_TEAM_CD
                  , EXTERNAL_TEAM_NM
                  , O3_ACTIVE_TEAM_CD
                  , O3_RATTACHEMENT_TEAM_CD
                  , INT_DETL_HABLT
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID
                  , ID_FACADE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , EXTERNAL_GAM_PRODUCT_ID
                  , IND_GAM_TYPE
                  , NEW_OC_OCATID
                  , OLD_OC_OCATID
                  , LINE_ID
                  , MASTER_LINE_ID
                  , LINE_TYPE
                  , LINE_START_DT
                  , OPERATOR_PROVIDER_ID
                  , SERVICE_ACCESS_ID
                  , BUSINESS_OFFER_BEGIN_DT
                  , PARTY_KNB_ID
                  , TERMINTN_VALUE_DS
                  , EXTERNAL_SYSTEM_ID
                  , EXTERNAL_PARTY_ID
                  , FREG_PARTY_EXTERNL_ID
                  , BSS_PARTY_EXTERNL_ID
                  , RES_VALUE_DS
                  , UNIFIED_PARTY_ID
                  , PARTY_REGRPMNT_ID
                  , SIRET_CODE_CD
                  , LAST_NAME_NM
                  , FIRST_NAME_NM
                  , NAME_NM
                  , INST_ADDRESS1_NM
                  , INST_ADDRESS2_NM
                  , INST_ADDRESS3_NM
                  , INST_ADDRESS4_NM
                  , INST_ADDRESS5_NM
                  , INST_ADDRESS6_NM
                  , MAIN_ADDRESS1_NM
                  , MAIN_ADDRESS2_NM
                  , MAIN_ADDRESS3_NM
                  , MAIN_ADDRESS4_NM
                  , MAIN_ADDRESS5_NM
                  , MAIN_ADDRESS6_NM
                  , BILL_ADDRESS1_NM
                  , BILL_ADDRESS2_NM
                  , BILL_ADDRESS3_NM
                  , BILL_ADDRESS4_NM
                  , BILL_ADDRESS5_NM
                  , BILL_ADDRESS6_NM
                  , INSEE_NB
                  , POSTAL_CD
                  , DEPARTMNT_ID
                  , PAR_FIBER_IN
                  , PAR_GEO_MACROZONE    
                  , PAR_UNIFIED_PARTY_ID 
                  , PAR_PARTY_REGRPMNT_ID
                  , PAR_IRIS2000_CD
                  , PAR_BU_CD
                  , CITY_LN
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE          
                  , IND_TECH_DMC_THRESHOLD      
                  , IND_DMC_THRESHOLD_TYPE      
                  , IND_DMC_THRESHOLD           
                  , IND_TECH_VMTIERS_THRES_T
                  , IND_TECH_VMTIERS_THRES           
                  , IND_TECH_SOC_TERMNTN_DUP    
                  , IND_TECH_SOC_TERMNTN_THRES_T
                  , IND_TECH_SOC_TERMNTN_THRES  
                  , IND_TECH_SOC_ADRSS_DUP      
                  , IND_TECH_SOC_ADRSS_THRES_T  
                  , IND_TECH_SOC_ADRSS_THRES    
                  , IND_TECH_KNB_AS_DUP
                  , RUN_ID
                  )
SELECT             V_ACT_F_ACTE_GEN.ACTE_ID                                                                                   AS ACTE_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                                      AS EXTERNAL_ACTE_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.TYPE_SOURCE_ID                                                                        AS TYPE_SOURCE_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_ID                                                                                AS INT_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_ID                                                                           AS INT_DETL_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_INT_TYPE                                                                          AS INT_TYPE
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_TS                                                                     AS INT_CREATED_BY_TS
               ,   CAST(INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CREATED_BY_TS AS DATE)                                                       AS INT_CREATED_BY_DT
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_SRC                                                                               AS INT_SRC
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_RESULT                                                                            AS INT_RESULT
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_REASON                                                                            AS INT_REASON
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_SRC                                                                          AS INT_DETL_SRC
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.DRK_PARTY_ID                                                                          AS DRK_PARTY_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.FREG_PARTY_ID                                                                         AS FREG_PARTY_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EUREKA_PARTY_ID                                                                       AS EUREKA_PARTY_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_PARC_CD                                                                           AS PAR_PARC_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_WKNESS_SCO                                                                        AS PAR_WKNESS_SCO
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.PAR_STORE_CD                                                                          AS PAR_STORE_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.REM_CHANNEL_CD                                                                        AS REM_CHANNEL_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_REM_CHANNEL_CD                                                                    AS ORG_REM_CHANNEL_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_CHANNEL_CD                                                                        AS ORG_CHANNEL_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_SUB_CHANNEL_CD                                                                    AS ORG_SUB_CHANNEL_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_SUB_SUB_CHANNEL_CD                                                                AS ORG_SUB_SUB_CHANNEL_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ACTIVITY_CD                                                                           AS ACTIVITY_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_GT_ACTIVITY                                                                       AS ORG_GT_ACTIVITY
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FIDELISATION                                                                      AS ORG_FIDELISATION
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_WEB_ACTIVITY                                                                      AS ORG_WEB_ACTIVITY
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_AUTO_ACTIVITY                                                                     AS ORG_AUTO_ACTIVITY
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_ID                                                                            AS ORG_EDO_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_DS                                                                            AS ORG_EDO_DS
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_TYPE_EDO                                                                          AS ORG_TYPE_EDO
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_PLT_CONV                                                                     AS ORG_FLAG_PLT_CONV
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_TEAM_MKT                                                                     AS ORG_FLAG_TEAM_MKT
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_FLAG_TYPE_CMP                                                                     AS ORG_FLAG_TYPE_CMP
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV1                                                                 AS ORG_EDO_FATHR_ID_NIV1
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV1                                                                 AS ORG_EDO_FATHR_DS_NIV1
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV2                                                                 AS ORG_EDO_FATHR_ID_NIV2
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV2                                                                 AS ORG_EDO_FATHR_DS_NIV2
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_ID_NIV3                                                                 AS ORG_EDO_FATHR_ID_NIV3
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_EDO_FATHR_DS_NIV3                                                                 AS ORG_EDO_FATHR_DS_NIV3
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AUTO_ACTIVITY_IN                                                                      AS AUTO_ACTIVITY_IN
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_TEAM_TYPE_ID                                                                      AS ORG_TEAM_TYPE_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_LOGIN_CD                                                                        AS AGENT_LOGIN_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_FIRST_NAME                                                                      AS AGENT_FIRST_NAME
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.AGENT_LAST_NAME                                                                       AS AGENT_LAST_NAME
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_TEAM_CD                                                                      AS EXTERNAL_TEAM_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_TEAM_NM                                                                      AS EXTERNAL_TEAM_NM
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.O3_ACTIVE_TEAM_CD                                                                     AS O3_ACTIVE_TEAM_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.O3_RATTACHEMENT_TEAM_CD                                                               AS O3_RATTACHEMENT_TEAM_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_DETL_HABLT                                                                        AS INT_DETL_HABLT
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.INT_CANAL_VENTE                                                                       AS INT_CANAL_VENTE
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ORG_CANAL_ID                                                                          AS ORG_CANAL_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.ID_FACADE                                                                             AS ID_FACADE
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_PRODUCT_ID_FINAL                                                             AS EXTERNAL_PRODUCT_ID_FINAL
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_GAM_PRODUCT_ID                                                               AS EXTERNAL_GAM_PRODUCT_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_GAM_TYPE                                                                          AS IND_GAM_TYPE
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.NEW_OC_OCATID                                                                         AS NEW_OC_OCATID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.OLD_OC_OCATID                                                                         AS OLD_OC_OCATID
               ,   NULL                                                                                                       AS LINE_ID
               ,   NULL                                                                                                       AS MASTER_LINE_ID
               ,   NULL                                                                                                       AS LINE_TYPE
               ,   NULL                                                                                                       AS LINE_START_DT
               ,   NULL                                                                                                       AS OPERATOR_PROVIDER_ID
               ,   NULL                                                                                                       AS SERVICE_ACCESS_ID
               ,   NULL                                                                                                       AS BUSINESS_OFFER_BEGIN_DT
               ,   NULL                                                                                                       AS PARTY_KNB_ID
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.RES_VALUE_DS                                                                          AS TERMINTN_VALUE_DS
               ,   NULL                                                                                                       AS EXTERNAL_SYSTEM_ID
               ,   NULL                                                                                                       AS EXTERNAL_PARTY_ID
               ,   NULL                                                                                                       AS FREG_PARTY_EXTERNL_ID
               ,   NULL                                                                                                       AS BSS_PARTY_EXTERNL_ID
               ,   NULL                                                                                                       AS RES_VALUE_DS
               ,   NULL                                                                                                       AS UNIFIED_PARTY_ID
               ,   NULL                                                                                                       AS PARTY_REGRPMNT_ID
               ,   NULL                                                                                                       AS SIRET_CODE_CD
               ,   NULL                                                                                                       AS LAST_NAME_NM
               ,   NULL                                                                                                       AS FIRST_NAME_NM
               ,   NULL                                                                                                       AS NAME_NM
               ,   NULL                                                                                                       AS INST_ADDRESS1_NM
               ,   NULL                                                                                                       AS INST_ADDRESS2_NM
               ,   NULL                                                                                                       AS INST_ADDRESS3_NM
               ,   NULL                                                                                                       AS INST_ADDRESS4_NM
               ,   NULL                                                                                                       AS INST_ADDRESS5_NM
               ,   NULL                                                                                                       AS INST_ADDRESS6_NM
               ,   NULL                                                                                                       AS MAIN_ADDRESS1_NM
               ,   NULL                                                                                                       AS MAIN_ADDRESS2_NM
               ,   NULL                                                                                                       AS MAIN_ADDRESS3_NM
               ,   NULL                                                                                                       AS MAIN_ADDRESS4_NM
               ,   NULL                                                                                                       AS MAIN_ADDRESS5_NM
               ,   NULL                                                                                                       AS MAIN_ADDRESS6_NM
               ,   NULL                                                                                                       AS BILL_ADDRESS1_NM
               ,   NULL                                                                                                       AS BILL_ADDRESS2_NM
               ,   NULL                                                                                                       AS BILL_ADDRESS3_NM
               ,   NULL                                                                                                       AS BILL_ADDRESS4_NM
               ,   NULL                                                                                                       AS BILL_ADDRESS5_NM
               ,   NULL                                                                                                       AS BILL_ADDRESS6_NM
               ,   NULL                                                                                                       AS INSEE_NB
               ,   NULL                                                                                                       AS POSTAL_CD
               ,   NULL                                                                                                       AS DEPARTMNT_ID
               ,   NULL                                                                                                       AS PAR_FIBER_IN
               ,   Null                                                                                                       As PAR_GEO_MACROZONE    
               ,   Null                                                                                                       As PAR_UNIFIED_PARTY_ID 
               ,   Null                                                                                                       As PAR_PARTY_REGRPMNT_ID
               ,   NULL                                                                                                       AS PAR_IRIS2000_CD
               ,   NULL                                                                                                       AS CITY_LN
               ,   NULL                                                                                                       AS PAR_BU_CD
               ,   NULL                                                                                                       AS SCORE_VALUE
               ,   NULL                                                                                                       AS SCORE_THRESHOLD
               ,   NULL                                                                                                       AS SCORE_IN
               ,   NULL                                                                                                       AS TAC_ID
               ,   NULL                                                                                                       AS IMEI_CD
               ,   NULL                                                                                                       AS IMSI_CD
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.IND_INT_RESULT_ERR                                                    AS IND_INT_RESULT_ERR
               , ${P_PIL_349}                                                                                                 AS IND_DMC_COH_DOMAIN
               , ${P_PIL_349}                                                                                                 AS IND_TECH_DMC_THRESHOLD_TYPE
               , ${P_PIL_349}                                                                                                 AS IND_TECH_DMC_THRESHOLD
               , ${P_PIL_349}                                                                                                 AS IND_DMC_THRESHOLD_TYPE
               , ${P_PIL_349}                                                                                                 AS IND_DMC_THRESHOLD
               , ${P_PIL_349}                                                                                                 AS IND_TECH_VMTIERS_THRES_T
               , ${P_PIL_349}                                                                                                 AS IND_TECH_VMTIERS_THRES
               , ${P_PIL_349}                                                                                                 AS IND_TECH_SOC_TERMNTN_DUP    
               , ${P_PIL_349}                                                                                                 AS IND_TECH_SOC_TERMNTN_THRES_T
               , ${P_PIL_349}                                                                                                 AS IND_TECH_SOC_TERMNTN_THRES
               , ${P_PIL_349}                                                                                                 AS IND_TECH_SOC_ADRSS_DUP      
               , ${P_PIL_349}                                                                                                 AS IND_TECH_SOC_ADRSS_THRES_T  
               , ${P_PIL_349}                                                                                                 AS IND_TECH_SOC_ADRSS_THRES  
               , ${P_PIL_349}                                                                                                 AS IND_TECH_KNB_AS_DUP
               ,   INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.RUN_ID                                                                AS RUN_ID
FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG
-- ENRICHISSEMENT PAR L'IDENTIFIANT INTERNE PILCOM DES ACTES
JOIN             ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN                                                                                 V_ACT_F_ACTE_GEN
ON                 1                                                                                                   =         1
AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                               =         V_ACT_F_ACTE_GEN.EXTERNAL_ACTE_ID
LEFT JOIN        ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI                                                                             INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI
ON                 INT_W_PLACEMENT_${RFORCE_SUFFIX}_ORG.EXTERNAL_ACTE_ID                                                               =         INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI.EXTERNAL_ACTE_ID
WHERE              1                                                                                                   =         1
-- SELECTION DES SEULS TRACAGES AUTOMATIQUES ET MANUELS SANS CORRESPONDANCE DANS LE DOMAINE DMC
AND                INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI.EXTERNAL_ACTE_ID                                                               IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;


-------------------------------------------------------------------------------------------------------
-- ETAPE 2 Enrichissement IRIS                                                                     ----
-------------------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_IRIS
(
  ACTE_ID                       ,
  EXTERNAL_ACTE_ID              ,
  DMC_LINE_ID                   ,
  PAR_GEO_MACROZONE             ,
  PAR_IRIS2000_CD
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                        ,
  RefId.EXTERNAL_ACTE_ID                          as EXTERNAL_ACTE_ID               ,
  RefId.LINE_ID                                   as DMC_LINE_ID                    ,
  FIBER.RESERV_4                                  as PAR_GEO_MACROZONE              ,
  FIBER.IRIS2000_CD                               as PAR_IRIS2000_CD
From
   ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI RefId
  Inner Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB FIBER
  on RefId.LINE_ID = FIBER.LINE_ID
  Where
  (1=1)
  Qualify Row_Number() Over (Partition by RefId.EXTERNAL_ACTE_ID Order by FIBER.LAST_MODIF_TS Desc)=1
 ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_IRIS;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 3 : Enrichissement   PAR_FIBER_IN                              ----
----------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_FIBER
(
  ACTE_ID                     ,
  EXTERNAL_ACTE_ID            ,
  DMC_LINE_ID                 ,
  PAR_FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                      ,
  RefId.EXTERNAL_ACTE_ID                          as EXTERNAL_ACTE_ID             ,
  RefId.LINE_ID                                   as DMC_LINE_ID                  ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN
From
   ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI RefId 
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
  on RefId.LINE_ID = FIBER.LINE_ID
   Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.EXTERNAL_ACTE_ID  Order by FIBER.START_DT Desc)=1  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_FIBER;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 4 : Enrichissement   BU_CD                                     ----
----------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_BU
(
  ACTE_ID                     ,
  EXTERNAL_ACTE_ID            ,
  DMC_LINE_ID                 ,
  PAR_BU_CD                   ,
  PAR_UNIFIED_PARTY_ID        ,
  PAR_PARTY_REGRPMNT_ID        
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                      ,
  RefId.EXTERNAL_ACTE_ID                          as EXTERNAL_ACTE_ID             ,
  RefId.LINE_ID                                   as DMC_LINE_ID                  ,
  Geo.BU_CD                                       as PAR_BU_CD                    ,
  Ldmc.UNIFIED_PARTY_ID                           as PAR_UNIFIED_PARTY_ID         ,
  Ldmc.PARTY_REGRPMNT_ID                          as PAR_PARTY_REGRPMNT_ID         
  
  
From
   ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_UNI RefId 
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On RefId.LINE_ID = Ldmc.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
Where
  (1=1)
  And Ldmc.CLOSURE_DT  Is Null
Qualify Row_Number() Over (Partition by RefId.EXTERNAL_ACTE_ID  Order by Ldmc.START_DT Desc)=1  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_${RFORCE_SUFFIX}_BU;
.if errorcode <> 0 then .quit 1


.QUIT 0;


