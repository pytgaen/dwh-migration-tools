 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ProduitSAVI.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des produits SAVI
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000


--Identification des produits SelfCare
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'SAVI'                                                        As SOURCE_ID              ,
  'SAVI'                                                        As CATALOG_ID             ,
  'Produit Externe manquant ; ( MOTIF_CD - CODE_INTERNE_CD - TERM_FAM_NM ) ; ( '
        ||Coalesce(Trim(Placement.EXT_PRODUCT_ID_1),'')
        ||' - '
        ||Coalesce(Trim(Placement.EXT_PRODUCT_ID_2),'')
        ||' - '
        ||Coalesce(Trim(Placement.EXT_PRODUCT_ID_3),'ND')
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.EXT_PRODUCT_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.EXT_PRODUCT_DS,''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  (
    Select
      Placement.MOTIF_CD                        As EXT_PRODUCT_ID_1           ,
      Placement.CODE_INTERNE_CD                 As EXT_PRODUCT_ID_2           ,
      Placement.TERM_FAM_NM                     As EXT_PRODUCT_ID_3           ,
      Null                                      As EXT_PRODUCT_DS             ,
      Count(*)                                  As VolumeCas                  ,
      Min(Placement.ORDER_DEPOSIT_DT)           As DateMinRecue               ,
      Max(Placement.ORDER_DEPOSIT_DT)           As DateMaxRecue               
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_SAVI Placement
    Where
      (1=1)
      And Placement.MOTIF_CD                Is Not Null
      And Placement.ORDER_DEPOSIT_DT        >= Current_date -30
    Group by
      EXT_PRODUCT_ID_1          ,
      EXT_PRODUCT_ID_2          ,
      EXT_PRODUCT_ID_3          ,
      EXT_PRODUCT_DS           
  ) Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_SAVI Catalogue
    On    Placement.EXT_PRODUCT_ID_1                        = Catalogue.EXT_PRODUCT_ID_1
      And Placement.EXT_PRODUCT_ID_2                        = Catalogue.EXT_PRODUCT_ID_2
      And Placement.EXT_PRODUCT_ID_3                        = Catalogue.EXT_PRODUCT_ID_5
      And Catalogue.CURRENT_IN                              = 1
      And Catalogue.CLOSURE_DT                              Is Null
      And Catalogue.PERIODE_ID                              =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Catalogue.EXT_PRODUCT_ID_1           Is Null
;
.if errorcode <> 0 Then .quit 1



-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
