--$HEADER:   %HEADER%
------------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DIGITAL_SOFTI_Extraction_Acte.sql  $                                                    
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL  de la source Digital des actes SOFTI dans la table ORD_W_EXTRACT_SOFTI_DIGITAL
------------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION                
-- 22/07/2019     GRH         Creation                             
------------------------------------------------------------------------------------------------------------

.set width 5000

-----------------------------------------
-- Table : ORD_W_EXTRACT_SOFTI_DIGITAL-- 
-----------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_EXTRACT_SOFTI_DIGITAL;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_W_EXTRACT_SOFTI_DIGITAL 
(
  ACTE_ID                       ,
  ACT_DT                        ,
  INTRNL_SOURCE_ID              ,
  SOURCE_DS                     ,
  ACT_ACTE_FAMILLE_KPI          ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PID_ID                    ,
  PAR_CID_ID                    ,
  UNIFIED_SHOP_CD               ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS
)
Select
  SOFTI.ACTE_ID_GEN                                                        As ACTE_ID                         ,
  SOFTI.ORDER_DEPOSIT_DT                                                   As ACT_DT                          ,
  SOFTI.INTRNL_SOURCE_ID                                                   As INTRNL_SOURCE_ID                ,
  'SOFTI'                                                                  As SOURCE_DS                       ,
  SOFTI.ACT_ACTE_FAMILLE_KPI                                               As ACT_ACTE_FAMILLE_KPI            ,
  SOFTI.PAR_UNIFIED_PARTY_ID                                               As PAR_UNIFIED_PARTY_ID            ,
  SOFTI.PAR_PID_ID                                                         As PAR_PID_ID                      ,
  SOFTI.PAR_CID_ID                                                         As PAR_CID_ID                      ,
  SOFTI.ORG_STORE_NAME                                                     As UNIFIED_SHOP_CD                 ,
Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SOFTI.CPLT_ORG_REM_CHANNEL_CD,SOFTI.ORG_REM_CHANEL_CD)
      Else    SOFTI.ORG_REM_CHANEL_CD
  End                                                                      As ORG_REM_CHANNEL_CD              ,
  Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SOFTI.CPLT_ORG_CHANNEL_CD,SOFTI.ORG_CHANEL_CD)
        Else    SOFTI.ORG_CHANEL_CD
  End                                                                      As ORG_CHANNEL_CD                  ,
  Case When SOFTI.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SOFTI.CPLT_ORG_SUB_CHANNEL_CD,SOFTI.ORG_SUB_CHANEL_CD)
        Else    SOFTI.ORG_SUB_CHANEL_CD
  End                                                                      As ORG_SUB_CHANNEL_CD              ,
  Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SOFTI.CPLT_ORG_SUB_SUB_CHANNEL_CD,SOFTI.ORG_SUB_SUB_CHANEL_CD)
         Else SOFTI.ORG_SUB_SUB_CHANEL_CD
  End                                                                      As ORG_SUB_SUB_CHANEL_CD           ,
  Case When SOFTI.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SOFTI.CPLT_ORG_GT_ACTIVITY,SOFTI.ORG_GT_ACTIVITY)
        Else    SOFTI.ORG_GT_ACTIVITY
  End                                                                      As ORG_GT_ACTIVITY                 ,
  Case When SOFTI.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SOFTI.CPLT_ORG_FIDELISATION,SOFTI.ORG_FIDELISATION)
         Else    SOFTI.ORG_FIDELISATION
  End                                                                      As ORG_FIDELISATION                ,
  Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SOFTI.CPLT_ORG_WEB_ACTIVITY,SOFTI.ORG_WEB_ACTIVITY)
          Else    SOFTI.ORG_WEB_ACTIVITY
  End                                                                      As ORG_WEB_ACTIVITY                ,
  Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SOFTI.CPLT_ORG_AUTO_ACTIVITY,SOFTI.ORG_AUTO_ACTIVITY)
         Else    SOFTI.ORG_AUTO_ACTIVITY
  End                                                                      As ORG_AUTO_ACTIVITY               ,
  Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then  Coalesce(SOFTI.CPLT_ORG_EDO_ID,SOFTI.ORG_EDO_ID)
        Else SOFTI.ORG_EDO_ID
  End                                                                      As ORG_EDO_ID                      ,
 Case  When SOFTI.CPLT_ACTE_ID Is Not Null
          Then   Coalesce(SOFTI.CPLT_ORG_TYPE_EDO,SOFTI.ORG_TYPE_EDO)
        Else SOFTI.ORG_TYPE_EDO
  End                                                                      As ORG_TYPE_EDO                    ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_1_CD)                                          As ORG_TEAM_LEVEL_1_CD             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_1_DS)                                          As ORG_TEAM_LEVEL_1_DS             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_2_CD)                                          As ORG_TEAM_LEVEL_2_CD             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_2_DS)                                          As ORG_TEAM_LEVEL_2_DS             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_3_CD)                                          As ORG_TEAM_LEVEL_3_CD             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_3_DS)                                          As ORG_TEAM_LEVEL_3_DS             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_4_CD)                                          As ORG_TEAM_LEVEL_4_CD             ,
  TRIM(SOFTI.ORG_TEAM_LEVEL_4_DS)                                          As ORG_TEAM_LEVEL_4_DS             ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_1_CD)                                         As WORK_TEAM_LEVEL_1_CD            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_1_DS)                                         As WORK_TEAM_LEVEL_1_DS            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_2_CD)                                         As WORK_TEAM_LEVEL_2_CD            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_2_DS)                                         As WORK_TEAM_LEVEL_2_DS            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_3_CD)                                         As WORK_TEAM_LEVEL_3_CD            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_3_DS)                                         As WORK_TEAM_LEVEL_3_DS            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_4_CD)                                         As WORK_TEAM_LEVEL_4_CD            ,
  TRIM(SOFTI.WORK_TEAM_LEVEL_4_DS)                                         As WORK_TEAM_LEVEL_4_DS             
From ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT As SOFTI
Where (1=1)
  And Substr(SOFTI.ACT_CD,1,3)      Not In (${L_PIL_036})
  And SOFTI.ACT_SEG_COM_ID_FINAL    <>      '${P_PIL_295}'
  And SOFTI.ACT_CD                  <>      '${P_PIL_067}'
  And SOFTI.ORDER_DEPOSIT_DT        >       '20130402'
  And SOFTI.HOT_IN                  =       0
  And SOFTI.ORDER_DEPOSIT_DT        >= Current_date - 250
  And SOFTI.ORG_CHANEL_CD          In ('Online', 'DNU')
  And ((SOFTI.LAST_MODIF_TS         >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And SOFTI.LAST_MODIF_TS  <=  '${KNB_PILCOM_EXTRACT_BORNE_MAX}') 
        or SOFTI.ORDER_DEPOSIT_DT > Current_date - 15)  
;

.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_W_EXTRACT_SOFTI_DIGITAL;
 if errorcode <> 0 then .quit 1;
