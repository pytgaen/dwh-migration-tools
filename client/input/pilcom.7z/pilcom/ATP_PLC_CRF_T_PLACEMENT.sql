-- $HEADER: mm2pco/current/sql/ATP_PLC_CRF_T_PLACEMENT.sql 13_05#13 26-JUN-2019 11:40:46 NNGS2043
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_CRF_T_PLACEMENT.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Perimetre CRF - PLACEMENT - VALORISATION DU TAMPON -
--
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 16/07/13        DARTIGUE    Creation
-- 23/02/2016      MDE         Modif
-- 12/01/2017      HLA         Modif (Ventes associés)
-- 05/12/2017      HOB         Modif IOBSP
-- 18/02/2019      SSI         Alimentation Champs ORG_AGENT_IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID

---------------------------------------------------------------------------------

.SET WIDTH 2000;

DELETE FROM      ${KNB_PCO_TMP}.INT_T_PLACEMENT_CRF ALL;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- INSERTION CONDITIONNELLE DANS LA STRUCTURE TAMPON POUR BASCULE VERS SOCLE
INSERT INTO      ${KNB_PCO_TMP}.INT_T_PLACEMENT_CRF
                  (
                    ACTE_ID
                  , EXTERNAL_ACTE_ID
                  , TYPE_SOURCE_ID
                  , INT_ID
                  , INT_DETL_ID
                  , INT_TYPE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , INT_SRC
                  , INT_REASON
                  , INT_RESULT
                  , INT_DETL_SRC
                  , DRK_PARTY_ID
                  , FREG_PARTY_ID
                  , EUREKA_PARTY_ID
                  , PAR_PARC_CD
                  , PAR_WKNESS_SCO
                  , PAR_STORE_CD
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD
                  , ORG_CHANNEL_CD
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY               
                  , ORG_FIDELISATION              
                  , ORG_WEB_ACTIVITY              
                  , ORG_AUTO_ACTIVITY             
                  , ORG_EDO_ID                    
                  , ORG_EDO_DS                    
                  , ORG_TYPE_EDO                  
                  , ORG_EDO_IOBSP                 
                  , ORG_FLAG_PLT_CONV             
                  , ORG_FLAG_TEAM_MKT             
                  , ORG_FLAG_TYPE_CMP             
                  , ORG_EDO_FATHR_ID_NIV1         
                  , ORG_EDO_FATHR_DS_NIV1         
                  , ORG_EDO_FATHR_ID_NIV2         
                  , ORG_EDO_FATHR_DS_NIV2         
                  , ORG_EDO_FATHR_ID_NIV3         
                  , ORG_EDO_FATHR_DS_NIV3         
                  , AUTO_ACTIVITY_IN
                  , ORG_TEAM_TYPE_ID     
                  , AGENT_LOGIN_CD
                  , AGENT_FIRST_NAME
                  , AGENT_LAST_NAME
                  , ORG_AGENT_IOBSP
                  , EXTERNAL_TEAM_CD
                  , EXTERNAL_TEAM_NM
                  , O3_ACTIVE_TEAM_CD
                  , O3_RATTACHEMENT_TEAM_CD
                  , INT_DETL_HABLT
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID
                  , ID_FACADE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , INTRNL_PRDCT_ID_OPENCAT_INI
                  , EXTERNAL_GAM_PRODUCT_ID
                  , IND_GAM_TYPE
                  , NEW_OC_OCATID
                  , OLD_OC_OCATID
                  , LINE_ID
                  , MASTER_LINE_ID
                  , LINE_TYPE
                  , LINE_START_DT
                  , OPERATOR_PROVIDER_ID
                  , SERVICE_ACCESS_ID
                  , BUSINESS_OFFER_BEGIN_DT
                  , PARTY_KNB_ID
                  , TERMINTN_VALUE_DS
                  , EXTERNAL_SYSTEM_ID
                  , EXTERNAL_PARTY_ID
                  , FREG_PARTY_EXTERNL_ID
                  , BSS_PARTY_EXTERNL_ID
                  , RES_VALUE_DS
                  , PARTY_REGRPMNT_ID
                  , SIRET_CODE_CD
                  , LAST_NAME_NM
                  , FIRST_NAME_NM
                  , NAME_NM
                  , INST_ADDRESS1_NM
                  , INST_ADDRESS2_NM
                  , INST_ADDRESS3_NM
                  , INST_ADDRESS4_NM
                  , INST_ADDRESS5_NM
                  , INST_ADDRESS6_NM
                  , MAIN_ADDRESS1_NM
                  , MAIN_ADDRESS2_NM
                  , MAIN_ADDRESS3_NM
                  , MAIN_ADDRESS4_NM
                  , MAIN_ADDRESS5_NM
                  , MAIN_ADDRESS6_NM
                  , BILL_ADDRESS1_NM
                  , BILL_ADDRESS2_NM
                  , BILL_ADDRESS3_NM
                  , BILL_ADDRESS4_NM
                  , BILL_ADDRESS5_NM
                  , BILL_ADDRESS6_NM
                  , INSEE_NB
                  , POSTAL_CD
                  , DEPARTMNT_ID
                  , PAR_FIBER_IN
                  , PAR_GEO_MACROZONE
                  , PAR_UNIFIED_PARTY_ID
                  , PAR_PARTY_REGRPMNT_ID
                  , PAR_IRIS2000_CD
                  , PAR_BU_CD
                  , CITY_LN
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE          
                  , IND_TECH_DMC_THRESHOLD      
                  , IND_DMC_THRESHOLD_TYPE      
                  , IND_DMC_THRESHOLD           
                  , IND_TECH_VMTIERS_THRES_T
                  , IND_TECH_VMTIERS_THRES           
                  , IND_TECH_SOC_TERMNTN_DUP    
                  , IND_TECH_SOC_TERMNTN_THRES_T
                  , IND_TECH_SOC_TERMNTN_THRES  
                  , IND_TECH_SOC_ADRSS_DUP      
                  , IND_TECH_SOC_ADRSS_THRES_T
                  , IND_TECH_SOC_ADRSS_THRES    
                  , IND_TECH_KNB_AS_DUP
                  , CREATION_TS
                  , LAST_MODIF_TS
                  , FRESH_IN
                  , COHERENCE_IN
                  , HOT_IN
                  , RUN_ID
                  )
SELECT             INT_W_PLACEMENT_CRF_UNI.ACTE_ID                                                                                         AS ACTE_ID
                 , INT_W_PLACEMENT_CRF_UNI.EXTERNAL_ACTE_ID                                                                                AS EXTERNAL_ACTE_ID
                 , INT_W_PLACEMENT_CRF_UNI.TYPE_SOURCE_ID                                                                                  AS TYPE_SOURCE_ID
                 , INT_W_PLACEMENT_CRF_UNI.INT_ID                                                                                          AS INT_ID
                 , INT_W_PLACEMENT_CRF_UNI.INT_DETL_ID                                                                                     AS INT_DETL_ID
                 , INT_W_PLACEMENT_CRF_UNI.INT_TYPE                                                                                        AS INT_TYPE
                 , INT_W_PLACEMENT_CRF_UNI.INT_CREATED_BY_TS                                                                               AS INT_CREATED_BY_TS
                 , INT_W_PLACEMENT_CRF_UNI.INT_CREATED_BY_DT                                                                               AS INT_CREATED_BY_DT
                 , INT_W_PLACEMENT_CRF_UNI.INT_SRC                                                                                         AS INT_SRC
                 , INT_W_PLACEMENT_CRF_UNI.INT_REASON                                                                                      AS INT_REASON
                 , INT_W_PLACEMENT_CRF_UNI.INT_RESULT                                                                                      AS INT_RESULT
                 , INT_W_PLACEMENT_CRF_UNI.INT_DETL_SRC                                                                                    AS INT_DETL_SRC
                 , INT_W_PLACEMENT_CRF_UNI.DRK_PARTY_ID                                                                                    AS DRK_PARTY_ID
                 , INT_W_PLACEMENT_CRF_UNI.FREG_PARTY_ID                                                                                   AS FREG_PARTY_ID
                 , INT_W_PLACEMENT_CRF_UNI.EUREKA_PARTY_ID                                                                                 AS EUREKA_PARTY_ID
                 , INT_W_PLACEMENT_CRF_UNI.PAR_PARC_CD                                                                                     AS PAR_PARC_CD
                 , INT_W_PLACEMENT_CRF_UNI.PAR_WKNESS_SCO                                                                                  AS PAR_WKNESS_SCO
                 , INT_W_PLACEMENT_CRF_UNI.PAR_STORE_CD                                                                                    AS PAR_STORE_CD
                 , INT_W_PLACEMENT_CRF_UNI.REM_CHANNEL_CD                                                                                  AS REM_CHANNEL_CD
                 , INT_W_PLACEMENT_CRF_UNI.ORG_REM_CHANNEL_CD                                                                              AS ORG_REM_CHANNEL_CD
                 , INT_W_PLACEMENT_CRF_UNI.ORG_CHANNEL_CD                                                                                  AS ORG_CHANNEL_CD
                 , INT_W_PLACEMENT_CRF_UNI.ORG_SUB_CHANNEL_CD                                                                              AS ORG_SUB_CHANNEL_CD
                 , INT_W_PLACEMENT_CRF_UNI.ORG_SUB_SUB_CHANNEL_CD                                                                          AS ORG_SUB_SUB_CHANNEL_CD
                 , INT_W_PLACEMENT_CRF_UNI.ACTIVITY_CD                                                                                     AS ACTIVITY_CD
                 , INT_W_PLACEMENT_CRF_UNI.ORG_GT_ACTIVITY                                                                                 AS ORG_GT_ACTIVITY
                 , INT_W_PLACEMENT_CRF_UNI.ORG_FIDELISATION                                                                                AS ORG_FIDELISATION
                 , INT_W_PLACEMENT_CRF_UNI.ORG_WEB_ACTIVITY                                                                                AS ORG_WEB_ACTIVITY
                 , INT_W_PLACEMENT_CRF_UNI.ORG_AUTO_ACTIVITY                                                                               AS ORG_AUTO_ACTIVITY
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_ID                                                                                      AS ORG_EDO_ID
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_DS                                                                                      AS ORG_EDO_DS
                 , INT_W_PLACEMENT_CRF_UNI.ORG_TYPE_EDO                                                                                    AS ORG_TYPE_EDO
                 ,  Case When EdoOBK.EDO_ID is Not Null
                    Then 'O'
                       Else 'N'
                    End                                                                                                                     AS ORG_EDO_IOBSP
                 , INT_W_PLACEMENT_CRF_UNI.ORG_FLAG_PLT_CONV                                                                               AS ORG_FLAG_PLT_CONV
                 , INT_W_PLACEMENT_CRF_UNI.ORG_FLAG_TEAM_MKT                                                                               AS ORG_FLAG_TEAM_MKT
                 , INT_W_PLACEMENT_CRF_UNI.ORG_FLAG_TYPE_CMP                                                                               AS ORG_FLAG_TYPE_CMP
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_FATHR_ID_NIV1                                                                           AS ORG_EDO_FATHR_ID_NIV1
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_FATHR_DS_NIV1                                                                           AS ORG_EDO_FATHR_DS_NIV1
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_FATHR_ID_NIV2                                                                           AS ORG_EDO_FATHR_ID_NIV2
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_FATHR_DS_NIV2                                                                           AS ORG_EDO_FATHR_DS_NIV2
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_FATHR_ID_NIV3                                                                           AS ORG_EDO_FATHR_ID_NIV3
                 , INT_W_PLACEMENT_CRF_UNI.ORG_EDO_FATHR_DS_NIV3                                                                           AS ORG_EDO_FATHR_DS_NIV3
                 , INT_W_PLACEMENT_CRF_UNI.AUTO_ACTIVITY_IN                                                                                AS AUTO_ACTIVITY_IN
                 , INT_W_PLACEMENT_CRF_UNI.ORG_TEAM_TYPE_ID                                                                                AS ORG_TEAM_TYPE_ID
                 , INT_W_PLACEMENT_CRF_UNI.AGENT_LOGIN_CD                                                                                  AS AGENT_LOGIN_CD
                 , INT_W_PLACEMENT_CRF_UNI.AGENT_FIRST_NAME                                                                                AS AGENT_FIRST_NAME
                 , INT_W_PLACEMENT_CRF_UNI.AGENT_LAST_NAME
                 ,  Case
	                  When CuidOBK.AGENT_ID is Null 
                       Then '0'
                      When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
                       Then '3'
                       Else   '2'
                    End                                                                                                                    as  ORG_AGENT_IOBSP         
                 , INT_W_PLACEMENT_CRF_UNI.EXTERNAL_TEAM_CD                                                                                AS EXTERNAL_TEAM_CD
                 , INT_W_PLACEMENT_CRF_UNI.EXTERNAL_TEAM_NM                                                                                AS EXTERNAL_TEAM_NM
                 , INT_W_PLACEMENT_CRF_UNI.O3_ACTIVE_TEAM_CD                                                                               AS O3_ACTIVE_TEAM_CD
                 , INT_W_PLACEMENT_CRF_UNI.O3_RATTACHEMENT_TEAM_CD                                                                         AS O3_RATTACHEMENT_TEAM_CD
                 , INT_W_PLACEMENT_CRF_UNI.INT_DETL_HABLT                                                                                  AS INT_DETL_HABLT
                 , INT_W_PLACEMENT_CRF_UNI.INT_CANAL_VENTE                                                                                 AS INT_CANAL_VENTE
                 , INT_W_PLACEMENT_CRF_UNI.ORG_CANAL_ID                                                                                    AS ORG_CANAL_ID
                 , INT_W_PLACEMENT_CRF_UNI.ID_FACADE                                                                                       AS ID_FACADE
                 , INT_W_PLACEMENT_CRF_UNI.EXTERNAL_PRODUCT_ID_FINAL                                                                       AS EXTERNAL_PRODUCT_ID_FINAL
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NULL
                             AND V_INT_F_PLACEMENT_HRF.LINE_ID IS NOT NULL
                             OR  V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN > INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN
                             OR  V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD < INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     V_INT_F_PLACEMENT_HRF.INTRNL_PRDCT_ID_OPENCAT_INI
                        ELSE     INT_W_PLACEMENT_CRF_UNI.INTRNL_PRDCT_ID_OPENCAT_INI
                   END                                                                                                                  AS INTRNL_PRDCT_ID_OPENCAT_INI
                 , INT_W_PLACEMENT_CRF_UNI.EXTERNAL_GAM_PRODUCT_ID                                                                         AS EXTERNAL_GAM_PRODUCT_ID
                 , INT_W_PLACEMENT_CRF_UNI.IND_GAM_TYPE                                                                                    AS IND_GAM_TYPE
                 , INT_W_PLACEMENT_CRF_UNI.NEW_OC_OCATID                                                                                   AS NEW_OC_OCATID
                 , INT_W_PLACEMENT_CRF_UNI.OLD_OC_OCATID                                                                                   AS OLD_OC_OCATID
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.LINE_ID
                   END                                                                                                                  AS LINE_ID                     
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN    INT_W_PLACEMENT_CRF_UNI.MASTER_LINE_ID
                        ELSE    V_INT_F_PLACEMENT_HRF.MASTER_LINE_ID
                   END                                                                                                                  AS MASTER_LINE_ID              
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.LINE_TYPE
                        ELSE     V_INT_F_PLACEMENT_HRF.LINE_TYPE
                   END                                                                                                                  AS LINE_TYPE
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.LINE_START_DT
                        ELSE     V_INT_F_PLACEMENT_HRF.LINE_START_DT
                   END                                                                                                                  AS LINE_START_DT                   
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.OPERATOR_PROVIDER_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.OPERATOR_PROVIDER_ID
                   END                                                                                                                  AS OPERATOR_PROVIDER_ID        
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.SERVICE_ACCESS_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.SERVICE_ACCESS_ID
                   END                                                                                                                  AS SERVICE_ACCESS_ID           
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BUSINESS_OFFER_BEGIN_DT
                        ELSE     V_INT_F_PLACEMENT_HRF.BUSINESS_OFFER_BEGIN_DT
                   END                                                                                                                  AS BUSINESS_OFFER_BEGIN_DT
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.PARTY_KNB_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.PARTY_KNB_ID
                   END                                                                                                                  AS PARTY_KNB_ID                
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.TERMINTN_VALUE_DS
                        ELSE     V_INT_F_PLACEMENT_HRF.TERMINTN_VALUE_DS
                   END                                                                                                                  AS TERMINTN_VALUE_DS           
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.EXTERNAL_SYSTEM_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.EXTERNAL_SYSTEM_ID
                   END                                                                                                                  AS EXTERNAL_SYSTEM_ID          
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.EXTERNAL_PARTY_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.EXTERNAL_PARTY_ID
                   END                                                                                                                  AS EXTERNAL_PARTY_ID           
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.FREG_PARTY_EXTERNL_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.FREG_PARTY_EXTERNL_ID
                   END                                                                                                                  AS FREG_PARTY_EXTERNL_ID
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BSS_PARTY_EXTERNL_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.BSS_PARTY_EXTERNL_ID
                   END                                                                                                                  AS BSS_PARTY_EXTERNL_ID
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.RES_VALUE_DS
                        ELSE     V_INT_F_PLACEMENT_HRF.RES_VALUE_DS
                   END                                                                                                                  AS RES_VALUE_DS                
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.PARTY_REGRPMNT_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.PARTY_REGRPMNT_ID
                   END                                                                                                                  AS PARTY_REGRPMNT_ID           
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.SIRET_CODE_CD
                        ELSE     V_INT_F_PLACEMENT_HRF.SIRET_CODE_CD
                   END                                                                                                                  AS SIRET_CODE_CD               
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.LAST_NAME_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.LAST_NAME_NM
                   END                                                                                                                  AS LAST_NAME_NM                
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.FIRST_NAME_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.FIRST_NAME_NM
                   END                                                                                                                  AS FIRST_NAME_NM               
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.NAME_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.NAME_NM
                   END                                                                                                                  AS NAME_NM                     
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INST_ADDRESS1_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.INST_ADDRESS1_NM
                   END                                                                                                                  AS INST_ADDRESS1_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INST_ADDRESS2_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.INST_ADDRESS2_NM
                   END                                                                                                                  AS INST_ADDRESS2_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INST_ADDRESS3_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.INST_ADDRESS3_NM
                   END                                                                                                                  AS INST_ADDRESS3_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INST_ADDRESS4_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.INST_ADDRESS4_NM
                   END                                                                                                                  AS INST_ADDRESS4_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INST_ADDRESS5_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.INST_ADDRESS5_NM
                   END                                                                                                                  AS INST_ADDRESS5_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INST_ADDRESS6_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.INST_ADDRESS6_NM
                   END                                                                                                                  AS INST_ADDRESS6_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.MAIN_ADDRESS1_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS1_NM
                   END                                                                                                                  AS MAIN_ADDRESS1_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.MAIN_ADDRESS2_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS2_NM
                   END                                                                                                                  AS MAIN_ADDRESS2_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.MAIN_ADDRESS3_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS3_NM
                   END                                                                                                                  AS MAIN_ADDRESS3_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.MAIN_ADDRESS4_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS4_NM
                   END                                                                                                                  AS MAIN_ADDRESS4_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.MAIN_ADDRESS5_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS5_NM
                   END                                                                                                                  AS MAIN_ADDRESS5_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.MAIN_ADDRESS6_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS6_NM
                   END                                                                                                                  AS MAIN_ADDRESS6_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BILL_ADDRESS1_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.BILL_ADDRESS1_NM
                   END                                                                                                                  AS BILL_ADDRESS1_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BILL_ADDRESS2_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.BILL_ADDRESS2_NM
                   END                                                                                                                  AS BILL_ADDRESS2_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BILL_ADDRESS3_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.BILL_ADDRESS3_NM
                   END                                                                                                                  AS BILL_ADDRESS3_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BILL_ADDRESS4_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.BILL_ADDRESS4_NM
                   END                                                                                                                  AS BILL_ADDRESS4_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BILL_ADDRESS5_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.BILL_ADDRESS5_NM
                   END                                                                                                                  AS BILL_ADDRESS5_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.BILL_ADDRESS6_NM
                        ELSE     V_INT_F_PLACEMENT_HRF.BILL_ADDRESS6_NM
                   END                                                                                                                  AS BILL_ADDRESS6_NM            
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.INSEE_NB
                        ELSE     V_INT_F_PLACEMENT_HRF.INSEE_NB
                   END                                                                                                                  AS INSEE_NB                    
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.POSTAL_CD
                        ELSE     V_INT_F_PLACEMENT_HRF.POSTAL_CD
                   END                                                                                                                  AS POSTAL_CD                   
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.DEPARTMNT_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.DEPARTMNT_ID
                   END                                                                                                                   AS DEPARTMNT_ID                     
                 ------------
                 , Coalesce(FIBER.PAR_FIBER_IN,V_INT_F_PLACEMENT_HRF.PAR_FIBER_IN)                                                       AS PAR_FIBER_IN 
                 , Coalesce(IRIS.PAR_GEO_MACROZONE,V_INT_F_PLACEMENT_HRF.PAR_GEO_MACROZONE)                                              AS PAR_GEO_MACROZONE
                 , Coalesce(BU.PAR_UNIFIED_PARTY_ID,V_INT_F_PLACEMENT_HRF.PAR_UNIFIED_PARTY_ID)                                        AS PAR_UNIFIED_PARTY_ID
                 , Coalesce(BU.PAR_PARTY_REGRPMNT_ID,V_INT_F_PLACEMENT_HRF.PAR_PARTY_REGRPMNT_ID)                                      AS PAR_PARTY_REGRPMNT_ID
                 , Coalesce(IRIS.PAR_IRIS2000_CD,V_INT_F_PLACEMENT_HRF.PAR_IRIS2000_CD)                                                  AS PAR_IRIS2000_CD 
                 , Coalesce(BU.PAR_BU_CD,V_INT_F_PLACEMENT_HRF.PAR_BU_CD )                                                               AS PAR_BU_CD
                --------------- 
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.CITY_LN
                        ELSE     V_INT_F_PLACEMENT_HRF.CITY_LN
                   END                                                                                                                  AS CITY_LN
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.SCORE_VALUE
                        ELSE     V_INT_F_PLACEMENT_HRF.SCORE_VALUE
                   END                                                                                                                  AS SCORE_VALUE
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.SCORE_THRESHOLD
                        ELSE     V_INT_F_PLACEMENT_HRF.SCORE_THRESHOLD
                   END                                                                                                                  AS SCORE_THRESHOLD
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.SCORE_IN
                        ELSE     V_INT_F_PLACEMENT_HRF.SCORE_IN
                   END                                                                                                                  AS SCORE_IN
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.TAC_ID
                        ELSE     V_INT_F_PLACEMENT_HRF.TAC_ID
                   END                                                                                                                  AS TAC_ID
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IMEI_CD
                        ELSE     V_INT_F_PLACEMENT_HRF.IMEI_CD
                   END                                                                                                                  AS IMEI_CD
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IMSI_CD
                        ELSE     V_INT_F_PLACEMENT_HRF.IMSI_CD
                   END                                                                                                                  AS IMSI_CD
                 , INT_W_PLACEMENT_CRF_UNI.IND_INT_RESULT_ERR                                                                              AS IND_INT_RESULT_ERR
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN,-1)
                   END                                                                                                                  AS IND_DMC_COH_DOMAIN          
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD_TYPE
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD_TYPE,-1)
                   END                                                                                                                  AS IND_TECH_DMC_THRESHOLD_TYPE 
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD,-1)
                   END                                                                                                                  AS IND_TECH_DMC_THRESHOLD      
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_DMC_THRESHOLD_TYPE
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_DMC_THRESHOLD_TYPE,-1)
                   END                                                                                                                  AS IND_DMC_THRESHOLD_TYPE      
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_DMC_THRESHOLD
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_DMC_THRESHOLD,-1)
                   END                                                                                                                  AS IND_DMC_THRESHOLD           
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_VMTIERS_THRES_T
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_VMTIERS_THRES_T,-1)
                   END                                                                                                                  AS IND_TECH_VMTIERS_THRES_T    
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_VMTIERS_THRES
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_VMTIERS_THRES,-1)
                   END                                                                                                                  AS IND_TECH_VMTIERS_THRES      
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_SOC_TERMNTN_DUP
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_TERMNTN_DUP,-1)
                   END                                                                                                                  AS IND_TECH_SOC_TERMNTN_DUP    
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_SOC_TERMNTN_THRES_T
                        ELSE     COALESCE (V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_TERMNTN_THRES_T,-1)
                   END                                                                                                                  AS IND_TECH_SOC_TERMNTN_THRES_T
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_SOC_TERMNTN_THRES
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_TERMNTN_THRES,-1)
                   END                                                                                                                  AS IND_TECH_SOC_TERMNTN_THRES  
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_SOC_ADRSS_DUP
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_ADRSS_DUP,-1)
                   END                                                                                                                  AS IND_TECH_SOC_ADRSS_DUP      
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_SOC_ADRSS_THRES_T
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_ADRSS_THRES_T,-1)
                   END                                                                                                                  AS IND_TECH_SOC_ADRSS_THRES_T  
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_SOC_ADRSS_THRES
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_ADRSS_THRES,-1)
                   END                                                                                                                  AS IND_TECH_SOC_ADRSS_THRES    
                 , CASE WHEN     INT_W_PLACEMENT_CRF_UNI.LINE_ID IS NOT NULL
                             AND  V_INT_F_PLACEMENT_HRF.LINE_ID IS NULL
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN > V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                             OR  INT_W_PLACEMENT_CRF_UNI.IND_TECH_DMC_THRESHOLD < V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD
                             AND INT_W_PLACEMENT_CRF_UNI.IND_DMC_COH_DOMAIN = V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN
                        THEN     INT_W_PLACEMENT_CRF_UNI.IND_TECH_KNB_AS_DUP
                        ELSE     COALESCE(V_INT_F_PLACEMENT_HRF.IND_TECH_KNB_AS_DUP,-1)
                   END                                                                                                                  AS IND_TECH_KNB_AS_DUP         
               ,   CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}')                                         AS CREATION_TS
               ,   CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}')                                         AS LAST_MODIF_TS
               ,   1                                                                                                                    AS FRESH_IN
               ,   0                                                                                                                    AS COHERENCE_IN
               ,   0                                                                                                                    AS HOT_IN
               ,   INT_W_PLACEMENT_CRF_UNI.RUN_ID                                                                                          AS RUN_ID
FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_CRF_UNI                                                                                       INT_W_PLACEMENT_CRF_UNI
LEFT JOIN        ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_HRF                                                                                      V_INT_F_PLACEMENT_HRF
ON                 1                                                                                                             =         1
AND                INT_W_PLACEMENT_CRF_UNI.ACTE_ID                                                                               =         V_INT_F_PLACEMENT_HRF.ACTE_ID
AND                INT_W_PLACEMENT_CRF_UNI.RUN_ID                                                                                =         V_INT_F_PLACEMENT_HRF.RUN_ID
Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CRF_IRIS         IRIS
         On    IRIS.ACTE_ID            = INT_W_PLACEMENT_CRF_UNI.ACTE_ID
Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CRF_FIBER         FIBER
         On    FIBER.ACTE_ID           = INT_W_PLACEMENT_CRF_UNI.ACTE_ID
Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CRF_BU           BU
         On    BU.ACTE_ID              = INT_W_PLACEMENT_CRF_UNI.ACTE_ID
Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    V_INT_F_PLACEMENT_HRF.ORG_EDO_ID    = EdoOBK.EDO_ID
        And V_INT_F_PLACEMENT_HRF.INT_CREATED_BY_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN        = 1
Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On V_INT_F_PLACEMENT_HRF.AGENT_LOGIN_CD=CuidOBK.AGENT_ID
         And   V_INT_F_PLACEMENT_HRF.INT_CREATED_BY_DT  >= CuidOBK.HABILL_BEGIN_DT 
         And   V_INT_F_PLACEMENT_HRF.INT_CREATED_BY_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))  
      
WHERE              1                                                                                                             =         1
Qualify Row_Number() Over (Partition by INT_W_PLACEMENT_CRF_UNI.ACTE_ID  Order by INT_W_PLACEMENT_CRF_UNI.INT_CREATED_BY_TS Desc)=1  ;
.if errorcode <> 0 then .quit 1
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;
