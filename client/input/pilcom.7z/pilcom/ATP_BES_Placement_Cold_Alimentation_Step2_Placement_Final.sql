-- $HEADER: mm2pco/current/sql/ATP_BES_Placement_Cold_Alimentation_Step2_Placement_Final.sql 13_05#17 26-JUN-2019 11:39:11 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Cold_Alimentation_Step2_Placement_Final.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/03/2014      HZO         Creation
-- 19/08/2014      HZO         Indus
-- 18/09/2015      MDE         Modif/Evol
-- 09/12/2016      HOB         MODIF VA
-- 12/04/2017      HLA         Modification
-- 10/07/2017      HOB         Evol
-- 14/05/2019      TCL         Evol : Hierachisation IOBSP avec le bon nom de champ
-- 16/11/2020      EVI         PILCOM-613 : Vue Chewbacca
-- 22/09/2021      EVI         PILCOM-792 : Gestion Retour/Annulation DSTAR
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 :  SEQ_PANIER pour les Placements BESTAR                                             ----
----------------------------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.BESTAR_BASKET_PRODUCT_SEQ
(
   ID_PANIER     Varchar(45)        ,
   SEQ_PANIER    SMALLINT           ,
   ID_PRODUIT    Varchar(30)        ,
   NUM_SERIE     Varchar(20)        ,
   NUM_LIGNE     Number         
)
Primary Index (
    ID_PANIER, SEQ_PANIER,NUM_SERIE,ID_PRODUIT
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.BESTAR_BASKET_PRODUCT_SEQ Column( ID_PANIER, SEQ_PANIER,NUM_SERIE,ID_PRODUIT);
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Calcul du bon SEQ_PANIER pour les Placements BESTAR                                             ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_TERADATA_USER}.BESTAR_BASKET_PRODUCT_SEQ
  (
   ID_PANIER          ,
   SEQ_PANIER         ,
   ID_PRODUIT         ,
   NUM_SERIE          ,
   NUM_LIGNE     
  )
 Select
 
   ID_PANIER           ,
   Case when Basket.QUANTITE = 1 
    Then ( Row_Number() over( order by id_panier,ID_PRODUCT,num_serie  ) - Rank() over( order by id_panier ,ID_PRODUCT,num_serie  ) + 1 )
   else Quantite.ID_QUANTITE
   End        as SEQ_PANIER,
   ID_PRODUCT          ,
   NUM_SERIE           ,
   NUM_LIGNE           
 FROM
 ${KNB_CSM_GLB_PIL_V}.CSM_F_CBK_BASKET_PRODUCT Basket 
   Inner Join ${KNB_PCO_TMP}.ORD_T_PILCOM_GEN_QUANTITY Quantite
    On Basket.QUANTITE = Quantite.REF_QUANTITE

;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.BESTAR_BASKET_PRODUCT_SEQ;
.if errorcode <> 0 then .quit 1
    

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1       
(
   ACTE_ID                    ,
   EXTERNAL_ACTE_ID           ,
   INTRNL_SOURCE_ID           ,
   ID_PANIER                  ,
   SEQ_PANIER                 ,
   ORDER_DEPOSIT_DT           ,
   ORDER_DEPOSIT_TS           ,
   CODE_EAN                   ,
   CODE_OT                    ,
   TYPE_PAIEMENT              ,
   SOUS_TYPE_PAIEMENT         ,
   NUM_LIGNE                  ,
   CUID                       ,
   USER_ID                    ,
   ORG_REF_TRAV               ,
   ORG_AGENT_ID               ,
   ORG_AGENT_IOBSP            ,
   ORG_POC_XI                 ,
   ORG_NOM                    ,
   ORG_PRENOM                 ,
   ORG_GROUPE_ID              ,
   ORG_GROUPE_ID_HIER         ,
   ORG_ACTVT_REEL             ,
   ORG_RESP_REF_TRAV          ,
   ORG_RESP_AGENT_ID          ,
   ORG_RESP_XI                ,
   ORG_RESP_ACTVT_REEL        ,
   CODE_CDR                   ,
   EDO_ID                     ,
   FLAG_PLT_CONV              ,
   FLAG_PLT_SCH               ,
   FLAG_TEAM_MKT              ,
   FLAG_TYPE_CMP              ,
   FLAG_TYPE_GEO              ,
   FLAG_TYPE_CPT_NTK          ,
   TYPE_EDO                   ,
   ORG_EDO_IOBSP              ,
   NETWRK_TYP_EDO_ID          ,
   CODE_SOUS_FAMILLE          ,
   QUANTITE                   ,
   CA_GLOBALE                 ,
   CA_LINE                    ,
   TVA_GLOBALE_NU             ,
   TVA_LINE_NU                ,
   MSISDN_NU                  ,
   PAR_EMAIL                  ,
   PRESFACT_CO_PRECED         ,
   DMC_LINE_ID                ,
   DMC_MASTER_LINE_ID         ,
   PAR_DEPARTMNT_ID           ,
   PAR_BU_CD                  ,
   PAR_POSTAL_CD              ,
   PAR_INSEE_CD               ,
   CONTRCT_DT_SIGN_PREC       ,
   CONTRCT_DT_FIN_PREC        ,
   CONTRCT_DT_SIGN_POST       ,
   CONTRCT_DUREE_ENG          ,
   CONTRCT_UNIT_ENG           ,
   PAR_BILL_ADRESS_1          ,
   PAR_BILL_ADRESS_2          ,
   PAR_BILL_ADRESS_3          ,
   PAR_BILL_ADRESS_4          ,
   PAR_BILL_VILLE             ,
   PAR_BILL_CD_POSTAL         ,
   PAR_DO                     ,
   PAR_USCM                   ,
   PAR_USCM_DS                ,
   PAR_USCM_USCM_DS           ,
   PAR_USCM_REGUSCM           ,
   PAR_USCM_REGUSCM_DS        ,
   PAR_LASTNAME               ,
   PAR_FIRSTNAME              ,
   PAR_TYPE                   ,
   PAR_SCORE_NU_MOB           ,
   PAR_SCORE_IN_MOB           ,
   PAR_TRESHOLD_NU_MOB        ,
   CLIENT_NU                  ,
   DOSSIER_NU                 ,
   PAR_IMSI                   ,
   PAR_AID                    ,
   PAR_ND                     ,
   PAR_MOB_IMEI               ,
   PAR_MOB_TAC                ,
   PAR_MOB_SIM                ,
   PAR_GEO_MACROZONE          ,
   PAR_UNIFIED_PARTY_ID       ,
   PAR_PARTY_REGRPMNT_ID      ,
   PAR_CID_ID                 ,
   PAR_PID_ID                 ,
   PAR_FIRST_IN               ,
   PAR_IRIS2000_CD            ,
   PAR_FIBER_IN               ,
   TYPE_VENTE                 ,
   PANIER_ID_ORIGINE          ,
   ACTE_ID_CANCELED           ,
   ACTE_ID_RETURN             ,
   ORDER_CANCELING_DT         ,
   ORDER_CANCELING_DS         ,
   HOT_IN                     ,
   CREATION_TS                ,
   LAST_MODIF_TS              ,
   FRESH_IN                   ,
   COHERENCE_IN               ,
   RUN_ID
)
Select
  Placement.ACTE_ID                                             as ACTE_ID                    ,
  Placement.EXTERNAL_ACTE_ID                                    as EXTERNAL_ACTE_ID           ,
  Placement.INTRNL_SOURCE_ID                                    as INTRNL_SOURCE_ID           ,
  Placement.ID_PANIER                                           as ID_PANIER                  ,
  Placement.SEQ_PANIER                                          as SEQ_PANIER                 ,
  Placement.ORDER_DEPOSIT_DT                                    as ORDER_DEPOSIT_DT           ,
  Placement.ORDER_DEPOSIT_TS                                    as ORDER_DEPOSIT_TS           ,
  Placement.CODE_EAN                                            as CODE_EAN                   ,
  Null    ,--PRODUCT.ID_REASON                                             as CODE_OT                    ,
  Null    ,-- BASKET.TYPE_PAIEMENT                                          as TYPE_PAIEMENT              ,
  Null    ,--BASKET.SOUS_TYPE_PAIEMENT                                     as SOUS_TYPE_PAIEMENT         ,
  SEQPanier.NUM_LIGNE                                           as NUM_LIGNE                  ,
  Placement.CUID                                                as CUID                       ,
  Placement.USER_ID                                             as USER_ID                    ,
  Placement.ORG_REF_TRAV                                        as ORG_REF_TRAV               ,
  Placement.ORG_AGENT_ID                                        as ORG_AGENT_ID               ,
      Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
      End                                                       as ORG_AGENT_IOBSP       ,
  Placement.ORG_POC_XI                                          as ORG_POC_XI                 ,
  RefCUID.ORG_NOM                                               as ORG_NOM                    ,
  RefCUID.ORG_PRENOM                                            as ORG_PRENOM                 ,
  Placement.ORG_GROUPE_ID                                       as ORG_GROUPE_ID              ,
  Placement.ORG_GROUPE_ID_HIER                                  as ORG_GROUPE_ID_HIER         ,
  Placement.ORG_ACTVT_REEL                                      as ORG_ACTVT_REEL             ,
  Placement.ORG_RESP_REF_TRAV                                   as ORG_RESP_REF_TRAV          ,
  Placement.ORG_RESP_AGENT_ID                                   as ORG_RESP_AGENT_ID          ,
  Placement.ORG_RESP_XI                                         as ORG_RESP_XI                ,
  Placement.ORG_RESP_ACTVT_REEL                                 as ORG_RESP_ACTVT_REEL        ,
  Placement.CODE_CDR                                            as CODE_CDR                   ,
  RefO3.EDO_ID                                                  as EDO_ID                     ,
  RefO3.FLAG_PLT_CONV                                           as FLAG_PLT_CONV              ,
  RefO3.FLAG_PLT_SCH                                            as FLAG_PLT_SCH               ,
  Placement.FLAG_TEAM_MKT                                       as FLAG_TEAM_MKT              ,
  Placement.FLAG_TYPE_CMP                                       as FLAG_TYPE_CMP              ,
  RefO3.FLAG_TYPE_GEO                                           as FLAG_TYPE_GEO              ,
  RefO3.FLAG_TYPE_CPT_NTK                                       as FLAG_TYPE_CPT_NTK          ,
  RefO3.TYPE_EDO                                                as TYPE_EDO                   ,
  Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
  End                                                           as ORG_EDO_IOBSP              ,
  RefO3.NETWRK_TYP_EDO_ID                                       as NETWRK_TYP_EDO_ID          ,
  Placement.CODE_SOUS_FAMILLE                                   as CODE_SOUS_FAMILLE          ,
  Placement.QUANTITE                                            as QUANTITE                   ,
  Placement.CA_GLOBALE                                          as CA_GLOBALE                 ,
  Placement.CA_LINE                                             as CA_LINE                    ,
  Placement.TVA_GLOBALE_NU                                      as TVA_GLOBALE_NU             ,
  Placement.TVA_LINE_NU                                         as TVA_LINE_NU                ,
  Placement.MSISDN_NU                                           as MSISDN_NU                  ,
  Placement.PAR_EMAIL                                           as PAR_EMAIL                  ,
  Placement.PRESFACT_CO_PRECED                                  as PRESFACT_CO_PRECED         ,
  Placement.DMC_LINE_ID                                         as DMC_LINE_ID                ,
  Placement.DMC_MASTER_LINE_ID                                  as DMC_MASTER_LINE_ID         ,
  Placement.PAR_DEPARTMNT_ID                                    as PAR_DEPARTMNT_ID           ,
  Placement.PAR_BU_CD                                           as PAR_BU_CD                  ,
  Placement.PAR_POSTAL_CD                                       as PAR_POSTAL_CD              ,
  Placement.PAR_INSEE_CD                                        as PAR_INSEE_CD               ,
  Placement.CONTRCT_DT_SIGN_PREC                                as CONTRCT_DT_SIGN_PREC       ,
  Placement.CONTRCT_DT_FIN_PREC                                 as CONTRCT_DT_FIN_PREC        ,
  Placement.CONTRCT_DT_SIGN_POST                                as CONTRCT_DT_SIGN_POST       ,
  Placement.CONTRCT_DUREE_ENG                                   as CONTRCT_DUREE_ENG          ,
  Placement.CONTRCT_UNIT_ENG                                    as CONTRCT_UNIT_ENG           ,
  Placement.PAR_BILL_ADRESS_1                                   as PAR_BILL_ADRESS_1          ,
  Placement.PAR_BILL_ADRESS_2                                   as PAR_BILL_ADRESS_2          ,
  Placement.PAR_BILL_ADRESS_3                                   as PAR_BILL_ADRESS_3          ,
  Placement.PAR_BILL_ADRESS_4                                   as PAR_BILL_ADRESS_4          ,
  Placement.PAR_BILL_VILLE                                      as PAR_BILL_VILLE             ,
  Placement.PAR_BILL_CD_POSTAL                                  as PAR_BILL_CD_POSTAL         ,
  Placement.PAR_DO                                              as PAR_DO                     ,
  Placement.PAR_USCM                                            as PAR_USCM                   ,
  Placement.PAR_USCM_DS                                         as PAR_USCM_DS                ,
  Placement.PAR_USCM_USCM_DS                                    as PAR_USCM_USCM_DS           ,
  Placement.PAR_USCM_REGUSCM                                    as PAR_USCM_REGUSCM           ,
  Placement.PAR_USCM_REGUSCM_DS                                 as PAR_USCM_REGUSCM_DS        ,
  Placement.PAR_LASTNAME                                        as PAR_LASTNAME               ,
  Placement.PAR_FIRSTNAME                                       as PAR_FIRSTNAME              ,
  Placement.PAR_TYPE                                            as PAR_TYPE                   ,
  Placement.PAR_SCORE_NU_MOB                                    as PAR_SCORE_NU_MOB           ,
  Placement.PAR_SCORE_IN_MOB                                    as PAR_SCORE_IN_MOB           ,
  Placement.PAR_TRESHOLD_NU_MOB                                 as PAR_TRESHOLD_NU_MOB        ,
  Coalesce(ClientDos.CLIENT_NU ,Placement.CLIENT_NU)            as CLIENT_NU                  ,
  Coalesce(ClientDos.DOSSIER_NU,Placement.DOSSIER_NU ,Placement.MSISDN_NU)   as DOSSIER_NU    ,
  Coalesce(ClientDos.DOSSIER_NU_IMSI ,Placement.PAR_IMSI)       as PAR_IMSI                   ,
  Placement.PAR_AID                                             as PAR_AID                    ,
  Placement.PAR_ND                                              as PAR_ND                     ,
  Placement.PAR_MOB_IMEI                                        as PAR_MOB_IMEI               ,
  Placement.PAR_MOB_TAC                                         as PAR_MOB_TAC                ,
  Placement.PAR_MOB_SIM                                         as PAR_MOB_SIM                ,
  Placement.PAR_GEO_MACROZONE                                   as PAR_GEO_MACROZONE          ,
  Placement.PAR_UNIFIED_PARTY_ID                                as PAR_UNIFIED_PARTY_ID       ,
  Placement.PAR_PARTY_REGRPMNT_ID                               as PAR_PARTY_REGRPMNT_ID      ,
  Placement.PAR_CID_ID                                          as PAR_CID_ID                 ,
  Placement.PAR_PID_ID                                          as PAR_PID_ID                 ,
  Placement.PAR_FIRST_IN                                        as PAR_FIRST_IN               ,
  Placement.PAR_IRIS2000_CD                                     as PAR_IRIS2000_CD            ,
  Placement.PAR_FIBER_IN                                        as PAR_FIBER_IN               ,
  Placement.TYPE_VENTE                                          as TYPE_VENTE                 ,
  Placement.PANIER_ID_ORIGINE                                   as PANIER_ID_ORIGINE          ,
  Placement.ACTE_ID_CANCELED                                    as ACTE_ID_CANCELED           ,
  Placement.ACTE_ID_RETURN                                      as ACTE_ID_RETURN             ,
  Placement.ORDER_CANCELING_DT                                  as ORDER_CANCELING_DT         ,
  Placement.ORDER_CANCELING_DS                                  as ORDER_CANCELING_DS         ,
  1                                                             as HOT_IN                     ,
  Current_Timestamp(0)                                          as CREATION_TS                ,
  Current_Timestamp(0)                                          as LAST_MODIF_TS              ,
  1                                                             as FRESH_IN                   ,
  0                                                             as COHERENCE_IN               ,
  Placement.RUN_ID                                              as RUN_ID                     
From
  --On prend tout le contenu de la table miroir tmp
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_C_EXTR Placement
  --Enrichissement du CUID
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_C_CUID RefCUID
    On    Placement.ACTE_ID           = RefCUID.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RefCUID.ORDER_DEPOSIT_DT
  --Enrichissement d'O3
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_C_O3 RefO3
    On    Placement.ACTE_ID           = RefO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RefO3.ORDER_DEPOSIT_DT
  --Enrichissement Client_nu/dossier_nu
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_CLIENT ClientDos
    On    Placement.ACTE_ID           = ClientDos.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = ClientDos.ORDER_DEPOSIT_DT
   Left Outer Join 
   ( Select ID_PANIER, SEQ_PANIER,ID_PRODUIT,Num_Serie,Num_ligne
   from ${KNB_TERADATA_USER}.BESTAR_BASKET_PRODUCT_SEQ 
   Where Num_Serie is not null ) SEQPanier
   On    Placement.ID_PANIER          = SEQPanier.ID_PANIER 
       And Placement.SEQ_PANIER       = SEQPanier.SEQ_PANIER
       And Placement.CODE_EAN         = SEQPanier.ID_PRODUIT
       And Placement.PAR_MOB_IMEI      =SEQPanier.Num_Serie 
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    RefO3.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Placement.ORG_AGENT_ID=CuidOBK.AGENT_ID
      And  Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
      And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))  
   Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By Placement.ORDER_DEPOSIT_TS asc)=1     
;

.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1;
.if errorcode <> 0 then .quit 1

.quit 0
