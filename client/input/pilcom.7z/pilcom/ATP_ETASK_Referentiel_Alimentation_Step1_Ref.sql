-- $HEADER: mm2pco/current/sql/ATP_ETASK_Referentiel_Alimentation_Step1_Ref.sql 13_05#10 12-JAN-2017 15:05:07 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ETASK_Referentiel_Alimentation_Step1_Ref.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/11/2014      MDE         Creation
-- 06/01/2015      HFO         MODIFICATION
-- 13/10/2015      MDE         MODIF:EVOL
-- 27/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
--------------------------------------------------------------------------------


.set width 2000;



Delete From ${KNB_PCO_TMP}.ORD_W_REF_ETK_1 All;
.if errorcode <> 0 then .quit 1
--------------Step 1 32R des commandes Online  

 Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK_1
(
  EXTERNAL_ORDER_ID                                ,
  ORDER_DEPOSIT_DT                                 ,
  PARSIFAL_ORDER_ID                                ,
  EXT_APPLI_ID                                     ,
  ORDER_DEPOSIT_TS                                 ,
  AGENT_ID                                         ,
  DISTRBTN_CHANNL_ID                               ,
  CUSTOMER_CIVILITY_CD                             ,
  CUSTOMER_LAST_NM                                 ,
  CUSTOMER_FIRST_NM                                ,
  CUSTOMER_SIRET_CD                                ,
  CUSTOMER_BSS_ID                                  ,
  CUSTOMER_FGT_ID                                  ,
  CUSTOMER_ND_DS                                   ,
  CUSTOMER_MSISDN_NU                               ,
  CLIENT_NU                                        ,
  PAR_IMSI                                         ,
  CUSTOMER_CLIENT_ADV_NU                           ,
  ORDR_TYPE_IN                                     ,
  JOB_ID                                           ,
  JOB_NAME                                         ,
  EDO_ID                                           ,
  FLAG_PLT_CONV_NB                                 ,
  TYPE_EDO_ID                                      ,
  NETWRK_TYP_EDO_ID                                ,
  FLAG_TYPE_GEO_CD                                 ,
  FLAG_TYPE_CPT_NTK_NU                             ,
  FLAG_TYPE_PTN_NTK_NU                             ,
  ORG_CANAL_ID                                     ,
  ORG_CHANEL_CD                                    ,
  ORG_SUB_CHANEL_CD                                ,
  ORG_SUB_SUB_CHANEL_CD                            ,
  ORG_REM_CHANEL_CD                                ,
  ORG_GT_ACTIVITY                                  ,
  ORG_FIDELISATION                                 ,
  ORG_WEB_ACTIVITY                                 ,
  ORG_AUTO_ACTIVITY                                ,
  STORE_NM                                         ,
  LAST_MODIF_TS                                    ,
  FLAG_TEAM_MKT_NB                                 ,
  FLAG_TYPE_CMP_NU                                 ,
  SOURCE_CD                                        ,
  SERVICE_ACCESS_ID                                ,
  LAST_TRT_PARSIFAL_ID                             ,
  ORDR_ID                                          ,
  ORDR_ORGN_DS                                     ,
  DMC_LINE_ID                                      ,
  DMC_MASTER_LINE_ID                               ,
  DEPARTMNT_ID                                     ,
  BU_CD                                            ,
  POSTAL_CD                                        ,
  INSEE_CD                                         ,
  PAR_IRIS2000_CD                                  ,
  PAR_FIBER_IN                                      
)
  Select 
  Web.SOFT_RESLT_PARSIFAL_ID                                      as EXTERNAL_ORDER_ID         ,
  Web.ORDR_CREATN_DATE                                            as ORDER_DEPOSIT_DT          ,
  Null                                                            as PARSIFAL_ORDER_ID         ,
  Null                                                            as EXT_APPLI_ID              ,
  Web.ORDR_CREATN_DT                                              as ORDER_DEPOSIT_TS          ,
  Null                                                            as AGENT_ID                  ,
 'SCC'                                                            as DISTRBTN_CHANNL_ID        ,
  Null                                                            as CUSTOMER_CIVILITY_CD      ,
  Null                                                            as CUSTOMER_LAST_NM          ,
  Null                                                            as CUSTOMER_FIRST_NM         ,
  Null                                                            as CUSTOMER_SIRET_CD         ,
  Null                                                            as CUSTOMER_BSS_ID           ,
  Null                                                            as CUSTOMER_FGT_ID           ,
  Null                                                            as CUSTOMER_ND_DS            ,
  Null                                                            as CUSTOMER_MSISDN_NU        ,
  Null                                                            as CLIENT_NU                 ,
  Null                                                            as PAR_IMSI                  ,
  Null                                                            as CUSTOMER_CLIENT_ADV_NU    ,
  Null                                                            as ORDR_TYPE_IN              ,
  Null                                                            as JOB_ID                    ,
  Null                                                            as JOB_NAME                  ,
  Null                                                            as EDO_ID                    ,
  Null                                                            as FLAG_PLT_CONV_NB          ,
  Null                                                            as TYPE_EDO_ID               ,
  Null                                                            as NETWRK_TYP_EDO_ID         ,
  Null                                                            as FLAG_TYPE_GEO_CD          ,
  Null                                                            as FLAG_TYPE_CPT_NTK_NU      ,
  Null                                                            as FLAG_TYPE_PTN_NTK_NU      ,
  Null                                                            as ORG_CANAL_ID              ,
  Null                                                            as ORG_CHANEL_CD             ,
  Null                                                            as ORG_SUB_CHANEL_CD         ,
  Null                                                            as ORG_SUB_SUB_CHANEL_CD     ,
  Null                                                            as ORG_REM_CHANEL_CD         ,
  Null                                                            as ORG_GT_ACTIVITY           ,
  Null                                                            as ORG_FIDELISATION          ,
  Null                                                            as ORG_WEB_ACTIVITY          ,
  Null                                                            as ORG_AUTO_ACTIVITY         ,
  Null                                                            as STORE_NM                  ,
  Web.LAST_MODIF_TS                                               as LAST_MODIF_TS             ,
  Null                                                            as FLAG_TEAM_MKT_NB          ,
  Null                                                            as FLAG_TYPE_CMP_NU          ,
  Null                                                            as SOURCE_CD                 ,
  Null                                                            as SERVICE_ACCESS_ID         ,
  Web.SOFT_RESLT_PARSIFAL_ID                                      as LAST_TRT_PARSIFAL_ID      ,
  Web.ORDR_ID                                                     as ORDR_ID                   ,
  Web.ORDR_ORGN_DS                                                as ORDR_ORGN_DS              ,
  Null                                                            as DMC_LINE_ID               ,
  Null                                                            as DMC_MASTER_LINE_ID        ,
  Null                                                            as DEPARTMNT_ID              ,
  Null                                                            as BU_CD                     ,
  Null                                                            as POSTAL_CD                 ,
  Null                                                            as INSEE_CD                  ,
  Null                                                            as PAR_IRIS2000_CD           ,
  Null                                                            as PAR_FIBER_IN
From
  ${KNB_SPO_VM_V}.VF_ORD_F_ORDR_OL_R_VM Web 
  Where
  (1=1)
  And Web.SOFT_RESLT_PARSIFAL_ID is not null 
  And (substr(Web.SOFT_RESLT_PARSIFAL_ID, 1,3)) like '32R' 
  And current_date - cast(Web.ORDR_CREATN_DATE as date) <= 100
Qualify Row_number() over (Partition By Web.SOFT_RESLT_PARSIFAL_ID Order By Web.ORDR_CREATN_DT asc)=1
;

.if errorcode <> 0 then .quit 1

--------------Step 2 32R associés aux commandes Online ayant un identifiant « etask »

 Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK_1
(
  EXTERNAL_ORDER_ID                                ,
  ORDER_DEPOSIT_DT                                 ,
  PARSIFAL_ORDER_ID                                ,
  EXT_APPLI_ID                                     ,
  ORDER_DEPOSIT_TS                                 ,
  AGENT_ID                                         ,
  DISTRBTN_CHANNL_ID                               ,
  CUSTOMER_CIVILITY_CD                             ,
  CUSTOMER_LAST_NM                                 ,
  CUSTOMER_FIRST_NM                                ,
  CUSTOMER_SIRET_CD                                ,
  CUSTOMER_BSS_ID                                  ,
  CUSTOMER_FGT_ID                                  ,
  CUSTOMER_ND_DS                                   ,
  CUSTOMER_MSISDN_NU                               ,
  CLIENT_NU                                        ,
  PAR_IMSI                                         ,
  CUSTOMER_CLIENT_ADV_NU                           ,
  ORDR_TYPE_IN                                     ,
  JOB_ID                                           ,
  JOB_NAME                                         ,
  EDO_ID                                           ,
  FLAG_PLT_CONV_NB                                 ,
  TYPE_EDO_ID                                      ,
  NETWRK_TYP_EDO_ID                                ,
  FLAG_TYPE_GEO_CD                                 ,
  FLAG_TYPE_CPT_NTK_NU                             ,
  FLAG_TYPE_PTN_NTK_NU                             ,
  ORG_CANAL_ID                                     ,
  ORG_CHANEL_CD                                    ,
  ORG_SUB_CHANEL_CD                                ,
  ORG_SUB_SUB_CHANEL_CD                            ,
  ORG_REM_CHANEL_CD                                ,
  ORG_GT_ACTIVITY                                  ,
  ORG_FIDELISATION                                 ,
  ORG_WEB_ACTIVITY                                 ,
  ORG_AUTO_ACTIVITY                                ,
  STORE_NM                                         ,
  LAST_MODIF_TS                                    ,
  FLAG_TEAM_MKT_NB                                 ,
  FLAG_TYPE_CMP_NU                                 ,
  SOURCE_CD                                        ,
  SERVICE_ACCESS_ID                                ,
  LAST_TRT_PARSIFAL_ID                             ,
  ORDR_ID                                          ,
  ORDR_ORGN_DS                                     ,
  DMC_LINE_ID                                      ,
  DMC_MASTER_LINE_ID                               ,
  DEPARTMNT_ID                                     ,
  BU_CD                                            ,
  POSTAL_CD                                        ,
  INSEE_CD                                         ,
  PAR_IRIS2000_CD                                  ,
  PAR_FIBER_IN                                      
)
  Select 
  Coalesce(RefId.LAST_TRT_PARSIFAL_ID,RefId.EXTERNAL_ORDR_ID)     as  EXTERNAL_ORDER_ID         ,
  RefId.DEPOSIT_DT                                                as ORDER_DEPOSIT_DT          ,
  cast(RefId.PARSIFAL_ORDR_ID As DECIMAL(32,0))                   as PARSIFAL_ORDER_ID         ,
  RefId.OT_ID                                                     as EXT_APPLI_ID              ,
  RefId.DEPOSIT_TS                                                as ORDER_DEPOSIT_TS          ,
  Case When (  char_length(trim(DEPSTR_ID))=8
             and  lower(substr(RefId.DEPSTR_ID, 1,1)) between 'a' and 'z'
             and  lower(substr(RefId.DEPSTR_ID, 2,1)) between 'a' and 'z'
             and  lower(substr(RefId.DEPSTR_ID, 3,1)) between 'a' and 'z'
             and  lower(substr(RefId.DEPSTR_ID, 4,1))  between 'a' and 'z' 
             and  substr(RefId.DEPSTR_ID, 5,1)  between '0' and '9'
             and  substr(RefId.DEPSTR_ID, 6,1)  between '0' and '9'
             and  substr(RefId.DEPSTR_ID, 7,1)  between '0' and '9'
             and  substr(RefId.DEPSTR_ID, 8,1)  between '0' and '9'
        )
  Then RefId.DEPSTR_ID
       Else NULL
  End                                                             as AGENT_ID                  ,
  Case When  RefJb.JOB_ID = '8104'
          Then   RefId.FORMLR_CD
        Else RefId.DISTRIBTN_CHANNL_ID
  End                                                            as DISTRBTN_CHANNL_ID        ,
  RefId.PERSON_SALUTATION_CD                                      as CUSTOMER_CIVILITY_CD      ,
  RefId.LAST_NAME_NM                                              as CUSTOMER_LAST_NM          ,
  RefId.FIRST_NAME_NM                                             as CUSTOMER_FIRST_NM         ,
  RefId.SIRET_CD                                                  as CUSTOMER_SIRET_CD         ,
  RefId.BSS_PARTY_EXTERNL_ID                                      as CUSTOMER_BSS_ID           ,
  RefId.FREG_PARTY_EXTERNL_ID                                     as CUSTOMER_FGT_ID           ,
  RefId.TERMINTN_VALUE_DS                                         as CUSTOMER_ND_DS            ,
  RefId.CUST_MSISDN_DS                                            as CUSTOMER_MSISDN_NU        ,
  Null                                                            as CLIENT_NU                 ,
  Null                                                            as PAR_IMSI                  ,
  RefId.ADV_CLIENT_NU                                             as CUSTOMER_CLIENT_ADV_NU    ,
  RefId.ORDR_TYPE_IN                                              as ORDR_TYPE_IN              ,
  RefId.JOB_ID                                                    as JOB_ID                    ,
  RefJb.JOB_DS                                                    as JOB_NAME                  ,
  Null                                                            as EDO_ID                    ,
  Null                                                            as FLAG_PLT_CONV_NB          ,
  Null                                                            as TYPE_EDO_ID               ,
  Null                                                            as NETWRK_TYP_EDO_ID         ,
  Null                                                            as FLAG_TYPE_GEO_CD          ,
  Null                                                            as FLAG_TYPE_CPT_NTK_NU      ,
  Null                                                            as FLAG_TYPE_PTN_NTK_NU      ,
  Null                                                            as ORG_CANAL_ID              ,
  Null                                                            as ORG_CHANEL_CD             ,
  Null                                                            as ORG_SUB_CHANEL_CD         ,
  Null                                                            as ORG_SUB_SUB_CHANEL_CD     ,
  Null                                                            as ORG_REM_CHANEL_CD         ,
  Null                                                            as ORG_GT_ACTIVITY           ,
  Null                                                            as ORG_FIDELISATION          ,
  Null                                                            as ORG_WEB_ACTIVITY          ,
  Null                                                            as ORG_AUTO_ACTIVITY         ,
  RefId.DISTRIBTN_ENTT_ID                                         as STORE_NM                  ,
  RefId.LAST_MODIF_TS                                             as LAST_MODIF_TS             ,
  Null                                                            as FLAG_TEAM_MKT_NB          ,
  Null                                                            as FLAG_TYPE_CMP_NU          ,
  Null                                                            as SOURCE_CD                 ,
  Null                                                            as SERVICE_ACCESS_ID         ,
  RefId.LAST_TRT_PARSIFAL_ID                                      as LAST_TRT_PARSIFAL_ID      ,
  Web.ORDR_ID                                                     as ORDR_ID                   ,
  Web.ORDR_ORGN_DS                                                as ORDR_ORGN_DS              ,
  Null                                                            as DMC_LINE_ID               ,
  Null                                                            as DMC_MASTER_LINE_ID        ,
  Null                                                            as DEPARTMNT_ID              ,
  Null                                                            as BU_CD                     ,
  Null                                                            as POSTAL_CD                 ,
  Null                                                            as INSEE_CD                  ,
  Null                                                            as PAR_IRIS2000_CD           ,
  Null                                                            as PAR_FIBER_IN
From
  ${KNB_COM_SOC_V}.V_ORD_F_OT RefId
     Inner Join   ${KNB_SPO_VM_V}.VF_ORD_F_ORDR_OL_R_VM Web
      --Jointure Commande 
       On  RefId.OT_ID =  cast (Web.ETASK_RESLT_ETASK_ID as BIGINT)
   Left Outer Join   ${KNB_PCO_SOC}.V_ORD_R_OT_BO_PILCOM RefJb
    On    RefId.JOB_ID = RefJb.JOB_ID
      And RefJb.CURRENT_IN    = 1
      And RefJb.FRESH_IN      = 1
      And RefJb.CLOSURE_DT    Is Null
Where
  (1=1)
   --On ne tient compte que des OT TERMINE
  --And  RefId.OT_SOURCE_ID='OT TERMINE'
  -- On regarde l'opération sur la commande 
  And ( RefId.EXTERNAL_ORDR_ID is not null or  RefId.LAST_TRT_PARSIFAL_ID is not null )
  And current_date - cast(RefId.DEPOSIT_DT as date) <= 100
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORD_W_REF_ETK_1 RefOtExclu
    Where
      (1=1)
      And Coalesce(RefId.LAST_TRT_PARSIFAL_ID,RefId.EXTERNAL_ORDR_ID )     = RefOtExclu.EXTERNAL_ORDER_ID
    
  )
  And RefId.LAST_TRT_PARSIFAL_ID not in ('32R00000000000000000','32R01000000000000000','32R01000000739957754','32R01000000737088003','32R10000000000000000','32R.................')
Qualify Row_number() over (Partition By Coalesce(RefId.LAST_TRT_PARSIFAL_ID,RefId.EXTERNAL_ORDR_ID) Order By RefId.DEPOSIT_TS asc)=1
;

.if errorcode <> 0 then .quit 1

--------------Step 3 OT nn existant dans ORD_F_ORDR_OL_R_VM  mais qui ont un job_id renseigné

Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK_1
(
  EXTERNAL_ORDER_ID                                ,
  ORDER_DEPOSIT_DT                                 ,
  PARSIFAL_ORDER_ID                                ,
  EXT_APPLI_ID                                     ,
  ORDER_DEPOSIT_TS                                 ,
  AGENT_ID                                         ,
  DISTRBTN_CHANNL_ID                               ,
  CUSTOMER_CIVILITY_CD                             ,
  CUSTOMER_LAST_NM                                 ,
  CUSTOMER_FIRST_NM                                ,
  CUSTOMER_SIRET_CD                                ,
  CUSTOMER_BSS_ID                                  ,
  CUSTOMER_FGT_ID                                  ,
  CUSTOMER_ND_DS                                   ,
  CLIENT_NU                                        ,
  PAR_IMSI                                         ,
  CUSTOMER_MSISDN_NU                               ,
  CUSTOMER_CLIENT_ADV_NU                           ,
  ORDR_TYPE_IN                                     ,
  JOB_ID                                           ,
  JOB_NAME                                         ,
  EDO_ID                                           ,
  FLAG_PLT_CONV_NB                                 ,
  TYPE_EDO_ID                                      ,
  NETWRK_TYP_EDO_ID                                ,
  FLAG_TYPE_GEO_CD                                 ,
  FLAG_TYPE_CPT_NTK_NU                             ,
  FLAG_TYPE_PTN_NTK_NU                             ,
  ORG_CANAL_ID                                     ,
  ORG_CHANEL_CD                                    ,
  ORG_SUB_CHANEL_CD                                ,
  ORG_SUB_SUB_CHANEL_CD                            ,
  ORG_REM_CHANEL_CD                                ,
  ORG_GT_ACTIVITY                                  ,
  ORG_FIDELISATION                                 ,
  ORG_WEB_ACTIVITY                                 ,
  ORG_AUTO_ACTIVITY                                ,
  STORE_NM                                         ,
  LAST_MODIF_TS                                    ,
  FLAG_TEAM_MKT_NB                                 ,
  FLAG_TYPE_CMP_NU                                 ,
  SOURCE_CD                                        ,
  SERVICE_ACCESS_ID                                ,
  LAST_TRT_PARSIFAL_ID                             ,
  ORDR_ID                                          ,
  ORDR_ORGN_DS                                     ,
  DMC_LINE_ID                                      ,
  DMC_MASTER_LINE_ID                               ,
  DEPARTMNT_ID                                     ,
  BU_CD                                            ,
  POSTAL_CD                                        ,
  INSEE_CD                                         ,
  PAR_IRIS2000_CD                                  ,
  PAR_FIBER_IN                                          
)
  Select 
  Coalesce(RefId.LAST_TRT_PARSIFAL_ID,RefId.EXTERNAL_ORDR_ID)     as  EXTERNAL_ORDER_ID         ,
  RefId.DEPOSIT_DT                                                as ORDER_DEPOSIT_DT          ,
  cast(RefId.PARSIFAL_ORDR_ID As DECIMAL(32,0))                   as PARSIFAL_ORDER_ID         ,
  RefId.OT_ID                                                     as EXT_APPLI_ID              ,
  RefId.DEPOSIT_TS                                                as ORDER_DEPOSIT_TS          ,
  Case When (  char_length(trim(DEPSTR_ID))=8
             and  lower(substr(RefId.DEPSTR_ID, 1,1)) between 'a' and 'z'
             and  lower(substr(RefId.DEPSTR_ID, 2,1)) between 'a' and 'z'
             and  lower(substr(RefId.DEPSTR_ID, 3,1)) between 'a' and 'z'
             and  lower(substr(RefId.DEPSTR_ID, 4,1))  between 'a' and 'z' 
             and  substr(RefId.DEPSTR_ID, 5,1)  between '0' and '9'
             and  substr(RefId.DEPSTR_ID, 6,1)  between '0' and '9'
             and  substr(RefId.DEPSTR_ID, 7,1)  between '0' and '9'
             and  substr(RefId.DEPSTR_ID, 8,1)  between '0' and '9'
        )
  Then RefId.DEPSTR_ID
       Else NULL
  End                                                             as AGENT_ID                  ,
  Case When  RefJb.JOB_ID = '8104'
          Then   RefId.FORMLR_CD
        Else RefId.DISTRIBTN_CHANNL_ID
  End                                                             as DISTRBTN_CHANNL_ID        ,
  RefId.PERSON_SALUTATION_CD                                      as CUSTOMER_CIVILITY_CD      ,
  RefId.LAST_NAME_NM                                              as CUSTOMER_LAST_NM          ,
  RefId.FIRST_NAME_NM                                             as CUSTOMER_FIRST_NM         ,
  RefId.SIRET_CD                                                  as CUSTOMER_SIRET_CD         ,
  RefId.BSS_PARTY_EXTERNL_ID                                      as CUSTOMER_BSS_ID           ,
  RefId.FREG_PARTY_EXTERNL_ID                                     as CUSTOMER_FGT_ID           ,
  RefId.TERMINTN_VALUE_DS                                         as CUSTOMER_ND_DS            ,
  RefId.CUST_MSISDN_DS                                            as CUSTOMER_MSISDN_NU        ,
  Null                                                            as CLIENT_NU                 ,
  Null                                                            as PAR_IMSI                  ,
  RefId.ADV_CLIENT_NU                                             as CUSTOMER_CLIENT_ADV_NU    ,
  RefId.ORDR_TYPE_IN                                              as ORDR_TYPE_IN              ,
  RefId.JOB_ID                                                    as JOB_ID                    ,
  RefJb.JOB_DS                                                    as JOB_NAME                  ,
  Null                                                            as EDO_ID                    ,
  Null                                                            as FLAG_PLT_CONV_NB          ,
  Null                                                            as TYPE_EDO_ID               ,
  Null                                                            as NETWRK_TYP_EDO_ID         ,
  Null                                                            as FLAG_TYPE_GEO_CD          ,
  Null                                                            as FLAG_TYPE_CPT_NTK_NU      ,
  Null                                                            as FLAG_TYPE_PTN_NTK_NU      ,
  Null                                                            as ORG_CANAL_ID              ,
  Null                                                            as ORG_CHANEL_CD             ,
  Null                                                            as ORG_SUB_CHANEL_CD         ,
  Null                                                            as ORG_SUB_SUB_CHANEL_CD     ,
  Null                                                            as ORG_REM_CHANEL_CD         ,
  Null                                                            as ORG_GT_ACTIVITY           ,
  Null                                                            as ORG_FIDELISATION          ,
  Null                                                            as ORG_WEB_ACTIVITY          ,
  Null                                                            as ORG_AUTO_ACTIVITY         ,
  RefId.DISTRIBTN_ENTT_ID                                         as STORE_NM                  ,
  RefId.LAST_MODIF_TS                                             as LAST_MODIF_TS             ,
  Null                                                            as FLAG_TEAM_MKT_NB          ,
  Null                                                            as FLAG_TYPE_CMP_NU          ,
  Null                                                            as SOURCE_CD                 ,
  Null                                                            as SERVICE_ACCESS_ID         ,
  RefId.LAST_TRT_PARSIFAL_ID                                      as LAST_TRT_PARSIFAL_ID      ,
  Null                                                            as ORDR_ID                   ,
  Null                                                            as ORDR_ORGN_DS              ,
  Null                                                            as DMC_LINE_ID               ,
  Null                                                            as DMC_MASTER_LINE_ID        ,
  Null                                                            as DEPARTMNT_ID              ,
  Null                                                            as BU_CD                     ,
  Null                                                            as POSTAL_CD                 ,
  Null                                                            as INSEE_CD                  ,
  Null                                                            as PAR_IRIS2000_CD           ,
  Null                                                            as PAR_FIBER_IN
From
  ${KNB_COM_SOC_V}.V_ORD_F_OT RefId
    Inner Join  ${KNB_PCO_SOC}.V_ORD_R_OT_BO_PILCOM RefJb
    On    RefId.JOB_ID = RefJb.JOB_ID
      And RefJb.CURRENT_IN    = 1
      And RefJb.FRESH_IN      = 1
      And RefJb.CLOSURE_DT    Is Null
Where
  (1=1)
   --On ne tient compte que des OT TERMINE
 -- And  RefId.OT_SOURCE_ID='OT TERMINE'
  -- On regarde l'opération sur la commande 
  And ( RefId.EXTERNAL_ORDR_ID is not null or  RefId.LAST_TRT_PARSIFAL_ID is not null )
  And current_date - cast(RefId.DEPOSIT_DT as date) <= 100
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORD_W_REF_ETK_1 RefOtExclu
    Where
      (1=1)
      And Coalesce(RefId.LAST_TRT_PARSIFAL_ID,RefId.EXTERNAL_ORDR_ID )     = RefOtExclu.EXTERNAL_ORDER_ID
    
  )
 And RefId.LAST_TRT_PARSIFAL_ID not in ('32R00000000000000000','32R01000000000000000','32R01000000739957754','32R01000000737088003','32R10000000000000000','32R.................')
Qualify Row_number() over (Partition By Coalesce(RefId.LAST_TRT_PARSIFAL_ID,RefId.EXTERNAL_ORDR_ID) Order By RefId.DEPOSIT_TS asc)=1
;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_REF_ETK_1;
.if errorcode <> 0 then .quit 1


.quit 0
