 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ProduitRforce.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des produits Rforce
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000

--Identification des produits Rforce
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'RFORCE'                                                      As SOURCE_ID              ,
  'RFORCE'                                                      As CATALOG_ID             ,
  'Produit Externe manquant ; ( PRODUCT_ID - PRODUCT_ID_SEC ) ; ( '
        ||Coalesce(Trim(Placement.EXTERNAL_PRODUCT_ID),'')
        ||' - '
        ||Coalesce(Trim(Placement.EXTERNAL_PRODUCT_ID_SEC),'ND')
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.EXT_PRODUCT_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.EXT_PRODUCT_DS,''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  (
    Select
      'RFO'                                     As PRODUCT_TYPE               ,
      Placement.EXTERNAL_PRODUCT_ID_FINAL       As EXTERNAL_PRODUCT_ID        ,
      Placement.INT_RESULT                      As EXTERNAL_PRODUCT_ID_SEC    ,
      Null                                      As EXT_PRODUCT_DS             ,
      Count(*)                                  As VolumeCas                  ,
      Min(Placement.INT_CREATED_BY_DT)          As DateMinRecue               ,
      Max(Placement.INT_CREATED_BY_DT)          As DateMaxRecue               
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_HRF Placement
    Where
      (1=1)
      And Placement.EXTERNAL_PRODUCT_ID_FINAL   Is Not Null
      And Placement.INT_RESULT                  Not In ('ERR')
      And Placement.INT_CREATED_BY_DT           >= Current_date -30
    Group by
      PRODUCT_TYPE            ,
      EXTERNAL_PRODUCT_ID     ,
      EXTERNAL_PRODUCT_ID_SEC ,
      EXT_PRODUCT_DS          
  ) Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE Catalogue
    On    Trim(Placement.EXTERNAL_PRODUCT_ID)               = Catalogue.EXT_PRODUCT_ID_1
      And Coalesce(Placement.EXTERNAL_PRODUCT_ID_SEC,'ND')  = Catalogue.EXT_PRODUCT_ID_2
      And Catalogue.CURRENT_IN                              = 1
      And Catalogue.CLOSURE_DT                              Is Null
      And Catalogue.PERIODE_ID                              =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Catalogue.TYPE_PRODUIT            Is Null
;
.if errorcode <> 0 Then .quit 1

-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
