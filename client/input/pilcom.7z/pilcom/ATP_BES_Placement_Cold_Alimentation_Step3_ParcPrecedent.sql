-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Cold_Alimentation_Step3_ParcPrecedent.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 15/09/2015      MDE         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_PARCPRE all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_PARCPRE
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  PRESFACT_CO_PRECED      
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT       ,
  Prestation.PRESFACT_CO_FORM               as PRESFACT_CO_PRECED     
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
    On    RefId.DOSSIER_NU                = ParcADV.SRVFCDOS_DOSSIER_NU
      And RefId.CLIENT_NU                 = ParcADV.SRVFCDOS_CLIENT_NU
      And RefId.ORDER_DEPOSIT_DT            >= ParcADV.SRVFCDOS_DT_DEBUT
      And RefId.ORDER_DEPOSIT_DT            <= coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('99991231' as date format 'YYYYMMDD'))
  Inner Join ${KNB_IBU_SOC}.V_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO    = Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT      = 'O'
      And Prestation.CURRENT_IN           =1
Where
  (1=1)
  And RefId.PRESFACT_CO_PRECED Is Null
Qualify Row_Number() Over (Partition By RefId.ACTE_ID Order By Coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('99991231' as date format 'YYYYMMDD')) desc, ParcADV.SRVFCDOS_DT_DEBUT desc, ParcADV.CLOSURE_DT asc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_PARCPRE;
.if errorcode <> 0 then .quit 1

.quit 0
