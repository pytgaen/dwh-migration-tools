-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   OUT_PVC_ExtractionIndicateurCompletude.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Creation des tables TMP
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 17/06/2014      AID         Creation
--------------------------------------------------------------------------------


-- =====================================================================================--
-- DATE_DEBUT = 1er jour du mois M-1
-- DATE_FIN = J-1
-- =====================================================================================--

Create volatile Table ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR(
  MP          Date Format 'YYYYMMDD'    Not Null    ,
  DATE_DEBUT  Date Format 'YYYYMMDD'    Not Null    ,
  DATE_FIN    Date Format 'YYYYMMDD'    Not Null    
)
Primary Index (
  DATE_DEBUT
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR
(
  MP          ,
  DATE_DEBUT  ,
  DATE_FIN    
)
Select
  Add_Months(Current_Date,-1)                                                       As MP         ,
  ((Extract(Year from MP) -1900) * 10000 + Extract(Month From MP)* 100 + 1  (Date)) As DATE_DEBUT ,
  Current_Date                                                                      As DATE_FIN   
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR Column(DATE_DEBUT);
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR Column(DATE_FIN);
.if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 002 : Nb d'actes transmis à PVC                    du mois M-1 et depuis le premier à J-1 du mois M et par sources
-- 006 : Nb d'actes transmis à PVC  par équipe du mois M-1 et depuis le premier à J-1 du mois M et par sources
-- =====================================================================================--


Create volatile Table ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP(
  EXT_DT            Date Format 'YYYYMMDD'  Not Null    ,
  ACTE_ID           Bigint                  Not Null    ,
  ORDER_DEPOSIT_TS  TimeStamp(0)                        ,
  SOURCE_ID         Varchar(10)                         ,
  ACTION_ACTE       Byteint                             
)
Primary Index (
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP
(
  EXT_DT            ,
  ACTE_ID           ,
  ORDER_DEPOSIT_TS  ,
  SOURCE_ID         ,
  ACTION_ACTE       
)
Select
  Cast(Tmp.EXT_DT As Date Format 'YYYYMMDD')            as EXT_DT           ,
  Tmp.ACTE_ID                                           as ACTE_ID          ,
  Tmp.ORDER_DEPOSIT_TS                                  as ORDER_DEPOSIT_TS ,
  Tmp.SOURCE_ID                                         as SOURCE_ID        ,
  Tmp.ACTION_ACTE                                       as ACTION_ACTE      
From
  (
      Select
        COO.EXT_DT            as EXT_DT           ,
        COO.ACTE_ID           as ACTE_ID          ,
        COO.ORDER_DEPOSIT_TS  as ORDER_DEPOSIT_TS ,
        COO.SOURCE_ID         as SOURCE_ID        ,
        COO.ACTION_ACTE       as ACTION_ACTE      
      From
        ${KNB_PCO_VM}.V_ACT_E_PVC_DAY_CCO COO
        Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
          On Cast(COO.ORDER_DEPOSIT_TS as Date) between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Union All
      Select
        SCH.EXT_DT            as EXT_DT           ,
        SCH.ACTE_ID           as ACTE_ID          ,
        SCH.ORDER_DEPOSIT_TS  as ORDER_DEPOSIT_TS ,
        SCH.SOURCE_ID         as SOURCE_ID        ,
        SCH.ACTION_ACTE       as ACTION_ACTE      
      From
        ${KNB_PCO_VM}.V_ACT_E_PVC_DAY_SCH SCH
        Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
          On Cast(SCH.ORDER_DEPOSIT_TS as Date) between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Union All
      Select
        Cast(Hot.EXT_CREATION_TS  as date Format 'YYYYMMDD')            as EXT_DT           ,
        Hot.ACTE_ID                                                     as ACTE_ID          ,
        Hot.ORDER_DEPOSIT_TS                                            as ORDER_DEPOSIT_TS ,
        Hot.SOURCE_ID                                                   as SOURCE_ID        ,
        Hot.ACTION_ACTE                                                 as ACTION_ACTE      
      From
        ${KNB_PCO_VM}.V_ACT_E_PVC_DAY_HOT Hot
        Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
          On Cast(Hot.EXT_CREATION_TS as Date) between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Where
        (1=1)
        And Hot.EXT_CREATION_TS     Is Not Null
  )Tmp
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP Column(ACTE_ID);
.if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 003 : Nb de placements par source                       du mois M-1 et depuis le premier à J-1 du mois M
-- 007 : Nb de placements par source et par équipe du mois M-1 et depuis le premier à J-1 du mois M
-- =====================================================================================--


Create volatile Table ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS(
  JOUR              Date Format 'YYYYMMDD'  Not Null    ,
  SOURCES           Byteint                 Not Null    ,
  CODE_EQUIPE       Varchar(50)             Not Null    ,
  EQUIPE            Varchar(250)                        ,
  NB_PLACEMENTS     Integer                             
)
Primary Index (
  JOUR            ,
  SOURCES         ,
  CODE_EQUIPE     
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS Column(JOUR,SOURCES,CODE_EQUIPE);
.if errorcode <> 0 then .quit 1


-- Nombre de placements Chorus
Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      2                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT          between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO ext
        On    p.ORG_GROUPE_ID         = ext.EXTNL_VAL_COD_CD
          And p.INT_DEPOSIT_DT        Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD        = 'REGARDSC' 
          And ext.CURRENT_IN          = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID              = edo.EDO_ID
          And p.INT_DEPOSIT_DT        between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN          = 1
          And edo.NETWRK_TYP_EDO_ID   = 'FT'
    Where
      (1=1)
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb Placement OEE
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      3                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_OEE p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT          between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO ext
        On    p.ORG_GROUPE_ID         = ext.EXTNL_VAL_COD_CD
          And p.INT_DEPOSIT_DT        Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD        = 'REGARDSC' 
          And ext.CURRENT_IN          = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID              = edo.EDO_ID
          And p.INT_DEPOSIT_DT        between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN          = 1
          And edo.NETWRK_TYP_EDO_ID   = 'FT'
    Where
      (1=1)
      --restriction il faut que le triplet soit éligible
      And Exists
      (
        Select
          1
        From
          ${KNB_COM_SOC}.V_CAT_R_REF_PRODUCT_OEE R
        Where
          (1=1)
          And P.RESOLU_ID     =   R.RESOLU_ID
          And P.CONCLU_ID     =   R.CONCLU_ID
          And P.SSCONCLU_ID   =   R.SSCONCLU_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb Placement EDL
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      4                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_EDL P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT          between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO ext
        On    p.ORG_GROUPE_ID         = ext.EXTNL_VAL_COD_CD
          And p.INT_DEPOSIT_DT        Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD        = 'REGARDSC' 
          And ext.CURRENT_IN          = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID              = edo.EDO_ID
          And p.INT_DEPOSIT_DT        between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN          = 1
          And edo.NETWRK_TYP_EDO_ID   = 'FT'
    Where
      (1=1)
      --restriction il faut que le triplet soit éligible
      And Exists
      (
        Select
          1
        From
          ${KNB_COM_SOC}.V_CAT_R_REF_PRODUCT_EDEL R
        Where
          (1=1)
          And P.RESOLU_ID     =   R.RESOLU_ID
          And P.CONCLU_ID     =   R.CONCLU_ID
          And P.SSCONCLU_ID   =   R.SSCONCLU_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb Placement PCM
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.DATESAISIEBCR                                 As JOUR             ,
      5                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.DATESAISIEBCR           Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK ext
        On    p.PV_POINTVENTE         = ext.EXTNL_VAL_COD_CD
          And p.DATESAISIEBCR         Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD        = 'ADV'
          And ext.CURRENT_IN          = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID              = edo.EDO_ID
          And p.DATESAISIEBCR         between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN          = 1
          And edo.NETWRK_TYP_EDO_ID   = 'FT'
    Where
      (1=1)
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb Placement VAD
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.DATE_SAISIE                                   As JOUR             ,
      6                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.DATE_SAISIE             Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK ext
        On    p.PDV                   = ext.EXTNL_VAL_COD_CD
          And p.DATE_SAISIE           Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD        = 'ADV'
          And ext.CURRENT_IN          = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID              = edo.EDO_ID
          And p.DATE_SAISIE           between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN          = 1
          And edo.NETWRK_TYP_EDO_ID   = 'FT'
    Where
      (1=1)
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          


--Nb Placement Rforce
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_CREATED_BY_DT                             As JOUR             ,
      11                                              As SOURCES          ,
      Coalesce(a.org_edo_id,'-')                      As CODE_EQUIPE      ,
      Coalesce(a.org_edo_ds,'Equipe indéterminée')    As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_HRF P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_CREATED_BY_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_PCO_VM}.V_INT_F_ACTE_HRF a
        On    P.ACTE_ID             = a.ACTE_ID
    Where
      (1=1)
      and a.ORG_TYPE_EDO            = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By a.ACTE_ID_GEN Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          

--Insertion du Nombre de Commande SOFT
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.EXTERNAL_ORDER_ID                             As ACTE_ID          ,
      p.ORDER_DEPOSIT_DT                              As JOUR             ,
      1                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.ORDER_DEPOSIT_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK ext
        On    p.STORE_NAME          = ext.EXTNL_VAL_COD_CD
          And p.ORDER_DEPOSIT_DT    Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'ADV'
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID            = edo.EDO_ID
          And p.ORDER_DEPOSIT_DT    between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN        = 1
          And edo.NETWRK_TYP_EDO_ID = 'FT'
    Where
      (1=1)
      And P.HOT_IN  = 0
    Qualify Row_Number() Over (Partition By p.EXTERNAL_ORDER_ID Order By p.ORDER_DEPOSIT_DT Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS Column(JOUR,SOURCES,CODE_EQUIPE);
.if errorcode <> 0 then .quit 1











--=====================================================================================
-- 004 : Nombre de placement sans actes par source                       du mois M-1 et depuis le premier à J-1 du mois M
-- 008 : Nombre de placement sans actes par source et par Equipe du mois M-1 et depuis le premier à J-1 du mois M  
-- =====================================================================================--


Create volatile Table ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA(
  JOUR              Date Format 'YYYYMMDD'  Not Null    ,
  SOURCES           Byteint                 Not Null    ,
  CODE_EQUIPE       Varchar(50)             Not Null    ,
  EQUIPE            Varchar(250)                        ,
  NB_PLACEMENTS     Integer                             
)
Primary Index (
  JOUR            ,
  SOURCES         ,
  CODE_EQUIPE     
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1



--Nombre de placements SOFT Manquants
Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.EXTERNAL_ORDER_ID                             As ACTE_ID          ,
      p.ORDER_DEPOSIT_DT                              As JOUR             ,
      1                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.ORDER_DEPOSIT_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK ext
        On    p.STORE_NAME          = ext.EXTNL_VAL_COD_CD
          And p.ORDER_DEPOSIT_DT    Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'ADV'
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID            = edo.EDO_ID
          And p.ORDER_DEPOSIT_DT    between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN        = 1
    Where
      (1=1)
      And P.HOT_IN  = 0
      And Not Exists
      (
        Select
          1
        From
          ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT act
        Where
          (1=1)
          And p.EXTERNAL_ORDER_ID  = act.ORDER_EXTERNAL_ID
      )
    Qualify Row_Number() Over (Partition By p.EXTERNAL_ORDER_ID Order By p.ORDER_DEPOSIT_DT Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb d'acte Rforce manquant
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_CREATED_BY_DT                             As JOUR             ,
      11                                              As SOURCES          ,
      Coalesce(a.org_edo_id,'-')                      As CODE_EQUIPE      ,
      Coalesce(a.org_edo_ds,'Equipe indéterminée')    As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_HRF P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_CREATED_BY_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_PCO_VM}.V_INT_F_ACTE_HRF a
        On    P.ACTE_ID             = a.ACTE_ID
    Where
      (1=1)
      And a.ACTE_ID Is Null
      And P.HOT_IN  =0
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By a.ACTE_ID_GEN Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          

-- Nombre d'actes Chorus manquant
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      2                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO ext
        On    p.ORG_GROUPE_ID       = ext.EXTNL_VAL_COD_CD
          And p.INT_DEPOSIT_DT      Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'REGARDSC' 
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID        = edo.EDO_ID
          And p.INT_DEPOSIT_DT  between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN    = 1
    Where
      (1=1)
      And Not Exists
      (
        Select
          1
        From
          ${KNB_PCO_VM}.V_INT_F_ACTE_CHO c
        Where
          (1=1)
          And p.ACTE_ID = c.ACTE_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          

-- Nombre d'actes OEE manquant

;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      3                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_OEE p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO ext
        On    p.ORG_GROUPE_ID       = ext.EXTNL_VAL_COD_CD
          And p.INT_DEPOSIT_DT      Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'REGARDSC' 
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID        = edo.EDO_ID
          And p.INT_DEPOSIT_DT  between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN    = 1
    Where
      (1=1)
      --restriction il faut que le triplet soit éligible
      And Exists
      (
        Select
          1
        From
          ${KNB_COM_SOC}.V_CAT_R_REF_PRODUCT_OEE R
        Where
          (1=1)
          And P.RESOLU_ID     =   R.RESOLU_ID
          And P.CONCLU_ID     =   R.CONCLU_ID
          And P.SSCONCLU_ID   =   R.SSCONCLU_ID
      )
      And Not Exists
      (
        Select
          1
        From
          ${KNB_PCO_VM}.V_INT_F_ACTE_OEE c
        Where
          (1=1)
          And p.ACTE_ID = c.ACTE_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb d'acte  EDL manquant
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      4                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_EDL P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO ext
        On    p.ORG_GROUPE_ID       = ext.EXTNL_VAL_COD_CD
          And p.INT_DEPOSIT_DT      Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'REGARDSC' 
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID        = edo.EDO_ID
          And p.INT_DEPOSIT_DT  between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN    = 1
    Where
      (1=1)
      --restriction il faut que le triplet soit éligible
      And Exists
      (
        Select
          1
        From
          ${KNB_COM_SOC}.V_CAT_R_REF_PRODUCT_EDEL R
        Where
          (1=1)
          And P.RESOLU_ID     =   R.RESOLU_ID
          And P.CONCLU_ID     =   R.CONCLU_ID
          And P.SSCONCLU_ID   =   R.SSCONCLU_ID
      )
      And Not Exists
      (
        Select
          1
        From
          ${KNB_PCO_VM}.V_INT_F_ACTE_EDL c
        Where
          (1=1)
          And p.ACTE_ID = c.ACTE_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb d'acte  PCM manquant
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.DATESAISIEBCR                                 As JOUR             ,
      5                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.DATESAISIEBCR         Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK ext
        On    p.PV_POINTVENTE       = ext.EXTNL_VAL_COD_CD
          And p.DATESAISIEBCR       Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'ADV'
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID        = edo.EDO_ID
          And p.DATESAISIEBCR   between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN    = 1
    Where
      (1=1)
      And Not Exists
      (
        Select
          1
        From
          ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM c
        Where
          (1=1)
          And p.ACTE_ID = c.ACTE_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          



--Nb d'acte  VAD manquant
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  EQUIPE            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.EQUIPE          as EQUIPE           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.DATE_SAISIE                                   As JOUR             ,
      6                                               As SOURCES          ,
      Coalesce(ext.EDO_ID,'-')                        As CODE_EQUIPE      ,
      Coalesce(edo.edo_ds, 'Equipe indéterminée')     As EQUIPE           
    From
      ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.DATE_SAISIE           Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK ext
        On    p.PDV                 = ext.EXTNL_VAL_COD_CD
          And p.DATE_SAISIE         Between ext.START_EXTNL_VAL_DT And ext.END_EXTNL_VAL_DT
          And ext.EXTNL_COD_CD      = 'ADV'
          And ext.CURRENT_IN        = 1
      Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EDO edo
        On    ext.EDO_ID        = edo.EDO_ID
          And p.DATE_SAISIE     between edo.START_DT and Coalesce(edo.CLOSE_DT,CURRENT_DATE)
          And edo.CURRENT_IN    = 1
    Where
      (1=1)
      And Not Exists
      (
        Select
          1
        From
          ${KNB_PCO_VM}.V_ORD_F_ACTE_VAD c
        Where
          (1=1)
          And p.ACTE_ID = c.ACTE_ID
      )
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By ext.END_EXTNL_VAL_DT Desc, ext.START_EXTNL_VAL_DT asc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.EQUIPE          
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS Column(JOUR,SOURCES,CODE_EQUIPE);
.if errorcode <> 0 then .quit 1




-- =====================================================================================--
-- 009 : Nombre d'actes en recyclage par source 					   du mois M-1 et depuis le premier à J-1 du mois M
-- 010 : Nombre d'actes en recyclage par source et par équipe du mois M-1 et depuis le premier à J-1 du mois M  
-- =====================================================================================--

Create volatile Table ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS(
  JOUR              Date Format 'YYYYMMDD'  Not Null    ,
  SOURCES           Byteint                 Not Null    ,
  CODE_EQUIPE       Varchar(50)             Not Null    ,
  ACT_CD            Varchar(100)                        ,
  NB_PLACEMENTS     Integer                             
)
Primary Index (
  JOUR            ,
  SOURCES         ,
  CODE_EQUIPE     
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1





--Alimentation des rejets SOFT
Insert into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Sum(Tmp.NB_ACTE)    as NB_PLACEMENTS    
From
  (
      Select
        p.ACTE_ID                                       As ACTE_ID          ,
        p.ORDER_DEPOSIT_DT                              As JOUR             ,
        1                                               As SOURCES          ,
        Coalesce(p.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
        Case  When P.ORG_REM_CHANEL_CD Is  Null
                Then 'ERR_ORG_REM_CHANEL_CD_NULL'
              Else P.ACT_CD
        End                                             As ACT_CD           ,
        1                                               As NB_ACTE          
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT p
        --Restriction sur les dates :
        Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
          On  p.ORDER_DEPOSIT_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Where
        (1=1)
        And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANEL_CD is null)
        And P.HOT_IN        = 0
        And p.ORG_TYPE_EDO  = 'INT'
      Qualify Row_Number() Over (Partition By p.ACTE_ID Order By p.ORDER_DEPOSIT_DT Desc)=1
    Union All
      Select
        p.ACTE_ID                                       As ACTE_ID          ,
        p.ORDER_DEPOSIT_DT                              As JOUR             ,
        1                                               As SOURCES          ,
        Coalesce(p.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
        Case  When P.ORG_REM_CHANEL_CD Is  Null
                Then 'ERR_ORG_REM_CHANEL_CD_NULL'
              Else P.ACT_CD
        End                                             As ACT_CD           ,
        1                                               As NB_ACTE          
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB p
        --Restriction sur les dates :
        Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
          On  p.ORDER_DEPOSIT_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Where
        (1=1)
        And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANEL_CD is null)
        And P.HOT_IN  = 0
        And p.ORG_TYPE_EDO  = 'INT'
      Qualify Row_Number() Over (Partition By p.ACTE_ID Order By p.ORDER_DEPOSIT_DT Desc)=1
    Union All
      Select
        p.ACTE_ID                                       As ACTE_ID          ,
        p.ORDER_DEPOSIT_DT                              As JOUR             ,
        1                                               As SOURCES          ,
        Coalesce(p.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
        Case  When P.ORG_REM_CHANEL_CD Is  Null
                Then 'ERR_ORG_REM_CHANEL_CD_NULL'
              Else P.ACT_CD
        End                                             As ACT_CD           ,
        1                                               As NB_ACTE          
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_PCM p
        --Restriction sur les dates :
        Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
          On  p.ORDER_DEPOSIT_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Where
        (1=1)
        And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANEL_CD is null)
        And P.HOT_IN  = 0
        And p.ORG_TYPE_EDO  = 'INT'
      Qualify Row_Number() Over (Partition By p.ACTE_ID Order By p.ORDER_DEPOSIT_DT Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          

--Alimentation des rejets Chorus
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      2                                               As SOURCES          ,
      Coalesce(P.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
      Case  When P.ORG_REM_CHANNEL_CD Is  Null
              Then 'ERR_ORG_REM_CHANEL_CD_NULL'
            Else P.ACT_CD
      End                                             As ACT_CD           
    From
      ${KNB_PCO_VM}.V_INT_F_ACTE_CHO p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Where
      (1=1)
      And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANNEL_CD is null)
      And p.ORG_TYPE_EDO  = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By P.CREATION_TS Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          



--Alimentation des rejets OEE
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      3                                               As SOURCES          ,
      Coalesce(P.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
      Case  When P.ORG_REM_CHANNEL_CD Is  Null
              Then 'ERR_ORG_REM_CHANEL_CD_NULL'
            Else P.ACT_CD
      End                                             As ACT_CD           
    From
      ${KNB_PCO_VM}.V_INT_F_ACTE_OEE p
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Where
      (1=1)
      And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANNEL_CD is null)
      And p.ORG_TYPE_EDO  = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By P.CREATION_TS Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          



--Alimentation des rejets EDL
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_DEPOSIT_DT                                As JOUR             ,
      4                                               As SOURCES          ,
      Coalesce(P.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
      Case  When P.ORG_REM_CHANNEL_CD Is  Null
              Then 'ERR_ORG_REM_CHANEL_CD_NULL'
            Else P.ACT_CD
      End                                             As ACT_CD           
    From
      ${KNB_PCO_VM}.V_INT_F_ACTE_EDL P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_DEPOSIT_DT between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Where
      (1=1)
      And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANNEL_CD is null)
      And p.ORG_TYPE_EDO  = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By P.CREATION_TS Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          



--Alimentation des rejets PCM
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.ORDER_DEPOSIT_DT                              As JOUR             ,
      5                                               As SOURCES          ,
      Coalesce(P.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
      Case  When P.ORG_REM_CHANNEL_CD Is  Null
              Then 'ERR_ORG_REM_CHANEL_CD_NULL'
            Else P.ACT_CD
      End                                             As ACT_CD           
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.ORDER_DEPOSIT_DT         Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Where
      (1=1)
      And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANNEL_CD is null)
      And p.ORG_TYPE_EDO  = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By P.CREATION_TS Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          



--Alimentation des rejets VAD
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.ORDER_DEPOSIT_DT                              As JOUR             ,
      6                                               As SOURCES          ,
      Coalesce(P.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
      Case  When P.ORG_REM_CHANNEL_CD Is  Null
              Then 'ERR_ORG_REM_CHANEL_CD_NULL'
            Else P.ACT_CD
      End                                             As ACT_CD           
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_VAD P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.ORDER_DEPOSIT_DT           Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Where
      (1=1)
      And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANNEL_CD is null)
      And p.ORG_TYPE_EDO  = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By P.CREATION_TS Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          


--Alimentation des rejets Rforce
;Insert Into ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS
(
  JOUR              ,
  SOURCES           ,
  CODE_EQUIPE       ,
  ACT_CD            ,
  NB_PLACEMENTS     
)
Select
  Tmp.JOUR            as JOUR             ,
  Tmp.SOURCES         as SOURCES          ,
  Tmp.CODE_EQUIPE     as CODE_EQUIPE      ,
  Tmp.ACT_CD          as ACT_CD           ,
  Count(*)            as NB_PLACEMENTS    
From
  (
    Select
      p.ACTE_ID                                       As ACTE_ID          ,
      p.INT_CREATED_BY_DT                             As JOUR             ,
      11                                              As SOURCES          ,
      Coalesce(P.ORG_EDO_ID,'-')                      As CODE_EQUIPE      ,
      Case  When P.ORG_REM_CHANNEL_CD Is  Null
              Then 'ERR_ORG_REM_CHANEL_CD_NULL'
            Else P.ACT_CD
      End                                             As ACT_CD           
    From
      ${KNB_PCO_VM}.V_INT_F_ACTE_HRF P
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  p.INT_CREATED_BY_DT      Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
    Where
      (1=1)
      And (Substr(P.ACT_CD,1,3) in ('ERR') Or P.ORG_REM_CHANNEL_CD is null)
      And p.ORG_TYPE_EDO  = 'INT'
    Qualify Row_Number() Over (Partition By p.ACTE_ID Order By P.CREATION_TS Desc)=1
  )Tmp
Group By
  Tmp.JOUR            ,
  Tmp.SOURCES         ,
  Tmp.CODE_EQUIPE     ,
  Tmp.ACT_CD          
;
.if errorcode <> 0 then .quit 1



Collect Stat On ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS Column(JOUR,SOURCES,CODE_EQUIPE);
.if errorcode <> 0 then .quit 1







-------------------------------------------------------------------------------------------------------
--                      Génération du fichier 
-------------------------------------------------------------------------------------------------------
--entete :
-- Select
--   'Periode d''extraction : '                                              ||';'||
--   Coalesce(Trim(Cast(V.DATE_DEBUT as Date Format 'DDMMYYYY')),'')         ||';'||
--   Coalesce(Trim(Cast(V.DATE_FIN as Date Format 'DDMMYYYY')),'')           (Title '')
-- From
--   ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR V
-- ;
-- .if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 001 : Nombre Actes par sources du mois M-1 et depuis le premier à J-1 du mois M
-- =====================================================================================--

Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.CANAL As Varchar(50))),'')                 ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '001'                                                       As TYPELIGNE  ,
      Trim(Cast(Unif.ACT_DT as Date Format 'DDMMYYYY'))           As DATEUNIF   ,
      Trim(Source.SOURCE_DESC)                                    As SOURCEDESC ,
      Trim(Unif.ORG_REM_CHANNEL_CD)                               As CANAL      ,
      Trim(Count(*))                                              As NUMBER_A   
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  Unif.ACT_DT             Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  Unif.INTRNL_SOURCE_ID   = Source.INTRNL_SOURCE_ID
    Where
      (1=1)
      And Unif.ACT_FLAG_PVC_REM   = 'O'
      And Unif.MASTER_FLAG        = 1
      And Unif.ORG_TYPE_EDO       = 'INT' 
    Group by 
      Unif.ACT_DT               ,
      Source.SOURCE_DESC        ,
      Unif.ORG_REM_CHANNEL_CD   
  )Tmp
Order By
  Tmp.DATEUNIF                Asc ,
  Tmp.SOURCEDESC              Asc ,
  Tmp.CANAL                   Asc 
;
.if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 002 : Nb d'actes transmis à PVC  du mois M-1 et depuis le premier à J-1 du mois M et par sources
-- =====================================================================================--
Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.ACTION_A As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '002'                                                           As TYPELIGNE    ,
      Trim(Cast(Unif.ACT_DT as Date Format 'DDMMYYYY'))               As DATEUNIF     ,
      Trim(Source.SOURCE_DESC)                                        As SOURCEDESC   ,
      Trim(RefId.ACTION_ACTE)                                         As ACTION_A     ,
      Trim(Count(*))                                                  As NUMBER_A     
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP RefId
        On  Unif.ACTE_ID            = RefId.ACTE_ID
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  Unif.INTRNL_SOURCE_ID   = Source.INTRNL_SOURCE_ID
    Where
      (1=1)
    Group by 
      Unif.ACT_DT               ,
      Source.SOURCE_DESC        ,
      RefId.ACTION_ACTE         
  )Tmp
Order By
  Tmp.DATEUNIF                Asc ,
  Tmp.SOURCEDESC              Asc ,
  Tmp.ACTION_A                Asc 
;
.if errorcode <> 0 then .quit 1


-- =====================================================================================--
-- 003 : Nombre de placements par source du mois M-1 et depuis le premier à J-1 du mois M
-- =====================================================================================--
Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '003'                                                               As TYPELIGNE    ,
      Trim(Cast(RefId.JOUR as Date Format 'DDMMYYYY'))                    As DATEUNIF     ,
      Trim(Source.SOURCE_DESC)                                            As SOURCEDESC   ,
      Trim(Sum(RefId.NB_PLACEMENTS))                                      As NUMBER_A     
    From
      ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS RefId
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  RefId.SOURCES         = Source.INTRNL_SOURCE_ID
    Group By
      RefId.JOUR                    ,
      Source.SOURCE_DESC            
  )Tmp
Order By
  Tmp.DATEUNIF                      Asc ,
  Tmp.SOURCEDESC                    Asc 
;
.if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 004 : Nombre de placement sans actes par source du mois M-1 et depuis le premier à J-1 du mois M 
-- =====================================================================================--
Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCES As Varchar(100))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '004'                                                               As TYPELIGNE      ,
      Trim(Cast(RefId.JOUR as Date Format 'DDMMYYYY'))                    As DATEUNIF       ,
      Trim(RefId.SOURCES)                                                 As SOURCES        ,
      Trim(Sum(RefId.NB_PLACEMENTS))                                      As NUMBER_A       
    From
      ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA RefId
    Group By
      RefId.JOUR                    ,
      RefId.SOURCES                 
  )Tmp
Order By
  Tmp.DATEUNIF                      Asc ,
  Tmp.SOURCES                       Asc 
;
.if errorcode <> 0 then .quit 1


-- =====================================================================================--
--  005 : Nombre Actes par sources, canal et Equipe O3 du mois M-1 et depuis le premier à J-1 du mois M
-- =====================================================================================--

Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.CHANNEL As Varchar(100))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.ID_WORK_TEAM As Varchar(100))),'')         ||';'||
  Coalesce(Trim(Cast(Tmp.DS_WORK_TEAM As Varchar(100))),'')         ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '005'                                                           As TYPELIGNE      ,
      Trim(Cast(Unif.ACT_DT as Date Format 'DDMMYYYY'))               As DATEUNIF       ,
      Trim(Source.SOURCE_DESC)                                        As SOURCEDESC     ,
      Trim(Unif.ORG_REM_CHANNEL_CD)                                   As CHANNEL        ,
      Trim(Case   When Unif.ORG_TYPE_CD = 'O3'
                    Then Coalesce(Unif.WORK_TEAM_LEVEL_1_CD,'-')
                  Else '-'
      End)                                                            As ID_WORK_TEAM   ,
      Trim(Case   When (
                            Case   When Unif.ORG_TYPE_CD = 'O3'
                                          Then Coalesce(Unif.WORK_TEAM_LEVEL_1_CD,'-')
                                        Else '-'
                            End
                        ) = '-'
                    Then 'Equipe indéterminée'
                  Else Unif.WORK_TEAM_LEVEL_1_DS
      End)                                                            As DS_WORK_TEAM   ,
      Trim(Count(*))                                                  As NUMBER_A       
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  Unif.ACT_DT             Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  Unif.INTRNL_SOURCE_ID   = Source.INTRNL_SOURCE_ID
    Where
      (1=1)
      And Unif.ACT_FLAG_PVC_REM   = 'O'
      And Unif.MASTER_FLAG        = 1
      And Unif.ORG_TYPE_EDO       = 'INT'
    Group by 
      Unif.ACT_DT               ,
      Source.SOURCE_DESC        ,
      Unif.ORG_REM_CHANNEL_CD   ,
      5                         ,
      6                         
  )Tmp
Order By
  Tmp.DATEUNIF                Asc ,
  Tmp.SOURCEDESC              Asc ,
  Tmp.CHANNEL                 Asc ,
  Tmp.ID_WORK_TEAM            Asc ,
  Tmp.DS_WORK_TEAM            Asc 
;
.if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 006 : Nb d'actes transmis à PVC  par équipe du mois M-1 et depuis le premier à J-1 du mois M et par sources
-- =====================================================================================--
Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.ACTION_A As Varchar(100))),'')             ||';'||
  Coalesce(Trim(Cast(Tmp.ID_WORK_TEAM As Varchar(100))),'')         ||';'||
  Coalesce(Trim(Cast(Tmp.DS_WORK_TEAM As Varchar(100))),'')         ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '006'                                                             As TYPELIGNE      ,
      Trim(Cast(Unif.ACT_DT as Date Format 'DDMMYYYY'))                 As DATEUNIF       ,
      Trim(Source.SOURCE_DESC)                                          As SOURCEDESC     ,
      Trim(RefId.ACTION_ACTE)                                           As ACTION_A       ,
      Trim(Coalesce(Unif.WORK_TEAM_LEVEL_1_CD,'-'))                     As ID_WORK_TEAM   ,
      Trim(Coalesce(Unif.WORK_TEAM_LEVEL_1_DS,'Equipe indéterminée'))   As DS_WORK_TEAM   ,
      Trim(Count(*))                                                    As NUMBER_A       
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP RefId
        On  Unif.ACTE_ID            = RefId.ACTE_ID
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  Unif.INTRNL_SOURCE_ID   = Source.INTRNL_SOURCE_ID
    Where
      (1=1)
    Group by
      Unif.ACT_DT                                               ,
      Source.SOURCE_DESC                                        ,
      RefId.ACTION_ACTE                                         ,
      Coalesce(Unif.WORK_TEAM_LEVEL_1_CD,'-')                   ,
      Coalesce(Unif.WORK_TEAM_LEVEL_1_DS,'Equipe indéterminée') 
  )Tmp
Order By
  Tmp.DATEUNIF                          Asc ,
  Tmp.SOURCEDESC                        Asc ,
  Tmp.ACTION_A                          Asc ,
  Tmp.ID_WORK_TEAM                      Asc ,
  Tmp.DS_WORK_TEAM                      Asc 
;
.if errorcode <> 0 then .quit 1



-- =====================================================================================--
-- 007 : Nombre de placements par source et par équipe du mois M-1 et depuis le premier à J-1 du mois M
-- =====================================================================================--
Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.CODE_EQUIPE As Varchar(100))),'')          ||';'||
  Coalesce(Trim(Cast(Tmp.EQUIPE As Varchar(100))),'')               ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '007'                                                             As TYPELIGNE      ,
      Trim(Cast(RefId.JOUR as Date Format 'DDMMYYYY'))                  As DATEUNIF       ,
      Trim(Source.SOURCE_DESC)                                          As SOURCEDESC     ,
      Trim(RefId.CODE_EQUIPE)                                           As CODE_EQUIPE    ,
      Trim(RefId.EQUIPE)                                                As EQUIPE         ,
      Trim(RefId.NB_PLACEMENTS)                                         As NUMBER_A       
    From
       ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PPS  RefId
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  RefId.SOURCES       = Source.INTRNL_SOURCE_ID
  )Tmp
Order By
  Tmp.DATEUNIF                  asc ,
  Tmp.SOURCEDESC                asc ,
  Tmp.CODE_EQUIPE               asc ,
  Tmp.EQUIPE                    asc 
;
.if errorcode <> 0 then .quit 1


-- =====================================================================================--
-- 008 : Nombre de placement sans actes par source et par Equipe du mois M-1 et depuis le premier à J-1 du mois M 
-- =====================================================================================--

Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.CODE_EQUIPE As Varchar(100))),'')          ||';'||
  Coalesce(Trim(Cast(Tmp.EQUIPE As Varchar(100))),'')               ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '008'                                                         As TYPELIGNE        ,
      Trim(Cast(RefId.JOUR as Date Format 'DDMMYYYY'))              As DATEUNIF         ,
      Trim(RefId.SOURCES)                                           As SOURCEDESC       ,
      Trim(RefId.CODE_EQUIPE)                                       As CODE_EQUIPE      ,
      Trim(RefId.EQUIPE)                                            As EQUIPE           ,
      Trim(RefId.NB_PLACEMENTS)                                     As NUMBER_A         
    From
       ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_PSA  RefId
  )Tmp
Order By
  Tmp.DATEUNIF                  asc ,
  Tmp.SOURCEDESC                asc ,
  Tmp.CODE_EQUIPE               asc ,
  Tmp.EQUIPE                    asc 
;
.if errorcode <> 0 then .quit 1


-- =====================================================================================--
-- 009 : Nombre d'actes en recyclage par source 					   du mois M-1 et depuis le premier à J-1 du mois M
-- =====================================================================================--

Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.CODE_EQUIPE As Varchar(100))),'')          ||';'||
  Coalesce(Trim(Cast(Tmp.ACT_CD As Varchar(100))),'')               ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '009'                                                             As TYPELIGNE          ,
      Trim(Cast(RefId.JOUR as Date Format 'DDMMYYYY'))                  As DATEUNIF           ,
      Trim(Source.SOURCE_DESC)                                          As SOURCEDESC         ,
      Trim(RefId.CODE_EQUIPE)                                           As CODE_EQUIPE        ,
      Trim(RefId.ACT_CD)                                                As ACT_CD             ,
      Trim(RefId.NB_PLACEMENTS)                                         As NUMBER_A           
    From
      ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS  RefId
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  RefId.SOURCES       = Source.INTRNL_SOURCE_ID
  )Tmp
Order By
  Tmp.DATEUNIF                  asc ,
  Tmp.SOURCEDESC                asc ,
  Tmp.CODE_EQUIPE               asc ,
  Tmp.ACT_CD                    asc
;
.if errorcode <> 0 then .quit 1


-- =====================================================================================--
-- 010 : Nombre d'actes en recyclage par source et par équipe du mois M-1 et depuis le premier à J-1 du mois M  
-- =====================================================================================--
Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.CODE_EQUIPE As Varchar(100))),'')          ||';'||
  Coalesce(Trim(Cast(Tmp.EQUIPE As Varchar(100))),'')               ||';'||
  Coalesce(Trim(Cast(Tmp.ACT_CD As Varchar(100))),'')               ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(50))),'')              (Title '')
From
  (
    Select
      '010'                                                         As TYPELIGNE          ,
      Trim(Cast(RefId.JOUR as Date Format 'DDMMYYYY'))              As DATEUNIF           ,
      Trim(Source.SOURCE_DESC)                                      As SOURCEDESC         ,
      Trim(Case   When Edo.EDO_DS Is Null
                    Then  '-'
                  Else    RefId.CODE_EQUIPE
      End)                                                          As CODE_EQUIPE        ,
      Trim(Coalesce(Edo.EDO_DS,'Equipe indéterminée'))              As EQUIPE             ,
      Trim(RefId.ACT_CD)                                            As ACT_CD             ,
      Trim(RefId.NB_PLACEMENTS)                                     As NUMBER_A           
    From
      ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ARS  RefId
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  RefId.SOURCES             = Source.INTRNL_SOURCE_ID
      Left Outer Join  ${KNB_COM_SOC}.V_ORG_F_EDO Edo
        On    RefId.CODE_EQUIPE       = Cast(Edo.EDO_ID as Varchar(50))
          And Edo.CURRENT_IN          = 1
          And RefId.JOUR              Between Edo.START_DT And Coalesce(Edo.CLOSE_DT,Current_Date)
  )Tmp
Order By
  Tmp.DATEUNIF                                              asc ,
  Tmp.SOURCEDESC                                            asc ,
  Tmp.CODE_EQUIPE                                           asc ,
  Tmp.EQUIPE                                                asc ,
  Tmp.ACT_CD                                                asc 
;
.if errorcode <> 0 then .quit 1




-- =====================================================================================--
-- 011 : Suivi du taux d'actes sur l'organisation O3 par mois et par source depuis le 01/08/2013
-- =====================================================================================--

Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.SOURCEDESC As Varchar(100))),'')           ||';'||
  Coalesce(Trim(Cast(Tmp.NUMBER_A As Varchar(100))),'')             ||';'||
  Coalesce(Trim(Cast(Tmp.S_O3 As Varchar(100))),'')                 ||';'||
  Coalesce(Trim(Cast(Tmp.P_O3 As Varchar(100))),'')                 ||';'||
  Coalesce(Trim(Cast(Tmp.S_HO3 As Varchar(100))),'')                ||';'||
  Coalesce(Trim(Cast(Tmp.P_HO3 As Varchar(100))),'')                ||';'||
  Coalesce(Trim(Cast(Tmp.S_WO3 As Varchar(100))),'')                ||';'||
  Coalesce(Trim(Cast(Tmp.P_WO3 As Varchar(100))),'')                (Title '')
From
  (
    Select
      '011'                                                                                           As TYPELIGNE      ,
      Trim(Cast((Unif.ACT_DT - Extract(Day from Unif.ACT_DT)+1) as Date Format 'DDMMYYYY'))           As DATEUNIF       ,
      Trim(Source.SOURCE_DESC)                                                                        As SOURCEDESC     ,
      Trim(Count(*))                                                                                  As NUMBER_A       ,
      Trim(Sum(
            Case  When Unif.ORG_TYPE_CD = 'O3' 
                    Then 1 
                  Else 0 
            End
          ))                                                                                          As S_O3           ,
      Trim(Sum(
            Case  When Unif.ORG_TYPE_CD = 'O3' 
                    Then 1 
                  Else 0 
            End
          )*100/Count(*))                                                                             As P_O3           ,
      Trim(Sum(
            Case  When (Unif.ORG_TYPE_CD = 'O3'  And Unif.ORG_TEAM_LEVEL_1_CD Is Not Null)
                    Then  1
                  Else    0
            End
          ))                                                                                          As S_HO3          ,
      Trim((Sum(
            Case  When (Unif.ORG_TYPE_CD = 'O3'  And Unif.ORG_TEAM_LEVEL_1_CD Is Not Null)
                    Then  1
                  Else    0
            End)*100/Count(*)))                                                                       As P_HO3          ,
      Trim(Sum(
            Case  When (Unif.ORG_TYPE_CD = 'O3'  And Unif.WORK_TEAM_LEVEL_1_CD Is Not Null)
                    Then  1
                  Else    0
            End
          ))                                                                                          As S_WO3          ,
      Trim((Sum(
            Case  When (Unif.ORG_TYPE_CD = 'O3'  And Unif.WORK_TEAM_LEVEL_1_CD Is Not Null)
                    Then  1
                  Else    0
            End)*100/Count(*)))                                                                       As P_WO3          
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  Unif.ACT_DT             Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  Unif.INTRNL_SOURCE_ID   = Source.INTRNL_SOURCE_ID
    Where
      (1=1)
      And Unif.ACT_FLAG_PVC_REM   = 'O'
      And Unif.MASTER_FLAG        = 1
      And Unif.ORG_TYPE_EDO       = 'INT'
    Group by 
      (Unif.ACT_DT - Extract(Day from Unif.ACT_DT)+1)             ,
      Source.SOURCE_DESC                                          
  )Tmp
Order By
  Tmp.DATEUNIF              asc ,
  Tmp.SOURCEDESC            asc 
;
.if errorcode <> 0 then .quit 1





-- =====================================================================================
-- 012 : Nb d'actes transmis en création à PVC  du mois M-1 et depuis le premier à J-1 du mois M et par KPI
-- =====================================================================================

Select
  Tmp.TYPELIGNE                                                     ||';'||
  Coalesce(Trim(Cast(Tmp.DATEUNIF As Varchar(50))),'')              ||';'||
  Coalesce(Trim(Cast(Tmp.KPI_ID As Varchar(100))),'')               ||';'||
  Coalesce(Trim(Cast(Tmp.NB_ACTES As Varchar(100))),'')             (Title '')
From
  (
    Select
      '012'                                                           As TYPELIGNE      ,
      Trim(Cast(Unif.ACT_DT as Date Format 'DDMMYYYY'))               As DATEUNIF       ,
      Trim(RefKPI.KPI_ID)                                             As KPI_ID         ,
      Trim(Count(Distinct Unif.ACTE_ID))                              As NB_ACTES       
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif
      --Restriction sur les dates :
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_VAR RefDt
        On  Unif.ACT_DT                 Between  RefDt.DATE_DEBUT and RefDt.DATE_FIN
      Inner Join ${KNB_PCO_SOC}.V_ORD_R_SOURCE Source
        On  Unif.INTRNL_SOURCE_ID       = Source.INTRNL_SOURCE_ID
      Inner Join ${KNB_COM_SOC}.V_CAT_R_ACTE_PILCOM RefActe
        On    Unif.ACT_CD               = RefActe.ACTE_ID
          And Unif.ACT_PERIODE_ID       = RefActe.PERIODE_ID
      Inner Join ${KNB_PCO_REFCOM}.CAT_R_KPI_PILCOM  RefKPI
        On    RefActe.ACTE_FAMILLE_KPI  = RefKPI.FAMILLE_KPI_ID
          And RefActe.PERIODE_ID        = RefKPI.PERIODE_ID
      Inner Join ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP IndAPT
        On    Unif.ACTE_ID              = IndAPT.ACTE_ID
          And IndAPT.ACTION_ACTE        = 1
    Where
      (1=1)
      --And Unif.ACT_FLAG_PVC_REM   = 'O'
      --And Unif.MASTER_FLAG        = 1
      And Not exists
      (
        Select
          1
        From
          ${KNB_TERADATA_USER}.EXT_V_PILCOM_INDICS_ATP IndAPT2
        Where
          (1=1)
          And IndAPT.ACTE_ID        = IndAPT2.ACTE_ID
          And IndAPT2.ACTION_ACTE   = 5
      )
    Group by 
      Unif.ACT_DT               ,
      RefKPI.KPI_ID             
  )Tmp
Order By
  Tmp.DATEUNIF                Asc ,
  Tmp.KPI_ID                  Asc 
;
.if errorcode <> 0 then .quit 1


.quit 0

