-- $HEADER:   mm2pco/current/sql/ATP_EDL_Placement_Consolidation_Enrichissement_Step1_IDLineDMC.sql 13_05#5 13-JAN-2017 10:15:55 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_Enrichissement_Step1_IDLineDMC.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrichissement Id Line DMC
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/06/2013      CBR         Creation
-- 20/03/2014      AID         Industrialisation   
-- 16/06/2015      AOU         Multicanal
---24/11/2016    HOB        Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IDLINEDMC all;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IDLINEDMC
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  PAR_DEPRTMNT_ID           ,
  PAR_POSTAL_CD             ,
  PAR_INSEE_NB              ,
  PAR_BU_CD                 ,
  DMC_LINE_TYPE             ,
  DMC_ACTIVATION_DT         ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT             ,
  LineDmc.LINE_ID                                 as DMC_LINE_ID                ,
  LineDmc.MASTER_LINE_ID                          as DMC_MASTER_LINE_ID         ,
  LineDmc.DEPRTMNT_ID                             as PAR_DEPRTMNT_ID            ,
  LineDmc.POSTAL_CD                               as PAR_POSTAL_CD              ,
  LineDmc.INSEE_NB                                as PAR_INSEE_NB               ,
  Ref_geo.BU_CD                                   as PAR_BU_CD                  ,
  LineDmc.LINE_TYPE                               as DMC_LINE_TYPE              ,
  LineDmc.ACTIVATION_DT                           as DMC_ACTIVATION_DT          ,
  LineDmc.UNIFIED_PARTY_ID                        AS PAR_UNIFIED_PARTY_ID       ,
  LineDmc.PARTY_REGRPMNT_ID                       AS PAR_PARTY_REGRPMNT_ID
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1 RefId
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
      --Jointure Client/Dossier
    On RefId.DOSSIER_NU                  = LineDmc.RES_VALUE_DS
      And LineDmc.ACTIVE_FLAG = 1 
  Left Outer join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT Ref_geo
    On Ref_geo.DEPT_CD=LineDmc.DEPRTMNT_ID

      Where
  (1=1)
--  And RefId.DMC_LINE_ID   Is Null
  -- And LineDmc.LINE_TYPE   In ('P','M')
  And LineDmc.CLOSURE_DT  Is Null
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IDLINEDMC;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 2 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  DMC_LINE_ID           ,
  DMC_MASTER_LINE_ID    ,
  DMC_CONVERGENT_IN     
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID              ,
  RefDmc.INT_DEPOSIT_DT           as INT_DEPOSIT_DT       ,
  RefDmc.DMC_LINE_ID              as DMC_LINE_ID          ,
  RefDmc.DMC_MASTER_LINE_ID       as DMC_MASTER_LINE_ID   ,
  Dmc.CONVERGENT_IN               as DMC_CONVERGENT_IN    
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IDLINEDMC RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_HIST Dmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_LINE_ID      =  Dmc.LINE_ID
      And RefDmc.INT_DEPOSIT_DT   >   Dmc.VAL_START_DT
      And RefDmc.INT_DEPOSIT_DT   <=  Dmc.VAL_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID, RefDmc.INT_DEPOSIT_DT Order by Dmc.VAL_START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 3 : On recherche l'identifiant ligne Internet en relation :
----------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  DMC_LINE_ID_INT       ,
  DMC_LINE_TYPE_INT     ,
  DMC_ACTIVATION_DT_INT ,
  DMC_SERVICE_ACCESS_ID ,
  PAR_UNIFIED_PARTY_ID  ,
  PAR_PARTY_REGRPMNT_ID
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID                  ,
  RefDmc.INT_DEPOSIT_DT           as INT_DEPOSIT_DT           ,
  Dmc.LINE_ID                     as DMC_LINE_ID_INT          ,
  Dmc.LINE_TYPE                   as DMC_LINE_TYPE_INT        ,
  Dmc.ACTIVATION_DT               as DMC_ACTIVATION_DT_INT    ,
  Dmc.SERVICE_ACCESS_ID           as DMC_SERVICE_ACCESS_ID    ,
  Dmc.UNIFIED_PARTY_ID            AS PAR_UNIFIED_PARTY_ID     ,
  Dmc.PARTY_REGRPMNT_ID           AS PAR_PARTY_REGRPMNT_ID
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Dmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_MASTER_LINE_ID       =   Dmc.MASTER_LINE_ID

Where
  (1=1)
  --On filtre que sur les lignes Internet / Fixe
  And Dmc.LINE_TYPE           in ('I','F')
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID, RefDmc.INT_DEPOSIT_DT Order by Dmc.START_DT, Dmc.LINE_ID Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------------------
-- Etape 4 : on détermine le Score Internet                                                        ----
-------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT_SC All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT_SC
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PAR_SCORE_NU_INT        ,
  PAR_SCORE_IN_INT        ,
  PAR_TRESHOLD_NU_INT     
)
Select
  RefDmc.ACTE_ID                  as ACTE_ID              ,
  RefDmc.INT_DEPOSIT_DT           as INT_DEPOSIT_DT       ,
  ScoreDmc.SCORE_VALUE_1          as PAR_SCORE_NU_INT     ,
  ScoreDmc.SCORE_TRESHOLD_1       as PAR_SCORE_IN_INT     ,
  Null                            as PAR_TRESHOLD_NU_INT  
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT RefDmc
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_CPLT_HIST ScoreDmc
      --Jointure sur l'ID Ligne
    On    RefDmc.DMC_LINE_ID_INT  = ScoreDmc.LINE_ID
      And RefDmc.INT_DEPOSIT_DT   >= ScoreDmc.VAL_START_DT
      And RefDmc.INT_DEPOSIT_DT   <  ScoreDmc.VAL_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefDmc.ACTE_ID, RefDmc.INT_DEPOSIT_DT Order by ScoreDmc.VAL_START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT_SC;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 5 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IRIS
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID               ,
  PAR_IRIS2000_CD           ,
  PAR_GEO_MACROZONE
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT             ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD            ,
  LFIBER.RESERV_4                                 as PAR_GEO_MACROZONE 
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV RefId
  Inner Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
  on RefId.DMC_LINE_ID = LFIBER.LINE_ID
 Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.INT_DEPOSIT_DT Order by LFIBER.LAST_MODIF_TS Desc)=1
  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 6 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_FIBER
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_FIBER
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID                ,
  PAR_FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT                            as INT_DEPOSIT_DT             ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN            
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
  Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.INT_DEPOSIT_DT Order by FIBER.START_DT Desc)=1

  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_FIBER;
.if errorcode <> 0 then .quit 1

.quit 0
