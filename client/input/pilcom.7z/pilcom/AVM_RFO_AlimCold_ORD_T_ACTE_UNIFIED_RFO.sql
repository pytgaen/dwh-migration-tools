-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_RFO_AlimCold_ORD_T_ACTE_UNIFIED_RFO.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source RFO dans la table ORD_T_ACTE_UNIFIED_RFO  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 30/05/2013     CBR         Création
-- 26/03/2014     AID         Indus
-- 05/03/2015     HZO         Modif: Profondeur de recalcul 15 jours
-- 30/03/2015     HZO         Modif: jointure avec la table de clôture
-- 29/04/2015     AOU         Suite QC 599 : 2 cas d'incohérences résiduels sur l'axe orga : QC 1062
-- 19/06/2015     OCH         Modif: digital
-- 23/02/2015     MDE         Evol digital
-- 06/01/2017     HOB         Modif Ajout Champs VA
-- 14/03/2017     HLA         Modification 
-- 05/12/2017     HOB         Modification Nvx Champs IOBSP 
-- 23/09/2019     EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF
-- 09/10/2019     EVI         KPI2020 : Mise en place du filtre sur les NS/NSTECH pour data enabler
-- 09/07/2020     EVI         PILCOM-508 : eSim Indicateur - New Champs SIM_EAN_CD
-- 08/10/2021     EVI         PILCOM-1031 : Refonte VU - Champs Obsolètes
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_RFO --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_RFO;
.if errorcode <> 0 then .quit 1;

-- RFO

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_RFO 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_EDO_IOBSP                 ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  PAR_IRIS2000_CD               ,
  ACT_CA_LINE_AM                ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
 Select
  RF.ACTE_ID_GEN                                                           As ACTE_ID,
  RF.OPERATOR_PROVIDER_ID                                                  As OPERATOR_PROVIDER_ID,
  RF.TYPE_SOURCE_ID                                                        As INTRNL_SOURCE_ID,
  Case
    When RF.IND_GAM_TYPE = 4 Then '${P_PIL_368}'
    When RF.IND_GAM_TYPE = 1 Then '${P_PIL_367}'
    When RF.IND_GAM_TYPE = 2 Then '${P_PIL_394}'
    When RF.IND_GAM_TYPE = 3 Then '${P_PIL_370}'
    Else '${P_PIL_371}'
  End                                                                      As TYPE_SOURCE_ID,
  RF.ACTE_ID_GEN                                                           As MASTER_ACTE_ID,
  RF.TYPE_SOURCE_ID                                                        As MASTER_INTRNL_SOURCE_ID,
  ${P_PIL_354}                                                             AS MASTER_FLAG,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND,
  Null                                                                     As CPLT_ACTE_ID,
  Null                                                                     As CPLT_INTRNL_SOURCE_ID,
  '${P_PIL_388}'                                                           As CPLT_IN,
  '${P_PIL_362}'                                                           As RULE_ID,
  Null                                                                     As OFFSET_NB,
  '${P_PIL_324}'                                                           As ACT_TYPE,
  RF.EXTERNAL_ACTE_ID                                                      As ORDER_EXTERNAL_ID,
  '${P_PIL_395}'                                                           As STATUS_CD,
  Case When RF.CONCURENCE_IN = '${P_PIL_356}' Then '${P_PIL_385}'
       When RF.CONFIRMATION_IN = '${P_PIL_357}' Then '${P_PIL_386}' 
       When RF.PERENNITE_IN = '${P_PIL_356}' Then '${P_PIL_384}' 
       When RF.DELIVERY_IN = '${P_PIL_356}' And RF.PERENNITE_IN = '${P_PIL_357}' Then '${P_PIL_387}' 
       When RF.DELIVERY_IN = '${P_PIL_356}' Then '${P_PIL_383}' 
       When RF.CONFIRMATION_IN = '${P_PIL_356}' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                      As ACT_UNIFIED_STATUS_CD,
  RF.INT_CREATED_BY_TS                                                     As ACT_TS,
  RF.INT_CREATED_BY_DT                                                     As ACT_DT,
  Extract(HOUR From RF.INT_CREATED_BY_TS)                                  As ACT_HH,
  RF.INT_CREATED_BY_TS                                                     As ACT_LAST_UPD_TS,
  RF.ACT_PRODUCT_ID_PRE                                                    As ACT_PRODUCT_ID_PRE,
  RF.ACT_SEG_COM_ID_PRE                                                    As ACT_SEG_COM_ID_PRE,
  RF.ACT_SEG_COM_AGG_ID_PRE                                                As ACT_SEG_COM_AGG_ID_PRE,
  RF.ACT_CODE_MIGR_PRE                                                     As ACT_CODE_MIGR_PRE,
  Null                                                                     As ACT_OPER_ID_PRE,
  RF.ACT_PRODUCT_ID_FINAL                                                  As ACT_PRODUCT_ID_FINAL,
  RF.ACT_SEG_COM_ID_FINAL                                                  As ACT_SEG_COM_ID_FINAL,
  RF.ACT_SEG_COM_AGG_ID_FINAL                                              As ACT_SEG_COM_AGG_ID_FINAL,
  RF.ACT_CODE_MIGR_FINAL                                                   As ACT_CODE_MIGR_FINAL,
  -- On calcul l'opérateur final en fonction du type de commande 
  Case  When RF.ACT_TYPE_COMMANDE_ID In ('ACQ','MEF','DEF','DEGF','MEGF','DEF','ISOOFFRE')
          Then  'ADD'
        When RF.ACT_TYPE_COMMANDE_ID In ('MAINTRTC','DMAINTRTCF','DMAINT','MAINTRTCF')
          Then  'INI'
        Else    Null
  End                                                                      As ACT_OPER_ID_FINAL,
  RF.ACT_TYPE_SERVICE_FINAL                                                As ACT_TYPE_SERVICE_FINAL,
  RF.ACT_TYPE_COMMANDE_ID                                                  As ACT_TYPE_COMMANDE_ID,
  RF.ACT_DELTA_TARIF                                                       As ACT_DELTA_TARIF,
  RF.ACT_CD                                                                As ACT_CD,
  RF.ACT_REM_ID                                                            As ACT_REM_ID,
  RF.ACT_FLAG_ACT_REM                                                      As ACT_FLAG_ACT_REM,
  RF.ACT_FLAG_PEC_PERPVC                                                   As ACT_FLAG_PEC_PERPVC,
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And RF.ACT_FLAG_ACT_REM     = 'O'
                    -- L'acte doit avoir un conseiller
                    And RF.AGENT_ID_UPD         Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And RF.ORG_REM_CHANNEL_CD   In (${L_PIL_043}) 
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And SFI.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And RF.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then 'O' 
       Else 'N'  
  End                                                                      As ACT_FLAG_PVC_REM,
  RF.ACT_ACTE_VALO                                                         As ACT_ACTE_VALO,
  RF.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI,
  RF.ACT_PERIODE_ID                                                        As ACT_PERIODE_ID,
  RF.ACT_PERIODE_STATUS                                                    As ACT_PERIODE_STATUS               ,
  RF.ACT_PERIODE_CLOSURE_DT                                                As ACT_PERIODE_CLOSURE_DT           ,
  RF.INT_SRC                                                               As ORIGIN_CD,
 trim( RF.AGENT_LOGIN_CD )                                                 As AGENT_ID,
 trim( RF.AGENT_ID_UPD   )                                                 As AGENT_ID_UPD,
  RF.AGENT_ID_UPD_DT                                                       As AGENT_ID_UPD_DT,
  RF.ORG_AGENT_IOBSP                                                       As ORG_AGENT_IOBSP ,
  RF.AGENT_FIRST_NAME                                                      As AGENT_FIRST_NAME,
  RF.AGENT_LAST_NAME                                                       As AGENT_LAST_NAME,
  Null                                                                     As UNIFIED_SHOP_CD,
  Null                                                                     As ORG_SPE_CANAL_ID_MACRO,
  RF.ORG_CANAL_ID                                                          As ORG_SPE_CANAL_ID,
  RF.ORG_REM_CHANNEL_CD                                                    As ORG_REM_CHANNEL_CD,
  RF.ORG_CHANNEL_CD                                                        As ORG_CHANNEL_CD,
  RF.ORG_SUB_CHANNEL_CD                                                    As ORG_SUB_CHANNEL_CD,
  RF.ORG_SUB_SUB_CHANNEL_CD                                                As ORG_SUB_SUB_CHANNEL_CD,
  RF.ORG_GT_ACTIVITY                                                       As ORG_GT_ACTIVITY,
  RF.ORG_FIDELISATION                                                      As ORG_FIDELISATION,
  RF.ORG_WEB_ACTIVITY                                                      As ORG_WEB_ACTIVITY,
  RF.ORG_AUTO_ACTIVITY                                                     As ORG_AUTO_ACTIVITY,
  RF.ORG_EDO_ID                                                            As ORG_EDO_ID,
  RF.ORG_TYPE_EDO                                                          As ORG_TYPE_EDO,
  RF.ORG_EDO_IOBSP                                                         As ORG_EDO_IOBSP ,
  RF.ORG_FLAG_PLT_CONV                                                     As ORG_FLAG_PLT_CONV,
  RF.ORG_FLAG_TEAM_MKT                                                     As ORG_FLAG_TEAM_MKT,
  RF.ORG_FLAG_TYPE_CMP                                                     As ORG_FLAG_TYPE_CMP,
  Null                                                                     As ORG_RESP_EDO_ID,
  Null                                                                     As ORG_RESP_TYPE_EDO, 
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV,
  RF.ACTIVITY_CD                                                           As ACTIVITY_CD,
  Null                                                                     As ACTIVITY_GROUPNG_CD,
  RF.AUTO_ACTIVITY_IN                                                      As AUTO_ACTIVITY_IN,
  Case 
    When RF.ORG_EDO_ID Is Null Then '45F'
    Else '${P_PIL_366}'
  End                                                                       As ORG_TYPE_CD                    ,
  RF.ORG_TEAM_TYPE_ID                                                       As ORG_TEAM_TYPE_ID               ,
  Null                                                                      As ORG_TEAM_LEVEL_1_CD            ,
  Null                                                                      As ORG_TEAM_LEVEL_1_DS            ,
  Null                                                                      As ORG_TEAM_LEVEL_2_CD            ,
  Null                                                                      As ORG_TEAM_LEVEL_2_DS            ,
  Null                                                                      As ORG_TEAM_LEVEL_3_CD            ,
  Null                                                                      As ORG_TEAM_LEVEL_3_DS            ,
  Null                                                                      As ORG_TEAM_LEVEL_4_CD            ,
  Null                                                                      As ORG_TEAM_LEVEL_4_DS            ,
  Case when RF.ORG_EDO_FATHR_ID_NIV1 is NULL then NULL 
       else Trim(RF.ORG_EDO_ID)
  End                                                                       As WORK_TEAM_LEVEL_1_CD           ,
  RF.ORG_EDO_DS                                                             As WORK_TEAM_LEVEL_1_DS           ,
  Trim(RF.ORG_EDO_FATHR_ID_NIV1)                                            As WORK_TEAM_LEVEL_2_CD           ,
  RF.ORG_EDO_FATHR_DS_NIV1                                                  As WORK_TEAM_LEVEL_2_DS           ,
  Trim(RF.ORG_EDO_FATHR_ID_NIV2)                                            As WORK_TEAM_LEVEL_3_CD           ,
  RF.ORG_EDO_FATHR_DS_NIV2                                                  As WORK_TEAM_LEVEL_3_DS           ,
  Trim(RF.ORG_EDO_FATHR_ID_NIV3)                                            As WORK_TEAM_LEVEL_4_CD           ,
  RF.ORG_EDO_FATHR_DS_NIV3                                                  As WORK_TEAM_LEVEL_4_DS           ,
  RF.CONFIRMATION_IN                                                        As CONFIRMATION_IN,
  Null                                                                     As MIGRA_DT                      ,
  Null                                                                     As MIGRA_NEXT_OFFRE              ,
  --Sur Rforce on ne fait pas de recherche en parc
  0                                                                        As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  --Pas de livraison
  Null                                                                     As SEGMENT_DELIVERY_IN_PARK_DT      ,
  Null                                                                     As ORDER_CANCELING_DT               ,
  RF.LINE_ID                                                               As LINE_ID,
  RF.MASTER_LINE_ID                                                        As MASTER_LINE_ID,
  Null                                                                     As CUST_TYPE_CD,
  Null                                                                     As MSISDN_ID,
  RF.TERMINTN_VALUE_DS                                                     As NDS_VALUE_DS,
  RF.FREG_PARTY_EXTERNL_ID                                                 As EXTERNAL_PARTY_ID,
  RF.BSS_PARTY_EXTERNL_ID                                                  As RES_VALUE_DS,
  SERVICE_ACCESS_ID                                                        As PAR_ACCES_SERVICE,
  RF.TAC_ID                                                                As TAC_CD, 
  RF.IMEI_CD                                                               As IMEI_CD, 
  RF.IMSI_CD                                                               As IMSI_CD, 
  Null                                                                     As HOM_START_DT, 
  Null                                                                     As MOB_START_DT, 
  Null                                                                     As I_SCORE_VALUE,
  Null                                                                     As I_SCORE_TRESHOLD,
  Null                                                                     As I_SCORE_IN,
  Null                                                                     As M_SCORE_VALUE,
  Null                                                                     As M_SCORE_TRESHOLD,
  Null                                                                     As M_SCORE_IN,
  Null                                                                     As OSCAR_VALUE,
  '${P_PIL_377}'                                                           As CUST_BU_TYPE_CD,
  RF.PAR_STORE_CD                                                          As CUST_BU_CD,
  '${P_PIL_372}'                                                           As ADDRESS_TYPE,
  Trim(
    Trim(Coalesce(RF.INST_ADDRESS2_NM,'')) || ' ' || 
    Trim(Coalesce(RF.INST_ADDRESS3_NM,'')) || ' ' || 
    Trim(Coalesce(RF.INST_ADDRESS4_NM,'')) || ' ' ||
    Trim(Coalesce(RF.INST_ADDRESS5_NM,'')) || ' ' || 
    Trim(Coalesce(RF.INST_ADDRESS6_NM,''))
  )                                                                        As ADDRESS_CONCAT_NM,
  RF.POSTAL_CD                                                             As POSTAL_CD,
  RF.INSEE_NB                                                              As INSEE_CD,
  RF.PAR_BU_CD                                                             As BU_CD,
  RF.DEPARTMNT_ID                                                          As DEPARTMNT_ID,
  RF.PAR_GEO_MACROZONE                                                     As PAR_GEO_MACROZONE,
  RF.PAR_UNIFIED_PARTY_ID                                                  As PAR_UNIFIED_PARTY_ID,
  RF.PAR_PARTY_REGRPMNT_ID                                                 As PAR_PARTY_REGRPMNT_ID,
  Null                                                                     as PAR_CID_ID                      ,
  Null                                                                     as PAR_PID_ID                      ,
  Null                                                                     as PAR_FIRST_IN                    ,
  RF.PAR_IRIS2000_CD                                                       As PAR_IRIS2000_CD ,
  RF.ACT_DELTA_TARIF                                                       AS ACT_CA_LINE_AM ,
  Null                                                                     AS SIM_CD ,
  Null                                                                     AS SIM_EAN_CD ,
  RF.CHECK_INITIAL_STATUS_CD                                               As CHECK_INITIAL_STATUS_CD,
  RF.CHECK_NAT_STATUS_CD                                                   As CHECK_NAT_STATUS_CD,
  RF.CHECK_NAT_COMMENT                                                     As CHECK_NAT_COMMENT,
  RF.CHECK_NAT_STATUS_LN                                                   As CHECK_NAT_STATUS_LN,
  RF.CHECK_LOC_STATUS_CD                                                   As CHECK_LOC_STATUS_CD,
  RF.CHECK_LOC_COMMENT                                                     As CHECK_LOC_COMMENT,
  RF.CHECK_LOC_STATUS_LN                                                   As CHECK_LOC_STATUS_LN,
  RF.CHECK_VALIDT_DT                                                       As CHECK_VALIDT_DT,
  Null                                                                     As ACT_END_UNIFIED_DT,
  Null                                                                     As ACT_END_UNIFIED_DS,
  RF.CLOSURE_DT                                                            As ACT_CLOSURE_DT,
  Case When RF.CLOSURE_DT Is Not Null
       Then 'Acte Clos'        
  End                                                                      As ACT_CLOSURE_DS,
  RF.HOT_IN                                                                As HOT_IN,
  RF.RUN_ID                                                                As RUN_ID,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS,
  1                                                                        As FRESH_IN,
  0                                                                        As COHERENCE_IN 
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_HRF RF
Where
  (1=1)
  And Substr(RF.ACT_CD,1,3)           Not In (${L_PIL_036})
  And RF.ACT_SEG_COM_ID_FINAL         <> '${P_PIL_295}'
  And RF.ACT_CD                       <> '${P_PIL_067}'
  And RF.ACT_ACTE_FAMILLE_KPI         Not In (${L_PIL_626}) -- NS, NSTECH
  And RF.HOT_IN                       = 0
  And RF.INT_CREATED_BY_DT            >= Current_date - 250
  And ((RF.LAST_MODIF_TS              >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And RF.LAST_MODIF_TS  <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or RF.INT_CREATED_BY_DT > Current_date - 15) 
  --And RF.CLOSURE_DT Is Null
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_RFO;
.if errorcode <> 0 then .quit 1;
