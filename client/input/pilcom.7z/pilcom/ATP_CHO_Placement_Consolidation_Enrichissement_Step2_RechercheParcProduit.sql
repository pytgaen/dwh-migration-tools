-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_Enrichissement_Step2_RechercheParcProduit.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PARCACQ all;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- 1er cas : On fait la recherche en Parc pour les OT
----------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PARCACQ
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PARC_DT_DEBUT             ,
  PARC_DT_FIN               ,
  INB_PRESFACT_ACQ_ADV      ,
  INB_PRESFACT_ACQ_AGAP     
)
Select
  CalcTmp.ACTE_ID                                                                      as ACTE_ID                   ,
  CalcTmp.INT_DEPOSIT_DT                                                               as INT_DEPOSIT_DT            ,
  --Si pas de date de début de parc ça veut dire qu'on a rien trouvé !
  CalcTmp.PARC_DT_DEBUT                                                                as PARC_DT_DEBUT             ,
  --Si pas de date de fin de parc ça veut dire que le parc est ouver ou qu'on a rien trouvé !
  Case  When CalcTmp.PARC_DT_FIN = Cast('29991231' as Date Format 'YYYYMMDD')
          Then Null
        Else CalcTmp.PARC_DT_FIN
  End                                                                                  as PARC_DT_FIN               ,
  CalcTmp.INB_PRESFACT_ACQ_ADV                                                         as INB_PRESFACT_ACQ_ADV      ,
  CalcTmp.INB_PRESFACT_ACQ_AGAP                                                        as INB_PRESFACT_ACQ_AGAP
From
(
  Select
    RefId.ACTE_ID                                                                      as ACTE_ID               ,
    RefId.INT_DEPOSIT_DT                                                               as INT_DEPOSIT_DT        ,
    -- On prend le Min des dates de fin
    Min(ParcADV.SRVFCDOS_DT_DEBUT)                                                     as PARC_DT_DEBUT         ,
    --On prend le Max des dates de fin, Si la date est vide ça veut dire que le
    --l 'élément de parc est tjs ouvert => Donc date de fin à l'infini
    Max(coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('29991231' as date format 'YYYYMMDD')))  as PARC_DT_FIN           ,
    ParcADV.SRVFCDOS_PRESFACT_CO                                                       as INB_PRESFACT_ACQ_ADV  ,
    ParcADV.SRVFCDOS_CO_FORM                                                           as INB_PRESFACT_ACQ_AGAP 
  From
    ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 RefId
    Inner Join ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
        --Jointure Client/Dossier
      On    RefId.DOSSIER_NU                  = ParcADV.SRVFCDOS_DOSSIER_NU
        And RefId.CLIENT_NU                   = ParcADV.SRVFCDOS_CLIENT_NU
        -- Le champ SRVFCDOS_CO_FORM est valorisé uniquement pour les OT
        -- On fait la jointure sur le produit placé
        And RefId.PRESFACT_CO_OFFRE_OPT_ACQ   = ParcADV.SRVFCDOS_CO_FORM
        -- On ne considère que le parc ouvert après le dépot de la commande
        And RefId.INT_DEPOSIT_DT              <= ParcADV.SRVFCDOS_DT_DEBUT
        And ParcADV.CLOSURE_DT                is Null
        --Pour ne ramener que les OT
        And ParcADV.SRVFCDOS_CO_FORM          is not Null
  Where (1=1)
    And RefId.PRESFACT_CO_OFFRE_OPT_ACQ is not Null
  Group by
    RefId.ACTE_ID                   ,
    RefId.INT_DEPOSIT_DT            ,
    ParcADV.SRVFCDOS_PRESFACT_CO    ,
    ParcADV.SRVFCDOS_CO_FORM        
) CalcTmp

----------------------------------------------------------------------------
-- 1er cas : On fait la recherche en Parc pour les SO
----------------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PARCACQ
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PARC_DT_DEBUT             ,
  PARC_DT_FIN               ,
  INB_PRESFACT_ACQ_ADV      ,
  INB_PRESFACT_ACQ_AGAP     
)
Select
  CalcTmp.ACTE_ID                                                                      as ACTE_ID                   ,
  CalcTmp.INT_DEPOSIT_DT                                                               as INT_DEPOSIT_DT            ,
  --Si pas de date de début de parc ça veut dire qu'on a rien trouvé !
  CalcTmp.PARC_DT_DEBUT                                                                as PARC_DT_DEBUT             ,
  --Si pas de date de fin de parc ça veut dire que le parc est ouver ou qu'on a rien trouvé !
  Case  When CalcTmp.PARC_DT_FIN = Cast('29991231' as Date Format 'YYYYMMDD')
          Then Null
        Else CalcTmp.PARC_DT_FIN
  End                                                                                  as PARC_DT_FIN               ,
  CalcTmp.INB_PRESFACT_ACQ_ADV                                                         as INB_PRESFACT_ACQ_ADV      ,
  CalcTmp.INB_PRESFACT_ACQ_AGAP                                                        as INB_PRESFACT_ACQ_AGAP
From
(
  Select
    RefId.ACTE_ID                                                                       as ACTE_ID                    ,
    RefId.INT_DEPOSIT_DT                                                                as INT_DEPOSIT_DT             ,
    -- On prend le Min des dates de fin
    Min(ParcADV.SRVFCDOS_DT_DEBUT)                                                      as PARC_DT_DEBUT              ,
    --On prend le Max des dates de fin, Si la date est vide ça veut dire que le
    --l 'élément de parc est tjs ouvert => Donc date de fin à l'infini
    Max(coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('29991231' as date format 'YYYYMMDD')))   as PARC_DT_FIN                ,
    ParcADV.SRVFCDOS_PRESFACT_CO                                                        as INB_PRESFACT_ACQ_ADV       ,
    Opt.SERVOPT_CO                                                                      as INB_PRESFACT_ACQ_AGAP      
  From
    ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 RefId
    Inner Join ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
        --Jointure Client/Dossier
      On    RefId.DOSSIER_NU                  =   ParcADV.SRVFCDOS_DOSSIER_NU
        And RefId.CLIENT_NU                   =   ParcADV.SRVFCDOS_CLIENT_NU
        -- On ne considère que le parc ouvert après le dépot de la commande
        And RefId.INT_DEPOSIT_DT              <=  ParcADV.SRVFCDOS_DT_DEBUT
        And ParcADV.CLOSURE_DT                is null
        --Pour ne ramener que les SO
        And ParcADV.SRVFCDOS_CO_FORM          is Null
    Inner Join ${KNB_IBU_SOC}.V_TDSERVOPT Opt
        --Jointure entre Le parc et le referentiel des SO
      On    ParcADV.SRVFCDOS_PRESFACT_CO      = Opt.SERVOPT_CO_PREST_ABONN
         -- On fait la jointure sur le produit placé
        And RefId.PRESFACT_CO_OFFRE_OPT_ACQ   = Opt.SERVOPT_CO
        And Opt.CURRENT_IN                    = 1
  Where (1=1)
    And RefId.PRESFACT_CO_OFFRE_OPT_ACQ is not Null
  Group by
    RefId.ACTE_ID                 ,
    RefId.INT_DEPOSIT_DT          ,
    ParcADV.SRVFCDOS_PRESFACT_CO  ,
    Opt.SERVOPT_CO                
) CalcTmp
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PARCACQ;
.if errorcode <> 0 then .quit 1

.quit 0
