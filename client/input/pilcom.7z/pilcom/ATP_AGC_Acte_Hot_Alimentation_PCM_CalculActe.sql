-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_Acte_Hot_Alimentation_PCM_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul des actes PCM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 07/04/2014      YZH         Creation
-- 13/10/2014      KBH         Modif QC #769
-- 22/10/2014      KBH         Modif évol PCM
-- 06/07/2016      MDE         Modif : ORG_GT_ACTIVITY  tronqué
-- 12/12/2016      HOB         Modif : Ajout Champs VA
-- 30/06/2017      HOB         Modif TERMINAUX SUB
-- 19/12/2017      HOB         Modif IOBSP
-- 27/09/2019      EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF / ACT_UNITE_CD
-- 15/04/2020      YAB         Modification de l'alimentation ACT_DELTA_TARIF KPI2020 
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------


.set width 2500;




Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_AGC_PCM_H All;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_AGC_PCM_H
(
  -- Champs clÃ©s du flux
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  ACTE_ID_CMD_RAPPROCHEE            ,
  INTRNL_SOURCE_ID                  ,
  CONTEXT_ID                        ,
  EXTERNAL_ORDER_ID                 ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_TYPE_CD                     ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  INB_PRESFACT_ACQ_ADV              ,           
  INB_PRESFACT_ACQ_AGAP             ,
  SEG_PARC_DT_DEBUT                 ,
  INB_PARK_ID                       ,
  TERMINAL_PRICE                    ,
  DISCOUNT                          ,
  PCM_REMNNG_UNPAID                 ,
  ENGGMNT_DURATION                  ,
  FLAG_HD                           ,
  ORG_CHANNEL_ID                    ,
  ORG_CHANNEL_CD                    ,
  ORG_SUB_CHANNEL_CD                ,
  ORG_SUB_SUB_CHANNEL_CD            ,
  ORG_REM_CHANNEL_CD                ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORIG_DEM                          ,
  CANALDEM_MTHD                     ,
  ORG_CHANNEL_ID_MACRO              ,
  ORG_CHANNEL_MACRO_LB              ,
  ORG_STORE_NAME                    ,
  ORG_FLAG_TYPE_PTN_NTK             ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_EDO_IOBSP                     ,
  ORG_AGENT_IOBSP                   ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  PAR_EXTERNAL_PARTY_FREG_ID        ,
  PAR_PARTY_KNB_FREG_ID             ,
  PAR_AID                           ,
  PAR_PARTY_KNB_BSS_ID              ,
  PAR_ND                            ,
  PAR_ACCES_SERVICE                 ,
  PAR_ADV_CLIENT_NU                 ,
  PAR_ADV_DOSSIER_NU                ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  OTO_OSCAR_VALUE_NU                ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_SIRET                         ,
  PAR_MARKET_SEG                    ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_CD_POSTAL                ,
  PAR_MAIL_CONTACT                  ,
  PAR_MSISDN_CONTACT                ,
  PAR_INVOICE_MAIL                  ,
  PAR_DO                            ,
  PAR_BU_CD                         ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  CODE_EAN                          ,
  PAR_MOB_IMEI                      ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  SIM_EAN_CD                        ,
  PAR_MOB_IMSI                      ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  CONTRCT_DT_SIGN_PREC_MOB          ,
  CONTRCT_DT_FIN_PREC_MOB           ,
  CONTRCT_DT_SIGN_POST_MOB          ,
  CONTRCT_DUREE_ENG_MOB             ,
  CONTRCT_UNIT_ENG_MOB              ,
  CONFIRMATION_IN                   ,
  CONFIRMATION_DT                   ,
  CONFIRMATION_CALC_FIN_DT          ,
  DELIVERY_IN                       ,
  DELIVERY_DT                       ,
  DELIVERY_CALC_FIN_DT              ,
  DELIVERY_ONTIME_IN                ,
  DELIVERY_DEAD_LINE_NU             ,
  PERNNT_IN                         ,
  PERNNT_END_DT                     ,
  PERNNT_CALC_END_DT                ,
  SEG_PRES_PARC_COMMANDE            ,
  CONCURENCE_IN                     ,
  CONCURENCE_CONCLU_IN              ,
  CONCURENCE_ID                     ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                         as ACTE_ID                            ,
  Placement.ACTE_ID                                         as ACTE_ID_GEN                        ,
  ActeAGC.ACTE_ID_CMD_RAPPROCHEE                            as ACTE_ID_CMD_RAPPROCHEE             ,
  Placement.INTRNL_SOURCE_ID                                as INTRNL_SOURCE_ID                   ,
  Placement.CONTEXT_ID                                      as CONTEXT_ID                         ,
  Placement.EXTERNAL_ORDER_ID                               as EXTERNAL_ORDER_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                as ORDER_DEPOSIT_TS                   ,
  Placement.ORDER_DEPOSIT_DT                                as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_TYPE_CD                                   as ORDER_TYPE_CD                      ,
  ActeAGC.PRODUCT_ID_PRE                                    as ACT_PRODUCT_ID_PRE                 ,
  ActeAGC.SEG_COM_ID_PRE                                    as ACT_SEG_COM_ID_PRE                 ,
  ActeAGC.SEG_COM_AGG_ID_PRE                                as ACT_SEG_COM_AGG_ID_PRE             ,
  ActeAGC.CODE_MIGR_PRE                                     as ACT_CODE_MIGR_PRE                  ,
  ActeAGC.TYPE_MVT_PRE                                      as ACT_OPER_ID_PRE                    ,
  ActeAGC.PRODUCT_ID_FINAL                                  as ACT_PRODUCT_ID_FINAL               ,
  ActeAGC.SEG_COM_ID_FINAL                                  as ACT_SEG_COM_ID_FINAL               ,
  ActeAGC.SEG_COM_AGG_ID_FINAL                              as ACT_SEG_COM_AGG_ID_FINAL           ,
  ActeAGC.CODE_MIGR_FINAL                                   as ACT_CODE_MIGR_FINAL                ,
  ActeAGC.TYPE_MVT_FINAL                                    as ACT_OPER_ID_FINAL                  ,
  ActeAGC.TYPE_SERVICE_FINAL                                as ACT_TYPE_SERVICE_FINAL             ,
  Case When Placement.ORDER_TYPE_CD = '5'
    Then '${P_PIL_057}'       -- MEG
  Else ActeAGC.TYPE_COMMANDE_ID                           
  End                                                       as ACT_TYPE_COMMANDE_ID               ,
  Case
  -- Unite = CA  
    When ACT_UNITE_CD ='${P_PIL_490}' 
         Then   Null
    -- Unite = NB  
      When ACT_UNITE_CD ='${P_PIL_620}' 
        Then
          case  When ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
              Then Coalesce(EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT,0) 
              Else ActeAGC.DELTA_TARIF
          End
    -- Unite = MKT
    When ACT_UNITE_CD ='${P_PIL_623}' 
         Then   Coalesce (Mat.CA_MARKETING, Mat2.CA_MARKETING)
    -- Unite = CA_CALIPSO (TMX)  
    When ACT_UNITE_CD ='${P_PIL_622}' 
         Then  Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)  
    Else Null
  END                                                       as ACT_DELTA_TARIF                    ,         
  Coalesce(Mat.UNITE_CD, Mat2.UNITE_CD)                     as ACT_UNITE_CD                       ,
  Coalesce(Mat.ACTE_ID, Mat2.ACTE_ID, '${P_PIL_067}')       as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID, Mat2.ACTE_REM_ID, '${P_PIL_067}') as ACT_REM_ID                       ,
  Coalesce(Mat.FLAG_ACT_REM, Mat2.FLAG_ACT_REM,'N')         as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC, Mat2.FLAG_PEC_PERPVC,'N')   as ACT_FLAG_PEC_PERPVC                ,
  Case
    -- Unite = CA  
    When ACT_UNITE_CD ='${P_PIL_490}' 
         Then   Null
    -- Unite = NB  
    When ACT_UNITE_CD ='${P_PIL_620}' 
         Then   Coalesce(Mat.ACTE_VALO, Mat2.ACTE_VALO,0) 
    -- Unite = MKT
    When ACT_UNITE_CD ='${P_PIL_623}' 
         Then   ( ACT_DELTA_TARIF * Coalesce(Mat.TAUX_MARGE, Mat2.TAUX_MARGE) )
    -- Unite = CA_CALIPSO (TMX)  
    When ACT_UNITE_CD ='${P_PIL_622}' 
         Then   ( ACT_DELTA_TARIF * Coalesce(Mat.TAUX_MARGE, Mat2.TAUX_MARGE) ) 
    Else Null
  END                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Mat.ACTE_FAMILLE_KPI, Mat2.ACTE_FAMILLE_KPI, 'NON PARAM') as ACT_ACTE_FAMILLE_KPI      ,
  ActeAGC.PERIODE_ID                                        as ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                  as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            as ACT_PERIODE_CLOSURE_DT             ,  
  Null                                                      as INB_PRESFACT_ACQ_ADV               ,
  Null                                                      as INB_PRESFACT_ACQ_AGAP              ,
  Null                                                      as SEG_PARC_DT_DEBUT                  ,
  Null                                                      as INB_PARK_ID                        ,
  Placement.TERMINAL_PRICE                                  as TERMINAL_PRICE                     ,
  Placement.DISCOUNT                                        as DISCOUNT                           ,
  Placement.PCM_REMNNG_UNPAID                               as PCM_REMNNG_UNPAID                  ,
  Placement.ENGGMNT_DURATION                                as ENGGMNT_DURATION                   ,
  Mat.HUMAINDIGITAL                                         as FLAG_HD                            ,
  Null                                                      as ORG_CHANNEL_ID                     ,
  --Calcul du canal de vente Macro
  'Dist'                                                    as ORG_CHANNEL_CD                     ,
  --Sous Canal
  Case When Placement.NETWRK_TYP_EDO_ID = 'FT'
       Then 'AD'
       When Placement.NETWRK_TYP_EDO_ID <> 'FT'
            And Placement.FLAG_TYPE_CPT_NTK Is Not Null 
       Then 'RC'
       When Placement.NETWRK_TYP_EDO_ID <> 'FT'
            And Placement.FLAG_TYPE_PTN_NTK Is Not Null 
       Then 'RP'       
  End                                                       as ORG_SUB_CHANNEL_CD                 ,
  --Sous Sous Canal
  Case   When ORG_SUB_CHANNEL_CD='RC' and Placement.FLAG_TYPE_CPT_NTK ='AUT'
        Then 'AUTRC'
       When ORG_SUB_CHANNEL_CD='RC' and Placement.FLAG_TYPE_CPT_NTK ='GRO'
        Then 'GROSS'
       When ORG_SUB_CHANNEL_CD='RC'
        Then Placement.FLAG_TYPE_CPT_NTK
       When 
        ( Placement.NETWRK_TYP_EDO_ID = 'FT' or ORG_SUB_CHANNEL_CD in ('AD', 'RP') )
        And FLAG_TYPE_GEO is Not NULL            
       Then 'DOM'
       Else 'Metropole'
  End                                                       as ORG_SUB_SUB_CHANNEL_CD             ,
  -- Canle Rem
  Case When Placement.NETWRK_TYP_EDO_ID = 'FT'
       Then 'AD'  
       Else 'Exclus'
  End                                                       as ORG_REM_CHANNEL_CD                 ,
  --ActivitÃ©
  Case When  ORG_SUB_CHANNEL_CD='AD'
       Then 'Boutique FT'     
       When  ORG_SUB_CHANNEL_CD='RC'
       Then  'Reseau Concurrent'              
       When  Placement.FLAG_TYPE_PTN_NTK is not Null
       Then  Placement.FLAG_TYPE_PTN_NTK        
  End                                                       as ORG_GT_ACTIVITY                    ,
  --Fidelisaion     
   'NONPARAM'                                               as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
   'NON'                                                    as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique                              
   'NON'                                                    as ORG_AUTO_ACTIVITY                  ,
  Null                                                      as ORIG_DEM                           ,
  Null                                                      as CANALDEM_MTHD                      ,
  Null                                                      as ORG_CHANNEL_ID_MACRO               ,
  Null                                                      as ORG_CHANNEL_MACRO_LB               ,
  Placement.ADV_STORE_CD                                    as ORG_STORE_NAME                     ,
  Placement.FLAG_TYPE_PTN_NTK                               as ORG_FLAG_TYPE_PTN_NTK              ,
  Placement.EDO_ID                                          as ORG_EDO_ID                         ,
  Placement.TYPE_EDO                                        as ORG_TYPE_EDO                       ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                      ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                    ,
  Placement.FLAG_PLT_CONV                                   as ORG_FLAG_PLT_CONV                  ,
  Placement.FLAG_TEAM_MKT                                   as ORG_FLAG_TEAM_MKT                  ,
  Placement.FLAG_TYPE_CMP                                   as ORG_FLAG_TYPE_CMP                  ,
  Placement.NETWRK_TYP_EDO_ID                               as ORG_NETWRK_TYP_EDO_ID              ,
  Placement.FLAG_TYPE_GEO                                   as ORG_FLAG_TYPE_GEO                  ,
  Placement.FLAG_TYPE_CPT_NTK                               as ORG_FLAG_TYPE_CPT_NTK              ,            
  Null                                                      as ORG_REF_TRAV                       ,
  Placement.AGENT_ID                                        as ORG_AGENT_ID                       ,
  Null                                                      as ORG_POC_XI                         ,
  Placement.AGENT_ID                                        as ORG_AGENT_ID_UPD                   ,
  Null                                                      as ORG_AGENT_ID_UPD_DT                ,
  Placement.AGENT_LAST_NAME_NM                              as ORG_NOM                            ,
  Placement.AGENT_FIRST_NAME_NM                             as ORG_PRENOM                         ,
  Null                                                      as ORG_GROUPE_ID                      ,
  Null                                                      as ORG_ACTVT_REEL                     ,
  Null                                                      as ORG_RESP_REF_TRAV                  ,
  Null                                                      as ORG_RESP_AGENT_ID                  ,
  Null                                                      as ORG_RESP_XI                        ,
  Null                                                      as PAR_EXTERNAL_PARTY_FREG_ID         ,
  Null                                                      as PAR_PARTY_KNB_FREG_ID              ,
  Null                                                      as PAR_AID                            ,
  Null                                                      as PAR_PARTY_KNB_BSS_ID               ,
  Null                                                      as PAR_ND                             ,
  Null                                                      as PAR_ACCES_SERVICE                  ,
  Placement.CUSTOMER_CLIENT_NU_ADV                          as PAR_ADV_CLIENT_NU                  ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                         as PAR_ADV_DOSSIER_NU                 ,
  Null                                                      as DMC_LINE_ID                        ,
  Null                                                      as DMC_MASTER_LINE_ID                 ,
  Null                                                      as PAR_GEO_MACROZONE                  ,
  Null                                                      as PAR_UNIFIED_PARTY_ID               ,
  Null                                                      as PAR_PARTY_REGRPMNT_ID              ,
  Case When Placement.CUSTOMER_CATEGORIE Is Null 
    Then '0'
    Else Placement.CUSTOMER_CATEGORIE
  End                                                       as OTO_OSCAR_VALUE_NU                 ,
  Placement.CUSTOMER_LAST_NAME_NM                           as PAR_LASTNAME                       ,
  Placement.CUSTOMER_FIRST_NAME_NM                          as PAR_FIRSTNAME                      ,
  Placement.CUSTOMER_SIRET                                  as PAR_SIRET                          ,
  Placement.CUSTOMER_MARKET_SEG                             as PAR_MARKET_SEG                     ,
  Null                                                      as PAR_TYPE                           ,
  Null                                                      as PAR_EMAIL                          ,
  CUSTOMER_ADDRESS_1_NM                                     as PAR_BILL_ADRESS_1                  ,
  CUSTOMER_ADDRESS_2_NM                                     as PAR_BILL_ADRESS_2                  ,
  CUSTOMER_ADDRESS_3_NM                                     as PAR_BILL_ADRESS_3                  ,
  Placement.CUSTOMER_CITY                                   as PAR_BILL_ADRESS_4                  ,
  Placement.CUSTOMER_ADDRESS_POSTAL_CD                      as PAR_BILL_CD_POSTAL                 ,
  Placement.CUSTOMER_MAIL_CONTACT                           as PAR_MAIL_CONTACT                   ,
  Placement.CUSTOMER_MSISDN_CONTACT                         as PAR_MSISDN_CONTACT                 ,
  Placement.INVOICE_ADDRESS_MAIL_NM                         as PAR_INVOICE_MAIL                   ,
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Placement.CUSTOMER_ADDRESS_POSTAL_CD) From 1 For 3) In (${L_PIL_034})
        Then    Substring(Trim(Placement.CUSTOMER_ADDRESS_POSTAL_CD) From 1 For 3)
        When    Placement.CUSTOMER_ADDRESS_POSTAL_CD Is not Null
        Then    Substring(Trim(Placement.CUSTOMER_ADDRESS_POSTAL_CD) From 1 For 2)
        Else    Null
  End                                                       as PAR_DO                             ,
  Null                                                      as PAR_BU_CD                          ,
  Null                                                      as PAR_USCM                           ,
  Null                                                      as PAR_USCM_DS                        ,
  Null                                                      as PAR_USCM_USCM_DS                   ,
  Null                                                      as PAR_USCM_REGUSCM                   ,
  Null                                                      as PAR_USCM_REGUSCM_DS                ,
  Placement.EXTERNAL_PRODUCT_ID                             as CODE_EAN                           ,
  Placement.PAR_IMEI_CD                                     as PAR_MOB_IMEI                       ,
  Null                                                      as PAR_MOB_TAC                        ,
  Placement.SIM_CD                                          as PAR_MOB_SIM                        ,
  Placement.SIM_EAN_CD                                      as SIM_EAN_CD                         ,
  Null                                                      as PAR_MOB_IMSI                       ,
  Null                                                      as PAR_SCORE_NU_MOB                   ,
  Null                                                      as PAR_SCORE_IN_MOB                   ,
  Null                                                      as PAR_TRESHOLD_NU_MOB                ,
  Null                                                      as CONTRCT_DT_SIGN_PREC_MOB           ,
  Null                                                      as CONTRCT_DT_FIN_PREC_MOB            ,
  Null                                                      as CONTRCT_DT_SIGN_POST_MOB           ,
  Null                                                      as CONTRCT_DUREE_ENG_MOB              ,
  Null                                                      as CONTRCT_UNIT_ENG_MOB               ,
  Null                                                      as CONFIRMATION_IN                    ,
  Null                                                      as CONFIRMATION_DT                    ,
  Null                                                      as CONFIRMATION_CALC_FIN_DT           ,
  Null                                                      as DELIVERY_IN                        ,
  Null                                                      as DELIVERY_DT                        ,
  Null                                                      as DELIVERY_CALC_FIN_DT               ,
  Null                                                      as DELIVERY_ONTIME_IN                 ,
  Null                                                      as DELIVERY_DEAD_LINE_NU              ,
  Null                                                      as PERNNT_IN                          ,
  Null                                                      as PERNNT_END_DT                      ,
  Null                                                      as PERNNT_CALC_END_DT                 ,
  Null                                                      as SEG_PRES_PARC_COMMANDE             ,
  Null                                                      as CONCURENCE_IN                      ,
  Null                                                      as CONCURENCE_CONCLU_IN               ,
  Null                                                      as CONCURENCE_ID                      ,
  Null                                                      as CHECK_INITIAL_STATUS_CD            ,
  Null                                                      as CHECK_NAT_STATUS_CD                ,
  Null                                                      as CHECK_NAT_COMMENT                  ,
  Null                                                      as CHECK_NAT_STATUS_LN                ,
  Null                                                      as CHECK_LOC_STATUS_CD                ,
  Null                                                      as CHECK_LOC_COMMENT                  ,
  Null                                                      as CHECK_LOC_STATUS_LN                ,
  Null                                                      as CHECK_VALIDT_DT                    ,
  Placement.CLOSURE_DT                                      as CLOSURE_DT                         ,
  Placement.QUEUE_TS                                        as QUEUE_TS                           ,
  Placement.RUN_ID                                          as RUN_ID                             ,
  Placement.STREAMING_TS                                    as STREAMING_TS                       ,
  Current_timestamp(0)                                      as CREATION_TS                        ,
  Current_timestamp(0)                                      as LAST_MODIF_TS                      ,
  1                                                         as HOT_IN                             ,
  1                                                         as FRESH_IN                           ,
  0                                                         as COHERENCE_IN                       
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_PCM_H Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_PCM_CALC ActeAGC
    On    Placement.ACTE_ID                                = ActeAGC.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                       = ActeAGC.ORDER_DEPOSIT_DT 
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat
      On                          
          Case When Placement.ORDER_TYPE_CD = '5'
          Then '${P_PIL_057}'       -- MEG
          Else ActeAGC.TYPE_COMMANDE_ID                           
          End                                              = Mat.TYPE_COMMANDE_ID                   
      And ActeAGC.SEG_COM_ID_FINAL                         = Mat.SEG_COM_ID_FINAL
      And ActeAGC.PERIODE_ID                               = Mat.PERIODE_ID
      And ActeAGC.CUSTOMER_CATEGORIE                       = Mat.CATEGORIE_CLIENT_ID
      And '${P_PIL_211}'                                   = Mat.SEG_COM_ID_INI
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat2         
      On                          
          Case When Placement.ORDER_TYPE_CD = '5'
          Then '${P_PIL_057}'       -- MEG
          Else ActeAGC.TYPE_COMMANDE_ID                           
          End                                              = Mat2.TYPE_COMMANDE_ID                   
      And ActeAGC.SEG_COM_ID_FINAL                         = Mat2.SEG_COM_ID_FINAL
      And ActeAGC.PERIODE_ID                               = Mat2.PERIODE_ID
      And Mat2.CATEGORIE_CLIENT_ID                         = 'SC'
      And '${P_PIL_211}'                                   = Mat2.SEG_COM_ID_INI
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
      On  ActeAGC.PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                           = 1
      And EtatPeriode.FRESH_IN                             = 1
      And EtatPeriode.CLOSURE_DT                           Is Null            
  -- KPI2020 : Jointure Referentiel CALIPSO
  Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB
     On EAN_Canal_WEB.EAN_CD = Placement.EXTERNAL_PRODUCT_ID
     And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM
     On  EAN_Canal_DOM.EAN_CD = Placement.EXTERNAL_PRODUCT_ID
     And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_AGC_PCM_H;
.if errorcode <> 0 then .quit 1

