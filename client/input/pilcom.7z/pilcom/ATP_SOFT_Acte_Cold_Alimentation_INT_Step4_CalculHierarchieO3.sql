-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step4_CalculHierarchieO3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql calcul de la hierrachie O3 à partir de l'edo
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE             AUTEUR      CREATION/MODIFICATION
-- 25/02/2013       GMA         Creation
-- 10/01/2014       GMA         Mise à jour normes DSM
-- 26/08/2014       GMA         Stabilisation de l'axe Orga
-- 20/10/2014       HZO         Modification : Correctif sur le NOT_EXIST
--------------------------------------------------------------------------------

.set width 2500;





Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ORGO3 all;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 1 : On insert l'orga à partir du traçage automatique                             ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ORGO3
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ORG_TYPE_CD               ,
  ORG_TEAM_LEVEL_1_CD       ,
  ORG_TEAM_LEVEL_1_DS       ,
  ORG_TEAM_LEVEL_2_CD       ,
  ORG_TEAM_LEVEL_2_DS       ,
  ORG_TEAM_LEVEL_3_CD       ,
  ORG_TEAM_LEVEL_3_DS       ,
  ORG_TEAM_LEVEL_4_CD       ,
  ORG_TEAM_LEVEL_4_DS       ,
  WORK_TEAM_LEVEL_1_CD      ,
  WORK_TEAM_LEVEL_1_DS      ,
  WORK_TEAM_LEVEL_2_CD      ,
  WORK_TEAM_LEVEL_2_DS      ,
  WORK_TEAM_LEVEL_3_CD      ,
  WORK_TEAM_LEVEL_3_DS      ,
  WORK_TEAM_LEVEL_4_CD      ,
  WORK_TEAM_LEVEL_4_DS      
)
Select
  RefIdAuto.ACTE_ID                         as ACTE_ID                    ,
  RefIdAuto.ORDER_DEPOSIT_DT                as ORDER_DEPOSIT_DT           ,
  'O3'                                      as ORG_TYPE_CD                ,
  WLvl1.WORK_TEAM_LEVEL_1_CD                as WORK_TEAM_LEVEL_1_CD       ,
  WLvl1.WORK_TEAM_LEVEL_1_DS                as WORK_TEAM_LEVEL_1_DS       ,
  WLvl1.WORK_TEAM_LEVEL_2_CD                as WORK_TEAM_LEVEL_2_CD       ,
  WLvl1.WORK_TEAM_LEVEL_2_DS                as WORK_TEAM_LEVEL_2_DS       ,
  WLvl1.WORK_TEAM_LEVEL_3_CD                as WORK_TEAM_LEVEL_3_CD       ,
  WLvl1.WORK_TEAM_LEVEL_3_DS                as WORK_TEAM_LEVEL_3_DS       ,
  WLvl1.WORK_TEAM_LEVEL_4_CD                as WORK_TEAM_LEVEL_4_CD       ,
  WLvl1.WORK_TEAM_LEVEL_4_DS                as WORK_TEAM_LEVEL_4_DS       ,
  WLvl1.WORK_TEAM_LEVEL_1_CD                as WORK_TEAM_LEVEL_1_CD       ,
  WLvl1.WORK_TEAM_LEVEL_1_DS                as WORK_TEAM_LEVEL_1_DS       ,
  WLvl1.WORK_TEAM_LEVEL_2_CD                as WORK_TEAM_LEVEL_2_CD       ,
  WLvl1.WORK_TEAM_LEVEL_2_DS                as WORK_TEAM_LEVEL_2_DS       ,
  WLvl1.WORK_TEAM_LEVEL_3_CD                as WORK_TEAM_LEVEL_3_CD       ,
  WLvl1.WORK_TEAM_LEVEL_3_DS                as WORK_TEAM_LEVEL_3_DS       ,
  WLvl1.WORK_TEAM_LEVEL_4_CD                as WORK_TEAM_LEVEL_4_CD       ,
  WLvl1.WORK_TEAM_LEVEL_4_DS                as WORK_TEAM_LEVEL_4_DS       
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_TRC_AUTO RefIdAuto
  --On jointe dans l'orga de Travail
  Left Outer Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL WLvl1
    On    RefIdAuto.CPLT_O3_ACTIVE_TEAM_CD        =   WLvl1.WORK_TEAM_LEVEL_1_CD
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_1_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_1_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_2_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_2_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_3_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_3_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_4_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_4_END_DT
Where
  (1=1)
  And 
      (
          RefIdAuto.CPLT_O3_ACTIVE_TEAM_CD        Is Not Null
        Or
          RefIdAuto.CPLT_O3_RATTACHEMENT_TEAM_CD  Is Not Null
      )
Qualify Row_Number() Over (Partition By RefIdAuto.ACTE_ID Order By        WLvl1.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1




Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ORGO3;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 1 : On insert l'orga à partir de la donnée SOFT                                  ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ORGO3
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ORG_TYPE_CD               ,
  ORG_TEAM_LEVEL_1_CD       ,
  ORG_TEAM_LEVEL_1_DS       ,
  ORG_TEAM_LEVEL_2_CD       ,
  ORG_TEAM_LEVEL_2_DS       ,
  ORG_TEAM_LEVEL_3_CD       ,
  ORG_TEAM_LEVEL_3_DS       ,
  ORG_TEAM_LEVEL_4_CD       ,
  ORG_TEAM_LEVEL_4_DS       ,
  WORK_TEAM_LEVEL_1_CD      ,
  WORK_TEAM_LEVEL_1_DS      ,
  WORK_TEAM_LEVEL_2_CD      ,
  WORK_TEAM_LEVEL_2_DS      ,
  WORK_TEAM_LEVEL_3_CD      ,
  WORK_TEAM_LEVEL_3_DS      ,
  WORK_TEAM_LEVEL_4_CD      ,
  WORK_TEAM_LEVEL_4_DS      
)
Select
  Refid.ACTE_ID                             as ACTE_ID                    ,
  Refid.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT           ,
  'O3'                                      as ORG_TYPE_CD                ,
  Null                                      as ORG_TEAM_LEVEL_1_CD        ,
  Null                                      as ORG_TEAM_LEVEL_1_DS        ,
  Null                                      as ORG_TEAM_LEVEL_2_CD        ,
  Null                                      as ORG_TEAM_LEVEL_2_DS        ,
  Null                                      as ORG_TEAM_LEVEL_3_CD        ,
  Null                                      as ORG_TEAM_LEVEL_3_DS        ,
  Null                                      as ORG_TEAM_LEVEL_4_CD        ,
  Null                                      as ORG_TEAM_LEVEL_4_DS        ,
  WLvl1.WORK_TEAM_LEVEL_1_CD                as WORK_TEAM_LEVEL_1_CD       ,
  WLvl1.WORK_TEAM_LEVEL_1_DS                as WORK_TEAM_LEVEL_1_DS       ,
  WLvl1.WORK_TEAM_LEVEL_2_CD                as WORK_TEAM_LEVEL_2_CD       ,
  WLvl1.WORK_TEAM_LEVEL_2_DS                as WORK_TEAM_LEVEL_2_DS       ,
  WLvl1.WORK_TEAM_LEVEL_3_CD                as WORK_TEAM_LEVEL_3_CD       ,
  WLvl1.WORK_TEAM_LEVEL_3_DS                as WORK_TEAM_LEVEL_3_DS       ,
  WLvl1.WORK_TEAM_LEVEL_4_CD                as WORK_TEAM_LEVEL_4_CD       ,
  WLvl1.WORK_TEAM_LEVEL_4_DS                as WORK_TEAM_LEVEL_4_DS       
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI Refid
  Inner Join ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_INT RefPlacement
    On    Refid.ACTE_ID                           = RefPlacement.ACTE_ID
    And   Refid.ORDER_DEPOSIT_DT                  = RefPlacement.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL WLvl1
    On    RefPlacement.EDO_ID                     =   WLvl1.WORK_TEAM_LEVEL_1_CD
      And RefPlacement.ORDER_DEPOSIT_DT           >=  WLvl1.WORK_TEAM_LEVEL_1_START_DT
      And RefPlacement.ORDER_DEPOSIT_DT           <=  WLvl1.WORK_TEAM_LEVEL_1_END_DT
      And RefPlacement.ORDER_DEPOSIT_DT           >=  WLvl1.WORK_TEAM_LEVEL_2_START_DT
      And RefPlacement.ORDER_DEPOSIT_DT           <=  WLvl1.WORK_TEAM_LEVEL_2_END_DT
      And RefPlacement.ORDER_DEPOSIT_DT           >=  WLvl1.WORK_TEAM_LEVEL_3_START_DT
      And RefPlacement.ORDER_DEPOSIT_DT           <=  WLvl1.WORK_TEAM_LEVEL_3_END_DT
      And RefPlacement.ORDER_DEPOSIT_DT           >=  WLvl1.WORK_TEAM_LEVEL_4_START_DT
      And RefPlacement.ORDER_DEPOSIT_DT           <=  WLvl1.WORK_TEAM_LEVEL_4_END_DT
Where
  (1=1)
  And RefPlacement.EDO_ID       Is Not Null
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ORGO3 RefDejaCalc
    Where
      (1=1)
      And Refid.ACTE_ID               = RefDejaCalc.ACTE_ID
      And Refid.ORDER_DEPOSIT_DT      = RefDejaCalc.ORDER_DEPOSIT_DT
  )
Qualify Row_Number() Over (Partition By Refid.ACTE_ID Order By            WLvl1.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1




Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ORGO3;
.if errorcode <> 0 then .quit 1



.quit 0




