-- $HEADER: mm2pco/current/sql/INIT_PCO_ERDV_RecuperationDataFromDataLab.sql 13_05#1 21-FEV-2017 10:54:54 FQJR5800
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   INIT_PCO_ERDV_RecuperationDataFromDataLab.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 17/02/2017      MDE         Creation
--------------------------------------------------------------------------------

.set width 2500;

Create Multiset Volatile Table ${KNB_TERADATA_USER}.ATP_V_IDORDER_ERDV_TO_LOAD_P(
  MSG_ID VARCHAR(20)  NOT NULL
)
PRIMARY INDEX ( MSG_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

--Alimentation de la table Volatile avec les ID :
--Principe On fait N requete pour chaque sous ensemble de commande et on agrège ensuite tout.
Insert Into ${KNB_TERADATA_USER}.ATP_V_IDORDER_ERDV_TO_LOAD_P
(
  MSG_ID
)
Select
  CalculFinal.MSG_ID   as MSG_ID  
From
  (
    --On agrège l'ensemble sur la clé afin de supprimer les null des sous ensemble de requete
    Select
      FusionComm.MSG_ID                   as MSG_ID             ,
      Coalesce(Max(NB_LINE_ORDER_NU),0)   as NB_LINE_ORDER_NU   ,
      Coalesce(Max(COUNTLINEORDER),0)     as COUNTLINEORDER     ,
      Coalesce(Max(NB_LINE_OPER_NU),0)    as NB_LINE_OPER_NU    ,
      Coalesce(Max(COUNTLINEORDEROP),0)   as COUNTLINEORDEROP   
    From
      (
          --On requete Pour calculer si le nombre de ligne de commande Internet
          Select
            RefCommande.MSG_ID                      as MSG_ID             ,
            RefCommande.NB_LINE_ORDER_NU            as NB_LINE_ORDER_NU   ,
            Count(LigneInternet.MSG_ID)             as COUNTLINEORDER     ,
            null                                    as NB_LINE_OPER_NU    ,
            null                                    as COUNTLINEORDEROP   
          From
            PLC_LAB_TMP.REP_O_ORDER_ERDV_COM RefCommande
            Inner Join PLC_LAB_TMP.REP_O_ORDER_ERDV_LINE_COM LigneInternet
              On    RefCommande.MSG_ID = LigneInternet.MSG_ID
          Where
            (1=1)
          Group by
            RefCommande.MSG_ID            ,
            RefCommande.NB_LINE_ORDER_NU  
        Union All
          --On requete Pour calculer si le nombre de ligne de commande Mobile
          Select
            RefCommande.MSG_ID                      as MSG_ID             ,
            Null                                    as NB_LINE_ORDER_NU   ,
            Null                                    as COUNTLINEORDER     ,
            RefCommande.NB_LINE_OPER_NU             as NB_LINE_OPER_NU    ,
            Count(LigneMobile.MSG_ID)               as COUNTLINEORDEROP   
          From
            PLC_LAB_TMP.REP_O_ORDER_ERDV_COM RefCommande
            Inner Join PLC_LAB_TMP.REP_O_ORDER_ERDV_OPERATION LigneMobile
              On    RefCommande.MSG_ID = LigneMobile.MSG_ID
          Where
            (1=1)
          Group by
            RefCommande.MSG_ID            ,
            RefCommande.NB_LINE_OPER_NU   
      )FusionComm
    Group By
      FusionComm.MSG_ID        
  )CalculFinal
Where
  (1=1)
  And Not Exists
    (
      Select
        1
      From
        ODS_MM2.ORD_O_ORDER_ERDV_COM RefPilcom
      Where
        (1=1)
        And CalculFinal.MSG_ID     = RefPilcom.MSG_ID
    )
  And CalculFinal.NB_LINE_ORDER_NU  = CalculFinal.COUNTLINEORDER
  And CalculFinal.NB_LINE_OPER_NU   = CalculFinal.COUNTLINEORDEROP
;
.if errorcode <> 0 then .quit 1

--On collecte les stats sur la table Volatile
Collect Stat ${KNB_TERADATA_USER}.ATP_V_IDORDER_ERDV_TO_LOAD_P Column(MSG_ID);
.if errorcode <> 0 then .quit 1


--On procèdes aux alimentations des tables Temporaires pour ces commandes :
----deraoui

--Insertion dans la table des commandes :
Insert Into ODS_MM2.ORD_O_ORDER_ERDV_COM
(
  MSG_ID,
  EXTERNAL_ORDER_ID,
  ORDER_DEPOSIT_TS,
  ORDER_VALIDATION_TS,
  AGENT_ID,
  ACTIVITY_UNIT_CD,
  CUSTOMER_LAST_NAME_NM,
  CUSTOMER_MARKET_SEG_CD,
  CONTACT_CIVILITY_NM,
  CONTACT_LAST_NAME_NM,
  CONTACT_FIRST_NAME_NM,
  CONTACT_MOBILE_NUMBER_NU,
  CONTACT_TEL_NUMBER_NU,
  OBSERVATIONS_CONTACT_DS,
  REF_GROUPED_OFFER_CD,
  INTERVENTION_ID,
  GPC_ID,
  STATUS_INTERVENTION_CD,
  DATE_RESERVATION_TS,
  DATE_BEGIN_TS,
  OBSERVATIONS_INTERVENTION_DS,
  REF_ERDV_CD,
  NB_LINE_ORDER_NU,
  NB_LINE_OPER_NU,
  ORDER_COMPLETED_IN,
  QUEUE_TS,
  STREAMING_TS
)
Select
  RefCommande.MSG_ID,
  RefCommande.EXTERNAL_ORDER_ID,
  RefCommande.ORDER_DEPOSIT_TS,
  RefCommande.ORDER_VALIDATION_TS,
  RefCommande.AGENT_ID,
  RefCommande.ACTIVITY_UNIT_CD,
  RefCommande.CUSTOMER_LAST_NAME_NM,
  RefCommande.CUSTOMER_MARKET_SEG_CD,
  RefCommande.CONTACT_CIVILITY_NM,
  RefCommande.CONTACT_LAST_NAME_NM,
  RefCommande.CONTACT_FIRST_NAME_NM,
  RefCommande.CONTACT_MOBILE_NUMBER_NU,
  RefCommande.CONTACT_TEL_NUMBER_NU,
  RefCommande.OBSERVATIONS_CONTACT_DS,
  RefCommande.REF_GROUPED_OFFER_CD,
  RefCommande.INTERVENTION_ID,
  RefCommande.GPC_ID,
  RefCommande.STATUS_INTERVENTION_CD,
  RefCommande.DATE_RESERVATION_TS,
  RefCommande.DATE_BEGIN_TS,
  RefCommande.OBSERVATIONS_INTERVENTION_DS,
  RefCommande.REF_ERDV_CD,
  RefCommande.NB_LINE_ORDER_NU,
  RefCommande.NB_LINE_OPER_NU,
  0,
  RefCommande.QUEUE_TS,
  RefCommande.STREAMING_TS
From
  PLC_LAB_TMP.REP_O_ORDER_ERDV_COM RefCommande
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_ERDV_TO_LOAD_P RefId
    On    RefCommande.MSG_ID = RefId.MSG_ID
    
--Insertion dans la table des lignes de commandes Internet :
;Insert Into ODS_MM2.ORD_O_ORDER_ERDV_LINE_COM
(
  MSG_ID,
  EXTERNAL_ORDER_ID,
  ORDER_DEPOSIT_TS,
  ORDER_LINE_EXTERNAL_ID,
  ORDER_LINE_STATUS_CD,
  ORDER_LINE_CONTRACT_DATE_TS,
  ORDER_LINE_WANTED_DATE_TS,
  ORDER_LINE_PREST_CD,
  ORDER_LINE_QUANTITY_QT,
  ORDER_LINE_AMOUNT_AM,
  ORDER_LINE_TVA_RT,
  ORDER_LINE_OPER_CD,
  CUSTOMER_MARKET_SEG_CD,
  CUSTOMER_LAST_NAME_NM,
  CUSTOMER_ADDRESS_APPT_NM,
  CUSTOMER_ADDRESS_ESC_NM,
  CUSTOMER_ADDRESS_STAGE_NM,
  CUSTOMER_ADDRESS_BAT_NM,
  CUSTOMER_ADDRESS_RESIDENCE_NM,
  CUSTOMER_ADDRESS_ZIPCODE_CD,
  CUSTOMER_ADDRESS_NUMBER_NU,
  CUSTOMER_ADDRESS_STR_TYPE_CD,
  CUSTOMER_ADDRESS_STREET_NM,
  CUSTOMER_ADDRESS_CITY_NM,
  CUSTOMER_ADDRESS_INSEE_CD,
  REF_OFFRE_CIBLE_CD,
  CATALOGUE_CD,
  CUSTOMER_ND_NU,
  CUSTOMER_NDS_NU,
  QUEUE_TS,
  STREAMING_TS
)
Select
  LigneInternet.MSG_ID,
  LigneInternet.EXTERNAL_ORDER_ID,
  LigneInternet.ORDER_DEPOSIT_TS,
  LigneInternet.ORDER_LINE_EXTERNAL_ID,
  LigneInternet.ORDER_LINE_STATUS_CD,
  LigneInternet.ORDER_LINE_CONTRACT_DATE_TS,
  LigneInternet.ORDER_LINE_WANTED_DATE_TS,
  LigneInternet.ORDER_LINE_PREST_CD,
  LigneInternet.ORDER_LINE_QUANTITY_QT,
  LigneInternet.ORDER_LINE_AMOUNT_AM,
  LigneInternet.ORDER_LINE_TVA_RT,
  LigneInternet.ORDER_LINE_OPER_CD,
  LigneInternet.CUSTOMER_MARKET_SEG_CD,
  LigneInternet.CUSTOMER_LAST_NAME_NM,
  LigneInternet.CUSTOMER_ADDRESS_APPT_NM,
  LigneInternet.CUSTOMER_ADDRESS_ESC_NM,
  LigneInternet.CUSTOMER_ADDRESS_STAGE_NM,
  LigneInternet.CUSTOMER_ADDRESS_BAT_NM,
  LigneInternet.CUSTOMER_ADDRESS_RESIDENCE_NM,
  LigneInternet.CUSTOMER_ADDRESS_ZIPCODE_CD,
  LigneInternet.CUSTOMER_ADDRESS_NUMBER_NU,
  LigneInternet.CUSTOMER_ADDRESS_STR_TYPE_CD,
  LigneInternet.CUSTOMER_ADDRESS_STREET_NM,
  LigneInternet.CUSTOMER_ADDRESS_CITY_NM,
  LigneInternet.CUSTOMER_ADDRESS_INSEE_CD,
  LigneInternet.REF_OFFRE_CIBLE_CD,
  LigneInternet.CATALOGUE_CD,
  LigneInternet.CUSTOMER_ND_NU,
  LigneInternet.CUSTOMER_NDS_NU,
  LigneInternet.QUEUE_TS,
  LigneInternet.STREAMING_TS
From
  PLC_LAB_TMP.REP_O_ORDER_ERDV_LINE_COM LigneInternet
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_ERDV_TO_LOAD_P RefId
    On    LigneInternet.MSG_ID = RefId.MSG_ID


--Insertion dans la table des lignes de commandes Mobile :
;Insert Into ODS_MM2.ORD_O_ORDER_ERDV_OPERATION
(
  MSG_ID,
  EXTERNAL_ORDER_ID,
  ORDER_DEPOSIT_TS,
  ORDER_LINE_EXTERNAL_ID,
  TYPE_OP_NM,
  INTERVENTION_ID,
  QUEUE_TS,
  STREAMING_TS
)
Select
  LigneMobile.MSG_ID,
  LigneMobile.EXTERNAL_ORDER_ID,
  LigneMobile.ORDER_DEPOSIT_TS,
  LigneMobile.ORDER_LINE_EXTERNAL_ID,
  LigneMobile.TYPE_OP_NM,
  LigneMobile.INTERVENTION_ID,
  LigneMobile.QUEUE_TS,
  LigneMobile.STREAMING_TS
From
  PLC_LAB_TMP.REP_O_ORDER_ERDV_OPERATION LigneMobile
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_ERDV_TO_LOAD_P RefId
    On    LigneMobile.MSG_ID = RefId.MSG_ID
;
.if errorcode <> 0 then .quit 1







