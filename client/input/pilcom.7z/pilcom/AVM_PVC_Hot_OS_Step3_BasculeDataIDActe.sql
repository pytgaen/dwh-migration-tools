--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_PVC_Hot_OS_Step3_BasculeDataIDActe.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'extraction des actes traité
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 12/09/2014     GMA           Création
---------------------------------------------------------------------------------

.set width 5000


Insert Into ${KNB_PCO_VM}.ACT_F_ACTE_SENT_PVC
(
  ACTE_ID                       ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  Refid.ACTE_ID                                     As ACTE_ID                        ,
  Current_Timestamp(0)                              As CREATION_TS                    ,
  Null                                              As LAST_MODIF_TS                  ,
  1                                                 As FRESH_IN                       ,
  1                                                 As COHERENCE_IN                   
From
  ${KNB_PCO_TMP}.ACT_T_PVC_DAY_HOT_OS Refid
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_VM}.ACT_F_ACTE_SENT_PVC;
.if errorcode <> 0 Then .quit 1;

