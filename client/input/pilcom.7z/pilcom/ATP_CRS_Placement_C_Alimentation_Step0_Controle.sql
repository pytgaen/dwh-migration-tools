-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CRS_Placement_C_Alimentation_Step0_Controle.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de controle des donn?es de l'ODS
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 06/01/2014      OCH         CREATION
-- 14/01/2020      ITA         PILCOM_793 : Amelioration du rejet des placements CRS
-- 17/06/2021      BCH         PILCOM_936 : Optimisation O3
--------------------------------------------------------------------------------


.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Alimentation de la table rejet pour Creation                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_SOC}.ORD_F_ACT_CRS_REJ
(
REJECT_CD              ,
ORDER_DEPOSIT_TS       ,
ORDER_ID               ,
FRESH_TS
)
Select
  'RJC3'                                                              As REJECT_CD              ,
  Pl.ORDER_DEPOSIT_TS                                                 As ORDER_DEPOSIT_TS       ,
  Pl.ORDER_ID                                                         As ORDER_ID               ,
  Pl.FRESH_TS                                                         As FRESH_TS
From ${KNB_COM_TMP}.ORD_W_ORDER_C_CRS Pl
Where   Cast( cast (Pl.ORDER_DEPOSIT_TS as timestamp(0)) as Date) < (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1), -1))
Or      Cast( cast (Pl.ORDER_DEPOSIT_TS as timestamp(0)) as Date) > (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1),1) - 1)
;                                          
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ORD_F_ACT_CRS_REJ;
.if errorcode <> 0 then .quit 1  

-------------------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ORD_F_ACT_CRS_REJ
(
REJECT_CD              ,
ORDER_DEPOSIT_TS       ,
ORDER_ID               ,
FRESH_TS
)
Select
  'RJC4'                                                              As REJECT_CD              ,
  Pl.ORDER_DEPOSIT_TS                                                 As ORDER_DEPOSIT_TS       ,
  Pl.ORDER_ID                                                         As ORDER_ID               ,
  Pl.FRESH_TS                                                         As FRESH_TS
From ${KNB_COM_TMP}.ORD_W_ORDER_C_CRS Pl
Where Not Exists (
                  Select 1
                  From  ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR    RefO3
                  Where  Pl.ADV_STORE_CD = RefO3.EXTNL_VAL_COD_CD
                  And Cast(cast (Pl.ORDER_DEPOSIT_TS as timestamp(0)) as Date) Between RefO3.START_EXTNL_VAL_DT
                  And Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
                  )
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ORD_F_ACT_CRS_REJ;
.if errorcode <> 0 then .quit 1 
---------------------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ORD_F_ACT_CRS_REJ
(
REJECT_CD              ,
ORDER_DEPOSIT_TS       ,
ORDER_ID               ,
FRESH_TS
)
Select
  'RJC5'                                                              As REJECT_CD              ,
  Pl.ORDER_DEPOSIT_TS                                                 As ORDER_DEPOSIT_TS       ,
  Pl.ORDER_ID                                                         As ORDER_ID               ,
  Pl.FRESH_TS                                                         As FRESH_TS
From ${KNB_COM_TMP}.ORD_W_ORDER_C_CRS Pl
Where  Exists (
                  Select 1
                  From  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_CRS    FinalOrder
                  Where  Pl.ORDER_ID = FinalOrder.ORDER_ID
                   )                  
;                                          
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ORD_F_ACT_CRS_REJ;
.if errorcode <> 0 then .quit 1  

               