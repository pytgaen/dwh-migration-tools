-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_EnrichissementPlacementVendeur_PCM.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2011     CDR         Création
-- 06/02/2014     AID         Indus
-- 03/11/2014     HFO         MODIFICATION (QC 646 : remplacement de ID_USER par CODEVENDEUR)
-- 05/11/2014     HFO         MODIFICATION (QC 646 : remplacement de ID_USER par CODEVENDEUR trois requetes)
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_ACTIV All
;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------
-- Implémentation des RGs sur la recherche du XI associé au code vendeur
-------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR
(
  ACTE_ID                   ,
  ORG_REF_TRAV              ,
  ORG_AGENT_ID              ,
  ORG_POC_XI                ,
  ORG_NOM                   ,
  ORG_PRENOM                ,
  ORG_GROUPE_ID             
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Lorsqu'on trouve l'orga POC
  'POCSC'                           as ORG_REF_TRAV         ,
  --Code Aliance du vendeur :
  MatPoc.UPPER_ID_FT                as ORG_AGENT_ID         ,
  --Code Xi du Vendeur :CLIENT_CO_TYPCLI 
  MatPoc.XI                         as ORG_POC_XI           ,
  --Nom du Vendeur :
  MatPoc.CSL_NOM                    as ORG_NOM              ,
  --Prénom du vendeur :
  MatPoc.CSL_PRENOM                 as ORG_PRENOM           ,
  --Groupe de travail
  MatPoc.TRAV_ORGA_EQUI_CO_GRP      as ORG_GROUPE_ID        
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_IBU_GLB_V}.VPOCCSLMAT MatPoc
    On    Case when Inter.ID_USER In ('ClientIPCM','ClientEBoutique')
                  Then Inter.CODEVENDEUR
               Else Inter.ID_USER
          End                   =   MatPoc.UPPER_ID_FT
    And   Inter.DATESAISIEBCR   >=  MatPoc.CSLORGA_DT_DEB
    And   Inter.DATESAISIEBCR   <   Case  When  MatPoc.CSLORGA_DT_FIN = Current_date - 1
                                            Then Current_date
                                          Else MatPoc.CSLORGA_DT_FIN
                                    End
Where
  (1=1)
  And (Inter.ORG_POC_XI Is Null Or Inter.ORG_REF_TRAV='OEEEDEL')
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by MatPoc.CSLORGA_DT_DEB Asc)=1

-------------------------------------------------------------------
-- Recherche de l'activité du conseillé au moment de la vente
-------------------------------------------------------------------

;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_ACTIV
(
  ACTE_ID                   ,
  LOGIN_CREA                ,
  ORG_ACTVT_REEL            
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Code Aliance du vendeur :
  Orga.AGENT_ID                     as ORG_AGENT_ID         ,
  --Code Activitee du vendeur au moment de la vente:
  Orga.ACTIVITY_ID                  as ORG_ACTVT_REEL        
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_COM_SOC_V_PRS}.VF_ORG_H_AGENT_ACTIVITY Orga
    On    Case when Inter.ID_USER In ('ClientIPCM','ClientEBoutique')
                  Then Inter.CODEVENDEUR
               Else Inter.ID_USER
          End                     =   Orga.AGENT_ID
    And   Inter.DATESAISIEBCR    >=  (Cast(Orga.START_ACTIVITY_DT As Timestamp(0)) + ((Orga.START_ACTIVITY_HH - Time '00:00:00') Hour To Second))
    And   (   --Soit la date de fin est valorisée alors on fait le calcul
              Inter.DATESAISIEBCR  <   (Cast(Orga.END_ACTIVITY_DT As Timestamp(0)) + ((Orga.END_ACTIVITY_HH - Time '00:00:00') Hour To Second))
            Or
              --Soit la date de fin n'est pas valo alors on prend
              Orga.END_ACTIVITY_DT Is Null
          )
Where
  (1=1)
  And Inter.ORG_ACTVT_REEL Is Null
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Orga.START_ACTIVITY_DT asc)=1

;
.if errorcode <> 0 then .quit 1


--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_ACTIV;
.if errorcode <> 0 then .quit 1



Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR
(
  ACTE_ID                   ,
  ORG_REF_TRAV              ,
  ORG_AGENT_ID              ,
  ORG_POC_XI                ,
  ORG_NOM                   ,
  ORG_PRENOM                ,
  ORG_GROUPE_ID             
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Lorsqu'on trouve l'orga POC
  'OEEEDEL'                         as ORG_REF_TRAV         ,
  --Code Aliance du vendeur :
  Conseil.CONSEIL_LB_UTIL           as ORG_AGENT_ID         ,
  --Code Xi du Vendeur :CLIENT_CO_TYPCLI
  Conseil.CONSEIL_XI                as ORG_POC_XI           ,
  --Nom du Vendeur :
  Conseil.CONSEIL_LB_NOM            as ORG_NOM              ,
  --Prénom du vendeur :
  Conseil.CONSEIL_LB_PRENOM         as ORG_PRENOM           ,
  --Groupe de travail
  Conseil.CONSEIL_ID_GROUPE         as ORG_GROUPE_ID        
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_TDCONSEIL Conseil
    On    Case when Inter.ID_USER In ('ClientIPCM','ClientEBoutique')
                  Then Inter.CODEVENDEUR
               Else Inter.ID_USER
          End                   =   Conseil.CONSEIL_LB_UTIL
    And   Inter.DATESAISIEBCR   >=  Conseil.CONSEIL_DT_DEB
    And   (Inter.DATESAISIEBCR  <=  Coalesce(Conseil.CONSEIL_DT_FIN,Cast('99991231' as date format 'YYYYMMDD')))
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR RefIdVend
    On Inter.ACTE_ID          =   RefIdVend.ACTE_ID
Where
  (1=1)
  And RefIdVend.ACTE_ID is null
  And (Inter.ORG_POC_XI Is Null)
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Conseil.CONSEIL_XI desc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR;
.if errorcode <> 0 then .quit 1




--On insert les lignes dont on calcul par l'orga de pilcom
Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR
(
  ACTE_ID                   ,
  ORG_REF_TRAV              ,
  ORG_AGENT_ID              ,
  ORG_POC_XI                ,
  ORG_NOM                   ,
  ORG_PRENOM                ,
  ORG_GROUPE_ID             
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Lorsqu'on trouve l'orga POC
  Null                              as ORG_REF_TRAV         ,
  --Code Aliance du vendeur :
  Case  When RefConsPilcom.AGENT_CUID is not Null
          Then RefConsPilcom.AGENT_CUID
        When  Inter.ID_USER In ('ClientIPCM','ClientEBoutique')
          Then  Inter.CODEVENDEUR
        Else    Inter.ID_USER
  End                               as ORG_AGENT_ID         ,
  --Code Xi du Vendeur :
  Null                              as ORG_POC_XI           ,
  --Nom du Vendeur :
  RefConsPilcom.LAST_NAME_NM        as ORG_NOM              ,
  --Prénom du vendeur :
  RefConsPilcom.FIRST_NAME_NM       as ORG_PRENOM           ,
  --Groupe de travail
  Null                              as ORG_GROUPE_ID        
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM Inter
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefConsPilcom
    On    Case when Inter.ID_USER In ('ClientIPCM','ClientEBoutique')
                  Then Inter.CODEVENDEUR
               Else Inter.ID_USER
          End                       =   RefConsPilcom.AGENT_CUID
      And RefConsPilcom.CURRENT_IN  = 1
      And RefConsPilcom.CLOSURE_DT  Is Null
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR RefIdVend
    On Inter.ACTE_ID                =   RefIdVend.ACTE_ID
Where
  (1=1)
  And RefIdVend.ACTE_ID is null
  And (Inter.ORG_POC_XI Is Null)
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by RefConsPilcom.FIRST_NAME_NM Asc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEUR;
.if errorcode <> 0 then .quit 1


.quit 0
