-- $HEADER: mm2pco/current/sql/ATP_EXF_Placement_C_Alimentation_Step0_Controle.sql 13_05#4 09-NOV-2018 17:20:30 LXQG9925
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EXF_Placement_C_Alimentation_Step0_Controle.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de controle des données de l'IHM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 26/05/2014      OCH         CREATION
-- 22/06/2018      JCR         Modification pour filtrer (pb rattrapage IODA Nord de France et Corse)
-- 25/06/2018      JCR         On enleve le filtre pour restreindre de nouveau.
-- 06/11/2018      LMU         QC 1798 : Ajout cas REINJection
--------------------------------------------------------------------------------

.set width 2500;


Create MULTISET VOLATILE Table ${KNB_TERADATA_USER}.ActeRem
(
  ACT_REM_ID            Varchar(64)   
 )
Primary Index (ACT_REM_ID )
ON COMMIT PRESERVE ROWS ;
Collect stat On ${KNB_TERADATA_USER}.ActeRem Column (ACT_REM_ID ) ;


Insert Into ${KNB_TERADATA_USER}.ActeRem
(
  ACT_REM_ID
 )
Select Distinct(mat_decla.ACTE_REM_ID) As ACTE_REM_ID
From ${KNB_PCO_REFCOM}.V_CAT_R_MAT_DECLA mat_decla
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM acte_pilcom  -- RG_C04R
    On   mat_decla.ACTE_ID = acte_pilcom.ACTE_ID
    And  mat_decla.PERIODE_ID = acte_pilcom.PERIODE_ID
    And  acte_pilcom.CURRENT_IN = 1
    And  acte_pilcom.CLOSURE_DT is NULL
Where  (1=1) 
And (   mat_decla.TYPE_DECLARATIF = 'VENDEUR+MGR' Or  mat_decla.ACTE_REM_ID like 'DECL/%' )
And     mat_decla.FRESH_IN     = 1
And     mat_decla.CURRENT_IN   = 1
And     mat_decla.PERIODE_ID  >= (Select Max(PERIODE_ID) - 1 
                        From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM 
                        Where CURRENT_IN=1 
                        And FRESH_IN=1)
;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 1 : Alimentation de la table rejet pour Creation                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN 
)
Select
  'RJC1'                                                           As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                       As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                       As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                           As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                             As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                  As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                 As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                             As MISISDN_ID               ,
  Placement.ND_ID                                                  As ND_ID                    ,
  Placement.NDIP_ID                                                As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                       As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                               As AGENT_ID                 ,
  Placement.EDO_ID                                                 As EDO_ID                   ,
  Placement.ACT_REM_ID                                             As ACT_REM_ID               ,
  Placement.QUANTT_QT                                              As QUANTT_QT                ,
  Placement.CA_AM                                                  As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                         As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                              As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                         As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                            As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                           As INJECTION_TS             ,
  Placement.CREATION_TS                                            As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                          As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                             As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                              As AUTHOR_CD                ,
  1                                                               As FRESH_IN                  ,
  0                                                                As COHERENCE_IN                 
From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA Placement
Where Not Exists (
                  Select 1
                  From  ${KNB_TERADATA_USER}.ActeRem ActRe
                  Where Placement.ACT_REM_ID = ActRe.ACT_REM_ID
                  )
 And  Placement.TYPE_MOVEMENT_CD  not In ('SUPP')
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
---------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJC4'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                 
From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA Placement
Where   Cast(Placement.ORDER_DEPOSIT_TS as Date) < (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1), -1))
Or      Cast(Placement.ORDER_DEPOSIT_TS as Date) > (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1),1) - 1)
;                                          
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN             
)
Select
  Case When Placement.TYPE_MOVEMENT_CD Not In ('CREA', 'REINJ') Then 'RJC2'
       When Placement.TYPE_SOURCE_CD Not In ('EXTERNE') Then 'RJC3'
  END                                                               As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN             
From 
${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA Placement
Where Placement.TYPE_MOVEMENT_CD Not In ('CREA', 'REINJ')
OR Placement.TYPE_SOURCE_CD Not In ('EXTERNE')

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
-----------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN             
)
Select
  'RJC6'                                                           As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                       As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                       As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                           As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                             As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                  As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                 As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                             As MISISDN_ID               ,
  Placement.ND_ID                                                  As ND_ID                    ,
  Placement.NDIP_ID                                                As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                       As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                               As AGENT_ID                 ,
  Placement.EDO_ID                                                 As EDO_ID                   ,
  Placement.ACT_REM_ID                                             As ACT_REM_ID               ,
  Placement.QUANTT_QT                                              As QUANTT_QT                ,
  Placement.CA_AM                                                  As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                         As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                              As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                         As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                            As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                           As INJECTION_TS             ,
  Placement.CREATION_TS                                            As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                          As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                             As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                              As AUTHOR_CD                ,
  1                                                                As FRESH_IN                 ,
  0                                                                As COHERENCE_IN                 
From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA  Placement
Where (Trim(Placement.ACT_REM_ID)||'|'||Trim(cast (Placement.ORDER_DEPOSIT_TS as char(12)))||'|'||Trim(Placement.LAST_NAME_CUSTOMER_NM)||'|'||Trim(Placement.FIRST_NAME_CUSTOMER_NM)||'|'||Trim(coalesce(Placement.MISISDN_ID , '0000000000' ))||'|'||Trim(coalesce(Placement.ND_ID , '0000000000' ))||'|'||Trim(coalesce(Placement.NDIP_ID , '0000000000' ))||'|'||Trim(Placement.AGENT_ID)||'@') 
                                  In ( 
                                           Select SubString (Act.EXTERNAL_ACTE_ID From 1 For POSITION('@' in Act.EXTERNAL_ACTE_ID)) 
                                           From ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN Act
                                           Where Act.TYPE_SOURCE_ID IN ( ${IdentifiantTechniqueSource}, ${IdentifiantTechniqueDV} )
                                     )

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJC8'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                           
From 
${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA Placement
Where Placement.EDO_ID Not In ( Select RefEDO.EDO_ID
                                From ${KNB_SOC_O3}.V_ORG_F_EDO RefEDO
                               )
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
-------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN              
)
Select
  'RJC9'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                           
From 
${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA Placement
Where Placement.TYPE_CUSTOMER_CD Not In ('R','P','I','M','X')
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 1 : Alimentation de la table rejet pour Suppresion                               ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJS1'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                 
From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP Placement
Where  Not Exists (
               Select 1
               From ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN Act
               Where Placement.ACTE_ID = Act.ACTE_ID
               And  Act.TYPE_SOURCE_ID In ( ${IdentifiantTechniqueSource}, ${IdentifiantTechniqueDV} )
               )
And  Placement.TYPE_MOVEMENT_CD  not In ('CREA', 'REINJ')
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
-----------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJS4'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                 
From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP  Placement
Inner Join ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF VPL
On Placement.ACTE_ID = VPL.ACTE_ID
Where   Cast(VPL.ORDER_DEPOSIT_TS as Date) < (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1), -1))
Or      Cast(VPL.ORDER_DEPOSIT_TS as Date) > (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1),1) - 1)
;                                          
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  Case When Placement.QUANTT_QT > 1                     Then 'RJS7'
       When Placement.TYPE_MOVEMENT_CD Not In ('SUPP')  Then 'RJS2'
       When Placement.TYPE_SOURCE_CD Not In ('EXTERNE') Then 'RJS3'
  END                                                    As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                       As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                       As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                           As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                             As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                  As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                 As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                             As MISISDN_ID               ,
  Placement.ND_ID                                                  As ND_ID                    ,
  Placement.NDIP_ID                                                As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                       As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                               As AGENT_ID                 ,
  Placement.EDO_ID                                                 As EDO_ID                   ,
  Placement.ACT_REM_ID                                             As ACT_REM_ID               ,
  Placement.QUANTT_QT                                              As QUANTT_QT                ,
  Placement.CA_AM                                                  As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                         As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                              As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                         As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                            As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                           As INJECTION_TS             ,
  Placement.CREATION_TS                                            As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                          As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                             As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                              As AUTHOR_CD                ,
  1                                                                As FRESH_IN                 ,
  0                                                                As COHERENCE_IN                 
From 
${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP Placement
Where Placement.TYPE_MOVEMENT_CD Not In ('SUPP')
Or Placement.TYPE_SOURCE_CD Not In('EXTERNE')
Or Placement.QUANTT_QT > 1

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 1 : Alimentation de la table rejet pour Mofification                               ----
----------------------------------------------------------------------------------------------

Create MULTISET VOLATILE Table ${KNB_TERADATA_USER}.ModifVol
(
  ACTE_ID                  Bigint                 ,
  TYPE_SOURCE_ID           Smallint               ,
  EXTERNAL_ACTE_ID         Varchar(255)           ,
  EXTERNAL_ACTE_ID_GEN     Varchar(255)           ,
  ORDER_DEPOSIT_TS         Timestamp(0)           ,
  LAST_NAME_CUSTOMER_NM    Varchar(30)            ,
  FIRST_NAME_CUSTOMER_NM   Varchar(30)            ,
  MISISDN_ID               Varchar(10)            ,
  ND_ID                    Varchar(10)            ,
  NDIP_ID                  Varchar(10)            ,
  AGENT_ID                 Char(10)               ,
  ACT_REM_ID               Varchar(64)
 )
Primary Index (ACTE_ID)
ON COMMIT PRESERVE ROWS ;
Collect stat On ${KNB_TERADATA_USER}.ModifVol Column (ACTE_ID) ;

Insert Into ${KNB_TERADATA_USER}.ModifVol
(
  ACTE_ID                  ,
  TYPE_SOURCE_ID           ,
  EXTERNAL_ACTE_ID         ,
  EXTERNAL_ACTE_ID_GEN     ,
  ORDER_DEPOSIT_TS         ,
  LAST_NAME_CUSTOMER_NM    ,
  FIRST_NAME_CUSTOMER_NM   ,
  MISISDN_ID               ,
  ND_ID                    ,
  NDIP_ID                  ,
  AGENT_ID                 ,
  ACT_REM_ID            
 )
Select 
  Modif.ACTE_ID                                                 As  ACTE_ID                  ,
  Act.TYPE_SOURCE_ID                                            As TYPE_SOURCE_ID            ,
  Case When Act.TYPE_SOURCE_ID = ${IdentifiantTechniqueSource}
       Then
       (Trim(Modif.ACT_REM_ID)||'|'
       ||Trim(cast (Modif.ORDER_DEPOSIT_TS as char(12)))||'|'
       ||Trim(Modif.LAST_NAME_CUSTOMER_NM)||'|'
       ||Trim(Modif.FIRST_NAME_CUSTOMER_NM)||'|'
       ||Trim(coalesce(Modif.MISISDN_ID , '0000000000' ))||'|'
       ||Trim(coalesce(Modif.ND_ID , '0000000000' ))||'|'
       ||Trim(coalesce(Modif.NDIP_ID , '0000000000' ))||'|'
       ||Trim(Modif.AGENT_ID)||'@') 
       Else  Act.EXTERNAL_ACTE_ID
  End                                                           As  EXTERNAL_ACTE_ID         ,
  Act.EXTERNAL_ACTE_ID                                          As  EXTERNAL_ACTE_ID_GEN     ,
  Modif.ORDER_DEPOSIT_TS                                        As  ORDER_DEPOSIT_TS         ,
  Modif.LAST_NAME_CUSTOMER_NM                                   As  LAST_NAME_CUSTOMER_NM    ,
  Modif.FIRST_NAME_CUSTOMER_NM                                  As  FIRST_NAME_CUSTOMER_NM   ,
  Modif.MISISDN_ID                                              As  MISISDN_ID               ,
  Modif.ND_ID                                                   As  ND_ID                    ,
  Modif.NDIP_ID                                                 As  NDIP_ID                  ,
  Modif.AGENT_ID                                                As  AGENT_ID                 ,
  Modif.ACT_REM_ID                                              As  ACT_REM_ID
From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF Modif 
Inner join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN Act
On Modif.ACTE_ID = Act.ACTE_ID
Where  (1=1) 
And  Act.TYPE_SOURCE_ID In ( ${IdentifiantTechniqueSource}, ${IdentifiantTechniqueDV} )
;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------

Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN 
)
Select
  'RJM1'                                                           As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                       As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                       As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                           As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                             As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                  As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                 As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                             As MISISDN_ID               ,
  Placement.ND_ID                                                  As ND_ID                    ,
  Placement.NDIP_ID                                                As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                       As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                               As AGENT_ID                 ,
  Placement.EDO_ID                                                 As EDO_ID                   ,
  Placement.ACT_REM_ID                                             As ACT_REM_ID               ,
  Placement.QUANTT_QT                                              As QUANTT_QT                ,
  Placement.CA_AM                                                  As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                         As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                              As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                         As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                            As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                           As INJECTION_TS             ,
  Placement.CREATION_TS                                            As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                          As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                             As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                              As AUTHOR_CD                ,
  1                                                                As FRESH_IN                 ,
  0                                                                As COHERENCE_IN                 
From 
 ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF  Placement
Where Not Exists (
                  Select 1
                  From  ${KNB_TERADATA_USER}.ActeRem ActRe
                  Where Placement.ACT_REM_ID = ActRe.ACT_REM_ID
                  )
 And  Placement.TYPE_MOVEMENT_CD  not In ('SUPP')     
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
---------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJM2'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN             
From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF  Placement
Where  Not Exists (
               Select 1
               From ${KNB_TERADATA_USER}.ModifVol Actmod
               Where Placement.ACTE_ID = Actmod.ACTE_ID
               )
And  Placement.TYPE_MOVEMENT_CD  not In ('CREA')
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1
---------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJM4'                                                            As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                 
From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF  Placement
Inner Join ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF VPL
On Placement.ACTE_ID = VPL.ACTE_ID
Where   Cast(VPL.ORDER_DEPOSIT_TS as Date) < (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1), -1))
Or      Cast(VPL.ORDER_DEPOSIT_TS as Date) > (select add_Months (( current_date - EXTRACT(DAY FROM current_date) + 1),1) - 1)
;                                          
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  Case When Placement.QUANTT_QT > 1                     Then 'RJM7'
       When Placement.TYPE_MOVEMENT_CD Not In ('MODIF') Then 'RJM3'
       When Placement.TYPE_SOURCE_CD Not In ('EXTERNE') Then 'RJM5'
  END                                                               As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                        As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                 As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                        As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                            As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                              As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                   As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                  As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                              As MISISDN_ID               ,
  Placement.ND_ID                                                   As ND_ID                    ,
  Placement.NDIP_ID                                                 As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                        As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                                As AGENT_ID                 ,
  Placement.EDO_ID                                                  As EDO_ID                   ,
  Placement.ACT_REM_ID                                              As ACT_REM_ID               ,
  Placement.QUANTT_QT                                               As QUANTT_QT                ,
  Placement.CA_AM                                                   As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                          As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                               As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                          As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                             As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                            As INJECTION_TS             ,
  Placement.CREATION_TS                                             As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                           As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                              As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                               As AUTHOR_CD                ,
  1                                                                 As FRESH_IN                 ,
  0                                                                 As COHERENCE_IN                 
From 
${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF Placement
Where Placement.TYPE_MOVEMENT_CD Not In ('MODIF')
Or Placement.TYPE_SOURCE_CD Not In ('EXTERNE')
Or Placement.QUANTT_QT > 1

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJM6'                                                           As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                       As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                       As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                           As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                             As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                  As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                 As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                             As MISISDN_ID               ,
  Placement.ND_ID                                                  As ND_ID                    ,
  Placement.NDIP_ID                                                As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                       As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                               As AGENT_ID                 ,
  Placement.EDO_ID                                                 As EDO_ID                   ,
  Placement.ACT_REM_ID                                             As ACT_REM_ID               ,
  Placement.QUANTT_QT                                              As QUANTT_QT                ,
  Placement.CA_AM                                                  As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                         As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                              As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                         As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                            As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                           As INJECTION_TS             ,
  Placement.CREATION_TS                                            As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                          As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                             As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                              As AUTHOR_CD                ,
  1                                                                As FRESH_IN                 ,
  0                                                                As COHERENCE_IN              
From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF  Placement
Where Placement.ACTE_ID In ( Select Actmod.ACTE_ID
                             From ${KNB_TERADATA_USER}.ModifVol Actmod
                             Where Actmod.EXTERNAL_ACTE_ID In ( Select SubString (Act.EXTERNAL_ACTE_ID_GEN From 1 For POSITION('@' in Act.EXTERNAL_ACTE_ID_GEN)-1)
                                                                From ${KNB_TERADATA_USER}.ModifVol Act
                                                                Where Act.ACTE_ID <> Actmod.ACTE_ID
                                                                And Act.TYPE_SOURCE_ID = ${IdentifiantTechniqueSource}))
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------
Insert Into ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
(
REJECT_CD                ,
TYPE_MOVEMENT_CD         ,
ACTE_ID                  ,
ORDER_DEPOSIT_TS         ,
NUM_ORDER_NU             ,
COMMENT_DS               ,
LAST_NAME_CUSTOMER_NM    ,
FIRST_NAME_CUSTOMER_NM   ,
MISISDN_ID               ,
ND_ID                    ,
NDIP_ID                  ,
TYPE_CUSTOMER_CD         ,
AGENT_ID                 ,
EDO_ID                   ,
ACT_REM_ID               ,
QUANTT_QT                ,
CA_AM                    ,
TYPE_SOURCE_CD           ,
NATURE_CD                ,
OSCAR_VALUE_CD           ,
ENGAGMNT_NB              ,
INJECTION_TS             ,
CREATION_TS              ,
LAST_MODIF_TS            ,
CLOSURE_DT               ,
AUTHOR_CD                ,
FRESH_IN                 ,
COHERENCE_IN               
)
Select
  'RJM7'                                                           As REJECT_CD                ,
  Placement.TYPE_MOVEMENT_CD                                       As TYPE_MOVEMENT_CD         ,
  Placement.ACTE_ID                                                As ACTE_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                       As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                           As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                             As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                                  As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                                 As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                             As MISISDN_ID               ,
  Placement.ND_ID                                                  As ND_ID                    ,
  Placement.NDIP_ID                                                As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                       As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                               As AGENT_ID                 ,
  Placement.EDO_ID                                                 As EDO_ID                   ,
  Placement.ACT_REM_ID                                             As ACT_REM_ID               ,
  Placement.QUANTT_QT                                              As QUANTT_QT                ,
  Placement.CA_AM                                                  As CA_AM                    ,
  Placement.TYPE_SOURCE_CD                                         As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                              As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                         As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                            As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                           As INJECTION_TS             ,
  Placement.CREATION_TS                                            As CREATION_TS              ,
  Placement.LAST_MODIF_TS                                          As LAST_MODIF_TS            ,
  Placement.CLOSURE_DT                                             As CLOSURE_DT               ,
  Placement.AUTHOR_CD                                              As AUTHOR_CD                ,
  1                                                                As FRESH_IN                 ,
  0                                                                As COHERENCE_IN                 
From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF  Placement
Where Placement.ACTE_ID in ( select Pl.ACTE_ID 
                            From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF Pl
                            Where Placement.ACTE_ID                     <> Pl.ACTE_ID
                            And   Placement.ACT_REM_ID                  =  Pl.ACT_REM_ID
                            And   Placement.ORDER_DEPOSIT_TS            =  Pl.ORDER_DEPOSIT_TS
                            And   Placement.LAST_NAME_CUSTOMER_NM       =  Pl.LAST_NAME_CUSTOMER_NM
                            And   Placement.FIRST_NAME_CUSTOMER_NM      =  Pl.FIRST_NAME_CUSTOMER_NM
                            And   Placement.MISISDN_ID                  =  Pl.MISISDN_ID
                            And   Placement.ND_ID                       =  Pl.ND_ID
                            And   Placement.NDIP_ID                     =  Pl.NDIP_ID
                            And   Placement.AGENT_ID                    =  Pl.AGENT_ID
                           )
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ;
.if errorcode <> 0 then .quit 1

.quit 0


