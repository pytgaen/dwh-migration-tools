--$HEADER:   mm2pco/current/sql/ATP_OSE_Placement_Consolidation_BasculeIDActe.sql 13_05#7 10-DEC-2018 16:26:42 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_OSE_Placement_Consolidation_BasculeIDActe.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/07/2018       LMU         Creation
-- 17/09/2018       JCR          Modif
--------------------------------------------------------------------------------

.set width 2500;




Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 all;
.if errorcode <> 0 then .quit 1




Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 
(
ACTE_ID                      ,
ORDER_EXTERNAL_ID            ,
TYPE_SOURCE_ID               ,
INTRNL_SOURCE_ID             ,
ORDER_DEPOSIT_TS             ,
ORDER_DEPOSIT_DT             ,
ORDER_CANCELING_TS           ,
ORDER_CANCELING_DT           ,
EXTRNL_SERV_PARTN_ID         ,
ORDER_TYP_CD                 ,
EXTRNL_OPSRV_CD              ,
EXTRNL_OFFR_PARTN_CD         ,
EXTRNL_ORDR_PARTN_ID         ,
EXTRNL_DEAL_PARTN_ID         ,
EXTRNL_CUST_PARTN_ID         ,
EXTRNL_STATUS_CD             ,
STATUS_UNIFIED_CD            ,
EXTRNL_SUB_PID               ,
EXTRNL_SUB_POSTAL_CD         ,
EXTRNL_SUB_LINE_ID           ,
EXTRNL_LINE_ID_DT            ,
DMC_MASTER_LINE_ID           ,
DMC_CUST_TYPE_CD             ,
DMC_NDS_VALUE_DS             ,
DMC_MSISDN_ID                ,
DMC_EXTERNAL_PARTY_ID        ,
DMC_RES_VALUE_DS             ,
DMC_SERVICE_ACCESS_ID        ,
DMC_LINE_TYPE                ,
DMC_START_DT                 ,
DMC_ACTIVATION_DT            ,
DMC_POSTAL_CD                ,
PAR_INSEE_NB                 ,
PAR_BU_CD                    ,
DMC_DEPRTMNT_ID              ,
PAR_GEO_MACROZONE            ,
PAR_UNIFIED_PARTY_ID         ,
PAR_PARTY_REGRPMNT_ID        ,
PAR_IRIS2000_CD              ,
PAR_CID_ID                   ,
PAR_PID_ID                   ,
PAR_FIRST_IN                 ,
PAR_FIBER_IN                 ,
ORG_CHANNEL_CD_CMD           ,
ORG_AGENT_ID                 ,
EXTRNL_SHOP_ID               ,
EXTRNL_EDO_ID                ,
TYPE_EDO_ID                  ,
NETWRK_TYP_EDO_ID            ,
FLAG_TYPE_GEO                ,
FLAG_TYPE_CPT_NTK            ,
FLAG_AD_SC                   ,
ORG_TEAM_LEVEL_1_CD          ,
ORG_TEAM_LEVEL_1_DS          ,
ORG_TEAM_LEVEL_2_CD          ,
ORG_TEAM_LEVEL_2_DS          ,
ORG_TEAM_LEVEL_3_CD          ,
ORG_TEAM_LEVEL_3_DS          ,
ORG_TEAM_LEVEL_4_CD          ,
ORG_TEAM_LEVEL_4_DS          ,
WORK_TEAM_LEVEL_1_CD         ,
WORK_TEAM_LEVEL_1_DS         ,
WORK_TEAM_LEVEL_2_CD         ,
WORK_TEAM_LEVEL_2_DS         ,
WORK_TEAM_LEVEL_3_CD         ,
WORK_TEAM_LEVEL_3_DS         ,
WORK_TEAM_LEVEL_4_CD         ,
WORK_TEAM_LEVEL_4_DS         ,
CREATION_TS                  ,
LAST_MODIF_TS                ,
FRESH_IN                     ,
COHERENCE_IN                 ,
HOT_IN                        


)
Select 
TblGen. ACTE_ID                  as ACTE_ID                 ,
Commande.EXTRNL_DEAL_PARTN_ID    as ORDER_EXTERNAL_ID       ,
Commande.TYPE_SOURCE_ID          as TYPE_SOURCE_ID          ,
Commande.INTRNL_SOURCE_ID        as INTRNL_SOURCE_ID        ,
Commande.ORDER_DEPOSIT_TS        as ORDER_DEPOSIT_TS        ,
Commande.ORDER_DEPOSIT_DT        as ORDER_DEPOSIT_DT        ,
Commande.ORDER_CANCELING_TS      as ORDER_CANCELING_TS      ,
Commande.ORDER_CANCELING_DT      as ORDER_CANCELING_DT      ,
Commande.EXTRNL_SERV_PARTN_ID    as EXTRNL_SERV_PARTN_ID    ,
Commande.ORDER_TYP_CD            as ORDER_TYP_CD            ,
Commande.EXTRNL_OPSRV_CD         as EXTRNL_OPSRV_CD         ,
Commande.EXTRNL_OFFR_PARTN_CD    as EXTRNL_OFFR_PARTN_CD    ,
Commande.EXTRNL_ORDR_PARTN_ID    as EXTRNL_ORDR_PARTN_ID    ,
Commande.EXTRNL_DEAL_PARTN_ID    as EXTRNL_DEAL_PARTN_ID    ,
Commande.EXTRNL_CUST_PARTN_ID    as EXTRNL_CUST_PARTN_ID    ,
Commande.EXTRNL_STATUS_CD        as EXTRNL_STATUS_CD        ,
Commande.STATUS_UNIFIED_CD       as STATUS_UNIFIED_CD       ,
Commande.EXTRNL_SUB_PID          as EXTRNL_SUB_PID          ,
Commande.EXTRNL_SUB_POSTAL_CD    as EXTRNL_SUB_POSTAL_CD    ,
Commande.EXTRNL_SUB_LINE_ID      as EXTRNL_SUB_LINE_ID      ,
Commande.EXTRNL_LINE_ID_DT       as EXTRNL_LINE_ID_DT       ,
Null                             as DMC_MASTER_LINE_ID      ,
Null                             as DMC_CUST_TYPE_CD        ,
Null                             as DMC_NDS_VALUE_DS        ,
Null                             as DMC_MSISDN_ID           ,
Null                             as DMC_EXTERNAL_PARTY_ID   ,
Null                             as DMC_RES_VALUE_DS        ,
Null                             as DMC_SERVICE_ACCESS_ID   ,
Null                             as DMC_LINE_TYPE           ,
Null                             as DMC_START_DT            ,
Null                             as DMC_ACTIVATION_DT       ,
Null                             as DMC_POSTAL_CD           ,
Null                             as PAR_INSEE_NB            ,
Null                             as PAR_BU_CD               ,
Null                             as DMC_DEPRTMNT_ID         ,
Null                             as PAR_GEO_MACROZONE       ,
Null                             as PAR_UNIFIED_PARTY_ID    ,
Null                             as PAR_PARTY_REGRPMNT_ID   ,
Null                             as PAR_IRIS2000_CD         ,
Null                             as PAR_CID_ID              ,
Null                             as PAR_PID_ID              ,
Null                             as PAR_FIRST_IN            ,
Null                             as PAR_FIBER_IN            ,
Commande.ORG_CHANNL_CD_CMD       as ORG_CHANNEL_CD_CMD      ,
Commande.ORG_AGENT_ID            as ORG_AGENT_ID            ,
Commande.EXTRNL_SHOP_ID          as EXTRNL_SHOP_ID          ,
Commande.EXTRNL_EDO_ID           as EXTRNL_EDO_ID           ,
Null                             as TYPE_EDO_ID             ,
Null                             as NETWRK_TYP_EDO_ID       ,
Null                             as FLAG_TYPE_GEO           ,
Null                             as FLAG_TYPE_CPT_NTK       ,
Null                             as FLAG_AD_SC              ,
Null                             as ORG_TEAM_LEVEL_1_CD     ,
Null                             as ORG_TEAM_LEVEL_1_DS     ,
Null                             as ORG_TEAM_LEVEL_2_CD     ,
Null                             as ORG_TEAM_LEVEL_2_DS     ,
Null                             as ORG_TEAM_LEVEL_3_CD     ,
Null                             as ORG_TEAM_LEVEL_3_DS     ,
Null                             as ORG_TEAM_LEVEL_4_CD     ,
Null                             as ORG_TEAM_LEVEL_4_DS     ,
Null                             as WORK_TEAM_LEVEL_1_CD    ,
Null                             as WORK_TEAM_LEVEL_1_DS    ,
Null                             as WORK_TEAM_LEVEL_2_CD    ,
Null                             as WORK_TEAM_LEVEL_2_DS    ,
Null                             as WORK_TEAM_LEVEL_3_CD    ,
Null                             as WORK_TEAM_LEVEL_3_DS    ,
Null                             as WORK_TEAM_LEVEL_4_CD    ,
Null                             as WORK_TEAM_LEVEL_4_DS    ,
Commande.CREATION_TS             as CREATION_TS             ,
Commande.LAST_MODIF_TS           as LAST_MODIF_TS           ,
Commande.FRESH_IN                as FRESH_IN                ,
Commande.COHERENCE_IN            as COHERENCE_IN            ,
Commande.HOT_IN                  as HOT_IN                  

From ${KNB_PCO_TMP}.ORD_W_EXTRACT_OSE Commande
Inner Join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN TblGen
   On    Commande.EXTERNAL_ACTE_ID  =   TblGen.EXTERNAL_ACTE_ID
   And   Commande.TYPE_SOURCE_ID    =   TblGen.TYPE_SOURCE_ID
;   
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 ;
.if errorcode <> 0 then .quit 1

