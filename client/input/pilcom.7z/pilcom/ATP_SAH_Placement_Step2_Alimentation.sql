--$HEADER: mm2pco/current/sql/ATP_SAH_Placement_Step2_Alimentation.sql 13_05#10 27-NOV-2018 09:03:00 LXQG9925
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_SAH_Placement_Step2_Alimentation.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Alimentation acte_id SAVI SAH
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 12/07/2017      MDE         Creation
-- 23/05/2018      LMU         Ajout items Task Force + Corrections
-- 12/06/2018      LMU         Modification : Ajout champ pour developpement BAL
-- 26/11/2018      LMU         Ajout extraction de la table TB_CLIENTS / SAV_F_CUSTOMER
-- 12/08/2020      ITA         Evolution SAVI pour REAP : PILCOM_404
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1 All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table temporaire                                          ----
----------------------------------------------------------------------------------------------
-- US PILCOM_404 : 
-- AJOUT DES 4 NOUVEAUX CHAMPS  SYSTEME_FACTURATION ,  ALLEGRO_CD , MONTANT_FACT_ALLEGRO ET TYPE_PROCESS 
-- SUPPRESSION DES COLONNES 
-- ETP_X_TS, ETP_X_USR_CD, ETP_X_ALLIANCE_CD, ETP_X_COMPTE_CD, ETP_X_EDO_ID 
-- AVEC X <> 0,200,1,101,20,204

 
Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1
(
    ACTE_ID                          ,
    EXTERNAL_ORDR_ID                 ,
    EXTERNAL_ACTE_ID                 ,
    ORDER_DEPOSIT_DT                 ,
    ORDER_DEPOSIT_TS                 ,
    TYPE_SOURCE_ID                   ,
    INTRNL_SOURCE_ID                 ,
    ORDER_STATUS_CD                  ,
    ORDER_STATUS_DS                  ,
    ORDR_TYP_CD                      ,
    MOTIF_CD                         ,
    CODE_INTERNE_CD                  ,
    PREVIOUS_FAMILLE_CD              ,
    PREVIOUS_FAMILLE_LB              ,
    CIRCUIT_CD                       ,
    EST_GESTE_CO                     ,
    PAR_MSISDN_ID                    ,
    PAR_NDS                          ,
    EXT_AGENT_ID                     ,
    ORG_AGENT_ID                     ,
    ORG_LAST_NAME_NM                 ,
    ORG_FIRST_NAME_NM                ,
    EXT_SHOP_ID                      ,
    EXT_SHOP_ADV_CD                  ,
    PREVIOUS_EXT_PRODUCT_ID          ,
    PREVIOUS_EAN_CD                  ,
    PREVIOUS_IMEI_CD                 ,
    EXT_PRODUCT_ID                   ,
    EAN_CD                           ,
    IMEI_CD                          ,
    FAMILLE_CD                       ,
    FAMILLE_LB                       ,
    DOSSIER_DEB_DT                   ,
    DOSSIER_FIN_DT                   ,
    PANNE_CD                         ,
    AIDE_DIAG                        ,
    DIAG_PANNE_CD                    ,
    REPARATION_LB                    ,
    REPARATION_DT                    ,
    REPARATION_GARANTIE              ,
    PRE_DOSSIER                      ,
    NUMERO_CHRONOPOST                ,
    DOSSIER_PRET_CD                  ,
    DUPLIQUE_CD                      ,
    CASE_ID_SPAS                     ,
    CRI_CD                           ,
    COMMANDE_DT                      ,
    PANNE                            ,
    EST_GARANTIE                     ,
    CLIENT_CP                        ,
    FIN_GARANTIE_DT                  ,
    LIVRAISON_DT                     ,
    ACHAT_DT                         ,
    STATUT_COMMANDE_CD               ,
    POINT_RELAIS_CD                  ,
    PR_CODE_POSTAL_CD                ,
    LIVRAISON_MODE_CD                ,
    DATE1_PROPOSEE                   ,
    RI_DATE_ENVOI                    ,
    RI_POINT_RELAIS_RET_CD           ,
    PR_RI_CODE_POSTAL_CD             ,
    CLIENT_EAN_TERM                  ,
    ANNULATION_CD                    ,
    FACTURATION_MOTIF_CD             ,
    MOBILE_ECHANGE_DT                ,
    GARANTIE_FIN_DT                  ,
    ACCESSOIRE_CD                    ,
    IMEI_COFFRET                     ,
    PAYS_FIRST_CD                    ,
    MOTIF_PRET_CD                    ,
    PRET_PAYANT                      ,
    RESTITUTION_TERMINAL             ,
    ETAT_TERM_PRET_CD                ,
    A_ETE_FACT_PRET                  ,
    A_ETE_FACT_RESTI                 ,
    FAIT_GENERATEUR_DT               ,
    MOTIF_RESILIATION_CD             ,
    SYSTEME_FACTURATION              , --PILCOM_404
    ALLEGRO_CD                       , --PILCOM_404
    MONTANT_FACT_ALLEGRO             , --PILCOM_404
    TYPE_PROCESS                     , --PILCOM_404 
    ETP_ANNUL_CD                     ,
    ETP_ANNUL_TS                     ,
    ETP_ANNUL_USR_CD                 ,
    ETP_ANNUL_ALLIANCE_CD            ,
    ETP_ANNUL_COMPTE_CD              ,
    ETP_ANNUL_EDO_ID                 ,
    ETP_0_CD                         ,
    ETP_0_TS                         ,
    ETP_0_USR_CD                     ,
    ETP_0_ALLIANCE_CD                ,
    ETP_0_COMPTE_CD                  ,
    ETP_0_EDO_ID                     ,
    ETP_200_CD                       ,
    ETP_200_TS                       ,
    ETP_200_USR_CD                   ,
    ETP_200_ALLIANCE_CD              ,
    ETP_200_COMPTE_CD                ,
    ETP_200_EDO_ID                   ,
    ETP_200_COM_FTT                  ,
    ETP_1_CD                         ,
    ETP_1_TS                         ,
    ETP_1_USR_CD                     ,
    ETP_1_ALLIANCE_CD                ,
    ETP_1_COMPTE_CD                  ,
    ETP_1_EDO_ID                     ,
    ETP_101_CD                       ,
    ETP_101_TS                       ,
    ETP_101_USR_CD                   ,
    ETP_101_ALLIANCE_CD              ,
    ETP_101_COMPTE_CD                ,
    ETP_101_EDO_ID                   ,
    ETP_101_COM_FTT                  ,
    ETP_20_CD                        ,
    ETP_20_TS                        ,
    ETP_20_USR_CD                    ,
    ETP_20_ALLIANCE_CD               ,
    ETP_20_COMPTE_CD                 ,
    ETP_20_EDO_ID                    ,
    ETP_204_CD                       ,
    ETP_204_TS                       ,
    ETP_204_USR_CD                   ,
    ETP_204_ALLIANCE_CD              ,
    ETP_204_COMPTE_CD                ,
    ETP_204_EDO_ID                   ,
    ETP_204_COM_FTT                  ,
    CREATION_TS                      ,
    LAST_MODIF_TS                    ,
    FRESH_IN                         ,
    COHERENCE_IN                        
)
Select
     ActeId.ACTE_ID                               AS      ACTE_ID                           ,
     Placement.EXTERNAL_ORDR_ID                   As      EXTERNAL_ORDR_ID                  ,
     Placement.EXTERNAL_ACTE_ID                   As      EXTERNAL_ACTE_ID                  ,
     Placement.ORDER_DEPOSIT_DT                   As      ORDER_DEPOSIT_DT                  ,
     Placement.ORDER_DEPOSIT_TS                   As      ORDER_DEPOSIT_TS                  ,
     Placement.TYPE_SOURCE_ID                     As      TYPE_SOURCE_ID                    ,
     Placement.INTRNL_SOURCE_ID                   As      INTRNL_SOURCE_ID                  ,
     Placement.ORDER_STATUS_CD                    As      ORDER_STATUS_CD                   ,
     Placement.ORDER_STATUS_DS                    As      ORDER_STATUS_DS                   ,
     Placement.ORDR_TYP_CD                        As      ORDR_TYP_CD                       ,
     Placement.MOTIF_CD                           As      MOTIF_CD                          ,
     Placement.CODE_INTERNE_CD                    As      CODE_INTERNE_CD                   ,
     Placement.PREVIOUS_FAMILLE_CD                As      PREVIOUS_FAMILLE_CD               ,
     Placement.PREVIOUS_FAMILLE_LB                As      PREVIOUS_FAMILLE_LB               ,
     Placement.CIRCUIT_CD                         As      CIRCUIT_CD                        ,
     Placement.EST_GESTE_CO                       As      EST_GESTE_CO                      ,
     Placement.PAR_MSISDN_ID                      As      PAR_MSISDN_ID                     ,
     Placement.PAR_NDS                            As      PAR_NDS                           ,
     trim(Placement.EXT_AGENT_ID )                As      EXT_AGENT_ID                      ,
     Placement.ORG_AGENT_ID                       As      ORG_AGENT_ID                      ,
     Placement.ORG_LAST_NAME_NM                   As      ORG_LAST_NAME_NM                  ,
     Placement.ORG_FIRST_NAME_NM                  As      ORG_FIRST_NAME_NM                 ,
     Placement.EXT_SHOP_ID                        As      EXT_SHOP_ID                       ,
     Placement.EXT_SHOP_ADV_CD                    As      EXT_SHOP_ADV_CD                   ,
     Placement.PREVIOUS_EXT_PRODUCT_ID            As      PREVIOUS_EXT_PRODUCT_ID           ,
     Placement.PREVIOUS_EAN_CD                    As      PREVIOUS_EAN_CD                   ,
     Placement.PREVIOUS_IMEI_CD                   As      PREVIOUS_IMEI_CD                  ,
     Placement.EXT_PRODUCT_ID                     As      EXT_PRODUCT_ID                    ,
     Placement.EAN_CD                             As      EAN_CD                            ,
     Placement.IMEI_CD                            As      IMEI_CD                           ,
     Placement.FAMILLE_CD                         As      FAMILLE_CD                        ,
     Placement.FAMILLE_LB                         As      FAMILLE_LB                        ,
     Placement.DOSSIER_DEB_DT                     As      DOSSIER_DEB_DT                    ,
     Placement.DOSSIER_FIN_DT                     As      DOSSIER_FIN_DT                    ,
     Placement.PANNE_CD                           As      PANNE_CD                          ,
     Placement.AIDE_DIAG                          As      AIDE_DIAG                         ,
     Placement.DIAG_PANNE_CD                      As      DIAG_PANNE_CD                     ,
     Placement.REPARATION_LB                      As      REPARATION_LB                     ,
     Placement.REPARATION_DT                      As      REPARATION_DT                     ,
     Placement.REPARATION_GARANTIE                As      REPARATION_GARANTIE               ,
     Placement.PRE_DOSSIER                        As      PRE_DOSSIER                       ,
     Placement.NUMERO_CHRONOPOST                  As      NUMERO_CHRONOPOST                 ,
     Placement.DOSSIER_PRET_CD                    As      DOSSIER_PRET_CD                   ,
     Placement.DUPLIQUE_CD                        As      DUPLIQUE_CD                       ,
     Placement.CASE_ID_SPAS                       As      CASE_ID_SPAS                      ,
     Placement.CRI_CD                             As      CRI_CD                            ,
     Placement.COMMANDE_DT                        As      COMMANDE_DT                       ,
     Placement.PANNE                              As      PANNE                             ,
     Placement.EST_GARANTIE                       As      EST_GARANTIE                      ,
     Placement.CLIENT_CP                          As      CLIENT_CP                         ,
     Placement.FIN_GARANTIE_DT                    As      FIN_GARANTIE_DT                   ,
     Placement.LIVRAISON_DT                       As      LIVRAISON_DT                      ,
     Placement.ACHAT_DT                           As      ACHAT_DT                          ,
     Placement.STATUT_COMMANDE_CD                 As      STATUT_COMMANDE_CD                ,
     Placement.POINT_RELAIS_CD                    As      POINT_RELAIS_CD                   ,
     Placement.PR_CODE_POSTAL_CD                  As      PR_CODE_POSTAL_CD                 ,
     Placement.LIVRAISON_MODE_CD                  As      LIVRAISON_MODE_CD                 ,
     Placement.DATE1_PROPOSEE                     As      DATE1_PROPOSEE                    ,
     Placement.RI_DATE_ENVOI                      As      RI_DATE_ENVOI                     ,
     Placement.RI_POINT_RELAIS_RET_CD             As      RI_POINT_RELAIS_RET_CD            ,
     Placement.PR_RI_CODE_POSTAL_CD               As      PR_RI_CODE_POSTAL_CD              ,
     Placement.CLIENT_EAN_TERM                    As      CLIENT_EAN_TERM                   ,
     Placement.ANNULATION_CD                      As      ANNULATION_CD                     ,
     Placement.FACTURATION_MOTIF_CD               As      FACTURATION_MOTIF_CD              ,
     Placement.MOBILE_ECHANGE_DT                  As      MOBILE_ECHANGE_DT                 ,
     Placement.GARANTIE_FIN_DT                    As      GARANTIE_FIN_DT                   ,
     Placement.ACCESSOIRE_CD                      As      ACCESSOIRE_CD                     ,
     Placement.IMEI_COFFRET                       As      IMEI_COFFRET                      ,
     Placement.PAYS_FIRST_CD                      As      PAYS_FIRST_CD                     ,
     Placement.MOTIF_PRET_CD                      As      MOTIF_PRET_CD                     ,
     Placement.PRET_PAYANT                        As      PRET_PAYANT                       ,
     Placement.RESTITUTION_TERMINAL               As      RESTITUTION_TERMINAL              ,
     Placement.ETAT_TERM_PRET_CD                  As      ETAT_TERM_PRET_CD                 ,
     Placement.A_ETE_FACT_PRET                    As      A_ETE_FACT_PRET                   ,
     Placement.A_ETE_FACT_RESTI                   As      A_ETE_FACT_RESTI                  ,
     Placement.FAIT_GENERATEUR_DT                 As      FAIT_GENERATEUR_DT                ,
     Placement.MOTIF_RESILIATION_CD               As      MOTIF_RESILIATION_CD              ,
     Placement.SYSTEME_FACTURATION                As      SYSTEME_FACTURATION               , --PILCOM_404
     Placement.ALLEGRO_CD                         As      ALLEGRO_CD                        , --PILCOM_404
     Placement.MONTANT_FACT_ALLEGRO               As      MONTANT_FACT_ALLEGRO              , --PILCOM_404
     Placement.TYPE_PROCESS                       As      TYPE_PROCESS                      , --PILCOM_404
     Placement.ETP_ANNUL_CD                       As      ETP_ANNUL_CD                      ,
     Placement.ETP_ANNUL_TS                       As      ETP_ANNUL_TS                      ,
     Placement.ETP_ANNUL_USR_CD                   As      ETP_ANNUL_USR_CD                  ,
     Placement.ETP_ANNUL_ALLIANCE_CD              As      ETP_ANNUL_ALLIANCE_CD             ,
     Placement.ETP_ANNUL_COMPTE_CD                As      ETP_ANNUL_COMPTE_CD               ,
     Placement.ETP_ANNUL_EDO_ID                   As      ETP_ANNUL_EDO_ID                  ,
     Placement.ETP_0_CD                           As      ETP_0_CD                          ,
     Placement.ETP_0_TS                           As      ETP_0_TS                          ,
     Placement.ETP_0_USR_CD                       As      ETP_0_USR_CD                      ,
     Placement.ETP_0_ALLIANCE_CD                  As      ETP_0_ALLIANCE_CD                 ,
     Placement.ETP_0_COMPTE_CD                    As      ETP_0_COMPTE_CD                   ,
     Placement.ETP_0_EDO_ID                       As      ETP_0_EDO_ID                      ,
     Placement.ETP_200_CD                         As      ETP_200_CD                        ,
     Placement.ETP_200_TS                         As      ETP_200_TS                        ,
     Placement.ETP_200_USR_CD                     As      ETP_200_USR_CD                    ,
     Placement.ETP_200_ALLIANCE_CD                As      ETP_200_ALLIANCE_CD               ,
     Placement.ETP_200_COMPTE_CD                  As      ETP_200_COMPTE_CD                 ,
     Placement.ETP_200_EDO_ID                     As      ETP_200_EDO_ID                    ,
     Placement.ETP_200_COM_FTT                    As      ETP_200_COM_FTT                   ,
     Placement.ETP_1_CD                           As      ETP_1_CD                          ,
     Placement.ETP_1_TS                           As      ETP_1_TS                          ,
     Placement.ETP_1_USR_CD                       As      ETP_1_USR_CD                      ,
     Placement.ETP_1_ALLIANCE_CD                  As      ETP_1_ALLIANCE_CD                 ,
     Placement.ETP_1_COMPTE_CD                    As      ETP_1_COMPTE_CD                   ,
     Placement.ETP_1_EDO_ID                       As      ETP_1_EDO_ID                      ,
     Placement.ETP_101_CD                         As      ETP_101_CD                        ,
     Placement.ETP_101_TS                         As      ETP_101_TS                        ,
     Placement.ETP_101_USR_CD                     As      ETP_101_USR_CD                    ,
     Placement.ETP_101_ALLIANCE_CD                As      ETP_101_ALLIANCE_CD               ,
     Placement.ETP_101_COMPTE_CD                  As      ETP_101_COMPTE_CD                 ,
     Placement.ETP_101_EDO_ID                     As      ETP_101_EDO_ID                    ,
     Placement.ETP_101_COM_FTT                    As      ETP_101_COM_FTT                   ,
     Placement.ETP_20_CD                          As      ETP_20_CD                         ,
     Placement.ETP_20_TS                          As      ETP_20_TS                         ,
     Placement.ETP_20_USR_CD                      As      ETP_20_USR_CD                     ,
     Placement.ETP_20_ALLIANCE_CD                 As      ETP_20_ALLIANCE_CD                ,
     Placement.ETP_20_COMPTE_CD                   As      ETP_20_COMPTE_CD                  ,
     Placement.ETP_20_EDO_ID                      As      ETP_20_EDO_ID                     ,
     Placement.ETP_204_CD                         As      ETP_204_CD                        ,
     Placement.ETP_204_TS                         As      ETP_204_TS                        ,
     Placement.ETP_204_USR_CD                     As      ETP_204_USR_CD                    ,
     Placement.ETP_204_ALLIANCE_CD                As      ETP_204_ALLIANCE_CD               ,
     Placement.ETP_204_COMPTE_CD                  As      ETP_204_COMPTE_CD                 ,
     Placement.ETP_204_EDO_ID                     As      ETP_204_EDO_ID                    ,
     Placement.ETP_204_COM_FTT                    As      ETP_204_COM_FTT                   ,
     Current_timestamp(0)                         As      CREATION_TS                       ,
     Current_Timestamp(0)                         As      LAST_MODIF_TS                     ,
     1                                            As      FRESH_IN                          ,
     1                                            As      COHERENCE_IN                      
From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT Placement
  Inner Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN ActeId
    On    Placement.EXTERNAL_ACTE_ID          = ActeId.EXTERNAL_ACTE_ID
      And Placement.TYPE_SOURCE_ID            = ActeId.TYPE_SOURCE_ID
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAH_1;
.if errorcode <> 0 then .quit 1

.quit 0
