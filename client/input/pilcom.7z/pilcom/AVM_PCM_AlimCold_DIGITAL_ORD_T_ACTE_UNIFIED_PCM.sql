--$HEADER: %HEADER%
--------------------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_PCM_AlimCold_DIGITAL_ORD_T_ACTE_UNIFIED_PCM.sql  $                                       
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source PCM dans la table ORD_T_ACTE_UNIFIED_PCM
--------------------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION                                
-- 23/07/2019     GRH         Modification                                         
-- 25/09/2019     EVI         Alimentation Champs KPI2020 : ACT_CA_LINE_AM
-- 09/10/2019     EVI         KPI2020 : Mise en place du filtre sur les NS/NSTECH pour data enabler
-- 02/07/2020     EVI         PILCOM-501 : Indicateur eSim - New Champ SIM_EAN_CD
-- 13/10/2020     EVI         PILCOM-724 : Gestion Retour PVC - Correction Bug ecrasement CUID
-- 24/02/2021     EVI         PILCOM-758 : REFONTE DIGITAL - Fiabilisation Gestion ANNUL 
-- 21/06/2021     BCH         PILCOM-948 : Suppression des colonnes obsolètes de ORD_T_ACTE_UNIFIED_PCM
---------------------------------------------------------------------------------- 
.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_PCM --
------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_PCM
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_EDO_IOBSP                 ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  PAR_IRIS2000_CD               ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  ACT_CA_LINE_AM                ,
  EAN_CD                        ,
  ORG_RESP_ID                   ,
   --Ajout QC 712 : Ajout Code TAC,EAN,IMEI
  TAC_PREVIOUS_CD               ,
  IMEI_PREVIOUS_CD              ,
  EAN_PREVIOUS_CD               ,
  PCM_PREVIOUS_OFFRE_CD         ,
  COMMARTICLE_RP_REFPRIX_CD     ,
  PCM_COMMTMNT_PERIOD_NU        ,
  PCM_LEVEL_POINT_NU            ,
  PCM_OFFRE_CD                  ,
  PCM_EFFCTV_NEXT_OFFRE_DT      ,
  PCM_TYPE_OFFRE_MOBILE_CD      ,
  PCM_POINT_UTIL_NU             ,
  PCM_BALANCE_POINT_NU          ,
  PCM_STATUT_POINT_CD           ,
  PCM_POINT_DUE_NU              ,
    --Fin QC 712
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                   
)
Select
  PCM.ACTE_ID_GEN                                                          As ACTE_ID                         ,
  PCM.OPERATOR_PROVIDER_ID                                                 As OPERATOR_PROVIDER_ID            ,
  PCM.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID                ,
  '${P_PIL_369}'                                                           As TYPE_SOURCE_ID                  ,
  PCM.ACTE_ID_GEN                                                          As MASTER_ACTE_ID                  ,
  PCM.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID         ,
  ${P_PIL_354}                                                             As MASTER_FLAG                     ,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND                 ,
  DIGITAL.ACTE_ID_INTRCTN                                                  As CPLT_ACTE_ID                    ,
    Case  When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then  31 -- code de la source JRC
    Else Null
  End                                                                      As CPLT_INTRNL_SOURCE_ID           ,
  
  Case  When DIGITAL.ACTE_ID_INTRCTN Is Not Null                                                               
          Then  'O'                                                                                            
        Else    'N'                                                                                            
  End                                                                      As CPLT_IN                         ,
  
  Case  When PCM.CPLT_ACTE_ID Is Not Null And CPLT_INTRL_SOURCE_ID =2                                          
            Then  '21'                                                                                         
          Else    '${P_PIL_362}'                                                                               
  End                                                                      As RULE_ID                         ,
  Null                                                                     As OFFSET_NB                       ,
  '${P_PIL_325}'                                                           As ACT_TYPE                        ,
  PCM.ORDER_EXTERNAL_ID                                                    As ORDER_EXTERNAL_ID               ,
  PCM.ORDER_STATUT_CD                                                      As STATUS_CD                       ,
  Case When PCM.CONCURENCE_IN = '${P_PIL_356}' Then '${P_PIL_385}' 
       When PCM.ORDER_STATUT_CD IN('AN','AB') And PCM.STATUT_NON_CONCLU >= PCM.ORDER_DEPOSIT_DT Then '${P_PIL_386}'                                             
       When PCM.CONFIRMATION_IN = '${P_PIL_357}' Then '${P_PIL_386}'                                           
       When PCM.PERENNITE_IN = '${P_PIL_356}' Then '${P_PIL_384}'                                              
       When PCM.DELIVERY_IN = '${P_PIL_356}' And PCM.PERENNITE_IN = '${P_PIL_357}' Then '${P_PIL_387}'         
       When PCM.DELIVERY_IN = '${P_PIL_356}' Then '${P_PIL_383}'                                               
       When PCM.CONFIRMATION_IN = '${P_PIL_356}' Then '${P_PIL_382}'                                           
       Else '${P_PIL_381}'                                                                                     
  End                                                                      As ACT_UNIFIED_STATUS_CD           ,
  Cast(PCM.ORDER_DEPOSIT_DT As TIMESTAMP(0) FORMAT 'YYYY-MM-DD')           As ACT_TS                          ,
  PCM.ORDER_DEPOSIT_DT                                                     As ACT_DT                          ,
  Extract(HOUR From (Cast(PCM.ORDER_DEPOSIT_DT As TIMESTAMP FORMAT 'YYYY-MM-DD') )) As ACT_HH                 ,
  PCM.ORDER_LAST_STATUT_MODIF_TS                                           As ACT_LAST_UPD_TS                 ,
  PCM.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE              ,
  PCM.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE              ,
  PCM.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE          ,
  PCM.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE               ,
  PCM.ACT_OPER_ID_PRE                                                      As ACT_OPER_ID_PRE                 ,
  PCM.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL            ,
  PCM.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL            ,
  PCM.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL        ,
  PCM.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL             ,
  --Dans PCM on ajoute que des produits                                                                        
  'ADD'                                                                    As ACT_OPER_ID_FINAL               ,
  PCM.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL          ,
  PCM.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID            ,
  PCM.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF                 ,
  PCM.ACT_CD                                                               As ACT_CD                          ,
  PCM.ACT_REM_ID                                                           As ACT_REM_ID                      ,
  PCM.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM                ,
  PCM.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC             ,
  --On Calcul si on doit envoyer ou pas l'acte à PVC                                                           
  Case  When  (   --Condition d'éligibilité                                                                    
                    (1=1)                                                                                      
                    -- L'acte doit être rémunérable                                                            
                    And PCM.ACT_FLAG_ACT_REM = 'O'                                                             
                    -- L'acte doit avoir un conseiller                                                         
                    And PCM.ORG_AGENT_ID_UPD Is Not Null                                                       
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)                               
                    And PCM.ORG_REM_CHANNEL_CD IN (${L_PIL_043})                                               
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)                        
                    --And SFI.SEG_PRES_PARC_COMMANDE  = 0                                                      
                    --L'acte ne doit pas être annulé                                                           
                    And PCM.CLOSURE_DT              Is Null                                                    
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV       
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV    
                )
        Then 'O'
       Else 'N'
  End                                                                       As ACT_FLAG_PVC_REM                 ,
  PCM.ACT_ACTE_VALO                                                         As ACT_ACTE_VALO                    ,
  PCM.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI             ,
  PCM.ACT_PERIODE_ID                                                        As ACT_PERIODE_ID                   ,
  PCM.ACT_PERIODE_STATUS                                                    As ACT_PERIODE_STATUS               ,
  PCM.ACT_PERIODE_CLOSURE_DT                                                As ACT_PERIODE_CLOSURE_DT           ,
  PCM.ORIG_DEM                                                              As ORIGIN_CD                        ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null  
    Then Trim (DIGITAL.INT_OPRTR_ID)             
    Else Trim(PCM.ORG_AGENT_ID)                  
  End                                                                       As AGENT_ID                                   ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null And PCM.ORG_AGENT_ID_UPD_DT Is Null
    Then Trim (DIGITAL.INT_OPRTR_ID)            
     Else Trim(PCM.ORG_AGENT_ID_UPD)            
  End                                                                       As AGENT_ID_UPD                               ,
  PCM.ORG_AGENT_ID_UPD_DT                                                   As AGENT_ID_UPD_DT                            ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null 
    Then DIGITAL.ORG_AGENT_IOBSP
    Else PCM.ORG_AGENT_IOBSP
  End                                                                       As ORG_AGENT_IOBSP                            ,
  
   Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null  
         Then Null                                
      Else PCM.ORG_AGENT_FIRST_NAME               
    End                                                                     As AGENT_FIRST_NAME                           ,
  
   Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null  
        Then Null                                 
      Else PCM.ORG_AGENT_LAST_NAME                
  End                                                                       As AGENT_LAST_NAME                            ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null   
       Then DIGITAL.NEW_UNIFIED_SHOP_CD           
    Else PCM.ORG_STORE_NAME                       
  End                                                                       As UNIFIED_SHOP_CD                             ,
  
 Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null    
    Then Null                                     
    Else PCM.ORG_CANAL_ID_MACRO                   
  End                                                                       As ORG_SPE_CANAL_ID_MACRO                      ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else PCM.ORG_CANAL_ID
  End                                                                       As ORG_SPE_CANAL_ID                             ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_REM_CHANNEL_CD
    Else PCM.ORG_REM_CHANNEL_CD
  End                                                                       As ORG_REM_CHANNEL_CD                           ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_CHANNEL_CD
    Else PCM.ORG_CHANNEL_CD
  End                                                                       As ORG_CHANNEL_CD                               ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_CHANNEL_CD
    Else PCM.ORG_SUB_CHANNEL_CD
  End                                                                       As ORG_SUB_CHANNEL_CD                            ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_SUB_CHANNEL_CD
    Else PCM.ORG_SUB_SUB_CHANNEL_CD
  End                                                                       As ORG_SUB_SUB_CHANNEL_CD                        ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_GT_ACTIVITY
    Else PCM.ORG_GT_ACTIVITY
  End                                                                       As ORG_GT_ACTIVITY                               ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_FIDELISATION
    Else PCM.ORG_FIDELISATION
  End                                                                       As ORG_FIDELISATION                              ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_WEB_ACTIVITY
    Else PCM.ORG_WEB_ACTIVITY
  End                                                                       As ORG_WEB_ACTIVITY                              ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_AUTO_ACTIVITY
    Else PCM.ORG_AUTO_ACTIVITY
  End                                                                       As ORG_AUTO_ACTIVITY                             ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_ID
    Else PCM.ORG_EDO_ID
  End                                                                      As ORG_EDO_ID                                    ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TYPE_EDO
    Else PCM.ORG_TYPE_EDO
  End                                                                      As ORG_TYPE_EDO                                  ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null 
    Then DIGITAL.NEW_ORG_EDO_IOBSP
    Else PCM.ORG_EDO_IOBSP
  End                                                                      As ORG_EDO_IOBSP                                 ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else PCM.ORG_FLAG_PLT_CONV
  End                                                                      As ORG_FLAG_PLT_CONV                             ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else PCM.ORG_FLAG_TEAM_MKT
  End                                                                      As ORG_FLAG_TEAM_MKT                             ,
  
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else PCM.ORG_FLAG_TYPE_CMP
  End                                                                      As ORG_FLAG_TYPE_CMP                             ,
  
  Case  When PCM.CPLT_ACTE_ID Is Not Null And PCM.CPLT_INTRL_SOURCE_ID = 2
            Then PCM.CPLT_ORG_RESP_EDO_ID
        Else    Null
  End                                                                      As ORG_RESP_EDO_ID                               ,
  Case  When PCM.CPLT_ACTE_ID Is Not Null And PCM.CPLT_INTRL_SOURCE_ID = 2
            Then PCM.CPLT_ORG_RESP_TYPE_EDO
        Else    Null
  End                                                                      As ORG_RESP_TYPE_EDO                             ,
  
  Case  When PCM.CPLT_ACTE_ID Is Not Null And PCM.CPLT_INTRL_SOURCE_ID = 2
            Then PCM.CPLT_ORG_RESP_FLAG_PLT_CONV
        Else    Null                                                                                                         
  End                                                                      As ORG_RESP_FLAG_PLT_CONV                        ,
  
  Null                                                                     As ACTIVITY_CD           ,
  Null                                                                     As ACTIVITY_GROUPNG_CD   ,
  Null                                                                     As AUTO_ACTIVITY_IN      ,
  '${P_PIL_366}'                                                           As ORG_TYPE_CD           ,
  Null                                                                     As ORG_TEAM_TYPE_ID      ,
  
 Trim (Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_CD
    Else PCM.ORG_TEAM_LEVEL_1_CD
  End)                                                                      As ORG_TEAM_LEVEL_1_CD             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_DS
    Else PCM.ORG_TEAM_LEVEL_1_DS
  End )                                                                      As ORG_TEAM_LEVEL_1_DS            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_CD
    Else PCM.ORG_TEAM_LEVEL_2_CD
  End)                                                                      As ORG_TEAM_LEVEL_2_CD             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_DS
    Else PCM.ORG_TEAM_LEVEL_2_DS
  End)                                                                      As ORG_TEAM_LEVEL_2_DS             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_CD
    Else PCM.ORG_TEAM_LEVEL_3_CD
  End)                                                                      As ORG_TEAM_LEVEL_3_CD             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_DS
    Else PCM.ORG_TEAM_LEVEL_3_DS
  End)                                                                      As ORG_TEAM_LEVEL_3_DS             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_CD
    Else PCM.ORG_TEAM_LEVEL_4_CD
  End)                                                                      As ORG_TEAM_LEVEL_4_CD             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_DS
    Else PCM.ORG_TEAM_LEVEL_4_DS
  End)                                                                      As ORG_TEAM_LEVEL_4_DS             ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_CD
    Else PCM.WORK_TEAM_LEVEL_1_CD
  End )                                                                     As WORK_TEAM_LEVEL_1_CD            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_DS
    Else PCM.WORK_TEAM_LEVEL_1_DS
  End)                                                                      As WORK_TEAM_LEVEL_1_DS            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_CD
    Else PCM.WORK_TEAM_LEVEL_2_CD
  End )                                                                     As WORK_TEAM_LEVEL_2_CD            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_DS
    Else PCM.WORK_TEAM_LEVEL_2_DS
  End )                                                                     As WORK_TEAM_LEVEL_2_DS            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_CD
    Else PCM.WORK_TEAM_LEVEL_3_CD
  End)                                                                      As WORK_TEAM_LEVEL_3_CD            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_DS
    Else PCM.WORK_TEAM_LEVEL_3_DS
  End )                                                                     As WORK_TEAM_LEVEL_3_DS            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_CD
    Else PCM.WORK_TEAM_LEVEL_4_CD
  End)                                                                      As WORK_TEAM_LEVEL_4_CD            ,
  
  Trim(Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_DS
    Else PCM.WORK_TEAM_LEVEL_4_DS
  End)                                                                     As WORK_TEAM_LEVEL_4_DS             ,
  
  PCM.CONFIRMATION_IN                                                      As CONFIRMATION_IN                  ,
  Null                                                                     As MIGRA_DT                      ,
  Null                                                                     As MIGRA_NEXT_OFFRE              ,
  --Les PCM on ne fait pas cette vérification
  0                                                                         As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  Case  When  (PCM.ORDER_DEPOSIT_DT + 45 ) >= PCM.DELIVERY_DT
          Then PCM.DELIVERY_DT
        Else Null
  End                                                                       As SEGMENT_DELIVERY_IN_PARK_DT      ,
  PCM.STATUT_NON_CONCLU                                                     As ORDER_CANCELING_DT               ,
  PCM.DMC_LINE_ID                                                          As LINE_ID,
  PCM.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID,
  PCM.PAR_TYPE                                                             As CUST_TYPE_CD,
  Coalesce(PCM.PAR_ADV_DOSSIER_NU, '0000000000')                           As MSISDN_ID,
  Coalesce(PCM.PAR_ND, '0000000000')                                       As NDS_VALUE_DS,
  PCM.PAR_ADV_CLIENT_NU                                                    As EXTERNAL_PARTY_ID,
  PCM.PAR_EXTERNAL_PARTY_BSS_ID                                            As RES_VALUE_DS,
  PCM.PAR_ACCES_SERVICE                                                    As PAR_ACCES_SERVICE,
  PCM.PAR_MOB_TAC                                                          As TAC_CD,
  PCM.PAR_MOB_IMEI                                                         As IMEI_CD,
  PCM.PAR_IMSI                                                             As IMSI_CD,
  Null                                                                     As HOM_START_DT,
  Null                                                                     As MOB_START_DT,
  Null                                                                     As I_SCORE_VALUE,
  Null                                                                     As I_SCORE_TRESHOLD,
  Null                                                                     As I_SCORE_IN,
  PCM.PAR_SCORE_NU                                                         As M_SCORE_VALUE,
  Case
    When PCM.PAR_TRESHOLD_NU > 100 Then -1
    Else PCM.PAR_TRESHOLD_NU
  End                                                                      As M_SCORE_TRESHOLD,
  PCM.PAR_SCORE_IN                                                         As M_SCORE_IN,
  Case
      When PCM.OTO_OSCAR_VALUE_NU = 'SC'
           Then Null
      Else
           Cast(PCM.OTO_OSCAR_VALUE_NU As BYTEINT)
  End                                                                      As OSCAR_VALUE,
  '${P_PIL_376}'                                                           AS CUST_BU_TYPE_CD,
  PCM.PAR_USCM                                                             As CUST_BU_CD,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE,
  Trim(
    Trim(Coalesce(Case When PCM.PAR_BILL_ADRESS_1 = 'null' Then Null Else PCM.PAR_BILL_ADRESS_1 End,'')) || ' ' ||
    Trim(Coalesce(Case When PCM.PAR_BILL_ADRESS_2 = 'null' Then Null Else PCM.PAR_BILL_ADRESS_2 End,'')) || ' ' ||
    Trim(Coalesce(Case When PCM.PAR_BILL_ADRESS_3 = 'null' Then Null Else PCM.PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(PCM.PAR_BILL_CD_POSTAL,'')) || ' ' ||
    Trim(Coalesce(Case When PCM.PAR_BILL_ADRESS_4 = 'null' Then Null Else PCM.PAR_BILL_ADRESS_4 End,''))         
  )                                                                        As ADDRESS_CONCAT_NM                 ,
  Coalesce(PCM.PAR_POSTAL_CD , PCM.PAR_BILL_CD_POSTAL )                    As POSTAL_CD                         ,
  Coalesce(PCM.PAR_INSEE_CD ,PCM.INSEE_CD  )                               As INSEE_CD                          ,
  PCM.PAR_BU_CD                                                            As BU_CD                             ,
  Coalesce(PCM.PAR_DEPARTMNT_ID ,PCM.PAR_DO )                              As DEPARTMNT_ID                      ,
  PCM.PAR_GEO_MACROZONE                                                    as PAR_GEO_MACROZONE                 ,
  
    Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_UNIFIED_PARTY_ID
    Else PCM.PAR_UNIFIED_PARTY_ID
  End                                                                      As PAR_UNIFIED_PARTY_ID              ,
  
  PCM.PAR_PARTY_REGRPMNT_ID                                                As PAR_PARTY_REGRPMNT_ID             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.PAR_CID_ID
    Else  PCM.PAR_CID_ID
  End                                                                      As PAR_CID_ID                        ,
  
   Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_PID_ID
    Else  PCM.PAR_PID_ID
  End                                                                      As PAR_PID_ID                        ,
  
  PCM.PAR_FIRST_IN                                                         As PAR_FIRST_IN                      ,
  PCM.PAR_IRIS2000_CD                                                      As PAR_IRIS2000_CD                   ,
  Null                                                                     As SIM_CD                            ,
  Null                                                                     As SIM_EAN_CD                        ,
  PCM.ACT_DELTA_TARIF                                                      As ACT_CA_LINE_AM                    ,
  PPROD.REFARTICLE                                                         As EAN_CD                            ,
  PCM.ORG_RESP_AGENT_ID                                                    As ORG_RESP_ID                       ,
  PCM.TAC_PREVIOUS_CD                                                      As TAC_PREVIOUS_CD                   ,
  PCM.IMEI_PREVIOUS_CD                                                     As IMEI_PREVIOUS_CD                  ,
  PCM.EAN_PREVIOUS_CD                                                      As EAN_PREVIOUS_CD                   ,
  PCM.PCM_PREVIOUS_OFFRE_CD                                                As PCM_PREVIOUS_OFFRE_CD             ,
  PCM.COMMARTICLE_RP_REFPRIX_CD                                            As COMMARTICLE_RP_REFPRIX_CD         ,
  PCM.PCM_COMMTMNT_PERIOD_NU                                               As PCM_COMMTMNT_PERIOD_NU            ,
  PCM.PCM_LEVEL_POINT_NU                                                   As PCM_LEVEL_POINT_NU                ,
  PCM.CO_OFFRE_TERM_CD                                                     As PCM_OFFRE_CD                      ,
  PCM.PCM_EFFCTV_NEXT_OFFRE_DT                                             As PCM_EFFCTV_NEXT_OFFRE_DT          ,
  PCM.PCM_TYPE_OFFRE_MOBILE_CD                                             As PCM_TYPE_OFFRE_MOBILE_CD          ,
  PCM.PCM_POINT_UTIL_NU                                                    As PCM_POINT_UTIL_NU                 ,
  PCM.PCM_BALANCE_POINT_NU                                                 As PCM_BALANCE_POINT_NU              ,
  PCM.PCM_STATUT_POINT_CD                                                  As PCM_STATUT_POINT_CD               ,
  PCM.PCM_POINT_DUE_NU                                                     As PCM_POINT_DUE_NU                  ,
  PCM.CHECK_INITIAL_STATUS_CD                                              As CHECK_INITIAL_STATUS_CD           ,
  PCM.CHECK_NAT_STATUS_CD                                                  As CHECK_NAT_STATUS_CD               ,
  PCM.CHECK_NAT_COMMENT                                                    As CHECK_NAT_COMMENT                 ,
  PCM.CHECK_NAT_STATUS_LN                                                  As CHECK_NAT_STATUS_LN               ,
  PCM.CHECK_LOC_STATUS_CD                                                  As CHECK_LOC_STATUS_CD               ,
  PCM.CHECK_LOC_COMMENT                                                    As CHECK_LOC_COMMENT                 ,
  PCM.CHECK_LOC_STATUS_LN                                                  As CHECK_LOC_STATUS_LN               ,
  PCM.CHECK_VALIDT_DT                                                      As CHECK_VALIDT_DT                   ,
  Null                                                                     As ACT_END_UNIFIED_DT                ,
  Null                                                                     As ACT_END_UNIFIED_DS                ,
  PCM.CLOSURE_DT                                                           As ACT_CLOSURE_DT                    ,
  Case When PCM.CLOSURE_DT Is Not Null
       Then 'Acte Clos'
  End                                                                      As ACT_CLOSURE_DS                    ,
  0                                                                        As HOT_IN                            ,
  PCM.RUN_ID                                                               As RUN_ID                            ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS                       ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS                     ,
  1                                                                        As FRESH_IN                          ,
  0                                                                        As COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM PCM                                                                          
Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL DIGITAL -- c'est une table historisee, bien faire attention au CURRENT_IN = 1
    On PCM.ACTE_ID            = DIGITAL.ACTE_ID
    And PCM.ORDER_DEPOSIT_DT  = DIGITAL.ACT_DT
    And DIGITAL.CURRENT_IN = 1
Left Outer Join ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM PPROD                                                       
On PCM.ACTE_ID = PPROD.ACTE_ID                                                                                   
  And PCM.ORDER_DEPOSIT_DT = PPROD.DATESAISIEBCR                                                                 
Where (1=1)                                                                                                      
  And Substr(PCM.ACT_CD,1,3) Not In (${L_PIL_036})
  And PCM.ACT_SEG_COM_ID_FINAL <> '${P_PIL_295}'
  And PCM.ACT_CD <> '${P_PIL_067}'
  And PCM.ACT_ACTE_FAMILLE_KPI          Not In (${L_PIL_626}) -- NS, NSTECH
  And PCM.ACT_PERIODE_ID > 12
  And PCM.ORDER_DEPOSIT_DT >= Current_date - 250
  And PCM.ORG_CHANNEL_CD   IN ('Online','DNU')  
  And ((PCM.LAST_MODIF_TS >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And PCM.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or PCM.ORDER_DEPOSIT_DT > Current_date -15)
  And Not Exists (
    Select 'X' 
    From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_PCM PC
    Where PC.ACTE_ID = DIGITAL.ACTE_ID
    And PC.ACT_DT  = DIGITAL.ACT_DT
  )
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_PCM;
.if errorcode <> 0 then .quit 1;