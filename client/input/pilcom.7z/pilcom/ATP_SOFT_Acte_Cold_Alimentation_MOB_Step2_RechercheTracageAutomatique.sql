-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step3_RechercheCommandeEFB.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul de rcherche du traçage automatique de l'acte SOFT mob 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 12/03/2015      HFO         Evolution Ajout CPLT_ORG_EDO_ID de HRF
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_TRC_AUTO All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : recherche le traçage automatique
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_TRC_AUTO
(
  ACTE_ID                             ,
  ORDER_DEPOSIT_DT                    ,
  CPLT_ACTE_ID                        ,
  CPLT_EXT_INT_ID                     ,
  CPLT_EXT_INT_DELT_ID                ,
  CPLT_ORG_EDO_ID                     ,
  CPLT_ORG_TYPE_EDO                   ,
  CPLT_ORG_FLAG_PLT_CONV              ,
  CPLT_ORG_FLAG_TEAM_MKT              ,
  CPLT_ORG_FLAG_TYPE_CMP              ,
  CPLT_ORG_REM_CHANNEL_CD             ,
  CPLT_ORG_CHANNEL_CD                 ,
  CPLT_ORG_SUB_CHANNEL_CD             ,
  CPLT_ORG_SUB_SUB_CHANNEL_CD         ,
  CPLT_ORG_GT_ACTIVITY                ,
  CPLT_ORG_FIDELISATION               ,
  CPLT_ORG_WEB_ACTIVITY               ,
  CPLT_ORG_AUTO_ACTIVITY              ,
  CPLT_EXTERNAL_TEAM_CD               ,
  CPLT_O3_ACTIVE_TEAM_CD              ,
  CPLT_O3_RATTACHEMENT_TEAM_CD        ,
  CPLT_AGENT_ID_UPD                   ,
  CPLT_INT_SRC                        ,
  CPLT_INT_REASON                     ,
  CPLT_INT_RESULT                     
)
Select
  Acte.ACTE_ID                                  as ACTE_ID                            ,
  Acte.ORDER_DEPOSIT_DT                         as ORDER_DEPOSIT_DT                   ,
  --Identifiant de l'acte complémentaire
  ActeReforce.ACTE_ID                           as CPLT_ACTE_ID                       ,
  ActeReforce.INT_ID                            as CPLT_EXT_INT_ID                    ,
  ActeReforce.INT_DETL_ID                       as CPLT_EXT_INT_DELT_ID               ,
  ActeReforce.ORG_EDO_ID                        as CPLT_ORG_EDO_ID                    ,
  ActeReforce.ORG_TYPE_EDO                      as CPLT_ORG_TYPE_EDO                  ,
  ActeReforce.ORG_FLAG_PLT_CONV                 as CPLT_ORG_FLAG_PLT_CONV             ,
  ActeReforce.ORG_FLAG_TEAM_MKT                 as CPLT_ORG_FLAG_TEAM_MKT             ,
  ActeReforce.ORG_FLAG_TYPE_CMP                 as CPLT_ORG_FLAG_TYPE_CMP             ,
  ActeReforce.ORG_REM_CHANNEL_CD                as CPLT_ORG_REM_CHANNEL_CD            ,
  ActeReforce.ORG_CHANNEL_CD                    as CPLT_ORG_CHANNEL_CD                ,
  ActeReforce.ORG_SUB_CHANNEL_CD                as CPLT_ORG_SUB_CHANNEL_CD            ,
  ActeReforce.ORG_SUB_SUB_CHANNEL_CD            as CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
  ActeReforce.ORG_GT_ACTIVITY                   as CPLT_ORG_GT_ACTIVITY               ,
  ActeReforce.ORG_FIDELISATION                  as CPLT_ORG_FIDELISATION              ,
  ActeReforce.ORG_WEB_ACTIVITY                  as CPLT_ORG_WEB_ACTIVITY              ,
  ActeReforce.ORG_AUTO_ACTIVITY                 as CPLT_ORG_AUTO_ACTIVITY             ,
  ActeReforce.EXTERNAL_TEAM_CD                  as CPLT_EXTERNAL_TEAM_CD              ,
  ActeReforce.O3_ACTIVE_TEAM_CD                 as CPLT_O3_ACTIVE_TEAM_CD             ,
  ActeReforce.O3_RATTACHEMENT_TEAM_CD           as CPLT_O3_RATTACHEMENT_TEAM_CD       ,
  ActeReforce.AGENT_ID_UPD                      as CPLT_AGENT_ID_UPD                  ,
  ActeReforce.INT_SRC                           as CPLT_INT_SRC                       ,
  ActeReforce.INT_REASON                        as CPLT_INT_REASON                    ,
  ActeReforce.INT_RESULT                        as CPLT_INT_RESULT                    
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_PRECAL Acte
  Inner Join ${KNB_PCO_VM}.V_INT_F_ACTE_HRF ActeReforce
    On  Acte.EXTERNAL_ORDER_ID    = ActeReforce.ID_FACADE
Where
  (1=1)
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order By ActeReforce.LAST_MODIF_TS Desc) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_TRC_AUTO;
.if errorcode <> 0 then .quit 1



.quit 0







