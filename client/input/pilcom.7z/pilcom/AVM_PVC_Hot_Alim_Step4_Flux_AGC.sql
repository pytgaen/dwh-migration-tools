-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_PVC_Hot_Alim_Step4_Flux_AGC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'extraction des actes a traiter
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 07/09/2014     YZH         Création
-- 11/09/2014     YZH         Harmonisation des source_id & Suppression de AGCP
-- 16/09/2014     YZH         Modification sur SALE_CHANNEL_DCL (NULL)
-- 13/10/2014     YZH         Modification-PCM HOT
-- 28/07/2020     EVI         PILCOM-624 : KPI2020 - Alimentation CA Flux à Chaud PVC
---------------------------------------------------------------------------------

.set width 5000

-- AGC MOB
Insert Into ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT
(
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
)
Select
  ActeUni.RUN_ID                                                                            As RUN_ID                         ,
  ActeUni.ACTE_ID                                                                           As ACTE_ID                        ,
  ActeSrc.EXTERNAL_ORDER_ID                                                                 As ACTE_ID_EXTERNE                ,
  Null                                                                                      As ACTE_ID_CONTACTE               ,
  Null                                                                                      As ACTE_ID_DETAIL_CONTACTE        ,
  Null                                                                                      As ACTE_ID_COMMANDE_REFERENCE     ,
  'IODA'                                                                                    As SOURCE_ID                      ,
  1                                                                                         As ACTE_STATUT                    ,
  --A chaud pour AGC on insert que des creation d'acte => 1 
  1                                                                                         As ACTION_ACTE                    ,
  ActeUni.ACT_TS                                                                            As ORDER_DEPOSIT_TS               ,
  Cast(SubString(Cast(ActeSrc.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0))     As ORDER_RECEIVED_PIL_TS          ,
  Cast(
        SubString(Cast(ActeUni.LAST_MODIF_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ORDER_MAJ_PIL_TS               ,
  NULL                                                                                      As ORDER_STATUT                   ,
  NULL                                                                                      As ORDER_STATUT_TS                ,
  ActeUni.AGENT_ID_UPD                                                                      As CUID                           ,
  ActeUni.AGENT_LAST_NAME                                                                   As SELLER_LAST_NAME               ,
  ActeUni.AGENT_FIRST_NAME                                                                  As SELLER_FIRST_NAME              ,
  Null                                                                                      As TEAM_DLC_DES                   ,
  Case When ActeUni.ORG_CHANNEL_CD in ('CCO','SCH') Then Null
       Else Trim(ActeUni.ORG_EDO_ID)
  End                                                                                       As TEAM_ORDER_DES                 ,
  Null                                                                                      As SALE_CHANNEL_DCL               ,
  ActeUni.ORG_REM_CHANNEL_CD                                                                As SALE_CHANNEL_ORDER             ,
  ActeSrc.ORIG_DEM                                                                          As SALE_ORIGINE                   ,
  Coalesce(ActeSrc.PAR_LASTNAME, 'IND')                                                     As CUSTOMER_LAST_NAME             ,
  ActeSrc.PAR_FIRSTNAME                                                                     As CUSTOMER_FIRST_NAME            ,
  Coalesce(ActeUni.MSISDN_ID,'0000000000')                                                  As MISISDN                        ,
  '0000000000'                                                                              As ND                             ,
  Null                                                                                      As NDIP                           ,
  Null                                                                                      As CUSTOMER_PARC                  ,
  Case  --S'il y a un code siret alors c'est un client morale
        When ActeSrc.PAR_SIRET Is Not Null
        Then 'M'
        --Sinon c'est une personne Physique
        Else 'P'
  End                                                                                       As CUSTOMER_TYPE                  ,
  ActeSrc.PAR_MARKET_SEG                                                                    As CUSTOMER_SEG                   ,
  ActeSrc.PAR_SIRET                                                                         As CUSTOMER_SIRET                 ,
  Null                                                                                      As CUSTOMER_CAT                   ,
  Null                                                                                      As CUSTOMER_AGENCE                ,
  ActeUni.POSTAL_CD                                                                         As CUSTOMER_ZIPCODE               ,
  ActeUni.EXTERNAL_PARTY_ID                                                                 As ID_FREGATE                     ,
  ActeSrc.PAR_MOB_IMEI                                                                      As IMEI                           ,
  Null                                                                                      As EAN                            ,
  ActeSrc.PAR_MOB_SIM                                                                       As SIM                            ,
  CASE WHEN TRIM(ActeUni.OSCAR_VALUE) = '-1' THEN NULL
       ELSE ActeUni.OSCAR_VALUE
  END                                                                                       As OSCAR_VALUE                    ,
  Null                                                                                      As DUREE_ENGMENT                  ,
  '1'                                                                                       As VOLUM                          ,
  Null                                                                                      As VAL                            ,
  Case When ActeSrc.ACT_UNITE_CD = '${P_PIL_620}'
     Then Null
     Else TRIM(TD_SYSFNLIB.Oreplace(Cast(ActeUni.ACT_CA_LINE_AM As Varchar(100)),',','.')) 
  End                                                                                       As CA                             ,
  Null                                                                                      As CSO_MOTIF                      ,
  Null                                                                                      As CSO_MOTIF_DES                  ,
  Null                                                                                      As DESCRIPTION                    ,
  ActeUni.ACT_REM_ID                                                                        As ACTE_CODE                      ,
  Null                                                                                      As CODE_TYPE_ORDER                ,
  Null                                                                                      As TYPE_ORDER_INI                 ,
  Null                                                                                      As CODE_TYPE_ORDER_NEW            ,
  Null                                                                                      As TYPE_ORDER_NEW                 ,
  ActeUni.ACT_PRODUCT_ID_PRE                                                                As CODE_PRODUCT_INI               ,
  LibProduitPre.PRODUCT_DS                                                                  As PRODUCT_DSC_INI                ,
  ActeUni.ACT_SEG_COM_ID_PRE                                                                As SEGMENT_COM_INI                ,
  ActeUni.ACT_CODE_MIGR_PRE                                                                 As CODE_MIGR_INI                  ,
  Null                                                                                      As DSC_MIGR_INI                   ,
  ActeUni.ACT_PRODUCT_ID_FINAL                                                              As CODE_PRODUCT_FIN               ,
  LibProduit.PRODUCT_DS                                                                     As PRODUCT_DSC_FIN                ,
  ActeUni.ACT_SEG_COM_ID_FINAL                                                              As SEGMENT_COM_FIN                ,
  ActeUni.ACT_CODE_MIGR_FINAL                                                               As CODE_MIGR_FIN                  ,
  Null                                                                                      As DSC_MIGR_FIN                   ,
  Null                                                                                      As DT_CHECK_PARC                  ,
  Null                                                                                      As DT_END_PARC                    ,
  Null                                                                                      As END_PARC_DSC                   ,
  Null                                                                                      As TAUX_PERENITE                  ,
  Null                                                                                      As CC_PLACEMENT                   ,
  Null                                                                                      As DELAI_PRENEITE                 ,
  Cast(
        SubString(Cast(ActeSrc.QUEUE_TS as Char(22)) From 1 For 19) AS Timestamp(0) 
      )                                                                                     As QUEUE_TS                       ,
  Cast(
        SubString(Cast(ActeSrc.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As STREAMING_TS                   ,
  Cast(
        SubString(Cast(ActeUni.CREATION_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ACT_CREATION_TS                ,
  Current_Timestamp(0)                                                                      As EXT_CREATION_TS                ,
  ActeUni.HOT_IN                                                                            As HOT_IN                         
From
  ${KNB_PCO_TMP}.ACT_T_ACTE_SENT_PVC Delta 
  Inner Join  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ActeUni
    On ActeUni.ACTE_ID  = Delta.ACTE_ID
      And ActeUni.ACT_DT  >= current_date - 20
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_MOB  ActeSrc
    On ActeUni.ACTE_ID = ActeSrc.ACTE_ID
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduit
    On    ActeUni.ACT_PRODUCT_ID_FINAL      = LibProduit.PRODUCT_ID
      And LibProduit.CURRENT_IN             = 1
      And LibProduit.CLOSURE_DT             Is Null  
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduitPre
    On    ActeUni.ACT_PRODUCT_ID_PRE        = LibProduitPre.PRODUCT_ID
      And LibProduitPre.CURRENT_IN          = 1
      And LibProduitPre.CLOSURE_DT          Is Null

;
.if errorcode <> 0 then .quit 1





-- AGC PRP
Insert Into ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT
(
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
)
Select
  ActeUni.RUN_ID                                                                            As RUN_ID                         ,
  ActeUni.ACTE_ID                                                                           As ACTE_ID                        ,
  ActeSrc.EXTERNAL_ORDER_ID                                                                 As ACTE_ID_EXTERNE                ,
  Null                                                                                      As ACTE_ID_CONTACTE               ,
  Null                                                                                      As ACTE_ID_DETAIL_CONTACTE        ,
  Null                                                                                      As ACTE_ID_COMMANDE_REFERENCE     ,
  'IODA'                                                                                    As SOURCE_ID                      ,
  1                                                                                         As ACTE_STATUT                    ,
  --A chaud pour AGC on insert que des creation d'acte => 1 
  1                                                                                         As ACTION_ACTE                    ,
  ActeUni.ACT_TS                                                                            As ORDER_DEPOSIT_TS               ,
  Cast(SubString(Cast(ActeSrc.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0))     As ORDER_RECEIVED_PIL_TS          ,
  Cast(
        SubString(Cast(ActeUni.LAST_MODIF_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ORDER_MAJ_PIL_TS               ,
  NULL                                                                                      As ORDER_STATUT                   ,
  NULL                                                                                      As ORDER_STATUT_TS                ,
  ActeUni.AGENT_ID_UPD                                                                      As CUID                           ,
  ActeUni.AGENT_LAST_NAME                                                                   As SELLER_LAST_NAME               ,
  ActeUni.AGENT_FIRST_NAME                                                                  As SELLER_FIRST_NAME              ,
  Null                                                                                      As TEAM_DLC_DES                   ,
  Case When ActeUni.ORG_CHANNEL_CD in ('CCO','SCH') Then Null
       Else Trim(ActeUni.ORG_EDO_ID)
  End                                                                                       As TEAM_ORDER_DES                 ,
  Null                                                                                      As SALE_CHANNEL_DCL               ,
  ActeUni.ORG_REM_CHANNEL_CD                                                                As SALE_CHANNEL_ORDER             ,
  ActeSrc.ORIG_DEM                                                                          As SALE_ORIGINE                   ,
  Coalesce(ActeSrc.PAR_LASTNAME, 'IND')                                                     As CUSTOMER_LAST_NAME             ,
  ActeSrc.PAR_FIRSTNAME                                                                     As CUSTOMER_FIRST_NAME            ,
  Coalesce(ActeUni.MSISDN_ID,'0000000000')                                                  As MISISDN                        ,
  '0000000000'                                                                              As ND                             ,
  Null                                                                                      As NDIP                           ,
  Null                                                                                      As CUSTOMER_PARC                  ,
  Case  --S'il y a un code siret alors c'est un client morale
        When ActeSrc.PAR_SIRET Is Not Null
        Then 'M'
        --Sinon c'est une personne Physique
        Else 'P'
  End                                                                                       As CUSTOMER_TYPE                  ,

  ActeSrc.PAR_MARKET_SEG                                                                    As CUSTOMER_SEG                   ,
  ActeSrc.PAR_SIRET                                                                         As CUSTOMER_SIRET                 ,
  Null                                                                                      As CUSTOMER_CAT                   ,
  Null                                                                                      As CUSTOMER_AGENCE                ,
  ActeUni.POSTAL_CD                                                                         As CUSTOMER_ZIPCODE               ,
  ActeUni.EXTERNAL_PARTY_ID                                                                 As ID_FREGATE                     ,
  ActeSrc.PAR_MOB_IMEI                                                                      As IMEI                           ,
  Null                                                                                      As EAN                            ,
  ActeSrc.PAR_MOB_SIM                                                                       As SIM                            ,
  CASE WHEN TRIM(ActeUni.OSCAR_VALUE) = '-1' THEN NULL
       ELSE ActeUni.OSCAR_VALUE
  END                                                                                       As OSCAR_VALUE                    ,
  Null                                                                                      As DUREE_ENGMENT                  ,
  '1'                                                                                       As VOLUM                          ,
  Null                                                                                      As VAL                            ,
  Case When ActeSrc.ACT_UNITE_CD = '${P_PIL_620}'
     Then Null
     Else TRIM(TD_SYSFNLIB.Oreplace(Cast(ActeUni.ACT_CA_LINE_AM As Varchar(100)),',','.')) 
  End                                                                                       As CA                             ,
  Null                                                                                      As CSO_MOTIF                      ,
  Null                                                                                      As CSO_MOTIF_DES                  ,
  Null                                                                                      As DESCRIPTION                    ,
  ActeUni.ACT_REM_ID                                                                        As ACTE_CODE                      ,
  Null                                                                                      As CODE_TYPE_ORDER                ,
  Null                                                                                      As TYPE_ORDER_INI                 ,
  Null                                                                                      As CODE_TYPE_ORDER_NEW            ,
  Null                                                                                      As TYPE_ORDER_NEW                 ,
  ActeUni.ACT_PRODUCT_ID_PRE                                                                As CODE_PRODUCT_INI               ,
  LibProduitPre.PRODUCT_DS                                                                  As PRODUCT_DSC_INI                ,
  ActeUni.ACT_SEG_COM_ID_PRE                                                                As SEGMENT_COM_INI                ,
  ActeUni.ACT_CODE_MIGR_PRE                                                                 As CODE_MIGR_INI                  ,
  Null                                                                                      As DSC_MIGR_INI                   ,
  ActeUni.ACT_PRODUCT_ID_FINAL                                                              As CODE_PRODUCT_FIN               ,
  LibProduit.PRODUCT_DS                                                                     As PRODUCT_DSC_FIN                ,
  ActeUni.ACT_SEG_COM_ID_FINAL                                                              As SEGMENT_COM_FIN                ,
  ActeUni.ACT_CODE_MIGR_FINAL                                                               As CODE_MIGR_FIN                  ,
  Null                                                                                      As DSC_MIGR_FIN                   ,
  Null                                                                                      As DT_CHECK_PARC                  ,
  Null                                                                                      As DT_END_PARC                    ,
  Null                                                                                      As END_PARC_DSC                   ,
  Null                                                                                      As TAUX_PERENITE                  ,
  Null                                                                                      As CC_PLACEMENT                   ,
  Null                                                                                      As DELAI_PRENEITE                 ,
  Cast(
        SubString(Cast(ActeSrc.QUEUE_TS as Char(22)) From 1 For 19) AS Timestamp(0)
      )                                                                                     As QUEUE_TS                       ,
  Cast(
        SubString(Cast(ActeSrc.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As STREAMING_TS                   ,
  Cast(
        SubString(Cast(ActeUni.CREATION_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ACT_CREATION_TS                ,
  Current_Timestamp(0)                                                                      As EXT_CREATION_TS                ,
  ActeUni.HOT_IN                                                                            As HOT_IN                         
From
  ${KNB_PCO_TMP}.ACT_T_ACTE_SENT_PVC Delta 
  Inner Join  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ActeUni
    On ActeUni.ACTE_ID  = Delta.ACTE_ID
      And ActeUni.ACT_DT  >= current_date - 20
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_PRP  ActeSrc
    On ActeUni.ACTE_ID = ActeSrc.ACTE_ID
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduit
    On    ActeUni.ACT_PRODUCT_ID_FINAL      = LibProduit.PRODUCT_ID
      And LibProduit.CURRENT_IN             = 1
      And LibProduit.CLOSURE_DT             Is Null  
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduitPre
    On    ActeUni.ACT_PRODUCT_ID_PRE        = LibProduitPre.PRODUCT_ID
      And LibProduitPre.CURRENT_IN          = 1
      And LibProduitPre.CLOSURE_DT          Is Null

;
.if errorcode <> 0 then .quit 1



-- AGC PCM
Insert Into ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT
(
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
)
Select
  ActeUni.RUN_ID                                                                            As RUN_ID                         ,
  ActeUni.ACTE_ID                                                                           As ACTE_ID                        ,
  ActeSrc.EXTERNAL_ORDER_ID                                                                 As ACTE_ID_EXTERNE                ,
  Null                                                                                      As ACTE_ID_CONTACTE               ,
  Null                                                                                      As ACTE_ID_DETAIL_CONTACTE        ,
  Null                                                                                      As ACTE_ID_COMMANDE_REFERENCE     ,
  'IODA'                                                                                    As SOURCE_ID                      ,
  1                                                                                         As ACTE_STATUT                    ,
  --A chaud pour AGC on insert que des creation d'acte => 1 
  1                                                                                         As ACTION_ACTE                    ,
  ActeUni.ACT_TS                                                                            As ORDER_DEPOSIT_TS               ,
  Cast(SubString(Cast(ActeSrc.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0))     As ORDER_RECEIVED_PIL_TS          ,
  Cast(
        SubString(Cast(ActeUni.LAST_MODIF_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ORDER_MAJ_PIL_TS               ,
  NULL                                                                                      As ORDER_STATUT                   ,
  NULL                                                                                      As ORDER_STATUT_TS                ,
  ActeUni.AGENT_ID_UPD                                                                      As CUID                           ,
  ActeUni.AGENT_LAST_NAME                                                                   As SELLER_LAST_NAME               ,
  ActeUni.AGENT_FIRST_NAME                                                                  As SELLER_FIRST_NAME              ,
  Null                                                                                      As TEAM_DLC_DES                   ,
  Case When ActeUni.ORG_CHANNEL_CD in ('CCO','SCH') Then Null
       Else Trim(ActeUni.ORG_EDO_ID)
  End                                                                                       As TEAM_ORDER_DES                 ,
  Null                                                                                      As SALE_CHANNEL_DCL               ,
  ActeUni.ORG_REM_CHANNEL_CD                                                                As SALE_CHANNEL_ORDER             ,
  ActeSrc.ORIG_DEM                                                                          As SALE_ORIGINE                   ,
  Coalesce(ActeSrc.PAR_LASTNAME, 'IND')                                                     As CUSTOMER_LAST_NAME             ,
  ActeSrc.PAR_FIRSTNAME                                                                     As CUSTOMER_FIRST_NAME            ,
  Coalesce(ActeUni.MSISDN_ID,'0000000000')                                                  As MISISDN                        ,
  '0000000000'                                                                              As ND                             ,
  Null                                                                                      As NDIP                           ,
  Null                                                                                      As CUSTOMER_PARC                  ,
  Case  --S'il y a un code siret alors c'est un client morale
        When ActeSrc.PAR_SIRET Is Not Null
        Then 'M'
        --Sinon c'est une personne Physique
        Else 'P'
  End                                                                                       As CUSTOMER_TYPE                  ,

  ActeSrc.PAR_MARKET_SEG                                                                    As CUSTOMER_SEG                   ,
  ActeSrc.PAR_SIRET                                                                         As CUSTOMER_SIRET                 ,
  Null                                                                                      As CUSTOMER_CAT                   ,
  Null                                                                                      As CUSTOMER_AGENCE                ,
  ActeUni.POSTAL_CD                                                                         As CUSTOMER_ZIPCODE               ,
  ActeUni.EXTERNAL_PARTY_ID                                                                 As ID_FREGATE                     ,
  ActeSrc.PAR_MOB_IMEI                                                                      As IMEI                           ,
  Null                                                                                      As EAN                            ,
  ActeSrc.PAR_MOB_SIM                                                                       As SIM                            ,
  CASE WHEN TRIM(ActeUni.OSCAR_VALUE) = '-1' THEN NULL
       ELSE ActeUni.OSCAR_VALUE
  END                                                                                       As OSCAR_VALUE                    ,
  Null                                                                                      As DUREE_ENGMENT                  ,
  '1'                                                                                       As VOLUM                          ,
  Null                                                                                      As VAL                            ,
  Case When ActeSrc.ACT_UNITE_CD = '${P_PIL_620}'
     Then Null
     Else TRIM(TD_SYSFNLIB.Oreplace(Cast(ActeUni.ACT_CA_LINE_AM As Varchar(100)),',','.')) 
  End                                                                                       As CA                             ,
  Null                                                                                      As CSO_MOTIF                      ,
  Null                                                                                      As CSO_MOTIF_DES                  ,
  Null                                                                                      As DESCRIPTION                    ,
  ActeUni.ACT_REM_ID                                                                        As ACTE_CODE                      ,
  Null                                                                                      As CODE_TYPE_ORDER                ,
  Null                                                                                      As TYPE_ORDER_INI                 ,
  Null                                                                                      As CODE_TYPE_ORDER_NEW            ,
  Null                                                                                      As TYPE_ORDER_NEW                 ,
  ActeUni.ACT_PRODUCT_ID_PRE                                                                As CODE_PRODUCT_INI               ,
  LibProduitPre.PRODUCT_DS                                                                  As PRODUCT_DSC_INI                ,
  ActeUni.ACT_SEG_COM_ID_PRE                                                                As SEGMENT_COM_INI                ,
  ActeUni.ACT_CODE_MIGR_PRE                                                                 As CODE_MIGR_INI                  ,
  Null                                                                                      As DSC_MIGR_INI                   ,
  ActeUni.ACT_PRODUCT_ID_FINAL                                                              As CODE_PRODUCT_FIN               ,
  LibProduit.PRODUCT_DS                                                                     As PRODUCT_DSC_FIN                ,
  ActeUni.ACT_SEG_COM_ID_FINAL                                                              As SEGMENT_COM_FIN                ,
  ActeUni.ACT_CODE_MIGR_FINAL                                                               As CODE_MIGR_FIN                  ,
  Null                                                                                      As DSC_MIGR_FIN                   ,
  Null                                                                                      As DT_CHECK_PARC                  ,
  Null                                                                                      As DT_END_PARC                    ,
  Null                                                                                      As END_PARC_DSC                   ,
  Null                                                                                      As TAUX_PERENITE                  ,
  Null                                                                                      As CC_PLACEMENT                   ,
  Null                                                                                      As DELAI_PRENEITE                 ,
  Cast(
        SubString(Cast(ActeSrc.QUEUE_TS as Char(22)) From 1 For 19) AS Timestamp(0)
      )                                                                                     As QUEUE_TS                       ,
  Cast(
        SubString(Cast(ActeSrc.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As STREAMING_TS                   ,
  Cast(
        SubString(Cast(ActeUni.CREATION_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ACT_CREATION_TS                ,
  Current_Timestamp(0)                                                                      As EXT_CREATION_TS                ,
  ActeUni.HOT_IN                                                                            As HOT_IN                         
From
  ${KNB_PCO_TMP}.ACT_T_ACTE_SENT_PVC Delta 
  Inner Join  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ActeUni
    On  ActeUni.ACTE_ID   = Delta.ACTE_ID 
      And ActeUni.ACT_DT  >= current_date - 20
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_PCM  ActeSrc
    On ActeUni.ACTE_ID = ActeSrc.ACTE_ID
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduit
    On    ActeUni.ACT_PRODUCT_ID_FINAL      = LibProduit.PRODUCT_ID
      And LibProduit.CURRENT_IN             = 1
      And LibProduit.CLOSURE_DT             Is Null  
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduitPre
    On    ActeUni.ACT_PRODUCT_ID_PRE        = LibProduitPre.PRODUCT_ID
      And LibProduitPre.CURRENT_IN          = 1
      And LibProduitPre.CLOSURE_DT          Is Null

;
.if errorcode <> 0 then .quit 1
