--$HEADER:   %HEADER% 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CAR_Acte__CalculPerennitePVCSegmentVerifPresParcAvant.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul Perennite PVC-Segment 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/08/2015      AOU          Creation
-- 03/06/2016      MDE          Modif / REFCOM KNB_PCO_REFCOM 
--------------------------------------------------------------------------------

.set width 2500;


Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEEK_SEGPRES All;
.if errorcode <> 0 then .quit 1


-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné pour les offres
-------------------------------------------------------------------------------------------


Create Volatile Table ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_CAR (
  TYPE_PRODUIT          Char(2)         Not Null      ,
  SEG_COM_ID            Varchar(64)     Not Null      ,
  TYPE_SERVICE          Varchar(20)                   ,
  PRODUCT_ID            VARCHAR(50)     NOT NULL      ,
  PERIODE_ID            INTEGER         NOT NULL      ,
  COM_BEGIN_DT          Date Format 'YYYYMMDD'        ,
  COM_END_DT            Date Format 'YYYYMMDD'         
)
Primary Index(
  PRODUCT_ID          ,
  PERIODE_ID
)
On Commit Preserve Rows
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_CAR Column(PRODUCT_ID,PERIODE_ID);
.if ErrorCode <> 0 Then .Quit 1;


Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_ACTE_CAR_SEEK_SGPRES (
  ACTE_ID                   BIGINT                        NOT NULL    ,
  ORD_DEPOSIT_DT            DATE FORMAT 'YYYYMMDD'         NOT NULL   ,
  PAR_IMSI                  VARCHAR(15)                               ,
  PERIODE_ID                INTEGER                      NOT NULL     ,
  SEG_COM_ID_LP             VARCHAR(64)                               ,
  SEG_COM_ID                VARCHAR(64)                               ,
  SEG_COM_ID_PRE            VARCHAR(64)                               ,
  PRODUCT_ID                VARCHAR(50)                               ,
  PRODUCT_ID_PRE            VARCHAR(50)                               ,
  COM_BEGIN_DT              Date Format 'YYYYMMDD'                    ,
  COM_END_DT                Date Format 'YYYYMMDD'                    ,
  COM_BEGIN_DT_PRE          Date Format 'YYYYMMDD'                    ,
  COM_END_DT_PRE            Date Format 'YYYYMMDD'                    ,
  TYPE_SERVICE              VARCHAR(64)                               ,
  TYPE_COMMANDE             CHAR(15)                       NOT NULL   ,
  PRESPARC_IN               CHAR(2)                                   ,
  TYPE_OT_SO                CHAR(3)                                    
)
Primary Index(
  PRODUCT_ID          ,
  PERIODE_ID
)
On Commit Preserve Rows
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_TERADATA_USER}.ORD_V_ACTE_CAR_SEEK_SGPRES Column(PRODUCT_ID,PERIODE_ID);
.if ErrorCode <> 0 Then .Quit 1;


Insert Into ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_CAR
(
  TYPE_PRODUIT          ,
  SEG_COM_ID            ,
  TYPE_SERVICE          ,
  PRODUCT_ID            ,
  PERIODE_ID            ,
  COM_BEGIN_DT          ,
  COM_END_DT             
)
Select
  Case  When ProdAgap.TYPE_PRODUIT = 'OT'
          Then  'OT'
        Else    'SO'
  End                                                                           as TYPE_PRODUIT         ,
  Seg.SEG_COM_ID                                                                as SEG_COM_ID           ,
  Seg.TYPE_SERVICE                                                              as TYPE_SERVICE         ,
  ProdAgap.PRODUCT_ID                                                           as PRODUCT_ID           ,
  ProdAgap.PERIODE_ID                                                           as PERIODE_ID           ,
  Coalesce(ProdAgap.DATE_DEBUT, Cast('19000101' as Date format 'YYYYMMDD'))     as COM_BEGIN_DT         ,
  Coalesce(ProdAgap.DATE_FIN, Cast('29991231' as Date format 'YYYYMMDD'))       as COM_END_DT            
From
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP ProdAgap
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM Seg
    On    ProdAgap.PERIODE_ID     = Seg.PERIODE_ID
      And ProdAgap.PRODUCT_ID     = Seg.PRODUCT_ID
      And Seg.CURRENT_IN          = 1
      And Seg.CLOSURE_DT          Is Null
Where
  (1=1)
  And ProdAgap.CURRENT_IN  = 1
  And ProdAgap.CLOSURE_DT  Is Null
Qualify Row_Number() Over (Partition By
                                        ProdAgap.EXT_PRODUCT_ID1                    ,
                                        Case  When ProdAgap.TYPE_PRODUIT = 'OT'
                                                Then  'OT'
                                              Else    'SO'
                                        End
                            Order by Seg.PERIODE_ID Desc
                          )=1
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On  ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_CAR Column(PERIODE_ID,PRODUCT_ID);
.if ErrorCode <> 0 Then .Quit 1;

Insert into ${KNB_TERADATA_USER}.ORD_V_ACTE_CAR_SEEK_SGPRES
(
  ACTE_ID                 ,
  ORD_DEPOSIT_DT          ,
  PAR_IMSI                ,
  PERIODE_ID              ,
  SEG_COM_ID_LP           ,
  SEG_COM_ID              ,
  SEG_COM_ID_PRE          ,
  PRODUCT_ID              ,
  PRODUCT_ID_PRE          ,
  COM_BEGIN_DT            ,
  COM_END_DT              ,
  COM_BEGIN_DT_PRE        ,
  COM_END_DT_PRE          ,
  TYPE_SERVICE            ,
  TYPE_COMMANDE           ,
  PRESPARC_IN             ,
  TYPE_OT_SO               
)

Select
  T.ACTE_ID                                            as ACTE_ID,
  T.ORD_DEPOSIT_DT                                     as ORD_DEPOSIT_DT,
  T.PAR_IMSI                                           as PAR_IMSI,
  T.PERIODE_ID                                         as PERIODE_ID,
  T.SEG_COM_ID_LP                                      as SEG_COM_ID_LP,
  T.SEG_COM_ID                                         as SEG_COM_ID,
  T.SEG_COM_ID_PRE                                     as SEG_COM_ID_PRE,
  T.PRODUCT_ID_PRE                                     as PRODUCT_ID_PRE,
  T.PRODUCT_ID                                         as PRODUCT_ID,
  T.COM_BEGIN_DT                                       as COM_BEGIN_DT,
  T.COM_END_DT                                         as COM_END_DT,
  T.COM_BEGIN_DT_PRE                                   as COM_BEGIN_DT_PRE,
  T.COM_END_DT_PRE                                     as COM_END_DT_PRE,
  T.TYPE_SERVICE                                       as TYPE_SERVICE,
  T.TYPE_COMMANDE                                      as TYPE_COMMANDE,
  Case When T.SEG_COM_ID_LP = T.SEG_COM_ID_PRE
                                    Then  Case When   T.PRODUCT_ID <> T.PRODUCT_ID_PRE
                                                 Then   Case When   T.COM_BEGIN_DT >= T.COM_BEGIN_DT_PRE
                                                               Then   'N'
                                                             Else   'O'
                                                        End
                                                Else  'O'
                                          End
                                   Else  'N'
  End                                                 as PRESPARC_IN,
  T.TYPE_OT_SO                                        as TYPE_OT_SO 


From
(
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.ORD_DEPOSIT_DT                   as ORD_DEPOSIT_DT         ,
  Acte.PAR_IMSI                         as PAR_IMSI               ,
  Acte.PERIODE_ID                       as PERIODE_ID             ,
  Acte.SEG_COM_ID_LP                    as SEG_COM_ID_LP          ,
  Acte.SEG_COM_ID                       as SEG_COM_ID             ,
  Acte.SEG_COM_ID_PRE                   as SEG_COM_ID_PRE         ,
  Acte.PRODUCT_ID_PRE                   as PRODUCT_ID_PRE         ,
  Acte.PRODUCT_ID                       as PRODUCT_ID             ,
  Coalesce(Seg.COM_BEGIN_DT, Cast('19000101' as Date format 'YYYYMMDD'))                        as COM_BEGIN_DT           ,
  Seg.COM_END_DT                        as COM_END_DT             ,
  Coalesce(Seg2.COM_BEGIN_DT, Cast('19000101' as Date format 'YYYYMMDD'))                     as COM_BEGIN_DT_PRE       ,
  Seg2.COM_END_DT                       as COM_END_DT_PRE         ,
  Acte.TYPE_SERVICE_LP                  as TYPE_SERVICE           ,
  Acte.TYPE_COMMANDE                    as TYPE_COMMANDE          ,
  Null                                  as PRESPARC_IN            ,
  Acte.TYPE_OT_SO                       as TYPE_OT_SO              
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_EXRACT Acte
  Left Outer Join ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_CAR Seg
    On    Acte.PERIODE_ID     = Seg.PERIODE_ID
      And Acte.PRODUCT_ID     = Seg.PRODUCT_ID
  Left Outer Join ${KNB_TERADATA_USER}.CAT_V_PROD_REFCOM_CAR Seg2
    On    Acte.PERIODE_ID     = Seg2.PERIODE_ID
      And Acte.PRODUCT_ID_PRE     = Seg2.PRODUCT_ID
Where
  (1=1)
  --on ne gere que les forfaits
  And Acte.TYPE_SERVICE In ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX')
  --on a enlevé le filtre sur les type de commandes suite à la QC 803
  --On filtre sur le type de commande qui nous intéresse
  --And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID             Not In ('NS','OPTTECH','OPT_INC')
  --And Acte.TYPE_OT_SO             in ('SO')
  And Acte.PAR_IMSI               Is Not Null
) T
;
.if errorcode <> 0 then .quit 1


Collect Stat On  ${KNB_TERADATA_USER}.ORD_V_ACTE_CAR_SEEK_SGPRES Column(PERIODE_ID,PRODUCT_ID);
.if ErrorCode <> 0 Then .Quit 1;


-------------------------------------------------------------------------------------------
--Step 2 : On Selectionne les data pour les joindres dans l référentiel fusionné pour les options
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEEK_SEGPRES
(
  ACTE_ID                 ,
  ORD_DEPOSIT_DT          ,
  PAR_IMSI                ,
  SEG_COM_ID              ,
  TYPE_SERVICE            ,
  TYPE_COMMANDE           ,
  TYPE_OT_SO              
)
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.ORD_DEPOSIT_DT                   as ORD_DEPOSIT_DT         ,
  Acte.PAR_IMSI                         as PAR_IMSI               ,
  Acte.SEG_COM_ID_LP                    as SEG_COM_ID             ,
  Acte.TYPE_SERVICE_LP                  as TYPE_SERVICE           ,
  Acte.TYPE_COMMANDE                    as TYPE_COMMANDE          ,
  Acte.TYPE_OT_SO                       as TYPE_OT_SO             
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_EXRACT Acte
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID             Not In ('NS','OPTTECH','OPT_INC')
  --And Acte.TYPE_OT_SO             in ('SO')
  And Acte.PAR_IMSI               Is Not Null
  --On filtre pour enlevé les segments à exclures :
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_SOC}.V_CAT_R_REF_EXCLUDED_SEEK_SEG SegExclu
    Where
      (1=1)
      And SegExclu.CURRENT_IN   = 1
      And SegExclu.CLOSURE_DT   Is Null
      And SegExclu.SEG_COM_ID   = Acte.SEG_COM_ID
      And SegExclu.PERIODE_ID   = Acte.PERIODE_ID
  )
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEEK_SEGPRES;
.if errorcode <> 0 then .quit 1


-------------------------------------------------------------------------------------------
--Step 3 :  On recherche en parc si le segment était déjà la à J-1
-------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES All;
.if errorcode <> 0 then .quit 1

--Insertion des OT
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES
(
  ACTE_ID                     ,
  ORD_DEPOSIT_DT              
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.ORD_DEPOSIT_DT          as ORDER_DEPOSIT_DT   
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEEK_SEGPRES Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_OT ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  And (Refid.ORD_DEPOSIT_DT - 1) >= ParcSeg.PARC_BEGIN_DT
  And (Refid.ORD_DEPOSIT_DT - 1) <= Coalesce(ParcSeg.PARC_END_DT,Cast('29991231' as Date format 'YYYYMMDD'))
  And Refid.TYPE_OT_SO             in ('OT')


--Insertion des SO
;Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES
(
  ACTE_ID                     ,
  ORD_DEPOSIT_DT              
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.ORD_DEPOSIT_DT          as ORDER_DEPOSIT_DT   
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEEK_SEGPRES Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  And (Refid.ORD_DEPOSIT_DT - 1) >= ParcSeg.PARC_BEGIN_DT
  And (Refid.ORD_DEPOSIT_DT - 1) <= Coalesce(ParcSeg.PARC_END_DT,Cast('29991231' as Date format 'YYYYMMDD'))
  And Refid.TYPE_OT_SO             in ('SO')
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES;
.if errorcode <> 0 then .quit 1


--Insertion des OT pour les offres
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES
(
  ACTE_ID                     ,
  ORD_DEPOSIT_DT
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.ORD_DEPOSIT_DT          as ORDER_DEPOSIT_DT
From
  ${KNB_TERADATA_USER}.ORD_V_ACTE_CAR_SEEK_SGPRES Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_OT ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  And Refid.PRESPARC_IN          ='O'
  --On ne regarde pas si le segment était déjà présent en parc
  --And (Refid.ORD_DEPOSIT_DT - 1) >= ParcSeg.PARC_BEGIN_DT
  --And (Refid.ORD_DEPOSIT_DT - 1) <= Coalesce(ParcSeg.PARC_END_DT,Cast('29991231' as Date format 'YYYYMMDD'))
  And Refid.TYPE_OT_SO            in ('OT')
  And  Not exists (
  select 1
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES t1
  where t1.ACTE_ID=Refid.ACTE_ID
  )
Qualify row_Number () Over (partition by Refid.Acte_ID, Refid.ORD_DEPOSIT_DT Order by ParcSeg.PARC_BEGIN_DT desc , ParcSeg.PARC_END_DT desc )=1

--Insertion des SO  pour les offres
;Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES
(
  ACTE_ID                     ,
  ORD_DEPOSIT_DT
)
Select
  Refid.ACTE_ID                 as ACTE_ID            ,
  Refid.ORD_DEPOSIT_DT          as ORDER_DEPOSIT_DT
From
  ${KNB_TERADATA_USER}.ORD_V_ACTE_CAR_SEEK_SGPRES Refid
  Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO ParcSeg
    On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
      And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
Where
  (1=1)
  And Refid.PRESPARC_IN          ='O'
    --On ne regarde pas si le segment était déjà présent en parc
  --And (Refid.ORD_DEPOSIT_DT - 1) >= ParcSeg.PARC_BEGIN_DT
  --And (Refid.ORD_DEPOSIT_DT - 1) <= Coalesce(ParcSeg.PARC_END_DT,Cast('29991231' as Date format 'YYYYMMDD'))
  And Refid.TYPE_OT_SO             in ('SO')
  And  Not exists (
  select 1
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES t1
  where t1.ACTE_ID=Refid.ACTE_ID
  )
Qualify row_Number () Over (partition by Refid.Acte_ID, Refid.ORD_DEPOSIT_DT Order by ParcSeg.PARC_BEGIN_DT desc , ParcSeg.PARC_END_DT desc )=1
;


.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_SEG_DEJPRES;
.if errorcode <> 0 then .quit 1


.quit 0

