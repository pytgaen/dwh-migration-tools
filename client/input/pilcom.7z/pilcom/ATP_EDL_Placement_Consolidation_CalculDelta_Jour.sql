-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_CalculDelta_Jour.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul Delta palcement EDL
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_EXRACT_EDL all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_EXRACT_EDL
(
  EXTERNAL_ACTE_ID        ,
  EXTERNAL_INT_ID         ,
  TYPE_SOURCE_ID          ,
  INT_DEPOSIT_TS          ,
  INT_DEPOSIT_DT          ,
  OPERATOR_PROVIDER_ID    ,
  RESOLU_ID               ,
  CONCLU_ID               ,
  SSCONCLU_ID             ,
  TYPE_COMMANDE           ,
  PLTF_CO                 ,
  INTRNL_SOURCE_ID        ,
  CONSEIL_XI_CREA         ,
  CONSEIL_XI_RESP         ,
  INT_MODIF_TS            ,
  IN_CLIDOS               ,
  CANALDEM                ,
  INT_REASON_CD           ,
  CLIENT_NU               ,
  DOSSIER_NU              ,
  CLOSURE_DT              
)
Select
  --Génération de la clé de la demande :
  Trim(Demande.DEMANDE_ID)||'S'||Trim(Coalesce(SSConc.SSCONC_CONCLU_ID,'${P_PIL_211}'))       as EXTERNAL_ACTE_ID       ,
  Trim(Demande.DEMANDE_ID)                                                                    as EXTERNAL_INT_ID        ,
  ${IdentifiantTechniqueSource}                                                               as TYPE_SOURCE_ID         ,
  Demande.DEMANDE_DT_CREAT                                                                    as INT_DEPOSIT_TS         ,
  Cast(Demande.DEMANDE_DT_CREAT as date format 'YYYYMMDD')                                    as INT_DEPOSIT_DT         ,
  'COM01'                                                                                     as OPERATOR_PROVIDER_ID   ,
  Demande.DEMANDE_RESOLU_ID                                                                   as RESOLU_ID              ,
  Demande.DEMANDE_CONCLU_ID                                                                   as CONCLU_ID              ,
  Coalesce(SSConc.SSCONC_CONCLU_ID,'${P_PIL_211}')                                            as SSCONCLU_ID            ,
   '${P_PIL_016}'                                                                             as TYPE_COMMANDE          ,
  Demande.DEMANDE_PLTF_CO                                                                     as PLTF_CO                ,
  ${IdSourceInterne}                                                                          as INTRNL_SOURCE_ID       ,
  --Information sur le XI Createur
  Demande.DEMANDE_CONSEIL_XI_CREA                                                             as CONSEIL_XI_CREA        ,
  --Information sur le XI responsable
  Demande.DEMANDE_CONSEIL_XI_RESP                                                             as CONSEIL_XI_RESP        ,
  Demande.DEMANDE_DT_DER_MODIF                                                                as INT_MODIF_TS           ,
  --Type client ou dossier
  Demande.DEMANDE_IN_CLIDOS                                                                   as IN_CLIDOS              ,
  Demande.DEMANDE_CANALDEM_CO                                                                 as CANALDEM               ,
  Resolu.RESOLU_ID_RESOLU_PERE                                                                as INT_REASON_CD          ,
  --Enrichissement Client/Dossier
  Demande.DEMANDE_CLIENT_NU                                                                   as CLIENT_NU              ,
  Demande.DEMANDE_DOSSIER_NU                                                                  as DOSSIER_NU             ,
  Demande.DEMANDE_DT_SUPP                                                                     as CLOSURE_DT             
From
  ${KNB_IBU_SOC}.V_TFDEMANDE Demande
  --Jointure dans les sous-conclusion :
  Inner Join ${KNB_IBU_SOC}.V_TFSSCONC SSConc
    On  Demande.DEMANDE_ID = SSConc.SSCONC_DEMANDE_ID
  Left Outer Join ${KNB_IBU_SOC}.V_TDRESOLU Resolu
    On    Demande.DEMANDE_RESOLU_ID = Resolu.RESOLU_ID
      And Resolu.CURRENT_IN         = 1
      And Resolu.CLOSURE_DT         Is Null
Where
  (1=1)
  --Restriction sur les dates de lastModif
  And (
          Demande.LAST_MODIF_TS > '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
        And
          Demande.LAST_MODIF_TS <= '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'
      )
  --On ne prend que les demandes valorisée :
  And Demande.DEMANDE_CONCLU_ID   is not null
  And Demande.DEMANDE_RESOLU_ID   is not null
  --And SSConc.SSCONC_CONCLU_ID     is not null
  --On filtre les données de EDL
  And Demande.DEMANDE_PLTF_CO   = 'EDEL'
  --On Exlcu de l'extraction certains canaux :
  And Demande.DEMANDE_CANALDEM_CO Not In ('CHO','CHORUS')
  --A Supprimer
  --And Demande.DEMANDE_DT_CREAT >= Cast('2012-01-01 00:00:00' as timestamp(0))

;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_EXRACT_EDL;
.if errorcode <> 0 then .quit 1
.quit 0

