 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_MigrationInternet.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des migrations Internet
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000

Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD (
  ORDER_EXTERNAL_ID         Varchar(20)         Not Null  ,
  IND_PRES_OFF_IN           SmallInt                      ,
  OPER                      Varchar(5)                    ,
  LIB                       Varchar(200)                  
)
Primary Index (
  ORDER_EXTERNAL_ID     
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1



Insert Into ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD
(
  ORDER_EXTERNAL_ID     ,
  IND_PRES_OFF_IN       ,
  OPER                  ,
  LIB                   
)
Select
  Int1.ORDER_EXTERNAL_ID                                                                                                                                  As ORDER_EXTERNAL_ID      ,
  Sum(Case  When Int1.ACT_TYPE_SERVICE_FINAL in ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX','ACCRTC') And Int1.ACT_SEG_COM_ID_FINAL Not In ('NS')
              Then 1
            Else 0
      End)                                                                                                                                                As IND_PRES_OFF_IN        ,
  Max(Case  When Int1.ACT_TYPE_SERVICE_FINAL in ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX','ACCRTC') And Int1.ACT_SEG_COM_ID_FINAL Not In ('NS')
              Then ACT_OPER_ID_FINAL
            Else Null
      End)                                                                                                                                                As OPER                   ,
  Max(Case  When Int1.ACT_TYPE_SERVICE_FINAL in ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX','ACCRTC') And Int1.ACT_SEG_COM_ID_FINAL Not In ('NS')
              Then '( CODE_MIGRA_INITIAL (SEG - SERVICE - PRODUIT)) - ( '
                    ||Int1.ACT_CODE_MIGR_FINAL||' ('||Int1.ACT_SEG_COM_ID_FINAL||' - '||Int1.ACT_TYPE_SERVICE_FINAL||' - '||Int1.ACT_PRODUCT_ID_FINAL
                    ||'))'
              Else Null End)                                                                                                                              As LIB                    
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int1
Where
  (1=1)
  And Int1.ORDER_OPER_ID                = 'MIGRA'
  And Int1.ORDER_DEPOSIT_DT             >= Current_Date - 30
  --Il faut que les migrations soit en dehors de Maintient idientifiant et access
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int3
      Where
        (1=1)
        And Int1.ORDER_EXTERNAL_ID    = Int3.ORDER_EXTERNAL_ID
        And Int3.ORDER_DEPOSIT_DT     >= Current_Date - 30
        And Int3.ACT_PRODUCT_ID_FINAL in (
                                            Select
                                              PRODUCT_ID
                                            From
                                              ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OPENCAT
                                            Where
                                              (1=1)
                                              And CURRENT_IN      =1
                                              And FRESH_IN        =1
                                              And CLOSURE_DT      is null
                                              And COMPST_OFFR_ID  in ('OC50000000008','OC50000000080')
                                              And ATOMIC_OFFR_ID  Is Null
                                              And FUNCTN_ID       Is Null
                                              And FUNCTN_VALUE_ID Is Null
                                              And PERIODE_ID      = (Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
                                          )
    )
  --Il ne faut pas avoir une migration RMV -> ADD de qualifier pour cette commande
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int2
      Where
        (1=1)
        And Int1.ORDER_EXTERNAL_ID            = Int2.ORDER_EXTERNAL_ID
        And Int2.ORDER_DEPOSIT_DT             >= Current_Date - 30
        And Int2.ACT_SEG_COM_ID_PRE           Is Not Null
        And Int2.ACT_OPER_ID_PRE              = 'RMV'
        And Int2.ACT_SEG_COM_ID_FINAL         Is Not Null
        And Int2.ACT_OPER_ID_FINAL            = 'ADD'
        And Int2.ORDER_OPER_ID                = 'MIGRA'
        And Int2.ORDER_DEPOSIT_DT             >= Current_Date - 30
      )
Group by
  Int1.ORDER_EXTERNAL_ID
;
.if errorcode <> 0 Then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD Column(ORDER_EXTERNAL_ID);
.if errorcode <> 0 Then .quit 1

-------------------
--Cas 1 : Aucune offre trouvée dans la commande 
------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  3                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  'Aucune Offre paramétrée pour la migration (Avant/Apres) ; ( '
        ||Coalesce(Trim(Tmp.PREVIOUS_COMPST_OFFR_ID),'')
        ||' - '
        ||Coalesce(Trim(Tmp.PREVIOUS_COMPST_OFFR_DS),'')
        ||' ) > ( '
        ||Coalesce(Trim(Tmp.COMPST_OFFR_ID),'')
        ||' - '
        ||Coalesce(Trim(Tmp.COMPST_OFFR_DS),'')
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Tmp.ORDER_DEPOSIT_DT)                                     As DateMinRecue           ,
  Max(Tmp.ORDER_DEPOSIT_DT)                                     As DateMaxRecue           
From
  (
    Select
      Commande.ORDER_STATUS_CD            as ORDER_STATUS_CD            ,
      Commande.ORDER_DEPOSIT_DT           as ORDER_DEPOSIT_DT           ,
      Commande.PREVIOUS_COMPST_OFFR_ID    as PREVIOUS_COMPST_OFFR_ID    ,
      Commande.PREVIOUS_COMPST_OFFR_DS    as PREVIOUS_COMPST_OFFR_DS    ,
      Commande.COMPST_OFFR_ID             as COMPST_OFFR_ID             ,
      Commande.COMPST_OFFR_DS             as COMPST_OFFR_DS             
    From
      ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD RefId
      Inner Join ${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM Commande
        On    RefId.ORDER_EXTERNAL_ID     = Commande.EXTERNAL_ORDER_ID
    Where
      (1=1)
      And RefId.IND_PRES_OFF_IN       = 0
    Qualify Row_Number() Over (Partition By Commande.EXTERNAL_ORDER_ID Order by Commande.ORDER_STATUS_CD Desc)=1
  )Tmp
Group by  4
;
.if errorcode <> 0 Then .quit 1


-------------------
--Cas 2 : Une Offre trouvée dans la commande
------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  3                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  Case  When Tmp.OPER In ('RMV')
          Then
            'Aucune Offre paramétrée pour la migration Vers la nouvelle Offre (Offre Initiale Trouvée / Offre Finale Non Param) ; ( '
                  ||Coalesce(Trim(Tmp.LIB),'')
                  ||' ) > ( '
                  ||Coalesce(Trim(Tmp.COMPST_OFFR_ID),'')
                  ||' - '
                  ||Coalesce(Trim(Tmp.COMPST_OFFR_DS),'')
                  ||' )'
        Else  
            'Aucune Offre paramétrée pour la migration Depuis l ancienne Offre (Offre Initiale Non Param / Offre Finale Trouvée) ; ( '
                  ||Coalesce(Trim(Tmp.PREVIOUS_COMPST_OFFR_ID),'')
                  ||' - '
                  ||Coalesce(Trim(Tmp.PREVIOUS_COMPST_OFFR_DS),'')
                  ||' ) > ( '
                  ||Coalesce(Trim(Tmp.LIB),'')
                  ||' )'
  End                                                           As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Tmp.ORDER_DEPOSIT_DT)                                     As DateMinRecue           ,
  Max(Tmp.ORDER_DEPOSIT_DT)                                     As DateMaxRecue           
From
  (
    Select
      Commande.ORDER_STATUS_CD            as ORDER_STATUS_CD            ,
      Commande.ORDER_DEPOSIT_DT           as ORDER_DEPOSIT_DT           ,
      Commande.PREVIOUS_COMPST_OFFR_ID    as PREVIOUS_COMPST_OFFR_ID    ,
      Commande.PREVIOUS_COMPST_OFFR_DS    as PREVIOUS_COMPST_OFFR_DS    ,
      Commande.COMPST_OFFR_ID             as COMPST_OFFR_ID             ,
      Commande.COMPST_OFFR_DS             as COMPST_OFFR_DS             ,
      RefId.OPER                          as OPER                       ,
      RefId.LIB                           as LIB                        
    From
      ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD RefId
      Inner Join ${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM Commande
        On    RefId.ORDER_EXTERNAL_ID     = Commande.EXTERNAL_ORDER_ID
    Where
      (1=1)
      And RefId.IND_PRES_OFF_IN       = 1
      And RefId.OPER                  Not In ('INI')
    Qualify Row_Number() Over (Partition By Commande.EXTERNAL_ORDER_ID Order by Commande.ORDER_STATUS_CD Desc)=1
  )Tmp
Group by  4
;
.if errorcode <> 0 Then .quit 1











-------------------
--Cas 3 : Cas des Migration Non Param
------------------

Select
  3                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  'Migration Internet ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
        ||Coalesce(Trim(Sup.ACT_CODE_MIGR_FINAL),'')
        ||' ('||Coalesce(Trim(Sup.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Sup.ACT_PRODUCT_ID_FINAL),'')||')'
        ||' > '
        ||Coalesce(Trim(Ajout.ACT_CODE_MIGR_FINAL),'')
        ||' ('||Coalesce(Trim(Ajout.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Ajout.ACT_PRODUCT_ID_FINAL),'')||')'
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Ajout.ORDER_DEPOSIT_DT)                                   As DateMinRecue           ,
  Max(Ajout.ORDER_DEPOSIT_DT)                                   As DateMaxRecue           
From
  (
    Select
      Int1.ORDER_EXTERNAL_ID          As ORDER_EXTERNAL_ID          ,
      Int1.ORDER_DEPOSIT_DT           As ORDER_DEPOSIT_DT           ,
      Int1.ACT_PRODUCT_ID_FINAL       As ACT_PRODUCT_ID_FINAL       ,
      Int1.ACT_SEG_COM_ID_FINAL       As ACT_SEG_COM_ID_FINAL       ,
      Int1.ACT_CODE_MIGR_FINAL        As ACT_CODE_MIGR_FINAL        ,
      Int1.ACT_TYPE_SERVICE_FINAL     As ACT_TYPE_SERVICE_FINAL     
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int1
      Inner Join ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD RefId
        On    Int1.ORDER_EXTERNAL_ID      = RefId.ORDER_EXTERNAL_ID
    Where
      (1=1)
      And Int1.ACT_TYPE_SERVICE_FINAL   In ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX','ACCRTC')
      And Int1.ACT_SEG_COM_ID_FINAL     Not In ('NS')
      And Int1.ACT_OPER_ID_FINAL        In ('ADD','INI')
      And Int1.ORDER_DEPOSIT_DT         >= Current_Date - 30
    Qualify Row_Number() Over (Partition By Int1.ORDER_EXTERNAL_ID Order by Int1.ACT_TYPE_SERVICE_FINAL Desc, Int1.ACT_OPER_ID_FINAL Asc)=1
  )Ajout
  Inner Join
  (
    Select
      Int1.ORDER_EXTERNAL_ID          As ORDER_EXTERNAL_ID          ,
      Int1.ORDER_DEPOSIT_DT           As ORDER_DEPOSIT_DT           ,
      Int1.ACT_PRODUCT_ID_FINAL       As ACT_PRODUCT_ID_FINAL       ,
      Int1.ACT_SEG_COM_ID_FINAL       As ACT_SEG_COM_ID_FINAL       ,
      Int1.ACT_CODE_MIGR_FINAL        As ACT_CODE_MIGR_FINAL        ,
      Int1.ACT_TYPE_SERVICE_FINAL     As ACT_TYPE_SERVICE_FINAL     
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Int1
      Inner Join ${KNB_TERADATA_USER}.ORD_V_SOFT_COM_BAD RefId
        On    Int1.ORDER_EXTERNAL_ID      = RefId.ORDER_EXTERNAL_ID
    Where
      (1=1)
      And Int1.ACT_TYPE_SERVICE_FINAL   In ('OFFQD','OFFMOB','OFFCONV','OFFCONVINT','OFFINT','OFFFIX','ACCRTC')
      And Int1.ACT_SEG_COM_ID_FINAL     Not In ('NS')
      And Int1.ACT_OPER_ID_FINAL        In ('RMV')
      And Int1.ORDER_DEPOSIT_DT         >= Current_Date - 30
    Qualify Row_Number() Over (Partition By Int1.ORDER_EXTERNAL_ID Order by Int1.ACT_TYPE_SERVICE_FINAL Desc)=1
  )Sup
  On Ajout.ORDER_EXTERNAL_ID = Sup.ORDER_EXTERNAL_ID
Group by  4
;
.if errorcode <> 0 Then .quit 1



-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
