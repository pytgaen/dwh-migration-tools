-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_GEN_Alimentation_CommandePSF_Step1_PSF_RechercheMigrationADSL_Vers_Fibre.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de  recherche de migration de ADSL vers Fibre pour éliminer de notre calcul de pérennité
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 12/09/2014      HFO         CREATION
-- 02/07/2015       GMA         Modification Pour ajouter le Delete Insert En MS
-- 02/07/2015       MDE         Modif : optim ajout filte  ACCES_SERVICE_ID <> -1
--------------------------------------------------------------------------------

.set width 2500;

--Création de la table volatile pour les OC
CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC
(
  ORDR_ID                           BIGINT                                   NOT NULL      ,
  TYPE_ORDR_CD                      VARCHAR(4)                                             ,
  STAT_MVT                          VARCHAR(2)                                             ,
  COMPST_OFFR_ID                    VARCHAR(13)                                            ,
  ORDR_DT                           DATE FORMAT 'YYYY/MM/DD'                               ,
  ACCES_SERVICE_ID                  BIGINT                                                  
)
PRIMARY INDEX  ( ORDR_ID,ACCES_SERVICE_ID )  
ON COMMIT PRESERVE ROWS
;
.if errorcode <> 0 then .quit 1

 CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC2
(
  ORDR_ID                           BIGINT                                   NOT NULL      ,
  TYPE_ORDR_CD                      VARCHAR(4)                                             ,
  STATT_ORDR_CD                     INTEGER                                                 ,
  COMPST_OFFR_ID                    VARCHAR(13)                                            ,
  ORDR_DT                           DATE FORMAT 'YYYY/MM/DD'                               ,
    CREATION_TS         TIMESTAMP(0) ,
    MAJ_ORDR_DT      TIMESTAMP(0) ,
  ACCES_SERVICE_ID                  BIGINT
)
PRIMARY INDEX  (ACCES_SERVICE_ID)
ON COMMIT PRESERVE ROWS
; 


--Table qui contiendra les OC à supprimer des commandes
CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_ACQFIB
(
  ORDR_ID                           BIGINT                                   NOT NULL      ,
  TYPE_ORDR_CD                      VARCHAR(4)                                             ,
  STAT_MVT                          VARCHAR(2)                                             ,
  COMPST_OFFR_ID                    VARCHAR(13)                                            ,
  ORDR_DT                           DATE FORMAT 'YYYY/MM/DD'                               ,
  ACCES_SERVICE_ID                  BIGINT                                                  
)
PRIMARY INDEX ( ACCES_SERVICE_ID ) 
ON COMMIT PRESERVE ROWS
;
.if errorcode <> 0 then .quit 1


--Etape 1 : On recherche les résiliations ADSL
Insert Into ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC
(
  ORDR_ID                 ,
  TYPE_ORDR_CD            ,
  STAT_MVT                ,
  COMPST_OFFR_ID          ,
  ORDR_DT                 ,
  ACCES_SERVICE_ID        
)
Select
  Cmd.ORDR_ID                                                                   As ORDR_ID                ,
  Cmd.TYPE_ORDR_CD                                                              As TYPE_ORDR_CD           ,
  --Calcul du mouvement
  Case  When Cmd.STATT_ORDR_CD In ('6000','3000','2000')
          Then 'O'
        When Cmd.STATT_ORDR_CD In ('500','1000')
          Then 'W'
        When Cmd.STATT_ORDR_CD Is Null
          Then 'W'
        When Cmd.STATT_ORDR_CD In ('9000','1','1200','9500')
          Then 'K'
        Else 'E'
  End                                                                           AS STAT_MVT               ,
  Cmd.COMPST_OFFR_RPS_ID                                                        As COMPST_OFFR_ID         ,
  Cmd.ORDR_DT                                                                   As ORDR_DT                ,
  Cmd.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID        
From 
  ${KNB_COM_SOC}.V_ORD_F_ORDR_BO  Cmd 
Where
  (1=1)
  And Cmd.COMPST_OFFR_RPS_ID                        is not Null
  And Cmd.COMPST_OFFR_RPS_ID                        = 'OC50000000008'
  And Cmd.TYPE_ORDR_CD                              = 'MIG'
  And Cmd.MOTV_ORDR_ID                              = 'RESCL'
  And Cmd.OPERATOR_PROVIDER_ID                      = 'COM03'
  And STAT_MVT                             Not in  ( 'E','K')
Qualify Row_Number() Over(Partition By Cmd.ORDR_ID Order By Cmd.MAJ_ORDR_DT Desc, Cmd.CREATION_TS Desc, STATT_ORDR_CD Desc) = 1 ;

.if errorcode <> 0 then .quit 1


Collect stat ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC column (ACCES_SERVICE_ID) ;
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC column (ORDR_ID) ;

.if errorcode <> 0 then .quit 1


 Insert Into ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC2
(
  ORDR_ID                 ,
  TYPE_ORDR_CD            ,
  STATT_ORDR_CD                ,
  COMPST_OFFR_ID          ,
  ORDR_DT                 ,
  CREATION_TS  ,
  MAJ_ORDR_DT ,
  ACCES_SERVICE_ID
)
Select
  Cmd.ORDR_ID                                                                   As ORDR_ID                ,
  Cmd.TYPE_ORDR_CD                                                              As TYPE_ORDR_CD           ,
  --Calcul du mouvement
  Cmd.STATT_ORDR_CD                                                             AS STATT_ORDR_CD          ,
  Cmd.COMPST_OFFR_RPS_ID                                                        As COMPST_OFFR_ID         ,
  Cmd.ORDR_DT                                                                   As ORDR_DT                ,
  Cmd.CREATION_TS                                                               As CREATION_TS            ,
  Cmd.MAJ_ORDR_DT                                                               As MAJ_ORDR_DT            ,
  Cmd.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID        
From
  ${KNB_COM_SOC}.V_ORD_F_ORDR_BO  Cmd
Where
  (1=1)
  And Cmd.ACCES_SERVICE_ID               <> -1
  And Cmd.TYPE_ORDR_CD                    = 'NEW'
  And Cmd.MOTV_ORDR_ID                    = 'ORDST'
  And Cmd.OPERATOR_PROVIDER_ID            In ( 'COM04','COM01' )
  And   Case  When Cmd.STATT_ORDR_CD In ('6000','3000','2000')
          Then 'O'
        When Cmd.STATT_ORDR_CD In ('500','1000')
          Then 'W'
        When Cmd.STATT_ORDR_CD Is Null
          Then 'W'
        When Cmd.STATT_ORDR_CD In ('9000','1','1200','9500')
          Then 'K'
        Else 'E'
        End                             Not in  ( 'E','K')
Qualify Row_Number() Over(Partition By Cmd.ORDR_ID Order By Cmd.MAJ_ORDR_DT Desc, Cmd.CREATION_TS Desc, STATT_ORDR_CD Desc) = 1 ;

.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC2 column (ACCES_SERVICE_ID) ;

--Etape 2 : On recherche les Commandes d'acquisition de la fibre 


Insert Into ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_ACQFIB
(
  ORDR_ID                           ,
  TYPE_ORDR_CD                      ,
  STAT_MVT                          ,
  COMPST_OFFR_ID                    ,
  ORDR_DT                           ,
  ACCES_SERVICE_ID                  
)

Select
  Cmd1.ORDR_ID                                                                   As ORDR_ID                ,
  Cmd1.TYPE_ORDR_CD                                                              As TYPE_ORDR_CD           ,
  --Calcul du mouvement
  Cmd1.STAT_MVT                                                                  AS STAT_MVT               ,
  Cmd1.COMPST_OFFR_ID                                                            As COMPST_OFFR_ID         ,
  Cmd1.ORDR_DT                                                                   As ORDR_DT                ,
  Cmd1.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID       
From 
 -- ${KNB_COM_SOC}.V_ORD_F_ORDR_BO  Cmd
   ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC2 Cmd
  Inner Join  ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC  Cmd1 
  On    Cmd1.ACCES_SERVICE_ID             = Cmd.ACCES_SERVICE_ID
        And Cmd1.ORDR_DT  -  60           < Cmd.ORDR_DT 
        And Cmd.ORDR_DT                   < Cmd1.ORDR_DT
Where
  (1=1)
  And Cmd.TYPE_ORDR_CD                    = 'NEW'
 -- And Cmd.MOTV_ORDR_ID                    = 'ORDST'
--  And Cmd.OPERATOR_PROVIDER_ID            In ( 'COM04','COM01' )
  And   Case  When Cmd.STATT_ORDR_CD In ('6000','3000','2000')
          Then 'O'
        When Cmd.STATT_ORDR_CD In ('500','1000')
          Then 'W'
        When Cmd.STATT_ORDR_CD Is Null
          Then 'W'
        When Cmd.STATT_ORDR_CD In ('9000','1','1200','9500')
          Then 'K'
        Else 'E'
        End                             Not in  ( 'E','K')
Qualify Row_Number() Over(Partition By Cmd.ORDR_ID Order By Cmd.MAJ_ORDR_DT Desc, Cmd.CREATION_TS Desc, 
Case  When Cmd.STATT_ORDR_CD In ('6000','3000','2000')
          Then 5
        When Cmd.STATT_ORDR_CD In ('500','1000')
          Then 4
        When Cmd.STATT_ORDR_CD Is Null
          Then 3
        When Cmd.STATT_ORDR_CD In ('9000','1','1200','9500')
          Then 2
        Else 1
        End Desc) = 1 ;

.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_ACQFIB column (ACCES_SERVICE_ID) ;

.if errorcode <> 0 then .quit 1



Delete From  ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_RESILADSL
;Insert Into ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_RESILADSL
(
  ORDR_ID                         ,
  ACCES_SERVICE_ID                ,
  ORDR_DT                        
)

select 
  t11.ORDR_ID                                                                      As ORDR_ID              ,
  t11.ACCES_SERVICE_ID                                                             As ACCES_SERVICE_ID     ,
  t11.ORDR_DT                                                                      As ORDR_DT
From
  ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC  t11
  Left Outer Join  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_ACQFIB t2
  On    t11.ACCES_SERVICE_ID          = t2.ACCES_SERVICE_ID
      And t11.ORDR_DT                   = t2.ORDR_DT
Where
  (1=1)
  And t2.ACCES_SERVICE_ID is null
  And t11.ACCES_SERVICE_ID <> -1
;
.if errorcode <> 0 then .quit 1

Collect stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_RESILADSL ;
.if errorcode <> 0 then .quit 1

Delete From  ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC All ;
.if errorcode <> 0 then .quit 1

Delete From  ${KNB_TERADATA_USER}.ORD_V_RESILADSL_ORDR_PCA_OC2 All ;
.if errorcode <> 0 then .quit 1

Delete From  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_ACQFIB All ;
.if errorcode <> 0 then .quit 1

