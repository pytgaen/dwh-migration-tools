--$HEADER:   mm2pco/current/sql/ATP_BES_Miroir_Alimentation_CalculTmpF.sql 13_05#1 20-JUN-2017 15:05:58 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Miroir_Alimentation_CalculTmpE.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de création des Tables BESTAR
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 23/05/2017     HOB         Creation

--------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.CAT_T_BESTAR_USERS All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.CAT_T_BESTAR_USERS
(
  USER_ID                 ,
  CU_ID                   ,
  NOM                     ,
  PRENOM                  ,
  DATE_MODIFICATION       ,
  CREATION_TS             ,
  LAST_MODIF_TS           ,
  FRESH_IN                ,
  COHERENCE_IN            

)
Select 
  Ods.USER_ID                               as USER_ID                 ,
  Ods.CU_ID                                 as CU_ID                   ,
  Ods.NOM                                   as NOM                     ,
  Ods.PRENOM                                as PRENOM                  ,
  Ods.DATE_MODIFICATION                     as DATE_MODIFICATION       ,
  Current_Timestamp(0)                      As CREATION_TS             ,
  Current_Timestamp(0)                      As LAST_MODIF_TS           ,
  1                                         As FRESH_IN                ,
  1                                         As COHERENCE_IN             

From 
  ${KNB_PCO_TMP}.CAT_W_BESTAR_USERS Ods
  
 Where
 (1=1)
 
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.CAT_T_BESTAR_USERS;
.if errorcode <> 0 then .quit 1

.quit 0
