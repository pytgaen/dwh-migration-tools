-- $HEADER:   mm2pco/current/sql/ATP_DPVC_Acte_Alimentation_Step1_PrecalculCatalogueDecla.sql 13_05#7 14-OCT-2019 13:59:55 KPRZ8434
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_DPVC_Acte_Alimentation_Step1_PrecalculCatalogueDecla.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/07/2014      HZO         Creation
-- 07/08/2014      HZO         Modification : Passage sur Refcom (au lieu de Retcom)
-- 02/07/2015      GMA         Modification Pour ajouter le Delete Insert En MS
-- 11/01/2016      MDE         Modification : Evol calcul CA- Alim unite_cd
-- 16/03/2016      MDE         Evol Limitation des periodes
-- 14/10/2019      EVI         Caisse GDT : Remonte PRODUIT_DS
-- 14/10/2019      EVI         KPI2020 : Remonte Champs CA_MARKETING / HUMAINDIGITAL

--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------
--STEP1 : limitation des periodes 
---------------------------------------------------------
       
Create Volatile Table ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM (
  PERIODE_ID               INTEGER                       Not null           ,
  PERIODE_DATE_DEB         DATE FORMAT 'YYYYMMDD'                           ,
  PERIODE_DATE_FIN         DATE FORMAT 'YYYYMMDD'                           ,
  FRESH_IN                 BYTEINT                                          ,
  CURRENT_IN               BYTEINT                                          ,
  CLOSURE_DT               DATE FORMAT 'YYYYMMDD'
)
Primary Index (PERIODE_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

-- Limitation des periodes sur 6 mois

Insert into ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM
(
  PERIODE_ID                   ,
  PERIODE_DATE_DEB             ,
  PERIODE_DATE_FIN             ,
  FRESH_IN                     ,
  CURRENT_IN                   ,
  CLOSURE_DT     
)
Select
  RefPeriod.PERIODE_ID                          As PERIODE_ID             ,
  RefPeriod.PERIODE_DATE_DEB                    As PERIODE_DATE_DEB       ,
  RefPeriod.PERIODE_DATE_FIN                    As PERIODE_DATE_FIN       ,
  RefPeriod.FRESH_IN                            As FRESH_IN               ,
  RefPeriod.CURRENT_IN                          As CURRENT_IN             ,
  RefPeriod.CLOSURE_DT                          As CLOSURE_DT             
  From
  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM RefPeriod
  Where
  (1=1)
    And RefPeriod.FRESH_IN                        = 1
    And RefPeriod.CURRENT_IN                      = 1
    And RefPeriod.CLOSURE_DT                      Is Null
    And RefPeriod.PERIODE_ID >=  (  Select 
                                      min (MinRefPeriod.PERIODE_ID)  
                                    From 
                                    ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM MinRefPeriod
                                    Where
                                       (1=1)
                                         And MinRefPeriod.FRESH_IN                        = 1
                                         And MinRefPeriod.CURRENT_IN                      = 1
                                         And MinRefPeriod.CLOSURE_DT                      Is Null
                                         And ( MinRefPeriod.PERIODE_DATE_FIN  >=  add_months(current_date ,-6) And MinRefPeriod.PERIODE_DATE_DEB  <= add_months(current_date ,-6))
                                 )
;
.if errorcode <> 0 then .quit 1
Collect stat On ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM Column (PERIODE_ID);
.if errorcode <> 0 then .quit 1


---------------------------------------------------------Step 2------------------------------------------------------
--Produits enrichis
---------------------------------------------------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA
;Insert into ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA
(
  PERIODE_ID                ,
  PRODUCT_ID                ,
  PRODUCT_DS                ,
  TYPE_PRODUIT              ,
  SEG_COM_ID                ,
  SEG_COM_AGG_ID            ,
  TYPE_SERVICE              ,
  CODE_MIGRATION            ,
  TARIF_HT                  ,
  START_COMM_DT             ,
  END_COMM_DT               
)
select
  RefProduit.PERIODE_ID                                                                    as PERIODE_ID                  ,
  RefProduit.PRODUCT_ID                                                                    as PRODUCT_ID                  ,
  RefProduit.PRODUCT_DS                                                                    as PRODUCT_DS                  ,
  RefProduit.TYPE_PRODUIT                                                                  as TYPE_PRODUIT                ,
  RefSegCom.SEG_COM_ID                                                                     as SEG_COM_ID                  ,
  Coalesce(RefSegType.SEG_COM_AGG_ID          ,'CODECAT INCONNU')                          as SEG_COM_AGG_ID              ,
  RefSegCom.TYPE_SERVICE                                                                   as TYPE_SERVICE                ,
  Coalesce(RefCat.CODE_MIGRATION              ,'CODEMIGRAINCO')                            as CODE_MIGRATION              ,
  Coalesce(RefProduit.TARIF_HT                ,0)                                          as TARIF_HT                    ,
  RefProduit.DATE_DEBUT                                                                    as START_COMM_DT               ,
  RefProduit.DATE_FIN                                                                      as END_COMM_DT                 
from 
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_DECLA RefProduit
    Inner Join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      RefPeriod.PERIODE_ID            = RefProduit.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
      On    RefProduit.PRODUCT_ID           = RefSegCom.PRODUCT_ID
        And RefProduit.PERIODE_ID           = RefSegCom.PERIODE_ID
        And RefSegCom.CURRENT_IN            = 1
        And RefSegCom.CLOSURE_DT            is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSegType
      On    RefSegCom.SEG_COM_ID              = RefSegType.SEG_COM_ID
        And RefSegCom.PERIODE_ID              = RefSegType.PERIODE_ID
        And RefSegType.FRESH_IN               = 1
        And RefSegType.CURRENT_IN             = 1
        And RefSegType.CLOSURE_DT             is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCat
      On    RefSegCom.SEG_COM_ID              = RefCat.SEG_COM_ID
        And RefSegCom.PERIODE_ID              = RefCat.PERIODE_ID
        And RefCat.CURRENT_IN                 = 1
        And RefCat.CLOSURE_DT                 is null
where ( 1                             = 1 )
      And RefProduit.CURRENT_IN       = 1
      And RefProduit.FRESH_IN         = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA;
.if errorcode <> 0 then .quit 1

---------------------------------------------------------Step 3------------------------------------------------------
--Matrice complète déclaratif (Produit Pre --> Produit final
---------------------------------------------------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA
;Insert Into ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA
(
  PERIODE_ID                ,
  ACTE_REM_ID               ,
  PRODUCT_ID_PRE            ,
  SEG_COM_ID_PRE            ,
  SEG_COM_AGG_ID_PRE        ,
  CODE_MIGR_PRE             ,
  OPER_ID_PRE               ,
  PRODUCT_ID_FINAL          ,
  PRODUCT_DS_FINAL          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  CODE_MIGR_FINAL           ,
  OPER_ID_FINAL             ,
  TYPE_SERVICE_FINAL        ,
  TYPE_COMMANDE_ID          ,
  ACT_CD                    ,
  FLAG_ACT_REM              ,
  FLAG_PEC_PERPVC           ,
  ACTE_VALO                 ,
  ACTE_FAMILLE_KPI          ,
  KPI_ID                    ,
  TAUX_MARGE                ,
  UNITE_CD                  ,
  CA_MARKETING              ,
  HUMAINDIGITAL  
)
Select
  Mat.PERIODE_ID                                                                  as PERIODE_ID                       ,
  Mat.ACTE_REM_ID                                                                 as ACTE_REM_ID                      ,
  Mat.PRODUCT_ID_INI                                                              as PRODUCT_ID_PRE                   ,
  PrdIni.SEG_COM_ID                                                               as SEG_COM_ID_PRE                   ,
  PrdIni.SEG_COM_AGG_ID                                                           as SEG_COM_AGG_ID_PRE               ,
  PrdIni.CODE_MIGRATION                                                           as CODE_MIGR_PRE                    ,
  Case  when Mat.PRODUCT_ID_INI = 'ND'
      Then 
          Null
      Else 
          'RMV'
  End                                                                             as OPER_ID_PRE                      ,
  Mat.PRODUCT_ID_FINAL                                                            as PRODUCT_ID_FINAL                 ,
  PrdFin.PRODUCT_DS                                                               as PRODUCT_DS_FINAL                 ,
  PrdFin.SEG_COM_ID                                                               as SEG_COM_ID_FINAL                 ,
  Coalesce(PrdFin.SEG_COM_AGG_ID          ,'CODECAT INCONNU')                     as SEG_COM_AGG_ID_FINAL             ,
  PrdFin.CODE_MIGRATION                                                           as CODE_MIGR_FINAL                  ,
  'ADD'                                                                           as OPER_ID_FINAL                    ,
  PrdFin.TYPE_SERVICE                                                             as TYPE_SERVICE_FINAL               ,
  Mat.TYPE_COMMANDE_ID                                                            as TYPE_COMMANDE_ID                 ,
  Mat.ACTE_ID                                                                     as ACT_CD                           ,
  MatActePil.FLAG_ACT_REM                                                         as FLAG_ACT_REM                     ,
  MatActePil.FLAG_PEC_PERPVC                                                      as FLAG_PEC_PERPVC                  ,
  MatActePil.ACTE_VALO                                                            as ACTE_VALO                        ,
  MatActePil.ACTE_FAMILLE_KPI                                                     as ACTE_FAMILLE_KPI                 ,
  Kpi.KPI_ID                                                                      as KPI_ID                           ,
  MatActePil.TAUX_MARGE                                                           as TAUX_MARGE                       ,
  MatActePil.UNITE_CD                                                             as UNITE_CD                         ,
  MatActePil.CA_MARKETING                                                         as CA_MARKETING                     ,
  Kpi.HUMAINDIGITAL                                                               as HUMAINDIGITAL  
From
  ${KNB_PCO_REFCOM}.V_CAT_R_MAT_DECLA Mat
   Inner Join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      RefPeriod.PERIODE_ID      = Mat.PERIODE_ID
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA PrdIni
    On Mat.PERIODE_ID                 = PrdIni.PERIODE_ID
      And Mat.PRODUCT_ID_INI          = PrdIni.PRODUCT_ID
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_JOUR_DECLA PrdFin
    On Mat.PERIODE_ID                 = PrdFin.PERIODE_ID
      And Mat.PRODUCT_ID_FINAL        = PrdFin.PRODUCT_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM MatActePil
    On Mat.PERIODE_ID                 = MatActePil.PERIODE_ID
      And Mat.ACTE_ID                 = MatActePil.ACTE_ID
      And MatActePil.FRESH_IN         = 1
      And MatActePil.CURRENT_IN       = 1
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM Kpi
    On Mat.PERIODE_ID                 = Kpi.PERIODE_ID
      And MatActePil.ACTE_FAMILLE_KPI = Kpi.FAMILLE_KPI_ID
      And Kpi.CURRENT_IN              = 1
      And Kpi.FRESH_IN                = 1
Where (1                              = 1)
  And Mat.CURRENT_IN                  = 1
  And Mat.FRESH_IN                    = 1
  --And Mat.COHERENCE_IN                = 1  
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA;
.if errorcode <> 0 then .quit 1

.quit 0


