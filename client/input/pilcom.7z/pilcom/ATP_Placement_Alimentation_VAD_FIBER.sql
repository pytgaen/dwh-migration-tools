--$HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_Placement_Alimentation_VAD_FIBER.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de Creation des tables TMP de VAD
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 04/06/2014      OCH         Creation
--------------------------------------------------------------------------------
Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_FIBER all;
.if errorcode <> 0 then .quit 1
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_FIBER
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  DMC_LINE_ID                ,
  FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.DATE_SAISIE                               as INT_DEPOSIT_DT             ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  FIBER.FIBER_IN                                  as FIBER_IN            
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_DMC_VAD RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
  Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.DATE_SAISIE Order by FIBER.START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_FIBER;
.if errorcode <> 0 then .quit 1
