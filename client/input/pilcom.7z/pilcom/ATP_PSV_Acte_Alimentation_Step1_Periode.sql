-- $HEADER: mm2pco/current/sql/ATP_PSV_Acte_Alimentation_Step1_Periode.sql 13_05#3 13-JUN-2017 16:54:48 GXPZ7694
--------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_PSV_Acte_Alimentation_Step1_Periode.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 13/04/2017      HOB         Creation

--------------------------------------------------------------------------------

.set width 2500;

---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des placements
--et réorganisation pour pouvoir jointer dans la table des catalogues
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_PSV_C_EXT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_PSV_C_EXT
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  EDO_ID                    ,
  TYPE_PRODUCT              ,
  ORDR_TYP_CD               ,
  EXT_OPER_ID               ,
  CODE_EAN                  ,
  EXTRNL_OPSRV_DS           ,
  PERIODE_ID                
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.EDO_ID                                                as EDO_ID                     ,
  Null                                                            as TYPE_PRODUCT               ,
  Placement.ORDR_TYP_CD                                           as ORDR_TYP_CD                ,
  'REA'                                                           as EXT_OPER_ID                ,
  Placement.EAN_CD                                                as CODE_EAN                   ,
  Placement.EXTRNL_OPSRV_DS                                       as EXTRNL_OPSRV_DS            ,
  --Période
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )          as PERIODE_ID                 
From
   ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_PSV Placement
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
Where
  (1=1)
  And  Placement.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_524})
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_PSV_C_EXT;
.if errorcode <> 0 then .quit 1

.quit 0

