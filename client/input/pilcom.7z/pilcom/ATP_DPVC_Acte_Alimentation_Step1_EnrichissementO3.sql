-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_DPVC_Acte_Alimentation_Step1_EnrichissementO3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/07/2014      HZO         Creation
-- 20/10/2014      HZO         Evolution declaratif CCO (Ajout du flag canal_Macro)
-- 16/12/2014      HZO         QC 663 : Canal Macro pour les SC (Nouvelle RG)
-- 02/03/2016      TPI         QC 1072 : Modification paramètres
--------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_ACTE_DPVC_O3 All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ACT_W_ACTE_DPVC_O3
(
  ACTE_ID                           ,
  ORDER_DEPOSIT_DT                  ,
  TEAM_ORDER_DES                    ,
  TYPE_EDO                          ,
  CHANNEL_CD                        ,
  FLAG_PLT_CONV                     ,
  FLAG_PLT_SCH                      ,
  FLAG_TYPE_GEO                     ,
  FLAG_TYPE_CPT_NTK                 ,
  NETWRK_TYP_EDO_ID                 
)
  Select
    RefId.ACTE_ID                                                                         as ACTE_ID              ,
    RefId.ORDER_DEPOSIT_DT                                                                as ORDER_DEPOSIT_DT     ,
    Cast(RefID.TEAM_ORDER_DES as Bigint)                                                  as TEAM_ORDER_DES       ,
    Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT' 
            Then  'INT'
          Else    'EXT'
    End                                                                                   as TYPE_EDO             ,
    Case when RefEdoAD.EDO_ID is not null
            Then  'Dist'
          Else
            Case when RefEdoConv.EDO_ID is not null
                Then 'CCO'
              else 
                Case when RefEdoAVSC.EDO_ID is not null
                      Then  'SCH'
                    Else 'CCO'
                End
            End
    End                                                                                   as CHANNEL_CD           ,
    Case
          When RefEdoConv.EDO_ID Is Not Null
            Then  1
          Else    0
    End                                                                                   as  FLAG_PLT_CONV       ,
    Case  When RefEdoAVSC.EDO_ID Is Not Null
            Then  1
          Else    0
    End                                                                                   as FLAG_PLT_SCH         ,
    RefEdoDOM.AXS_CLSSF_ID                                                                as FLAG_TYPE_GEO        ,
    RefEdoCompNetwork.AXS_CLSSF_ID                                                        as FLAG_TYPE_CPT_NTK    ,
    RefEdo.NETWRK_TYP_EDO_ID                                                              as NETWRK_TYP_EDO_ID    
  From
   ${KNB_PCO_TMP}.ACT_T_PLACEMENT_DECLAR_PVC RefID
   Inner join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
      On  RefEdo.EDO_ID         = Cast(RefID.TEAM_ORDER_DES as Bigint)
      And RefEdo.CURRENT_IN     = 1
  Left Outer Join
  (
    --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
    Select
      EDO_ID
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
      And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110})
      And EdoAx.FRESH_IN          = 1
      And EdoAx.CURRENT_IN        = 1
      And EdoAx.CLOSURE_DT        Is Null
    Group By
    EDO_ID
  ) RefEdoConv
  On  RefEdo.EDO_ID   = RefEdoConv.EDO_ID
      --On va dans le referentiel axs_edo pour remonter les CARAIBES et REUNION
  Left Outer Join
  (
    Select
      EDO_ID                          As EDO_ID             ,
      VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111})
        And EdoAx.FRESH_IN              = 1
        And EdoAx.CURRENT_IN            = 1
        And EdoAx.CLOSURE_DT            Is Null
    Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
  ) RefEdoDOM
      On  Cast(RefID.TEAM_ORDER_DES as Bigint)   = RefEdoDOM.EDO_ID
  --On va dans le referentiel axs_edo pour remonter les GSS et GSA
  Left Outer Join
  (
    Select
        EDO_ID                          As EDO_ID             ,
        VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
      And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112})
      And EdoAx.FRESH_IN              = 1
      And EdoAx.CURRENT_IN            = 1
      And EdoAx.CLOSURE_DT            Is Null
    Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
    ) RefEdoCompNetwork
    On  Cast(RefID.TEAM_ORDER_DES as Bigint)   = RefEdoCompNetwork.EDO_ID
  Left Outer Join
  (
    --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
    Select
      EDO_ID
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
      And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) 
      And EdoAx.FRESH_IN          = 1
      And EdoAx.CURRENT_IN        = 1
      And EdoAx.CLOSURE_DT        Is Null
    Group By
      EDO_ID
  ) RefEdoAVSC
  On  RefEdo.EDO_ID             = RefEdoAVSC.EDO_ID
   --On applique ici la sous- requete qui permet de savoir si l'EDO appartient est AD ou non (canal Dist)
  Left Outer Join
  (     
    Select
      EDO_ID
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
      And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_114}) 
      And EdoAx.FRESH_IN          = 1
      And EdoAx.CURRENT_IN        = 1
      And EdoAx.CLOSURE_DT        Is Null
    Group By
      EDO_ID
  ) RefEdoAD
  On  RefEdo.EDO_ID             = RefEdoAD.EDO_ID
Where
  (1=1)
Qualify Row_Number() Over(Partition by RefId.ACTE_ID Order By RefId.ORDER_DEPOSIT_DT Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ACT_W_ACTE_DPVC_O3;
.if errorcode <> 0 then .quit 1


