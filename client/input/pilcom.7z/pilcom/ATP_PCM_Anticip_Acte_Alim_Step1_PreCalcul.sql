-- $HEADER:   mm2pco/current/sql/ATP_PCM_Anticip_Acte_Alim_Step1_PreCalcul.sql 13_05#5 22-JAN-2018 16:38:49 KRQJ9961
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCM_Anticip_Acte_Alim_Step1_PreCalcul.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_KC
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     CDR         Création
-- 19/03/2013     XKN         Modification de la jointure avec PERIODE (inner --> Left) afin de tracer les erreurs PERIODE_ID inocnnues
-- 09/04/2014     AID         Indus
-- 05/08/2015     HLA         Modification transformatino en acte Ean
-- 28/12/2017     MEL         Evol Placement EAN
---------------------------------------------------------------------------------

.set width 2000;

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_KC 
-- **************************************************************

Delete from ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
(
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  SEGMENTVALEURCLIENT       ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        
)
Select
  CalculTypePCM.ACTE_ID                      as ACTE_ID                    ,
  CalculTypePCM.DATESAISIEBCR                as DATESAISIEBCR              ,
  CalculTypePCM.SEGMENTVALEURCLIENT          as SEGMENTVALEURCLIENT        ,
  CalculTypePCM.EXT_PRODUCT_ID               as EXT_PRODUCT_ID             ,
  CalculTypePCM.PERIODE_ID                   as PERIODE_ID                 ,
  Coalesce(CalculTypePCM.PRODUCT_ID,'${P_PIL_223}')             as PRODUCT_ID                 ,
  CalculTypePCM.SEG_COM_ID                   as SEG_COM_ID                 ,
  CalculTypePCM.TYPE_SERVICE                 as TYPE_SERVICE               ,
  CalculTypePCM.SEG_COM_AGG_ID_FINAL         as SEG_COM_AGG_ID             ,
  CalculTypePCM.CODE_MIGR_FINAL              as CODE_MIGRATION             ,
  CalculTypePCM.MIGRATION_REGROUPEMENT_ID    as MIGRATION_REGROUPEMENT_ID  ,
  CalculTypePCM.MIGRATION_POSSIBLE           as MIGRATION_POSSIBLE         
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATESAISIEBCR                                           as DATESAISIEBCR        ,
      --On Privilégie s'il y a un cashBack
      TmpCalc.TYPE_PCM                                                as EXT_PRODUCT_ID       ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      TypeEAN.PRODUCT_ID                                              as PRODUCT_ID           ,
      TypeEAN.SEG_COM_ID                                              as SEG_COM_ID           ,
      TypeEAN.TYPE_SERVICE                                            as TYPE_SERVICE         ,
      TypeEAN.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID_FINAL ,
      TypeEAN.CODE_MIGRATION                                          as CODE_MIGR_FINAL      ,
      TypeEAN.MIGRATION_REGROUPEMENT_ID                               as MIGRATION_REGROUPEMENT_ID ,
      TypeEAN.MIGRATION_POSSIBLE                                      as MIGRATION_POSSIBLE      
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                   ,
          Placement.DATESAISIEBCR                   as DATESAISIEBCR             ,
          Case  When    Placement.ID_PROGRAMMEFID='${P_PIL_089}' --Cas d'un PCM ORM
                     Then  'ORM'
                Else       'PCM'
          End                                       as TYPE_PCM                   ,
          Placement.SEGMENTVALEURCLIENT             as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          cast(trim(Placement.REFARTICLE )  as varchar(13))                      as REFARTICLE                 
        From
          ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_A Placement
          Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
            On    Placement.DATESAISIEBCR     >= Period.PERIODE_DATE_DEB
              And Placement.DATESAISIEBCR     <= Period.PERIODE_DATE_FIN
              And Period.FRESH_IN             = 1
              And Period.CURRENT_IN           = 1
              And Period.CLOSURE_DT           Is Null
        Where 
         (1=1)
         And Placement.DATESAISIEBCR >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
      )TmpCalc
           --Jointure pour récupérer les code EAN
      Inner Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN TypeEAN
        On      TmpCalc.REFARTICLE                  = TypeEAN.CODE_EAN
          And   TmpCalc.PERIODE_ID                  = TypeEAN.PERIODE_ID
    Where
      (1=1)
  )CalculTypePCM
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1 
--new2
Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
(
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  SEGMENTVALEURCLIENT       ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        
)
Select
  CalculTypePCM.ACTE_ID                      as ACTE_ID                    ,
  CalculTypePCM.DATESAISIEBCR                as DATESAISIEBCR              ,
  CalculTypePCM.SEGMENTVALEURCLIENT          as SEGMENTVALEURCLIENT        ,
  CalculTypePCM.EXT_PRODUCT_ID               as EXT_PRODUCT_ID             ,
  CalculTypePCM.PERIODE_ID                   as PERIODE_ID                 ,
  Coalesce(CalculTypePCM.PRODUCT_ID,'${P_PIL_223}')             as PRODUCT_ID                 ,
  CalculTypePCM.SEG_COM_ID                   as SEG_COM_ID                 ,
  CalculTypePCM.TYPE_SERVICE                 as TYPE_SERVICE               ,
  CalculTypePCM.SEG_COM_AGG_ID_FINAL         as SEG_COM_AGG_ID             ,
  CalculTypePCM.CODE_MIGR_FINAL              as CODE_MIGRATION             ,
  CalculTypePCM.MIGRATION_REGROUPEMENT_ID    as MIGRATION_REGROUPEMENT_ID  ,
  CalculTypePCM.MIGRATION_POSSIBLE           as MIGRATION_POSSIBLE         
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATESAISIEBCR                                           as DATESAISIEBCR        ,
      --On Privilégie s'il y a un cashBack
      TmpCalc.TYPE_PCM                                                as EXT_PRODUCT_ID       ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      TypeEAN.PRODUCT_ID                                              as PRODUCT_ID           ,
      TypeEAN.SEG_COM_ID                                              as SEG_COM_ID           ,
      TypeEAN.TYPE_SERVICE                                            as TYPE_SERVICE         ,
      TypeEAN.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID_FINAL ,
      TypeEAN.CODE_MIGRATION                                          as CODE_MIGR_FINAL      ,
      TypeEAN.MIGRATION_REGROUPEMENT_ID                               as MIGRATION_REGROUPEMENT_ID ,
      TypeEAN.MIGRATION_POSSIBLE                                      as MIGRATION_POSSIBLE      
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                   ,
          Placement.DATESAISIEBCR                   as DATESAISIEBCR             ,
          Case  When    Placement.ID_PROGRAMMEFID='${P_PIL_089}' --Cas d'un PCM ORM
                  Then  'ORM'
                Else    'PCM'
          End                                       as TYPE_PCM                   ,
          Placement.SEGMENTVALEURCLIENT             as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          cast(trim(Placement.REFARTICLE )  as varchar(13))                      as REFARTICLE                 
        From
          ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_A Placement
          Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
            On    Placement.DATESAISIEBCR     >= Period.PERIODE_DATE_DEB
              And Placement.DATESAISIEBCR     <= Period.PERIODE_DATE_FIN
              And Period.FRESH_IN             = 1
              And Period.CURRENT_IN           = 1
              And Period.CLOSURE_DT           Is Null
        Where 
         (1=1)
         And Placement.DATESAISIEBCR >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
      )TmpCalc
      --Jointure pour récupérer EAN
      Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB TypeEAN
       On    Case  When TmpCalc.TYPE_PCM = 'ORM'
                        Then 'PP_0000003'
                        Else 'PP_0000004'
             End                                = TypeEAN.PRODUCT_ID
         And TmpCalc.PERIODE_ID                 = TypeEAN.PERIODE_ID
    Where 
      (1=1)
      And Not Exists
      (
        Select
         1
        From
          ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM RefId
        Where
          (1=1)
          And TmpCalc.ACTE_ID           = RefId.ACTE_ID
          And TmpCalc.DATESAISIEBCR     = RefId.DATESAISIEBCR
      )
  )CalculTypePCM
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1 
