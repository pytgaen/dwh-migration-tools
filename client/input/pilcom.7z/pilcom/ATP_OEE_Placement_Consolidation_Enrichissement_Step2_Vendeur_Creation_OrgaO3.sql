-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Placement_Consolidation_Enrichissement_Step2_Vendeur_Creation_OrgaO3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrichissement Orga O3
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
-- 02/03/2016      TPI         QC 1072 : Modification paramètres
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3 all;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------
-- Implémentation des RGs sur la recherche du XI associé au code vendeur
-- On recherche Ici le conseiller ayant réaliser la vente
-------------------------------------------------------------------

--Creation de la table volatile
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_OEE_O3 (
  ACTE_ID                   Bigint                      Not Null    ,
  INT_DEPOSIT_DT            Date Format 'YYYYMMDD'      Not Null    ,
  ORG_REF_TRAV              CHAR(7)                     Not Null    ,
  ORG_GROUPE_ID             VARCHAR(15)                             ,
  PRIORITY                  ByteInt                     Not Null
)
Primary Index (
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_OEE_O3 Column(ACTE_ID);
.if errorcode <> 0 then .quit 1

-- Récupération des ORG_GROUPE_ID nécessaire à la récupération du EDO_ID
Insert Into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_OEE_O3
(
      ACTE_ID,       
      INT_DEPOSIT_DT,
      ORG_REF_TRAV,
      ORG_GROUPE_ID, 
      PRIORITY      
)
SELECT 
      ACTE_ID                   ,
      INT_DEPOSIT_DT            ,
      ORG_REF_TRAV              ,
      ORG_GROUPE_ID             ,
      PRIORITY
FROM
(
  SELECT
      ACTE_ID                      AS ACTE_ID,
      INT_DEPOSIT_DT               AS INT_DEPOSIT_DT,
      ORG_REF_TRAV                 AS ORG_REF_TRAV,
      ORG_GROUPE_ID                AS ORG_GROUPE_ID,
      1                            AS PRIORITY
  FROM
    ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR
  UNION ALL
  SELECT
      ACTE_ID                      AS ACTE_ID,
      INT_DEPOSIT_DT               AS INT_DEPOSIT_DT,
      ORG_REF_TRAV                 AS ORG_REF_TRAV,
      ORG_GROUPE_ID                AS ORG_GROUPE_ID,
      2                            AS PRIORITY
  FROM
    ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 
  WHERE
    (1=1)
    AND ORG_GROUPE_ID IS NOT NULL  
) AS A
QUALIFY ROW_NUMBER() OVER(PARTITION BY ACTE_ID ORDER BY PRIORITY ASC)=1
;
.if errorcode <> 0 then .quit 1

--Collecte des stats
Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_OEE_O3 Column(ACTE_ID);
.if errorcode <> 0 then .quit 1

-- Récupération de l'EDO_ID nécessaire à l'enrichissement O3

-----------------
-- RG : POC_SC --
-----------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
From
  ${KNB_TERADATA_USER}.INT_V_PLACEMENT_OEE_O3 RefId
  Inner Join
    (
      Select
        RefPdv.EDO_ID                                                                         as EDO_ID               ,
        RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
        RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   as TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
              Else    0
        End                                                                                   as FLAG_PLT_CONV        ,
        Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                                                   as FLAG_PLT_SCH         ,
        Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
        Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
        Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT             
      From
        ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO RefPdv
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoAVSC
        On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
          --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
        Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
          On    RefPdv.EDO_ID         = RefEdo.EDO_ID
            And RefEdo.CURRENT_IN     = 1
            And RefEdo.CLOSURE_DT     Is Null
      Where
        (1=1)
        And RefPdv.EXTNL_COD_CD = 'REGARDSC'
        And RefPdv.CURRENT_IN   = 1
        And RefPdv.CLOSURE_DT   Is Null
    )RefO3
    On    RefId.ORG_GROUPE_ID     =   RefO3.EXTNL_VAL_COD_CD
      And RefId.INT_DEPOSIT_DT    >=  RefO3.START_EXTNL_VAL_DT
      And RefId.INT_DEPOSIT_DT    <=  Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
      And RefId.INT_DEPOSIT_DT    >=  RefO3.OPEN_DT
      And RefId.INT_DEPOSIT_DT    <=  RefO3.CLOSE_DT
Where
  (1=1)
  And RefId.ORG_REF_TRAV    = 'POCSC'
  And RefId.ORG_GROUPE_ID   Is Not Null
  --Calcul pendant 200 jours
  --And RefId.EDO_ID          Is Null
Qualify Row_Number() Over(Partition by
                                        RefId.ACTE_ID,
                                        RefId.INT_DEPOSIT_DT
                          Order by      
                                        RefO3.START_EXTNL_VAL_DT Desc,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1
;
.if errorcode <> 0 then .quit 1


--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3;
.if errorcode <> 0 then .quit 1

------------------
-- RG : OEEEDEL --
------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
) 
SELECT
  RefId.ACTE_ID                     AS ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              AS INT_DEPOSIT_DT       ,
  RefId.ORG_GROUPE_ID               AS ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      AS EDO_ID               ,
  RefO3.FLAG_PLT_CONV               AS FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                AS FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    AS TYPE_EDO
FROM
  ${KNB_TERADATA_USER}.INT_V_PLACEMENT_OEE_O3 RefId
  INNER JOIN
    (
      SELECT
        RefEdo.EDO_ID                                                                         AS EDO_ID               ,
        Conv.ORG_GROUPE_ID                                                                    AS ORG_GROUPE_ID        ,
        RefEdo.START_DT                                                                       AS START_DT             ,
        COALESCE(RefEdo.CLOSE_DT,CURRENT_DATE)                                                AS CLOSE_DT             ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   AS TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        CASE  WHEN RefEdoConv.EDO_ID IS NOT NULL
                THEN  1 --Si on trouve une correspondance alors c'est un plateau convergent
              ELSE    0
        END                                                                                   AS FLAG_PLT_CONV        ,
        CASE  WHEN RefEdoAVSC.EDO_ID IS NOT NULL
                THEN  1
              ELSE    0
        END                                                                                   AS FLAG_PLT_SCH         

      FROM ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
               
      INNER JOIN ${KNB_PCO_SOC}.ORG_R_TRANS_CONSEIL_O3 Conv
          ON RefEdo.EDO_ID = Conv.EDO_ID
             AND Conv.CURRENT_IN     = 1
             AND Conv.CLOSURE_DT     IS NULL
             
        LEFT OUTER JOIN
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        ON  RefEdo.EDO_ID   = RefEdoConv.EDO_ID
        LEFT OUTER JOIN
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
         SELECT
            EDO_ID
          FROM
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          WHERE
            (1=1)
            AND EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            AND EdoAx.FRESH_IN          = 1
            AND EdoAx.CURRENT_IN        = 1
            AND EdoAx.CLOSURE_DT        IS NULL
          GROUP BY
            EDO_ID
        ) RefEdoAVSC
        ON  RefEdo.EDO_ID   = RefEdoAVSC.EDO_ID
        
      WHERE
        (1=1)
        AND RefEdo.CURRENT_IN   = 1
        AND RefEdo.CLOSURE_DT   IS NULL
    )RefO3
    ON    RefId.ORG_GROUPE_ID    = RefO3.ORG_GROUPE_ID
      AND RefId.INT_DEPOSIT_DT >= RefO3.START_DT
      AND RefId.INT_DEPOSIT_DT <=  RefO3.CLOSE_DT
WHERE
  (1=1)
  AND RefId.ORG_REF_TRAV    = 'OEEEDEL'
QUALIFY ROW_NUMBER() OVER(PARTITION BY RefId.ACTE_ID, RefId.INT_DEPOSIT_DT ORDER BY RefO3.START_DT DESC, RefO3.CLOSE_DT DESC)=1
;
.if errorcode <> 0 then .quit 1


--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3;
.if errorcode <> 0 then .quit 1



--Recherche du INT/EXT
Update RefId
From
  (
    Select
      RefVend.ACTE_ID                             as ACTE_ID              ,
      RefVend.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT       ,
      Case  When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                      OrgWork.WORK_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_2_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_3_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_4_TYPE_EDO ='${P_PIL_236}'
                  )
              Then '${P_PIL_236}'
              Else '${P_PIL_235}'
      End                                         as TYPE_EDO             
    From
      ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3 RefVend
      Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL OrgWork
        On    RefVend.EDO_ID                      =   OrgWork.WORK_TEAM_LEVEL_1_CD
          And RefVend.INT_DEPOSIT_DT              >=  OrgWork.WORK_TEAM_LEVEL_1_START_DT
          And RefVend.INT_DEPOSIT_DT              <=  OrgWork.WORK_TEAM_LEVEL_1_END_DT
          And RefVend.INT_DEPOSIT_DT              >=  OrgWork.WORK_TEAM_LEVEL_2_START_DT
          And RefVend.INT_DEPOSIT_DT              <=  OrgWork.WORK_TEAM_LEVEL_2_END_DT
          And RefVend.INT_DEPOSIT_DT              >=  OrgWork.WORK_TEAM_LEVEL_3_START_DT
          And RefVend.INT_DEPOSIT_DT              <=  OrgWork.WORK_TEAM_LEVEL_3_END_DT
          And RefVend.INT_DEPOSIT_DT              >=  OrgWork.WORK_TEAM_LEVEL_4_START_DT
          And RefVend.INT_DEPOSIT_DT              <=  OrgWork.WORK_TEAM_LEVEL_4_END_DT
    Qualify Row_Number() Over (Partition by RefVend.ACTE_ID Order by  OrgWork.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_CD Desc
                              )=1
  )RefEnri,
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3 RefId
Set
  TYPE_EDO= RefEnri.TYPE_EDO
Where
  (1=1)
  And RefId.ACTE_ID               = RefEnri.ACTE_ID
  And RefId.INT_DEPOSIT_DT        = RefEnri.INT_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1


--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_O3;
.if errorcode <> 0 then .quit 1

.quit 0
