-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Cold_Alimentation_Step3_ClientDossier_Resiliation.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/09/2015      MDE         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_CLIDOSSRES all;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Creation de la table Volatile pour stocker le temporaire :
----------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES (
  ACTE_ID               Bigint                  Not null  ,
  ORDER_DEPOSIT_DT      Date Format 'YYYYMMDD'  Not null  ,
  CLIENT_NU             Char(10)                          ,
  DOSSIER_NU            Char(10)                          ,
  DATE_ACTIV_DOS        Date Format 'YYYYMMDD'            ,
  DATE_RESIL_DOS        Date Format 'YYYYMMDD'            ,
  CO_RESILDOS           Varchar(5)                        ,
  DOSSIER_MOTIF_RESIL   Varchar(32)                       
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(ORDER_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
--On va récupéré ensuite le statut du Dossier du Client Poussé par la source
----------------------------------------------------------------------------
Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES
(
  ACTE_ID               ,
  ORDER_DEPOSIT_DT      ,
  CLIENT_NU             ,
  DOSSIER_NU            ,
  DATE_ACTIV_DOS        ,
  DATE_RESIL_DOS        ,
  CO_RESILDOS           ,
  DOSSIER_MOTIF_RESIL   
)
Select
  Tmp.ACTE_ID                                                             as ACTE_ID                ,
  Tmp.ORDER_DEPOSIT_DT                                                    as ORDER_DEPOSIT_DT         ,
  Tmp.CLIENT_NU                                                           as CLIENT_NU              ,
  Tmp.DOSSIER_NU                                                          as DOSSIER_NU             ,
  Tmp.DATE_ACTIV_DOS                                                      as DATE_ACTIV_DOS         ,
  Tmp.DATE_RESIL_DOS                                                      as DATE_RESIL_DOS         ,
  Tmp.CO_RESILDOS                                                         as CO_RESILDOS            ,
  Tmp.DOSSIER_MOTIF_RESIL                                                 as DOSSIER_MOTIF_RESIL    
From
  (
      Select
        RefId.ACTE_ID                                                             as ACTE_ID                ,
        RefId.ORDER_DEPOSIT_DT                                                    as ORDER_DEPOSIT_DT         ,
        RefId.CLIENT_NU                                                           as CLIENT_NU              ,
        RefId.DOSSIER_NU                                                          as DOSSIER_NU             ,
        Cast(DossierCli.DOSSIER_DT_CREAT as Date Format 'YYYYMMDD')               as DATE_ACTIV_DOS         ,
        Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
                --Si le dossier est cloturé alors on prend la date de résil
                Then Coalesce(Cast(DossierCli.DOSSIER_DT_RESIL as Date Format 'YYYYMMDD'),DossierCli.DOSSIER_DT_DER_CHGT)
              Else
                --Sinon on prend rien
                Null
        End                                                                       as DATE_RESIL_DOS         ,
        Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
                --Si le dossier est cloturé alors on prend la date de résil
                Then DossierCli.DOSSIER_CO_RESILDOS
              Else
                --Sinon on prend rien
                Null
        End                                                                       as CO_RESILDOS           ,
        Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
                --Si le dossier est cloturé alors on prend le Motif de Résil
                Then DossierCli.DOSSIER_LL_MOTRESIL --Varchar(32)
              Else
                --Sinon on prend rien
                Null
        End                                                                       as DOSSIER_MOTIF_RESIL  ,
        1                                                                         as PRIORITE             
      From
        ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_CLIENT RefId
        Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER DossierCli
          On    RefId.DOSSIER_NU        = DossierCli.DOSSIER_NU
            And RefId.CLIENT_NU         = DossierCli.DOSSIER_CLIENT_NU
    Union All
      Select
        RefId.ACTE_ID                                                             as ACTE_ID                ,
        RefId.ORDER_DEPOSIT_DT                                                    as ORDER_DEPOSIT_DT         ,
        RefId.CLIENT_NU                                                           as CLIENT_NU              ,
        RefId.DOSSIER_NU                                                          as DOSSIER_NU             ,
        Cast(DossierCli.DOSSIER_DT_CREAT as Date Format 'YYYYMMDD')               as DATE_ACTIV_DOS         ,
        Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
                --Si le dossier est cloturé alors on prend la date de résil
                Then Coalesce(Cast(DossierCli.DOSSIER_DT_RESIL as Date Format 'YYYYMMDD'),DossierCli.DOSSIER_DT_DER_CHGT)
              Else
                --Sinon on prend rien
                Null
        End                                                                       as DATE_RESIL_DOS         ,
        Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
                --Si le dossier est cloturé alors on prend la date de résil
                Then DossierCli.DOSSIER_CO_RESILDOS
              Else
                --Sinon on prend rien
                Null
        End                                                                       as CO_RESILDOS           ,
        Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
                --Si le dossier est cloturé alors on prend le Motif de Résil
                Then DossierCli.DOSSIER_LL_MOTRESIL --Varchar(32)
              Else
                --Sinon on prend rien
                Null
        End                                                                       as DOSSIER_MOTIF_RESIL  ,
        2                                                                         as PRIORITE             
      From
        ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1 RefId
        Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER DossierCli
          On    RefId.DOSSIER_NU        = DossierCli.DOSSIER_NU
            And RefId.CLIENT_NU         = DossierCli.DOSSIER_CLIENT_NU
  )Tmp
Qualify Row_Number() Over (Partition by Tmp.ACTE_ID Order by Tmp.PRIORITE asc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES Column(CLIENT_NU);
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES Column(DOSSIER_NU);
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------
-- Creation de la table Volatile pour stocker le temporaire :
----------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRCLIENT(
  ACTE_ID               Bigint                  Not null  ,
  ORDER_DEPOSIT_DT      Date Format 'YYYYMMDD'  Not null  ,
  DOSSIER_NU            Char(10)                          ,
  CLIENT_NU_NEW_PORTE   Char(10)                          ,
  CLIENT_NU             Char(10)                          ,
  DATE_ACTIV_DOS        Date Format 'YYYYMMDD'            ,
  DATE_RESIL_DOS        Date Format 'YYYYMMDD'            ,
  CO_RESILDOS           Varchar(5)                        ,
  DOSSIER_MOTIF_RESIL   Varchar(32)                       
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(ORDER_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRDOSS(
  ACTE_ID               Bigint                  Not null  ,
  ORDER_DEPOSIT_DT     Date Format 'YYYYMMDD'  Not null  ,
  CLIENT_NU             Char(10)                          ,
  DOSSIER_NU_NEW_PORTE  Char(10)                          ,
  DOSSIER_NU            Char(10)                          ,
  DATE_ACTIV_DOS        Date Format 'YYYYMMDD'            ,
  DATE_RESIL_DOS        Date Format 'YYYYMMDD'            ,
  CO_RESILDOS           Varchar(5)                        ,
  DOSSIER_MOTIF_RESIL   Varchar(32)                       
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(ORDER_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
---- On s'occupe ensuite des Dossiers Dont le client a été transféré :
----------------------------------------------------------------------------
Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRCLIENT
(
  ACTE_ID               ,
  ORDER_DEPOSIT_DT      ,
  DOSSIER_NU            ,
  CLIENT_NU_NEW_PORTE   ,
  CLIENT_NU             ,
  DATE_ACTIV_DOS        ,
  DATE_RESIL_DOS        ,
  CO_RESILDOS           ,
  DOSSIER_MOTIF_RESIL   
)
Select
  Tmp.ACTE_ID                                                         as ACTE_ID                ,
  Tmp.ORDER_DEPOSIT_DT                                                as ORDER_DEPOSIT_DT       ,
  Tmp.DOSSIER_NU                                                      as DOSSIER_NU             ,
  Tmp.CLIENT_NU_NEW_PORTE                                             as CLIENT_NU_NEW_PORTE    ,
  Tmp.CLIENT_NU                                                       as CLIENT_NU              ,
  Tmp.DATE_ACTIV_DOS                                                  as DATE_ACTIV_DOS         ,
  Tmp.DATE_RESIL_DOS                                                  as DATE_RESIL_DOS         ,
  Tmp.CO_RESILDOS                                                     as CO_RESILDOS            ,
  Tmp.DOSSIER_MOTIF_RESIL                                             as DOSSIER_MOTIF_RESIL    
From
  (
    Select
      RefDossier.ACTE_ID                                                        as ACTE_ID                ,
      RefDossier.ORDER_DEPOSIT_DT                                                 as ORDER_DEPOSIT_DT         ,
      --Numéro de dossier
      RefDossier.DOSSIER_NU                                                     as DOSSIER_NU             ,
      -- Si l'on trouve un dossier actif alors on rattache le Dossier à son nouveau Client
      DossierCli.DOSSIER_CLIENT_NU                                              as CLIENT_NU_NEW_PORTE    ,
      -- On passe l'ancien Client dans le numéro client porté
      RefDossier.CLIENT_NU                                                      as CLIENT_NU              ,
      RefDossier.DATE_ACTIV_DOS                                                 as DATE_ACTIV_DOS         ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then Coalesce(Cast(DossierCli.DOSSIER_DT_RESIL as Date Format 'YYYYMMDD'),DossierCli.DOSSIER_DT_DER_CHGT)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DATE_RESIL_DOS         ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then DossierCli.DOSSIER_CO_RESILDOS
            Else
              --Sinon on prend rien
              Null
      End                                                                       as CO_RESILDOS           ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend le Motif de Résil
              Then DossierCli.DOSSIER_LL_MOTRESIL --Varchar(32)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DOSSIER_MOTIF_RESIL  ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90,99999)
              --On priorise les dossier actif
              Then  0
            Else
                    1
      End                                                                       as PRIORITY             ,
      DossierCli.CLOSURE_DT                                                     as CLOSURE_DT           
    From
      ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES RefDossier
      Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER DossierCli
        On    RefDossier.DOSSIER_NU     = DossierCli.DOSSIER_NU
          And RefDossier.DATE_RESIL_DOS = Cast(DossierCli.DOSSIER_DT_CREAT as Date Format 'YYYYMMDD')
          --Restriction : Il faut que le Dossier Soit Actif
          --And DossierCli.DOSSIER_CO_STD Not in (60,70,90,99999)
    Where
      (1=1)
      And RefDossier.DATE_RESIL_DOS             Is Not Null
      And RefDossier.CO_RESILDOS                = 'TRDOS'
      And Coalesce(RefDossier.CLIENT_NU,'-1')  <>  Coalesce(DossierCli.DOSSIER_CLIENT_NU,'-1')
  )Tmp
Qualify Row_Number() Over (Partition By Tmp.ACTE_ID
                                      Order by  Tmp.CLOSURE_DT  asc,
                                                Tmp.PRIORITY    desc,
                                                --On prend le dossier Actif en prio (DOSSIER_CO_RESILDOS Null)
                                                Coalesce(Cast('9999-12-31 23:59:59' as timestamp(0)),Tmp.DATE_RESIL_DOS) desc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRCLIENT Column(ACTE_ID);
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
---- On s'occupe ensuite des Clients dont le numéro à été porté
----------------------------------------------------------------------------
Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRDOSS
(
  ACTE_ID               ,
  ORDER_DEPOSIT_DT      ,
  CLIENT_NU             ,
  DOSSIER_NU_NEW_PORTE  ,
  DOSSIER_NU            ,
  DATE_ACTIV_DOS        ,
  DATE_RESIL_DOS        ,
  CO_RESILDOS           ,
  DOSSIER_MOTIF_RESIL   
)
Select
  Tmp.ACTE_ID                                                         as ACTE_ID                ,
  Tmp.ORDER_DEPOSIT_DT                                                as ORDER_DEPOSIT_DT       ,
  Tmp.CLIENT_NU                                                       as CLIENT_NU              ,
  -- Si l'on trouve un dossier actif alors on rattache le client à son nouveau dossier
  Tmp.DOSSIER_NU_NEW_PORTE                                            as DOSSIER_NU_NEW_PORTE   ,
  -- On passe l'ancien dossier dans le numéro porté
  Tmp.DOSSIER_NU                                                      as DOSSIER_NU             ,
  Tmp.DATE_ACTIV_DOS                                                  as DATE_ACTIV_DOS         ,
  Tmp.DATE_RESIL_DOS                                                  as DATE_RESIL_DOS         ,
  Tmp.CO_RESILDOS                                                     as CO_RESILDOS            ,
  Tmp.DOSSIER_MOTIF_RESIL                                             as DOSSIER_MOTIF_RESIL    
From
  (
    Select
      RefDossier.ACTE_ID                                                        as ACTE_ID                ,
      RefDossier.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT       ,
      RefDossier.CLIENT_NU                                                      as CLIENT_NU              ,
      -- Si l'on trouve un dossier actif alors on rattache le client à son nouveau dossier
      DossierCli.DOSSIER_NU                                                     as DOSSIER_NU_NEW_PORTE   ,
      -- On passe l'ancien dossier dans le numéro porté
      RefDossier.DOSSIER_NU                                                     as DOSSIER_NU             ,
      RefDossier.DATE_ACTIV_DOS                                                 as DATE_ACTIV_DOS         ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then Coalesce(Cast(DossierCli.DOSSIER_DT_RESIL as Date Format 'YYYYMMDD'),DossierCli.DOSSIER_DT_DER_CHGT)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DATE_RESIL_DOS         ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend la date de résil
              Then DossierCli.DOSSIER_CO_RESILDOS
            Else
              --Sinon on prend rien
              Null
      End                                                                       as CO_RESILDOS           ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
              --Si le dossier est cloturé alors on prend le Motif de Résil
              Then DossierCli.DOSSIER_LL_MOTRESIL --Varchar(32)
            Else
              --Sinon on prend rien
              Null
      End                                                                       as DOSSIER_MOTIF_RESIL  ,
      Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90,99999)
              --On priorise les dossier actif
              Then  0
            Else
                    1
      End                                                                       as PRIORITY             ,
      DossierCli.CLOSURE_DT                                                     as CLOSURE_DT           
    From
      ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES RefDossier
      Inner Join ${KNB_IBU_SOC_V}.VF_TDDOSSIER DossierCli
        On    RefDossier.CLIENT_NU      = DossierCli.DOSSIER_CLIENT_NU
          --Dans le cas du portage de numéro la date d'activation du Dossier Reste la meme
          And RefDossier.DATE_ACTIV_DOS = Cast(DossierCli.DOSSIER_DT_CREAT as Date Format 'YYYYMMDD') 
          --Restriction : Il faut que le Dossier Soit Actif
          --And DossierCli.DOSSIER_CO_STD Not in (60,70,90,99999)
    Where
      (1=1)
      And RefDossier.DATE_RESIL_DOS Is Not Null
      And RefDossier.CO_RESILDOS ='CHAPP'
      And Coalesce(RefDossier.DOSSIER_NU,'-1')  <>  Coalesce(DossierCli.DOSSIER_NU,'-1')
  )Tmp
Qualify Row_Number() Over (Partition By Tmp.ACTE_ID
                                      Order by  Tmp.CLOSURE_DT  asc,
                                                Tmp.PRIORITY    desc,
                                                --On prend le dossier Actif en prio (DOSSIER_CO_RESILDOS Null)
                                                Coalesce(Cast('9999-12-31 23:59:59' as timestamp(0)),Tmp.DATE_RESIL_DOS) desc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRDOSS Column(ACTE_ID);
.if errorcode <> 0 then .quit 1


--Fusion et Insertion dans la table Finale
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_CLIDOSSRES
(
  ACTE_ID               ,
  ORDER_DEPOSIT_DT        ,
  CLIENT_NU             ,
  CLIENT_NU_NEW_PORTE   ,
  DOSSIER_NU            ,
  DOSSIER_NU_NEW_PORTE  ,
  DOSSIER_DATE_ACTIV    ,
  DOSSIER_DATE_RESIL    ,
  DOSSIER_TYPE_RESIL    ,
  DOSSIER_MOTIF_RESIL   
)
Select
  RefId.ACTE_ID                                                                                             as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                                                                                      as ORDER_DEPOSIT_DT             ,
  --Si le client a été transféré on met le nouveau client
  Coalesce(TransClient.CLIENT_NU,RefId.CLIENT_NU)                                                           as CLIENT_NU                  ,
  TransClient.CLIENT_NU_NEW_PORTE                                                                           as CLIENT_NU_NEW_PORTE        ,
  --Si le Dossier a été transféré on met le nouveau Dossier
  Coalesce(TransDossier.DOSSIER_NU,RefId.DOSSIER_NU)                                                        as DOSSIER_NU                 ,
  TransDossier.DOSSIER_NU_NEW_PORTE                                                                         as DOSSIER_NU_NEW_PORTE       ,
  RefId.DATE_ACTIV_DOS                                                                                      as DOSSIER_DATE_ACTIV         ,
  --On ne valorise que le champs de Resiliation lorsque qu'il n'y a pas eu de portabilité client / Dossier
  Case  When TransDossier.ACTE_ID Is not Null Or TransClient.ACTE_ID Is not Null
          Then  Coalesce(TransDossier.DATE_RESIL_DOS,TransClient.DATE_RESIL_DOS)
        Else    RefId.DATE_RESIL_DOS
  End                                                                                                       as DOSSIER_DATE_RESIL         ,
  Case  When TransDossier.ACTE_ID Is not Null Or TransClient.ACTE_ID Is not Null
          Then  Coalesce(TransDossier.CO_RESILDOS,TransClient.CO_RESILDOS)
        Else  RefId.CO_RESILDOS
  End                                                                                                       as DOSSIER_TYPE_RESIL         ,
  Case  When TransDossier.ACTE_ID Is not Null Or TransClient.ACTE_ID Is not Null
          Then  Coalesce(TransDossier.DOSSIER_MOTIF_RESIL,TransClient.DOSSIER_MOTIF_RESIL)
        Else     RefId.DOSSIER_MOTIF_RESIL
  End                                                                                                       as DOSSIER_MOTIF_RESIL        
From
  ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_CLIDOSSRES RefId
  Left Outer Join ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRCLIENT TransClient
    On    RefId.ACTE_ID         = TransClient.ACTE_ID
      And RefId.ORDER_DEPOSIT_DT  = TransClient.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_TERADATA_USER}.INT_V_PLACEMENT_BES_TRDOSS TransDossier
    On    RefId.ACTE_ID         = TransDossier.ACTE_ID
      And RefId.ORDER_DEPOSIT_DT  = TransDossier.ORDER_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1


Collect Stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_CLIDOSSRES;
.if errorcode <> 0 then .quit 1


.quit 0

