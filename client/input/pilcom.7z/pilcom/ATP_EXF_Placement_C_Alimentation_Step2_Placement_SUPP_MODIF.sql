-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_EXF_Placement_C_Alimentation_Step2_Placement_SUPP_MODIF.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de creation et mise à jour des placements 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/06/2014      OCH         Creation
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL 
Where TYPE_MOVEMENT_CD Not In ('CREA');
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP  SUPP                                           ----
----------------------------------------------------------------------------------------------
Update RefId
From
  (
    Select
      Src.ACTE_ID                             AS ACTE_ID                ,
      Src.COMMENT_DS                          AS COMMENT_DS             ,
      Src.AGENT_ID                            AS AGENT_ID               ,
      Src.EDO_ID                              AS EDO_ID                 ,
      Src.TYPE_MOVEMENT_CD                    As TYPE_MOVEMENT_CD       ,
      Src.INJECTION_TS                        As INJECTION_TS           ,
      Src.ACT_REM_ID                          As ACT_REM_ID
    From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP  Src
    Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_EXF Act
    On Src.ACTE_ID = Act.ACTE_ID
    Where Act.INTRNL_SOURCE_ID = 12
  )RefEnri,
   ${KNB_PCO_SOC}.ACT_F_PLACEMENT_EXF RefId
Set
    COMMENT_DS        =  RefEnri.COMMENT_DS       ,
    TYPE_MOVEMENT_CD  =  RefEnri.TYPE_MOVEMENT_CD ,
    CLOSURE_DT        =  Case When RefEnri.TYPE_MOVEMENT_CD IN ('SUPP') then  Current_Timestamp(0)
                               Else Null 
                         End
Where
  (1=1)
  And RefEnri.ACTE_ID Is Not Null  
  And RefId.ACTE_ID   = RefEnri.ACTE_ID
  And Not Exists (Select 1  
                   From  ${KNB_PCO_SOC}.V_ACT_F_ACT_EXF_REJ REJ
                   Where RefEnri.ACTE_ID = Rej.ACTE_ID
                   And   RefEnri.INJECTION_TS =  Rej.INJECTION_TS )
;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Mise a jour de latable de placement a partir de   MODIF                      ----
----------------------------------------------------------------------------------------------
Update RefId
From
  (
    Select
      Pl.EXTERNAL_ACTE_ID                     As  EXTERNAL_ACTE_ID         ,
      Pl.ORDER_DEPOSIT_TS                     As  ORDER_DEPOSIT_TS         ,
      Pl.LAST_NAME_CUSTOMER_NM                As  LAST_NAME_CUSTOMER_NM    ,
      Pl.FIRST_NAME_CUSTOMER_NM               As  FIRST_NAME_CUSTOMER_NM   ,
      Pl.MISISDN_ID                           As  MISISDN_ID               ,
      Pl.ND_ID                                As  ND_ID                    ,
      Pl.NDIP_ID                              As  NDIP_ID                  ,
      Src.ACTE_ID                             AS ACTE_ID                   ,
      Src.COMMENT_DS                          AS COMMENT_DS                ,
      Src.AGENT_ID                            AS AGENT_ID                  ,
      Src.EDO_ID                              AS EDO_ID                    ,
      Src.TYPE_MOVEMENT_CD                    As TYPE_MOVEMENT_CD          ,
      Src.INJECTION_TS                        As INJECTION_TS              ,
      Src.ACT_REM_ID                          As ACT_REM_ID
    From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF Src
    Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_EXF Act
    On Src.ACTE_ID = Act.ACTE_ID
    Inner Join ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF Pl
    On Src.ACTE_ID = Pl.ACTE_ID
    Where Act.INTRNL_SOURCE_ID = 12
  )RefEnri,
   ${KNB_PCO_SOC}.ACT_F_PLACEMENT_EXF RefId
Set
    EXTERNAL_ACTE_ID  = (Trim(RefEnri.ACT_REM_ID)||'|'
                        ||Trim(cast (RefEnri.ORDER_DEPOSIT_TS as char(12)))||'|'
                        ||Trim(RefEnri.LAST_NAME_CUSTOMER_NM)||'|'
                        ||Trim(RefEnri.FIRST_NAME_CUSTOMER_NM)||'|'
                        ||Trim(coalesce(RefEnri.MISISDN_ID , '0000000000' ))||'|'
                        ||Trim(coalesce(RefEnri.ND_ID , '0000000000' ))||'|'
                        ||Trim(coalesce(RefEnri.NDIP_ID , '0000000000' ))||'|'
                        ||Trim(RefEnri.AGENT_ID)||'@'||SubString(RefId.EXTERNAL_ACTE_ID From  POSITION('@' in RefId.EXTERNAL_ACTE_ID) +1 For 1 )),
    COMMENT_DS        =  RefEnri.COMMENT_DS ,
    AGENT_ID          =  RefEnri.AGENT_ID   ,
    EDO_ID            =  RefEnri.EDO_ID     ,
    ACT_REM_ID        =  RefEnri.ACT_REM_ID ,
    TYPE_MOVEMENT_CD  =  RefEnri.TYPE_MOVEMENT_CD
Where
  (1=1)
  And RefEnri.ACTE_ID Is Not Null  
  And RefId.ACTE_ID   = RefEnri.ACTE_ID
  And Not Exists (Select 1  
                   From  ${KNB_PCO_SOC}.V_ACT_F_ACT_EXF_REJ REJ
                   Where RefEnri.ACTE_ID = Rej.ACTE_ID
                   And   RefEnri.INJECTION_TS =  Rej.INJECTION_TS )
;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Mise à jour de la table  Ref des acte_id                                        ----
----------------------------------------------------------------------------------------------
Create MULTISET VOLATILE Table ${KNB_TERADATA_USER}.ModifVol
(
  ACTE_ID                  Bigint                 ,
  EXTERNAL_ACTE_ID         Varchar(255)           ,
  EXTERNAL_ACTE_ID_GEN     Varchar(255)           ,
  ORDER_DEPOSIT_TS         Timestamp(0)           ,
  LAST_NAME_CUSTOMER_NM    Varchar(30)            ,
  FIRST_NAME_CUSTOMER_NM   Varchar(30)            ,
  MISISDN_ID               Varchar(10)            ,
  ND_ID                    Varchar(10)            ,
  NDIP_ID                  Varchar(10)            ,
  AGENT_ID                 Char(10)               ,
  INJECTION_TS             Timestamp(0)           ,
  ACT_REM_ID               Varchar(64)
 )
Primary Index (ACTE_ID)
ON COMMIT PRESERVE ROWS ;
Collect stat On ${KNB_TERADATA_USER}.ModifVol Column (ACTE_ID) ;

Insert Into ${KNB_TERADATA_USER}.ModifVol
(
  ACTE_ID                  ,
  EXTERNAL_ACTE_ID         ,
  EXTERNAL_ACTE_ID_GEN     ,
  ORDER_DEPOSIT_TS         ,
  LAST_NAME_CUSTOMER_NM    ,
  FIRST_NAME_CUSTOMER_NM   ,
  MISISDN_ID               ,
  ND_ID                    ,
  NDIP_ID                  ,
  AGENT_ID                 ,
  INJECTION_TS             ,
  ACT_REM_ID            
 )
Select 
  Modif.ACTE_ID                                                 As  ACTE_ID                  ,
  (Trim(Modif.ACT_REM_ID)||'|'
  ||Trim(cast (Pl.ORDER_DEPOSIT_TS as char(12)))||'|'
  ||Trim(Pl.LAST_NAME_CUSTOMER_NM)||'|'
  ||Trim(Pl.FIRST_NAME_CUSTOMER_NM)||'|'
  ||Trim(coalesce(Pl.MISISDN_ID , '0000000000' ))||'|'
  ||Trim(coalesce(Pl.ND_ID , '0000000000' ))||'|'
  ||Trim(coalesce(Pl.NDIP_ID , '0000000000' ))||'|'
  ||Trim(Modif.AGENT_ID)||'@')                                  As  EXTERNAL_ACTE_ID         ,
  Act.EXTERNAL_ACTE_ID                                          As  EXTERNAL_ACTE_ID_GEN     ,
  Pl.ORDER_DEPOSIT_TS                                           As  ORDER_DEPOSIT_TS         ,
  Pl.LAST_NAME_CUSTOMER_NM                                      As  LAST_NAME_CUSTOMER_NM    ,
  Pl.FIRST_NAME_CUSTOMER_NM                                     As  FIRST_NAME_CUSTOMER_NM   ,
  Pl.MISISDN_ID                                                 As  MISISDN_ID               ,
  Pl.ND_ID                                                      As  ND_ID                    ,
  Pl.NDIP_ID                                                    As  NDIP_ID                  ,
  Modif.AGENT_ID                                                As  AGENT_ID                 ,
  Modif.INJECTION_TS                                            As INJECTION_TS              ,
  Modif.ACT_REM_ID                                              As  ACT_REM_ID
From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF Modif 
Inner join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN Act
On Modif.ACTE_ID = Act.ACTE_ID
Inner Join ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF Pl
On Modif.ACTE_ID = Pl.ACTE_ID
Where  (1=1) 
And  Act.TYPE_SOURCE_ID = ${IdentifiantTechniqueSource}
And Not Exists (Select 1  
                   From  ${KNB_PCO_SOC}.V_ACT_F_ACT_EXF_REJ REJ
                   Where Modif.ACTE_ID = Rej.ACTE_ID
                   And   Modif.INJECTION_TS =  Rej.INJECTION_TS )
;
.if errorcode <> 0 then .quit 1



---------------------------------------------------------------------------------
Update RefId
From ${KNB_TERADATA_USER}.ModifVol RefEnri,
   ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN RefId
Set
    EXTERNAL_ACTE_ID  =  (RefEnri.EXTERNAL_ACTE_ID||SubString(RefId.EXTERNAL_ACTE_ID From  POSITION('@' in RefId.EXTERNAL_ACTE_ID) +1 For 1 )) 
Where
  (1=1)
  And RefEnri.ACTE_ID Is Not Null  
  And RefId.ACTE_ID   = RefEnri.ACTE_ID
  And Not Exists (Select 1  
                   From  ${KNB_PCO_SOC}.V_ACT_F_ACT_EXF_REJ REJ
                   Where RefEnri.ACTE_ID = Rej.ACTE_ID
                   And   RefEnri.INJECTION_TS =  Rej.INJECTION_TS )
;
.if errorcode <> 0 then .quit 1



---------------------------------------------------------------------------------------
---Etape 2 : Mise a jour de latable de placement a partir de table SUPP    -----------------
--------------------------------------------------------------------------------------

Update RefId
From
  (
    Select
      Src.ACTE_ID                             As ACTE_ID                ,
      Src.COMMENT_DS                          As COMMENT_DS             ,
      Src.AGENT_ID                            As AGENT_ID               ,
      Src.EDO_ID                              As EDO_ID                 ,
      Src.TYPE_MOVEMENT_CD                    As TYPE_MOVEMENT_CD       ,
      Src.INJECTION_TS                        As INJECTION_TS           ,
      Src.ACT_REM_ID                          As ACT_REM_ID
    From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP  Src
    Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_DECLAR_PVC Act
    On Src.ACTE_ID = Act.ACTE_ID
    Where Act.INTRNL_SOURCE_ID = 14
  )RefEnri,
   ${KNB_PCO_SOC}.ACT_F_PLACEMENT_DECLAR_PVC RefId
Set
    COMMENTAIRE_DS        =  RefEnri.COMMENT_DS     ,
    ACTION_ACTE           = Case 
                                When RefEnri.TYPE_MOVEMENT_CD In ('SUPP') Then  6
                            Else ACTION_ACTE
                            End
Where
  (1=1)
  And RefEnri.ACTE_ID Is Not Null  
  And RefId.ACTE_ID   = RefEnri.ACTE_ID
  And Not Exists (Select 1  
                   From  ${KNB_PCO_SOC}.V_ACT_F_ACT_EXF_REJ REJ
                   Where RefEnri.ACTE_ID = Rej.ACTE_ID
                   And   RefEnri.INJECTION_TS =  Rej.INJECTION_TS )
;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
----Etape 2 : Mise a jour de latable de placement a partir de table MODIF    -----------------
------------------------------------------------------------------------------------------

Update RefId
From
  (
    Select
      Src.ACTE_ID                             As ACTE_ID                ,
      Src.COMMENT_DS                          As COMMENT_DS             ,
      Src.AGENT_ID                            As AGENT_ID               ,
      Src.EDO_ID                              As EDO_ID                 ,
      Src.TYPE_MOVEMENT_CD                    As TYPE_MOVEMENT_CD       ,
      Src.INJECTION_TS                        As INJECTION_TS           ,
      Src.ACT_REM_ID                          As ACT_REM_ID             ,
      RefAGENT_ID.LAST_NAME_NM                As ORG_LAST_NAME_NM       ,
      RefAGENT_ID.FIRST_NAME_NM               As ORG_FIRST_NAME_NM     
    From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF Src
      Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_DECLAR_PVC Act
        On Src.ACTE_ID = Act.ACTE_ID
      Inner Join  ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefAGENT_ID
        On Src.AGENT_ID  = RefAGENT_ID.AGENT_CUID
          And RefAGENT_ID.CURRENT_IN  = 1
          And RefAGENT_ID.CLOSURE_DT  is Null
    Where Act.INTRNL_SOURCE_ID = 14
    Qualify Row_Number() Over(Partition by Src.ACTE_ID order by 1)=1
  )RefEnri,
   ${KNB_PCO_SOC}.ACT_F_PLACEMENT_DECLAR_PVC RefId
Set
    COMMENTAIRE_DS        =  RefEnri.COMMENT_DS         ,
    CUID                  =  RefEnri.AGENT_ID           ,
    SELLER_FIRST_NAME     =  RefEnri.ORG_FIRST_NAME_NM  ,
    SELLER_LAST_NAME      =  RefEnri.ORG_LAST_NAME_NM   ,
    TEAM_ORDER_DES        =  RefEnri.EDO_ID             ,
    LAST_MODIF_TS         =  Current_Timestamp(0)       ,
    ACT_CD                =  RefEnri.ACT_REM_ID         ,
    ACTION_ACTE           =  Case 
                             When RefEnri.TYPE_MOVEMENT_CD In ('MODIF') Then  4
                             Else ACTION_ACTE
                             End
Where
  (1=1)
  And RefEnri.ACTE_ID Is Not Null  
  And RefId.ACTE_ID   = RefEnri.ACTE_ID
  And Not Exists (Select 1  
                   From  ${KNB_PCO_SOC}.V_ACT_F_ACT_EXF_REJ REJ
                   Where RefEnri.ACTE_ID = Rej.ACTE_ID
                   And   RefEnri.INJECTION_TS =  Rej.INJECTION_TS )
;
.if errorcode <> 0 then .quit 1

.quit 0
