-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_CalculHierarchieO3_ACTE_PCM.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de récupération de la hiérarchie de travail O3 pour le flux PCM
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 31/10/2013     XKN         Création
-- 06/02/2014     AID         Indus
-- 26/08/2014     GMA         Stabilisation de l'axe Orga
---------------------------------------------------------------------------------

.set width 2000;


Delete from ${KNB_PCO_TMP}.ORD_T_CALC_ACT_PCM_O3 all;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_T_CALC_ACT_PCM_O3
(
      ACTE_ID,
      DATE_SAISIE,
      WORK_TEAM_LEVEL_1_CD,
      WORK_TEAM_LEVEL_1_DS,
      WORK_TEAM_LEVEL_2_CD,
      WORK_TEAM_LEVEL_2_DS,
      WORK_TEAM_LEVEL_3_CD,
      WORK_TEAM_LEVEL_3_DS,
      WORK_TEAM_LEVEL_4_CD,
      WORK_TEAM_LEVEL_4_DS
 )
Select
      Placement.ACTE_ID,
      Placement.DATESAISIEBCR,
      Hier.WORK_TEAM_LEVEL_1_CD,
      Hier.WORK_TEAM_LEVEL_1_DS,
      Hier.WORK_TEAM_LEVEL_2_CD,
      Hier.WORK_TEAM_LEVEL_2_DS,
      Hier.WORK_TEAM_LEVEL_3_CD,
      Hier.WORK_TEAM_LEVEL_3_DS,
      Hier.WORK_TEAM_LEVEL_4_CD,
      Hier.WORK_TEAM_LEVEL_4_DS
From
  ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM Placement
  Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL As Hier
    On    Placement.EDO_ID          = Hier.WORK_TEAM_LEVEL_1_CD
      And Placement.DATESAISIEBCR   Between Hier.WORK_TEAM_LEVEL_1_START_DT And Hier.WORK_TEAM_LEVEL_1_END_DT
      And Placement.DATESAISIEBCR   Between Hier.WORK_TEAM_LEVEL_2_START_DT And Hier.WORK_TEAM_LEVEL_2_END_DT
      And Placement.DATESAISIEBCR   Between Hier.WORK_TEAM_LEVEL_3_START_DT And Hier.WORK_TEAM_LEVEL_3_END_DT
      And Placement.DATESAISIEBCR   Between Hier.WORK_TEAM_LEVEL_4_START_DT And Hier.WORK_TEAM_LEVEL_4_END_DT
Qualify Row_Number() Over(Partition by Placement.ACTE_ID Order By         Hier.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          Hier.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          Hier.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          Hier.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          Hier.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                          Hier.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                          Hier.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                          Hier.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                          Hier.WORK_TEAM_LEVEL_1_CD Desc,
                                                                          Hier.WORK_TEAM_LEVEL_2_CD Desc,
                                                                          Hier.WORK_TEAM_LEVEL_3_CD Desc,
                                                                          Hier.WORK_TEAM_LEVEL_4_CD Desc
                          )=1
;
.if errorcode <> 0 then .quit 1

Collect Stats On ${KNB_PCO_TMP}.ORD_T_CALC_ACT_PCM_O3;
.if errorcode <> 0 then .quit 1

