--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_PVC_Hot_OS_Step2_BasculeDataTMPSOC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de bascule du run One Shot à extraire
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 12/09/2014     GMA           Création
---------------------------------------------------------------------------------

.set width 5000

Delete
From
  ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT
Where
  RUN_ID In (${RUN_ID})
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT
(
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
)
Select
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
From
  ${KNB_PCO_TMP}.ACT_T_PVC_DAY_HOT_OS
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_VM}.ACT_E_PVC_DAY_HOT;
.if errorcode <> 0 Then .quit 1;

