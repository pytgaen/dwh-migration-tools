-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_GEN_Alimentation_CommandePSF_Step2_DedoublonnageCmdLigne.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/04/2014      HFO         Creation
-- 02/07/2015      GMA         Modification Pour ajouter le Delete Insert En MS
-- 03/02/2020      EVI         PILCOM-256 : Optimisation Requete
--------------------------------------------------------------------------------

.set width 2500;

-- Insertion pour le dédoublonnage des ligne de commande
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD_TRT
(
  ORDR_ID                           ,
  PRODUCT_ID_RPS                    ,
  STATT_CD                          ,
  ORDR_LINE_ACT_CD                  ,
  ATTRIBUTE_RPS_ID                  ,
  ATTR_ITEM_RPS_ID                  ,
  ATTR_ITEM_RPS_PREV_ID             ,
  INST_PROD_DT                      ,
  START_DT                          ,
  END_DT                            ,
  CREATION_TS                       ,
  ORDR_LINE_NU                      ,
  STATT_CD_ORI                       
)
Select
  CmdLin.ORDR_ID                                                                   As ORDR_ID                         ,
  CmdLin.PRODUCT_ID_RPS                                                            As PRODUCT_ID_RPS                  ,
  Case  When CmdLin.STATT_CD In (6010)
          Then 'O'
        When CmdLin.STATT_CD In (1000)
          Then 'W'
        When CmdLin.STATT_CD In (1)
          Then 'K'
        Else 'E'
  End                                                                              As STATT_CD                        ,
  CmdLin.ORDR_LINE_ACT_CD                                                          As ORDR_LINE_ACT_CD                ,
  CmdLin.ATTRIBUTE_RPS_ID                                                          As ATTRIBUTE_RPS_ID                ,
  CmdLin.ATTR_ITEM_RPS_ID                                                          As ATTR_ITEM_RPS_ID                ,
  CmdLin.ATTR_ITEM_RPS_PREV_ID                                                     As ATTR_ITEM_RPS_PREV_ID           ,
  CmdLin.INST_PROD_DT                                                              As INST_PROD_DT                    ,
  CmdLin.START_DT                                                                  As START_DT                        ,
  CmdLin.END_DT                                                                    As END_DT                          ,
  CmdLin.CREATION_TS                                                               As CREATION_TS                     ,
  CmdLin.ORDR_LINE_NU                                                              As ORDR_LINE_NU                    ,
  CmdLin.STATT_CD                                                                  As STATT_CD_ORI                     
From 
  ${KNB_COM_SOC}.V_ORD_F_ORDR_LINE_BO  CmdLin
Where
  (1=1)
  And creation_ts >= (current_date -100)
  And CURRENT_IN =1
 Group by ORDR_ID              , PRODUCT_ID_RPS   , STATT_CD
        , ORDR_LINE_ACT_CD     , ATTRIBUTE_RPS_ID , ATTR_ITEM_RPS_ID
        , ATTR_ITEM_RPS_PREV_ID, INST_PROD_DT     , START_DT
        , END_DT               , CREATION_TS      , ORDR_LINE_NU
        , STATT_CD_ORI
;
.if errorcode <> 0 then .quit 1


Collect stat On ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD_TRT  ;
.if errorcode <> 0 then .quit 1

-- Vidage de la table de dedoublonnage





-- dedoublonnage table de commande 
Delete From  ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD
;Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD
(
  ORDR_ID                  ,
  COMPST_OFFR_RPS_ID       ,
  OLD_COMPST_OFFR_RPS_ID   ,
  STATT_CD                 ,
  TYPE_ORDR_CD             ,
  ORDR_DT                  ,
  ACCES_SERVICE_ID          
)
Select
  Cmd.ORDR_ID                                                                   As ORDR_ID                         ,
  Cmd.COMPST_OFFR_RPS_ID                                                        As COMPST_OFFR_RPS_ID              ,
  Cmd.OLD_COMPST_OFFR_RPS_ID                                                    As OLD_COMPST_OFFR_RPS_ID          ,
  --Calcul du mouvement
  Case  When Cmd.STATT_ORDR_CD In ('6000','3000','2000')
          Then 'O'
        When Cmd.STATT_ORDR_CD In ('500','1000')
          Then 'W'
        When Cmd.STATT_ORDR_CD Is Null
          Then 'W'
        When Cmd.STATT_ORDR_CD In ('1','1200','9500')
          Then 'K'
        Else 'E'
  End                                                                           As STATT_CD                        ,
  Cmd.TYPE_ORDR_CD                                                              As TYPE_ORDR_CD                    ,
  Cmd.ORDR_DT                                                                   As ORDR_DT                         ,
  Cmd.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID                 
From 
  ${KNB_COM_SOC}.V_ORD_F_ORDR_BO  Cmd
Where
  (1=1)
  And Cmd.STATT_ORDR_CD Not In ('9000')
  And creation_ts >= (current_date -100)
  And Cmd.COMPST_OFFR_RPS_ID <>'OC50000000008'
  --And creation_ts >current_date -50
Qualify Row_Number() Over(Partition By  
                                          Cmd.ORDR_ID
                                Order By  Cmd.MAJ_ORDR_DT Desc,
                                          Cmd.CREATION_TS Desc,
                                          Case  When Cmd.STATT_ORDR_CD in ('500','1000') Or Cmd.STATT_ORDR_CD Is Null
                                                  Then 0
                                                When Cmd.STATT_ORDR_CD in ('1','1200','9500')
                                                  Then 1
                                                When Cmd.STATT_ORDR_CD in ('6000','3000','2000')
                                                  Then 2
                                          End Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1


Collect Stats On ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD;
.if errorcode <> 0 then .quit 1

--dedoublonnage table de ligne de commande
Delete From  ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD
;Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD
(
  ORDR_ID                  ,
  PRODUCT_ID_RPS           ,
  STATT_CD                 ,
  ORDR_LINE_ACT_CD         ,
  ATTRIBUTE_RPS_ID         ,
  ATTR_ITEM_RPS_ID         ,
  ATTR_ITEM_RPS_PREV_ID    ,
  INST_PROD_DT             ,
  START_DT                 ,
  END_DT                    
)
Select
  CmdLin.ORDR_ID                                                                   As ORDR_ID                         ,
  CmdLin.PRODUCT_ID_RPS                                                            As PRODUCT_ID_RPS                  ,
  CmdLin.STATT_CD                                                                  As STATT_CD                        ,
  CmdLin.ORDR_LINE_ACT_CD                                                          As ORDR_LINE_ACT_CD                ,
  CmdLin.ATTRIBUTE_RPS_ID                                                          As ATTRIBUTE_RPS_ID                ,
  CmdLin.ATTR_ITEM_RPS_ID                                                          As ATTR_ITEM_RPS_ID                ,
  CmdLin.ATTR_ITEM_RPS_PREV_ID                                                     As ATTR_ITEM_RPS_PREV_ID           ,
  CmdLin.INST_PROD_DT                                                              As INST_PROD_DT                    ,
  CmdLin.START_DT                                                                  As START_DT                        ,
  CmdLin.END_DT                                                                    As END_DT                           
From 
  ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD_TRT  CmdLin
Where
  (1=1)
Qualify Row_Number() Over(Partition By  
                                          CmdLin.ORDR_ID                  ,
                                          CmdLin.ORDR_LINE_NU             ,
                                          CmdLin.PRODUCT_ID_RPS           ,
                                          CmdLin.ATTRIBUTE_RPS_ID          
                                Order By  CmdLin.CREATION_TS Desc,
                                          Case  When CmdLin.STATT_CD_ORI in ('1000')
                                                  Then 0
                                                When CmdLin.STATT_CD_ORI in ('1')
                                                  Then 1
                                                When CmdLin.STATT_CD_ORI in ('6010')
                                                  Then 2
                                          End Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD ;
.if errorcode <> 0 then .quit 1

-- Purge table Tmp
Delete From  ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD_TRT ;
.if errorcode <> 0 then .quit 1

.quit 0

