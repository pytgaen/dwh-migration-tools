-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    AVM_GEN_AlimCold_ORD_T_ACTE_UNIFIED_ROrga_Step2_CanalExtERC.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 11/02/2015      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_ERC All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
--Insert ERC
Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_ERC
(
  ACTE_ID                       ,
  ORG_CANAL_ID                  
)
Select
  RefId.ACTE_ID                                 As ACTE_ID              ,
  RefERC.STORE_CD                               As ORG_CANAL_ID         
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG RefId
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_ERC RefERC
    On RefId.ACTE_ID      = RefERC.ACTE_ID
Where
  (1=1)
  And RefERC.STORE_CD = 'SC'
Qualify Row_number() over (Partition by RefId.ACTE_ID Order By  RefERC.STORE_CD Asc) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_ERC;
.if errorcode <> 0 then .quit 1

.quit 0


