-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Acte_Consolidation_CalculActe_Step2.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Consolidation Calcul des Actes
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/02/214       AID          Suppression de TDCANALDIST_PCO
-- 01/07/2014       GMA         Evulution RG perennité
-- 08/09/2014      HFO          MODIFICATION : gestion de CHAPP pour la pérennité
-- 03/10/2014      HFO          MODIFICATION : Enlever le HOT_IN pour gerer le CHORUS HOT
-- 17/12/2014      GMA          Ajout de la gestion des actes cloturé
-- 04/03/2015      HFO          Ajout de type de resil (DOSSIER_TYPE_RESIL,DOSSIER_MOTIF_RESIL) pour stabilisation pérénnité
-- 08/01/2016      MDE          Evol  : Calcul CA
-- 19/01/2016      HLA          Ajout Champs digitales
-- 12/12/2016      HOB          Modif : Ajout Champs VA
-- 12/12/2017      HOB          Modif : Ajout Champs IOBSP
-- 30/09/2019      SSI         Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
--------------------------------------------------------------------------------

.set width 2500;

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.ACT_T_KC
-- **************************************************************
Delete From ${KNB_PCO_TMP}.INT_T_ACTE_CHO All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_CHO
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                               ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  RSFCOMMENTAIRE_DS                         ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRESFACT_CO_PRE                       ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRESFACT_CO_OFOPT_ACQ                 ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_UNITE_CD                              ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_FLAG_PEC_PERPVC                       ,
  ACT_ACTE_VALO                             ,
  ACT_ACTE_FAMILLE_KPI                      ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  INB_ORIGINE_PARC                          ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID_SC                           ,
  ORIG_DEM_SC                               ,
  INT_ORIGIN_CD                             ,
  INT_REASON_CD                             ,
  INT_RESULT_CD                             ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO_SC                     ,
  ORG_CANAL_MACRO_LB_SC                     ,
  FLAG_HD                                   ,
  ORG_CANAL_ID                              ,
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  ORG_EDO_IOBSP                             ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         ,
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_AGENT_IOBSP                           ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_ACTVT_REEL                       ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,
  CLIENT_NU                                 ,
  CLIENT_NU_NEW_PORTE                       ,
  DOSSIER_NU                                ,
  DOSSIER_NU_NEW_PORTE                      ,
  DOSSIER_DATE_ACTIV                        ,
  DOSSIER_DATE_RESIL                        ,
  DOSSIER_TYPE_RESIL                        ,
  DOSSIER_MOTIF_RESIL                       ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  DMC_LINE_TYPE                             ,
  DMC_ACTIVATION_DT                         ,
    --------
  PAR_DEPRTMNT_ID                           ,
  PAR_POSTAL_CD                             ,
  PAR_BU_CD                                 ,
  
  PAR_GEO_MACROZONE                         ,
  PAR_UNIFIED_PARTY_ID                       ,    
  PAR_PARTY_REGRPMNT_ID                      ,
  PAR_IRIS2000_CD                           ,
  PAR_FIBER_IN                              ,
  ----
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU_MOB                          ,
  PAR_SCORE_IN_MOB                          ,
  PAR_TRESHOLD_NU_MOB                       ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,
  PERENNITE_PVC_FIN_DT                      ,
  PERENNITE_PVC_CALC_FIN_DT                 ,
  PERNNT_IN                                 ,
  PERNNT_END_DT                             ,
  PERNNT_MOTIF                              ,
  PERNNT_CALC_END_DT                        ,
  ORDER_CANCELING_DT                        ,
  SEG_PRES_PARC_COMMANDE                    ,
  MIGRA_DT                                  ,
  MIGRA_NEXT_OFFRE                          ,
  RESIL_INT_DT                              ,
  RESIL_INT_MOTIF                           ,
  RESIL_INT_MOTIF_DS                        ,
  SEG_COM_ID_LAST_PER                       ,
  SEG_COM_ID_SOLD                           ,
  SEG_COM_ID_FIND                           ,
  SEG_FIND_LIVR_DT                          ,
  SEG_FIND_CANCEL_DT                        ,
  SEG_COM_ID_NEXT_PARC                      ,
  SEG_NEXT_PARC_LIVR_DT                     ,
  SEG_NEXT_PARC_CANCEL_DT                   ,
  SEG_COM_ID_FINAL_PARC                     ,
  SEG_FINAL_PARC_LIVR_DT                    ,
  SEG_FINAL_PARC_CANCEL_DT                  ,
  SEG_COM_ID_LAST_IN_PARC                   ,
  NB_IN_OUT_PARC                            ,
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  DELIVERY_DEAD_LINE_NU                     ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  SEG_COM_ID_ORDER_ID                       ,
  SEG_ORDER_DT                              ,
  SEG_CANCEL_DT                             ,
  SEG_COM_ID_NEXT_ORDER                     ,
  SEG_NEXT_ORDER_DT                         ,
  SEG_NEXT_CANCEL_DT                        ,
  SEG_COM_ID_FINAL_ORDER                    ,
  SEG_FINAL_ORDER_DT                        ,
  SEG_FINAL_ORDER_CANCEL_DT                 ,
  CHECK_INITIAL_STATUS_CD                   ,
  CHECK_NAT_STATUS_CD                       ,
  CHECK_NAT_COMMENT                         ,
  CHECK_NAT_STATUS_LN                       ,
  CHECK_LOC_STATUS_CD                       ,
  CHECK_LOC_COMMENT                         ,
  CHECK_LOC_STATUS_LN                       ,
  CHECK_VALIDT_DT                           ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              ,
  HOT_IN                                    
)
Select
  Placement.ACTE_ID                                                                     as ACTE_ID                                ,
  Placement.ACTE_ID                                                                     as ACTE_ID_GEN                            ,
  Placement.DEMANDE_ID                                                                  as DEMANDE_ID                             ,
  Placement.EXTERNAL_INT_ID                                                             as EXTERNAL_INT_ID                        ,
  Placement.INT_DEPOSIT_TS                                                              as INT_DEPOSIT_TS                         ,
  Placement.INT_DEPOSIT_DT                                                              as INT_DEPOSIT_DT                         ,
  Placement.OPERATOR_PROVIDER_ID                                                        as OPERATOR_PROVIDER_ID                   ,
  Placement.RESOLU_ID                                                                   as RESOLU_ID                              ,
  Placement.CONCLU_ID                                                                   as CONCLU_ID                              ,
  Placement.SSCONCLU_ID                                                                 as SSCONCLU_ID                            ,
  Placement.INT_MODIF_TS                                                                as INT_MODIF_TS                           ,
  --Information sur la source :
  Placement.PLTF_CO                                                                     as PLTF_CO                                ,
  Placement.INTRNL_SOURCE_ID                                                            as INTRNL_SOURCE_ID                       ,
  --Info de chorus
  Placement.SOLDOFF_SRC_CD                                                              as SOLDOFF_SRC_CD                         ,
  Placement.RSFCOMMENTAIRE_DS                                                           as RSFCOMMENTAIRE_DS                      ,
  Placement.OTO_OFFER_CD                                                                as OTO_OFFER_CD                           ,
  Placement.OTO_OFFER_TYPE_CD                                                           as OTO_OFFER_TYPE_CD                      ,
  --Information Liée aux produit et acte :
  --produit precedant :
  Placement.PRESFACT_CO_PRECED                                                          as ACT_PRESFACT_CO_PRE                    ,
  RefId.PRODUCT_ID_PRE                                                                  as ACT_PRODUCT_ID_PRE                     ,
  RefId.SEG_COM_ID_PRE                                                                  as ACT_SEG_COM_ID_PRE                     ,
  RefId.SEG_COM_AGG_ID_PRE                                                              as ACT_SEG_COM_AGG_ID_PRE                 ,
  RefId.CODE_MIGR_PRE                                                                   as ACT_CODE_MIGR_PRE                      ,
  --Produit Vendu :
  Placement.PRESFACT_CO_OFFRE_OPT_ACQ                                                   as ACT_PRESFACT_CO_OFOPT_ACQ              ,
  RefId.PRODUCT_ID_FINAL                                                                as ACT_PRODUCT_ID_FINAL                   ,
  Placement.TYPE_OT_SO                                                                  as TYPE_OT_SO                             ,
  Placement.IN_CLIDOS                                                                   as IN_CLIDOS                              ,
  RefId.SEG_COM_ID_FINAL                                                                as ACT_SEG_COM_ID_FINAL                   ,
  RefId.SEG_COM_AGG_ID_FINAL                                                            as ACT_SEG_COM_AGG_ID_FINAL               ,
  RefId.CODE_MIGR_FINAL                                                                 as ACT_CODE_MIGR_FINAL                    ,
  RefId.TYPE_SERVICE_FINAL                                                              as ACT_TYPE_SERVICE_FINAL                 ,
  --Calcul de l'acte :
  RefId.TYPE_COMMANDE_ID                                                                as ACT_TYPE_COMMANDE_ID                   ,
--Unité = NB
  Case When RefActeSC.UNITE_CD ='${P_PIL_620}'
         Then RefId.DELTA_TARIF 
    --Unité  CA_MARKET 
      When RefActeSC.UNITE_CD ='${P_PIL_623}'
           then RefActeSC.CA_MARKETING 
       Else Coalesce(RefId.DELTA_TARIF,0)
  End                                                                                   as ACT_DELTA_TARIF                       ,
  RefActeSC.UNITE_CD                                                                    as ACT_UNITE_CD                          ,
  --Calcul de l'acte avec les différents cas de rejets :
  Case  
        -- Cas de Faux Maintien d'Accès Internet
        When Coalesce(Placement.FLAG_MAINT_INT_FALSE, 'N') = '${P_PIL_356}'
          Then  '${P_PIL_412}'
--         When  Mat.ACTE_ID Is Not Null
--           Then Mat.ACTE_ID
        When  MatSC.ACTE_ID Is Not Null
          Then  MatSC.ACTE_ID
        --Cas de rejet sur les périodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  RefId.PERIODE_ID      = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit Placé est un produit inconnu de RefCom
        When  RefId.PRODUCT_ID_FINAL  = '${P_PIL_223}'
          Then '${P_PIL_224}'
        When RefId.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        --Cas de rejet sur le produit précédant, Produit Non retrouvé dans Pilcom et qu'il s'agit d'un OT -> ERR_ACTE_INCO_PRESTA_PRE_CALC_PILCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_215}' And Placement.TYPE_OT_SO ='OT'
          Then  '${P_PIL_218}'
        --Cas de rejet sur le produit précédant, Produit Non retrouvé dans RefCom et qu'il s'agit d'un OT-> ERR_ACTE_INCO_PRESTA_PRE_REFCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_216}' And Placement.TYPE_OT_SO ='OT'
          Then  '${P_PIL_219}'
        --Si la migration de l'init vers le final n'est pas paramétrée -> ERR_ACTE_INCO_MIGR_NON_PARAM_REFCOM
        When  RefId.CODE_MIGR_PRE  Is Not Null And RefId.CODE_MIGR_FINAL Is Not Null And RefId.TYPE_COMMANDE_ID ='${P_PIL_045}'
          Then  '${P_PIL_222}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        --Sinon c'est un problème dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                                                   as ACT_CD                                 ,
  Coalesce(RefActeSC.ACTE_REM_ID,'${P_PIL_067}')                                        as ACT_REM_ID                             ,
  Coalesce(RefActeSC.FLAG_ACT_REM,'N')                                                  as ACT_FLAG_ACT_REM                       ,
  Coalesce(RefActeSC.FLAG_PEC_PERPVC,'N')                                               as ACT_FLAG_PEC_PERPVC                    ,
     --Unité = NB
  Case When RefActeSC.UNITE_CD ='${P_PIL_620}'
         Then RefActeSC.ACTE_VALO
  --Unité = CA_MARKET 
       When RefActeSC.UNITE_CD  ='${P_PIL_623}' 
         Then  ( ACT_DELTA_TARIF * RefActeSC.TAUX_MARGE ) 
       Else   Coalesce(RefActeSC.ACTE_VALO,0)
  End                                                                                   as ACT_ACTE_VALO                          ,
  Coalesce(RefActeSC.ACTE_FAMILLE_KPI,'NON PARAM')                                      as ACT_ACTE_FAMILLE_KPI                   ,
  RefId.PERIODE_ID                                                                      as ACT_PERIODE_ID                         ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                                              as ACT_PERIODE_STATUS                     ,
  EtatPeriode.PERIODE_CLOSURE_DT                                                        as ACT_PERIODE_CLOSURE_DT                 ,
  --Information sur le code prestation retrouvé en parc
  Coalesce(RefPer.INB_PRESFACT_ACQ_ADV,Placement.INB_PRESFACT_ACQ_ADV)                  as INB_PRESFACT_ACQ_ADV                   ,
  Coalesce(RefPer.INB_PRESFACT_ACQ_AGAP,Placement.INB_PRESFACT_ACQ_AGAP)                as INB_PRESFACT_ACQ_AGAP                  ,
  Coalesce(RefPer.INB_ORIGINE_PARC,'P')                                                 as INB_ORIGINE_PARC                       ,
  Coalesce(RefPer.SEG_PARC_DT_DEBUT,Placement.PARC_DT_DEBUT)                            as SEG_PARC_DT_DEBUT                      ,
  --Infos sur le canal de vente
  Placement.CANALVENTE                                                                  as ORG_CANAL_ID_SC                        ,
  Coalesce(OrigineVente.ORIG_DEM,Placement.CANALDEM)                                    as ORIG_DEM_SC                            ,
  Placement.CANALDEM                                                                    as INT_ORIGIN_CD                          ,
  Placement.INT_REASON_CD                                                               as INT_REASON_CD                          ,
  Placement.SOLDOFF_SRC_CD                                                              as INT_RESULT_CD                          ,
  Case  When OrigineVente.ORIG_DEM Is Null
          Then Placement.CANALDEM_MTHD
        Else Null
   End                                                                                  as CANALDEM_MTHD                          ,
  CanalVenteMacroPrem.ORG_CANAL_ID_MACRO                                                as ORG_CANAL_ID_MACRO_SC                  ,
  CanalVenteMacroPrem.ORG_CANAL_MACRO_LB                                                as ORG_CANAL_MACRO_LB_SC                  ,
  KPI_PILCOM.HUMAINDIGITAL                                                              as FLAG_HD                                ,
  --Nouvelle RG Cannal :
  Null                                                                                  as ORG_CANAL_ID                           ,
  --Calcul du canal de vente Macro
  Coalesce(OrgChannelCho.ORG_CHANNEL_CD,'NONPARAM')                                     as ORG_CHANNEL_CD                         ,
  --Sous Canal
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                                                   as ORG_SUB_CHANNEL_CD                     ,
  --Sous-Sous-Canal
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_SUB_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                                                   as ORG_SUB_SUB_CHANNEL_CD                 ,
  --Canal de Rem
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_REM_CHANNEL_CD
        Else 'NONPAR'
  End                                                                                   as ORG_REM_CHANNEL_CD                     ,
  --Activité
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_GT_ACTIVITY
        Else 'NONPARAM'
  End                                                                                   as ORG_GT_ACTIVITY                        ,
  --Fidelisaion
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_FIDELISATION
        Else 'NONPARAM'
  End                                                                                   as ORG_FIDELISATION                       ,
  --Activité Web
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_WEB_ACTIVITY
        Else 'E'
  End                                                                                   as ORG_WEB_ACTIVITY                       ,
  --Activité Automatique
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_AUTO_ACTIVITY
        Else 'E'
  End                                                                                   as ORG_AUTO_ACTIVITY                      ,
  Placement.EDO_ID                                                                      as ORG_EDO_ID                             ,
  Placement.TYPE_EDO                                                                    as ORG_TYPE_EDO                           ,
  Placement.ORG_EDO_IOBSP                                                               as ORG_EDO_IOBSP                          ,
  OrgChannelCho.FLAG_PLT_CONV                                                           as ORG_FLAG_PLT_CONV                      ,
  Placement.FLAG_TEAM_MKT                                                               as ORG_FLAG_TEAM_MKT                      ,
  OrgChannelCho.ORG_FLAG_TYPE_CMP                                                       as ORG_FLAG_TYPE_CMP                      ,
  Placement.EDO_ID_HIER                                                                 as ORG_EDO_ID_HIER                        ,
  Placement.TYPE_EDO_HIER                                                               as ORG_TYPE_EDO_HIER                      ,
  --Alimentation Orga
  Placement.ORG_REF_TRAV                                                                as ORG_REF_TRAV                           ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.LOGIN_CREA)                                 as ORG_AGENT_ID                           ,
  Placement.ORG_AGENT_IOBSP                                                             as ORG_AGENT_IOBSP                        ,
  Placement.ORG_POC_XI                                                                  as ORG_POC_XI                             ,
  Placement.ORG_NOM                                                                     as ORG_NOM                                ,
  Placement.ORG_PRENOM                                                                  as ORG_PRENOM                             ,
  Placement.ORG_GROUPE_ID                                                               as ORG_GROUPE_ID                          ,
  Placement.ORG_GROUPE_ID_HIER                                                          as ORG_GROUPE_ID_HIER                     ,
  Placement.ORG_ACTVT_REEL                                                              as ORG_ACTVT_REEL                         ,
  Placement.ORG_RESP_REF_TRAV                                                           as ORG_RESP_REF_TRAV                      ,
  Coalesce(Placement.ORG_RESP_AGENT_ID,Placement.LOGIN_RESP)                            as ORG_RESP_AGENT_ID                      ,
  Placement.ORG_RESP_XI                                                                 as ORG_RESP_XI                            ,
  Placement.ORG_RESP_ACTVT_REEL                                                         as ORG_RESP_ACTVT_REEL                    ,
  Null                                                                                  as ORG_RESP_EDO_ID                        ,
  Null                                                                                  as ORG_RESP_TYPE_EDO                      ,
  Null                                                                                  as ORG_RESP_FLAG_PLT_CONV                 ,
  Trim(HierO3.ORG_TEAM_LEVEL_1_CD)                                                      as ORG_TEAM_LEVEL_1_CD                    ,
  HierO3.ORG_TEAM_LEVEL_1_DS                                                            as ORG_TEAM_LEVEL_1_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_2_CD)                                                      as ORG_TEAM_LEVEL_2_CD                    ,
  HierO3.ORG_TEAM_LEVEL_2_DS                                                            as ORG_TEAM_LEVEL_2_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_3_CD)                                                      as ORG_TEAM_LEVEL_3_CD                    ,
  HierO3.ORG_TEAM_LEVEL_3_DS                                                            as ORG_TEAM_LEVEL_3_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_4_CD)                                                      as ORG_TEAM_LEVEL_4_CD                    ,
  HierO3.ORG_TEAM_LEVEL_4_DS                                                            as ORG_TEAM_LEVEL_4_DS                    ,
  Trim(HierO3.WORK_TEAM_LEVEL_1_CD)                                                     as WORK_TEAM_LEVEL_1_CD                   ,
  HierO3.WORK_TEAM_LEVEL_1_DS                                                           as WORK_TEAM_LEVEL_1_DS                   ,
  Trim(HierO3.WORK_TEAM_LEVEL_2_CD)                                                     as WORK_TEAM_LEVEL_2_CD                   ,
  HierO3.WORK_TEAM_LEVEL_2_DS                                                           as WORK_TEAM_LEVEL_2_DS                   ,
  Trim(HierO3.WORK_TEAM_LEVEL_3_CD)                                                     as WORK_TEAM_LEVEL_3_CD                   ,
  HierO3.WORK_TEAM_LEVEL_3_DS                                                           as WORK_TEAM_LEVEL_3_DS                   ,
  Trim(HierO3.WORK_TEAM_LEVEL_4_CD )                                                    as WORK_TEAM_LEVEL_4_CD                   ,
  HierO3.WORK_TEAM_LEVEL_4_DS                                                           as WORK_TEAM_LEVEL_4_DS                   ,
  --Information client
  Placement.CLIENT_NU                                                                   as CLIENT_NU                              ,
  Placement.CLIENT_NU_NEW_PORTE                                                         as CLIENT_NU_NEW_PORTE                    ,
  Placement.DOSSIER_NU                                                                  as DOSSIER_NU                             ,
  Placement.DOSSIER_NU_NEW_PORTE                                                        as DOSSIER_NU_NEW_PORTE                   ,
  Placement.DOSSIER_DATE_ACTIV                                                          as DOSSIER_DATE_ACTIV                     ,
  Placement.DOSSIER_DATE_RESIL                                                          as DOSSIER_DATE_RESIL                     ,
  Placement.DOSSIER_TYPE_RESIL                                                          as DOSSIER_TYPE_RESIL                     ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as DOSSIER_MOTIF_RESIL                    ,
  --Alimentation des champs de convergence :
  Placement.DMC_LINE_ID                                                                 as DMC_LINE_ID                            ,
  Placement.DMC_MASTER_LINE_ID                                                          as DMC_MASTER_LINE_ID                     ,
  Placement.DMC_LINE_TYPE                                                               as DMC_LINE_TYPE                          ,
  Placement.DMC_ACTIVATION_DT                                                           as DMC_ACTIVATION_DT                      ,
   ---
  Placement.PAR_DEPRTMNT_ID                                                             As PAR_DEPRTMNT_ID                        ,
  Placement.PAR_POSTAL_CD                                                               As PAR_POSTAL_CD                          ,
  Placement.PAR_BU_CD                                                                   As PAR_BU_CD                              ,
  Placement.PAR_GEO_MACROZONE                                                           As PAR_GEO_MACROZONE       ,
  Placement.PAR_UNIFIED_PARTY_ID                                                        As PAR_UNIFIED_PARTY_ID     ,    
  Placement.PAR_PARTY_REGRPMNT_ID                                                      As  PAR_PARTY_REGRPMNT_ID      ,
  Placement.PAR_IRIS2000_CD                                                             As PAR_IRIS2000_CD                        ,
  Placement.PAR_FIBER_IN                                                                As PAR_FIBER_IN                           ,
   --
  Placement.DMC_CONVERGENT_IN                                                           as DMC_CONVERGENT_IN                      ,
  Placement.DMC_LINE_ID_INT                                                             as DMC_LINE_ID_INT                        ,
  Placement.DMC_LINE_TYPE_INT                                                           as DMC_LINE_TYPE_INT                      ,
  Placement.DMC_ACTIVATION_DT_INT                                                       as DMC_ACTIVATION_DT_INT                  ,
  Placement.DMC_SERVICE_ACCESS_ID                                                       as DMC_SERVICE_ACCESS_ID                  ,
  Placement.OFFRE_INT_PRE                                                               as OFFRE_INT_PRE                          ,
  --Alim Infos Clients
  Placement.OTO_OSCAR_VALUE_NU                                                          as OTO_OSCAR_VALUE_NU                     ,
  Placement.PAR_LASTNAME                                                                as PAR_LASTNAME                           ,
  Placement.PAR_FIRSTNAME                                                               as PAR_FIRSTNAME                          ,
  Placement.PAR_TYPE                                                                    as PAR_TYPE                               ,
  Placement.PAR_IMSI                                                                    as PAR_IMSI                               ,
  Placement.PAR_EMAIL                                                                   as PAR_EMAIL                              ,
  Placement.PAR_BILL_ADRESS_1                                                           as PAR_BILL_ADRESS_1                      ,
  Placement.PAR_BILL_ADRESS_2                                                           as PAR_BILL_ADRESS_2                      ,
  Placement.PAR_BILL_ADRESS_3                                                           as PAR_BILL_ADRESS_3                      ,
  Placement.PAR_BILL_ADRESS_4                                                           as PAR_BILL_ADRESS_4                      ,
  Placement.PAR_BILL_VILLE                                                              as PAR_BILL_VILLE                         ,
  Placement.PAR_BILL_CD_POSTAL                                                          as PAR_BILL_CD_POSTAL                     ,
  Placement.PAR_INSEE_CD                                                                as PAR_INSEE_CD                           ,
  Placement.PAR_DO                                                                      as PAR_DO                                 ,
  Placement.PAR_USCM                                                                    as PAR_USCM                               ,
  Placement.PAR_USCM_DS                                                                 as PAR_USCM_DS                            ,
  Placement.PAR_USCM_USCM_DS                                                            as PAR_USCM_USCM_DS                       ,
  Placement.PAR_USCM_REGUSCM                                                            as PAR_USCM_REGUSCM                       ,
  Placement.PAR_USCM_REGUSCM_DS                                                         as PAR_USCM_REGUSCM_DS                    ,
  Placement.PAR_AID                                                                     as PAR_AID                                ,
  Placement.PAR_ND                                                                      as PAR_ND                                 ,
  Placement.PAR_MOB_IMEI                                                                as PAR_MOB_IMEI                           ,
  Placement.PAR_MOB_TAC                                                                 as PAR_MOB_TAC                            ,
  Placement.PAR_MOB_SIM                                                                 as PAR_MOB_SIM                            ,
  --Segementation client :
  Placement.PAR_SCORE_NU_MOB                                                            as PAR_SCORE_NU_MOB                       ,
  Placement.PAR_SCORE_IN_MOB                                                            as PAR_SCORE_IN_MOB                       ,
  Placement.PAR_TRESHOLD_NU_MOB                                                         as PAR_TRESHOLD_NU_MOB                    ,
  Placement.PAR_SCORE_NU_INT                                                            as PAR_SCORE_NU_INT                       ,
  Placement.PAR_SCORE_IN_INT                                                            as PAR_SCORE_IN_INT                       ,
  Placement.PAR_TRESHOLD_NU_INT                                                         as PAR_TRESHOLD_NU_INT                    ,
  --Contrat Avec le client :
  Placement.CONTRCT_DT_SIGN_PREC                                                        as CONTRCT_DT_SIGN_PREC                   ,
  Placement.CONTRCT_DT_FIN_PREC                                                         as CONTRCT_DT_FIN_PREC                    ,
  Placement.CONTRCT_DT_SIGN_POST                                                        as CONTRCT_DT_SIGN_POST                   ,
  Placement.CONTRCT_DUREE_ENG                                                           as CONTRCT_DUREE_ENG                      ,
  Placement.CONTRCT_UNIT_ENG                                                            as CONTRCT_UNIT_ENG                       ,
  --Attributs de pérénité   :
  RefPer.CONFIRMATION_IN                                                                as CONFIRMATION_IN                        ,
  RefPer.CONFIRMATION_DT                                                                as CONFIRMATION_DT                        ,
  RefPer.CONFIRMATION_CALC_FIN_DT                                                       as CONFIRMATION_CALC_FIN_DT               ,
  RefPer.DELIVERY_IN                                                                    as DELIVERY_IN                            ,
  RefPer.DELIVERY_DT                                                                    as DELIVERY_DT                            ,
  RefPer.DELIVERY_CALC_FIN_DT                                                           as DELIVERY_CALC_FIN_DT                   ,
  RefPer.PERENNITE_IN                                                                   as PERENNITE_IN                           ,
  RefPer.PERENNITE_FIN_DT                                                               as PERENNITE_FIN_DT                       ,
  RefPer.PERENNITE_CALC_FIN_DT                                                          as PERENNITE_CALC_FIN_DT                  ,
  PerPVC.PERENNITE_PVC_IN                                                               as PERENNITE_PVC_IN                       ,
  PerPVC.PERENNITE_PVC_FIN_DT                                                           as PERENNITE_PVC_FIN_DT                   ,
  PerPVC.PERENNITE_PVC_CALC_FIN_DT                                                      as PERENNITE_PVC_CALC_FIN_DT              ,
  Case  When RefActeSC.FLAG_PEC_PERPVC = 'N'
          Then  'O' --Si le flag est à Non alors on force la perennité à Oui
        Else    PerPVC.PERNNT_IN
  End                                                                                   as PERNNT_IN                              ,
  Case  When RefActeSC.FLAG_PEC_PERPVC = 'N'
          Then  Null  --Si le flag est à Non alors on force la perennité à Oui
        Else    PerPVC.PERNNT_END_DT
  End                                                                                   as PERNNT_END_DT                          ,
  Case  When RefActeSC.FLAG_PEC_PERPVC = 'N'
          Then  Null  --Si le flag est à Non alors on force la perennité à Oui
        Else    PerPVC.PERNNT_MOTIF
  End                                                                                   as PERNNT_MOTIF                          ,
  Case  When  PerPVC.PERNNT_CALC_END_DT is not  null
          Then PerPVC.PERNNT_CALC_END_DT
        Else Null 
  End                                                                                 as PERNNT_CALC_END_DT                     ,
  Case  When AnnulationAGD.ACTE_ID Is not Null
        --Si on trouve une correspondance alors c'est que l'ordre agendé est annulé
          Then  Placement.INT_DEPOSIT_DT
        Else    Null
  End                                                                                   as ORDER_CANCELING_DT                     ,
  Case  --Si le segment est déjà en parc alors on positionne le flag à Oui
        When PerDejPres.ACTE_ID Is Not Null 
          Then  1
        Else    0
  End                                                                                   as SEG_PRES_PARC_COMMANDE                 ,
  PerPVC.SEG_NEXT_PARC_LIVR_DT                                                          as MIGRA_DT                               ,
  PerPVC.SEG_COM_ID_NEXT_PARC                                                           as MIGRA_NEXT_OFFRE                       ,
  Placement.DOSSIER_DATE_RESIL                                                          as RESIL_INT_DT                           ,
  Placement.DOSSIER_TYPE_RESIL                                                          as RESIL_INT_MOTIF                        ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as RESIL_INT_MOTIF_DS                     ,
  PerPVC.SEG_COM_ID_LAST_PER                                                            as SEG_COM_ID_LAST_PER                    ,
  PerPVC.SEG_COM_ID_SOLD                                                                as SEG_COM_ID_SOLD                        ,
  PerPVC.SEG_COM_ID_FIND                                                                as SEG_COM_ID_FIND                        ,
  PerPVC.SEG_FIND_LIVR_DT                                                               as SEG_FIND_LIVR_DT                       ,
  PerPVC.SEG_FIND_CANCEL_DT                                                             as SEG_FIND_CANCEL_DT                     ,
  PerPVC.SEG_COM_ID_NEXT_PARC                                                           as SEG_COM_ID_NEXT_PARC                   ,
  PerPVC.SEG_NEXT_PARC_LIVR_DT                                                          as SEG_NEXT_PARC_LIVR_DT                  ,
  PerPVC.SEG_NEXT_PARC_CANCEL_DT                                                        as SEG_NEXT_PARC_CANCEL_DT                ,
  PerPVC.SEG_COM_ID_FINAL_PARC                                                          as SEG_COM_ID_FINAL_PARC                  ,
  PerPVC.SEG_FINAL_PARC_LIVR_DT                                                         as SEG_FINAL_PARC_LIVR_DT                 ,
  PerPVC.SEG_FINAL_PARC_CANCEL_DT                                                       as SEG_FINAL_PARC_CANCEL_DT               ,
  PerPVC.SEG_COM_ID_LAST_IN_PARC                                                        as SEG_COM_ID_LAST_IN_PARC                ,
  PerPVC.NB_IN_OUT_PARC                                                                 as NB_IN_OUT_PARC                         ,
  PerPVC.POURCENTAGE_PRES_PARC                                                          as POURCENTAGE_PRES_PARC                  ,
  --Calcul si la livraison à eu lieu dans les temps :
  Case  When RefPer.DELIVERY_DT is Null
          Then 'NA'
        When Delais.DELAIS is Null
          --Dans le cas où le delais est null alors on a pas pu évaluer : NC
          Then 'NC'
        When ( Placement.INT_DEPOSIT_DT + Cast(Delais.DELAIS as interval day(4))) >= RefPer.DELIVERY_DT
          -- Dans le cas où on est dans le délais :
          Then  'O'
          --Sinon on n'est pas dans les clous
        Else    'N'
  End                                                                                   as DELIVERY_ONTIME_IN                     ,
  Coalesce(Delais.DELAIS,-1)                                                            as DELIVERY_DEAD_LINE_NU                  ,
  'NA'                                                                                  as CONCURENCE_IN                          ,
  'NA'                                                                                  as CONCURENCE_CONCLU_IN                   ,
  Null                                                                                  as CONCURENCE_ID                          ,
  ----------------------------------------------------------------------------
  Null                                                                                  as SEG_COM_ID_ORDER_ID                    ,
  Null                                                                                  as SEG_ORDER_DT                           ,
  Null                                                                                  as SEG_CANCEL_DT                          ,
  Null                                                                                  as SEG_COM_ID_NEXT_ORDER                  ,
  Null                                                                                  as SEG_NEXT_ORDER_DT                      ,
  Null                                                                                  as SEG_NEXT_CANCEL_DT                     ,
  PerPVC.SEG_COM_ID_FINAL_ORDER                                                         as SEG_COM_ID_FINAL_ORDER                 ,
  PerPVC.SEG_FINAL_ORDER_DT                                                             as SEG_FINAL_ORDER_DT                     ,
  PerPVC.SEG_FINAL_ORDER_CANCEL_DT                                                      as SEG_FINAL_ORDER_CANCEL_DT              ,
  ----------------------------------------------------------------------------
  Null                                                                                  as CHECK_INITIAL_STATUS_CD                ,
  RetournCSO.CHECK_NAT_STATUS_CD                                                        as CHECK_NAT_STATUS_CD                    ,
  RetournCSO.CHECK_NAT_COMMENT                                                          as CHECK_NAT_COMMENT                      ,
  RetournCSO.CHECK_NAT_STATUS_LN                                                        as CHECK_NAT_STATUS_LN                    ,
  RetournCSO.CHECK_LOC_STATUS_CD                                                        as CHECK_LOC_STATUS_CD                    ,
  RetournCSO.CHECK_LOC_COMMENT                                                          as CHECK_LOC_COMMENT                      ,
  RetournCSO.CHECK_LOC_STATUS_LN                                                        as CHECK_LOC_STATUS_LN                    ,
  RetournCSO.CHECK_VALIDT_DT                                                            as CHECK_VALIDT_DT                        ,
  Null                                                                                  as CLOSURE_DT                             ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                            ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS                          ,
  1                                                                                     as FRESH_IN                               ,
  0                                                                                     as COHERENCE_IN                           ,
  0                                                                                     as HOT_IN 
From
  ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO Placement
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CALC RefId
    On    Placement.ACTE_ID                             = RefId.ACTE_ID
      And Placement.INT_DEPOSIT_DT                      = RefId.INT_DEPOSIT_DT
   Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM MatSC
    On    RefId.TYPE_COMMANDE_ID                        = MatSC.TYPE_COMMANDE_ID
      And RefId.SEG_COM_ID_FINAL                        = MatSC.SEG_COM_ID_FINAL
      And Coalesce(RefId.SEG_COM_ID_PRE,'${P_PIL_211}') = MatSC.SEG_COM_ID_INI
      And RefId.PERIODE_ID                              = MatSC.PERIODE_ID
      And MatSC.CATEGORIE_CLIENT_ID                     = 'SC' --Catégorie Oscar
      And MatSC.FRESH_IN                                = 1
      And MatSC.CURRENT_IN                              = 1
      And MatSC.CLOSURE_DT                              is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM    RefActeSC
    On    MatSC.ACTE_ID                                 = RefActeSC.ACTE_ID
      And MatSC.PERIODE_ID                              = RefActeSC.PERIODE_ID
      And RefActeSC.FRESH_IN                            = 1
      And RefActeSC.CURRENT_IN                          = 1
      And RefActeSC.CLOSURE_DT                          Is Null
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER RefPer
    On    RefPer.ACTE_ID                                = RefId.ACTE_ID
      And RefPer.INT_DEPOSIT_DT                         = RefId.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On    RefId.TYPE_COMMANDE_ID                        = Delais.TYPE_COMMANDE_ID
      And RefId.TYPE_SERVICE_FINAL                      = Delais.TYPE_SERVICE
      And RefId.PERIODE_ID                              = Delais.PERIODE_ID
      And Delais.FRESH_IN                               = 1
      And Delais.CURRENT_IN                             = 1
      And Delais.CLOSURE_DT                             is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_ORIG_DEM OrigineVente
    On    Placement.ORG_REF_TRAV                        =  OrigineVente.ORG_REF_TRAV
      And Placement.ORG_GROUPE_ID                       =  OrigineVente.ORG_GROUPE_ID
      And Placement.PLTF_CO                             =  OrigineVente.APPLI_SOURCE_ID
      And Placement.INT_DEPOSIT_DT                      >= OrigineVente.GRP_DT_DEB
      And Placement.INT_DEPOSIT_DT                      <= OrigineVente.GRP_DT_FIN
      And OrigineVente.FRESH_IN                         =  1
      And OrigineVente.CURRENT_IN                       =  1
      And OrigineVente.CLOSURE_DT                       is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_CANAL_VENTE CanalVenteMacroPrem
    On    OrigineVente.ORIG_DEM                         = CanalVenteMacroPrem.ORIG_DEM
      And CanalVenteMacroPrem.FRESH_IN                  = 1
      And CanalVenteMacroPrem.CURRENT_IN                = 1
      And CanalVenteMacroPrem.CLOSURE_DT                is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_CHO OrgChannelCho
    On    Placement.RESOLU_ID                                                                                               = OrgChannelCho.RESOLU_ID
      And Case When Coalesce(Placement.PAR_SCORE_IN_MOB, 0) = ${P_PIL_419} Then '${P_PIL_417}' Else '${P_PIL_416}' End      = OrgChannelCho.PAR_SCORE_IN_MOB
      And Case When Coalesce(Placement.CANALDEM, '${P_PIL_418}')  In (${L_PIL_042}) Then Placement.CANALDEM Else '#' End    = OrgChannelCho.CANALDEM
            And Case  When (Placement.FLAG_PLT_CONV IS NULL AND Placement.CANALDEM = '${P_PIL_436}') Then 1
                        Else Coalesce(Placement.FLAG_PLT_CONV, 0)
                End                                                                                                         = OrgChannelCho.FLAG_PLT_CONV
      And Coalesce(Placement.FLAG_PLT_SCH, 0)                                                                               = OrgChannelCho.FLAG_PLT_SCH
      And Coalesce(Placement.FLAG_TYPE_CMP, '${P_PIL_418}')                                                                 = OrgChannelCho.ORG_FLAG_TYPE_CMP
  --Jointure pour récupérer la hierarchie O3:
  Left Outer Join ${KNB_PCO_TMP}.ORD_T_CALC_ACT_CHO_O3 HierO3
    On    Placement.ACTE_ID        = HierO3.ACTE_ID
      And Placement.INT_DEPOSIT_DT = HierO3.DATE_SAISIE
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_FULL PerPVC
    On    Placement.ACTE_ID        = PerPVC.ACTE_ID
      And Placement.INT_DEPOSIT_DT = PerPVC.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_SEG_DEJPRES PerDejPres
    On    Placement.ACTE_ID        = PerDejPres.ACTE_ID
      And Placement.INT_DEPOSIT_DT = PerDejPres.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    RefId.PERIODE_ID                                    = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                              = 1
      And EtatPeriode.FRESH_IN                                = 1
      And EtatPeriode.CLOSURE_DT                              Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                                   = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG                       = 1
      And RetournCSO.CURRENT_IN                               = 1
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID                                   = RetourGRV.ACTE_ID
      And Placement.INT_DEPOSIT_DT                            = RetourGRV.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_CANCLNG   AnnulationAGD
    On    Placement.ACTE_ID                                   = AnnulationAGD.ACTE_ID
      And Placement.INT_DEPOSIT_DT                            = AnnulationAGD.INT_DEPOSIT_DT
   --Jointure pour KPI 2020 Flag_HumainDigital
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM         KPI_PILCOM
On                 KPI_PILCOM.PERIODE_ID                      = RefActeSC.PERIODE_ID
And                KPI_PILCOM.FAMILLE_KPI_ID                  = RefActeSC.ACTE_FAMILLE_KPI
And                KPI_PILCOM.CURRENT_IN                      = 1
And                KPI_PILCOM.CLOSURE_DT                      Is Null
Where
  (1=1)
  And
      ( 
        --On veut suivre les produits :
            --Qui sont sur une période valable :
                RefId.PERIODE_ID        <> ${P_PIL_049}
            --Dont le produit est défini dans le référentiel 
            And RefId.PRODUCT_ID_FINAL  Not in ('${P_PIL_223}')
            --Et qui sont sur un segment suivi
            And RefId.SEG_COM_ID_FINAL  Not in ('${P_PIL_022}','${P_PIL_295}')
      )
  --And Placement.HOT_IN = 0
--Insertion des non suivi
;

Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_CHO
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                               ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  RSFCOMMENTAIRE_DS                         ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRESFACT_CO_PRE                       ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRESFACT_CO_OFOPT_ACQ                 ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_UNITE_CD                              ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  INB_ORIGINE_PARC                          ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID_SC                           ,
  ORIG_DEM_SC                               ,
  INT_ORIGIN_CD                             ,
  INT_REASON_CD                             ,
  INT_RESULT_CD                             ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO_SC                     ,
  ORG_CANAL_MACRO_LB_SC                     ,
  FLAG_HD                                   ,
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  ORG_EDO_IOBSP                             ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         ,
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_AGENT_IOBSP                           ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_ACTVT_REEL                       ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,
  CLIENT_NU                                 ,
  CLIENT_NU_NEW_PORTE                       ,
  DOSSIER_NU                                ,
  DOSSIER_NU_NEW_PORTE                      ,
  DOSSIER_DATE_ACTIV                        ,
  DOSSIER_DATE_RESIL                        ,
  DOSSIER_TYPE_RESIL                        ,
  DOSSIER_MOTIF_RESIL                       ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  DMC_LINE_TYPE                             ,
  DMC_ACTIVATION_DT                         ,
      --------
  PAR_DEPRTMNT_ID                           ,
  PAR_POSTAL_CD                             ,
  PAR_BU_CD                                 ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID                       ,
  PAR_PARTY_REGRPMNT_ID               ,
  PAR_IRIS2000_CD                           ,
  PAR_FIBER_IN                              ,
  ----
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU_MOB                          ,
  PAR_SCORE_IN_MOB                          ,
  PAR_TRESHOLD_NU_MOB                       ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,
  PERENNITE_PVC_FIN_DT                      ,
  PERENNITE_PVC_CALC_FIN_DT                 ,
  PERNNT_IN                                 ,
  PERNNT_END_DT                             ,
  PERNNT_MOTIF                              ,
  PERNNT_CALC_END_DT                        ,
  ORDER_CANCELING_DT                        ,
  SEG_PRES_PARC_COMMANDE                    ,
  MIGRA_DT                                  ,
  MIGRA_NEXT_OFFRE                          ,
  RESIL_INT_DT                              ,
  RESIL_INT_MOTIF                           ,
  RESIL_INT_MOTIF_DS                        ,
  SEG_COM_ID_LAST_PER                       ,
  SEG_COM_ID_SOLD                           ,
  SEG_COM_ID_FIND                           ,
  SEG_FIND_LIVR_DT                          ,
  SEG_FIND_CANCEL_DT                        ,
  SEG_COM_ID_NEXT_PARC                      ,
  SEG_NEXT_PARC_LIVR_DT                     ,
  SEG_NEXT_PARC_CANCEL_DT                   ,
  SEG_COM_ID_FINAL_PARC                     ,
  SEG_FINAL_PARC_LIVR_DT                    ,
  SEG_FINAL_PARC_CANCEL_DT                  ,
  SEG_COM_ID_LAST_IN_PARC                   ,
  NB_IN_OUT_PARC                            ,
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  DELIVERY_DEAD_LINE_NU                     ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  SEG_COM_ID_ORDER_ID                       ,
  SEG_ORDER_DT                              ,
  SEG_CANCEL_DT                             ,
  SEG_COM_ID_NEXT_ORDER                     ,
  SEG_NEXT_ORDER_DT                         ,
  SEG_NEXT_CANCEL_DT                        ,
  SEG_COM_ID_FINAL_ORDER                    ,
  SEG_FINAL_ORDER_DT                        ,
  SEG_FINAL_ORDER_CANCEL_DT                 ,
  CHECK_INITIAL_STATUS_CD                   ,
  CHECK_NAT_STATUS_CD                       ,
  CHECK_NAT_COMMENT                         ,
  CHECK_NAT_STATUS_LN                       ,
  CHECK_LOC_STATUS_CD                       ,
  CHECK_LOC_COMMENT                         ,
  CHECK_LOC_STATUS_LN                       ,
  CHECK_VALIDT_DT                           ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              ,
  HOT_IN
)
Select
  Placement.ACTE_ID                                                                     as ACTE_ID                                ,
  Placement.ACTE_ID                                                                     as ACTE_ID_GEN                            ,
  Placement.DEMANDE_ID                                                                  as DEMANDE_ID                             ,
  Placement.EXTERNAL_INT_ID                                                             as EXTERNAL_INT_ID                        ,
  Placement.INT_DEPOSIT_TS                                                              as INT_DEPOSIT_TS                         ,
  Placement.INT_DEPOSIT_DT                                                              as INT_DEPOSIT_DT                         ,
  Placement.OPERATOR_PROVIDER_ID                                                        as OPERATOR_PROVIDER_ID                   ,
  Placement.RESOLU_ID                                                                   as RESOLU_ID                              ,
  Placement.CONCLU_ID                                                                   as CONCLU_ID                              ,
  Placement.SSCONCLU_ID                                                                 as SSCONCLU_ID                            ,
  Placement.INT_MODIF_TS                                                                as INT_MODIF_TS                           ,
  --Information sur la source :
  Placement.PLTF_CO                                                                     as PLTF_CO                                ,
  Placement.INTRNL_SOURCE_ID                                                            as INTRNL_SOURCE_ID                       ,
  --Info de chorus
  Placement.SOLDOFF_SRC_CD                                                              as SOLDOFF_SRC_CD                         ,
  Placement.RSFCOMMENTAIRE_DS                                                           as RSFCOMMENTAIRE_DS                      ,
  Placement.OTO_OFFER_CD                                                                as OTO_OFFER_CD                           ,
  Placement.OTO_OFFER_TYPE_CD                                                           as OTO_OFFER_TYPE_CD                      ,
  --Information Liée aux produit et acte :
  --produit precedant :
  Placement.PRESFACT_CO_PRECED                                                          as ACT_PRESFACT_CO_PRE                    ,
  RefId.PRODUCT_ID_PRE                                                                  as ACT_PRODUCT_ID_PRE                     ,
  RefId.SEG_COM_ID_PRE                                                                  as ACT_SEG_COM_ID_PRE                     ,
  RefId.SEG_COM_AGG_ID_PRE                                                              as ACT_SEG_COM_AGG_ID_PRE                 ,
  RefId.CODE_MIGR_PRE                                                                   as ACT_CODE_MIGR_PRE                      ,
  --Produit Vendu :
  Placement.PRESFACT_CO_OFFRE_OPT_ACQ                                                   as ACT_PRESFACT_CO_OFOPT_ACQ              ,
  RefId.PRODUCT_ID_FINAL                                                                as ACT_PRODUCT_ID_FINAL                   ,
  Placement.TYPE_OT_SO                                                                  as TYPE_OT_SO                             ,
  Placement.IN_CLIDOS                                                                   as IN_CLIDOS                              ,
  RefId.SEG_COM_ID_FINAL                                                                as ACT_SEG_COM_ID_FINAL                   ,
  RefId.SEG_COM_AGG_ID_FINAL                                                            as ACT_SEG_COM_AGG_ID_FINAL               ,
  RefId.CODE_MIGR_FINAL                                                                 as ACT_CODE_MIGR_FINAL                    ,
  RefId.TYPE_SERVICE_FINAL                                                              as ACT_TYPE_SERVICE_FINAL                 ,
  --Calcul de l'acte :
  RefId.TYPE_COMMANDE_ID                                                                as ACT_TYPE_COMMANDE_ID                   ,
  0                                                                                     as ACT_DELTA_TARIF                        ,
  null                                                                                  as ACT_UNITE_CD                          ,
  --Calcul de l'acte avec les différents cas de rejets :
  Case  
        --Cas de rejet sur les périodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  RefId.PERIODE_ID      = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit Placé est un produit inconnu de RefCom
        When  RefId.PRODUCT_ID_FINAL  = '${P_PIL_223}'
          Then '${P_PIL_224}'
        When RefId.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        --Cas de rejet sur le produit précédant, Produit Non retrouvé dans Pilcom et qu'il s'agit d'un OT -> ERR_ACTE_INCO_PRESTA_PRE_CALC_PILCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_215}' And Placement.TYPE_OT_SO ='OT'
          Then  '${P_PIL_218}'
        --Cas de rejet sur le produit précédant, Produit Non retrouvé dans RefCom et qu'il s'agit d'un OT-> ERR_ACTE_INCO_PRESTA_PRE_REFCOM_INCO
        When  RefId.PRODUCT_ID_PRE  = '${P_PIL_216}' And Placement.TYPE_OT_SO ='OT'
          Then  '${P_PIL_219}'
        --Si la migration de l'init vers le final n'est pas paramétrée -> ERR_ACTE_INCO_MIGR_NON_PARAM_REFCOM
        When  RefId.CODE_MIGR_PRE  Is Not Null And RefId.CODE_MIGR_FINAL Is Not Null And RefId.TYPE_COMMANDE_ID ='${P_PIL_045}'
          Then  '${P_PIL_222}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        --Sinon c'est un problème dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                                                   as ACT_CD                                 ,
  '${P_PIL_067}'                                                                        as ACT_REM_ID                             ,
  'N'                                                                                   as ACT_FLAG_ACT_REM                       ,
  RefId.PERIODE_ID                                                                      as ACT_PERIODE_ID                         ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                                              as ACT_PERIODE_STATUS                     ,
  EtatPeriode.PERIODE_CLOSURE_DT                                                        as ACT_PERIODE_CLOSURE_DT                 ,
  --Information sur le code prestation retrouvé en parc
  Coalesce(RefPer.INB_PRESFACT_ACQ_ADV,Placement.INB_PRESFACT_ACQ_ADV)                  as INB_PRESFACT_ACQ_ADV                   ,
  Coalesce(RefPer.INB_PRESFACT_ACQ_AGAP,Placement.INB_PRESFACT_ACQ_AGAP)                as INB_PRESFACT_ACQ_AGAP                  ,
  Coalesce(RefPer.INB_ORIGINE_PARC,'P')                                                 as INB_ORIGINE_PARC                       ,
  Coalesce(RefPer.SEG_PARC_DT_DEBUT,Placement.PARC_DT_DEBUT)                            as SEG_PARC_DT_DEBUT                      ,
  --Infos sur le canal de vente
  Placement.CANALVENTE                                                                  as ORG_CANAL_ID_SC                        ,
  Coalesce(OrigineVente.ORIG_DEM,Placement.CANALDEM)                                    as ORIG_DEM_SC                            ,
  Placement.CANALDEM                                                                    as INT_ORIGIN_CD                          ,
  Placement.INT_REASON_CD                                                               as INT_REASON_CD                          ,
  Placement.SOLDOFF_SRC_CD                                                              as INT_RESULT_CD                          ,
  Case  When OrigineVente.ORIG_DEM Is Null
          Then Placement.CANALDEM_MTHD
        Else Null
   End                                                                                  as CANALDEM_MTHD                          ,
  CanalVenteMacroPrem.ORG_CANAL_ID_MACRO                                                as ORG_CANAL_ID_MACRO_SC                  ,
  CanalVenteMacroPrem.ORG_CANAL_MACRO_LB                                                as ORG_CANAL_MACRO_LB_SC                  ,
  null                                                                                  as  FLAG_HD                               ,
  --Nouvelle RG Cannal :
  --Calcul du canal de vente Macro
  Coalesce(OrgChannelCho.ORG_CHANNEL_CD,'NONPARAM')                                     as ORG_CHANNEL_CD                         ,
  --Sous Canal
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                                                   as ORG_SUB_CHANNEL_CD                     ,
  --Sous-Sous-Canal
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_SUB_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                                                   as ORG_SUB_SUB_CHANNEL_CD                 ,
  --Canal de Rem
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_REM_CHANNEL_CD
        Else 'NONPAR'
  End                                                                                   as ORG_REM_CHANNEL_CD                     ,
  --Activité
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_GT_ACTIVITY
        Else 'NONPARAM'
  End                                                                                   as ORG_GT_ACTIVITY                        ,
  --Fidelisaion
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_FIDELISATION
        Else 'NONPARAM'
  End                                                                                   as ORG_FIDELISATION                       ,
  --Activité Web
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_WEB_ACTIVITY
        Else 'E'
  End                                                                                   as ORG_WEB_ACTIVITY                       ,
  --Activité Automatique
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_AUTO_ACTIVITY
        Else 'E'
  End                                                                                   as ORG_AUTO_ACTIVITY                      ,
  Placement.EDO_ID                                                                      as ORG_EDO_ID                             ,
  Placement.TYPE_EDO                                                                    as ORG_TYPE_EDO                           ,
  Placement.ORG_EDO_IOBSP                                                               as ORG_EDO_IOBSP                          ,
  OrgChannelCho.FLAG_PLT_CONV                                                           as ORG_FLAG_PLT_CONV                      ,
  Placement.FLAG_TEAM_MKT                                                               as ORG_FLAG_TEAM_MKT                      ,
  OrgChannelCho.ORG_FLAG_TYPE_CMP                                                       as ORG_FLAG_TYPE_CMP                      ,
  Placement.EDO_ID_HIER                                                                 as ORG_EDO_ID_HIER                        ,
  Placement.TYPE_EDO_HIER                                                               as ORG_TYPE_EDO_HIER                      ,
  --Alimentation Orga
  Placement.ORG_REF_TRAV                                                                as ORG_REF_TRAV                           ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.LOGIN_CREA)                                 as ORG_AGENT_ID                           ,
  Placement.ORG_AGENT_IOBSP                                                             as ORG_AGENT_IOBSP                        ,
  Placement.ORG_POC_XI                                                                  as ORG_POC_XI                             ,
  Placement.ORG_NOM                                                                     as ORG_NOM                                ,
  Placement.ORG_PRENOM                                                                  as ORG_PRENOM                             ,
  Placement.ORG_GROUPE_ID                                                               as ORG_GROUPE_ID                          ,
  Placement.ORG_GROUPE_ID_HIER                                                          as ORG_GROUPE_ID_HIER                     ,
  Placement.ORG_ACTVT_REEL                                                              as ORG_ACTVT_REEL                         ,
  Placement.ORG_RESP_REF_TRAV                                                           as ORG_RESP_REF_TRAV                      ,
  Coalesce(Placement.ORG_RESP_AGENT_ID,Placement.LOGIN_RESP)                            as ORG_RESP_AGENT_ID                      ,
  Placement.ORG_RESP_XI                                                                 as ORG_RESP_XI                            ,
  Placement.ORG_RESP_ACTVT_REEL                                                         as ORG_RESP_ACTVT_REEL                    ,
  Null                                                                                  as ORG_RESP_EDO_ID                        ,
  Null                                                                                  as ORG_RESP_TYPE_EDO                      ,
  Null                                                                                  as ORG_RESP_FLAG_PLT_CONV                 ,
  Trim(HierO3.ORG_TEAM_LEVEL_1_CD)                                                      as ORG_TEAM_LEVEL_1_CD                    ,
  HierO3.ORG_TEAM_LEVEL_1_DS                                                            as ORG_TEAM_LEVEL_1_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_2_CD)                                                      as ORG_TEAM_LEVEL_2_CD                    ,
  HierO3.ORG_TEAM_LEVEL_2_DS                                                            as ORG_TEAM_LEVEL_2_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_3_CD)                                                      as ORG_TEAM_LEVEL_3_CD                    ,
  HierO3.ORG_TEAM_LEVEL_3_DS                                                            as ORG_TEAM_LEVEL_3_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_4_CD)                                                      as ORG_TEAM_LEVEL_4_CD                    ,
  HierO3.ORG_TEAM_LEVEL_4_DS                                                            as ORG_TEAM_LEVEL_4_DS                    ,
  Trim(HierO3.WORK_TEAM_LEVEL_1_CD)                                                     as WORK_TEAM_LEVEL_1_CD                   ,
  HierO3.WORK_TEAM_LEVEL_1_DS                                                           as WORK_TEAM_LEVEL_1_DS                   ,
  Trim(HierO3.WORK_TEAM_LEVEL_2_CD)                                                     as WORK_TEAM_LEVEL_2_CD                   ,
  HierO3.WORK_TEAM_LEVEL_2_DS                                                           as WORK_TEAM_LEVEL_2_DS                   ,
  Trim(HierO3.WORK_TEAM_LEVEL_3_CD)                                                     as WORK_TEAM_LEVEL_3_CD                   ,
  HierO3.WORK_TEAM_LEVEL_3_DS                                                           as WORK_TEAM_LEVEL_3_DS                   ,
  Trim(HierO3.WORK_TEAM_LEVEL_4_CD)                                                     as WORK_TEAM_LEVEL_4_CD                   ,
  HierO3.WORK_TEAM_LEVEL_4_DS                                                           as WORK_TEAM_LEVEL_4_DS                   ,
  --Information client
  Placement.CLIENT_NU                                                                   as CLIENT_NU                              ,
  Placement.CLIENT_NU_NEW_PORTE                                                         as CLIENT_NU_NEW_PORTE                    ,
  Placement.DOSSIER_NU                                                                  as DOSSIER_NU                             ,
  Placement.DOSSIER_NU_NEW_PORTE                                                        as DOSSIER_NU_NEW_PORTE                   ,
  Placement.DOSSIER_DATE_ACTIV                                                          as DOSSIER_DATE_ACTIV                     ,
  Placement.DOSSIER_DATE_RESIL                                                          as DOSSIER_DATE_RESIL                     ,
  Placement.DOSSIER_TYPE_RESIL                                                          as DOSSIER_TYPE_RESIL                     ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as DOSSIER_MOTIF_RESIL                    ,
  --Alimentation des champs de convergence :
  Placement.DMC_LINE_ID                                                                 as DMC_LINE_ID                            ,
  Placement.DMC_MASTER_LINE_ID                                                          as DMC_MASTER_LINE_ID                     ,
  Placement.DMC_LINE_TYPE                                                               as DMC_LINE_TYPE                          ,
  Placement.DMC_ACTIVATION_DT                                                           as DMC_ACTIVATION_DT                      ,
    ---
  Placement.PAR_DEPRTMNT_ID                                                             As PAR_DEPRTMNT_ID                        ,
  Placement.PAR_POSTAL_CD                                                               As PAR_POSTAL_CD                          ,
  Placement.PAR_BU_CD                                                                   As PAR_BU_CD                              ,
  Placement.PAR_GEO_MACROZONE                                                           As PAR_GEO_MACROZONE                      ,
  Placement.PAR_UNIFIED_PARTY_ID                                                        As PAR_UNIFIED_PARTY_ID                   ,
  Placement.PAR_PARTY_REGRPMNT_ID                                                       As PAR_PARTY_REGRPMNT_ID                  ,
  Placement.PAR_IRIS2000_CD                                                             As PAR_IRIS2000_CD                        ,
  Placement.PAR_FIBER_IN                                                                As PAR_FIBER_IN                           ,
   --
  Placement.DMC_CONVERGENT_IN                                                           as DMC_CONVERGENT_IN                      ,
  Placement.DMC_LINE_ID_INT                                                             as DMC_LINE_ID_INT                        ,
  Placement.DMC_LINE_TYPE_INT                                                           as DMC_LINE_TYPE_INT                      ,
  Placement.DMC_ACTIVATION_DT_INT                                                       as DMC_ACTIVATION_DT_INT                  ,
  Placement.DMC_SERVICE_ACCESS_ID                                                       as DMC_SERVICE_ACCESS_ID                  ,
  Placement.OFFRE_INT_PRE                                                               as OFFRE_INT_PRE                          ,
  --Alim Infos Clients
  Placement.OTO_OSCAR_VALUE_NU                                                          as OTO_OSCAR_VALUE_NU                     ,
  Placement.PAR_LASTNAME                                                                as PAR_LASTNAME                           ,
  Placement.PAR_FIRSTNAME                                                               as PAR_FIRSTNAME                          ,
  Placement.PAR_TYPE                                                                    as PAR_TYPE                               ,
  Placement.PAR_IMSI                                                                    as PAR_IMSI                               ,
  Placement.PAR_EMAIL                                                                   as PAR_EMAIL                              ,
  Placement.PAR_BILL_ADRESS_1                                                           as PAR_BILL_ADRESS_1                      ,
  Placement.PAR_BILL_ADRESS_2                                                           as PAR_BILL_ADRESS_2                      ,
  Placement.PAR_BILL_ADRESS_3                                                           as PAR_BILL_ADRESS_3                      ,
  Placement.PAR_BILL_ADRESS_4                                                           as PAR_BILL_ADRESS_4                      ,
  Placement.PAR_BILL_VILLE                                                              as PAR_BILL_VILLE                         ,
  Placement.PAR_BILL_CD_POSTAL                                                          as PAR_BILL_CD_POSTAL                     ,
  Placement.PAR_INSEE_CD                                                                as PAR_INSEE_CD                           ,
  Placement.PAR_DO                                                                      as PAR_DO                                 ,
  Placement.PAR_USCM                                                                    as PAR_USCM                               ,
  Placement.PAR_USCM_DS                                                                 as PAR_USCM_DS                            ,
  Placement.PAR_USCM_USCM_DS                                                            as PAR_USCM_USCM_DS                       ,
  Placement.PAR_USCM_REGUSCM                                                            as PAR_USCM_REGUSCM                       ,
  Placement.PAR_USCM_REGUSCM_DS                                                         as PAR_USCM_REGUSCM_DS                    ,
  Placement.PAR_AID                                                                     as PAR_AID                                ,
  Placement.PAR_ND                                                                      as PAR_ND                                 ,
  Placement.PAR_MOB_IMEI                                                                as PAR_MOB_IMEI                           ,
  Placement.PAR_MOB_TAC                                                                 as PAR_MOB_TAC                            ,
  Placement.PAR_MOB_SIM                                                                 as PAR_MOB_SIM                            ,
  --Segementation client :
  Placement.PAR_SCORE_NU_MOB                                                            as PAR_SCORE_NU_MOB                       ,
  Placement.PAR_SCORE_IN_MOB                                                            as PAR_SCORE_IN_MOB                       ,
  Placement.PAR_TRESHOLD_NU_MOB                                                         as PAR_TRESHOLD_NU_MOB                    ,
  Placement.PAR_SCORE_NU_INT                                                            as PAR_SCORE_NU_INT                       ,
  Placement.PAR_SCORE_IN_INT                                                            as PAR_SCORE_IN_INT                       ,
  Placement.PAR_TRESHOLD_NU_INT                                                         as PAR_TRESHOLD_NU_INT                    ,
  --Contrat Avec le client :
  Placement.CONTRCT_DT_SIGN_PREC                                                        as CONTRCT_DT_SIGN_PREC                   ,
  Placement.CONTRCT_DT_FIN_PREC                                                         as CONTRCT_DT_FIN_PREC                    ,
  Placement.CONTRCT_DT_SIGN_POST                                                        as CONTRCT_DT_SIGN_POST                   ,
  Placement.CONTRCT_DUREE_ENG                                                           as CONTRCT_DUREE_ENG                      ,
  Placement.CONTRCT_UNIT_ENG                                                            as CONTRCT_UNIT_ENG                       ,
  --Attributs de pérénité   :
  RefPer.CONFIRMATION_IN                                                                as CONFIRMATION_IN                        ,
  RefPer.CONFIRMATION_DT                                                                as CONFIRMATION_DT                        ,
  RefPer.CONFIRMATION_CALC_FIN_DT                                                       as CONFIRMATION_CALC_FIN_DT               ,
  RefPer.DELIVERY_IN                                                                    as DELIVERY_IN                            ,
  RefPer.DELIVERY_DT                                                                    as DELIVERY_DT                            ,
  RefPer.DELIVERY_CALC_FIN_DT                                                           as DELIVERY_CALC_FIN_DT                   ,
  RefPer.PERENNITE_IN                                                                   as PERENNITE_IN                           ,
  RefPer.PERENNITE_FIN_DT                                                               as PERENNITE_FIN_DT                       ,
  RefPer.PERENNITE_CALC_FIN_DT                                                          as PERENNITE_CALC_FIN_DT                  ,
  Null                                                                                  as PERENNITE_PVC_IN                       ,
  Null                                                                                  as PERENNITE_PVC_FIN_DT                   ,
  Null                                                                                  as PERENNITE_PVC_CALC_FIN_DT              ,
  Null                                                                                  as PERNNT_IN                              ,
  Null                                                                                  as PERNNT_MOTIF                           ,
  Null                                                                                  as PERNNT_END_DT                          ,
  Null                                                                                  as PERNNT_CALC_END_DT                     ,
  Null                                                                                  as ORDER_CANCELING_DT                     ,
  Null                                                                                  as SEG_PRES_PARC_COMMANDE                 ,
  Null                                                                                  as MIGRA_DT                               ,
  Null                                                                                  as MIGRA_NEXT_OFFRE                       ,
  Null                                                                                  as RESIL_INT_DT                           ,
  Null                                                                                  as RESIL_INT_MOTIF                        ,
  Null                                                                                  as RESIL_INT_MOTIF_DS                     ,
  Null                                                                                  as SEG_COM_ID_LAST_PER                    ,
  Null                                                                                  as SEG_COM_ID_SOLD                        ,
  Null                                                                                  as SEG_COM_ID_FIND                        ,
  Null                                                                                  as SEG_FIND_LIVR_DT                       ,
  Null                                                                                  as SEG_FIND_CANCEL_DT                     ,
  Null                                                                                  as SEG_COM_ID_NEXT_PARC                   ,
  Null                                                                                  as SEG_NEXT_PARC_LIVR_DT                  ,
  Null                                                                                  as SEG_NEXT_PARC_CANCEL_DT                ,
  Null                                                                                  as SEG_COM_ID_FINAL_PARC                  ,
  Null                                                                                  as SEG_FINAL_PARC_LIVR_DT                 ,
  Null                                                                                  as SEG_FINAL_PARC_CANCEL_DT               ,
  Null                                                                                  as SEG_COM_ID_LAST_IN_PARC                ,
  Null                                                                                  as NB_IN_OUT_PARC                         ,
  Null                                                                                  as POURCENTAGE_PRES_PARC                  ,
  --Calcul si la livraison à eu lieu dans les temps :
  Case  When RefPer.DELIVERY_DT is Null
          Then 'NA'
        When Delais.DELAIS is Null 
          --Dans le cas où le delais est null alors on a pas pu évaluer : NC
          Then 'NC'
        When ( Placement.INT_DEPOSIT_DT + Cast(Delais.DELAIS as interval day(4))) >= RefPer.DELIVERY_DT
          -- Dans le cas où on est dans le délais :
          Then  'O'
          --Sinon on n'est pas dans les clous
        Else    'N'
  End                                                                                   as DELIVERY_ONTIME_IN                     ,
  Coalesce(Delais.DELAIS,-1)                                                            as DELIVERY_DEAD_LINE_NU                  ,
  'NA'                                                                                  as CONCURENCE_IN                          ,
  'NA'                                                                                  as CONCURENCE_CONCLU_IN                   ,
  Null                                                                                  as CONCURENCE_ID                          ,
  ----------------------------------------------------------------------------
  Null                                                                                  as SEG_COM_ID_ORDER_ID                    ,
  Null                                                                                  as SEG_ORDER_DT                           ,
  Null                                                                                  as SEG_CANCEL_DT                          ,
  Null                                                                                  as SEG_COM_ID_NEXT_ORDER                  ,
  Null                                                                                  as SEG_NEXT_ORDER_DT                      ,
  Null                                                                                  as SEG_NEXT_CANCEL_DT                     ,
  Null                                                                                  as SEG_COM_ID_FINAL_ORDER                 ,
  Null                                                                                  as SEG_FINAL_ORDER_DT                     ,
  Null                                                                                  as SEG_FINAL_ORDER_CANCEL_DT              ,
  ----------------------------------------------------------------------------
  Null                                                                                  as CHECK_INITIAL_STATUS_CD                ,
  RetournCSO.CHECK_NAT_STATUS_CD                                                        as CHECK_NAT_STATUS_CD                    ,
  RetournCSO.CHECK_NAT_COMMENT                                                          as CHECK_NAT_COMMENT                      ,
  RetournCSO.CHECK_NAT_STATUS_LN                                                        as CHECK_NAT_STATUS_LN                    ,
  RetournCSO.CHECK_LOC_STATUS_CD                                                        as CHECK_LOC_STATUS_CD                    ,
  RetournCSO.CHECK_LOC_COMMENT                                                          as CHECK_LOC_COMMENT                      ,
  RetournCSO.CHECK_LOC_STATUS_LN                                                        as CHECK_LOC_STATUS_LN                    ,
  RetournCSO.CHECK_VALIDT_DT                                                            as CHECK_VALIDT_DT                        ,
  Null                                                                                  as CLOSURE_DT                             ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                            ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS                          ,
  1                                                                                     as FRESH_IN                               ,
  0                                                                                     as COHERENCE_IN                           ,
  0                                                                                     as HOT_IN
From
  ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO Placement
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CALC RefId
    On    Placement.ACTE_ID                             = RefId.ACTE_ID
      And Placement.INT_DEPOSIT_DT                      = RefId.INT_DEPOSIT_DT
  Inner Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER RefPer
    On    RefPer.ACTE_ID                                = RefId.ACTE_ID
      And RefPer.INT_DEPOSIT_DT                         = RefId.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On    RefId.TYPE_COMMANDE_ID                        = Delais.TYPE_COMMANDE_ID
      And RefId.TYPE_SERVICE_FINAL                      = Delais.TYPE_SERVICE
      And RefId.PERIODE_ID                              = Delais.PERIODE_ID
      And Delais.FRESH_IN                               = 1
      And Delais.CURRENT_IN                             = 1
      And Delais.CLOSURE_DT                             is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_ORIG_DEM OrigineVente
    On    Placement.ORG_REF_TRAV                        =  OrigineVente.ORG_REF_TRAV
      And Placement.ORG_GROUPE_ID                       =  OrigineVente.ORG_GROUPE_ID
      And Placement.PLTF_CO                             =  OrigineVente.APPLI_SOURCE_ID
      And Placement.INT_DEPOSIT_DT                      >= OrigineVente.GRP_DT_DEB
      And Placement.INT_DEPOSIT_DT                      <= OrigineVente.GRP_DT_FIN
      And OrigineVente.FRESH_IN                         =  1
      And OrigineVente.CURRENT_IN                       =  1
      And OrigineVente.CLOSURE_DT                       is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_CANAL_VENTE CanalVenteMacroPrem
    On    OrigineVente.ORIG_DEM                         = CanalVenteMacroPrem.ORIG_DEM
      And CanalVenteMacroPrem.FRESH_IN                  = 1
      And CanalVenteMacroPrem.CURRENT_IN                = 1
      And CanalVenteMacroPrem.CLOSURE_DT                is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_CHO OrgChannelCho
    On    Placement.RESOLU_ID                                                                                               = OrgChannelCho.RESOLU_ID
      And Case When COALESCE(Placement.PAR_SCORE_IN_MOB, 0) = ${P_PIL_419} THEN '${P_PIL_417}' ELSE '${P_PIL_416}' End      = OrgChannelCho.PAR_SCORE_IN_MOB
      And Case When COALESCE(Placement.CANALDEM, '${P_PIL_418}')  IN (${L_PIL_042}) THEN Placement.CANALDEM ELSE '#' End    = OrgChannelCho.CANALDEM
      And Case When (Placement.FLAG_PLT_CONV IS NULL AND Placement.CANALDEM = '${P_PIL_436}') Then 1
               Else Coalesce(Placement.FLAG_PLT_CONV, 0)
          End                                                                                                               = OrgChannelCho.FLAG_PLT_CONV
      And Coalesce(Placement.FLAG_PLT_SCH, 0)                                                                               = OrgChannelCho.FLAG_PLT_SCH
      AND Coalesce(Placement.FLAG_TYPE_CMP, '${P_PIL_418}')                                                                 = OrgChannelCho.ORG_FLAG_TYPE_CMP
    --Jointure pour récupérer la hierarchie O3:
  Left Outer Join ${KNB_PCO_TMP}.ORD_T_CALC_ACT_CHO_O3 HierO3
    On    Placement.ACTE_ID        = HierO3.ACTE_ID
      And Placement.INT_DEPOSIT_DT = HierO3.DATE_SAISIE
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    RefId.PERIODE_ID                                    = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                              = 1
      And EtatPeriode.FRESH_IN                                = 1
      And EtatPeriode.CLOSURE_DT                              Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                                   = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG                       = 1
      And RetournCSO.CURRENT_IN                               = 1
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID                                   = RetourGRV.ACTE_ID
      And Placement.INT_DEPOSIT_DT                            = RetourGRV.ORDER_DEPOSIT_DT
Where
  (1=1)
  And
      ( 
        --On veut suivre les produits :
            --Qui sont sur une période valable :
                RefId.PERIODE_ID        = ${P_PIL_049}
            --Dont le produit est défini dans le référentiel 
            Or RefId.PRODUCT_ID_FINAL  in ('${P_PIL_223}')
            --Et qui sont sur un segment suivi
            Or RefId.SEG_COM_ID_FINAL  in ('${P_PIL_022}','${P_PIL_295}')
      )
  --And Placement.HOT_IN = 0
--Insertion des PCM
;Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_CHO
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                               ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  RSFCOMMENTAIRE_DS                         ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRESFACT_CO_PRE                       ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRESFACT_CO_OFOPT_ACQ                 ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_UNITE_CD                              ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_ACTE_VALO                             ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  INB_ORIGINE_PARC                          ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID_SC                           ,
  ORIG_DEM_SC                               ,
  INT_ORIGIN_CD                             ,
  INT_REASON_CD                             ,
  INT_RESULT_CD                             ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO_SC                     ,
  ORG_CANAL_MACRO_LB_SC                     ,
  FLAG_HD                                   ,
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  ORG_EDO_IOBSP                             ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         ,
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_AGENT_IOBSP                           ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_ACTVT_REEL                       ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,  
  CLIENT_NU                                 ,
  CLIENT_NU_NEW_PORTE                       ,
  DOSSIER_NU                                ,
  DOSSIER_NU_NEW_PORTE                      ,
  DOSSIER_DATE_ACTIV                        ,
  DOSSIER_DATE_RESIL                        ,
  DOSSIER_TYPE_RESIL                        ,
  DOSSIER_MOTIF_RESIL                       ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  DMC_LINE_TYPE                             ,
  DMC_ACTIVATION_DT                         ,
  --------
  PAR_DEPRTMNT_ID                           ,
  PAR_POSTAL_CD                             ,
  PAR_BU_CD                                 ,
  PAR_GEO_MACROZONE                         ,
  PAR_UNIFIED_PARTY_ID                      , 
  PAR_PARTY_REGRPMNT_ID                     ,
  PAR_IRIS2000_CD                           ,
  PAR_FIBER_IN                              ,
  ----
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU_MOB                          ,
  PAR_SCORE_IN_MOB                          ,
  PAR_TRESHOLD_NU_MOB                       ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,  
  PERENNITE_PVC_FIN_DT                      ,  
  PERENNITE_PVC_CALC_FIN_DT                 ,  
  PERNNT_IN                                 ,
  PERNNT_END_DT                             ,
  PERNNT_MOTIF                              ,
  PERNNT_CALC_END_DT                        ,
  ORDER_CANCELING_DT                        ,
  SEG_PRES_PARC_COMMANDE                    ,  
  MIGRA_DT                                  ,  
  MIGRA_NEXT_OFFRE                          ,  
  RESIL_INT_DT                              ,  
  RESIL_INT_MOTIF                           ,  
  RESIL_INT_MOTIF_DS                        ,  
  SEG_COM_ID_LAST_PER                       ,  
  SEG_COM_ID_SOLD                           ,  
  SEG_COM_ID_FIND                           ,  
  SEG_FIND_LIVR_DT                          ,  
  SEG_FIND_CANCEL_DT                        ,  
  SEG_COM_ID_NEXT_PARC                      ,  
  SEG_NEXT_PARC_LIVR_DT                     ,  
  SEG_NEXT_PARC_CANCEL_DT                   ,  
  SEG_COM_ID_FINAL_PARC                     ,  
  SEG_FINAL_PARC_LIVR_DT                    ,  
  SEG_FINAL_PARC_CANCEL_DT                  ,  
  SEG_COM_ID_LAST_IN_PARC                   ,  
  NB_IN_OUT_PARC                            ,  
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  DELIVERY_DEAD_LINE_NU                     ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  SEG_COM_ID_ORDER_ID                       ,
  SEG_ORDER_DT                              ,
  SEG_CANCEL_DT                             ,
  SEG_COM_ID_NEXT_ORDER                     ,
  SEG_NEXT_ORDER_DT                         ,
  SEG_NEXT_CANCEL_DT                        ,
  SEG_COM_ID_FINAL_ORDER                    ,
  SEG_FINAL_ORDER_DT                        ,
  SEG_FINAL_ORDER_CANCEL_DT                 ,
  CHECK_INITIAL_STATUS_CD                   ,
  CHECK_NAT_STATUS_CD                       ,
  CHECK_NAT_COMMENT                         ,
  CHECK_NAT_STATUS_LN                       ,
  CHECK_LOC_STATUS_CD                       ,
  CHECK_LOC_COMMENT                         ,
  CHECK_LOC_STATUS_LN                       ,
  CHECK_VALIDT_DT                           ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              ,
  HOT_IN                                    
)
Select
  Placement.ACTE_ID                                                                     as ACTE_ID                                ,
  Placement.ACTE_ID                                                                     as ACTE_ID_GEN                            ,
  Placement.DEMANDE_ID                                                                  as DEMANDE_ID                             ,
  Placement.EXTERNAL_INT_ID                                                             as EXTERNAL_INT_ID                        ,
  Placement.INT_DEPOSIT_TS                                                              as INT_DEPOSIT_TS                         ,
  Placement.INT_DEPOSIT_DT                                                              as INT_DEPOSIT_DT                         ,
  Placement.OPERATOR_PROVIDER_ID                                                        as OPERATOR_PROVIDER_ID                   ,
  Placement.RESOLU_ID                                                                   as RESOLU_ID                              ,
  Placement.CONCLU_ID                                                                   as CONCLU_ID                              ,
  Placement.SSCONCLU_ID                                                                 as SSCONCLU_ID                            ,
  Placement.INT_MODIF_TS                                                                as INT_MODIF_TS                           ,
  --Information sur la source :
  Placement.PLTF_CO                                                                     as PLTF_CO                                ,
  Placement.INTRNL_SOURCE_ID                                                            as INTRNL_SOURCE_ID                       ,
  --Info de chorus
  Placement.SOLDOFF_SRC_CD                                                              as SOLDOFF_SRC_CD                         ,
  Placement.RSFCOMMENTAIRE_DS                                                           as RSFCOMMENTAIRE_DS                       ,
  Placement.OTO_OFFER_CD                                                                as OTO_OFFER_CD                           ,
  Placement.OTO_OFFER_TYPE_CD                                                           as OTO_OFFER_TYPE_CD                      ,
  --Information Liée aux produit et acte :
  --produit precedant :
  Placement.PRESFACT_CO_PRECED                                                          as ACT_PRESFACT_CO_PRE                    ,
  NULL                                                                                  as ACT_PRODUCT_ID_PRE                     ,
  NULL                                                                                  as ACT_SEG_COM_ID_PRE                     ,
  NULL                                                                                  as ACT_SEG_COM_AGG_ID_PRE                 ,
  NULL                                                                                  as ACT_CODE_MIGR_PRE                      ,
  --Produit Vendu :
  Placement.PRESFACT_CO_OFFRE_OPT_ACQ                                                   as ACT_PRESFACT_CO_OFOPT_ACQ              ,
  NULL                                                                                  as ACT_PRODUCT_ID_FINAL                   ,
  Placement.TYPE_OT_SO                                                                  as TYPE_OT_SO                             ,
  Placement.IN_CLIDOS                                                                   as IN_CLIDOS                              ,
  NULL                                                                                  as ACT_SEG_COM_ID_FINAL                   ,
  NULL                                                                                  as ACT_SEG_COM_AGG_ID_FINAL               ,
  NULL                                                                                  as ACT_CODE_MIGR_FINAL                    ,
  NULL                                                                                  as ACT_TYPE_SERVICE_FINAL                 ,
  --Calcul de l'acte :
  NULL                                                                                  as ACT_TYPE_COMMANDE_ID                   ,
--Unité = NB
  Case When RefActeSC.UNITE_CD ='${P_PIL_620}'
         Then RefId.DELTA_TARIF 
    --Unité  CA_MARKET 
      When RefActeSC.UNITE_CD ='${P_PIL_623}'
           then RefActeSC.CA_MARKETING 
       Else Coalesce(RefId.DELTA_TARIF,0)
  End                                                                                   as ACT_DELTA_TARIF                       ,
  RefActeSC.UNITE_CD                                                                    as ACT_UNITE_CD                          ,
  --Calcul de l'acte avec les différents cas de rejets :
  '${P_PIL_413}'                                                                        as ACT_CD                                 ,
  '${P_PIL_067}'                                                                        as ACT_REM_ID                             ,
  'N'                                                                                   as ACT_FLAG_ACT_REM                       ,
     --Unité = NB
  Case When RefActeSC.UNITE_CD ='${P_PIL_620}'
         Then RefActeSC.ACTE_VALO
  --Unité = CA_MARKET 
       When RefActeSC.UNITE_CD  ='${P_PIL_623}' 
         Then  ( ACT_DELTA_TARIF * RefActeSC.TAUX_MARGE ) 
       Else   Coalesce(RefActeSC.ACTE_VALO,0)
  End                                                                                   as ACT_ACTE_VALO                          ,
  -1                                                                                    as ACT_PERIODE_ID                         ,
  Null                                                                                  as ACT_PERIODE_STATUS                     ,
  Null                                                                                  as ACT_PERIODE_CLOSURE_DT                 ,
  --Information sur le code prestation retrouvé en parc
  Placement.INB_PRESFACT_ACQ_ADV                                                        as INB_PRESFACT_ACQ_ADV                   ,
  Placement.INB_PRESFACT_ACQ_AGAP                                                       as INB_PRESFACT_ACQ_AGAP                  ,
  'P'                                                                                   as INB_ORIGINE_PARC                       ,
  Placement.PARC_DT_DEBUT                                                               as SEG_PARC_DT_DEBUT                      ,
  --Infos sur le canal de vente
  Placement.CANALVENTE                                                                  as ORG_CANAL_ID_SC                        ,
  Coalesce(OrigineVente.ORIG_DEM,Placement.CANALDEM)                                    as ORIG_DEM_SC                            ,
  Placement.CANALDEM                                                                    as INT_ORIGIN_CD                          ,
  Placement.INT_REASON_CD                                                               as INT_REASON_CD                          ,
  Placement.SOLDOFF_SRC_CD                                                              as INT_RESULT_CD                          ,
  Case  When OrigineVente.ORIG_DEM Is Null
          Then Placement.CANALDEM_MTHD
        Else Null
   End                                                                                  as CANALDEM_MTHD                          ,
  CanalVenteMacroPrem.ORG_CANAL_ID_MACRO                                                as ORG_CANAL_ID_MACRO_SC                  ,
  CanalVenteMacroPrem.ORG_CANAL_MACRO_LB                                                as ORG_CANAL_MACRO_LB_SC                  ,
  KPI_PILCOM.HUMAINDIGITAL                                                              as FLAG_HD                                ,
  --Nouvelle RG Cannal :
  --Calcul du canal de vente Macro
  Coalesce(OrgChannelCho.ORG_CHANNEL_CD,'NONPARAM')                                     as ORG_CHANNEL_CD                         ,
  --Sous Canal
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                                                   as ORG_SUB_CHANNEL_CD                     ,
  --Sous-Sous-Canal
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_SUB_SUB_CHANNEL_CD
        Else 'NONPARAM'
  End                                                                                   as ORG_SUB_SUB_CHANNEL_CD                 ,
  --Canal de Rem
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_REM_CHANNEL_CD
        Else 'NONPAR'
  End                                                                                   as ORG_REM_CHANNEL_CD                     ,
  --Activité
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_GT_ACTIVITY
        Else 'NONPARAM'
  End                                                                                   as ORG_GT_ACTIVITY                        ,
  --Fidelisaion
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_FIDELISATION
        Else 'NONPARAM'
  End                                                                                   as ORG_FIDELISATION                       ,
  --Activité Web
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_WEB_ACTIVITY
        Else 'E'
  End                                                                                   as ORG_WEB_ACTIVITY                       ,
  --Activité Automatique
  Case  When OrgChannelCho.ORG_CHANNEL_CD Is Not Null
          Then OrgChannelCho.ORG_AUTO_ACTIVITY
        Else 'E'
  End                                                                                   as ORG_AUTO_ACTIVITY                      ,  
  Placement.EDO_ID                                                                      as ORG_EDO_ID                             ,
  Placement.TYPE_EDO                                                                    as ORG_TYPE_EDO                           ,
  Placement.ORG_EDO_IOBSP                                                               as ORG_EDO_IOBSP                          ,
  OrgChannelCho.FLAG_PLT_CONV                                                           as ORG_FLAG_PLT_CONV                      ,
  Placement.FLAG_TEAM_MKT                                                               as ORG_FLAG_TEAM_MKT                      ,
  OrgChannelCho.ORG_FLAG_TYPE_CMP                                                       as ORG_FLAG_TYPE_CMP                      ,
    Placement.EDO_ID_HIER                                                               as ORG_EDO_ID_HIER                             ,
  Placement.TYPE_EDO_HIER                                                               as ORG_TYPE_EDO_HIER                           ,
  --Alimentation Orga
  Placement.ORG_REF_TRAV                                                                as ORG_REF_TRAV                           ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.LOGIN_CREA)                                 as ORG_AGENT_ID                           ,
  Placement.ORG_AGENT_IOBSP                                                             as ORG_AGENT_IOBSP                        ,
  Placement.ORG_POC_XI                                                                  as ORG_POC_XI                             ,
  Placement.ORG_NOM                                                                     as ORG_NOM                                ,
  Placement.ORG_PRENOM                                                                  as ORG_PRENOM                             ,
  Placement.ORG_GROUPE_ID                                                               as ORG_GROUPE_ID                          ,
  Placement.ORG_GROUPE_ID_HIER                                                          as ORG_GROUPE_ID_HIER                          ,
  Placement.ORG_ACTVT_REEL                                                              as ORG_ACTVT_REEL                         ,
  Placement.ORG_RESP_REF_TRAV                                                           as ORG_RESP_REF_TRAV                      ,
  Coalesce(Placement.ORG_RESP_AGENT_ID,Placement.LOGIN_RESP)                            as ORG_RESP_AGENT_ID                      ,
  Placement.ORG_RESP_XI                                                                 as ORG_RESP_XI                            ,
  Placement.ORG_RESP_ACTVT_REEL                                                         as ORG_RESP_ACTVT_REEL                    ,
  Null                                                                                  as ORG_RESP_EDO_ID                        ,
  Null                                                                                  as ORG_RESP_TYPE_EDO                      ,
  Null                                                                                  as ORG_RESP_FLAG_PLT_CONV                 ,
  Trim(HierO3.ORG_TEAM_LEVEL_1_CD)                                                      as ORG_TEAM_LEVEL_1_CD                    ,
  HierO3.ORG_TEAM_LEVEL_1_DS                                                            as ORG_TEAM_LEVEL_1_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_2_CD)                                                      as ORG_TEAM_LEVEL_2_CD                    ,
  HierO3.ORG_TEAM_LEVEL_2_DS                                                            as ORG_TEAM_LEVEL_2_DS                    ,
  Trim(HierO3.ORG_TEAM_LEVEL_3_CD)                                                      as ORG_TEAM_LEVEL_3_CD                    ,
  HierO3.ORG_TEAM_LEVEL_3_DS                                                            as ORG_TEAM_LEVEL_3_DS          ,
  Trim(HierO3.ORG_TEAM_LEVEL_4_CD)                                                      as ORG_TEAM_LEVEL_4_CD          ,
  HierO3.ORG_TEAM_LEVEL_4_DS                                                            as ORG_TEAM_LEVEL_4_DS          ,
  Trim(HierO3.WORK_TEAM_LEVEL_1_CD)                                                     as WORK_TEAM_LEVEL_1_CD         ,
  HierO3.WORK_TEAM_LEVEL_1_DS                                                           as WORK_TEAM_LEVEL_1_DS         ,
  Trim(HierO3.WORK_TEAM_LEVEL_2_CD)                                                     as WORK_TEAM_LEVEL_2_CD         ,
  HierO3.WORK_TEAM_LEVEL_2_DS                                                           as WORK_TEAM_LEVEL_2_DS         ,
  Trim(HierO3.WORK_TEAM_LEVEL_3_CD)                                                     as WORK_TEAM_LEVEL_3_CD         ,
  HierO3.WORK_TEAM_LEVEL_3_DS                                                           as WORK_TEAM_LEVEL_3_DS         ,
  Trim(HierO3.WORK_TEAM_LEVEL_4_CD)                                                     as WORK_TEAM_LEVEL_4_CD         ,
  HierO3.WORK_TEAM_LEVEL_4_DS                                                           as WORK_TEAM_LEVEL_4_DS         ,
  --Information client
  Placement.CLIENT_NU                                                                   as CLIENT_NU                              ,
  Placement.CLIENT_NU_NEW_PORTE                                                         as CLIENT_NU_NEW_PORTE                    ,
  Placement.DOSSIER_NU                                                                  as DOSSIER_NU                             ,
  Placement.DOSSIER_NU_NEW_PORTE                                                        as DOSSIER_NU_NEW_PORTE                   ,
  Placement.DOSSIER_DATE_ACTIV                                                          as DOSSIER_DATE_ACTIV                     ,
  Placement.DOSSIER_DATE_RESIL                                                          as DOSSIER_DATE_RESIL                     ,
  Placement.DOSSIER_TYPE_RESIL                                                          as DOSSIER_TYPE_RESIL                     ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as DOSSIER_MOTIF_RESIL                    ,
  --Alimentation des champs de convergence :
  Placement.DMC_LINE_ID                                                                 as DMC_LINE_ID                            ,
  Placement.DMC_MASTER_LINE_ID                                                          as DMC_MASTER_LINE_ID                     ,
  Placement.DMC_LINE_TYPE                                                               as DMC_LINE_TYPE                          ,
  Placement.DMC_ACTIVATION_DT                                                           as DMC_ACTIVATION_DT                      ,
  ---
  Placement.PAR_DEPRTMNT_ID                                                             As PAR_DEPRTMNT_ID                        ,
  Placement.PAR_POSTAL_CD                                                               As PAR_POSTAL_CD                          ,
  Placement.PAR_BU_CD                                                                   As PAR_BU_CD                              ,
  Placement.PAR_GEO_MACROZONE                                                           As PAR_GEO_MACROZONE                       ,
  Placement.PAR_UNIFIED_PARTY_ID                                                        As PAR_UNIFIED_PARTY_ID                    ,
  Placement.PAR_PARTY_REGRPMNT_ID                                                       As PAR_PARTY_REGRPMNT_ID                   ,
  Placement.PAR_IRIS2000_CD                                                             As PAR_IRIS2000_CD                        ,
  Placement.PAR_FIBER_IN                                                                As PAR_FIBER_IN                           ,
--- 
  Placement.DMC_CONVERGENT_IN                                                           as DMC_CONVERGENT_IN                      ,
  Placement.DMC_LINE_ID_INT                                                             as DMC_LINE_ID_INT                        ,
  Placement.DMC_LINE_TYPE_INT                                                           as DMC_LINE_TYPE_INT                      ,
  Placement.DMC_ACTIVATION_DT_INT                                                       as DMC_ACTIVATION_DT_INT                  ,
  Placement.DMC_SERVICE_ACCESS_ID                                                       as DMC_SERVICE_ACCESS_ID                  ,
  Placement.OFFRE_INT_PRE                                                               as OFFRE_INT_PRE                          ,
  --Alim Infos Clients
  Placement.OTO_OSCAR_VALUE_NU                                                          as OTO_OSCAR_VALUE_NU                     ,
  Placement.PAR_LASTNAME                                                                as PAR_LASTNAME                           ,
  Placement.PAR_FIRSTNAME                                                               as PAR_FIRSTNAME                          ,
  Placement.PAR_TYPE                                                                    as PAR_TYPE                               ,
  Placement.PAR_IMSI                                                                    as PAR_IMSI                               ,
  Placement.PAR_EMAIL                                                                   as PAR_EMAIL                              ,
  Placement.PAR_BILL_ADRESS_1                                                           as PAR_BILL_ADRESS_1                      ,
  Placement.PAR_BILL_ADRESS_2                                                           as PAR_BILL_ADRESS_2                      ,
  Placement.PAR_BILL_ADRESS_3                                                           as PAR_BILL_ADRESS_3                      ,
  Placement.PAR_BILL_ADRESS_4                                                           as PAR_BILL_ADRESS_4                      ,
  Placement.PAR_BILL_VILLE                                                              as PAR_BILL_VILLE                         ,
  Placement.PAR_BILL_CD_POSTAL                                                          as PAR_BILL_CD_POSTAL                     ,
  Placement.PAR_INSEE_CD                                                                as PAR_INSEE_CD                           ,
  Placement.PAR_DO                                                                      as PAR_DO                                 ,
  Placement.PAR_USCM                                                                    as PAR_USCM                               ,
  Placement.PAR_USCM_DS                                                                 as PAR_USCM_DS                            ,
  Placement.PAR_USCM_USCM_DS                                                            as PAR_USCM_USCM_DS                       ,
  Placement.PAR_USCM_REGUSCM                                                            as PAR_USCM_REGUSCM                       ,
  Placement.PAR_USCM_REGUSCM_DS                                                         as PAR_USCM_REGUSCM_DS                    ,
  Placement.PAR_AID                                                                     as PAR_AID                                ,
  Placement.PAR_ND                                                                      as PAR_ND                                 ,
  Placement.PAR_MOB_IMEI                                                                as PAR_MOB_IMEI                           ,
  Placement.PAR_MOB_TAC                                                                 as PAR_MOB_TAC                            ,
  Placement.PAR_MOB_SIM                                                                 as PAR_MOB_SIM                            ,
  --Segementation client :
  Placement.PAR_SCORE_NU_MOB                                                            as PAR_SCORE_NU_MOB                       ,
  Placement.PAR_SCORE_IN_MOB                                                            as PAR_SCORE_IN_MOB                       ,
  Placement.PAR_TRESHOLD_NU_MOB                                                         as PAR_TRESHOLD_NU_MOB                    ,
  Placement.PAR_SCORE_NU_INT                                                            as PAR_SCORE_NU_INT                       ,
  Placement.PAR_SCORE_IN_INT                                                            as PAR_SCORE_IN_INT                       ,
  Placement.PAR_TRESHOLD_NU_INT                                                         as PAR_TRESHOLD_NU_INT                    ,
  --Contrat Avec le client :
  Placement.CONTRCT_DT_SIGN_PREC                                                        as CONTRCT_DT_SIGN_PREC                   ,
  Placement.CONTRCT_DT_FIN_PREC                                                         as CONTRCT_DT_FIN_PREC                    ,
  Placement.CONTRCT_DT_SIGN_POST                                                        as CONTRCT_DT_SIGN_POST                   ,
  Placement.CONTRCT_DUREE_ENG                                                           as CONTRCT_DUREE_ENG                      ,
  Placement.CONTRCT_UNIT_ENG                                                            as CONTRCT_UNIT_ENG                       ,
  NULL                                                                                  as CONFIRMATION_IN                        ,
  NULL                                                                                  as CONFIRMATION_DT                        ,
  NULL                                                                                  as CONFIRMATION_CALC_FIN_DT               ,
  NULL                                                                                  as DELIVERY_IN                            ,
  NULL                                                                                  as DELIVERY_DT                            ,
  NULL                                                                                  as DELIVERY_CALC_FIN_DT                   ,
  NULL                                                                                  as PERENNITE_IN                           ,
  NULL                                                                                  as PERENNITE_FIN_DT                       ,
  NULL                                                                                  as PERENNITE_CALC_FIN_DT                  ,
  Null                                                                                  as PERENNITE_PVC_IN             ,
  Null                                                                                  as PERENNITE_PVC_FIN_DT         ,
  Null                                                                                  as PERENNITE_PVC_CALC_FIN_DT    ,
  Null                                                                                  as PERNNT_IN                              ,
  Null                                                                                  as PERNNT_END_DT                          ,
  Null                                                                                  as PERNNT_MOTIF                           ,
  Null                                                                                  as PERNNT_CALC_END_DT                     ,
  Null                                                                                  as ORDER_CANCELING_DT                     ,
  Null                                                                                  as SEG_PRES_PARC_COMMANDE       ,
  Null                                                                                  as MIGRA_DT                     ,
  Null                                                                                  as MIGRA_NEXT_OFFRE             ,
  Null                                                                                  as RESIL_INT_DT                 ,
  Null                                                                                  as RESIL_INT_MOTIF              ,
  Null                                                                                  as RESIL_INT_MOTIF_DS           ,
  Null                                                                                  as SEG_COM_ID_LAST_PER          ,
  Null                                                                                  as SEG_COM_ID_SOLD              ,
  Null                                                                                  as SEG_COM_ID_FIND              ,
  Null                                                                                  as SEG_FIND_LIVR_DT             ,
  Null                                                                                  as SEG_FIND_CANCEL_DT           ,
  Null                                                                                  as SEG_COM_ID_NEXT_PARC         ,
  Null                                                                                  as SEG_NEXT_PARC_LIVR_DT        ,
  Null                                                                                  as SEG_NEXT_PARC_CANCEL_DT      ,
  Null                                                                                  as SEG_COM_ID_FINAL_PARC        ,
  Null                                                                                  as SEG_FINAL_PARC_LIVR_DT       ,
  Null                                                                                  as SEG_FINAL_PARC_CANCEL_DT     ,
  Null                                                                                  as SEG_COM_ID_LAST_IN_PARC      ,
  Null                                                                                  as NB_IN_OUT_PARC               ,
  Null                                                                                  as POURCENTAGE_PRES_PARC        ,
  NULL                                                                                  as DELIVERY_ONTIME_IN                     ,
  Null                                                                                  as DELIVERY_DEAD_LINE_NU                  ,
  'NA'                                                                                  as CONCURENCE_IN                          ,
  'NA'                                                                                  as CONCURENCE_CONCLU_IN                   ,
  Null                                                                                  as CONCURENCE_ID                          ,
  ----------------------------------------------------------------------------
  Null                                                                                  as SEG_COM_ID_ORDER_ID                    ,
  Null                                                                                  as SEG_ORDER_DT                           ,
  Null                                                                                  as SEG_CANCEL_DT                          ,
  Null                                                                                  as SEG_COM_ID_NEXT_ORDER                  ,
  Null                                                                                  as SEG_NEXT_ORDER_DT                      ,
  Null                                                                                  as SEG_NEXT_CANCEL_DT                     ,
  Null                                                                                  as SEG_COM_ID_FINAL_ORDER                 ,
  Null                                                                                  as SEG_FINAL_ORDER_DT                     ,
  Null                                                                                  as SEG_FINAL_ORDER_CANCEL_DT              ,
  ----------------------------------------------------------------------------
  Null                                                                                  as CHECK_INITIAL_STATUS_CD                ,
  RetournCSO.CHECK_NAT_STATUS_CD                                                        as CHECK_NAT_STATUS_CD                    ,
  RetournCSO.CHECK_NAT_COMMENT                                                          as CHECK_NAT_COMMENT                      ,
  RetournCSO.CHECK_NAT_STATUS_LN                                                        as CHECK_NAT_STATUS_LN                    ,
  RetournCSO.CHECK_LOC_STATUS_CD                                                        as CHECK_LOC_STATUS_CD                    ,
  RetournCSO.CHECK_LOC_COMMENT                                                          as CHECK_LOC_COMMENT                      ,
  RetournCSO.CHECK_LOC_STATUS_LN                                                        as CHECK_LOC_STATUS_LN                    ,
  RetournCSO.CHECK_VALIDT_DT                                                            as CHECK_VALIDT_DT                        ,
  Null                                                                                  as CLOSURE_DT                             ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                            ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS                          ,
  1                                                                                     as FRESH_IN                               ,
  0                                                                                     as COHERENCE_IN                           ,
  0                                                                                     as HOT_IN                                
From
  ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO Placement
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_ORIG_DEM OrigineVente
    On    Placement.ORG_REF_TRAV                        =  OrigineVente.ORG_REF_TRAV
      And Placement.ORG_GROUPE_ID                       =  OrigineVente.ORG_GROUPE_ID
      And Placement.PLTF_CO                             =  OrigineVente.APPLI_SOURCE_ID
      And Placement.INT_DEPOSIT_DT                      >= OrigineVente.GRP_DT_DEB
      And Placement.INT_DEPOSIT_DT                      <= OrigineVente.GRP_DT_FIN
      And OrigineVente.FRESH_IN                         =  1
      And OrigineVente.CURRENT_IN                       =  1
      And OrigineVente.CLOSURE_DT                       is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_PCO_CANAL_VENTE CanalVenteMacroPrem
    On    OrigineVente.ORIG_DEM                         = CanalVenteMacroPrem.ORIG_DEM
      And CanalVenteMacroPrem.FRESH_IN                  = 1
      And CanalVenteMacroPrem.CURRENT_IN                = 1
      And CanalVenteMacroPrem.CLOSURE_DT                is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_CHO OrgChannelCho
    ON    Placement.RESOLU_ID                                                                                               = OrgChannelCho.RESOLU_ID
      AND CASE WHEN COALESCE(Placement.PAR_SCORE_IN_MOB, 0) = ${P_PIL_419} THEN '${P_PIL_417}' ELSE '${P_PIL_416}' END      = OrgChannelCho.PAR_SCORE_IN_MOB
      AND CASE WHEN COALESCE(Placement.CANALDEM, '${P_PIL_418}')  IN (${L_PIL_042}) THEN Placement.CANALDEM ELSE '#' END    = OrgChannelCho.CANALDEM
      AND CASE WHEN (Placement.FLAG_PLT_CONV IS NULL AND Placement.CANALDEM = '${P_PIL_436}') Then 1
               ELSE Coalesce(Placement.FLAG_PLT_CONV, 0)
          END                                                                                                               = OrgChannelCho.FLAG_PLT_CONV
      AND Coalesce(Placement.FLAG_PLT_SCH, 0)                                                                               = OrgChannelCho.FLAG_PLT_SCH
      AND COALESCE(Placement.FLAG_TYPE_CMP, '${P_PIL_418}')                                                                 = OrgChannelCho.ORG_FLAG_TYPE_CMP
      --Jointure pour récupérer la hierarchie O3:
  Left Outer Join ${KNB_PCO_TMP}.ORD_T_CALC_ACT_CHO_O3 HierO3
    On Placement.ACTE_ID        = HierO3.ACTE_ID
   And Placement.INT_DEPOSIT_DT = HierO3.DATE_SAISIE
Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                                   = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG                       = 1
      And RetournCSO.CURRENT_IN                               = 1
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID                                   = RetourGRV.ACTE_ID
      And Placement.INT_DEPOSIT_DT                            = RetourGRV.ORDER_DEPOSIT_DT
  --KPI 2020
  Left Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CALC RefId
    On    Placement.ACTE_ID                             = RefId.ACTE_ID
      And Placement.INT_DEPOSIT_DT                      = RefId.INT_DEPOSIT_DT
   Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM MatSC
    On    RefId.TYPE_COMMANDE_ID                        = MatSC.TYPE_COMMANDE_ID
      And RefId.SEG_COM_ID_FINAL                        = MatSC.SEG_COM_ID_FINAL
      And Coalesce(RefId.SEG_COM_ID_PRE,'${P_PIL_211}') = MatSC.SEG_COM_ID_INI
      And RefId.PERIODE_ID                              = MatSC.PERIODE_ID
      And MatSC.CATEGORIE_CLIENT_ID                     = 'SC' --Catégorie Oscar
      And MatSC.FRESH_IN                                = 1
      And MatSC.CURRENT_IN                              = 1
      And MatSC.CLOSURE_DT                              is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM    RefActeSC
    On    MatSC.ACTE_ID                                 = RefActeSC.ACTE_ID
      And MatSC.PERIODE_ID                              = RefActeSC.PERIODE_ID
      And RefActeSC.FRESH_IN                            = 1
      And RefActeSC.CURRENT_IN                          = 1
      And RefActeSC.CLOSURE_DT                          Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM         KPI_PILCOM
On                 KPI_PILCOM.PERIODE_ID                      = RefActeSC.PERIODE_ID
And                KPI_PILCOM.FAMILLE_KPI_ID                  = RefActeSC.ACTE_FAMILLE_KPI
And                KPI_PILCOM.CURRENT_IN                      = 1
And                KPI_PILCOM.CLOSURE_DT                      Is Null
Where
  (1=1)
  --Filtre pour le calcul de profondeur
  --And Placement.CLOSURE_DT is null
  And Placement.INT_DEPOSIT_DT >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
  --Filtre pour ne prendre que le commande à AGAP
  And Placement.TYPE_OT_SO in ('${P_PIL_038}')
  --And Placement.HOT_IN = 0
  And Placement.CLOSURE_DT  Is Null
;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.INT_T_ACTE_CHO
(
  ACTE_ID                                   ,
  ACTE_ID_GEN                               ,
  DEMANDE_ID                                ,
  EXTERNAL_INT_ID                           ,
  INT_DEPOSIT_TS                            ,
  INT_DEPOSIT_DT                            ,
  OPERATOR_PROVIDER_ID                      ,
  RESOLU_ID                                 ,
  CONCLU_ID                                 ,
  SSCONCLU_ID                               ,
  INT_MODIF_TS                              ,
  PLTF_CO                                   ,
  INTRNL_SOURCE_ID                          ,
  SOLDOFF_SRC_CD                            ,
  RSFCOMMENTAIRE_DS                         ,
  OTO_OFFER_CD                              ,
  OTO_OFFER_TYPE_CD                         ,
  ACT_PRESFACT_CO_PRE                       ,
  ACT_PRODUCT_ID_PRE                        ,
  ACT_SEG_COM_ID_PRE                        ,
  ACT_SEG_COM_AGG_ID_PRE                    ,
  ACT_CODE_MIGR_PRE                         ,
  ACT_PRESFACT_CO_OFOPT_ACQ                 ,
  ACT_PRODUCT_ID_FINAL                      ,
  TYPE_OT_SO                                ,
  IN_CLIDOS                                 ,
  ACT_SEG_COM_ID_FINAL                      ,
  ACT_SEG_COM_AGG_ID_FINAL                  ,
  ACT_CODE_MIGR_FINAL                       ,
  ACT_TYPE_SERVICE_FINAL                    ,
  ACT_TYPE_COMMANDE_ID                      ,
  ACT_DELTA_TARIF                           ,
  ACT_UNITE_CD                              ,
  ACT_CD                                    ,
  ACT_REM_ID                                ,
  ACT_FLAG_ACT_REM                          ,
  ACT_FLAG_PEC_PERPVC                       ,
  ACT_ACTE_VALO                             ,
  ACT_ACTE_FAMILLE_KPI                      ,
  ACT_PERIODE_ID                            ,
  ACT_PERIODE_STATUS                        ,
  ACT_PERIODE_CLOSURE_DT                    ,
  INB_PRESFACT_ACQ_ADV                      ,
  INB_PRESFACT_ACQ_AGAP                     ,
  INB_ORIGINE_PARC                          ,
  SEG_PARC_DT_DEBUT                         ,
  ORG_CANAL_ID_SC                           ,
  ORIG_DEM_SC                               ,
  INT_ORIGIN_CD                             ,
  INT_REASON_CD                             ,
  INT_RESULT_CD                             ,
  CANALDEM_MTHD                             ,
  ORG_CANAL_ID_MACRO_SC                     ,
  ORG_CANAL_MACRO_LB_SC                     ,
  FLAG_HD                                   ,
  ORG_CANAL_ID                              ,
  ORG_CHANNEL_CD                            ,
  ORG_SUB_CHANNEL_CD                        ,
  ORG_SUB_SUB_CHANNEL_CD                    ,
  ORG_REM_CHANNEL_CD                        ,
  ORG_GT_ACTIVITY                           ,
  ORG_FIDELISATION                          ,
  ORG_WEB_ACTIVITY                          ,
  ORG_AUTO_ACTIVITY                         ,
  ORG_EDO_ID                                ,
  ORG_TYPE_EDO                              ,
  ORG_EDO_IOBSP                             ,
  ORG_FLAG_PLT_CONV                         ,
  ORG_FLAG_TEAM_MKT                         ,
  ORG_FLAG_TYPE_CMP                         ,
  ORG_EDO_ID_HIER                           ,
  ORG_TYPE_EDO_HIER                         ,
  ORG_REF_TRAV                              ,
  ORG_AGENT_ID                              ,
  ORG_AGENT_IOBSP                           ,
  ORG_POC_XI                                ,
  ORG_NOM                                   ,
  ORG_PRENOM                                ,
  ORG_GROUPE_ID                             ,
  ORG_GROUPE_ID_HIER                        ,
  ORG_ACTVT_REEL                            ,
  ORG_RESP_REF_TRAV                         ,
  ORG_RESP_AGENT_ID                         ,
  ORG_RESP_XI                               ,
  ORG_RESP_ACTVT_REEL                       ,
  ORG_RESP_EDO_ID                           ,
  ORG_RESP_TYPE_EDO                         ,
  ORG_RESP_FLAG_PLT_CONV                    ,
  ORG_TEAM_LEVEL_1_CD                       ,
  ORG_TEAM_LEVEL_1_DS                       ,
  ORG_TEAM_LEVEL_2_CD                       ,
  ORG_TEAM_LEVEL_2_DS                       ,
  ORG_TEAM_LEVEL_3_CD                       ,
  ORG_TEAM_LEVEL_3_DS                       ,
  ORG_TEAM_LEVEL_4_CD                       ,
  ORG_TEAM_LEVEL_4_DS                       ,
  WORK_TEAM_LEVEL_1_CD                      ,
  WORK_TEAM_LEVEL_1_DS                      ,
  WORK_TEAM_LEVEL_2_CD                      ,
  WORK_TEAM_LEVEL_2_DS                      ,
  WORK_TEAM_LEVEL_3_CD                      ,
  WORK_TEAM_LEVEL_3_DS                      ,
  WORK_TEAM_LEVEL_4_CD                      ,
  WORK_TEAM_LEVEL_4_DS                      ,
  CLIENT_NU                                 ,
  CLIENT_NU_NEW_PORTE                       ,
  DOSSIER_NU                                ,
  DOSSIER_NU_NEW_PORTE                      ,
  DOSSIER_DATE_ACTIV                        ,
  DOSSIER_DATE_RESIL                        ,
  DOSSIER_TYPE_RESIL                        ,
  DOSSIER_MOTIF_RESIL                       ,
  DMC_LINE_ID                               ,
  DMC_MASTER_LINE_ID                        ,
  DMC_LINE_TYPE                             ,
  PAR_CID_ID                                ,
  PAR_PID_ID                                ,
  DMC_ACTIVATION_DT                         ,
   --------
  PAR_DEPRTMNT_ID                           ,
  PAR_POSTAL_CD                             ,
  PAR_BU_CD                                 ,
  PAR_GEO_MACROZONE                         ,
  PAR_UNIFIED_PARTY_ID                      ,
  PAR_PARTY_REGRPMNT_ID                     ,
  PAR_IRIS2000_CD                           ,
  PAR_FIBER_IN                              ,
  ----
  DMC_CONVERGENT_IN                         ,
  DMC_LINE_ID_INT                           ,
  DMC_LINE_TYPE_INT                         ,
  DMC_ACTIVATION_DT_INT                     ,
  DMC_SERVICE_ACCESS_ID                     ,
  OFFRE_INT_PRE                             ,
  OTO_OSCAR_VALUE_NU                        ,
  PAR_LASTNAME                              ,
  PAR_FIRSTNAME                             ,
  PAR_TYPE                                  ,
  PAR_IMSI                                  ,
  PAR_EMAIL                                 ,
  PAR_BILL_ADRESS_1                         ,
  PAR_BILL_ADRESS_2                         ,
  PAR_BILL_ADRESS_3                         ,
  PAR_BILL_ADRESS_4                         ,
  PAR_BILL_VILLE                            ,
  PAR_BILL_CD_POSTAL                        ,
  PAR_INSEE_CD                              ,
  PAR_DO                                    ,
  PAR_USCM                                  ,
  PAR_USCM_DS                               ,
  PAR_USCM_USCM_DS                          ,
  PAR_USCM_REGUSCM                          ,
  PAR_USCM_REGUSCM_DS                       ,
  PAR_AID                                   ,
  PAR_ND                                    ,
  PAR_MOB_IMEI                              ,
  PAR_MOB_TAC                               ,
  PAR_MOB_SIM                               ,
  PAR_SCORE_NU_MOB                          ,
  PAR_SCORE_IN_MOB                          ,
  PAR_TRESHOLD_NU_MOB                       ,
  PAR_SCORE_NU_INT                          ,
  PAR_SCORE_IN_INT                          ,
  PAR_TRESHOLD_NU_INT                       ,
  CONTRCT_DT_SIGN_PREC                      ,
  CONTRCT_DT_FIN_PREC                       ,
  CONTRCT_DT_SIGN_POST                      ,
  CONTRCT_DUREE_ENG                         ,
  CONTRCT_UNIT_ENG                          ,
  CONFIRMATION_IN                           ,
  CONFIRMATION_DT                           ,
  CONFIRMATION_CALC_FIN_DT                  ,
  DELIVERY_IN                               ,
  DELIVERY_DT                               ,
  DELIVERY_CALC_FIN_DT                      ,
  PERENNITE_IN                              ,
  PERENNITE_FIN_DT                          ,
  PERENNITE_CALC_FIN_DT                     ,
  PERENNITE_PVC_IN                          ,
  PERENNITE_PVC_FIN_DT                      ,
  PERENNITE_PVC_CALC_FIN_DT                 ,
  PERNNT_IN                                 ,
  PERNNT_END_DT                             ,
  PERNNT_MOTIF                              ,
  PERNNT_CALC_END_DT                        ,
  ORDER_CANCELING_DT                        ,
  SEG_PRES_PARC_COMMANDE                    ,
  MIGRA_DT                                  ,
  MIGRA_NEXT_OFFRE                          ,
  RESIL_INT_DT                              ,
  RESIL_INT_MOTIF                           ,
  RESIL_INT_MOTIF_DS                        ,
  SEG_COM_ID_LAST_PER                       ,
  SEG_COM_ID_SOLD                           ,
  SEG_COM_ID_FIND                           ,
  SEG_FIND_LIVR_DT                          ,
  SEG_FIND_CANCEL_DT                        ,
  SEG_COM_ID_NEXT_PARC                      ,
  SEG_NEXT_PARC_LIVR_DT                     ,
  SEG_NEXT_PARC_CANCEL_DT                   ,
  SEG_COM_ID_FINAL_PARC                     ,
  SEG_FINAL_PARC_LIVR_DT                    ,
  SEG_FINAL_PARC_CANCEL_DT                  ,
  SEG_COM_ID_LAST_IN_PARC                   ,
  NB_IN_OUT_PARC                            ,
  POURCENTAGE_PRES_PARC                     ,
  DELIVERY_ONTIME_IN                        ,
  DELIVERY_DEAD_LINE_NU                     ,
  CONCURENCE_IN                             ,
  CONCURENCE_CONCLU_IN                      ,
  CONCURENCE_ID                             ,
  SEG_COM_ID_ORDER_ID                       ,
  SEG_ORDER_DT                              ,
  SEG_CANCEL_DT                             ,
  SEG_COM_ID_NEXT_ORDER                     ,
  SEG_NEXT_ORDER_DT                         ,
  SEG_NEXT_CANCEL_DT                        ,
  SEG_COM_ID_FINAL_ORDER                    ,
  SEG_FINAL_ORDER_DT                        ,
  SEG_FINAL_ORDER_CANCEL_DT                 ,
  CHECK_INITIAL_STATUS_CD                   ,
  CHECK_NAT_STATUS_CD                       ,
  CHECK_NAT_COMMENT                         ,
  CHECK_NAT_STATUS_LN                       ,
  CHECK_LOC_STATUS_CD                       ,
  CHECK_LOC_COMMENT                         ,
  CHECK_LOC_STATUS_LN                       ,
  CHECK_VALIDT_DT                           ,
  CLOSURE_DT                                ,
  CREATION_TS                               ,
  LAST_MODIF_TS                             ,
  FRESH_IN                                  ,
  COHERENCE_IN                              ,
  HOT_IN                                    
)
Select
  Acte.ACTE_ID                                  ,
  Acte.ACTE_ID_GEN                              ,
  Acte.DEMANDE_ID                               ,
  Acte.EXTERNAL_INT_ID                          ,
  Acte.INT_DEPOSIT_TS                           ,
  Acte.INT_DEPOSIT_DT                           ,
  Acte.OPERATOR_PROVIDER_ID                     ,
  Acte.RESOLU_ID                                ,
  Acte.CONCLU_ID                                ,
  Acte.SSCONCLU_ID                              ,
  Acte.INT_MODIF_TS                             ,
  Acte.PLTF_CO                                  ,
  Acte.INTRNL_SOURCE_ID                         ,
  Acte.SOLDOFF_SRC_CD                           ,
  Acte.RSFCOMMENTAIRE_DS                        ,
  Acte.OTO_OFFER_CD                             ,
  Acte.OTO_OFFER_TYPE_CD                        ,
  Acte.ACT_PRESFACT_CO_PRE                      ,
  Acte.ACT_PRODUCT_ID_PRE                       ,
  Acte.ACT_SEG_COM_ID_PRE                       ,
  Acte.ACT_SEG_COM_AGG_ID_PRE                   ,
  Acte.ACT_CODE_MIGR_PRE                        ,
  Acte.ACT_PRESFACT_CO_OFOPT_ACQ                ,
  Acte.ACT_PRODUCT_ID_FINAL                     ,
  Acte.TYPE_OT_SO                               ,
  Acte.IN_CLIDOS                                ,
  Acte.ACT_SEG_COM_ID_FINAL                     ,
  Acte.ACT_SEG_COM_AGG_ID_FINAL                 ,
  Acte.ACT_CODE_MIGR_FINAL                      ,
  Acte.ACT_TYPE_SERVICE_FINAL                   ,
  Acte.ACT_TYPE_COMMANDE_ID                     ,
  Acte.ACT_DELTA_TARIF                          ,
  Acte.ACT_UNITE_CD                             ,
  Acte.ACT_CD                                   ,
  Acte.ACT_REM_ID                               ,
  Acte.ACT_FLAG_ACT_REM                         ,
  Acte.ACT_FLAG_PEC_PERPVC                      ,
  Acte.ACT_ACTE_VALO                            ,
  Acte.ACT_ACTE_FAMILLE_KPI                     ,
  Acte.ACT_PERIODE_ID                           ,
  Acte.ACT_PERIODE_STATUS                       ,
  Acte.ACT_PERIODE_CLOSURE_DT                   ,
  Acte.INB_PRESFACT_ACQ_ADV                     ,
  Acte.INB_PRESFACT_ACQ_AGAP                    ,
  Acte.INB_ORIGINE_PARC                         ,
  Acte.SEG_PARC_DT_DEBUT                        ,
  Acte.ORG_CANAL_ID_SC                          ,
  Acte.ORIG_DEM_SC                              ,
  Acte.INT_ORIGIN_CD                            ,
  Acte.INT_REASON_CD                            ,
  Acte.INT_RESULT_CD                            ,
  Acte.CANALDEM_MTHD                            ,
  Acte.ORG_CANAL_ID_MACRO_SC                    ,
  Acte.ORG_CANAL_MACRO_LB_SC                    ,
  Acte.FLAG_HD                                  ,
  Acte.ORG_CANAL_ID                             ,
  Acte.ORG_CHANNEL_CD                           ,
  Acte.ORG_SUB_CHANNEL_CD                       ,
  Acte.ORG_SUB_SUB_CHANNEL_CD                   ,
  Acte.ORG_REM_CHANNEL_CD                       ,
  Acte.ORG_GT_ACTIVITY                          ,
  Acte.ORG_FIDELISATION                         ,
  Acte.ORG_WEB_ACTIVITY                         ,
  Acte.ORG_AUTO_ACTIVITY                        ,
  Acte.ORG_EDO_ID                               ,
  Acte.ORG_TYPE_EDO                             ,
  Acte.ORG_EDO_IOBSP                            ,
  Acte.ORG_FLAG_PLT_CONV                        ,
  Acte.ORG_FLAG_TEAM_MKT                        ,
  Acte.ORG_FLAG_TYPE_CMP                        ,
  Acte.ORG_EDO_ID_HIER                          ,
  Acte.ORG_TYPE_EDO_HIER                        ,
  Acte.ORG_REF_TRAV                             ,
  Acte.ORG_AGENT_ID                             ,
  Acte.ORG_AGENT_IOBSP                          ,
  Acte.ORG_POC_XI                               ,
  Acte.ORG_NOM                                  ,
  Acte.ORG_PRENOM                               ,
  Acte.ORG_GROUPE_ID                            ,
  Acte.ORG_GROUPE_ID_HIER                       ,
  Acte.ORG_ACTVT_REEL                           ,
  Acte.ORG_RESP_REF_TRAV                        ,
  Acte.ORG_RESP_AGENT_ID                        ,
  Acte.ORG_RESP_XI                              ,
  Acte.ORG_RESP_ACTVT_REEL                      ,
  Acte.ORG_RESP_EDO_ID                          ,
  Acte.ORG_RESP_TYPE_EDO                        ,
  Acte.ORG_RESP_FLAG_PLT_CONV                   ,
  Acte.ORG_TEAM_LEVEL_1_CD                      ,
  Acte.ORG_TEAM_LEVEL_1_DS                      ,
  Acte.ORG_TEAM_LEVEL_2_CD                      ,
  Acte.ORG_TEAM_LEVEL_2_DS                      ,
  Acte.ORG_TEAM_LEVEL_3_CD                      ,
  Acte.ORG_TEAM_LEVEL_3_DS                      ,
  Acte.ORG_TEAM_LEVEL_4_CD                      ,
  Acte.ORG_TEAM_LEVEL_4_DS                      ,
  Acte.WORK_TEAM_LEVEL_1_CD                     ,
  Acte.WORK_TEAM_LEVEL_1_DS                     ,
  Acte.WORK_TEAM_LEVEL_2_CD                     ,
  Acte.WORK_TEAM_LEVEL_2_DS                     ,
  Acte.WORK_TEAM_LEVEL_3_CD                     ,
  Acte.WORK_TEAM_LEVEL_3_DS                     ,
  Acte.WORK_TEAM_LEVEL_4_CD                     ,
  Acte.WORK_TEAM_LEVEL_4_DS                     ,
  Acte.CLIENT_NU                                ,
  Acte.CLIENT_NU_NEW_PORTE                      ,
  Acte.DOSSIER_NU                               ,
  Acte.DOSSIER_NU_NEW_PORTE                     ,
  Acte.DOSSIER_DATE_ACTIV                       ,
  Acte.DOSSIER_DATE_RESIL                       ,
  Acte.DOSSIER_TYPE_RESIL                       ,
  Acte.DOSSIER_MOTIF_RESIL                      ,
  Acte.DMC_LINE_ID                              ,
  Acte.DMC_MASTER_LINE_ID                       ,
  Acte.DMC_LINE_TYPE                            ,
  Acte.PAR_CID_ID                               ,
  Acte.PAR_PID_ID                               ,
  Acte.DMC_ACTIVATION_DT                        ,
  
     --------
  Acte.PAR_DEPRTMNT_ID                          ,
  Acte.PAR_POSTAL_CD                            ,
  Acte.PAR_BU_CD                                ,
  Acte.PAR_GEO_MACROZONE                        ,
  Acte.PAR_UNIFIED_PARTY_ID                     ,
  Acte.PAR_PARTY_REGRPMNT_ID                    ,
  Acte.PAR_IRIS2000_CD                          ,
  Acte.PAR_FIBER_IN                             ,
  ----
  Acte.DMC_CONVERGENT_IN                        ,
  Acte.DMC_LINE_ID_INT                          ,
  Acte.DMC_LINE_TYPE_INT                        ,
  Acte.DMC_ACTIVATION_DT_INT                    ,
  Acte.DMC_SERVICE_ACCESS_ID                    ,
  Acte.OFFRE_INT_PRE                            ,
  Acte.OTO_OSCAR_VALUE_NU                       ,
  Acte.PAR_LASTNAME                             ,
  Acte.PAR_FIRSTNAME                            ,
  Acte.PAR_TYPE                                 ,
  Acte.PAR_IMSI                                 ,
  Acte.PAR_EMAIL                                ,
  Acte.PAR_BILL_ADRESS_1                        ,
  Acte.PAR_BILL_ADRESS_2                        ,
  Acte.PAR_BILL_ADRESS_3                        ,
  Acte.PAR_BILL_ADRESS_4                        ,
  Acte.PAR_BILL_VILLE                           ,
  Acte.PAR_BILL_CD_POSTAL                       ,
  Acte.PAR_INSEE_CD                             ,
  Acte.PAR_DO                                   ,
  Acte.PAR_USCM                                 ,
  Acte.PAR_USCM_DS                              ,
  Acte.PAR_USCM_USCM_DS                         ,
  Acte.PAR_USCM_REGUSCM                         ,
  Acte.PAR_USCM_REGUSCM_DS                      ,
  Acte.PAR_AID                                  ,
  Acte.PAR_ND                                   ,
  Acte.PAR_MOB_IMEI                             ,
  Acte.PAR_MOB_TAC                              ,
  Acte.PAR_MOB_SIM                              ,
  Acte.PAR_SCORE_NU_MOB                         ,
  Acte.PAR_SCORE_IN_MOB                         ,
  Acte.PAR_TRESHOLD_NU_MOB                      ,
  Acte.PAR_SCORE_NU_INT                         ,
  Acte.PAR_SCORE_IN_INT                         ,
  Acte.PAR_TRESHOLD_NU_INT                      ,
  Acte.CONTRCT_DT_SIGN_PREC                     ,
  Acte.CONTRCT_DT_FIN_PREC                      ,
  Acte.CONTRCT_DT_SIGN_POST                     ,
  Acte.CONTRCT_DUREE_ENG                        ,
  Acte.CONTRCT_UNIT_ENG                         ,
  Acte.CONFIRMATION_IN                          ,
  Acte.CONFIRMATION_DT                          ,
  Acte.CONFIRMATION_CALC_FIN_DT                 ,
  Acte.DELIVERY_IN                              ,
  Acte.DELIVERY_DT                              ,
  Acte.DELIVERY_CALC_FIN_DT                     ,
  Acte.PERENNITE_IN                             ,
  Acte.PERENNITE_FIN_DT                         ,
  Acte.PERENNITE_CALC_FIN_DT                    ,
  Acte.PERENNITE_PVC_IN                         ,
  Acte.PERENNITE_PVC_FIN_DT                     ,
  Acte.PERENNITE_PVC_CALC_FIN_DT                ,
  Acte.PERNNT_IN                                ,
  Acte.PERNNT_END_DT                            ,
  Acte.PERNNT_MOTIF                             ,
  Acte.PERNNT_CALC_END_DT                       ,
  Acte.ORDER_CANCELING_DT                       ,
  Acte.SEG_PRES_PARC_COMMANDE                   ,
  Acte.MIGRA_DT                                 ,
  Acte.MIGRA_NEXT_OFFRE                         ,
  Acte.RESIL_INT_DT                             ,
  Acte.RESIL_INT_MOTIF                          ,
  Acte.RESIL_INT_MOTIF_DS                       ,
  Acte.SEG_COM_ID_LAST_PER                      ,
  Acte.SEG_COM_ID_SOLD                          ,
  Acte.SEG_COM_ID_FIND                          ,
  Acte.SEG_FIND_LIVR_DT                         ,
  Acte.SEG_FIND_CANCEL_DT                       ,
  Acte.SEG_COM_ID_NEXT_PARC                     ,
  Acte.SEG_NEXT_PARC_LIVR_DT                    ,
  Acte.SEG_NEXT_PARC_CANCEL_DT                  ,
  Acte.SEG_COM_ID_FINAL_PARC                    ,
  Acte.SEG_FINAL_PARC_LIVR_DT                   ,
  Acte.SEG_FINAL_PARC_CANCEL_DT                 ,
  Acte.SEG_COM_ID_LAST_IN_PARC                  ,
  Acte.NB_IN_OUT_PARC                           ,
  Acte.POURCENTAGE_PRES_PARC                    ,
  Acte.DELIVERY_ONTIME_IN                       ,
  Acte.DELIVERY_DEAD_LINE_NU                    ,
  Acte.CONCURENCE_IN                            ,
  Acte.CONCURENCE_CONCLU_IN                     ,
  Acte.CONCURENCE_ID                            ,
  Acte.SEG_COM_ID_ORDER_ID                      ,
  Acte.SEG_ORDER_DT                             ,
  Acte.SEG_CANCEL_DT                            ,
  Acte.SEG_COM_ID_NEXT_ORDER                    ,
  Acte.SEG_NEXT_ORDER_DT                        ,
  Acte.SEG_NEXT_CANCEL_DT                       ,
  Acte.SEG_COM_ID_FINAL_ORDER                   ,
  Acte.SEG_FINAL_ORDER_DT                       ,
  Acte.SEG_FINAL_ORDER_CANCEL_DT                ,
  Acte.CHECK_INITIAL_STATUS_CD                  ,
  Acte.CHECK_NAT_STATUS_CD                      ,
  Acte.CHECK_NAT_COMMENT                        ,
  Acte.CHECK_NAT_STATUS_LN                      ,
  Acte.CHECK_LOC_STATUS_CD                      ,
  Acte.CHECK_LOC_COMMENT                        ,
  Acte.CHECK_LOC_STATUS_LN                      ,
  Acte.CHECK_VALIDT_DT                          ,
  Coalesce(Acte.CLOSURE_DT,Current_Date)        ,
  Acte.CREATION_TS                              ,
  Acte.LAST_MODIF_TS                            ,
  Acte.FRESH_IN                                 ,
  Acte.COHERENCE_IN                             ,
  Acte.HOT_IN                                   
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_CHO  Acte
  Inner Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO Placement
    On Acte.ACTE_ID   = Placement.ACTE_ID
Where
  (1=1)
  And Placement.CLOSURE_DT      Is Not Null
  And Placement.INT_DEPOSIT_DT  >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_T_ACTE_CHO;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CALC;
.if errorcode <> 0 then .quit 1


.quit 0

