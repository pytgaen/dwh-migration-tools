-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step3_RechercheParcParsifal.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_SEEK_PARK_ID All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On reformate les lignes à chercher pour joindre dans le parc
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_SEEK_PARK_ID
(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  PARSIFAL_PARC_ID        ,
  SERVICE_ACCESS_ID       ,
  COMPST_OFFR_ID          ,
  ATOMIC_OFFR_ID          ,
  FUNCTN_ID               ,
  FUNCTN_VALUE_ID         ,
  TYPE_PRODUCT            ,
  EXT_OPER_ID_INIT        ,
  EXT_OPER_ID             
)
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.ORDER_DEPOSIT_DT                 as ORDER_DEPOSIT_DT       ,
  Acte.PARSIFAL_PARC_ID                 as PARSIFAL_PARC_ID       ,
  Acte.SERVICE_ACCESS_ID                as SERVICE_ACCESS_ID      ,
  Acte.COMPST_OFFR_ID                   as COMPST_OFFR_ID         ,
  Acte.ATOMIC_OFFR_ID                   as ATOMIC_OFFR_ID         ,
  Acte.FUNCTN_ID                        as FUNCTN_ID              ,
  Acte.FUNCTN_VALUE_ID                  as FUNCTN_VALUE_ID        ,
  --On reformate la valeur de fonction pour etre Iso Parc Kenobi
  Case  When Acte.TYPE_PRODUCT='OC'     Then 'OC'
        When Acte.TYPE_PRODUCT='OA'     Then 'O'
        When Acte.TYPE_PRODUCT='FVF'    Then 'F-VF'
  End                                   as TYPE_PRODUCT           ,
  Acte.EXT_OPER_ID_INIT                 as EXT_OPER_ID_INIT       ,
  Acte.EXT_OPER_ID                      as EXT_OPER_ID            
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI Acte
Where
  (1=1)
  And Acte.EXT_OPER_ID_INIT   Not In ('RMP')
  And Acte.SERVICE_ACCESS_ID  Is Not Null
  And (
        Acte.PARK_ID      Is Null
        Or
        Acte.CANCELLNG_DT Is Not Null
      )
  
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_SEEK_PARK_ID;
.if errorcode <> 0 then .quit 1



-------------------------------------------------------------------------------------------
--Step 2 :  On realise la recherche en parc
-------------------------------------------------------------------------------------------
Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_PARK_ID all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_PARK_ID
(
  ACTE_ID           ,
  ORDER_DEPOSIT_DT  ,
  PARK_ID           ,
  REALZTN_DT        ,
  CONTRCT_DT        ,
  CANCELLNG_DT      
)
Select
  Refid.ACTE_ID                 as ACTE_ID          ,
  Refid.ORDER_DEPOSIT_DT        as ORDER_DEPOSIT_DT ,
  RefParc.PARK_ID               as PARK_ID          ,
  RefParc.REALZTN_DT            as REALZTN_DT       ,
  RefParc.CONTRCT_DT            as CONTRCT_DT       ,
  RefParc.CANCELLNG_DT          as CANCELLNG_DT      
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_SEEK_PARK_ID Refid
  Inner Join ${KNB_COM_SOC_V_PRS}.VF_INB_F_PART_INB LienParc
    On    Refid.SERVICE_ACCESS_ID                 = LienParc.ACCES_SERVICE
      And LienParc.PARTY_ROL_ID                   = 'DETENTEUR'
      And LienParc.APPLI_SOURCE_ID                = '32R'
      And LienParc.CURRENT_IN                     = 1
  Inner Join ${KNB_COM_SOC_V_PRS}.VF_INB_F_PARK RefParc
    On    LienParc.PARK_ID                        = RefParc.PARK_ID
      And Refid.COMPST_OFFR_ID                    = RefParc.COMPST_OFFR_ID
      And Refid.ATOMIC_OFFR_ID                    = Coalesce(RefParc.ATOMIC_OFFR_ID,'-1')
      And Refid.FUNCTN_ID                         = Coalesce(RefParc.FUNCTN_ID,'-1')
      And Refid.FUNCTN_VALUE_ID                   = Coalesce(RefParc.FUNCTN_VALUE_ID,'-1')
      And Refid.TYPE_PRODUCT                      = RefParc.TYP_PRODCT_EXTRNL_ID
      And RefParc.CURRENT_IN                      = 1
Where
  (1=1)
Qualify Row_Number() Over (Partition By Refid.ACTE_ID Order by RefParc.PARK_STATT_ID asc, RefParc.CONTRCT_DT desc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_PARK_ID;
.if errorcode <> 0 then .quit 1


.quit 0







