-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Hot_Alimentation_INT_Step1_Precalcul.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de précalcul / extraction du placement pour transfo acte SOFT Internet à Chaud
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------

.set width 2500;



---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des placements
--et réorganisation pour pouvoir jointer dans la table des catalogues
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_EXT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_EXT
(
  ACTE_ID                     ,
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_DT            ,
  TYPE_PRODUCT                ,
  EXT_OPER_ID                 ,
  COMPST_OFFR_ID              ,
  ATOMIC_OFFR_ID              ,
  FUNCTN_ID                   ,
  FUNCTN_VALUE_ID             ,
  PERIODE_ID                  ,
  OSCAR_VALUE_NU              ,
  ACTE_OPERTR_ID_COMPST_OFFR  
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.TYPE_PRODUCT                                          as TYPE_PRODUCT               ,
  --Reformatage des champs de mouvements
  Case  --Si c'est un RMV ou SUP ou RMP => RMV
        When (Placement.EXT_OPER_ID in ('${P_PIL_008}','${P_PIL_015}','${P_PIL_098}'))
          then '${P_PIL_008}'
        --Si C'est un ADM ou ADD Ou ADP => ADD
        When (Placement.EXT_OPER_ID in ('${P_PIL_005}','${P_PIL_091}','${P_PIL_099}'))
          then '${P_PIL_005}'
        Else Placement.EXT_OPER_ID
  End                                                             as EXT_OPER_ID                ,
  --OC
  Placement.COMPST_OFFR_ID                                        as COMPST_OFFR_ID             ,
  --OA
  Coalesce(Placement.ATOMIC_OFFR_ID     ,'${P_PIL_049}')          as ATOMIC_OFFR_ID             ,
  --Fonction / Valeur de fonction
  Coalesce(Placement.FUNCTN_ID          ,'${P_PIL_049}')          as FUNCTN_ID                  ,
  Coalesce(Placement.FUNCTN_VALUE_ID    ,'${P_PIL_049}')          as FUNCTN_VALUE_ID            ,
  --Période
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )          as PERIODE_ID                 ,
  Placement.OSCAR_VALUE_NU                                        as OSCAR_VALUE_NU             ,
  Placement.ACTE_OPERTR_ID_COMPST_OFFR                            as ACTE_OPERTR_ID_COMPST_OFFR 
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_INT Placement
  Left Outer Join ${KNB_COM_SOC}.CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
Where
  (1=1)
  And Placement.FLAG_FIRST_RECEPTION_COM  = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_EXT;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------------------------------------------
--Step 2 :
--Jointure avec le catalogue pour récupérer les attributs pour la migration
---------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL
(
  ACTE_ID                     ,
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_DT            ,
  TYPE_PRODUCT                ,
  EXT_OPER_ID                 ,
  PERIODE_ID                  ,
  PRODUCT_ID                  ,
  SEG_COM_ID                  ,
  SEG_COM_AGG_ID              ,
  TYPE_SERVICE                ,
  MIGRATION_REGROUPEMENT_ID   ,
  MIGRATION_POSSIBLE          ,
  CODE_MIGRATION              ,
  TARIF_HT                    ,
  OSCAR_VALUE_NU              ,
  ACTE_OPERTR_ID_COMPST_OFFR  
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.TYPE_PRODUCT                                          as TYPE_PRODUCT               ,
  Placement.EXT_OPER_ID                                           as EXT_OPER_ID                ,
  Placement.PERIODE_ID                                            as PERIODE_ID                 ,
  Coalesce(RefInt.PRODUCT_ID                  ,'${P_PIL_223}')    as PRODUCT_ID                 ,
  Coalesce(RefInt.SEG_COM_ID                  ,'${P_PIL_022}')    as SEG_COM_ID                 ,
  Coalesce(RefInt.SEG_COM_AGG_ID              ,'${P_PIL_022}')    as SEG_COM_AGG_ID             ,
  RefInt.TYPE_SERVICE                                             as TYPE_SERVICE               ,
  Coalesce(RefInt.MIGRATION_REGROUPEMENT_ID   ,'${P_PIL_023}')    as MIGRATION_REGROUPEMENT_ID  ,
  Coalesce(RefInt.MIGRATION_POSSIBLE          ,'${P_PIL_020}')    as MIGRATION_POSSIBLE         ,
  Coalesce(RefInt.CODE_MIGRATION              ,'${P_PIL_024}')    as CODE_MIGRATION             ,
  Coalesce(RefInt.TARIF_HT                    ,0)                 as TARIF_HT                   ,
  Placement.OSCAR_VALUE_NU                                        as OSCAR_VALUE_NU             ,
  Placement.ACTE_OPERTR_ID_COMPST_OFFR                            as ACTE_OPERTR_ID_COMPST_OFFR 
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_EXT Placement
  Left Outer Join  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_INT RefInt
    On    Placement.COMPST_OFFR_ID                = RefInt.COMPST_OFFR_ID
      And Placement.ATOMIC_OFFR_ID                = RefInt.ATOMIC_OFFR_ID
      And Placement.FUNCTN_ID                     = RefInt.FUNCTN_ID
      And Placement.FUNCTN_VALUE_ID               = RefInt.FUNCTN_VALUE_ID
      And Placement.PERIODE_ID                    = RefInt.PERIODE_ID
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL;
.if errorcode <> 0 then .quit 1



-------------------------------------------------------------------------------------------------
-- Step 3
-- On insert les données que l'on veut suivre :
-------------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_ELI all;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_ELI
(
  ACTE_ID                     ,
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_DT            ,
  TYPE_PRODUCT                ,
  EXT_OPER_ID                 ,
  PERIODE_ID                  ,
  PRODUCT_ID                  ,
  SEG_COM_ID                  ,
  SEG_COM_AGG_ID              ,
  TYPE_SERVICE                ,
  MIGRATION_REGROUPEMENT_ID   ,
  MIGRATION_POSSIBLE          ,
  CODE_MIGRATION              ,
  TARIF_HT                    ,
  OSCAR_VALUE_NU              ,
  ACTE_OPERTR_ID_COMPST_OFFR  
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.TYPE_PRODUCT                                          as TYPE_PRODUCT               ,
  Placement.EXT_OPER_ID                                           as EXT_OPER_ID                ,
  Placement.PERIODE_ID                                            as PERIODE_ID                 ,
  Placement.PRODUCT_ID                                            as PRODUCT_ID                 ,
  Placement.SEG_COM_ID                                            as SEG_COM_ID                 ,
  Placement.SEG_COM_AGG_ID                                        as SEG_COM_AGG_ID             ,
  Placement.TYPE_SERVICE                                          as TYPE_SERVICE               ,
  Placement.MIGRATION_REGROUPEMENT_ID                             as MIGRATION_REGROUPEMENT_ID  ,
  Placement.MIGRATION_POSSIBLE                                    as MIGRATION_POSSIBLE         ,
  Placement.CODE_MIGRATION                                        as CODE_MIGRATION             ,
  Placement.TARIF_HT                                              as TARIF_HT                   ,
  Placement.OSCAR_VALUE_NU                                        as OSCAR_VALUE_NU             ,
  Placement.ACTE_OPERTR_ID_COMPST_OFFR                            as ACTE_OPERTR_ID_COMPST_OFFR 
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL Placement
Where
  (1=1)
  And
    (
      --On veut suivre les produits :
          --Qui sont sur une période valable :
              Placement.PERIODE_ID  <> ${P_PIL_049}
          --Dont le produit est défini dans le référentiel 
          And Placement.PRODUCT_ID  Not in ('${P_PIL_223}')
          --Et qui sont sur un segment suivi
          And Placement.SEG_COM_ID  Not in ('${P_PIL_022}','${P_PIL_295}')
    )
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_ELI;
.if errorcode <> 0 then .quit 1


-------------------------------------------------------------------------------------------------
-- Step 4
-- On insert les données que l'on ne veut pas suivre
-------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_NS all;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_NS
(
  ACTE_ID                     ,
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_DT            ,
  TYPE_PRODUCT                ,
  EXT_OPER_ID                 ,
  PERIODE_ID                  ,
  PRODUCT_ID                  ,
  SEG_COM_ID                  ,
  SEG_COM_AGG_ID              ,
  TYPE_SERVICE                ,
  MIGRATION_REGROUPEMENT_ID   ,
  MIGRATION_POSSIBLE          ,
  CODE_MIGRATION              ,
  TARIF_HT                    ,
  OSCAR_VALUE_NU              ,
  ACTE_OPERTR_ID_COMPST_OFFR  
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.TYPE_PRODUCT                                          as TYPE_PRODUCT               ,
  Placement.EXT_OPER_ID                                           as EXT_OPER_ID                ,
  Placement.PERIODE_ID                                            as PERIODE_ID                 ,
  Placement.PRODUCT_ID                                            as PRODUCT_ID                 ,
  Placement.SEG_COM_ID                                            as SEG_COM_ID                 ,
  Placement.SEG_COM_AGG_ID                                        as SEG_COM_AGG_ID             ,
  Placement.TYPE_SERVICE                                          as TYPE_SERVICE               ,
  Placement.MIGRATION_REGROUPEMENT_ID                             as MIGRATION_REGROUPEMENT_ID  ,
  Placement.MIGRATION_POSSIBLE                                    as MIGRATION_POSSIBLE         ,
  Placement.CODE_MIGRATION                                        as CODE_MIGRATION             ,
  Placement.TARIF_HT                                              as TARIF_HT                   ,
  Placement.OSCAR_VALUE_NU                                        as OSCAR_VALUE_NU             ,
  Placement.ACTE_OPERTR_ID_COMPST_OFFR                            as ACTE_OPERTR_ID_COMPST_OFFR 
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL Placement
Where
  (1=1)
  And
    ( 
      --On veut suivre les produits :
          --Qui sont sur une période valable :
              Placement.PERIODE_ID  = ${P_PIL_049}
          --Dont le produit est défini dans le référentiel 
          Or Placement.PRODUCT_ID  in ('${P_PIL_223}')
          --Et qui sont sur un segment suivi
          Or Placement.SEG_COM_ID  in ('${P_PIL_022}','${P_PIL_295}')
    )
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_NS;
.if errorcode <> 0 then .quit 1


