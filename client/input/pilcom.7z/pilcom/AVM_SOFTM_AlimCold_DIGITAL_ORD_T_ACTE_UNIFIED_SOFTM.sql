-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_SOFTM_AlimCold_DIGITAL_ORD_T_ACTE_UNIFIED_SOFTM.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source SOFTM dans la table ORD_T_ACTE_UNIFIED_SOFTM  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 15/07/2019     SSI         Création
-- 02/07/2020     EVI         PILCOM-496 : Indicateur eSim - New Champ SIM_EAN_CD
-- 13/10/2020     EVI         PILCOM-724 : Gestion Retour PVC - Correction Bug ecrasement CUID
-- 28/04/2021     EVI         PILCOM-800 : REFONTE DIGITAL - Alimentation VU IMEI + EXTERNAL_PARTY_ID
-- 28/06/2021     EVI         PILCOM-945 : Suppression Champs Obsolète VU 
-------------------------------------------------------------------------------

.set width 5000

--------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_SOFTM --
--------------------------------------



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTM
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  PERNNT_IN                     ,
  PERNNT_END_DT                 ,
  PERNNT_MOTIF                  ,
  PERNNT_CALC_END_DT            ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  ORG_AGENT_IOBSP               ,
  ORG_EDO_IOBSP                 ,
  PAR_IRIS2000_CD               ,
  ACT_CA_LINE_AM                ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  ORG_RESP_ID                   ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                   
)
Select
  SFM.ACTE_ID_GEN                                                           As ACTE_ID                      ,
  SFM.OPERATOR_PROVIDER_ID                                                  As OPERATOR_PROVIDER_ID         ,
  SFM.INTRNL_SOURCE_ID                                                      As INTRNL_SOURCE_ID             ,
  '${P_PIL_368}'                                                            As TYPE_SOURCE_ID               ,
  SFM.ACTE_ID_GEN                                                           As MASTER_ACTE_ID               ,
  SFM.INTRNL_SOURCE_ID                                                      As MASTER_INTRNL_SOURCE_ID      ,
  ${P_PIL_354}                                                              AS MASTER_FLAG                  ,
  ${P_PIL_375}                                                              As MASTER_NB_FOUND              ,
  DIGITAL.ACTE_ID_INTRCTN                                                   As CPLT_ACTE_ID                 ,
  -- Si c'est un traçage Auto ALors c'est ReFoce => 11 ou ETASK ->16
  Case  When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then  31 -- code de la source JRC
    Else Null
  End                                                                        As CPLT_INTRNL_SOURCE_ID       ,
  Case  When  DIGITAL.ACTE_ID_INTRCTN In ('${P_INT_031}','${P_PIL_520}')  
          Then  '${P_PIL_356}'
        When DIGITAL.ACTE_ID_INTRCTN Is Not Null  
          Then  '${P_PIL_356}'
        Else    '${P_PIL_357}'
  End                                                                       As CPLT_IN                     ,
  Case  When SFM.CPLT_ACTE_ID = '${P_INT_031}' 
          Then  '${P_PIL_048}'
        When SFM.CPLT_ACTE_ID = '${P_PIL_520}' 
          Then  '${P_PIL_521}'   
       When  SFM.CPLT_ACTE_ID Not In ('${P_INT_031}','${P_PIL_520}')  
          Then '${P_PIL_436}'
      When  SFM.CPLT_ACTE_ID is Null
         Then  '${P_PIL_362}'
  End                                                                       As RULE_ID                      ,
  Null                                                                      As OFFSET_NB                    ,
  '${P_PIL_325}'                                                            As ACT_TYPE                     ,
  Case When SFM.ORDER_REF_EXTERNAL_ID Is Null
        Then SFM.ORDER_EXTERNAL_ID
        Else SFM.ORDER_REF_EXTERNAL_ID
  End                                                                       As ORDER_EXTERNAL_ID,
  SFM.ORDER_LAST_STATUT_CD                                                  As STATUS_CD                    ,
  Case When SFM.CONCURENCE_IN = '${P_PIL_356}' Then '${P_PIL_385}'
       When SFM.CONFIRMATION_IN = '${P_PIL_357}' Then '${P_PIL_386}' 
       When SFM.PERENNITE_IN = '${P_PIL_356}' Then '${P_PIL_384}' 
       When SFM.DELIVERY_IN = '${P_PIL_356}' And SFM.PERENNITE_IN = '${P_PIL_357}' Then '${P_PIL_387}' 
       When SFM.DELIVERY_IN = '${P_PIL_356}' Then '${P_PIL_383}' 
       When SFM.CONFIRMATION_IN = '${P_PIL_356}' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                       As ACT_UNIFIED_STATUS_CD          ,
  SFM.ORDER_DEPOSIT_TS                                                      As ACT_TS                         ,
  SFM.ORDER_DEPOSIT_DT                                                      As ACT_DT                         ,
  Extract(HOUR From SFM.ORDER_DEPOSIT_TS)                                   As ACT_HH                         ,
  SFM.ORDER_LAST_STATUT_MODIF_TS                                            As ACT_LAST_UPD_TS                ,
  SFM.ACT_PRODUCT_ID_PRE                                                    As ACT_PRODUCT_ID_PRE             ,
  SFM.ACT_SEG_COM_ID_PRE                                                    As ACT_SEG_COM_ID_PRE             ,
  SFM.ACT_SEG_COM_AGG_ID_PRE                                                As ACT_SEG_COM_AGG_ID_PRE         ,
  SFM.ACT_CODE_MIGR_PRE                                                     As ACT_CODE_MIGR_PRE              ,
  SFM.ACT_OPER_ID_PRE                                                       As ACT_OPER_ID_PRE                ,
  SFM.ACT_PRODUCT_ID_FINAL                                                  As ACT_PRODUCT_ID_FINAL           ,
  SFM.ACT_SEG_COM_ID_FINAL                                                  As ACT_SEG_COM_ID_FINAL           ,
  SFM.ACT_SEG_COM_AGG_ID_FINAL                                              As ACT_SEG_COM_AGG_ID_FINAL       ,
  SFM.ACT_CODE_MIGR_FINAL                                                   As ACT_CODE_MIGR_FINAL            ,
  SFM.ACT_OPER_ID_FINAL                                                     As ACT_OPER_ID_FINAL              ,
  SFM.ACT_TYPE_SERVICE_FINAL                                                As ACT_TYPE_SERVICE_FINAL         ,
  SFM.ACT_TYPE_COMMANDE_ID                                                  As ACT_TYPE_COMMANDE_ID           ,
  SFM.ACT_DELTA_TARIF                                                       As ACT_DELTA_TARIF                ,
  SFM.ACT_CD                                                                As ACT_CD                         ,
  SFM.ACT_REM_ID                                                            As ACT_REM_ID                     ,
  SFM.ACT_FLAG_ACT_REM                                                      As ACT_FLAG_ACT_REM               ,
  SFM.ACT_FLAG_PEC_PERPVC                                                   As ACT_FLAG_PEC_PERPVC            ,
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And SFM.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And SFM.ORG_AGENT_ID_UPD Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And SFM.ORG_REM_CHANEL_CD IN (${L_PIL_043}) 
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    And SFM.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And SFM.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then 'O' 
       Else 'N'  
  End                                                                       As ACT_FLAG_PVC_REM               ,
  SFM.ACT_ACTE_VALO                                                         As ACT_ACTE_VALO                  ,
  SFM.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI           ,
  SFM.ACT_PERIODE_ID                                                        As ACT_PERIODE_ID                 ,
  SFM.ACT_PERIODE_STATUS                                                    As ACT_PERIODE_STATUS             ,
  SFM.ACT_PERIODE_CLOSURE_DT                                                As ACT_PERIODE_CLOSURE_DT         ,
  SFM.CPLT_INT_SRC                                                          As ORIGIN_CD                      ,
 Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Trim (DIGITAL.INT_OPRTR_ID)
    Else Trim(SFM.ORG_AGENT_ID)
  End                                                                      As AGENT_ID                        ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null And SFM.ORG_AGENT_ID_UPD_DT Is Null
    Then Trim (DIGITAL.INT_OPRTR_ID)
    Else Trim(SFM.ORG_AGENT_ID_UPD)
  End                                                                      As AGENT_ID_UPD                    ,
  SFM.ORG_AGENT_ID_UPD_DT                                                  As AGENT_ID_UPD_DT                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFM.ORG_PRENOM
  End                                                                      As AGENT_FIRST_NAME                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFM.ORG_NOM
  End                                                                      As AGENT_LAST_NAME                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_UNIFIED_SHOP_CD
    Else SFM.ORG_STORE_NAME
  End                                                                      As UNIFIED_SHOP_CD                 ,
  NULL                                                                     As ORG_SPE_CANAL_ID_MACRO          ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFM.ORG_CANAL_ID
  End                                                                      As ORG_SPE_CANAL_ID                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_REM_CHANNEL_CD
    Else SFM.ORG_REM_CHANEL_CD
  End                                                                      As ORG_REM_CHANNEL_CD              ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_CHANNEL_CD
    Else SFM.ORG_CHANEL_CD
  End                                                                      As ORG_CHANNEL_CD                  ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_CHANNEL_CD
    Else SFM.ORG_SUB_CHANEL_CD
  End                                                                      As ORG_SUB_CHANNEL_CD              ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_SUB_CHANNEL_CD
    Else SFM.ORG_SUB_SUB_CHANEL_CD
  End                                                                      As ORG_SUB_SUB_CHANNEL_CD          ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_GT_ACTIVITY
    Else SFM.ORG_GT_ACTIVITY
  End                                                                      As ORG_GT_ACTIVITY                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_FIDELISATION
    Else SFM.ORG_FIDELISATION
  End                                                                      As ORG_FIDELISATION                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_WEB_ACTIVITY
    Else SFM.ORG_WEB_ACTIVITY
  End                                                                      As ORG_WEB_ACTIVITY                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_AUTO_ACTIVITY
    Else SFM.ORG_AUTO_ACTIVITY
  End                                                                      As ORG_AUTO_ACTIVITY               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_ID
    Else SFM.ORG_EDO_ID
  End                                                                      As ORG_EDO_ID                      ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TYPE_EDO
    Else SFM.ORG_TYPE_EDO
  End                                                                      As ORG_TYPE_EDO                    ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFM.ORG_FLAG_PLT_CONV
  End                                                                      As ORG_FLAG_PLT_CONV               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFM.ORG_FLAG_TEAM_MKT
  End                                                                      As ORG_FLAG_TEAM_MKT               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFM.ORG_FLAG_TYPE_CMP
  End                                                                      As ORG_FLAG_TYPE_CMP               ,
  Null                                                                     As ORG_RESP_EDO_ID                 ,
  Null                                                                     As ORG_RESP_TYPE_EDO               ,
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV          ,
  Null                                                                     As ACTIVITY_CD                     ,
  Null                                                                     As ACTIVITY_GROUPNG_CD             ,
  Null                                                                     As AUTO_ACTIVITY_IN                ,
  '${P_PIL_366}'                                                           As ORG_TYPE_CD                     ,
  Null                                                                     As ORG_TEAM_TYPE_ID                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_CD
    Else Trim(SFM.ORG_TEAM_LEVEL_1_CD)
  End                                                                      As ORG_TEAM_LEVEL_1_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_DS
    Else Trim(SFM.ORG_TEAM_LEVEL_1_DS)
  End                                                                      As ORG_TEAM_LEVEL_1_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_CD
    Else Trim(SFM.ORG_TEAM_LEVEL_2_CD)
  End                                                                      As ORG_TEAM_LEVEL_2_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_DS
    Else Trim(SFM.ORG_TEAM_LEVEL_2_DS)
  End                                                                      As ORG_TEAM_LEVEL_2_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_CD
    Else Trim(SFM.ORG_TEAM_LEVEL_3_CD)
  End                                                                      As ORG_TEAM_LEVEL_3_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_DS
    Else Trim(SFM.ORG_TEAM_LEVEL_3_DS)
  End                                                                      As ORG_TEAM_LEVEL_3_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_CD
    Else Trim(SFM.ORG_TEAM_LEVEL_4_CD)
  End                                                                      As ORG_TEAM_LEVEL_4_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_DS
    Else Trim(SFM.ORG_TEAM_LEVEL_4_DS)
  End                                                                      As ORG_TEAM_LEVEL_4_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_CD
    Else Trim(SFM.WORK_TEAM_LEVEL_1_CD)
  End                                                                      As WORK_TEAM_LEVEL_1_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_DS
    Else Trim(SFM.WORK_TEAM_LEVEL_1_DS)
  End                                                                      As WORK_TEAM_LEVEL_1_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_CD
    Else Trim(SFM.WORK_TEAM_LEVEL_2_CD)
  End                                                                      As WORK_TEAM_LEVEL_2_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_DS
    Else Trim(SFM.WORK_TEAM_LEVEL_2_DS)
  End                                                                      As WORK_TEAM_LEVEL_2_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_CD
    Else Trim(SFM.WORK_TEAM_LEVEL_3_CD)
  End                                                                      As WORK_TEAM_LEVEL_3_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_DS
    Else Trim(SFM.WORK_TEAM_LEVEL_3_DS)
  End                                                                      As WORK_TEAM_LEVEL_3_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_CD
    Else Trim(SFM.WORK_TEAM_LEVEL_4_CD)
  End                                                                      As WORK_TEAM_LEVEL_4_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_DS
    Else Trim(SFM.WORK_TEAM_LEVEL_4_DS)
  End                                                                      As WORK_TEAM_LEVEL_4_DS            ,
  SFM.CONFIRMATION_IN                                                       As CONFIRMATION_IN                ,
  --Flag perennité
  Case  When SFM.ACT_FLAG_PEC_PERPVC = 'N'
          Then  'O' --Si le flag est à Non alors on force la perennité à Oui
        Else    SFM.PERNNT_IN
  End                                                              As PERNNT_IN                      ,
  Case  When SFM.ACT_FLAG_PEC_PERPVC <> 'N'
          Then   SFM.PERNNT_END_DT 
        Else    null
  End                                                                       As PERNNT_END_DT                  ,
    Case  When SFM.ACT_FLAG_PEC_PERPVC <> 'N'
          Then   SFM.PERNNT_MOTIF 
        Else    null
  End                                                                       As PERNNT_MOTIF,
  SFM.PERNNT_CALC_END_DT                                                    As PERNNT_CALC_END_DT             ,
  SFM.MIGRA_DT                                                              As MIGRA_DT                       ,
  SFM.MIGRA_NEXT_OFFRE                                                      As MIGRA_NEXT_OFFRE               ,
  SFM.SEG_PRES_PARC_COMMANDE                                                As PRES_SEGMENT_IN_PARK_BEFORE_IN ,
  Case  When  (SFM.ORDER_DEPOSIT_DT + SFM.DELIVERY_DEAD_LINE_NU) >= SFM.SEG_FIND_LIVR_DT
          Then SFM.SEG_FIND_LIVR_DT 
        Else Null
  End                                                                       As SEGMENT_DELIVERY_IN_PARK_DT    ,
  SFM.ORDER_CANCELING_DT                                                    As ORDER_CANCELING_DT             ,
  SFM.DMC_LINE_ID                                                           As LINE_ID                        ,
  SFM.DMC_MASTER_LINE_ID                                                    As MASTER_LINE_ID                 ,
  Null                                                                      As CUST_TYPE_CD                   ,
  Coalesce(SFM.PAR_ADV_DOSSIER_NU,'0000000000')                             As MSISDN_ID                      ,
  Coalesce(SFM.PAR_ND,'0000000000')                                         As NDS_VALUE_DS                   ,
  Coalesce(SFM.PAR_EXTERNAL_PARTY_ID,SFM.PAR_EXTERNAL_PARTY_FREG_ID)        As EXTERNAL_PARTY_ID              ,
  SFM.PAR_AID                                                               As RES_VALUE_DS                   ,
  SFM.PAR_ACCES_SERVICE                                                     As PAR_ACCES_SERVICE              ,
  Null                                                                      As TAC_CD                         ,
  SFM.PAR_MOB_IMEI                                                          As IMEI_CD                        ,
  SFM.PAR_MOB_IMSI                                                          As IMSI_CD                        ,
  Null                                                                      As HOM_START_DT                   ,
  Null                                                                      As MOB_START_DT                   ,
  SFM.PAR_SCORE_NU_INT                                                      As I_SCORE_VALUE                  ,
  SFM.PAR_TRESHOLD_NU_INT                                                   As I_SCORE_TRESHOLD               ,
  Case  When SFM.PAR_SCORE_IN_INT = 'O'
          Then  1
        Else    0
  End                                                                       As I_SCORE_IN                     ,
  SFM.PAR_SCORE_NU_MOB                                                      As M_SCORE_VALUE                  ,
  SFM.PAR_TRESHOLD_NU_MOB                                                   As M_SCORE_TRESHOLD               ,
  SFM.PAR_SCORE_IN_MOB                                                      As M_SCORE_IN                     ,
  Case
    When SFM.OTO_OSCAR_VALUE_NU ='S' Then '-1'
    Else SFM.OTO_OSCAR_VALUE_NU
  End                                                                       As OSCAR_VALUE                    ,
  '${P_PIL_380}'                                                            AS CUST_BU_TYPE_CD                ,
  SFM.PAR_BU_CD                                                             As CUST_BU_CD                     ,
  '${P_PIL_372}'                                                            As ADDRESS_TYPE                   ,
  Trim(
  Coalesce(SFM.PAR_BILL_ADRESS_1,'') || 
  Coalesce(SFM.PAR_BILL_CD_POSTAL,'') || ' ' || 
  Coalesce(SFM.PAR_BILL_ADRESS_4,'')
      )                                                                     As ADDRESS_CONCAT_NM              ,
  
  SFM.PAR_POSTAL_CD                                                         As POSTAL_CD                      ,
  SFM.PAR_INSEE_CD                                                          As INSEE_CD                       ,
  Case When COM_O${KNB_SUFFIX}.IsNumber(SFM.PAR_BU_CD)=1
         Then SFM.PAR_BU_CD
       Else Null
  End                                                                      As BU_CD                              ,
  SFM.PAR_DEPRTMNT_ID                                                      As DEPARTMNT_ID                       ,
  SFM.PAR_GEO_MACROZONE                                                    as PAR_GEO_MACROZONE                  ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_UNIFIED_PARTY_ID
    Else SFM.PAR_UNIFIED_PARTY_ID
  End                                                                      as PAR_UNIFIED_PARTY_ID               ,
  SFM.PAR_PARTY_REGRPMNT_ID                                                as PAR_PARTY_REGRPMNT_ID              ,
  SFM.PAR_CID_ID                                                           as PAR_CID_ID                         ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_PID_ID
    Else SFM.PAR_PID_ID
  End                                                                      as PAR_PID_ID                         ,
  SFM.PAR_FIRST_IN                                                         as PAR_FIRST_IN                       ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.ORG_AGENT_IOBSP
    Else SFM.ORG_AGENT_IOBSP
  End                                                                      as ORG_AGENT_IOBSP                    ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_IOBSP
    Else SFM.ORG_EDO_IOBSP
  End                                                                      as ORG_EDO_IOBSP                      ,
  SFM.PAR_IRIS2000_CD                                                      As PAR_IRIS2000_CD                    ,
  Case When SFM.ACT_UNITE_CD ='${P_PIL_620}' --Unité = NB
         Then Null
       Else Coalesce(SFM.ACT_DELTA_TARIF,0)
  End                                                                      as ACT_CA_LINE_AM                    ,
  SFM.PAR_MOB_SIM                                                          As SIM_CD                             ,
  Null                                                                     As SIM_EAN_CD                         ,
  SFM.ORG_RESP_AGENT_ID                                                    As ORG_RESP_ID                        ,
  SFM.CHECK_INITIAL_STATUS_CD                                              As CHECK_INITIAL_STATUS_CD            ,
  SFM.CHECK_NAT_STATUS_CD                                                  As CHECK_NAT_STATUS_CD                ,
  SFM.CHECK_NAT_COMMENT                                                    As CHECK_NAT_COMMENT                  ,
  SFM.CHECK_NAT_STATUS_LN                                                  As CHECK_NAT_STATUS_LN                ,
  SFM.CHECK_LOC_STATUS_CD                                                  As CHECK_LOC_STATUS_CD                ,
  SFM.CHECK_LOC_COMMENT                                                    As CHECK_LOC_COMMENT                  ,
  SFM.CHECK_LOC_STATUS_LN                                                  As CHECK_LOC_STATUS_LN                ,
  SFM.CHECK_VALIDT_DT                                                      As CHECK_VALIDT_DT                    ,
  Null                                                                     As ACT_END_UNIFIED_DT                 ,
  Null                                                                     As ACT_END_UNIFIED_DS                 ,
  SFM.CLOSURE_DT                                                           As ACT_CLOSURE_DT                     ,
  Case When SFM.CLOSURE_DT Is Not Null
       Then 'Acte Clos'        
  End                                                                      As ACT_CLOSURE_DS                     ,
  SFM.HOT_IN                                                               As HOT_IN                             ,
  SFM.RUN_ID                                                               As RUN_ID                             ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS                        ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS                      ,
  1                                                                        As FRESH_IN                           ,
  0                                                                        As COHERENCE_IN                        
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB SFM
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL DIGITAL
    On SFM.ACTE_ID            = DIGITAL.ACTE_ID
    And SFM.ORDER_DEPOSIT_DT  = DIGITAL.ACT_DT
    And DIGITAL.CURRENT_IN = 1
--Left Outer Join ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_MOB P_SOFTM
  --  On SFM.ACTE_ID            = P_SOFTM.ACTE_ID
  --  And SFM.ORDER_DEPOSIT_DT  = P_SOFTM.ORDER_DEPOSIT_DT
Where
  (1=1)
  And Substr(SFM.ACT_CD,1,3)          Not In (${L_PIL_036})
  And SFM.ACT_SEG_COM_ID_FINAL        <> '${P_PIL_295}'
  And SFM.ACT_CD                      <> '${P_PIL_067}'
  And SFM.ORDER_DEPOSIT_DT            > '20130402' 
  And SFM.HOT_IN                      = 0
  And SFM.ORDER_DEPOSIT_DT            >= Current_date - 250
  And SFM.ORG_CHANEL_CD                IN ('Online','DNU')
  And ((SFM.LAST_MODIF_TS             >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And SFM.LAST_MODIF_TS  <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') or SFM.ORDER_DEPOSIT_DT > Current_date - 15)
  And SFM.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
  And Not Exists (
    Select 'X' 
    From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTM SM
    Where SM.ACTE_ID = DIGITAL.ACTE_ID
    And SM.ACT_DT  = DIGITAL.ACT_DT
  )
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTM;
.if errorcode <> 0 then .quit 1;

