--$HEADER:   %HEADER% 
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_CHO_AlimCold_ORD_T_ACTE_UNIFIED_CHO.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source CHO dans la table ORD_T_ACTE_UNIFIED_CHO  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 30/05/2013     CBR         Création
-- 26/03/2014     AID         Indus 
-- 02/08/2014     GMA         Evolution du retour CSO + gestion des reprises
-- 19/06/2015     OCH         Modif: digital
-- 07/01/2016     MDE         Evolution Calcul CA
-- 28/12/2016     JCR         Modif Ajout Champs VA + ajout QC 1235 sur Chorus
-- 14/03/2017     HLA         Modification 
-- 21/11/2017     HOB         Alimentation Champs IOBSP
-- 02/07/2020     EVI         PILCOM-498 : Indicateur eSim - New Champ SIM_EAN_CD
-- 30/09/2021     EVI         PILCOM-1023 : Refonte VU - Suppression champs obsolètes
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_CHO --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO 
(
  ACTE_ID                         ,
  OPERATOR_PROVIDER_ID            ,
  INTRNL_SOURCE_ID                ,
  TYPE_SOURCE_ID                  ,
  MASTER_ACTE_ID                  ,
  MASTER_INTRNL_SOURCE_ID         ,
  MASTER_FLAG                     ,
  MASTER_NB_FOUND                 ,
  CPLT_ACTE_ID                    ,
  CPLT_INTRNL_SOURCE_ID           ,
  CPLT_IN                         ,
  RULE_ID                         ,
  OFFSET_NB                       ,
  ACT_TYPE                        ,
  ORDER_EXTERNAL_ID               ,
  STATUS_CD                       ,
  ACT_UNIFIED_STATUS_CD           ,
  ACT_TS                          ,
  ACT_DT                          ,
  ACT_HH                          ,
  ACT_LAST_UPD_TS                 ,
  ACT_PRODUCT_ID_PRE              ,
  ACT_SEG_COM_ID_PRE              ,
  ACT_SEG_COM_AGG_ID_PRE          ,
  ACT_CODE_MIGR_PRE               ,
  ACT_OPER_ID_PRE                 ,
  ACT_PRODUCT_ID_FINAL            ,
  ACT_SEG_COM_ID_FINAL            ,
  ACT_SEG_COM_AGG_ID_FINAL        ,
  ACT_CODE_MIGR_FINAL             ,
  ACT_OPER_ID_FINAL               ,
  ACT_TYPE_SERVICE_FINAL          ,
  ACT_TYPE_COMMANDE_ID            ,
  ACT_DELTA_TARIF                 ,
  ACT_CD                          ,
  ACT_REM_ID                      ,
  ACT_FLAG_ACT_REM                ,
  ACT_FLAG_PEC_PERPVC             ,
  ACT_FLAG_PVC_REM                ,
  ACT_ACTE_VALO                   ,
  ACT_ACTE_FAMILLE_KPI            ,
  ACT_PERIODE_ID                  ,
  ACT_PERIODE_STATUS              ,
  ACT_PERIODE_CLOSURE_DT          ,
  ORIGIN_CD                       ,
  AGENT_ID                        ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  ORG_AGENT_IOBSP                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  UNIFIED_SHOP_CD                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ACTIVITY_CD                     ,
  ACTIVITY_GROUPNG_CD             ,
  AUTO_ACTIVITY_IN                ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            ,
  CONFIRMATION_IN                 ,
  CONCLDD_IN                      ,
  COMPTTN_IN                      ,
  COMPTTN_ID                      ,
  PERNNT_IN                       ,
  PERNNT_END_DT                   ,
  PERNNT_MOTIF                    ,
  PERNNT_CALC_END_DT              ,
  MIGRA_DT                        ,
  MIGRA_NEXT_OFFRE                ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN  ,
  SEGMENT_DELIVERY_IN_PARK_DT     ,
  ORDER_CANCELING_DT              ,
  LINE_ID                         ,
  MASTER_LINE_ID                  ,
  CUST_TYPE_CD                    ,
  MSISDN_ID                       ,
  NDS_VALUE_DS                    ,
  EXTERNAL_PARTY_ID               ,
  RES_VALUE_DS                    ,
  PAR_ACCES_SERVICE               ,
  TAC_CD                          ,
  IMEI_CD                         ,
  IMSI_CD                         ,
  HOM_START_DT                    ,
  MOB_START_DT                    ,
  I_SCORE_VALUE                   ,
  I_SCORE_TRESHOLD                ,
  I_SCORE_IN                      ,
  M_SCORE_VALUE                   ,
  M_SCORE_TRESHOLD                ,
  M_SCORE_IN                      ,
  OSCAR_VALUE                     ,
  CUST_BU_TYPE_CD                 ,
  CUST_BU_CD                      ,
  ADDRESS_TYPE                    ,
  ADDRESS_CONCAT_NM               ,
  POSTAL_CD                       ,
  INSEE_CD                        ,
  BU_CD                           ,
  DEPARTMNT_ID                    ,
  PAR_GEO_MACROZONE               ,
  PAR_UNIFIED_PARTY_ID            ,
  PAR_PARTY_REGRPMNT_ID           ,
  PAR_CID_ID                      ,
  PAR_PID_ID                      ,
  PAR_FIRST_IN                    ,
  PAR_IRIS2000_CD                 ,
  ACT_CA_LINE_AM                  ,
  SIM_CD                          ,
  SIM_EAN_CD                      ,
  ORG_RESP_ID                     ,
  CHECK_INITIAL_STATUS_CD         ,
  CHECK_NAT_STATUS_CD             ,
  CHECK_NAT_COMMENT               ,
  CHECK_NAT_STATUS_LN             ,
  CHECK_LOC_STATUS_CD             ,
  CHECK_LOC_COMMENT               ,
  CHECK_LOC_STATUS_LN             ,
  CHECK_VALIDT_DT                 ,
  ACT_END_UNIFIED_DT              ,
  ACT_END_UNIFIED_DS              ,
  ACT_CLOSURE_DT                  ,
  ACT_CLOSURE_DS                  ,
  HOT_IN                          ,
  RUN_ID                          ,
  CREATION_TS                     ,
  LAST_MODIF_TS                   ,
  FRESH_IN                        ,
  COHERENCE_IN                    
)
Select
  CHO.ACTE_ID                                                               As ACTE_ID                          ,
  CHO.OPERATOR_PROVIDER_ID                                                  As OPERATOR_PROVIDER_ID             ,
  CHO.INTRNL_SOURCE_ID                                                      As INTRNL_SOURCE_ID                 ,
  '${P_PIL_368}'                                                            As TYPE_SOURCE_ID                   ,
  CHO.ACTE_ID                                                               As MASTER_ACTE_ID                   ,
  CHO.INTRNL_SOURCE_ID                                                      As MASTER_INTRNL_SOURCE_ID          ,
  ${P_PIL_354}                                                              As MASTER_FLAG                      ,
  ${P_PIL_375}                                                              As MASTER_NB_FOUND                  ,
  Null                                                                      As CPLT_ACTE_ID                     ,
  Null                                                                      As CPLT_INTRNL_SOURCE_ID            ,
  '${P_PIL_388}'                                                            As CPLT_IN                          ,
  '${P_PIL_362}'                                                            As RULE_ID                          ,
  Null                                                                      As OFFSET_NB                        ,
  '${P_PIL_324}'                                                            As ACT_TYPE                         ,
  CHO.EXTERNAL_INT_ID                                                       As ORDER_EXTERNAL_ID                ,
  '${P_PIL_397}'                                                            As STATUS_CD                        ,
  Case When CHO.CONCURENCE_IN = 'O' Then '${P_PIL_385}'
       When CHO.CONFIRMATION_IN = 'N' Then '${P_PIL_386}' 
       When CHO.PERENNITE_IN = 'O' Then '${P_PIL_384}' 
       When CHO.DELIVERY_IN = 'O' And CHO.PERENNITE_IN = 'N' Then '${P_PIL_387}' 
       When CHO.DELIVERY_IN = 'O' Then '${P_PIL_383}' 
       When CHO.CONFIRMATION_IN = 'O' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                       As ACT_UNIFIED_STATUS_CD            ,
  CHO.INT_DEPOSIT_TS                                                        As ACT_TS                           ,
  CHO.INT_DEPOSIT_DT                                                        As ACT_DT                           ,
  Extract(HOUR From CHO.INT_DEPOSIT_TS)                                     As ACT_HH                           ,
  CHO.INT_MODIF_TS                                                          As ACT_LAST_UPD_TS                  ,
  Case  When CHO.ACT_SEG_COM_ID_PRE Is Not Null
          Then CHO.ACT_PRODUCT_ID_PRE
        Else Null
  End                                                                       As ACT_PRODUCT_ID_PRE               ,
  CHO.ACT_SEG_COM_ID_PRE                                                    As ACT_SEG_COM_ID_PRE               ,
  Case  When CHO.ACT_SEG_COM_AGG_ID_PRE Is Not Null
          Then CHO.ACT_SEG_COM_AGG_ID_PRE
        Else Null
  End                                                                       As ACT_SEG_COM_AGG_ID_PRE           ,
  Case  When CHO.ACT_CODE_MIGR_PRE Is Not Null
          Then CHO.ACT_CODE_MIGR_PRE
        Else Null
  End                                                                       As ACT_CODE_MIGR_PRE                ,
  Case When CHO.ACT_SEG_COM_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                       As ACT_OPER_ID_PRE                  ,
  CHO.ACT_PRODUCT_ID_FINAL                                                  As ACT_PRODUCT_ID_FINAL             ,
  CHO.ACT_SEG_COM_ID_FINAL                                                  As ACT_SEG_COM_ID_FINAL             ,
  CHO.ACT_SEG_COM_AGG_ID_FINAL                                              As ACT_SEG_COM_AGG_ID_FINAL         ,
  CHO.ACT_CODE_MIGR_FINAL                                                   As ACT_CODE_MIGR_FINAL              ,
  Case  When CHO.SOLDOFF_SRC_CD in ('MCC','GOC','MOC') --MCC,GOC,MOC alors c'est un Maintien
          Then  'INI'
        When CHO.SOLDOFF_SRC_CD in ('SOC') -- SOC alors c'est une Suppression
          Then  'RMV'
        When CHO.SOLDOFF_SRC_CD in ('GCC') --GCC alors c'est une Migration
          Then  'ADD'
        When CHO.SOLDOFF_SRC_CD in ('NCC','AOC') -- NCC,AOC alors c'est une Acquisition
          Then  'ADD'
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Migration alors c'est une Migration
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Migration')
          Then  'ADD'
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Suppression alors c'est une Suppression
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Suppression')
          Then  'RMV'
        Else    'ADD'
  End                                                                       As ACT_OPER_ID_FINAL                ,
  CHO.ACT_TYPE_SERVICE_FINAL                                                As ACT_TYPE_SERVICE_FINAL           ,
  CHO.ACT_TYPE_COMMANDE_ID                                                  As ACT_TYPE_COMMANDE_ID             ,
  CHO.ACT_DELTA_TARIF                                                       As ACT_DELTA_TARIF                  ,
  CHO.ACT_CD                                                                As ACT_CD                           ,
  CHO.ACT_REM_ID                                                            As ACT_REM_ID                       ,
  CHO.ACT_FLAG_ACT_REM                                                      As ACT_FLAG_ACT_REM                 ,
  CHO.ACT_FLAG_PEC_PERPVC                                                   As ACT_FLAG_PEC_PERPVC              ,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And CHO.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And CHO.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And CHO.ORG_REM_CHANNEL_CD In (${L_PIL_043})
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    And CHO.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And CHO.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then  'O'
       Else   'N'
  End                                                                       As ACT_FLAG_PVC_REM                 ,
  CHO.ACT_ACTE_VALO                                                         As ACT_ACTE_VALO                    ,
  CHO.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI             ,
  CHO.ACT_PERIODE_ID                                                        As ACT_PERIODE_ID                   ,
  CHO.ACT_PERIODE_STATUS                                                    As ACT_PERIODE_STATUS               ,
  CHO.ACT_PERIODE_CLOSURE_DT                                                As ACT_PERIODE_CLOSURE_DT           ,
  CHO.ORIG_DEM_SC                                                           As ORIGIN_CD                        ,
  CHO.ORG_AGENT_ID                                                          As AGENT_ID                         ,
  CHO.ORG_AGENT_ID                                                          As AGENT_ID_UPD                     ,
  Null                                                                      As AGENT_ID_UPD_DT                  ,
  CHO.ORG_AGENT_IOBSP                                                       As ORG_AGENT_IOBSP                  ,
  CHO.ORG_PRENOM                                                            As AGENT_FIRST_NAME                 ,
  CHO.ORG_NOM                                                               As AGENT_LAST_NAME                  ,
  Null                                                                      As UNIFIED_SHOP_CD                  ,
  CHO.ORG_CANAL_ID_MACRO_SC                                                 As ORG_SPE_CANAL_ID_MACRO           ,
  CHO.ORG_CANAL_ID_SC                                                       As ORG_SPE_CANAL_ID                 ,
  CHO.ORG_REM_CHANNEL_CD                                                    As ORG_REM_CHANNEL_CD               ,
  CHO.ORG_CHANNEL_CD                                                        As ORG_CHANNEL_CD                   ,
  CHO.ORG_SUB_CHANNEL_CD                                                    As ORG_SUB_CHANNEL_CD               ,
  CHO.ORG_SUB_SUB_CHANNEL_CD                                                As ORG_SUB_SUB_CHANNEL_CD           ,
  CHO.ORG_GT_ACTIVITY                                                       As ORG_GT_ACTIVITY                  ,
  CHO.ORG_FIDELISATION                                                      As ORG_FIDELISATION                 ,
  CHO.ORG_WEB_ACTIVITY                                                      As ORG_WEB_ACTIVITY                 ,
  CHO.ORG_AUTO_ACTIVITY                                                     As ORG_AUTO_ACTIVITY                ,
  CHO.ORG_EDO_ID                                                            As ORG_EDO_ID                       ,
  CHO.ORG_TYPE_EDO                                                          As ORG_TYPE_EDO                     ,
  CHO.ORG_EDO_IOBSP                                                         As ORG_EDO_IOBSP                    ,
  CHO.ORG_FLAG_PLT_CONV                                                     As ORG_FLAG_PLT_CONV                ,
  CHO.ORG_FLAG_TEAM_MKT                                                     As ORG_FLAG_TEAM_MKT                ,
  CHO.ORG_FLAG_TYPE_CMP                                                     As ORG_FLAG_TYPE_CMP                ,
  Null                                                                      As ORG_RESP_EDO_ID                  ,
  Null                                                                      As ORG_RESP_TYPE_EDO                ,
  Null                                                                      As ORG_RESP_FLAG_PLT_CONV           ,
  Null                                                                      As ACTIVITY_CD                      ,
  Null                                                                      As ACTIVITY_GROUPNG_CD              ,
  Null                                                                      As AUTO_ACTIVITY_IN                 ,
  Case  When CHO.ORG_EDO_ID Is Not Null
          Then 'O3'
        Else CHO.ORG_REF_TRAV
  END                                                                       As ORG_TYPE_CD                      ,
  Null                                                                      As ORG_TEAM_TYPE_ID                 ,
  Trim(CHO.ORG_TEAM_LEVEL_1_CD)                                             As ORG_TEAM_LEVEL_1_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_1_DS)                                             As ORG_TEAM_LEVEL_1_DS              ,
  Trim(CHO.ORG_TEAM_LEVEL_2_CD)                                             As ORG_TEAM_LEVEL_2_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_2_DS)                                             As ORG_TEAM_LEVEL_2_DS              ,
  Trim(CHO.ORG_TEAM_LEVEL_3_CD)                                             As ORG_TEAM_LEVEL_3_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_3_DS)                                             As ORG_TEAM_LEVEL_3_DS              ,
  Trim(CHO.ORG_TEAM_LEVEL_4_CD)                                             As ORG_TEAM_LEVEL_4_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_4_DS)                                             As ORG_TEAM_LEVEL_4_DS              ,
  Trim(CHO.WORK_TEAM_LEVEL_1_CD)                                            As WORK_TEAM_LEVEL_1_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_1_DS)                                            As WORK_TEAM_LEVEL_1_DS             ,
  Trim(CHO.WORK_TEAM_LEVEL_2_CD)                                            As WORK_TEAM_LEVEL_2_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_2_DS)                                            As WORK_TEAM_LEVEL_2_DS             ,
  Trim(CHO.WORK_TEAM_LEVEL_3_CD)                                            As WORK_TEAM_LEVEL_3_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_3_DS)                                            As WORK_TEAM_LEVEL_3_DS             ,
  Trim(CHO.WORK_TEAM_LEVEL_4_CD)                                            As WORK_TEAM_LEVEL_4_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_4_DS)                                            As WORK_TEAM_LEVEL_4_DS             ,
  CHO.CONFIRMATION_IN                                                       As CONFIRMATION_IN                  ,
  --Flag Si la vente en conclue
  Null                                                                      As CONCLDD_IN                       ,
  --Flag De concurrence
  Null                                                                      As COMPTTN_IN                       ,
  Null                                                                      As COMPTTN_ID                       ,
  CHO.PERNNT_IN                                                             As PERNNT_IN                        ,
  CHO.PERNNT_END_DT                                                         As PERNNT_END_DT                    ,
  CHO.PERNNT_MOTIF                                                          As PERNNT_MOTIF                     ,
  CHO.PERNNT_CALC_END_DT                                                    As PERNNT_CALC_END_DT               ,
  CHO.MIGRA_DT                                                              As MIGRA_DT                         ,
  CHO.MIGRA_NEXT_OFFRE                                                      As MIGRA_NEXT_OFFRE                 ,
  Case  When CHO.SOLDOFF_SRC_CD in ('MCC','GOC','MOC') --MCC,GOC,MOC alors c'est un Maintien
          Then  0
        When CHO.SOLDOFF_SRC_CD in ('SOC') -- SOC alors c'est une Suppression
          Then  0
        When CHO.SOLDOFF_SRC_CD in ('GCC') --GCC alors c'est une Migration
          Then  CHO.SEG_PRES_PARC_COMMANDE
        When CHO.SOLDOFF_SRC_CD in ('NCC','AOC') -- NCC,AOC alors c'est une Acquisition
          Then  CHO.SEG_PRES_PARC_COMMANDE
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Migration alors c'est une Migration
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Migration')
          Then  CHO.SEG_PRES_PARC_COMMANDE
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Suppression alors c'est une Suppression
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Suppression')
          Then  0
        --Par défaut Acquisition -> On met la pres en parc
        Else    CHO.SEG_PRES_PARC_COMMANDE
  End                                                                       As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  Case  When  ( CHO.INT_DEPOSIT_DT + CHO.DELIVERY_DEAD_LINE_NU ) >= CHO.SEG_FIND_LIVR_DT
          Then CHO.SEG_FIND_LIVR_DT 
        Else Null
  End                                                                    As SEGMENT_DELIVERY_IN_PARK_DT      ,
  CHO.ORDER_CANCELING_DT                                                    As ORDER_CANCELING_DT               ,
  CHO.DMC_LINE_ID                                                           As LINE_ID                          ,
  CHO.DMC_MASTER_LINE_ID                                                    As MASTER_LINE_ID                   ,
  CHO.PAR_TYPE                                                              As CUST_TYPE_CD                     ,
  Coalesce(CHO.DOSSIER_NU, '0000000000')                                    As MSISDN_ID                        ,
  Coalesce(CHO.PAR_ND, '0000000000')                                        As NDS_VALUE_DS                     ,
  Coalesce(CHO.CLIENT_NU, '0000000000')                                     As EXTERNAL_PARTY_ID                ,
  CHO.PAR_AID                                                               As RES_VALUE_DS                     ,
  Null                                                                      As PAR_ACCES_SERVICE                ,
  Null                                                                      As TAC_CD                           ,
  Null                                                                      As IMEI_CD                          ,
  CHO.PAR_IMSI                                                              As IMSI_CD                          ,
  CHO.DMC_ACTIVATION_DT_INT                                                 As HOM_START_DT                     ,
  CHO.DMC_ACTIVATION_DT                                                     As MOB_START_DT                     ,
  CHO.PAR_SCORE_NU_INT                                                      As I_SCORE_VALUE                    ,
  CHO.PAR_TRESHOLD_NU_INT                                                   As I_SCORE_TRESHOLD                 ,
  Case
        When CHO.PAR_SCORE_IN_INT = 'O'
          Then 1
        Else 0
  End                                                                       As I_SCORE_IN                       ,
  CHO.PAR_SCORE_NU_MOB                                                      As M_SCORE_VALUE                    ,
  Case
        When CHO.PAR_TRESHOLD_NU_MOB > 100
          Then -1
        Else CHO.PAR_TRESHOLD_NU_MOB
  End                                                                       As M_SCORE_TRESHOLD                 ,
  CHO.PAR_SCORE_IN_MOB                                                      As M_SCORE_IN                       ,
  Cast(Case When CHO.OTO_OSCAR_VALUE_NU = 'SC' Then -1
            Else CHO.OTO_OSCAR_VALUE_NU
  End As BYTEINT)                                                           As OSCAR_VALUE                      ,
  '${P_PIL_376}'                                                            As CUST_BU_TYPE_CD                  ,
  CHO.PAR_USCM                                                              As CUST_BU_CD                       ,
  '${P_PIL_373}'                                                            As ADDRESS_TYPE                     ,
  Trim(
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_1 = 'null' Then Null Else PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_2 = 'null' Then Null Else PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_3 = 'null' THEN Null Else PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(CHO.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_4 = 'null' Then Null Else PAR_BILL_ADRESS_4 End,'')) || ' ' ||
    Trim(Coalesce(CHO.PAR_BILL_VILLE,'')) 
  )                                                                         As ADDRESS_CONCAT_NM                ,
  Coalesce(CHO.PAR_POSTAL_CD,CHO.PAR_BILL_CD_POSTAL )                       As POSTAL_CD                        ,
  CHO.PAR_INSEE_CD                                                          As INSEE_CD                         ,
  CHO.PAR_BU_CD                                                             As BU_CD                            ,
  Coalesce(CHO.PAR_DEPRTMNT_ID ,CHO.PAR_DO )                                As DEPARTMNT_ID                     ,
  CHO.PAR_GEO_MACROZONE                                                     As PAR_GEO_MACROZONE                ,
  CHO.PAR_UNIFIED_PARTY_ID                                                  As PAR_UNIFIED_PARTY_ID             ,
  CHO.PAR_PARTY_REGRPMNT_ID                                                 As PAR_PARTY_REGRPMNT_ID            ,
  Null                                                                      as PAR_CID_ID                       ,
  Null                                                                      as PAR_PID_ID                       ,
  Null                                                                      as PAR_FIRST_IN                     ,
  CHO.PAR_IRIS2000_CD                                                       As PAR_IRIS2000_CD                  ,
  Case When CHO.ACT_UNITE_CD ='${P_PIL_620}' --Unité = NB
         Then Null
       Else Coalesce(CHO.ACT_DELTA_TARIF,0)
  End                                                                      as ACT_CA_LINE_AM                    ,

  CHO.PAR_MOB_SIM                                                           As SIM_CD                           ,
  Null                                                                      As SIM_EAN_CD                       ,
  CHO.ORG_RESP_AGENT_ID                                                     As ORG_RESP_ID                      ,
  CHO.CHECK_INITIAL_STATUS_CD                                               As CHECK_INITIAL_STATUS_CD          ,
  CHO.CHECK_NAT_STATUS_CD                                                   As CHECK_NAT_STATUS_CD              ,
  CHO.CHECK_NAT_COMMENT                                                     As CHECK_NAT_COMMENT                ,
  CHO.CHECK_NAT_STATUS_LN                                                   As CHECK_NAT_STATUS_LN              ,
  CHO.CHECK_LOC_STATUS_CD                                                   As CHECK_LOC_STATUS_CD              ,
  CHO.CHECK_LOC_COMMENT                                                     As CHECK_LOC_COMMENT                ,
  CHO.CHECK_LOC_STATUS_LN                                                   As CHECK_LOC_STATUS_LN              ,
  CHO.CHECK_VALIDT_DT                                                       As CHECK_VALIDT_DT                  ,
  Null                                                                      As ACT_END_UNIFIED_DT               ,
  Null                                                                      As ACT_END_UNIFIED_DS               ,
  CHO.CLOSURE_DT                                                            As ACT_CLOSURE_DT                   ,
  Case When CHO.CLOSURE_DT Is Not Null
        Then 'Acte Clos'
  End                                                                       As ACT_CLOSURE_DS                   ,
  0                                                                         As HOT_IN                           ,
  Null                                                                      As RUN_ID                           ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                 As CREATION_TS                      ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                 As LAST_MODIF_TS                    ,
  1                                                                         As FRESH_IN                         ,
  0                                                                         As COHERENCE_IN                     
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_CHO As CHO  
  Left Outer Join ${KNB_IBU_GLB_V}.VPOCCSLMAT As VPOCCSLMAT
    On  CHO.ORG_POC_XI = VPOCCSLMAT.XI
Where
(1=1)
  And Substr(CHO.ACT_CD,1,3)        Not In (${L_PIL_036})
  And CHO.ACT_SEG_COM_ID_FINAL      <> '${P_PIL_295}'
  And CHO.ACT_CD                    <> '${P_PIL_067}'
  And CHO.ACT_PERIODE_ID            > 12
  And CHO.INT_DEPOSIT_DT            >= current_date - 250
  And ((CHO.LAST_MODIF_TS           >  '${KNB_PILCOM_EXTRACT_BORNE_INF}'  And CHO.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or CHO.INT_DEPOSIT_DT > current_date - 15)
  And CHO.HOT_IN                    = 0
  And CHO.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO;
.if errorcode <> 0 then .quit 1;


-- reccuperation des actes liés au même master

CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_MASTER_ACTE_CHO
(
MASTER_ACTE_ID BIGINT 
)
PRIMARY INDEX ( MASTER_ACTE_ID ) 
ON COMMIT PRESERVE ROWS ;

.if errorcode <> 0 then .quit 1 ;
--Reccuperation de tous les master acte_id pour les actes de la source CHO
Insert into ${KNB_TERADATA_USER}.ORD_V_MASTER_ACTE_CHO
(
  MASTER_ACTE_ID
)
Select distinct uni.MASTER_ACTE_ID As Master_ACTE_ID
From 
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED uni
  Inner Join ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO As CHO3
  On uni.ACTE_ID=CHO3.ACTE_ID
Where 
  (1=1)
  And uni.INTRNL_SOURCE_ID=2;

.if errorcode <> 0 then .quit 1;

Collect stat ${KNB_TERADATA_USER}.ORD_V_MASTER_ACTE_CHO column (MASTER_ACTE_ID) ;

.if errorcode <> 0 then .quit 1;

CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_ACTE_CHO
(
  ACTE_ID BIGINT 
)
PRIMARY INDEX ( ACTE_ID ) 
ON COMMIT PRESERVE ROWS ;

--les actes  de la source CHO qui ont le même master_acte_id
Insert into ${KNB_TERADATA_USER}.ORD_V_ACTE_CHO
(
    ACTE_ID
)
Select  distinct  uni2.ACTE_ID as acte_ID
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED As uni2
Inner  Join
  ${KNB_TERADATA_USER}.ORD_V_MASTER_ACTE_CHO tab2
  On uni2.MASTER_ACTE_ID=tab2.MASTER_ACTE_ID
Where 
  (1=1)
  And uni2.INTRNL_SOURCE_ID=2
  And  not exists (Select t.ACTE_ID From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO t where uni2.ACTE_ID=t.ACTE_ID  );
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_CHO column (ACTE_ID) ;

.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO 
(
  ACTE_ID                         ,
  OPERATOR_PROVIDER_ID            ,
  INTRNL_SOURCE_ID                ,
  TYPE_SOURCE_ID                  ,
  MASTER_ACTE_ID                  ,
  MASTER_INTRNL_SOURCE_ID         ,
  MASTER_FLAG                     ,
  MASTER_NB_FOUND                 ,
  CPLT_ACTE_ID                    ,
  CPLT_INTRNL_SOURCE_ID           ,
  CPLT_IN                         ,
  RULE_ID                         ,
  OFFSET_NB                       ,
  ACT_TYPE                        ,
  ORDER_EXTERNAL_ID               ,
  STATUS_CD                       ,
  ACT_UNIFIED_STATUS_CD           ,
  ACT_TS                          ,
  ACT_DT                          ,
  ACT_HH                          ,
  ACT_LAST_UPD_TS                 ,
  ACT_PRODUCT_ID_PRE              ,
  ACT_SEG_COM_ID_PRE              ,
  ACT_SEG_COM_AGG_ID_PRE          ,
  ACT_CODE_MIGR_PRE               ,
  ACT_OPER_ID_PRE                 ,
  ACT_PRODUCT_ID_FINAL            ,
  ACT_SEG_COM_ID_FINAL            ,
  ACT_SEG_COM_AGG_ID_FINAL        ,
  ACT_CODE_MIGR_FINAL             ,
  ACT_OPER_ID_FINAL               ,
  ACT_TYPE_SERVICE_FINAL          ,
  ACT_TYPE_COMMANDE_ID            ,
  ACT_DELTA_TARIF                 ,
  ACT_CD                          ,
  ACT_REM_ID                      ,
  ACT_FLAG_ACT_REM                ,
  ACT_FLAG_PEC_PERPVC             ,
  ACT_FLAG_PVC_REM                ,
  ACT_ACTE_VALO                   ,
  ACT_ACTE_FAMILLE_KPI            ,
  ACT_PERIODE_ID                  ,
  ACT_PERIODE_STATUS              ,
  ACT_PERIODE_CLOSURE_DT          ,
  ORIGIN_CD                       ,
  AGENT_ID                        ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  UNIFIED_SHOP_CD                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ACTIVITY_CD                     ,
  ACTIVITY_GROUPNG_CD             ,
  AUTO_ACTIVITY_IN                ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            ,
  CONFIRMATION_IN                 ,
  CONCLDD_IN                      ,
  COMPTTN_IN                      ,
  COMPTTN_ID                      ,
  PERNNT_IN                       ,
  PERNNT_END_DT                   ,
  PERNNT_MOTIF                    ,
  PERNNT_CALC_END_DT              ,
  MIGRA_DT                        ,
  MIGRA_NEXT_OFFRE                ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN  ,
  SEGMENT_DELIVERY_IN_PARK_DT     ,
  ORDER_CANCELING_DT              ,
  LINE_ID                         ,
  MASTER_LINE_ID                  ,
  CUST_TYPE_CD                    ,
  MSISDN_ID                       ,
  NDS_VALUE_DS                    ,
  EXTERNAL_PARTY_ID               ,
  RES_VALUE_DS                    ,
  PAR_ACCES_SERVICE               ,
  TAC_CD                          ,
  IMEI_CD                         ,
  IMSI_CD                         ,
  HOM_START_DT                    ,
  MOB_START_DT                    ,
  I_SCORE_VALUE                   ,
  I_SCORE_TRESHOLD                ,
  I_SCORE_IN                      ,
  M_SCORE_VALUE                   ,
  M_SCORE_TRESHOLD                ,
  M_SCORE_IN                      ,
  OSCAR_VALUE                     ,
  CUST_BU_TYPE_CD                 ,
  CUST_BU_CD                      ,
  ADDRESS_TYPE                    ,
  ADDRESS_CONCAT_NM               ,
  POSTAL_CD                       ,
  INSEE_CD                        ,
  BU_CD                           ,
  DEPARTMNT_ID                    ,
  PAR_IRIS2000_CD                 ,
  ACT_CA_LINE_AM                  ,
  SIM_CD                          ,
  SIM_EAN_CD                      ,
  ORG_RESP_ID                     ,
  CHECK_INITIAL_STATUS_CD         ,
  CHECK_NAT_STATUS_CD             ,
  CHECK_NAT_COMMENT               ,
  CHECK_NAT_STATUS_LN             ,
  CHECK_LOC_STATUS_CD             ,
  CHECK_LOC_COMMENT               ,
  CHECK_LOC_STATUS_LN             ,
  CHECK_VALIDT_DT                 ,
  ACT_END_UNIFIED_DT              ,
  ACT_END_UNIFIED_DS              ,
  ACT_CLOSURE_DT                  ,
  ACT_CLOSURE_DS                  ,
  HOT_IN                          ,
  RUN_ID                          ,
  CREATION_TS                     ,
  LAST_MODIF_TS                   ,
  FRESH_IN                        ,
  COHERENCE_IN                    
)
Select
  CHO.ACTE_ID                                                               As ACTE_ID                          ,
  CHO.OPERATOR_PROVIDER_ID                                                  As OPERATOR_PROVIDER_ID             ,
  CHO.INTRNL_SOURCE_ID                                                      As INTRNL_SOURCE_ID                 ,
  '${P_PIL_368}'                                                            As TYPE_SOURCE_ID                   ,
  CHO.ACTE_ID                                                               As MASTER_ACTE_ID                   ,
  CHO.INTRNL_SOURCE_ID                                                      As MASTER_INTRNL_SOURCE_ID          ,
  ${P_PIL_354}                                                              As MASTER_FLAG                      ,
  ${P_PIL_375}                                                              As MASTER_NB_FOUND                  ,
  Null                                                                      As CPLT_ACTE_ID                     ,
  Null                                                                      As CPLT_INTRNL_SOURCE_ID            ,
  '${P_PIL_388}'                                                            As CPLT_IN                          ,
  '${P_PIL_362}'                                                            As RULE_ID                          ,
  Null                                                                      As OFFSET_NB                        ,
  '${P_PIL_324}'                                                            As ACT_TYPE                         ,
  CHO.EXTERNAL_INT_ID                                                       As ORDER_EXTERNAL_ID                ,
  '${P_PIL_397}'                                                            As STATUS_CD                        ,
  Case When CHO.CONCURENCE_IN = 'O' Then '${P_PIL_385}'
       When CHO.CONFIRMATION_IN = 'N' Then '${P_PIL_386}' 
       When CHO.PERENNITE_IN = 'O' Then '${P_PIL_384}' 
       When CHO.DELIVERY_IN = 'O' And CHO.PERENNITE_IN = 'N' Then '${P_PIL_387}' 
       When CHO.DELIVERY_IN = 'O' Then '${P_PIL_383}' 
       When CHO.CONFIRMATION_IN = 'O' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                       As ACT_UNIFIED_STATUS_CD            ,
  CHO.INT_DEPOSIT_TS                                                        As ACT_TS                           ,
  CHO.INT_DEPOSIT_DT                                                        As ACT_DT                           ,
  Extract(HOUR From CHO.INT_DEPOSIT_TS)                                     As ACT_HH                           ,
  CHO.INT_MODIF_TS                                                          As ACT_LAST_UPD_TS                  ,
  Case  When CHO.ACT_SEG_COM_ID_PRE Is Not Null
          Then CHO.ACT_PRODUCT_ID_PRE
        Else Null
  End                                                                       As ACT_PRODUCT_ID_PRE               ,
  CHO.ACT_SEG_COM_ID_PRE                                                    As ACT_SEG_COM_ID_PRE               ,
  Case  When CHO.ACT_SEG_COM_AGG_ID_PRE Is Not Null
          Then CHO.ACT_SEG_COM_AGG_ID_PRE
        Else Null
  End                                                                       As ACT_SEG_COM_AGG_ID_PRE           ,
  Case  When CHO.ACT_CODE_MIGR_PRE Is Not Null
          Then CHO.ACT_CODE_MIGR_PRE
        Else Null
  End                                                                       As ACT_CODE_MIGR_PRE                ,
  Case When CHO.ACT_SEG_COM_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                       As ACT_OPER_ID_PRE                  ,
  CHO.ACT_PRODUCT_ID_FINAL                                                  As ACT_PRODUCT_ID_FINAL             ,
  CHO.ACT_SEG_COM_ID_FINAL                                                  As ACT_SEG_COM_ID_FINAL             ,
  CHO.ACT_SEG_COM_AGG_ID_FINAL                                              As ACT_SEG_COM_AGG_ID_FINAL         ,
  CHO.ACT_CODE_MIGR_FINAL                                                   As ACT_CODE_MIGR_FINAL              ,
  Case  When CHO.SOLDOFF_SRC_CD in ('MCC','GOC','MOC') --MCC,GOC,MOC alors c'est un Maintien
          Then  'INI'
        When CHO.SOLDOFF_SRC_CD in ('SOC') -- SOC alors c'est une Suppression
          Then  'RMV'
        When CHO.SOLDOFF_SRC_CD in ('GCC') --GCC alors c'est une Migration
          Then  'ADD'
        When CHO.SOLDOFF_SRC_CD in ('NCC','AOC') -- NCC,AOC alors c'est une Acquisition
          Then  'ADD'
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Migration alors c'est une Migration
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Migration')
          Then  'ADD'
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Suppression alors c'est une Suppression
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Suppression')
          Then  'RMV'
        Else    'ADD'
  End                                                                       As ACT_OPER_ID_FINAL                ,
  CHO.ACT_TYPE_SERVICE_FINAL                                                As ACT_TYPE_SERVICE_FINAL           ,
  CHO.ACT_TYPE_COMMANDE_ID                                                  As ACT_TYPE_COMMANDE_ID             ,
  CHO.ACT_DELTA_TARIF                                                       As ACT_DELTA_TARIF                  ,
  CHO.ACT_CD                                                                As ACT_CD                           ,
  CHO.ACT_REM_ID                                                            As ACT_REM_ID                       ,
  CHO.ACT_FLAG_ACT_REM                                                      As ACT_FLAG_ACT_REM                 ,
  CHO.ACT_FLAG_PEC_PERPVC                                                   As ACT_FLAG_PEC_PERPVC              ,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And CHO.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And CHO.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And CHO.ORG_REM_CHANNEL_CD In (${L_PIL_043})
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    And CHO.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And CHO.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then  'O'
       Else   'N'
  End                                                                       As ACT_FLAG_PVC_REM                 ,
  CHO.ACT_ACTE_VALO                                                         As ACT_ACTE_VALO                    ,
  CHO.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI             ,
  CHO.ACT_PERIODE_ID                                                        As ACT_PERIODE_ID                   ,
  CHO.ACT_PERIODE_STATUS                                                    As ACT_PERIODE_STATUS               ,
  CHO.ACT_PERIODE_CLOSURE_DT                                                As ACT_PERIODE_CLOSURE_DT           ,
  CHO.ORIG_DEM_SC                                                           As ORIGIN_CD                        ,
  trim(CHO.ORG_AGENT_ID )                                                   As AGENT_ID                         ,
  trim(CHO.ORG_AGENT_ID )                                                   As AGENT_ID_UPD                     ,
  Null                                                                      As AGENT_ID_UPD_DT                  ,
  CHO.ORG_PRENOM                                                            As AGENT_FIRST_NAME                 ,
  CHO.ORG_NOM                                                               As AGENT_LAST_NAME                  ,
  Null                                                                      As UNIFIED_SHOP_CD                  ,
  CHO.ORG_CANAL_ID_MACRO_SC                                                 As ORG_SPE_CANAL_ID_MACRO           ,
  CHO.ORG_CANAL_ID_SC                                                       As ORG_SPE_CANAL_ID                 ,
  CHO.ORG_REM_CHANNEL_CD                                                    As ORG_REM_CHANNEL_CD               ,
  CHO.ORG_CHANNEL_CD                                                        As ORG_CHANNEL_CD                   ,
  CHO.ORG_SUB_CHANNEL_CD                                                    As ORG_SUB_CHANNEL_CD               ,
  CHO.ORG_SUB_SUB_CHANNEL_CD                                                As ORG_SUB_SUB_CHANNEL_CD           ,
  CHO.ORG_GT_ACTIVITY                                                       As ORG_GT_ACTIVITY                  ,
  CHO.ORG_FIDELISATION                                                      As ORG_FIDELISATION                 ,
  CHO.ORG_WEB_ACTIVITY                                                      As ORG_WEB_ACTIVITY                 ,
  CHO.ORG_AUTO_ACTIVITY                                                     As ORG_AUTO_ACTIVITY                ,
  CHO.ORG_EDO_ID                                                            As ORG_EDO_ID                       ,
  CHO.ORG_TYPE_EDO                                                          As ORG_TYPE_EDO                     ,
  CHO.ORG_FLAG_PLT_CONV                                                     As ORG_FLAG_PLT_CONV                ,
  CHO.ORG_FLAG_TEAM_MKT                                                     As ORG_FLAG_TEAM_MKT                ,
  CHO.ORG_FLAG_TYPE_CMP                                                     As ORG_FLAG_TYPE_CMP                ,
  Null                                                                      As ORG_RESP_EDO_ID                  ,
  Null                                                                      As ORG_RESP_TYPE_EDO                ,
  Null                                                                      As ORG_RESP_FLAG_PLT_CONV           ,
  Null                                                                      As ACTIVITY_CD                      ,
  Null                                                                      As ACTIVITY_GROUPNG_CD              ,
  Null                                                                      As AUTO_ACTIVITY_IN                 ,
  Case  When CHO.ORG_EDO_ID Is Not Null
          Then 'O3'
        Else CHO.ORG_REF_TRAV
  END                                                                       As ORG_TYPE_CD                      ,
  Null                                                                      As ORG_TEAM_TYPE_ID                 ,
  Trim(CHO.ORG_TEAM_LEVEL_1_CD)                                             As ORG_TEAM_LEVEL_1_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_1_DS)                                             As ORG_TEAM_LEVEL_1_DS              ,
  Trim(CHO.ORG_TEAM_LEVEL_2_CD)                                             As ORG_TEAM_LEVEL_2_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_2_DS)                                             As ORG_TEAM_LEVEL_2_DS              ,
  Trim(CHO.ORG_TEAM_LEVEL_3_CD)                                             As ORG_TEAM_LEVEL_3_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_3_DS)                                             As ORG_TEAM_LEVEL_3_DS              ,
  Trim(CHO.ORG_TEAM_LEVEL_4_CD)                                             As ORG_TEAM_LEVEL_4_CD              ,
  Trim(CHO.ORG_TEAM_LEVEL_4_DS)                                             As ORG_TEAM_LEVEL_4_DS              ,
  Trim(CHO.WORK_TEAM_LEVEL_1_CD)                                            As WORK_TEAM_LEVEL_1_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_1_DS)                                            As WORK_TEAM_LEVEL_1_DS             ,
  Trim(CHO.WORK_TEAM_LEVEL_2_CD)                                            As WORK_TEAM_LEVEL_2_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_2_DS)                                            As WORK_TEAM_LEVEL_2_DS             ,
  Trim(CHO.WORK_TEAM_LEVEL_3_CD)                                            As WORK_TEAM_LEVEL_3_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_3_DS)                                            As WORK_TEAM_LEVEL_3_DS             ,
  Trim(CHO.WORK_TEAM_LEVEL_4_CD)                                            As WORK_TEAM_LEVEL_4_CD             ,
  Trim(CHO.WORK_TEAM_LEVEL_4_DS)                                            As WORK_TEAM_LEVEL_4_DS             ,
  CHO.CONFIRMATION_IN                                                       As CONFIRMATION_IN                  ,
  --Flag Si la vente en conclue
  Null                                                                      As CONCLDD_IN                       ,
  --Flag De concurrence
  Null                                                                      As COMPTTN_IN                       ,
  Null                                                                      As COMPTTN_ID                       ,
  CHO.PERNNT_IN                                                             As PERNNT_IN                        ,
  CHO.PERNNT_END_DT                                                         As PERNNT_END_DT                    ,
  CHO.PERNNT_MOTIF                                                          As PERNNT_MOTIF                     ,
  CHO.PERNNT_CALC_END_DT                                                    As PERNNT_CALC_END_DT               ,
  CHO.MIGRA_DT                                                              As MIGRA_DT                         ,
  CHO.MIGRA_NEXT_OFFRE                                                      As MIGRA_NEXT_OFFRE                 ,
  Case  When CHO.SOLDOFF_SRC_CD in ('MCC','GOC','MOC') --MCC,GOC,MOC alors c'est un Maintien
          Then  0
        When CHO.SOLDOFF_SRC_CD in ('SOC') -- SOC alors c'est une Suppression
          Then  0
        When CHO.SOLDOFF_SRC_CD in ('GCC') --GCC alors c'est une Migration
          Then  CHO.SEG_PRES_PARC_COMMANDE
        When CHO.SOLDOFF_SRC_CD in ('NCC','AOC') -- NCC,AOC alors c'est une Acquisition
          Then  CHO.SEG_PRES_PARC_COMMANDE
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Migration alors c'est une Migration
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Migration')
          Then  CHO.SEG_PRES_PARC_COMMANDE
        When CHO.SOLDOFF_SRC_CD in ('CMD') -- CMD et commentaire dit Suppression alors c'est une Suppression
          And Coalesce(CHO.RSFCOMMENTAIRE_DS, 'ND') in ('Suppression')
          Then  0
        --Par défaut Acquisition -> On met la pres en parc
        Else    CHO.SEG_PRES_PARC_COMMANDE
  End                                                                       As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  CHO.SEG_FIND_LIVR_DT                                                      As SEGMENT_DELIVERY_IN_PARK_DT      ,
  CHO.ORDER_CANCELING_DT                                                    As ORDER_CANCELING_DT               ,
  CHO.DMC_LINE_ID                                                           As LINE_ID                          ,
  CHO.DMC_MASTER_LINE_ID                                                    As MASTER_LINE_ID                   ,
  CHO.PAR_TYPE                                                              As CUST_TYPE_CD                     ,
  Coalesce(CHO.DOSSIER_NU, '0000000000')                                    As MSISDN_ID                        ,
  Coalesce(CHO.PAR_ND, '0000000000')                                        As NDS_VALUE_DS                     ,
  Coalesce(CHO.CLIENT_NU, '0000000000')                                     As EXTERNAL_PARTY_ID                ,
  CHO.PAR_AID                                                               As RES_VALUE_DS                     ,
  Null                                                                      As PAR_ACCES_SERVICE                ,
  Null                                                                      As TAC_CD                           ,
  Null                                                                      As IMEI_CD                          ,
  CHO.PAR_IMSI                                                              As IMSI_CD                          ,
  CHO.DMC_ACTIVATION_DT_INT                                                 As HOM_START_DT                     ,
  CHO.DMC_ACTIVATION_DT                                                     As MOB_START_DT                     ,
  CHO.PAR_SCORE_NU_INT                                                      As I_SCORE_VALUE                    ,
  CHO.PAR_TRESHOLD_NU_INT                                                   As I_SCORE_TRESHOLD                 ,
  Case
        When CHO.PAR_SCORE_IN_INT = 'O'
          Then 1
        Else 0
  End                                                                       As I_SCORE_IN                       ,
  CHO.PAR_SCORE_NU_MOB                                                      As M_SCORE_VALUE                    ,
  Case
        When CHO.PAR_TRESHOLD_NU_MOB > 100
          Then -1
        Else CHO.PAR_TRESHOLD_NU_MOB
  End                                                                       As M_SCORE_TRESHOLD                 ,
  CHO.PAR_SCORE_IN_MOB                                                      As M_SCORE_IN                       ,
  Cast(Case When CHO.OTO_OSCAR_VALUE_NU = 'SC' Then -1
            Else CHO.OTO_OSCAR_VALUE_NU
  End As BYTEINT)                                                           As OSCAR_VALUE                      ,
  '${P_PIL_376}'                                                            As CUST_BU_TYPE_CD                  ,
  CHO.PAR_USCM                                                              As CUST_BU_CD                       ,
  '${P_PIL_373}'                                                            As ADDRESS_TYPE                     ,
  Trim(
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_1 = 'null' Then Null Else PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_2 = 'null' Then Null Else PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_3 = 'null' THEN Null Else PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(CHO.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(Case When CHO.PAR_BILL_ADRESS_4 = 'null' Then Null Else PAR_BILL_ADRESS_4 End,'')) || ' ' ||
    Trim(Coalesce(CHO.PAR_BILL_VILLE,'')) 
  )                                                                         As ADDRESS_CONCAT_NM                ,
  Coalesce(CHO.PAR_POSTAL_CD,CHO.PAR_BILL_CD_POSTAL )                       As POSTAL_CD                        ,
  CHO.PAR_INSEE_CD                                                          As INSEE_CD                         ,
  CHO.PAR_BU_CD                                                             As BU_CD                            ,
  Coalesce(CHO.PAR_DEPRTMNT_ID ,CHO.PAR_DO )                                As DEPARTMNT_ID                     ,
  CHO.PAR_IRIS2000_CD                                                       as PAR_IRIS2000_CD                  ,
  Case When CHO.ACT_UNITE_CD ='${P_PIL_620}' --Unité = NB
         Then Null
       Else Coalesce(CHO.ACT_DELTA_TARIF,0)
  End                                                                       as ACT_CA_LINE_AM                   ,
  CHO.PAR_MOB_SIM                                                           As SIM_CD                           ,
  Null                                                                      As SIM_EAN_CD                       ,
  CHO.ORG_RESP_AGENT_ID                                                     As ORG_RESP_ID                      ,
  CHO.CHECK_INITIAL_STATUS_CD                                               As CHECK_INITIAL_STATUS_CD          ,
  CHO.CHECK_NAT_STATUS_CD                                                   As CHECK_NAT_STATUS_CD              ,
  CHO.CHECK_NAT_COMMENT                                                     As CHECK_NAT_COMMENT                ,
  CHO.CHECK_NAT_STATUS_LN                                                   As CHECK_NAT_STATUS_LN              ,
  CHO.CHECK_LOC_STATUS_CD                                                   As CHECK_LOC_STATUS_CD              ,
  CHO.CHECK_LOC_COMMENT                                                     As CHECK_LOC_COMMENT                ,
  CHO.CHECK_LOC_STATUS_LN                                                   As CHECK_LOC_STATUS_LN              ,
  CHO.CHECK_VALIDT_DT                                                       As CHECK_VALIDT_DT                  ,
  Null                                                                      As ACT_END_UNIFIED_DT               ,
  Null                                                                      As ACT_END_UNIFIED_DS               ,
  CHO.CLOSURE_DT                                                            As ACT_CLOSURE_DT                   ,
  Case When CHO.CLOSURE_DT Is Not Null
        Then 'Acte Clos'
  End                                                                       As ACT_CLOSURE_DS                   ,
  0                                                                         As HOT_IN                           ,
  Null                                                                      As RUN_ID                           ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                 As CREATION_TS                      ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                 As LAST_MODIF_TS                    ,
  1                                                                         As FRESH_IN                         ,
  0                                                                         As COHERENCE_IN                     
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_CHO As CHO  
  Left Outer Join ${KNB_IBU_GLB_V}.VPOCCSLMAT As VPOCCSLMAT
    On  CHO.ORG_POC_XI = VPOCCSLMAT.XI
  Inner Join ${KNB_TERADATA_USER}.ORD_V_ACTE_CHO CHO2
  On CHO2.ACTE_ID=CHO.ACTE_ID
Where
(1=1)
  And Substr(CHO.ACT_CD,1,3)        Not In (${L_PIL_036})
  And CHO.ACT_SEG_COM_ID_FINAL      <> '${P_PIL_295}'
  And CHO.ACT_CD                    <> '${P_PIL_067}'
  And CHO.ACT_PERIODE_ID            > 12
  And CHO.HOT_IN                    = 0
  And CHO.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_CHO;
.if errorcode <> 0 then .quit 1;

.quit 0

