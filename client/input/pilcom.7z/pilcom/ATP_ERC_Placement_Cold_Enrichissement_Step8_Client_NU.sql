-- $HEADER:   %HEADER%
-------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERC_Placement_Cold_Enrichissement_Step8_Client_NU.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/02/2016      HLA         Creation
-- 13/07/2016      HLA         Modification:Syntax error
--------------------------------------------------------------------------------
.set width 2500;




Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_CLIENT all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_CLIENT

(
  ACTE_ID                       ,
  ORD_DEPOSIT_DT                ,
  CLIENT_NU                     ,
  CLIENT_NU_NEW_PORTE           ,
  DOSSIER_NU                    ,
  DOSSIER_NU_NEW_PORTE          ,
  DOSSIER_DATE_ACTIV            ,
  DOSSIER_DATE_RESIL            ,
  DOSSIER_TYPE_RESIL            ,
  DOSSIER_MOTIF_RESIL           ,
  DOSSIER_NU_IMSI                
)
Select
  RefId.ACTE_ID                             as  ACTE_ID                       ,
  RefId.ORDER_DEPOSIT_DT                    as  ORD_DEPOSIT_DT                ,
  Dossier.DOSSIER_CLIENT_NU                 as  CLIENT_NU                     ,
  NULL                                      as  CLIENT_NU_NEW_PORTE           ,
  RefId.MSISDN                              as  DOSSIER_NU                    ,
  NULL                                      as  DOSSIER_NU_NEW_PORTE          ,
  NULL                                      as  DOSSIER_DATE_ACTIV            ,
  Dossier.DOSSIER_DT_RESIL                  as  DOSSIER_DATE_RESIL            ,
  NULL                                      as  DOSSIER_TYPE_RESIL            ,
  Dossier.DOSSIER_CO_MOTRESIL               as  DOSSIER_MOTIF_RESIL           ,
  Dossier.DOSSIER_NU_IMSI                   as  DOSSIER_NU_IMSI                
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC RefId
  Inner join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
    On      RefId.MSISDN = Dossier.DOSSIER_NU
        and Dossier.DOSSIER_DT_CREAT <= RefId.ORDER_DEPOSIT_DT
        and RefId.ORDER_DEPOSIT_DT < Coalesce(Dossier.DOSSIER_DT_RESIL,cast('2999-12-31 00:00:00'as timestamp(0)))
Where 
  (1=1)
  qualify row_number() over (Partition by ACTE_ID order by Dossier.DOSSIER_DT_CREAT desc, Dossier.CLOSURE_DT asc ,Dossier.DOSSIER_NU_IMSI asc) = 1
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC_CLIENT;
.if errorcode <> 0 then .quit 1
