--$HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_OSE_Placement_Consolidation_Enrichissement_Channel.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 17/09/2018       JCR         Creation
-- 07/12/2018       JCR         Ajustement matrice
-- 16/10/2010       JCR         Ajustement matrice (SERVICE CLIENT)
-- 08/02/2020       BCH         PILCOM 916 : Optimisation O3
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_CHANNEL all;
.if errorcode <> 0 then .quit 1

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_ENRI_ACT all;
.if errorcode <> 0 then .quit 1

-- Enrichissement QW CHORUS RFORCE
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_ENRI_ACT
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  AGENT_ID                      ,
  START_ACTIVITY_TS             ,
  END_ACTIVITY_TS               ,
  ACTIVITY                      ,
  PRIO
)
Select
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  AGENT_ID             ,
  START_ACTIVITY_TS    ,
  END_ACTIVITY_TS      ,
  ACTIVITY             ,
  PRIO
From
(
  Select
    Placement.ACTE_ID                       As ACTE_ID              ,
    Placement.ORDER_DEPOSIT_DT              As ORDER_DEPOSIT_DT     ,
    ACTIVITY.CUID                           As AGENT_ID             ,
    ACTIVITY.START_ACTIVITY_TS              As START_ACTIVITY_TS    ,
    ACTIVITY.END_ACTIVITY_TS                As END_ACTIVITY_TS      ,
    ACTIVITY.ACTIVITY                       As ACTIVITY             ,
    Case  When ACTIVITY.SOURCE = 'RFOR'
            Then 1
          When ACTIVITY.SOURCE = 'CHO'
            Then 2
          Else 3
    End                                     As PRIO
  From
    ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 As Placement
    Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_ACTIVITY As ACTIVITY
      On    Placement.ORG_AGENT_ID    =   ACTIVITY.CUID
        And Placement.ORDER_DEPOSIT_TS      >=  ACTIVITY.START_ACTIVITY_TS
        And Placement.ORDER_DEPOSIT_TS      <=  ACTIVITY.END_ACTIVITY_TS
  Where
    (1=1)
  Qualify Row_number() over
              (Partition by
                  Placement.ACTE_ID                 ,
                  Placement.ORDER_DEPOSIT_DT
               Order By
                  PRIO ASC                          ,
                  ACTIVITY.START_ACTIVITY_TS Desc   ,
                  ACTIVITY.END_ACTIVITY_TS Desc
              ) = 1
 ) RefAct
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_ENRI_ACT;
.if errorcode <> 0 then .quit 1


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_PRIO_AXE all;
.if errorcode <> 0 then .quit 1
-- Récupération des axes de classification
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_PRIO_AXE
(
ACTE_ID,
VAL_AXS_CLSSF_ID,
PRIO
)
Select 
    RefId.ACTE_ID,
    EdoAx.VAL_AXS_CLSSF_ID,
    Case  When EdoAx.VAL_AXS_CLSSF_ID In ('OPEN', 'SOSH')
            Then 1
          When EdoAx.VAL_AXS_CLSSF_ID In ('1014', 'GSCR')
            Then 2
          Else 3
    End                                     As PRIO
From
${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 RefId
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoAx
  -- la valeur 2 n'a pas de correspondance dans ORG_H_AXS_EDO
    On    RefId.EXTRNL_EDO_ID   = EdoAx.EDO_ID
    And   RefId.ORDER_DEPOSIT_DT      between EdoAx.START_VAL_AXS_DT
        And Coalesce(EdoAx.END_VAL_AXS_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
   And EdoAx.CURRENT_IN = 1
   And   EdoAx.CLOSURE_DT is null
   Where RefId.ORG_CHANNEL_CD_CMD = 'SERVICE CLIENT'
Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT Order By PRIO Asc) = 1;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_PRIO_AXE;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_CHANNEL
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD_CMD         ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_REM_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_GT_ACTIVITY            ,
  ORG_FIDELISATION           ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_AD_SC
)

Select
  RefId.ACTE_ID                                                      As ACTE_ID                                 ,
  RefId.ORDER_DEPOSIT_DT                                             As ORDER_DEPOSIT_DT                        ,
  RefId.ORG_CHANNEL_CD_CMD                                           As ORG_CHANNEL_CD_CMD                      ,
  -- Canal
  Case  When RefId.EXTRNL_SHOP_ID in ('PDV-MYSHOP','PDV-BOI')
          Then 'Online'
        When ORG_CHANNEL_CD_CMD ='BOUTIQUE'
          Then 'Dist'
        When ORG_CHANNEL_CD_CMD ='SERVICE CLIENT' And EdoAx.VAL_AXS_CLSSF_ID In ('OPEN', 'SOSH')
          Then 'CCO'
        When ORG_CHANNEL_CD_CMD ='SERVICE CLIENT' And EdoAx.VAL_AXS_CLSSF_ID In ('1014', 'GSCR')
          Then 'SCH'
        When ORG_CHANNEL_CD_CMD ='SERVICE CLIENT' And EdoAx.VAL_AXS_CLSSF_ID is not null
          Then 'CCO'
        Else 'NON PARAM'
  End                                                                As ORG_CHANNEL_CD_AGR                  ,
      --Sous Canal
  Case  When ORG_CHANNEL_CD_AGR ='Online'
          Then 'Web'
        When ORG_CHANNEL_CD_AGR ='Dist' And Coalesce (RefEDO.NETWRK_TYP_EDO_ID, RefADV.NETWRK_TYP_EDO_ID, '#') ='RP'
          Then 'RP'
        When ORG_CHANNEL_CD_AGR ='Dist'And Coalesce (RefEDO.NETWRK_TYP_EDO_ID, RefADV.NETWRK_TYP_EDO_ID, '#') ='FT'
          Then 'AD'
        When ORG_CHANNEL_CD_AGR ='CCO' And EdoAx.VAL_AXS_CLSSF_ID In ('OPEN', 'SOSH')
          Then 'Convergent'
        When ORG_CHANNEL_CD_AGR ='SCH' And EdoAx.VAL_AXS_CLSSF_ID is not null
          Then 'Home'
        When ORG_CHANNEL_CD_AGR ='CCO' And EdoAx.VAL_AXS_CLSSF_ID is not null
          Then 'Mobile'
        Else 'NON PARAM'
  End                                                                As ORG_SUB_CHANNEL_CD_AGR                  ,
    --Canal de Rem
  Case When ORG_SUB_CHANNEL_CD_AGR = 'RP'
         Then 'Exclus'
       When ORG_SUB_CHANNEL_CD_AGR = 'AD'
         Then 'AD'
       When ORG_CHANNEL_CD_AGR In ('CCO', 'SCH') And EdoAx.VAL_AXS_CLSSF_ID is not null
         Then ORG_CHANNEL_CD_AGR
       When RefId.EXTRNL_SHOP_ID in ('PDV-MYSHOP','PDV-BOI')
          Then 'Online'
       Else 'NON PARAM'
  End                                                                As ORG_REM_CHANNEL_CD                       ,
  --Sous Sous Canal
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then
            Case When Coalesce(RefEDO.FLAG_TYPE_GEO, RefADV.FLAG_TYPE_GEO, '#') in ('REUNION','CARAIBES')
                 Then 'Dom'
                 Else 'Metropole'
            End
        When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then
            Case When Coalesce(RefEDO.FLAG_TYPE_GEO, RefADV.FLAG_TYPE_GEO, '#') in ('REUNION','CARAIBES')
                 Then 'Dom'
                 Else 'Metropole'
            End
      /* implementer la partie QW sur l'axe canal */
        When ORG_CHANNEL_CD_CMD ='SERVICE CLIENT' And EdoAx.VAL_AXS_CLSSF_ID is not null
          Then
             Case when ActAgentSC.ACTIVITY like ('%CTC%')
                  Then 'CTC'
                  when ActAgentSC.ACTIVITY like ('%Front Pr%')
                  Then 'Front Prevenance'
                  Else 'Front'
             End
        Else 'NON PARAM'
  End                                                                As ORG_SUB_SUB_CHANNEL_CD                  ,
  -- GT/Activite
    Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'Boutique FT'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'GDT'
        When RefId.EXTRNL_SHOP_ID = 'PDV-MYSHOP'
          Then 'PDV-MYSHOP'
        When RefId.EXTRNL_SHOP_ID = 'PDV-BOI'
          Then 'PDV-BOI'
      /* implementer la partie QW sur l'axe canal */
        When ORG_CHANNEL_CD_AGR = 'SCH' And EdoAx.VAL_AXS_CLSSF_ID is not null
          Then ActAgentSC.ACTIVITY
        When ORG_CHANNEL_CD_AGR = 'CCO' and ORG_SUB_CHANNEL_CD_AGR = 'Convergent' And EdoAx.VAL_AXS_CLSSF_ID is not null
          Then
              Case When ActAgentSC.ACTIVITY  like ('Front Pr%')
                     Then ActAgentSC.ACTIVITY
                   Else 'Front Open'
              End
        When ORG_CHANNEL_CD_AGR = 'CCO' and ORG_SUB_CHANNEL_CD_AGR = 'Mobile' And EdoAx.VAL_AXS_CLSSF_ID is not null
         Then
              Case When ActAgentSC.ACTIVITY like ('Front Pr%')
                     Then ActAgentSC.ACTIVITY
                   Else 'Front Mobile'
              End
        Else 'NON PARAM'
  End                                                                As ORG_GT_ACTIVITY                          ,
  Null                                                               As ORG_FIDELISATION                         ,
  Case  When ORG_CHANNEL_CD_AGR = 'Online'
          Then 'OUI'
        When ORG_SUB_SUB_CHANNEL_CD = 'CTC'
          Then 'OUI'
        Else 'NON'
  End                                                                As ORG_WEB_ACTIVITY                         ,
  Case  When ORG_CHANNEL_CD_AGR = 'Online'
          Then 'OUI'
        Else 'NON'
  End                                                                As ORG_AUTO_ACTIVITY                        ,
  Case  When RefId.EXTRNL_SHOP_ID = 'PDV-MYSHOP'
           Then 112960
        When RefId.EXTRNL_SHOP_ID = 'PDV-BOI'
           Then 107008
        Else Coalesce (RefEDO.EDO_ID, RefADV.EDO_ID) 
  End                                                                As EDO_ID                                   ,
  Coalesce (RefEDO.TYPE_EDO, RefADV.TYPE_EDO)                        As TYPE_EDO_ID                              ,
  Coalesce (RefEDO.NETWRK_TYP_EDO_ID, RefEDO.NETWRK_TYP_EDO_ID)      As NETWRK_TYP_EDO_ID                        ,
  Case When  ORG_SUB_CHANNEL_CD_AGR ='AD'
         Then 1
       When ORG_CHANNEL_CD_AGR In ('CCO', 'SCH') And EdoAx.VAL_AXS_CLSSF_ID is not null
         Then 0
       Else Null
  End                                                                As FLAG_AD_SC

From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 RefId
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    RefId.EXTRNL_EDO_ID    = RefEDO.EDO_ID
    And   RefId.ORDER_DEPOSIT_DT  Between RefEDO.START_EXTNL_VAL_DT 
          And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefADV
    On    RefId.EXTRNL_SHOP_ID    = RefADV.EXTNL_VAL_COD_CD
    And   RefId.ORDER_DEPOSIT_DT  Between RefADV.START_EXTNL_VAL_DT 
          And Coalesce(RefADV.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_ENRI_ACT  ActAgentSC
    On    RefId.ACTE_ID          =   ActAgentSC.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_PRIO_AXE EdoAx
    On    RefId.ACTE_ID = EdoAx.ACTE_ID
Where
  (1=1)
  
Qualify Row_number() over (Partition by RefId.ACTE_ID,RefId.ORDER_DEPOSIT_DT 
                           Order By RefEDO.EDO_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_CHANNEL;
.if errorcode <> 0 then .quit 1




