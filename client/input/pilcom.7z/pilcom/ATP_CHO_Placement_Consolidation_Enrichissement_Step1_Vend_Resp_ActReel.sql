-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_CHO_Placement_Consolidation_Enrichissement_Step1_Vend_Resp_ActReel.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_RESPACTIV all;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------------
--On passe par une table Volatile pour selectionner les Id à enrichir
--Et qui existe dans l'orga Activitée
-------------------------------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.INT_V_PLACEMENT_CHO_RESPACTIV(
  ACTE_ID                 Bigint                  Not Null  ,
  INT_DEPOSIT_DT          Date Format 'YYYYMMDD'  Not Null  ,
  ORG_RESP_AGENT_ID       Varchar(20)                       ,
  ORG_RESP_ACTVT_REEL     Varchar(15)                       ,
  START_ACTIVITY_DT       Date Format 'YYYYMMDD'  Not Null  
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_CHO_RESPACTIV
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_RESP_AGENT_ID         ,
  ORG_RESP_ACTVT_REEL       ,
  START_ACTIVITY_DT         
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  --Code Aliance du vendeur :
  RefId.LOGIN_RESP                  as ORG_RESP_AGENT_ID    ,
  --Code Activitee du vendeur au moment de la vente:
  Orga.ACTIVITY_ID                  as ORG_RESP_ACTVT_REEL  ,
  Orga.START_ACTIVITY_DT            as START_ACTIVITY_DT    
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_RESPACTIV1 RefId
  Inner Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PREACTIV Orga
    On    RefId.LOGIN_RESP          =   Orga.AGENT_ID
      And RefId.INT_MODIF_DT        =   Orga.START_ACTIVITY_DT
      And RefId.INT_MODIF_TS        >=  Orga.START_ACTIVITY_TS
      And RefId.INT_MODIF_TS        <   Orga.END_ACTIVITY_TS
Where
  (1=1)
  --On alimente ceux qui on la meme date
  And Orga.FLAG_DATE = 1
;Insert into ${KNB_TERADATA_USER}.INT_V_PLACEMENT_CHO_RESPACTIV
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_RESP_AGENT_ID         ,
  ORG_RESP_ACTVT_REEL       ,
  START_ACTIVITY_DT         
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  --Code Aliance du vendeur :
  RefId.LOGIN_RESP                  as ORG_RESP_AGENT_ID    ,
  --Code Activitee du vendeur au moment de la vente:
  Orga.ACTIVITY_ID                  as ORG_RESP_ACTVT_REEL  ,
  Orga.START_ACTIVITY_DT            as START_ACTIVITY_DT    
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_RESPACTIV1 RefId
  Inner Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PREACTIV Orga
    On    RefId.LOGIN_RESP          =   Orga.AGENT_ID
      And RefId.INT_MODIF_TS        >=  Orga.START_ACTIVITY_TS
      And RefId.INT_MODIF_TS        <   Orga.END_ACTIVITY_TS
Where
  (1=1)
  --On alimente ceux qui on la meme date
  And Orga.FLAG_DATE = 2
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.INT_V_PLACEMENT_CHO_RESPACTIV column(ACTE_ID);
.if errorcode <> 0 then .quit 1



Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_RESPACTIV
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_RESP_AGENT_ID              ,
  ORG_RESP_ACTVT_REEL            
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  --Code Aliance du vendeur :
  RefId.ORG_RESP_AGENT_ID           as ORG_RESP_AGENT_ID    ,
  --Code Activitee du vendeur au moment de la vente:
  RefId.ORG_RESP_ACTVT_REEL         as ORG_RESP_ACTVT_REEL  
From
  ${KNB_TERADATA_USER}.INT_V_PLACEMENT_CHO_RESPACTIV RefId
Qualify Row_Number() Over(Partition by RefId.ACTE_ID Order by RefId.START_ACTIVITY_DT asc)=1
;
.if errorcode <> 0 then .quit 1



--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_RESPACTIV;
.if errorcode <> 0 then .quit 1


.quit 0
