-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_PCO_Referentiel_Alimentation_O3_MD2_Hot_Step1.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de calcul du référentiel pour déterminer l'EDO
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 27/08/2014      HFO         Creation
-- 03/03/2016      TPI         QC 1072 : Modification paramètres
--------------------------------------------------------------------------------


.set width 2500;


--Step 1 Orga Fonctionnelle

Delete from ${KNB_PCO_TMP}.ORG_W_Ref_O3_POCSC all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORG_W_Ref_O3_POCSC
(
  EDO_ID                ,
  START_EXTNL_VAL_DT    ,
  CODE_GRP_ID           ,
  TYPE_EDO              ,
  FLAG_PLT_CONV         ,
  FLAG_PLT_SCH          ,
  END_EXTNL_VAL_DT      ,
  OPEN_DT               ,
  CLOSE_DT               
)
Select
  RefPdv.EDO_ID                                                                         as EDO_ID               ,
  RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
  RefPdv.EXTNL_VAL_COD_CD                                                               as CODE_GRP_ID             ,
  --On détermine si c'est un plateau Interne ou Externe
  Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
          Then  '${P_PIL_235}'
        Else    '${P_PIL_236}'
  End                                                                                   as TYPE_EDO             ,
  --On vérifie si le plateau travail sur du convergent ou pas
  Case  When RefEdoConv.EDO_ID Is Not Null
          Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
        Else    0
  End                                                                                   as FLAG_PLT_CONV        ,
  Case  When RefEdoAVSC.EDO_ID Is Not Null
          Then  1
        Else    0
  End                                                                                   as FLAG_PLT_SCH         ,
  Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
  Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
  Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT
From
  ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO RefPdv
  Left Outer Join
  (
    --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
    Select
      EDO_ID
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
      And EdoAx.VAL_AXS_CLSSF_ID   in (${L_PIL_110})  -- 'SOSH','OPEN'
      And EdoAx.FRESH_IN          = 1
      And EdoAx.CURRENT_IN        = 1
      And EdoAx.CLOSURE_DT        Is Null
    Group By
      EDO_ID
  ) RefEdoConv
  On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
  Left Outer Join
  (
    --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
    Select
      EDO_ID
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
    Where
      (1=1)
      And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113})  -- 'GSCR','1014'
      And EdoAx.FRESH_IN          = 1
      And EdoAx.CURRENT_IN        = 1
      And EdoAx.CLOSURE_DT        Is Null
    Group By
      EDO_ID
  ) RefEdoAVSC
  On  RefPdv.EDO_ID             = RefEdoAVSC.EDO_ID
    --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
  Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
    On    RefPdv.EDO_ID         = RefEdo.EDO_ID
      And RefEdo.CURRENT_IN     = 1
      And RefEdo.CLOSURE_DT     Is Null
Where
  (1=1)
  And RefPdv.EXTNL_COD_CD = 'REGARDSC'
  And RefPdv.CURRENT_IN   = 1
  And RefPdv.CLOSURE_DT   Is Null ;
  
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORG_W_Ref_O3_POCSC;
.if errorcode <> 0 then .quit 1

.quit 0
