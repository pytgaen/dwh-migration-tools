-- $HEADER:   mm2pco/current/sql/ATP_EDL_Placement_Consolidation_FusionEnrichi_Step1.sql 13_05#11 26-JUN-2019 11:39:47 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_FusionEnrichi_Step1.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Fusion Enrichissement placement EDL
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
-- 01/07/2015      AOU         Ajout de l'axe Géo ( multicanal)
---24/11/2016      HOB         Creation
-- 30/11/2017      MEL         IOBSP
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_T_PLACEMENT_EDL all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_T_PLACEMENT_EDL
(
  ACTE_ID                     ,
  DEMANDE_ID                  ,
  EXTERNAL_INT_ID             ,
  INT_DEPOSIT_TS              ,
  INT_DEPOSIT_DT              ,
  OPERATOR_PROVIDER_ID        ,
  RESOLU_ID                   ,
  CONCLU_ID                   ,
  SSCONCLU_ID                 ,
  TYPE_COMMANDE               ,
  PLTF_CO                     ,
  INTRNL_SOURCE_ID            ,
  CONSEIL_XI_CREA             ,
  CONSEIL_XI_RESP             ,
  INT_MODIF_TS                ,
  IN_CLIDOS                   ,
  TYPE_OT_SO                  ,
  CANALDEM                    ,
  INT_REASON_CD               ,
  CLIENT_NU                   ,
  DOSSIER_NU                  ,
  DMC_LINE_ID                 ,
  DMC_MASTER_LINE_ID          ,
  PAR_DEPRTMNT_ID             ,
  PAR_POSTAL_CD               ,
  PAR_INSEE_NB                ,
  PAR_BU_CD                   ,
  PAR_GEO_MACROZONE           ,
  PAR_UNIFIED_PARTY_ID        ,
  PAR_PARTY_REGRPMNT_ID       ,
  PAR_CID_ID                  ,
  PAR_PID_ID                  ,
  PAR_FIRST_IN                ,
  ORG_AGENT_IOBSP             ,
  ORG_EDO_IOBSP               ,
  PAR_IRIS2000_CD             ,
  PAR_FIBER_IN                ,
  DMC_LINE_TYPE               ,
  DMC_ACTIVATION_DT           ,
  DMC_CONVERGENT_IN           ,
  DMC_LINE_ID_INT             ,
  DMC_LINE_TYPE_INT           ,
  DMC_ACTIVATION_DT_INT       ,
  DMC_SERVICE_ACCESS_ID       ,
  OFFRE_INT_PRE               ,
  PRESFACT_CO_PRECED          ,
  PRESFACT_CO_OFFRE_OPT_ACQ   ,
  INB_PRESFACT_ACQ_ADV        ,
  INB_PRESFACT_ACQ_AGAP       ,
  PARC_DT_DEBUT               ,
  PARC_DT_FIN                 ,
  ORDAGD_DT_CONF              ,
  CONTRCT_DT_SIGN_PREC        ,
  CONTRCT_DT_FIN_PREC         ,
  CONTRCT_DT_SIGN_POST        ,
  CONTRCT_DUREE_ENG           ,
  CONTRCT_UNIT_ENG            ,
  EDO_ID                      ,
  FLAG_PLT_CONV               ,
  FLAG_PLT_SCH                ,
  FLAG_TEAM_MKT               ,
  FLAG_TYPE_CMP               ,
  TYPE_EDO                    ,
  EDO_ID_HIER                 ,
  TYPE_EDO_HIER               ,
  ORG_REF_TRAV                ,
  ORG_AGENT_ID                ,
  ORG_POC_XI                  ,
  ORG_NOM                     ,
  ORG_PRENOM                  ,
  ORG_GROUPE_ID               ,
  ORG_GROUPE_ID_HIER          ,
  ORG_ACTVT_REEL              ,
  ORG_RESP_REF_TRAV           ,
  ORG_RESP_AGENT_ID           ,
  ORG_RESP_XI                 ,
  PAR_LASTNAME                ,
  PAR_FIRSTNAME               ,
  PAR_TYPE                    ,
  PAR_IMSI                    ,
  PAR_EMAIL                   ,
  PAR_BILL_ADRESS_1           ,
  PAR_BILL_ADRESS_2           ,
  PAR_BILL_ADRESS_3           ,
  PAR_BILL_ADRESS_4           ,
  PAR_BILL_VILLE              ,
  PAR_BILL_CD_POSTAL          ,
  PAR_INSEE_CD                ,
  PAR_DO                      ,
  PAR_USCM                    ,
  PAR_USCM_DS                 ,
  PAR_USCM_USCM_DS            ,
  PAR_USCM_REGUSCM            ,
  PAR_USCM_REGUSCM_DS         ,
  PAR_AID                     ,
  PAR_ND                      ,
  PAR_MOB_IMEI                ,
  PAR_MOB_TAC                 ,
  PAR_MOB_SIM                 ,
  PAR_SCORE_NU                ,
  PAR_SCORE_IN                ,
  PAR_TRESHOLD_NU             ,
  PAR_SCORE_NU_INT            ,
  PAR_SCORE_IN_INT            ,
  PAR_TRESHOLD_NU_INT         ,
  CLOSURE_DT                  ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN                
)
Select
  Commande.ACTE_ID                                                                      as ACTE_ID                    ,
  Commande.DEMANDE_ID                                                                   as DEMANDE_ID                 ,
  Commande.EXTERNAL_INT_ID                                                              as EXTERNAL_INT_ID            ,
  Commande.INT_DEPOSIT_TS                                                               as INT_DEPOSIT_TS             ,
  Commande.INT_DEPOSIT_DT                                                               as INT_DEPOSIT_DT             ,
  Commande.OPERATOR_PROVIDER_ID                                                         as OPERATOR_PROVIDER_ID       ,
  Commande.RESOLU_ID                                                                    as RESOLU_ID                  ,
  Commande.CONCLU_ID                                                                    as CONCLU_ID                  ,
  Commande.SSCONCLU_ID                                                                  as SSCONCLU_ID                ,
  Commande.TYPE_COMMANDE                                                                as TYPE_COMMANDE              ,
  Commande.PLTF_CO                                                                      as PLTF_CO                    ,
  Commande.INTRNL_SOURCE_ID                                                             as INTRNL_SOURCE_ID           ,
  Commande.CONSEIL_XI_CREA                                                              as CONSEIL_XI_CREA            ,
  Commande.CONSEIL_XI_RESP                                                              as CONSEIL_XI_RESP            ,
  Commande.INT_MODIF_TS                                                                 as INT_MODIF_TS               ,
  Commande.IN_CLIDOS                                                                    as IN_CLIDOS                  ,
  Null                                                                                  as TYPE_OT_SO                 ,
  Commande.CANALDEM                                                                     as CANALDEM                   ,
  Commande.INT_REASON_CD                                                                as INT_REASON_CD              ,
  Commande.CLIENT_NU                                                                    as CLIENT_NU                  ,
  Commande.DOSSIER_NU                                                                   as DOSSIER_NU                 ,
  Coalesce(LigneDMC.DMC_LINE_ID, Commande.DMC_LINE_ID)                                  as DMC_LINE_ID                ,
  Coalesce(LigneDMC.DMC_MASTER_LINE_ID, Commande.DMC_MASTER_LINE_ID)                    as DMC_MASTER_LINE_ID         ,
  LigneDMC.PAR_DEPRTMNT_ID                                                              as PAR_DEPRTMNT_ID            ,
  LigneDMC.PAR_POSTAL_CD                                                                as PAR_POSTAL_CD              ,
  LigneDMC.PAR_INSEE_NB                                                                 as PAR_INSEE_NB               ,
  LigneDMC.PAR_BU_CD                                                                    as PAR_BU_CD                  ,
  Coalesce(EDL_IRIS.PAR_GEO_MACROZONE,Commande.PAR_GEO_MACROZONE)                       as PAR_GEO_MACROZONE          ,
  Coalesce(LigneDMC.PAR_UNIFIED_PARTY_ID,Commande.PAR_UNIFIED_PARTY_ID)                 as PAR_UNIFIED_PARTY_ID       ,
  Coalesce(LigneDMC.PAR_PARTY_REGRPMNT_ID,Commande.PAR_PARTY_REGRPMNT_ID)               as PAR_PARTY_REGRPMNT_ID      ,
  Null                                                                                  as PAR_CID_ID                 ,
  Null                                                                                  as PAR_PID_ID                 ,
  Null                                                                                  as PAR_FIRST_IN               ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
  End                                                                                   as  ORG_AGENT_IOBSP                    ,
  Case When EdoOBK.EDO_ID is Not Null
         Then 'O'
          Else 'N'
  End                                                                                   as ORG_EDO_IOBSP              ,
  EDL_IRIS.PAR_IRIS2000_CD                                                              as PAR_IRIS2000_CD            ,
  EDL_FIBER.PAR_FIBER_IN                                                                as PAR_FIBER_IN               ,
  Coalesce(LigneDMC.DMC_LINE_TYPE,Commande.DMC_LINE_TYPE)                               as DMC_LINE_TYPE              ,
  Coalesce(LigneDMC.DMC_ACTIVATION_DT,Commande.DMC_ACTIVATION_DT)                       as DMC_ACTIVATION_DT          ,
  Coalesce(DmcConv.DMC_CONVERGENT_IN,Commande.DMC_CONVERGENT_IN)                        as DMC_CONVERGENT_IN          ,
  Coalesce(DmcInt.DMC_LINE_ID_INT,Commande.DMC_LINE_ID_INT)                             as DMC_LINE_ID_INT            ,
  Coalesce(DmcInt.DMC_LINE_TYPE_INT,Commande.DMC_LINE_TYPE_INT)                         as DMC_LINE_TYPE_INT          ,
  Coalesce(DmcInt.DMC_ACTIVATION_DT_INT,Commande.DMC_ACTIVATION_DT_INT)                 as DMC_ACTIVATION_DT_INT      ,
  Coalesce(DmcInt.DMC_SERVICE_ACCESS_ID,Commande.DMC_SERVICE_ACCESS_ID)                 as DMC_SERVICE_ACCESS_ID      ,
  Null                                                                                  as OFFRE_INT_PRE              ,
  Null                                                                                  as PRESFACT_CO_PRECED         ,
  Coalesce(Parc.PRESFACT_CO_OFFRE_OPT_ACQ,Commande.PRESFACT_CO_OFFRE_OPT_ACQ)           as PRESFACT_CO_OFFRE_OPT_ACQ  ,
  Coalesce(Parc.INB_PRESFACT_ACQ_ADV,Commande.INB_PRESFACT_ACQ_ADV)                     as INB_PRESFACT_ACQ_ADV       ,
  Coalesce(Parc.INB_PRESFACT_ACQ_AGAP,Commande.INB_PRESFACT_ACQ_AGAP)                   as INB_PRESFACT_ACQ_AGAP      ,
  Coalesce(Parc.PARC_DT_DEBUT,Commande.PARC_DT_DEBUT)                                   as PARC_DT_DEBUT              ,
  Coalesce(Parc.PARC_DT_FIN,Commande.PARC_DT_FIN)                                       as PARC_DT_FIN                ,
  Null                                                                                  as ORDAGD_DT_CONF             ,
  Coalesce(ContrOld.CONTRCT_DT_SIGN_PREC,Commande.CONTRCT_DT_SIGN_PREC)                 as CONTRCT_DT_SIGN_PREC       ,
  Coalesce(ContrOld.CONTRCT_DT_FIN_PREC,Commande.CONTRCT_DT_FIN_PREC)                   as CONTRCT_DT_FIN_PREC        ,
  Coalesce(ContrNew.CONTRCT_DT_SIGN_POST,Commande.CONTRCT_DT_SIGN_POST)                 as CONTRCT_DT_SIGN_POST       ,
  Coalesce(ContrNew.CONTRCT_DUREE_ENG,Commande.CONTRCT_DUREE_ENG)                       as CONTRCT_DUREE_ENG          ,
  Coalesce(ContrNew.CONTRCT_UNIT_ENG,Commande.CONTRCT_UNIT_ENG)                         as CONTRCT_UNIT_ENG           ,
  Coalesce(RefO3.EDO_ID,Commande.EDO_ID)                                                as EDO_ID                     ,
  Coalesce(RefO3.FLAG_PLT_CONV,Commande.FLAG_PLT_CONV)                                  as FLAG_PLT_CONV              ,
  Coalesce(RefO3.FLAG_PLT_SCH,Commande.FLAG_PLT_SCH)                                    as FLAG_PLT_SCH               ,
  Commande.FLAG_TEAM_MKT                                                                as FLAG_TEAM_MKT              ,
  Commande.FLAG_TYPE_CMP                                                                as FLAG_TYPE_CMP              ,
  Coalesce(RefO3.TYPE_EDO,Commande.TYPE_EDO)                                            as TYPE_EDO                   ,
  Coalesce(RefO3_Hier.EDO_ID_HIER,Commande.EDO_ID_HIER)                                 as EDO_ID_HIER                ,
  Coalesce(RefO3_Hier.TYPE_EDO_HIER,Commande.TYPE_EDO_HIER)                             as TYPE_EDO_HIER              ,
  Coalesce(VendeurVente.ORG_REF_TRAV,Commande.ORG_REF_TRAV)                             as ORG_REF_TRAV               ,
  Coalesce(VendeurVente.ORG_AGENT_ID,Commande.ORG_AGENT_ID)                             as ORG_AGENT_ID               ,
  Coalesce(VendeurVente.ORG_POC_XI,Commande.ORG_POC_XI)                                 as ORG_POC_XI                 ,
  Coalesce(VendeurVente.ORG_NOM,Commande.ORG_NOM)                                       as ORG_NOM                    ,
  Coalesce(VendeurVente.ORG_PRENOM,Commande.ORG_PRENOM)                                 as ORG_PRENOM                 ,
  Coalesce(VendeurVente.ORG_GROUPE_ID,Commande.ORG_GROUPE_ID)                           as ORG_GROUPE_ID              ,
  Coalesce(VendeurVente.ORG_GROUPE_ID_HIER,Commande.ORG_GROUPE_ID_HIER)                 as ORG_GROUPE_ID_HIER         ,
  Coalesce(VendeurActiv.ORG_ACTVT_REEL,Commande.ORG_ACTVT_REEL)                         as ORG_ACTVT_REEL             ,
  Coalesce(VendeurResp.ORG_RESP_REF_TRAV,Commande.ORG_RESP_REF_TRAV)                    as ORG_RESP_REF_TRAV          ,
  Coalesce(VendeurResp.ORG_RESP_AGENT_ID,Commande.ORG_RESP_AGENT_ID)                    as ORG_RESP_AGENT_ID          ,
  Coalesce(VendeurResp.ORG_RESP_XI,Commande.ORG_RESP_XI)                                as ORG_RESP_XI                ,
  Coalesce(ClPostPaid.PAR_LASTNAME,ClPrePaid.PAR_LASTNAME,Commande.PAR_LASTNAME)        as PAR_LASTNAME               ,
  Coalesce(ClPostPaid.PAR_FIRSTNAME,ClPrePaid.PAR_FIRSTNAME,Commande.PAR_FIRSTNAME)     as PAR_FIRSTNAME              ,
  Coalesce(ClPostPaid.PAR_TYPE,Commande.PAR_TYPE)                                       as PAR_TYPE                   ,
  Coalesce(RefImsi.PAR_IMSI,Commande.PAR_IMSI)                                          as PAR_IMSI                   ,
  Coalesce(ClBal.PAR_EMAIL,Commande.PAR_EMAIL)                                          as PAR_EMAIL                  ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_1,Commande.PAR_BILL_ADRESS_1)                          as PAR_BILL_ADRESS_1          ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_2,Commande.PAR_BILL_ADRESS_2)                          as PAR_BILL_ADRESS_2          ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_3,Commande.PAR_BILL_ADRESS_3)                          as PAR_BILL_ADRESS_3          ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_4,Commande.PAR_BILL_ADRESS_4)                          as PAR_BILL_ADRESS_4          ,
  Coalesce(ClAdr.PAR_BILL_VILLE,Commande.PAR_BILL_VILLE)                                as PAR_BILL_VILLE             ,
  Coalesce(ClAdr.PAR_BILL_CD_POSTAL,Commande.PAR_BILL_CD_POSTAL)                        as PAR_BILL_CD_POSTAL         ,
  Coalesce(ClAdr.PAR_INSEE_CD,Commande.PAR_INSEE_CD)                                    as PAR_INSEE_CD               ,
  Coalesce(ClAdr.PAR_DO,Commande.PAR_DO)                                                as PAR_DO                     ,
  Coalesce(ClUscm.PAR_USCM,Commande.PAR_USCM)                                           as PAR_USCM                   ,
  Coalesce(ClUscm.PAR_USCM_DS,Commande.PAR_USCM_DS)                                     as PAR_USCM_DS                ,
  Coalesce(ClUscm.PAR_USCM_USCM_DS,Commande.PAR_USCM_USCM_DS)                           as PAR_USCM_USCM_DS           ,
  Coalesce(ClUscm.PAR_USCM_REGUSCM,Commande.PAR_USCM_REGUSCM)                           as PAR_USCM_REGUSCM           ,
  Coalesce(ClUscm.PAR_USCM_REGUSCM_DS,Commande.PAR_USCM_REGUSCM_DS)                     as PAR_USCM_REGUSCM_DS        ,
  Coalesce(AtInt.PAR_AID,Commande.PAR_AID)                                              as PAR_AID                    ,
  Coalesce(AtInt.PAR_ND,Commande.PAR_ND)                                                as PAR_ND                     ,
  Coalesce(ClImei.PAR_MOB_IMEI,Commande.PAR_MOB_IMEI)                                   as PAR_MOB_IMEI               ,
  Coalesce(ClImei.PAR_MOB_TAC,Commande.PAR_MOB_TAC)                                     as PAR_MOB_TAC                ,
  Coalesce(ClSim.PAR_MOB_SIM,Commande.PAR_MOB_SIM)                                      as PAR_MOB_SIM                ,
  Coalesce(ClScore.PAR_SCORE_NU,Commande.PAR_SCORE_NU)                                  as PAR_SCORE_NU               ,
  Coalesce(ClScore.PAR_SCORE_IN,Commande.PAR_SCORE_IN)                                  as PAR_SCORE_IN               ,
  Coalesce(ClScore.PAR_TRESHOLD_NU,Commande.PAR_TRESHOLD_NU)                            as PAR_TRESHOLD_NU            ,
  Coalesce(DmcSC.PAR_SCORE_NU_INT,Commande.PAR_SCORE_NU_INT)                            as PAR_SCORE_NU_INT           ,
  Coalesce(DmcSC.PAR_SCORE_IN_INT,Commande.PAR_SCORE_IN_INT)                            as PAR_SCORE_IN_INT           ,
  Coalesce(DmcSC.PAR_TRESHOLD_NU_INT,Commande.PAR_TRESHOLD_NU_INT)                      as PAR_TRESHOLD_NU_INT        ,
  Commande.CLOSURE_DT                                                                   as CLOSURE_DT                 ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS              ,
  1                                                                                     as FRESH_IN                   ,
  0                                                                                     as COHERENCE_IN               
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1 Commande
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDEUR VendeurVente
    On    Commande.ACTE_ID        = VendeurVente.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VendeurVente.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDACTIV VendeurActiv
    On    Commande.ACTE_ID        = VendeurActiv.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VendeurActiv.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP VendeurResp
    On    Commande.ACTE_ID        = VendeurResp.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VendeurResp.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_AT_INT AtInt
    On    Commande.ACTE_ID        = AtInt.ACTE_ID
      And Commande.INT_DEPOSIT_DT = AtInt.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CLPREPAID ClPrePaid
    On    Commande.ACTE_ID        = ClPrePaid.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClPrePaid.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CLPOSTPAID ClPostPaid
    On    Commande.ACTE_ID        = ClPostPaid.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClPostPaid.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_BAL ClBal
    On    Commande.ACTE_ID        = ClBal.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClBal.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_ADR ClAdr
    On    Commande.ACTE_ID        = ClAdr.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClAdr.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_SCORE ClScore
    On    Commande.ACTE_ID        = ClScore.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClScore.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_IMEI ClImei
    On    Commande.ACTE_ID        = ClImei.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClImei.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_SIM ClSim
    On    Commande.ACTE_ID        = ClSim.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClSim.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CL_USCM ClUscm
    On    Commande.ACTE_ID        = ClUscm.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClUscm.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CONTRATOLD ContrOld
    On    Commande.ACTE_ID        = ContrOld.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ContrOld.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CONTRATNEW ContrNew
    On    Commande.ACTE_ID        = ContrNew.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ContrNew.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_PARC Parc
    On    Commande.ACTE_ID        = Parc.ACTE_ID
      And Commande.INT_DEPOSIT_DT = Parc.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IDLINEDMC LigneDMC
    On    Commande.ACTE_ID        = LigneDMC.ACTE_ID
      And Commande.INT_DEPOSIT_DT = LigneDMC.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_CV   DmcConv
    On    Commande.ACTE_ID        = DmcConv.ACTE_ID
      And Commande.INT_DEPOSIT_DT = DmcConv.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT   DmcInt
    On    Commande.ACTE_ID        = DmcInt.ACTE_ID
      And Commande.INT_DEPOSIT_DT = DmcInt.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_DMC_INT_SC   DmcSC
    On    Commande.ACTE_ID        = DmcSC.ACTE_ID
      And Commande.INT_DEPOSIT_DT = DmcSC.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDEUR_O3  RefO3
    On    Commande.ACTE_ID        = RefO3.ACTE_ID
      And Commande.INT_DEPOSIT_DT = RefO3.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VEND_O3_H  RefO3_Hier
    On    Commande.ACTE_ID        = RefO3_Hier.ACTE_ID
      And Commande.INT_DEPOSIT_DT = RefO3_Hier.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_CLIIMSI  RefImsi
    On    Commande.ACTE_ID        = RefImsi.ACTE_ID
      And Commande.INT_DEPOSIT_DT = RefImsi.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_IRIS EDL_IRIS
    On    Commande.ACTE_ID        = EDL_IRIS.ACTE_ID
      And Commande.INT_DEPOSIT_DT = EDL_IRIS.INT_DEPOSIT_DT
   Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_FIBER EDL_FIBER
    On    Commande.ACTE_ID        = EDL_FIBER.ACTE_ID
      And Commande.INT_DEPOSIT_DT = EDL_FIBER.INT_DEPOSIT_DT
-- IOBSP
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On   (Commande.EDO_ID   = EdoOBK.EDO_ID or RefO3.EDO_ID =EdoOBK.EDO_ID)
        And Commande.INT_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')     And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On   Coalesce (Commande.ORG_AGENT_ID, VendeurVente.ORG_AGENT_ID)= CuidOBK.AGENT_ID
      AND Commande.INT_DEPOSIT_DT >= CuidOBK.HABILL_BEGIN_DT 
      AND Commande.INT_DEPOSIT_DT < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
;
  
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_T_PLACEMENT_EDL;
.if errorcode <> 0 then .quit 1

-- Purge des TABLE de travail trop skewee
DELETE FROM ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDRESP_2;
.if errorcode <> 0 then .quit 1

DELETE FROM ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDEUR_1;
.if errorcode <> 0 then .quit 1
