-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_MOB_Acte_Cold_MIGRATION.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql de calcul des migrations pour AGC MOB à froid
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/04/2014      YZH         Creation
-- 09/03/2015      HFO         MODIFICATION (ajout champs CHAPP perennité)
-- 27/05/2015      HFO         MODIFICATION   QC 1060
-- 20/07/2021      BCH         PILCOM-970 : Migration Assurance Mobile
--------------------------------------------------------------------------------

.set width 2500;

                                                          


----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

-- Produits migrables
Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C
(
  ACTE_ID                                   ,
  CONTEXT_ID                                ,
  EXTERNAL_ORDER_ID                         ,
  ORDER_DEPOSIT_DT                          ,
  PERIODE_ID                                ,
  CUSTOMER_CLIENT_NU_ADV                    ,
  CUSTOMER_DOSSIER_NU_ADV                   ,
  PRODUCT_ID_PRE                            ,
  SEG_COM_ID_PRE                            ,
  SEG_COM_AGG_ID_PRE                        ,
  CODE_MIGR_PRE                             ,
  TYPE_MVT_PRE                              ,
  PRODUCT_ID_FINAL                          ,
  SEG_COM_ID_FINAL                          ,
  SEG_COM_AGG_ID_FINAL                      ,
  SEG_COM_ID_LP                             ,
  CODE_MIGR_FINAL                           ,
  TYPE_SERVICE_FINAL                        ,
  TYPE_SERVICE_LP                           ,
  TYPE_MVT_FINAL                            ,
  TYPE_COMMANDE_ID                          ,
  DELTA_TARIF                               ,
  ACTE_ID_FUS                               ,
  RESIL_MOB_DT                              ,
  RESIL_MOB_MOTIF                           ,
  RESIL_MOB_MOTIF_DS                        ,
  PAR_IMSI_CD                                
)
Select
  ActeCreation.ACTE_ID                                                        as ACTE_ID                    ,
  ActeCreation.CONTEXT_ID                                                     as CONTEXT_ID                 ,
  ActeCreation.EXTERNAL_ORDER_ID                                              as EXTERNAL_ORDER_ID          ,
  ActeCreation.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT           ,
  ActeCreation.PERIODE_ID                                                     as PERIODE_ID                 ,
  ActeCreation.CUSTOMER_CLIENT_NU_ADV                                         as CUSTOMER_CLIENT_NU_ADV     ,
  ActeCreation.CUSTOMER_DOSSIER_NU_ADV                                        as CUSTOMER_DOSSIER_NU_ADV    ,
  Case  When ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And ActeCreation.MOUVEMENT = '${P_PIL_005}'
          Then 
            Case When MatMigAss.FLAG_EXPL_TARIF = '${P_PIL_100}' And AssMob.CPT_FACT_PR_NU Is Not Null
              Then RefProduit.PRODUCT_ID
              Else Null 
            End
          Else ActeDelete.PRODUCT_ID
  End                                                                         as PRODUCT_ID_PRE             ,
  --On ne valorise le produit précédant que lorsqu'on a détecter une migration :
  Case          
        When ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And ActeCreation.MOUVEMENT = '${P_PIL_005}'
          Then 
            Case When MatMigAss.FLAG_EXPL_TARIF = '${P_PIL_100}' And AssMob.CPT_FACT_PR_NU Is Not Null
              Then RefSegCom.SEG_COM_ID
              Else Null 
            End
        When ActeDelete.EXTERNAL_ORDER_ID Is Not Null
          Then ActeDelete.SEG_COM_ID
        Else Null
  End                                                                         as SEG_COM_ID_PRE             ,
  Case  When ActeDelete.EXTERNAL_ORDER_ID Is Not Null
          Then ActeDelete.SEG_COM_AGG_ID
        Else Null
  End                                                                         as SEG_COM_AGG_ID_PRE         ,
  Case  When ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And ActeCreation.MOUVEMENT = '${P_PIL_005}'
          Then 
            Case When MatMigAss.FLAG_EXPL_TARIF = '${P_PIL_100}' And AssMob.CPT_FACT_PR_NU Is Not Null
              Then MatMig.CODE_MIGRATION_INITIAL
              Else Null 
            End
          Else ActeDelete.CODE_MIGRATION
  End                                                                         as CODE_MIGR_PRE              ,
  Case  When ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And ActeCreation.MOUVEMENT = '${P_PIL_005}'
          Then 
            Case When MatMigAss.FLAG_EXPL_TARIF = '${P_PIL_100}' And AssMob.CPT_FACT_PR_NU Is Not Null
              Then MatMig.MOUVEMENT_INITIAL
              Else Null 
            End
          Else ActeDelete.MOUVEMENT
  End                                                                         as TYPE_MVT_PRE               ,
  ActeCreation.PRODUCT_ID                                                     as PRODUCT_ID_FINAL           ,
  ActeCreation.SEG_COM_ID                                                     as SEG_COM_ID_FINAL           ,
  ActeCreation.SEG_COM_AGG_ID                                                 as SEG_COM_AGG_ID_FINAL       ,
  ActeCreation.SEG_COM_ID_LP                                                  as SEG_COM_ID_LP              ,
  ActeCreation.CODE_MIGRATION                                                 as CODE_MIGR_FINAL            ,
  ActeCreation.TYPE_SERVICE                                                   as TYPE_SERVICE_FINAL         ,
  ActeCreation.TYPE_SERVICE_LP                                                as TYPE_SERVICE_LP            ,
  Case When ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And AssMob.CPT_FACT_PR_NU Is Not Null
          Then 'ADD'
       Else  ActeCreation.MOUVEMENT
  End                                                                         as TYPE_MVT_FINAL             ,
  --Calcul Du Type de commande
  Case  When  ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And ActeCreation.MOUVEMENT = '${P_PIL_005}'
          Then Case 
                  When MatMigAss.FLAG_EXPL_TARIF = '${P_PIL_100}' And AssMob.CPT_FACT_PR_NU Is Not Null
                    Then DeltaTarifAM.TYPE_COMMANDE_ID
                  Else  '${P_PIL_026}' -- ACQ
                End
        When  (ActeDelete.EXTERNAL_ORDER_ID is null And ActeCreation.MOUVEMENT = '${P_PIL_005}')
          Then '${P_PIL_026}'
        When  (ActeDelete.EXTERNAL_ORDER_ID is null And ActeCreation.MOUVEMENT = '${P_PIL_008}')
          Then '${P_PIL_027}'
        When  (ActeDelete.EXTERNAL_ORDER_ID is null And ActeCreation.MOUVEMENT = '${P_PIL_007}')
          Then '${P_PIL_028}'
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_101}' --Si on ne doit pas exploiter le delta tarif alors c'est le type commande (+le suffix)
          Then MatMig.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_100}' --Cas ou on doit exploiter le delta tarif
          Then DeltaTarif.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        Else Coalesce(DeltaTarif.TYPE_COMMANDE_ID,'MEF')
  End                                                                         as TYPE_COMMANDE_ID           ,
  Case  
     When  ActeCreation.SEG_COM_AGG_ID = 'ASSURMOB' And ActeCreation.MOUVEMENT = '${P_PIL_005}' 
	    Then (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(AssMob.PRESFACT_MT_TARIF ,0))
	    Else (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeDelete.TARIF_HT,0))       
  End                                                                         as DELTA_TARIF                ,
  --On purge les Ids des lignes dont on a fait la migration
  Case  When ActeDelete.MOUVEMENT = 'RMV'
          Then ActeDelete.ACTE_ID
        Else
          Null
  End                                                                         as ACTE_ID_FUS                ,
  ActeCreation.RESIL_MOB_DT                                                   as RESIL_MOB_DT               ,
  ActeCreation.RESIL_MOB_MOTIF                                                as RESIL_MOB_MOTIF            ,
  ActeCreation.RESIL_MOB_MOTIF_DS                                             as RESIL_MOB_MOTIF_DS         ,
  ActeCreation.PAR_IMSI_CD                                                    as PAR_IMSI_CD                
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C ActeCreation
  --Jointure sur la matrice de migration suivant le produit final + le mouvement Final
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM MatMig
    On ActeCreation.CODE_MIGRATION        = MatMig.CODE_MIGRATION_FINAL
      And ActeCreation.MOUVEMENT          = MatMig.MOUVEMENT_FINAL
      And ActeCreation.PERIODE_ID         = MatMig.PERIODE_ID
      And MatMig.CURRENT_IN               = 1
      And MatMig.CLOSURE_DT               is null 
  --Jointure sur la matrice de migration suivant le produit Ini + le mouvement Ini
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C ActeDelete
    On MatMig.CODE_MIGRATION_INITIAL      = ActeDelete.CODE_MIGRATION
      And ActeDelete.MOUVEMENT            = MatMig.MOUVEMENT_INITIAL
      And ActeCreation.CONTEXT_ID         = ActeDelete.CONTEXT_ID
      And ActeCreation.EXTERNAL_ORDER_ID  = ActeDelete.EXTERNAL_ORDER_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PRIX_TYPE_COMMANDE DeltaTarif --On réalise le delta tarif entre l'offre avant/Apres
    On    (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeDelete.TARIF_HT,0))         >= DeltaTarif.VAL_MIN
      And (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeDelete.TARIF_HT,0))         <= DeltaTarif.VAL_MAX
      And ActeCreation.PERIODE_ID                                                       = DeltaTarif.PERIODE_ID
      And DeltaTarif.CURRENT_IN                                                         = 1
      And DeltaTarif.CLOSURE_DT                                                         Is Null
  --Jointure sur la VP PILCOM suivant CLIENT_NU et DOSSIER_NU / Migration Assurance Mobile
  Left Outer Join ${KNB_KRP_VM_V}.INB_F_INSURANCE_VP AssMob
    ON AssMob.CPT_FACT_PR_NU              = ActeCreation.CUSTOMER_CLIENT_NU_ADV
      And AssMob.LIGNE_PR_NU              = ActeCreation.CUSTOMER_DOSSIER_NU_ADV
      And AssMob.FIN_CVT_DT         Between ActeCreation.ORDER_DEPOSIT_DT And ActeCreation.ORDER_DEPOSIT_DT + 1
      And AssMob.DEB_CVT_DT               <> AssMob.FIN_CVT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefProduit
     On   RefProduit.EXT_PRODUCT_ID2        = AssMob.PREFAC_CO 
	   And  RefProduit.TYPE_PRODUIT           = 'SO'
	   And  RefProduit.PERIODE_ID             = ActeCreation.PERIODE_ID 
     And  RefProduit.CURRENT_IN             = 1
     And  RefProduit.CLOSURE_DT             is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
      On    RefProduit.PRODUCT_ID           = RefSegCom.PRODUCT_ID
        And RefProduit.PERIODE_ID           = RefSegCom.PERIODE_ID
        And RefSegCom.CURRENT_IN            = 1
        And RefSegCom.CLOSURE_DT            is null
  --Jointure DeltaTarif pour Assurance Mobile sur PERIODE_ID VP PILCOM
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PRIX_TYPE_COMMANDE DeltaTarifAM 
    On    (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(AssMob.PRESFACT_MT_TARIF ,0))   >= DeltaTarifAM.VAL_MIN
      And (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(AssMob.PRESFACT_MT_TARIF ,0))   <= DeltaTarifAM.VAL_MAX
      And ActeCreation.PERIODE_ID                                                       = DeltaTarifAM.PERIODE_ID
      And DeltaTarifAM.CURRENT_IN                                                       = 1
      And DeltaTarifAM.CLOSURE_DT                                                       Is Null
  Left Outer Join  ${KNB_PCO_REFCOM}.CAT_R_MAT_MIGR_PILCOM MatMigAss
    On ActeCreation.CODE_MIGRATION=MatMigAss.CODE_MIGRATION_FINAL
      And MatMigAss.MOUVEMENT_FINAL = 'ADD'
      And ActeCreation.PERIODE_ID=MatMigAss.PERIODE_ID
      And MatMigAss.FRESH_IN=1
      And MatMigAss.CURRENT_IN=1
      And MatMigAss.CLOSURE_DT is null 
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE=${P_PIL_019}
Qualify Row_Number() Over (Partition by ActeCreation.ACTE_ID order by ActeDelete.CODE_MIGRATION desc)=1
;

.if errorcode <> 0 then .quit 1


-- Produits non migrable

Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C
(
  ACTE_ID                                   ,
  CONTEXT_ID                                ,
  EXTERNAL_ORDER_ID                         ,
  ORDER_DEPOSIT_DT                          ,
  --OSCAR_VALUE_NU                            ,
  PERIODE_ID                                ,
  CUSTOMER_CLIENT_NU_ADV                    ,
  CUSTOMER_DOSSIER_NU_ADV                   ,
  PRODUCT_ID_PRE                            ,
  SEG_COM_ID_PRE                            ,
  SEG_COM_AGG_ID_PRE                        ,
  CODE_MIGR_PRE                             ,
  TYPE_MVT_PRE                              ,
  PRODUCT_ID_FINAL                          ,
  SEG_COM_ID_FINAL                          ,
  SEG_COM_AGG_ID_FINAL                      ,
  SEG_COM_ID_LP                             ,
  CODE_MIGR_FINAL                           ,
  TYPE_SERVICE_FINAL                        ,
  TYPE_SERVICE_LP                           ,
  TYPE_MVT_FINAL                            ,
  TYPE_COMMANDE_ID                          ,
  DELTA_TARIF                               ,
  ACTE_ID_FUS                               ,
  RESIL_MOB_DT                              ,
  RESIL_MOB_MOTIF                           ,
  RESIL_MOB_MOTIF_DS                        ,
  PAR_IMSI_CD                                
)
Select
  ActeCreation.ACTE_ID                                                        as ACTE_ID                    ,
  ActeCreation.CONTEXT_ID                                                     as CONTEXT_ID                 ,
  ActeCreation.EXTERNAL_ORDER_ID                                              as EXTERNAL_ORDER_ID          ,
  ActeCreation.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT           ,
  ActeCreation.PERIODE_ID                                                     as PERIODE_ID                 ,
  ActeCreation.CUSTOMER_CLIENT_NU_ADV                                         as CUSTOMER_CLIENT_NU_ADV     ,
  ActeCreation.CUSTOMER_DOSSIER_NU_ADV                                        as CUSTOMER_DOSSIER_NU_ADV    ,
  Null                                                                        as PRODUCT_ID_PRE             ,
  Null                                                                        as SEG_COM_ID_PRE             ,
  Null                                                                        as SEG_COM_AGG_ID_PRE         ,
  Null                                                                        as CODE_MIGR_PRE              ,
  Null                                                                        as TYPE_MVT_PRE               ,
  ActeCreation.PRODUCT_ID                                                     as PRODUCT_ID_FINAL           ,
  ActeCreation.SEG_COM_ID                                                     as SEG_COM_ID_FINAL           ,
  ActeCreation.SEG_COM_AGG_ID                                                 as SEG_COM_AGG_ID_FINAL       ,
  ActeCreation.SEG_COM_ID_LP                                                  as SEG_COM_ID_LP              ,
  ActeCreation.CODE_MIGRATION                                                 as CODE_MIGR_FINAL            ,
  ActeCreation.TYPE_SERVICE                                                   as TYPE_SERVICE_FINAL         ,
  ActeCreation.TYPE_SERVICE_LP                                                as TYPE_SERVICE_LP            ,
  ActeCreation.MOUVEMENT                                                      as TYPE_MVT_FINAL             ,
  --Calcul Du Type de commande
  Case  When ActeCreation.MOUVEMENT = '${P_PIL_005}'
          Then '${P_PIL_016}'
        When ActeCreation.MOUVEMENT = '${P_PIL_008}'
          Then '${P_PIL_017}'
        When ActeCreation.MOUVEMENT = '${P_PIL_007}'
          Then '${P_PIL_018}'
  End                                                                         as TYPE_COMMANDE_ID           ,
  (Coalesce(ActeCreation.TARIF_HT,0))                                         as DELTA_TARIF                ,
  Null                                                                        as ACTE_ID_FUS                ,
  ActeCreation.RESIL_MOB_DT                                                   as RESIL_MOB_DT               ,
  ActeCreation.RESIL_MOB_MOTIF                                                as RESIL_MOB_MOTIF            ,
  ActeCreation.RESIL_MOB_MOTIF_DS                                             as RESIL_MOB_MOTIF_DS         ,
  ActeCreation.PAR_IMSI_CD                                                    as PAR_IMSI_CD                 
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C ActeCreation
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE=${P_PIL_020}
;
.if errorcode <> 0 then .quit 1


-- Collecter les statistiques

Collect Stat On ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C;
.if errorcode <> 0 then .quit 1






------------------------------------------------------------------------------------------------------------------
--On purge les Ids Dont on a migré :
------------------------------------------------------------------------------------------------------------------
Delete
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C RefId
Where
  (1=1)
  And Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C RefSup
    Where
      (1=1)
      And RefId.ACTE_ID   = RefSup.ACTE_ID_FUS
  )
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_MIGR_C;
.if errorcode <> 0 then .quit 1


.quit 0
