-- $HEADER: mm2pco/current/sql/ATP_OEE_Placement_Consolidation_CalculDelta_Jour.sql 13_05#7 04-DEC-2018 17:06:32 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Placement_Consolidation_CalculDelta_Jour.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul Delta
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
-- 02/05/2016      HLA         Ajouter filtre sur  Triplay 
-- 28/06/2016      HLA         Modification DEMANDE_DT_CREAT 
-- 04/12/2018      JCR         Ajout filtre sur les nouveaux produits inutiles (via COE)
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_EXRACT_OEE all;
.if errorcode <> 0 then .quit 1


------------------------------------------------------------------
-- Etape 1 : Création de la table volatile ---

Create Multiset Volatile Table ${KNB_TERADATA_USER}.INT_W_REF_ERC_OEE(
      RESOLU_ID CHAR(6) ,
      CONCLU_ID CHAR(6) ,
      SSCONCLU_ID VARCHAR(10)
   )
   Primary Index (
    RESOLU_ID,CONCLU_ID,SSCONCLU_ID
  )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.INT_W_REF_ERC_OEE Column( RESOLU_ID,CONCLU_ID,SSCONCLU_ID);
.if errorcode <> 0 then .quit 1

-- Etape 2 : Insertion dans la table volatile  pour les données des 6 derniers mois---

Insert Into ${KNB_TERADATA_USER}.INT_W_REF_ERC_OEE( 
   RESOLU_ID,
   CONCLU_ID,
   SSCONCLU_ID
)
Select
   RESOLU_ID,
   CONCLU_ID,
   SSCONCLU_ID
   
From  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OEE RefProduitOEE 
Where 
 (1=1)
      And RefProduitOEE.FRESH_IN                = 1
      And RefProduitOEE.CURRENT_IN              = 1
      And RefProduitOEE.CLOSURE_DT              is null 
      And RefProduitOEE.TYPE_PRODUIT            <> 'NS'
	  And RefProduitOEE.PERIODE_ID >=  (  Select
                                      min (MinRefPeriod.PERIODE_ID)
                                    From
                                    ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OEE MinRefPeriod
                                    Where
                                       (1=1)
                                         And MinRefPeriod.FRESH_IN                        = 1
                                         And MinRefPeriod.CURRENT_IN                      = 1
                                         And MinRefPeriod.CLOSURE_DT                      Is Null
                                         And ( MinRefPeriod.DATE_FIN  >=  add_months(current_date ,-6) And MinRefPeriod.DATE_DEBUT  <= add_months(current_date ,-6))
                                  )
   Qualify Row_Number() Over(Partition by  RefProduitOEE.RESOLU_ID,RefProduitOEE.CONCLU_ID,RefProduitOEE.SSCONCLU_ID Order By RefProduitOEE.PERIODE_ID DESC)=1						  

;   
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.INT_W_REF_ERC_OEE;
.if errorcode <> 0 then .quit 1
-- Etape 3 :
Insert Into ${KNB_PCO_TMP}.INT_W_EXRACT_OEE
(
  EXTERNAL_ACTE_ID        ,
  EXTERNAL_INT_ID         ,
  TYPE_SOURCE_ID          ,
  INT_DEPOSIT_TS          ,
  INT_DEPOSIT_DT          ,
  OPERATOR_PROVIDER_ID    ,
  RESOLU_ID               ,
  CONCLU_ID               ,
  SSCONCLU_ID             ,
  TYPE_COMMANDE           ,
  PLTF_CO                 ,
  INTRNL_SOURCE_ID        ,
  CONSEIL_XI_CREA         ,
  CONSEIL_XI_RESP         ,
  INT_MODIF_TS            ,
  IN_CLIDOS               ,
  CANALDEM                ,
  INT_REASON_CD           ,
  CLIENT_NU               ,
  DOSSIER_NU              ,
  PTVENTE_XI              ,
  CLOSURE_DT              
)
Select
  --Génération de la clé de la demande :
  Trim(Demande.DEMANDE_ID)||'S'||Trim(Coalesce(SSConc.SSCONC_CONCLU_ID,'${P_PIL_211}'))       as EXTERNAL_ACTE_ID       ,
  Trim(Demande.DEMANDE_ID)                                                                    as EXTERNAL_INT_ID        ,
  ${IdentifiantTechniqueSource}                                                               as TYPE_SOURCE_ID         ,
  Demande.DEMANDE_DT_CREAT                                                                    as INT_DEPOSIT_TS         ,
  Cast(Demande.DEMANDE_DT_CREAT as date format 'YYYYMMDD')                                    as INT_DEPOSIT_DT         ,
  'COM01'                                                                                     as OPERATOR_PROVIDER_ID   ,
  Demande.DEMANDE_RESOLU_ID                                                                   as RESOLU_ID              ,
  Demande.DEMANDE_CONCLU_ID                                                                   as CONCLU_ID              ,
  Coalesce(SSConc.SSCONC_CONCLU_ID,'${P_PIL_211}')                                            as SSCONCLU_ID            ,
   '${P_PIL_016}'                                                                             as TYPE_COMMANDE          ,
  Demande.DEMANDE_PLTF_CO                                                                     as PLTF_CO                ,
  ${IdSourceInterne}                                                                          as INTRNL_SOURCE_ID       ,
  --Information sur le XI Createur
  Demande.DEMANDE_CONSEIL_XI_CREA                                                             as CONSEIL_XI_CREA        ,
  --Information sur le XI responsable
  Demande.DEMANDE_CONSEIL_XI_RESP                                                             as CONSEIL_XI_RESP        ,
  Demande.DEMANDE_DT_DER_MODIF                                                                as INT_MODIF_TS           ,
  --Type client ou dossier
  Demande.DEMANDE_IN_CLIDOS                                                                   as IN_CLIDOS              ,
  Demande.DEMANDE_CANALDEM_CO                                                                 as CANALDEM               ,
  --Type de la Résolution (pour le motif)
  Resolu.RESOLU_CO_THM                                                                        as INT_REASON_CD          ,
  --Enrichissement Client/Dossier
  Demande.DEMANDE_CLIENT_NU                                                                   as CLIENT_NU              ,
  Demande.DEMANDE_DOSSIER_NU                                                                  as DOSSIER_NU             ,
  Demande.Demande_PTVENTE_XI                                                                  as PTVENTE_XI             ,
  Demande.DEMANDE_DT_SUPP                                                                     as CLOSURE_DT             
From
  ${KNB_IBU_SOC}.V_TFDEMANDE Demande
  --Jointure dans les sous-conclusion :
  Inner Join ${KNB_IBU_SOC}.V_TFSSCONC SSConc
    On    Demande.DEMANDE_ID        = SSConc.SSCONC_DEMANDE_ID
  Inner Join ${KNB_TERADATA_USER}.INT_W_REF_ERC_OEE RefProduitOEE
    On       Demande.DEMANDE_RESOLU_ID                         = RefProduitOEE.RESOLU_ID
       And   Demande.DEMANDE_CONCLU_ID                         = RefProduitOEE.CONCLU_ID
       And   Coalesce(SSConc.SSCONC_CONCLU_ID,'${P_PIL_211}')  = RefProduitOEE.SSCONCLU_ID
  Left Outer Join ${KNB_IBU_SOC}.V_TDRESOLU Resolu
    On    Demande.DEMANDE_RESOLU_ID = Resolu.RESOLU_ID
      And Resolu.CURRENT_IN         = 1
      And Resolu.CLOSURE_DT         Is Null
Where
  (1=1)
  --Restriction sur les dates de lastModif
  And (
         (
		    Demande.LAST_MODIF_TS > '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
          And
            Demande.LAST_MODIF_TS <= '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'
		  )
		  Or 
		    Demande.DEMANDE_DT_CREAT >= current_date -60
      )
  --On ne prend que les demandes valorisée :
  And Demande.DEMANDE_CONCLU_ID   is not null
  And Demande.DEMANDE_RESOLU_ID   is not null
  --And SSConc.SSCONC_CONCLU_ID     is not null
  --On filtre les données de OEE
  And Demande.DEMANDE_PLTF_CO   = 'OEE'
  --On Exlcu de l'extraction certains canaux :
  And Demande.DEMANDE_CANALDEM_CO Not In ('CHO','CHORUS')

;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_EXRACT_OEE;
.if errorcode <> 0 then .quit 1


