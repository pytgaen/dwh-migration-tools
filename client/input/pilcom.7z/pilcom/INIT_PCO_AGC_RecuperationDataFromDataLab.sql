-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   INIT_PCO_AGC_RecuperationDataFromDataLab.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 30/10/2014      GAM         Changement de table pour les reprises
--------------------------------------------------------------------------------

.set width 2500;

Create Multiset Volatile Table ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD_P(
  CONTEXT_ID Integer  NOT NULL
)
PRIMARY INDEX ( CONTEXT_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Locking ODS_MM2.ORD_O_ORDER_AGC_COM for access
Insert into ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD_P
(
  CONTEXT_ID
)
Select
  CalculFinal.CONTEXT_ID as CONTEXT_ID
From
  (
    --On agrège l'ensemble sur la clé afin de supprimer les null des sous ensemble de requete
    Select
      FusionComm.CONTEXT_ID               as CONTEXT_ID                   ,
      FusionComm.QUEUE_TS                 as QUEUE_TS                     ,
      Coalesce(Max(NB_LINE_ORDER),0)      as NB_LINE_ORDER                ,
      Coalesce(Max(COUNTLINEORDER),0)     as COUNTLINEORDER
    From
      (
          --On requete pour calculer le nombre de ligne de commande par contexte  et queue_ts
          Select
            Com.CONTEXT_ID                          as CONTEXT_ID         ,
            Com.QUEUE_TS                            as QUEUE_TS           ,
            Com.NB_LINE_ORDER                       as NB_LINE_ORDER      ,
            Count(LigneCom.CONTEXT_ID)              as COUNTLINEORDER
          From
            PLC_LAB_TMP.REP_O_ORDER_AGC_COM Com
            Inner Join PLC_LAB_TMP.REP_O_ORDER_AGC_LINE_COM LigneCom
            On  Com.CONTEXT_ID = LigneCom.CONTEXT_ID
            And Com.QUEUE_TS   = LigneCom.QUEUE_TS
          Where
            (1=1)
          Group by Com.CONTEXT_ID, Com.QUEUE_TS, Com.NB_LINE_ORDER
      )FusionComm
    Group By
      FusionComm.CONTEXT_ID,
      FusionComm.QUEUE_TS
  )CalculFinal
Where
  (1=1)
  And CalculFinal.NB_LINE_ORDER = CalculFinal.COUNTLINEORDER
  And Not exists (
    Select 1 From ODS_MM2.ORD_O_ORDER_AGC_COM ods
    Where CalculFinal.CONTEXT_ID=ods.CONTEXT_ID
  )
;
.if errorcode <> 0 then .quit 1





--On collecte les stats sur la table Volatile
Collect Stat ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD_P Column(CONTEXT_ID);
.if errorcode <> 0 then .quit 1

--On procèdes aux alimentations des tables Temporaires pour ces commandes :


--Insertion dans la table des commandes :
Insert Into ODS_MM2.ORD_O_ORDER_AGC_COM
Select
 COM.*
From
  PLC_LAB_TMP.REP_O_ORDER_AGC_COM Com
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD_P RefId
    On    Com.CONTEXT_ID = RefId.CONTEXT_ID

--Insertion dans la table des lignes de commandes Internet :
;Insert Into ODS_MM2.ORD_O_ORDER_AGC_LINE_COM
Select
  LigneInternet.*
From
  PLC_LAB_TMP.REP_O_ORDER_AGC_LINE_COM LigneInternet
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD_P RefId
    On   LigneInternet.CONTEXT_ID = RefId.CONTEXT_ID
;
.if errorcode <> 0 then .quit 1


