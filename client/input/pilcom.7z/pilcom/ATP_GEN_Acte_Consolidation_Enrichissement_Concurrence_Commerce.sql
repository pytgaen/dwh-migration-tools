-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GEN_Acte_Consolidation_Enrichissement_Concurrence_Commerce.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------------------
--Dédoublonnage de la vente Conclu 
----------------------------------------------------------------------------------------------------------

Create Volatile Table ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} (
  ACTE_ID                       Bigint                  Not Null,
  INT_DEPOSIT_DT                Date Format 'YYYYMMDD'  Not Null,
  NUMERO_LINE                   Integer                         ,
  CONCURENCE_ID                 Bigint                          ,
  TYPE_MODIF                    Char(1)                         
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1




--Calcul des Actes en concurrence
Insert into ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source}
(
  ACTE_ID           ,
  INT_DEPOSIT_DT    ,
  NUMERO_LINE       ,
  CONCURENCE_ID     ,
  TYPE_MODIF        
)
Select
  Tmp.ACTE_ID           as ACTE_ID          ,
  Tmp.INT_DEPOSIT_DT    as INT_DEPOSIT_DT   ,
  Tmp.NumLine           as NUMERO_LINE      ,
  Case
      --Dans le cas où c'est la 1ere commande :
      When Tmp.NumLine = 1
        Then Null
      --Dans le cas où ce n'est pas la 1ere commande on récupère l'identifiant de la 1ere colonne
      Else
        (Max(Case When Tmp.NumLine > 1 Then Null Else Tmp.ACTE_ID end)
            Over  ( Partition by  Tmp.CLIENT_NU               ,
                                  Tmp.DOSSIER_NU              ,
                                  Tmp.ACT_SEG_COM_ID_FINAL    ,
                                  Tmp.ORG_AGENT_ID            ,
                                  Tmp.INT_DEPOSIT_DT          ,
                                  Tmp.ACT_TYPE_COMMANDE_ID    
                    Order by      Tmp.NumLine Asc             ,
                                  Tmp.ACTE_ID Asc             
                  )
        )
  End                   as CONCURENCE_ID  ,
  Tmp.TYPE_MODIF        as TYPE_MODIF     
From
  (
    Select
      Acte.ACTE_ID                  as ACTE_ID                ,
      Acte.INT_DEPOSIT_DT           as INT_DEPOSIT_DT         ,
      Acte.CLIENT_NU                as CLIENT_NU              ,
      Acte.DOSSIER_NU               as DOSSIER_NU             ,
      Acte.ACT_SEG_COM_ID_FINAL     as ACT_SEG_COM_ID_FINAL   ,
      Acte.ORG_AGENT_ID             as ORG_AGENT_ID           ,
      Acte.ACT_TYPE_COMMANDE_ID     as ACT_TYPE_COMMANDE_ID   ,
      --On met un numéro de ligne devant chaque doublon de commande pour reconnaitre le 1er
      Row_number() Over (Partition by Acte.CLIENT_NU, Acte.DOSSIER_NU, Acte.ACT_SEG_COM_ID_FINAL, Acte.INT_DEPOSIT_DT, Acte.ORG_AGENT_ID, Acte.ACT_TYPE_COMMANDE_ID Order by Acte.INT_DEPOSIT_TS asc, Acte.ACTE_ID asc) as NumLine ,
      Acte.INT_DEPOSIT_TS           as INT_DEPOSIT_TS         ,
      --On regarde le Type de modification dans le socle
      Case  When Acte.COHERENCE_IN=1
              Then 'M'  --Dans le cas où la ligne est En 1,1 alors on réalise un passage en FRESH_IN=0
            When Acte.COHERENCE_IN=0
              Then 'U'  --Dans le cas où la ligne a déjà été basculée alors on update directement
      End                     as TYPE_MODIF
    From
      ${KNB_PCO_VM}.V_INT_F_ACTE_${Source} Acte
    Where
      (1=1)
      And Acte.ACT_SEG_COM_ID_FINAL   Is Not Null
      And Acte.CLOSURE_DT             Is Null
    --On ne recupère que les doublons de commande
    Qualify count(*) Over (Partition by Acte.CLIENT_NU, Acte.DOSSIER_NU, Acte.ACT_SEG_COM_ID_FINAL, Acte.INT_DEPOSIT_DT, Acte.ORG_AGENT_ID, Acte.ACT_TYPE_COMMANDE_ID) > 1
  ) Tmp
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} column(ACTE_ID);
.if errorcode <> 0 then .quit 1


--On réinsert toutes les lignes qui était auparavent en concurrence
Insert into ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source}
(
  ACTE_ID           ,
  INT_DEPOSIT_DT    ,
  NUMERO_LINE       ,
  CONCURENCE_ID     ,
  TYPE_MODIF        
)
Select
  RefVm.ACTE_ID           as ACTE_ID          ,
  RefVm.INT_DEPOSIT_DT    as INT_DEPOSIT_DT   ,
  Null                    as NUMERO_LINE      ,
  Null                    as CONCURENCE_ID    ,
  Case  When RefVm.COHERENCE_IN=1
          Then 'M'  --Dans le cas où la ligne est En 1,1 alors on réalise un passage en FRESH_IN=0
        When RefVm.COHERENCE_IN=0
          Then 'U'  --Dans le cas où la ligne a déjà été basculée alors on update directement
  End                     as TYPE_MODIF     
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_${Source} RefVm
  Left Outer Join ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} Vol
    On    RefVm.ACTE_ID         = Vol.ACTE_ID
      And RefVm.INT_DEPOSIT_DT  = Vol.INT_DEPOSIT_DT
Where
  (1=1)
  And RefVm.CONCURENCE_CONCLU_IN     in ('N','O')
  --Filtrage des lignes Non présente dans la table Volatile
  And Vol.ACTE_ID             Is Null
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} column(ACTE_ID);
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} column(TYPE_MODIF);
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------------------
--Dédoublonnage de la vente Livré
----------------------------------------------------------------------------------------------------------


Create Volatile Table ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} (
  ACTE_ID                       Bigint                  Not Null,
  INT_DEPOSIT_DT                Date Format 'YYYYMMDD'  Not Null,
  NUMERO_LINE                   ByteInt                         ,
  CONCURENCE_ID                 Bigint                          ,
  TYPE_MODIF                    Char(1)                         
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1







--Calcul des Actes en concurrence
Insert into ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source}
(
  ACTE_ID           ,
  INT_DEPOSIT_DT    ,
  NUMERO_LINE       ,
  CONCURENCE_ID     ,
  TYPE_MODIF        
)
Select
  Tmp.ACTE_ID           as ACTE_ID          ,
  Tmp.INT_DEPOSIT_DT    as INT_DEPOSIT_DT   ,
  Tmp.NumLine           as NUMERO_LINE      ,
  Case
      --Dans le cas où c'est la 1ere commande :
      When Tmp.NumLine = 1
        Then Null
      --Dans le cas où ce n'est pas la 1ere commande on récupère l'identifiant de la 1ere colonne
      Else
        (Max(Case When Tmp.NumLine > 1 Then Null Else Tmp.ACTE_ID end)
            Over  ( Partition by  Tmp.CLIENT_NU               ,
                                  Tmp.DOSSIER_NU              ,
                                  Tmp.ACT_SEG_COM_ID_FINAL    ,
                                  Tmp.SEG_PARC_DT_DEBUT       ,
                                  Tmp.ACT_TYPE_COMMANDE_ID    
                    Order by      Tmp.NumLine Asc       ,
                                  Tmp.ACTE_ID Asc
                  )
        )
  End                   as CONCURENCE_ID  ,
  Tmp.TYPE_MODIF        as TYPE_MODIF     
From
  (
    Select
      Acte.ACTE_ID                  as ACTE_ID                ,
      Acte.INT_DEPOSIT_DT           as INT_DEPOSIT_DT         ,
      Acte.CLIENT_NU                as CLIENT_NU              ,
      Acte.DOSSIER_NU               as DOSSIER_NU             ,
      Acte.ACT_SEG_COM_ID_FINAL     as ACT_SEG_COM_ID_FINAL   ,
      Acte.SEG_PARC_DT_DEBUT        as SEG_PARC_DT_DEBUT      ,
      Acte.ACT_TYPE_COMMANDE_ID     as ACT_TYPE_COMMANDE_ID   ,
      --On met un numéro de ligne devant chaque doublon de commande pour reconnaitre le 1er
      Row_number() Over (Partition by Acte.CLIENT_NU, Acte.DOSSIER_NU, Acte.ACT_SEG_COM_ID_FINAL, Acte.SEG_PARC_DT_DEBUT, Acte.ACT_TYPE_COMMANDE_ID Order by Acte.INT_DEPOSIT_TS asc, Acte.ACTE_ID asc) as NumLine ,
      Acte.INT_DEPOSIT_TS           as INT_DEPOSIT_TS         ,
      --On regarde le Type de modification dans le socle
      Case  When Acte.COHERENCE_IN=1
              Then 'M'  --Dans le cas où la ligne est En 1,1 alors on réalise un passage en FRESH_IN=0
            When Acte.COHERENCE_IN=0
              Then 'U'  --Dans le cas où la ligne a déjà été basculée alors on update directement
      End                     as TYPE_MODIF
    From
      ${KNB_PCO_VM}.V_INT_F_ACTE_${Source} Acte
    Where
      (1=1)
      And Acte.DELIVERY_DT            Is Not null
      And Acte.ACT_SEG_COM_ID_FINAL   Is Not Null
      And Acte.CLOSURE_DT             Is Null
      --On ne récupère que les commandes ayant été livrées à Temps
      And Acte.DELIVERY_ONTIME_IN     = 'O'
      --On exclu les ventes en doublon sur le conclu
      And Not Exists
          (
            Select
              1
            From
              ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} Conclu
            Where
              (1=1)
              And Acte.ACTE_ID            = Conclu.ACTE_ID
              And Acte.INT_DEPOSIT_DT     = Conclu.INT_DEPOSIT_DT
              And Conclu.NUMERO_LINE > 1
          )
    --On ne recupère que les doublons de commande
    Qualify count(*) Over (Partition by Acte.CLIENT_NU, Acte.DOSSIER_NU, Acte.ACT_SEG_COM_ID_FINAL, Acte.SEG_PARC_DT_DEBUT, Acte.ACT_TYPE_COMMANDE_ID) > 1
  ) Tmp
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} column(ACTE_ID);
.if errorcode <> 0 then .quit 1

--On réinsert toutes les lignes qui était auparavent en concurrence
Insert into ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source}
(
  ACTE_ID           ,
  INT_DEPOSIT_DT    ,
  NUMERO_LINE       ,
  CONCURENCE_ID     ,
  TYPE_MODIF        
)
Select
  RefVm.ACTE_ID           as ACTE_ID          ,
  RefVm.INT_DEPOSIT_DT    as INT_DEPOSIT_DT   ,
  Null                    as NUMERO_LINE      ,
  Null                    as CONCURENCE_ID    ,
  Case  When RefVm.COHERENCE_IN=1
          Then 'M'  --Dans le cas où la ligne est En 1,1 alors on réalise un passage en FRESH_IN=0
        When RefVm.COHERENCE_IN=0
          Then 'U'  --Dans le cas où la ligne a déjà été basculée alors on update directement
  End                     as TYPE_MODIF     
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_${Source} RefVm
  Left Outer Join ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} Vol
    On    RefVm.ACTE_ID         = Vol.ACTE_ID
      And RefVm.INT_DEPOSIT_DT  = Vol.INT_DEPOSIT_DT
Where
  (1=1)
  And RefVm.CONCURENCE_IN     in ('N','O')
  --Filtrage des lignes Non présente dans la table Volatile
  And Vol.ACTE_ID             Is Null
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} column(ACTE_ID);
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} column(TYPE_MODIF);
.if errorcode <> 0 then .quit 1






--On créer la table de bascule Volatile

Create Volatile Table ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} (
  ACTE_ID                       Bigint                  Not Null  ,
  INT_DEPOSIT_DT                Date Format 'YYYYMMDD'  Not Null  ,
  CONCURENCE_IN                 Char(2)                           ,
  CONCURENCE_CONCLU_IN          Char(2)                           ,
  CONCURENCE_ID                 Bigint                            
)
Primary Index (
  ACTE_ID
)
Partition By RANGE_N(INT_DEPOSIT_DT Between Date '2008-01-01' And Date '2100-01-01' each Interval '1' Day )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

--On insert les lignes concurrence conclu

Insert into ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source}
(
  ACTE_ID                       ,
  INT_DEPOSIT_DT                ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 
)
Select
  VolConclu.ACTE_ID                       as ACTE_ID                      ,
  VolConclu.INT_DEPOSIT_DT                as INT_DEPOSIT_DT               ,
  Case    When VolConclu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
            Then 'CC'
  End                                     as CONCURENCE_IN                ,
  Case    When VolConclu.NUMERO_LINE Is Null  --Si la ligne vient de perdre sa concurrence
            Then 'NA'
          When VolConclu.NUMERO_LINE = 1 --Si c'est la ligne de référence
            Then 'O'
          When VolConclu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
            Then 'N'
  End                                     as CONCURENCE_CONCLU_IN         ,
  Case    When VolConclu.NUMERO_LINE Is Null  --Si la ligne vient de perdre sa concurrence
            Then Null
          When VolConclu.NUMERO_LINE = 1 --Si c'est la ligne de référence
            Then Null
          When VolConclu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
            Then VolConclu.CONCURENCE_ID
  End                                     as CONCURENCE_ID                
From
  ${KNB_TERADATA_USER}.ACT_V_DEDUP_CONCLU_${Source} VolConclu
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} Column(PARTITION);
.if errorcode <> 0 then .quit 1

--On insert les lignes en concurrence
--On fait d'abord l'update pour les lignes qui ont les 2 concurrences
Update Vm
From
  ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} Vm        ,
  ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} VolVendu   
Set
  CONCURENCE_IN   = Case    When VolVendu.NUMERO_LINE Is Null  --Si la ligne vient de perdre sa concurrence
                              Then 'NA'
                            When VolVendu.NUMERO_LINE = 1 --Si c'est la ligne de référence
                              Then 'O'
                            When VolVendu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
                              Then 'N'
                    End,
  CONCURENCE_ID   = Case    When VolVendu.NUMERO_LINE Is Null  --Si la ligne vient de perdre sa concurrence
                              Then Null
                            When VolVendu.NUMERO_LINE = 1 --Si c'est la ligne de référence
                              Then Null
                            When VolVendu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
                              Then VolVendu.CONCURENCE_ID
                    End
Where
  (1=1)
  And Vm.ACTE_ID              = VolVendu.ACTE_ID
  And Vm.INT_DEPOSIT_DT       = VolVendu.INT_DEPOSIT_DT


--On insert les lignes en concurrences simple
;Insert into ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source}
(
  ACTE_ID                       ,
  INT_DEPOSIT_DT                ,
  CONCURENCE_IN                 ,
  CONCURENCE_CONCLU_IN          ,
  CONCURENCE_ID                 
)
Select
  VolVendu.ACTE_ID                        as ACTE_ID                      ,
  VolVendu.INT_DEPOSIT_DT                 as INT_DEPOSIT_DT               ,
  Case    When VolVendu.NUMERO_LINE Is Null  --Si la ligne vient de perdre sa concurrence
            Then 'NA'
          When VolVendu.NUMERO_LINE = 1 --Si c'est la ligne de référence
            Then 'O'
          When VolVendu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
            Then 'N'
  End                                     as CONCURENCE_IN                ,
  Null                                    as CONCURENCE_CONCLU_IN         ,
  Case    When VolVendu.NUMERO_LINE Is Null  --Si la ligne vient de perdre sa concurrence
            Then Null
          When VolVendu.NUMERO_LINE = 1 --Si c'est la ligne de référence
            Then Null
          When VolVendu.NUMERO_LINE > 1 --Dans le cas de ligne Concurrentes
            Then VolVendu.CONCURENCE_ID
  End                                     as CONCURENCE_ID                
From
  ${KNB_TERADATA_USER}.ACT_V_DEDUP_VENDU_${Source} VolVendu
Where
  (1=1)
  And Not Exists
    (
      Select
        1
      From
        ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} RefId
      Where
        (1=1)
        And VolVendu.ACTE_ID         = RefId.ACTE_ID
        And VolVendu.INT_DEPOSIT_DT  = RefId.INT_DEPOSIT_DT
    )
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} Column(ACTE_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} Column(PARTITION);
.if errorcode <> 0 then .quit 1


--On delete les lignes identiques
Delete From ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source}
Where
  ACTE_ID in
  (
    --On selectionne ici les ids qui n'ont pas de modifications
    Select
      VolConclu.ACTE_ID
    From
      ${KNB_PCO_VM}.INT_F_ACTE_${Source} Vm
      Inner Join ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} VolConclu 
        On    Vm.ACTE_ID         = VolConclu.ACTE_ID
          And Vm.INT_DEPOSIT_DT  = VolConclu.INT_DEPOSIT_DT
    Where
      (1=1)
      And Vm.FRESH_IN  = 1
      And Coalesce(Vm.CONCURENCE_IN,'#')            =  Coalesce(VolConclu.CONCURENCE_IN,'#')
      And Coalesce(Vm.CONCURENCE_CONCLU_IN,'#')     =  Coalesce(VolConclu.CONCURENCE_CONCLU_IN,'#')
      And Coalesce(Vm.CONCURENCE_ID,-1)             =  Coalesce(VolConclu.CONCURENCE_ID,-1)
  )
;
.if errorcode <> 0 then .quit 1



--Mise à jour du Socle
Update Vm
From
  ${KNB_PCO_VM}.INT_F_ACTE_${Source} Vm                       ,
  ${KNB_TERADATA_USER}.ACT_V_DEDUP_BASCULE_${Source} Vol      
Set
  CONCURENCE_IN         = Vol.CONCURENCE_IN               ,
  CONCURENCE_CONCLU_IN  = Vol.CONCURENCE_CONCLU_IN        ,
  CONCURENCE_ID         = Vol.CONCURENCE_ID               ,
  LAST_MODIF_TS         = Current_Timestamp(0)            
Where
  (1=1)
  And Vm.ACTE_ID              = Vol.ACTE_ID
  And Vm.INT_DEPOSIT_DT       = Vol.INT_DEPOSIT_DT
  And Vm.FRESH_IN             = 1
;
.if errorcode <> 0 then .quit 1


.quit 0

