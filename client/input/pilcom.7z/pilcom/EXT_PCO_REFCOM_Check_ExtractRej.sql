 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step3_CollectStatTb.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des produits SAVI
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000


Select
  Trim(RejRefcom.REJECT_TYPE_ID)||'|'||
  Coalesce(RejRefcom.SOURCE_ID,'')||'|'||
  Coalesce(RejRefcom.CATALOG_ID,'')||'|'||
  Coalesce(RejRefcom.ERROR_CD,'')||'|'||
  Coalesce(RejRefcom.INFO_CD,'')||'|'||
  Coalesce(Trim(RejRefcom.VOLUME_NB),'')||'|'||
  Coalesce(Trim(Cast(Cast(RejRefcom.MIN_RECEIVED_DT as date Format 'YYYY/MM/DD') as Varchar(20))),'')||'|'||
  Coalesce(Trim(Cast(Cast(RejRefcom.MAX_RECEIVED_DT as date Format 'YYYY/MM/DD') as Varchar(20))),'') (title '')
From
  ${KNB_PCO_SOC}.V_FLW_H_REFCOM_LOGS RejRefcom
Where
  (1=1)
  And   (
            RejRefcom.REJECT_TYPE_ID  in (1,2,3,4,5,6)
            Or
            (RejRefcom.REJECT_TYPE_ID in (7,8) And RejRefcom.CATALOG_ID='ERR')
        )
Order by
  RejRefcom.REJECT_TYPE_ID Asc    ,
  RejRefcom.SOURCE_ID Asc         ,
  RejRefcom.CATALOG_ID Asc        ,
  RejRefcom.ERROR_CD              
;
.if errorcode <> 0 Then .quit 1


.quit 0
