--$HEADER:   %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DIGITAL_ORD_T_ACTE_VAD_DIGITAL.sql  $            
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL  Rapprochement avec les interactions  JRC           
---------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 25/06/2019     JCR         Création
-- 19/08/2019     GRH         Modification
-- 15/11/2019     SII         Modification
-- 23/01/2020     EVI         PILCOM-234 : Variabilisation Interaction JRC de J-X jours
-- 11/05/2020     EVI         PILCOM-440 : Optimisation Calcul Digitaux + Suppression Bloc avant 01/01/2020
-- 25/03/2020     YAB         Modification de IND_HD_RAP_CD lorsque la tempo est activée
-- 15/04/2021     EVI         PILCOM-882 : H&D - Recherche Table Ancetre / Rapprochement H&D-JRC
---------------------------------------------------------------------------------

.set width 5000

Delete From ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM;
.if errorcode <> 0 then .quit 1;

-------------------------------------------------------------
---      Alimentation de la table ORD_KPI_HD_PILCOM      ----
-------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM
(

PERIODE_ID           ,
PERIODE_DATE_DEB     ,
PERIODE_DATE_FIN     ,
KPI_HD                
)
select 
Periode.PERIODE_ID                      As PERIODE_ID           ,
Periode.PERIODE_DATE_DEB                As PERIODE_DATE_DEB     ,
Periode.PERIODE_DATE_FIN                As PERIODE_DATE_FIN     ,
KPI.FAMILLE_KPI_ID                      As KPI_HD               

from       ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
inner join  ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM        KPI
On    KPI.PERIODE_ID    =   Periode.PERIODE_ID
 And  KPI.HUMAINDIGITAL =   'O'
 And  KPI.CLOSURE_DT    Is  Null
 And  KPI.CURRENT_IN    =   1 
--pour les derniers 6 mois
 Where Periode.PERIODE_ID >=  (  Select
                                      min (MinRefPeriod.PERIODE_ID)
                                    From
                                    ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM MinRefPeriod
                                    Where
                                       (1=1)
                                         And MinRefPeriod.FRESH_IN          = 1
                                         And MinRefPeriod.CURRENT_IN        = 1
                                         And MinRefPeriod.CLOSURE_DT        Is Null
                                         And MinRefPeriod.PERIODE_DATE_FIN  >= add_months(current_date ,-6) 
                                         And MinRefPeriod.PERIODE_DATE_DEB  <= add_months(current_date ,-6)
                                  )
 And Periode.CLOSURE_DT Is Null
 And Periode.CURRENT_IN =        1
 And Periode.FRESH_IN   =        1
;
.if errorcode <> 0 then .quit 1;
Collect Stats On ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM ;
.if errorcode <> 0 then .quit 1; 

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL;
.if errorcode <> 0 then .quit 1;


------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
--                                       RECHERCHE TABLE DES ANCETRES : PID
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------

-----------------------------------
--  Table des grappes PID pour chaque PID d'un acte
-----------------------------------
CREATE MULTISET VOLATILE TABLE ${KNB_TERADATA_USER}.INT_V_GRP_PID_${Source} 
     (
      PAR_PID_ID     VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      LNK_PID_ID     VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC , 
      CURRENT_PID_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC 
     )
PRIMARY INDEX  ( PAR_PID_ID)
ON COMMIT PRESERVE ROWS;
.if errorcode <> 0 then .quit 1;

-----------------------------------
--  Recherche des grappes PID
-----------------------------------
Insert Into ${KNB_TERADATA_USER}.INT_V_GRP_PID_${Source}
(
   PAR_PID_ID
 , LNK_PID_ID
 , CURRENT_PID_ID
)
Select Distinct
  ACT_DIGIT.PAR_PID_ID   As PAR_PID_ID  ,
  GRP_PID.LINK_PID_ID    As LNK_PID_ID  ,
  GRP_PID.CURRENT_PID_ID As CURRENT_PID_ID

 From ${KNB_PCO_TMP}.ORD_W_${Source}_ELIG_JRC_DIGITAL  ACT_DIGIT
Inner Join ${KNB_CLP_VM_GLB}.PAR_F_PID_HISTO_LINKS_VM  CURRENT_PID
   On CURRENT_PID.LINK_PID_ID  = ACT_DIGIT.PAR_PID_ID
  And CURRENT_PID.LINK_TYPE_CD <> 'S' 
Inner Join ${KNB_CLP_VM_GLB}.PAR_F_PID_HISTO_LINKS_VM  GRP_PID
   On GRP_PID.CURRENT_PID_ID  = CURRENT_PID.CURRENT_PID_ID
Where (1=1)
  And GRP_PID.LINK_DATE_TS >= (Current_Date - 15);
.if errorcode <> 0 then .quit 1;


Collect stat on ${KNB_TERADATA_USER}.INT_V_GRP_PID_${Source} Index (PAR_PID_ID);
.if errorcode <> 0 then .quit 1;


------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
--                                       RAPPROCHEMENT PRECALCUL ACTE H&D / INTERACTION JRC
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------

-----------------------------------
--  Table des rapprochements H&D/JRC
-----------------------------------
CREATE MULTISET VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_CROSS_${Source}_JRC 
     (
      ACTE_ID BIGINT ,
      ACT_DT DATE FORMAT 'YYYY-MM-DD' ,
      PRIO_INTRCTN INT ,
      RAP_PID_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      RAP_UNIFIED_PARTY_ID VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ACTE_ID_INTRCTN BIGINT ,
      INTRCTN_DT DATE FORMAT 'YYYY-MM-DD' 
     )
PRIMARY INDEX  ( ACTE_ID)
ON COMMIT PRESERVE ROWS;
.if errorcode <> 0 then .quit 1;

-----------------------------------
--  Recherche des interractions (par priorisation) : 1 - PID / 2 - CUID Drakkar
-----------------------------------
Insert Into ${KNB_TERADATA_USER}.ORD_V_CROSS_${Source}_JRC 
(
   ACTE_ID
 , ACT_DT
 , PRIO_INTRCTN
 , RAP_PID_ID
 , RAP_UNIFIED_PARTY_ID
 , ACTE_ID_INTRCTN
 , INTRCTN_DT
)
Select 
  ACT_DIGIT.ACTE_ID                                                    As ACTE_ID              ,
  ACT_DIGIT.ACT_DT                                                     As ACT_DT               ,
  Case     
     When Placement_JRC_PID.ACTE_ID  Is Not Null Then 1    
     When Placement_JRC_CUID.ACTE_ID Is Not Null Then 2    
  End                                                                  As PRIO_INTRCTN         ,
  GRP_PID.CURRENT_PID_ID                                               As RAP_PID_ID           ,
  Placement_JRC_CUID.UNIFIED_PARTY_ID                                  As RAP_UNIFIED_PARTY_ID ,
  Coalesce(Placement_JRC_PID.ACTE_ID,Placement_JRC_CUID.ACTE_ID)       As ACTE_ID_INTRCTN      ,
  Coalesce(Placement_JRC_PID.INTRCTN_DT,Placement_JRC_CUID.INTRCTN_DT) As INTRCTN_DT
 From ${KNB_PCO_TMP}.ORD_W_${Source}_ELIG_JRC_DIGITAL   ACT_DIGIT
 -- Recherche Interaction via PID
 Left Outer Join ${KNB_TERADATA_USER}.INT_V_GRP_PID_${Source} GRP_PID
   On GRP_PID.PAR_PID_ID = ACT_DIGIT.PAR_PID_ID
 Left Outer Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC    Placement_JRC_PID
   On GRP_PID.LNK_PID_ID  = Placement_JRC_PID.PID_ID
  And ACT_DIGIT.ACT_DT    Between (Placement_JRC_PID.INTRCTN_DT) 
                              And (Placement_JRC_PID.INTRCTN_DT + ${P_PIL_626}   )
  -- Recherche Interaction via CUID Drakkar
 Left Outer Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC    Placement_JRC_CUID
   On ACT_DIGIT.PAR_UNIFIED_PARTY_ID  = Placement_JRC_CUID.UNIFIED_PARTY_ID
  And ACT_DIGIT.ACT_DT    Between (Placement_JRC_CUID.INTRCTN_DT) 
                              And (Placement_JRC_CUID.INTRCTN_DT + ${P_PIL_626}   )
Where (1=1)
  And (Placement_JRC_PID.ACTE_ID Is Not Null
       Or 
       Placement_JRC_CUID.ACTE_ID Is Not Null 
      ) 
Qualify Row_Number () Over (Partition By ACT_DIGIT.ACTE_ID Order By PRIO_INTRCTN ASC, Placement_JRC_PID.INTRCTN_TS ASC, Placement_JRC_CUID.INTRCTN_TS ASC) = 1;
.if errorcode <> 0 then .quit 1;

Collect stat on ${KNB_TERADATA_USER}.ORD_V_CROSS_${Source}_JRC Column (ACTE_ID, ACT_DT);
.if errorcode <> 0 then .quit 1;
Collect stat on ${KNB_TERADATA_USER}.ORD_V_CROSS_${Source}_JRC Column (ACTE_ID_INTRCTN, INTRCTN_DT);
.if errorcode <> 0 then .quit 1;

Drop Table ${KNB_TERADATA_USER}.INT_V_GRP_PID_${Source};
.if errorcode <> 0 then .quit 1;


------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
--                                       RAPPROCHEMENT FINAL ACTE H&D / INTERACTION JRC
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------

-----------------------------------
--Cas 2 - Alimentation des lignes à exclure du processus de rapprochement avec JRC (hors lignes issues de l'init) 
-----------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL
(
      CODE_PROCESS                         ,
      INTRNL_SOURCE_ID                     ,
      SOURCE_DS                            ,
      ACT_ACTE_FAMILLE_KPI                 ,
      ACTE_ID                              ,
      ACT_DT                               ,
      PAR_UNIFIED_PARTY_ID                 ,
      PAR_PID_ID                           ,
      PAR_CID_ID                           ,
      IND_HD_TEMPO_CD                      ,
      IND_HD_TEMPO_DT                      ,
      RAP_PID_ID                           ,
      RAP_UNIFIED_PARTY_ID                 ,
      INTRCTN_DT                           ,
      DELAI                                ,
      ACTE_ID_INTRCTN                      ,
      INTRCTN_ID                           ,
      KEYGEN_CD                            ,
      APPLI_SOURCE_ID                      ,
      UNIFIED_PARTY_ID                     ,
      PID_ID                               ,
      CID_ID                               ,
      INT_OPRTR_ID                         ,
      ORG_AGENT_IOBSP                      ,
      OPRTR_TEAM_HIERCH_ID                 ,
      OPRTR_TEAM_ACTVT_ID                  ,
      UNVRS_CD                             ,
      DIRCTN_CD                            ,
      CHANL_CD                             ,
      MEDIA_CD                             ,
      ORIGN_CD                             ,
      WAY_CD                               ,
      REASN_CD                             ,
      REASN_DETL_CD                        ,
      CONCLSN_CD                           ,
      UNIFIED_SHOP_CD                      ,
      ORG_REM_CHANNEL_CD                   ,
      ORG_CHANNEL_CD                       ,
      ORG_SUB_CHANNEL_CD                   ,
      ORG_SUB_SUB_CHANNEL_CD               ,
      ORG_GT_ACTIVITY                      ,
      ORG_FIDELISATION                     ,
      ORG_WEB_ACTIVITY                     ,
      ORG_AUTO_ACTIVITY                    ,
      ORG_EDO_ID                           ,
      ORG_TYPE_EDO                         ,
      ORG_TEAM_LEVEL_1_CD                  ,
      ORG_TEAM_LEVEL_1_DS                  ,
      ORG_TEAM_LEVEL_2_CD                  ,
      ORG_TEAM_LEVEL_2_DS                  ,
      ORG_TEAM_LEVEL_3_CD                  ,
      ORG_TEAM_LEVEL_3_DS                  ,
      ORG_TEAM_LEVEL_4_CD                  ,
      ORG_TEAM_LEVEL_4_DS                  ,
      WORK_TEAM_LEVEL_1_CD                 ,
      WORK_TEAM_LEVEL_1_DS                 ,
      WORK_TEAM_LEVEL_2_CD                 ,
      WORK_TEAM_LEVEL_2_DS                 ,
      WORK_TEAM_LEVEL_3_CD                 ,
      WORK_TEAM_LEVEL_3_DS                 ,
      WORK_TEAM_LEVEL_4_CD                 ,
      WORK_TEAM_LEVEL_4_DS                 ,
      NEW_UNIFIED_SHOP_CD                  ,
      NEW_ORG_REM_CHANNEL_CD               ,
      NEW_ORG_CHANNEL_CD                   ,
      NEW_ORG_SUB_CHANNEL_CD               ,
      NEW_ORG_SUB_SUB_CHANNEL_CD           ,
      NEW_ORG_GT_ACTIVITY                  ,
      NEW_ORG_FIDELISATION                 ,
      NEW_ORG_WEB_ACTIVITY                 ,
      NEW_ORG_AUTO_ACTIVITY                ,
      NEW_ORG_EDO_ID                       ,
      NEW_ORG_EDO_IOBSP                    ,
      NEW_ORG_TYPE_EDO                     ,
      NEW_ORG_TEAM_LEVEL_1_CD              ,
      NEW_ORG_TEAM_LEVEL_1_DS              ,
      NEW_ORG_TEAM_LEVEL_2_CD              ,
      NEW_ORG_TEAM_LEVEL_2_DS              ,
      NEW_ORG_TEAM_LEVEL_3_CD              ,
      NEW_ORG_TEAM_LEVEL_3_DS              ,
      NEW_ORG_TEAM_LEVEL_4_CD              ,
      NEW_ORG_TEAM_LEVEL_4_DS              ,
      NEW_WORK_TEAM_LEVEL_1_CD             ,
      NEW_WORK_TEAM_LEVEL_1_DS             ,
      NEW_WORK_TEAM_LEVEL_2_CD             ,
      NEW_WORK_TEAM_LEVEL_2_DS             ,
      NEW_WORK_TEAM_LEVEL_3_CD             ,
      NEW_WORK_TEAM_LEVEL_3_DS             ,
      NEW_WORK_TEAM_LEVEL_4_CD             ,
      NEW_WORK_TEAM_LEVEL_4_DS             ,
      ANNUL_HD_DT                          ,
      ANNUL_HD_DS                          ,
      IND_HD_CD                            ,
      IND_HD_RAP_CD                        ,
      HD_RAP_DT                            ,
      CREATION_TS                          ,
      LAST_MODIF_TS                        ,
      CLOSURE_DT                           ,
      AUTHOR_CD                            ,
      CURRENT_IN                           ,
      FRESH_IN                             ,
      COHERENCE_IN                          
)
select 

--Champs du Groupe 1 (Alimentation comme défini dans le tableau du mapping )
  ACT_DIGIT.CODE_PROCESS                                                        As CODE_PROCESS                    ,
  ACT_DIGIT.INTRNL_SOURCE_ID                                                    As INTRNL_SOURCE_ID                ,
  ACT_DIGIT.SOURCE_DS                                                           As SOURCE_DS                       ,
  ACT_DIGIT.ACT_ACTE_FAMILLE_KPI                                                As ACT_ACTE_FAMILLE_KPI            ,
  ACT_DIGIT.ACTE_ID                                                             As ACTE_ID                         ,
  ACT_DIGIT.ACT_DT                                                              As ACT_DT                          ,
  ACT_DIGIT.PAR_UNIFIED_PARTY_ID                                                As PAR_UNIFIED_PARTY_ID            ,
  ACT_DIGIT.PAR_PID_ID                                                          As PAR_PID_ID                      ,
  ACT_DIGIT.PAR_CID_ID                                                          As PAR_CID_ID                      ,
  Null                                                                          As IND_HD_TEMPO_CD                 ,
  Null                                                                          As IND_HD_TEMPO_DT                 ,
--Champs du Groupe 2 --seront mis Ã  null (informations liées Ã  l'interaction JRC)
  Null                                                                          As RAP_PID_ID                      ,
  Null                                                                          As RAP_UNIFIED_PARTY_ID            ,
  Null                                                                          As INTRCTN_DT                      ,
  Null                                                                          As DELAI                           ,
  Null                                                                          As ACTE_ID_INTRCTN                 ,
  Null                                                                          As INTRCTN_ID                      ,
  Null                                                                          As KEYGEN_CD                       ,
  Null                                                                          As APPLI_SOURCE_ID                 ,
  Null                                                                          As UNIFIED_PARTY_ID                ,
  Null                                                                          As PID_ID                          ,
  Null                                                                          As CID_ID                          ,
  Null                                                                          As INT_OPRTR_ID                    ,
  Null                                                                          As ORG_AGENT_IOBSP                 ,
  Null                                                                          As OPRTR_TEAM_HIERCH_ID            ,
  Null                                                                          As OPRTR_TEAM_ACTVT_ID             ,
  Null                                                                          As UNVRS_CD                        ,
  Null                                                                          As DIRCTN_CD                       ,
  Null                                                                          As CHANL_CD                        ,
  Null                                                                          As MEDIA_CD                        ,
  Null                                                                          As ORIGN_CD                        ,
  Null                                                                          As WAY_CD                          ,
  Null                                                                          As REASN_CD                        ,
  Null                                                                          As REASN_DETL_CD                   ,
  Null                                                                          As CONCLSN_CD                      ,
--Champs du Groupe 3 ( Alimentation comme défini dans le tableau du mapping )
  ACT_DIGIT.UNIFIED_SHOP_CD                                                     As UNIFIED_SHOP_CD                 ,
  ACT_DIGIT.ORG_REM_CHANNEL_CD                                                  As ORG_REM_CHANNEL_CD              ,
  ACT_DIGIT.ORG_CHANNEL_CD                                                      As ORG_CHANNEL_CD                  ,
  ACT_DIGIT.ORG_SUB_CHANNEL_CD                                                  As ORG_SUB_CHANNEL_CD              ,
  ACT_DIGIT.ORG_SUB_SUB_CHANNEL_CD                                              As ORG_SUB_SUB_CHANNEL_CD          ,
  ACT_DIGIT.ORG_GT_ACTIVITY                                                     As ORG_GT_ACTIVITY                 ,
  ACT_DIGIT.ORG_FIDELISATION                                                    As ORG_FIDELISATION                ,
  ACT_DIGIT.ORG_WEB_ACTIVITY                                                    As ORG_WEB_ACTIVITY                ,
  ACT_DIGIT.ORG_AUTO_ACTIVITY                                                   As ORG_AUTO_ACTIVITY               ,
  ACT_DIGIT.ORG_EDO_ID                                                          As ORG_EDO_ID                      ,
  ACT_DIGIT.ORG_TYPE_EDO                                                        As ORG_TYPE_EDO                    ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_CD                                                 As ORG_TEAM_LEVEL_1_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_DS                                                 As ORG_TEAM_LEVEL_1_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_CD                                                 As ORG_TEAM_LEVEL_2_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_DS                                                 As ORG_TEAM_LEVEL_2_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_CD                                                 As ORG_TEAM_LEVEL_3_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_DS                                                 As ORG_TEAM_LEVEL_3_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_CD                                                 As ORG_TEAM_LEVEL_4_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_DS                                                 As ORG_TEAM_LEVEL_4_DS             ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_CD                                                As WORK_TEAM_LEVEL_1_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_DS                                                As WORK_TEAM_LEVEL_1_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_CD                                                As WORK_TEAM_LEVEL_2_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_DS                                                As WORK_TEAM_LEVEL_2_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_CD                                                As WORK_TEAM_LEVEL_3_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_DS                                                As WORK_TEAM_LEVEL_3_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_CD                                                As WORK_TEAM_LEVEL_4_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_DS                                                As WORK_TEAM_LEVEL_4_DS            ,
--Champs du Groupe 4 --seront mis Ã  null (informations liées à  l'interaction JRC)
  Null                                                                          As NEW_UNIFIED_SHOP_CD             ,
  Null                                                                          As NEW_ORG_REM_CHANNEL_CD          ,
  Null                                                                          As NEW_ORG_CHANNEL_CD              ,
  Null                                                                          As NEW_ORG_SUB_CHANNEL_CD          ,
  Null                                                                          As NEW_ORG_SUB_SUB_CHANNEL_CD      ,
  Null                                                                          As NEW_ORG_GT_ACTIVITY             ,
  Null                                                                          As NEW_ORG_FIDELISATION            ,
  Null                                                                          As NEW_ORG_WEB_ACTIVITY            ,
  Null                                                                          As NEW_ORG_AUTO_ACTIVITY           ,
  Null                                                                          As NEW_ORG_EDO_ID                  ,
  Null                                                                          As NEW_ORG_EDO_IOBSP               ,
  Null                                                                          As NEW_ORG_TYPE_EDO                ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_1_CD         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_1_DS         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_2_CD         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_2_DS         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_3_CD         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_3_DS         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_4_CD         ,
  Null                                                                          As NEW_ORG_TEAM_LEVEL_4_DS         ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_1_CD        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_1_DS        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_2_CD        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_2_DS        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_3_CD        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_3_DS        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_4_CD        ,
  Null                                                                          As NEW_WORK_TEAM_LEVEL_4_DS        ,
--Champs du Groupe 5
  ACT_DIGIT.ANNUL_HD_DT                                                         As ANNUL_HD_DT                      ,
  ACT_DIGIT.ANNUL_HD_DS                                                         As ANNUL_HD_DS                      ,
  Case When ANNUL_HD_DT Is Not Null
    Then -1 -- l'acte n'est plus Online ou DNU
    Else 0 -- sinon l'acte est digital Only        
  End                                                                           As IND_HD_CD                      ,
-- acte hors périmètre « H&D »
  -1                                                                            As IND_HD_RAP_CD                   ,
--pas de rapprochement pour ces actes
  Null                                                                          As HD_RAP_DT                       ,
  Coalesce (ACT_DIGIT.CREATION_TS, Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0)))   As CREATION_TS                     ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                     As LAST_MODIF_TS                   ,
  ACT_DIGIT.CLOSURE_DT                                                          As CLOSURE_DT                      ,
  Null                                                                          As AUTHOR_CD                       ,
  1                                                                             As CURRENT_IN                      ,
  1                                                                             As FRESH_IN                        ,
  1                                                                             As COHERENCE_IN                     


from ${KNB_PCO_TMP}.ORD_W_${Source}_ELIG_JRC_DIGITAL  ACT_DIGIT
Left Outer Join ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM      KPI_HD_PILCOM
  On ACT_DIGIT.ACT_DT                 Between (KPI_HD_PILCOM.PERIODE_DATE_DEB) 
                                      And (KPI_HD_PILCOM.PERIODE_DATE_FIN)
  And ACT_DIGIT.ACT_ACTE_FAMILLE_KPI  = KPI_HD_PILCOM.KPI_HD
where
      (ACT_DIGIT.IND_HD_RAP_CD         <> -2
      Or
       ACT_DIGIT.IND_HD_RAP_CD        Is Null
       )
  And KPI_HD_PILCOM.KPI_HD            Is Null 
  And ACT_DIGIT.ACT_DT                >= Cast('01012020' As Date Format 'DDMMYYYY')
;
.if errorcode <> 0 then .quit 1;
Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL ;
.if errorcode <> 0 then .quit 1; 


-----------------------------------
--Cas 3- Alimentation des lignes non exclues du processus de rapprochement JRC et pour lesquelles le rapprochement JRC n'est pas fige 
-----------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL
(
      CODE_PROCESS                         ,
      INTRNL_SOURCE_ID                     ,
      SOURCE_DS                            ,
      ACT_ACTE_FAMILLE_KPI                 ,
      ACTE_ID                              ,
      ACT_DT                               ,
      PAR_UNIFIED_PARTY_ID                 ,
      PAR_PID_ID                           ,
      PAR_CID_ID                           ,
      IND_HD_TEMPO_CD                      ,
      IND_HD_TEMPO_DT                      ,
      RAP_PID_ID                           ,
      RAP_UNIFIED_PARTY_ID                 ,
      INTRCTN_DT                           ,
      DELAI                                ,
      ACTE_ID_INTRCTN                      ,
      INTRCTN_ID                           ,
      KEYGEN_CD                            ,
      APPLI_SOURCE_ID                      ,
      UNIFIED_PARTY_ID                     ,
      PID_ID                               ,
      CID_ID                               ,
      INT_OPRTR_ID                         ,
      ORG_AGENT_IOBSP                      ,
      OPRTR_TEAM_HIERCH_ID                 ,
      OPRTR_TEAM_ACTVT_ID                  ,
      UNVRS_CD                             ,
      DIRCTN_CD                            ,
      CHANL_CD                             ,
      MEDIA_CD                             ,
      ORIGN_CD                             ,
      WAY_CD                               ,
      REASN_CD                             ,
      REASN_DETL_CD                        ,
      CONCLSN_CD                           ,
      UNIFIED_SHOP_CD                      ,
      ORG_REM_CHANNEL_CD                   ,
      ORG_CHANNEL_CD                       ,
      ORG_SUB_CHANNEL_CD                   ,
      ORG_SUB_SUB_CHANNEL_CD               ,
      ORG_GT_ACTIVITY                      ,
      ORG_FIDELISATION                     ,
      ORG_WEB_ACTIVITY                     ,
      ORG_AUTO_ACTIVITY                    ,
      ORG_EDO_ID                           ,
      ORG_TYPE_EDO                         ,
      ORG_TEAM_LEVEL_1_CD                  ,
      ORG_TEAM_LEVEL_1_DS                  ,
      ORG_TEAM_LEVEL_2_CD                  ,
      ORG_TEAM_LEVEL_2_DS                  ,
      ORG_TEAM_LEVEL_3_CD                  ,
      ORG_TEAM_LEVEL_3_DS                  ,
      ORG_TEAM_LEVEL_4_CD                  ,
      ORG_TEAM_LEVEL_4_DS                  ,
      WORK_TEAM_LEVEL_1_CD                 ,
      WORK_TEAM_LEVEL_1_DS                 ,
      WORK_TEAM_LEVEL_2_CD                 ,
      WORK_TEAM_LEVEL_2_DS                 ,
      WORK_TEAM_LEVEL_3_CD                 ,
      WORK_TEAM_LEVEL_3_DS                 ,
      WORK_TEAM_LEVEL_4_CD                 ,
      WORK_TEAM_LEVEL_4_DS                 ,
      NEW_UNIFIED_SHOP_CD                  ,
      NEW_ORG_REM_CHANNEL_CD               ,
      NEW_ORG_CHANNEL_CD                   ,
      NEW_ORG_SUB_CHANNEL_CD               ,
      NEW_ORG_SUB_SUB_CHANNEL_CD           ,
      NEW_ORG_GT_ACTIVITY                  ,
      NEW_ORG_FIDELISATION                 ,
      NEW_ORG_WEB_ACTIVITY                 ,
      NEW_ORG_AUTO_ACTIVITY                ,
      NEW_ORG_EDO_ID                       ,
      NEW_ORG_EDO_IOBSP                    ,
      NEW_ORG_TYPE_EDO                     ,
      NEW_ORG_TEAM_LEVEL_1_CD              ,
      NEW_ORG_TEAM_LEVEL_1_DS              ,
      NEW_ORG_TEAM_LEVEL_2_CD              ,
      NEW_ORG_TEAM_LEVEL_2_DS              ,
      NEW_ORG_TEAM_LEVEL_3_CD              ,
      NEW_ORG_TEAM_LEVEL_3_DS              ,
      NEW_ORG_TEAM_LEVEL_4_CD              ,
      NEW_ORG_TEAM_LEVEL_4_DS              ,
      NEW_WORK_TEAM_LEVEL_1_CD             ,
      NEW_WORK_TEAM_LEVEL_1_DS             ,
      NEW_WORK_TEAM_LEVEL_2_CD             ,
      NEW_WORK_TEAM_LEVEL_2_DS             ,
      NEW_WORK_TEAM_LEVEL_3_CD             ,
      NEW_WORK_TEAM_LEVEL_3_DS             ,
      NEW_WORK_TEAM_LEVEL_4_CD             ,
      NEW_WORK_TEAM_LEVEL_4_DS             ,
      ANNUL_HD_DT                          ,
      ANNUL_HD_DS                          ,
      IND_HD_CD                            ,
      IND_HD_RAP_CD                        ,
      HD_RAP_DT                            ,
      CREATION_TS                          ,
      LAST_MODIF_TS                        ,
      CLOSURE_DT                           ,
      AUTHOR_CD                            ,
      CURRENT_IN                           ,
      FRESH_IN                             ,
      COHERENCE_IN                          
)
select 

--Champs du Groupe 1 (alimentes comme defini dans le tableau de mapping )
  ACT_DIGIT.CODE_PROCESS                                                        As CODE_PROCESS                   ,
  ACT_DIGIT.INTRNL_SOURCE_ID                                                    As INTRNL_SOURCE_ID               ,
  ACT_DIGIT.SOURCE_DS                                                           As SOURCE_DS                      ,
  ACT_DIGIT.ACT_ACTE_FAMILLE_KPI                                                As ACT_ACTE_FAMILLE_KPI           ,
  ACT_DIGIT.ACTE_ID                                                             As ACTE_ID                        ,
  ACT_DIGIT.ACT_DT                                                              As ACT_DT                         ,
  ACT_DIGIT.PAR_UNIFIED_PARTY_ID                                                As PAR_UNIFIED_PARTY_ID           ,
  ACT_DIGIT.PAR_PID_ID                                                          As PAR_PID_ID                     ,
  ACT_DIGIT.PAR_CID_ID                                                          As PAR_CID_ID                     ,
  0                                                                             As IND_HD_TEMPO_CD                ,
  Null                                                                          As IND_HD_TEMPO_DT                ,
--champs du Groupe 2
  Case When HD_RAP_DT_AGR Is Not Null 
    Then ACT_DIGIT.PAR_PID_ID
    Else Null  
  End                                                                           As RAP_PID_ID                     ,
  Case When HD_RAP_DT_AGR Is Not Null 
    Then ACT_DIGIT.PAR_UNIFIED_PARTY_ID 
    Else Null  
  End                                                                           As RAP_UNIFIED_PARTY_ID           ,
  Placement_JRC_NOUVEAU.INTRCTN_DT                                              As INTRCTN_DT                     ,
  Case When HD_RAP_DT_AGR Is Not Null 
    Then ACT_DIGIT.ACT_DT - Placement_JRC_NOUVEAU.INTRCTN_DT 
    Else Null  
  End                                                                           As DELAI                          ,
  Placement_JRC_NOUVEAU.ACTE_ID                                                 As ACTE_ID_INTRCTN                ,
  Placement_JRC_NOUVEAU.INTRCTN_ID                                              As INTRCTN_ID                     ,
  Placement_JRC_NOUVEAU.KEYGEN_CD                                               As KEYGEN_CD                      ,
  Placement_JRC_NOUVEAU.APPLI_SOURCE_ID                                         As APPLI_SOURCE_ID                ,
  Placement_JRC_NOUVEAU.UNIFIED_PARTY_ID                                        As UNIFIED_PARTY_ID               ,
  Placement_JRC_NOUVEAU.PID_ID                                                  As PID_ID                         ,
  Placement_JRC_NOUVEAU.CID_ID                                                  As CID_ID                         ,
  Placement_JRC_NOUVEAU.INT_OPRTR_ID                                            As INT_OPRTR_ID                   ,
  Placement_JRC_NOUVEAU.ORG_AGENT_IOBSP                                         As ORG_AGENT_IOBSP                ,
  Placement_JRC_NOUVEAU.OPRTR_TEAM_HIERCH_ID                                    As OPRTR_TEAM_HIERCH_ID           ,
  Placement_JRC_NOUVEAU.OPRTR_TEAM_ACTVT_ID                                     As OPRTR_TEAM_ACTVT_ID            ,
  Placement_JRC_NOUVEAU.UNVRS_CD                                                As UNVRS_CD                       ,
  Placement_JRC_NOUVEAU.DIRCTN_CD                                               As DIRCTN_CD                      ,
  Placement_JRC_NOUVEAU.CHANL_CD                                                As CHANL_CD                       ,
  Placement_JRC_NOUVEAU.MEDIA_CD                                                As MEDIA_CD                       ,
  Placement_JRC_NOUVEAU.ORIGN_CD                                                As ORIGN_CD                       ,
  Placement_JRC_NOUVEAU.WAY_CD                                                  As WAY_CD                         ,
  Placement_JRC_NOUVEAU.REASN_CD                                                As REASN_CD                       ,
  Placement_JRC_NOUVEAU.REASN_DETL_CD                                           As REASN_DETL_CD                  ,
  Placement_JRC_NOUVEAU.CONCLSN_CD                                              As CONCLSN_CD                     ,
--Champs du Groupe 3 (alimentation comme défini dans le tableau de mapping) 
  ACT_DIGIT.UNIFIED_SHOP_CD                                                     As UNIFIED_SHOP_CD                ,
  ACT_DIGIT.ORG_REM_CHANNEL_CD                                                  As ORG_REM_CHANNEL_CD             ,
  ACT_DIGIT.ORG_CHANNEL_CD                                                      As ORG_CHANNEL_CD                 ,
  ACT_DIGIT.ORG_SUB_CHANNEL_CD                                                  As ORG_SUB_CHANNEL_CD             ,
  ACT_DIGIT.ORG_SUB_SUB_CHANNEL_CD                                              As ORG_SUB_SUB_CHANNEL_CD         ,
  ACT_DIGIT.ORG_GT_ACTIVITY                                                     As ORG_GT_ACTIVITY                ,
  ACT_DIGIT.ORG_FIDELISATION                                                    As ORG_FIDELISATION               ,
  ACT_DIGIT.ORG_WEB_ACTIVITY                                                    As ORG_WEB_ACTIVITY               ,
  ACT_DIGIT.ORG_AUTO_ACTIVITY                                                   As ORG_AUTO_ACTIVITY              ,
  ACT_DIGIT.ORG_EDO_ID                                                          As ORG_EDO_ID                     ,
  ACT_DIGIT.ORG_TYPE_EDO                                                        As ORG_TYPE_EDO                   ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_CD                                                 As ORG_TEAM_LEVEL_1_CD            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_DS                                                 As ORG_TEAM_LEVEL_1_DS            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_CD                                                 As ORG_TEAM_LEVEL_2_CD            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_DS                                                 As ORG_TEAM_LEVEL_2_DS            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_CD                                                 As ORG_TEAM_LEVEL_3_CD            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_DS                                                 As ORG_TEAM_LEVEL_3_DS            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_CD                                                 As ORG_TEAM_LEVEL_4_CD            ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_DS                                                 As ORG_TEAM_LEVEL_4_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_CD                                                As WORK_TEAM_LEVEL_1_CD           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_DS                                                As WORK_TEAM_LEVEL_1_DS           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_CD                                                As WORK_TEAM_LEVEL_2_CD           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_DS                                                As WORK_TEAM_LEVEL_2_DS           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_CD                                                As WORK_TEAM_LEVEL_3_CD           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_DS                                                As WORK_TEAM_LEVEL_3_DS           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_CD                                                As WORK_TEAM_LEVEL_4_CD           ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_DS                                                As WORK_TEAM_LEVEL_4_DS           ,
--Champs du Groupe 4
  Placement_JRC_NOUVEAU.UNIFIED_SHOP_CD                                         As NEW_UNIFIED_SHOP_CD            ,
  Placement_JRC_NOUVEAU.ORG_REM_CHANNEL_CD                                      As NEW_ORG_REM_CHANNEL_CD         ,
  Placement_JRC_NOUVEAU.ORG_CHANNEL_CD                                          As NEW_ORG_CHANNEL_CD             ,
  Placement_JRC_NOUVEAU.ORG_SUB_CHANNEL_CD                                      As NEW_ORG_SUB_CHANNEL_CD         ,
  Placement_JRC_NOUVEAU.ORG_SUB_SUB_CHANNEL_CD                                  As NEW_ORG_SUB_SUB_CHANNEL_CD     ,
  Placement_JRC_NOUVEAU.ORG_GT_ACTIVITY                                         As NEW_ORG_GT_ACTIVITY            ,
  Placement_JRC_NOUVEAU.ORG_FIDELISATION                                        As NEW_ORG_FIDELISATION           ,
  Placement_JRC_NOUVEAU.ORG_WEB_ACTIVITY                                        As NEW_ORG_WEB_ACTIVITY           ,
  Placement_JRC_NOUVEAU.ORG_AUTO_ACTIVITY                                       As NEW_ORG_AUTO_ACTIVITY          ,
  Placement_JRC_NOUVEAU.ORG_EDO_ID                                              As NEW_ORG_EDO_ID                 ,
  Placement_JRC_NOUVEAU.ORG_EDO_IOBSP                                           As NEW_ORG_EDO_IOBSP              ,
  Placement_JRC_NOUVEAU.ORG_TEAM_TYPE_ID                                        As NEW_ORG_TYPE_EDO               ,
  Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_1_CD As Varchar(18)))         As NEW_ORG_TEAM_LEVEL_1_CD        ,
  Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_1_DS                                     As NEW_ORG_TEAM_LEVEL_1_DS        ,
  Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_2_CD As Varchar(18)))         As NEW_ORG_TEAM_LEVEL_2_CD        ,
  Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_2_DS                                     As NEW_ORG_TEAM_LEVEL_2_DS        ,
  Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_3_CD As Varchar(18)))         As NEW_ORG_TEAM_LEVEL_3_CD        ,
  Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_3_DS                                     As NEW_ORG_TEAM_LEVEL_3_DS        ,
  Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_4_CD As Varchar(18)))         As NEW_ORG_TEAM_LEVEL_4_CD        ,
  Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_4_DS                                     As NEW_ORG_TEAM_LEVEL_4_DS        ,
  Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_1_CD As Varchar(18)))        As NEW_WORK_TEAM_LEVEL_1_CD       ,
  Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_1_DS                                    As NEW_WORK_TEAM_LEVEL_1_DS       ,
  Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_2_CD As Varchar(18)))        As NEW_WORK_TEAM_LEVEL_2_CD       ,
  Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_2_DS                                    As NEW_WORK_TEAM_LEVEL_2_DS       ,
  Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_3_CD As Varchar(18)))        As NEW_WORK_TEAM_LEVEL_3_CD       ,
  Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_3_DS                                    As NEW_WORK_TEAM_LEVEL_3_DS       ,
  Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_4_CD As Varchar(18)))        As NEW_WORK_TEAM_LEVEL_4_CD       ,
  Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_4_DS                                    As NEW_WORK_TEAM_LEVEL_4_DS       ,
-- Champs du Groupe 5
  ACT_DIGIT.ANNUL_HD_DT                                                         As ANNUL_HD_DT                    ,
  ACT_DIGIT.ANNUL_HD_DS                                                         As ANNUL_HD_DS                    ,
  Case When HD_RAP_DT_AGR is not null  
    Then 1 -- l'acte est Humain et Digital »
    When ANNUL_HD_DT Is Not Null
    Then -1 -- l'acte n'est plus Online ou DNU
    Else 0 -- sinon l'acte est digital Only        
  End                                                                           As IND_HD_CD                      ,
                   
                    
                       
  0                                                                             As IND_HD_RAP_CD                  ,
  Case When Placement_JRC_NOUVEAU.INTRCTN_ID Is Not Null
    Then Coalesce (ACT_DIGIT.HD_RAP_DT, Current_date)
    Else Null
  End                                                                           As HD_RAP_DT_AGR                  ,
  Coalesce (ACT_DIGIT.CREATION_TS, Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0)))   As CREATION_TS                    ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                     As LAST_MODIF_TS                  ,
  ACT_DIGIT.CLOSURE_DT                                                          As CLOSURE_DT                     ,
  Null                                                                          As AUTHOR_CD                      ,
  1                                                                             As CURRENT_IN                     ,
  1                                                                             As FRESH_IN                       ,
  1                                                                             As COHERENCE_IN                    



from ${KNB_PCO_TMP}.ORD_W_${Source}_ELIG_JRC_DIGITAL    ACT_DIGIT
Inner Join ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM            KPI_HD_PILCOM
  On  ACT_DIGIT.ACT_DT                Between (KPI_HD_PILCOM.PERIODE_DATE_DEB) 
                                      And (KPI_HD_PILCOM.PERIODE_DATE_FIN)
  And ACT_DIGIT.ACT_ACTE_FAMILLE_KPI  =    KPI_HD_PILCOM.KPI_HD
Left Outer Join ${KNB_TERADATA_USER}.ORD_V_CROSS_${Source}_JRC Cross_JRC
  On Cross_JRC.ACTE_ID = ACT_DIGIT.ACTE_ID
 And Cross_JRC.ACT_DT  = ACT_DIGIT.ACT_DT
Left Outer Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC    Placement_JRC_NOUVEAU
  On  Cross_JRC.ACTE_ID_INTRCTN  = Placement_JRC_NOUVEAU.ACTE_ID
 And  Cross_JRC.INTRCTN_DT       = Placement_JRC_NOUVEAU.INTRCTN_DT
Where
-- des actes ne sont pas issues des cas 1 et cas 2 ou sont Null
      (ACT_DIGIT.IND_HD_RAP_CD        <> -2
      Or
       ACT_DIGIT.IND_HD_RAP_CD        Is Null
       )
  
  And ACT_DIGIT.ACT_DT + 10  > Current_date 
  And ACT_DIGIT.ACT_DT                 >= Cast('01012020' As Date Format 'DDMMYYYY')
Qualify Row_Number () Over (Partition By ACT_DIGIT.ACTE_ID Order By Placement_JRC_NOUVEAU.INTRCTN_TS) = 1;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL ;
.if errorcode <> 0 then .quit 1; 

-----------------------------------
--Cas 4- Alimentation des lignes pour lesquelles le rapprochement avec JRC a été traité
-----------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL 
(
      CODE_PROCESS                         ,
      INTRNL_SOURCE_ID                     ,
      SOURCE_DS                            ,
      ACT_ACTE_FAMILLE_KPI                 ,
      ACTE_ID                              ,
      ACT_DT                               ,
      PAR_UNIFIED_PARTY_ID                 ,
      PAR_PID_ID                           ,
      PAR_CID_ID                           ,
      IND_HD_TEMPO_CD                      ,
      IND_HD_TEMPO_DT                      ,
      RAP_PID_ID                           ,
      RAP_UNIFIED_PARTY_ID                 ,
      INTRCTN_DT                           ,
      DELAI                                ,
      ACTE_ID_INTRCTN                      ,
      INTRCTN_ID                           ,
      KEYGEN_CD                            ,
      APPLI_SOURCE_ID                      ,
      UNIFIED_PARTY_ID                     ,
      PID_ID                               ,
      CID_ID                               ,
      INT_OPRTR_ID                         ,
      ORG_AGENT_IOBSP                      ,
      OPRTR_TEAM_HIERCH_ID                 ,
      OPRTR_TEAM_ACTVT_ID                  ,
      UNVRS_CD                             ,
      DIRCTN_CD                            ,
      CHANL_CD                             ,
      MEDIA_CD                             ,
      ORIGN_CD                             ,
      WAY_CD                               ,
      REASN_CD                             ,
      REASN_DETL_CD                        ,
      CONCLSN_CD                           ,
      UNIFIED_SHOP_CD                      ,
      ORG_REM_CHANNEL_CD                   ,
      ORG_CHANNEL_CD                       ,
      ORG_SUB_CHANNEL_CD                   ,
      ORG_SUB_SUB_CHANNEL_CD               ,
      ORG_GT_ACTIVITY                      ,
      ORG_FIDELISATION                     ,
      ORG_WEB_ACTIVITY                     ,
      ORG_AUTO_ACTIVITY                    ,
      ORG_EDO_ID                           ,
      ORG_TYPE_EDO                         ,
      ORG_TEAM_LEVEL_1_CD                  ,
      ORG_TEAM_LEVEL_1_DS                  ,
      ORG_TEAM_LEVEL_2_CD                  ,
      ORG_TEAM_LEVEL_2_DS                  ,
      ORG_TEAM_LEVEL_3_CD                  ,
      ORG_TEAM_LEVEL_3_DS                  ,
      ORG_TEAM_LEVEL_4_CD                  ,
      ORG_TEAM_LEVEL_4_DS                  ,
      WORK_TEAM_LEVEL_1_CD                 ,
      WORK_TEAM_LEVEL_1_DS                 ,
      WORK_TEAM_LEVEL_2_CD                 ,
      WORK_TEAM_LEVEL_2_DS                 ,
      WORK_TEAM_LEVEL_3_CD                 ,
      WORK_TEAM_LEVEL_3_DS                 ,
      WORK_TEAM_LEVEL_4_CD                 ,
      WORK_TEAM_LEVEL_4_DS                 ,
      NEW_UNIFIED_SHOP_CD                  ,
      NEW_ORG_REM_CHANNEL_CD               ,
      NEW_ORG_CHANNEL_CD                   ,
      NEW_ORG_SUB_CHANNEL_CD               ,
      NEW_ORG_SUB_SUB_CHANNEL_CD           ,
      NEW_ORG_GT_ACTIVITY                  ,
      NEW_ORG_FIDELISATION                 ,
      NEW_ORG_WEB_ACTIVITY                 ,
      NEW_ORG_AUTO_ACTIVITY                ,
      NEW_ORG_EDO_ID                       ,
      NEW_ORG_EDO_IOBSP                    ,
      NEW_ORG_TYPE_EDO                     ,
      NEW_ORG_TEAM_LEVEL_1_CD              ,
      NEW_ORG_TEAM_LEVEL_1_DS              ,
      NEW_ORG_TEAM_LEVEL_2_CD              ,
      NEW_ORG_TEAM_LEVEL_2_DS              ,
      NEW_ORG_TEAM_LEVEL_3_CD              ,
      NEW_ORG_TEAM_LEVEL_3_DS              ,
      NEW_ORG_TEAM_LEVEL_4_CD              ,
      NEW_ORG_TEAM_LEVEL_4_DS              ,
      NEW_WORK_TEAM_LEVEL_1_CD             ,
      NEW_WORK_TEAM_LEVEL_1_DS             ,
      NEW_WORK_TEAM_LEVEL_2_CD             ,
      NEW_WORK_TEAM_LEVEL_2_DS             ,
      NEW_WORK_TEAM_LEVEL_3_CD             ,
      NEW_WORK_TEAM_LEVEL_3_DS             ,
      NEW_WORK_TEAM_LEVEL_4_CD             ,
      NEW_WORK_TEAM_LEVEL_4_DS             ,
      ANNUL_HD_DT                          ,
      ANNUL_HD_DS                          ,
      IND_HD_CD                            ,
      IND_HD_RAP_CD                        ,
      HD_RAP_DT                            ,
      CREATION_TS                          ,
      LAST_MODIF_TS                        ,
      CLOSURE_DT                           ,
      AUTHOR_CD                            ,
      CURRENT_IN                           ,
      FRESH_IN                             ,
      COHERENCE_IN                          
)
select 

--Champs du Groupe 1 (alimentÃ©s comme défini dans le tableau de mapping )
  ACT_DIGIT.CODE_PROCESS                                                        As CODE_PROCESS                   ,
  ACT_DIGIT.INTRNL_SOURCE_ID                                                    As INTRNL_SOURCE_ID               ,
  ACT_DIGIT.SOURCE_DS                                                           As SOURCE_DS                      ,
  ACT_DIGIT.ACT_ACTE_FAMILLE_KPI                                                As ACT_ACTE_FAMILLE_KPI           ,
  ACT_DIGIT.ACTE_ID                                                             As ACTE_ID                        ,
  ACT_DIGIT.ACT_DT                                                              As ACT_DT                         ,
  ACT_DIGIT.PAR_UNIFIED_PARTY_ID                                                As PAR_UNIFIED_PARTY_ID           ,
  ACT_DIGIT.PAR_PID_ID                                                          As PAR_PID_ID                     ,
  ACT_DIGIT.PAR_CID_ID                                                          As PAR_CID_ID                     ,
  1                                                                             As IND_HD_TEMPO_CD                ,
  Coalesce (ACT_DIGIT.IND_HD_TEMPO_DT, current_date)                            As IND_HD_TEMPO_DT                ,
--champs du Groupe 2
  Case When HD_RAP_DT_AGR = current_date 
    Then ACT_DIGIT.PAR_PID_ID 
    Else ACT_DIGIT.RAP_PID_ID  
  End                                                                           As RAP_PID_ID                     ,
  Case When HD_RAP_DT_AGR = current_date 
    Then ACT_DIGIT.PAR_UNIFIED_PARTY_ID 
    Else ACT_DIGIT.RAP_UNIFIED_PARTY_ID  
  End                                                                           As RAP_UNIFIED_PARTY_ID           ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.INTRCTN_DT 
    Else ACT_DIGIT.INTRCTN_DT  
  End                                                                           As INTRCTN_DT                     ,
  Case When HD_RAP_DT_AGR = current_date 
    Then ACT_DIGIT.ACT_DT - Placement_JRC_NOUVEAU.INTRCTN_DT 
    Else ACT_DIGIT.DELAI  
  End                                                                           As DELAI                          ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ACTE_ID 
    Else ACT_DIGIT.ACTE_ID_INTRCTN 
  End                                                                           As ACTE_ID_INTRCTN                ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.INTRCTN_ID 
    Else ACT_DIGIT.INTRCTN_ID 
  End                                                                           As INTRCTN_ID                     ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.KEYGEN_CD 
    Else ACT_DIGIT.KEYGEN_CD 
  End                                                                           As KEYGEN_CD                      ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.APPLI_SOURCE_ID 
    Else ACT_DIGIT.APPLI_SOURCE_ID 
  End                                                                           As APPLI_SOURCE_ID                ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.UNIFIED_PARTY_ID 
    Else ACT_DIGIT.UNIFIED_PARTY_ID 
  End                                                                           As UNIFIED_PARTY_ID               ,
  Case When HD_RAP_DT_AGR = current_date 
    Then  Placement_JRC_NOUVEAU.PID_ID 
    Else ACT_DIGIT.PID_ID 
  End                                                                           As PID_ID                         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.CID_ID 
    Else ACT_DIGIT.CID_ID 
  End                                                                           As CID_ID                        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.INT_OPRTR_ID 
    Else ACT_DIGIT.INT_OPRTR_ID 
  End                                                                           As INT_OPRTR_ID                  ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_AGENT_IOBSP 
    Else ACT_DIGIT.ORG_AGENT_IOBSP 
  End                                                                           As ORG_AGENT_IOBSP               ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.OPRTR_TEAM_HIERCH_ID 
    Else ACT_DIGIT.OPRTR_TEAM_HIERCH_ID 
  End                                                                           As OPRTR_TEAM_HIERCH_ID           ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.OPRTR_TEAM_ACTVT_ID 
    Else ACT_DIGIT.OPRTR_TEAM_ACTVT_ID 
  End                                                                           As OPRTR_TEAM_ACTVT_ID            ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.UNVRS_CD 
    Else ACT_DIGIT.UNVRS_CD 
  End                                                                           As UNVRS_CD                       ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.DIRCTN_CD 
    Else ACT_DIGIT.DIRCTN_CD 
  End                                                                           As DIRCTN_CD                      ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.CHANL_CD 
    Else ACT_DIGIT.CHANL_CD 
  End                                                                           As CHANL_CD                        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.MEDIA_CD 
    Else ACT_DIGIT.MEDIA_CD 
  End                                                                           As MEDIA_CD                        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORIGN_CD 
    Else ACT_DIGIT.ORIGN_CD 
  End                                                                           As ORIGN_CD                        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.WAY_CD 
    Else ACT_DIGIT.WAY_CD 
  End                                                                           As WAY_CD                          ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.REASN_CD 
    Else ACT_DIGIT.REASN_CD 
  End                                                                           As REASN_CD                        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.REASN_DETL_CD 
    Else ACT_DIGIT.REASN_DETL_CD 
  End                                                                           As REASN_DETL_CD                   ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.CONCLSN_CD 
    Else ACT_DIGIT.CONCLSN_CD 
  End                                                                           As CONCLSN_CD                      ,
--Champs du Groupe 3 (alimentation comme défini dans le tableau de mapping) 
  ACT_DIGIT.UNIFIED_SHOP_CD                                                     As UNIFIED_SHOP_CD                 ,
  ACT_DIGIT.ORG_REM_CHANNEL_CD                                                  As ORG_REM_CHANNEL_CD              ,
  ACT_DIGIT.ORG_CHANNEL_CD                                                      As ORG_CHANNEL_CD                  ,
  ACT_DIGIT.ORG_SUB_CHANNEL_CD                                                  As ORG_SUB_CHANNEL_CD              ,
  ACT_DIGIT.ORG_SUB_SUB_CHANNEL_CD                                              As ORG_SUB_SUB_CHANNEL_CD          ,
  ACT_DIGIT.ORG_GT_ACTIVITY                                                     As ORG_GT_ACTIVITY                 ,
  ACT_DIGIT.ORG_FIDELISATION                                                    As ORG_FIDELISATION                ,
  ACT_DIGIT.ORG_WEB_ACTIVITY                                                    As ORG_WEB_ACTIVITY                ,
  ACT_DIGIT.ORG_AUTO_ACTIVITY                                                   As ORG_AUTO_ACTIVITY               ,
  ACT_DIGIT.ORG_EDO_ID                                                          As ORG_EDO_ID                      ,
  ACT_DIGIT.ORG_TYPE_EDO                                                        As ORG_TYPE_EDO                    ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_CD                                                 As ORG_TEAM_LEVEL_1_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_DS                                                 As ORG_TEAM_LEVEL_1_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_CD                                                 As ORG_TEAM_LEVEL_2_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_DS                                                 As ORG_TEAM_LEVEL_2_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_CD                                                 As ORG_TEAM_LEVEL_3_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_DS                                                 As ORG_TEAM_LEVEL_3_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_CD                                                 As ORG_TEAM_LEVEL_4_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_DS                                                 As ORG_TEAM_LEVEL_4_DS             ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_CD                                                As WORK_TEAM_LEVEL_1_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_DS                                                As WORK_TEAM_LEVEL_1_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_CD                                                As WORK_TEAM_LEVEL_2_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_DS                                                As WORK_TEAM_LEVEL_2_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_CD                                                As WORK_TEAM_LEVEL_3_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_DS                                                As WORK_TEAM_LEVEL_3_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_CD                                                As WORK_TEAM_LEVEL_4_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_DS                                                As WORK_TEAM_LEVEL_4_DS            ,
--Champs du Groupe 4
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.UNIFIED_SHOP_CD
    Else Placement_JRC_ANCIEN.UNIFIED_SHOP_CD
  End                                                                           As NEW_UNIFIED_SHOP_CD             ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_REM_CHANNEL_CD
    Else Placement_JRC_ANCIEN.ORG_REM_CHANNEL_CD
  End                                                                           As NEW_ORG_REM_CHANNEL_CD          ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_CHANNEL_CD         
    Else Placement_JRC_ANCIEN.ORG_CHANNEL_CD 
  End                                                                           As NEW_ORG_CHANNEL_CD              ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_SUB_CHANNEL_CD     
    Else Placement_JRC_ANCIEN.ORG_SUB_CHANNEL_CD 
  End                                                                           As NEW_ORG_SUB_CHANNEL_CD          ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_SUB_SUB_CHANNEL_CD 
    Else Placement_JRC_ANCIEN.ORG_SUB_SUB_CHANNEL_CD 
  End                                                                           As NEW_ORG_SUB_SUB_CHANNEL_CD      ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_GT_ACTIVITY        
    Else Placement_JRC_ANCIEN.ORG_GT_ACTIVITY 
  End                                                                           As NEW_ORG_GT_ACTIVITY             ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_FIDELISATION      
    Else Placement_JRC_ANCIEN.ORG_FIDELISATION 
  End                                                                           As NEW_ORG_FIDELISATION            ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_WEB_ACTIVITY      
    Else Placement_JRC_ANCIEN.ORG_WEB_ACTIVITY 
  End                                                                           As NEW_ORG_WEB_ACTIVITY            ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_AUTO_ACTIVITY    
    Else Placement_JRC_ANCIEN.ORG_AUTO_ACTIVITY 
  End                                                                           As NEW_ORG_AUTO_ACTIVITY           ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_EDO_ID 
    Else Placement_JRC_ANCIEN.ORG_EDO_ID 
  End                                                                           As NEW_ORG_EDO_ID                  ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_EDO_IOBSP 
    Else Placement_JRC_ANCIEN.ORG_EDO_IOBSP 
  End                                                                           As NEW_ORG_EDO_IOBSP               ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_TEAM_TYPE_ID 
    Else Placement_JRC_ANCIEN.ORG_TEAM_TYPE_ID 
  End                                                                           As NEW_ORG_TYPE_EDO                ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_1_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_1_CD As Varchar(18)))
  End                                                                           As NEW_ORG_TEAM_LEVEL_1_CD         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_1_DS 
    Else Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_1_DS 
  End                                                                           As NEW_ORG_TEAM_LEVEL_1_DS         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_2_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_2_CD As Varchar(18)))
  End                                                                           As NEW_ORG_TEAM_LEVEL_2_CD         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_2_DS 
    Else Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_2_DS 
  End                                                                           As NEW_ORG_TEAM_LEVEL_2_DS         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_3_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_3_CD As Varchar(18)))
  End                                                                           As NEW_ORG_TEAM_LEVEL_3_CD         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_3_DS 
    Else Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_3_DS 
  End                                                                           As NEW_ORG_TEAM_LEVEL_3_DS         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_4_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_4_CD As Varchar(18)))
  End                                                                           As NEW_ORG_TEAM_LEVEL_4_CD         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.ORG_TEAM_LEVEL_4_DS 
    Else Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_4_DS 
  End                                                                           As NEW_ORG_TEAM_LEVEL_4_DS         ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_1_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_1_CD As Varchar(18)))
  End                                                                           As NEW_WORK_TEAM_LEVEL_1_CD        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_1_DS 
    Else Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_1_DS 
  End                                                                           As NEW_WORK_TEAM_LEVEL_1_DS        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_2_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_2_CD As Varchar(18)))
  End                                                                           As NEW_WORK_TEAM_LEVEL_2_CD        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_2_DS 
    Else Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_2_DS 
  End                                                                           As NEW_WORK_TEAM_LEVEL_2_DS        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_3_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_3_CD As Varchar(18)))
  End                                                                           As NEW_WORK_TEAM_LEVEL_3_CD        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_3_DS 
    Else Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_3_DS 
  End                                                                           As NEW_WORK_TEAM_LEVEL_3_DS        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Trim (Cast(Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_4_CD As Varchar(18)))
    Else Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_4_CD As Varchar(18)))
  End                                                                           As NEW_WORK_TEAM_LEVEL_4_CD        ,
  Case When HD_RAP_DT_AGR = current_date 
    Then Placement_JRC_NOUVEAU.WORK_TEAM_LEVEL_4_DS 
    Else Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_4_DS 
  End                                                                           As NEW_WORK_TEAM_LEVEL_4_DS        ,
-- Champs du Groupe 5
  ACT_DIGIT.ANNUL_HD_DT                                                         As ANNUL_HD_DT                     ,
  ACT_DIGIT.ANNUL_HD_DS                                                         As ANNUL_HD_DS                     ,
  Case When HD_RAP_DT_AGR is not null  
    Then 1 -- l'acte est Humain et Digital »
    When ANNUL_HD_DT Is Not Null
    Then -1 -- l'acte n'est plus Online ou DNU
    Else 0 -- sinon l'acte est digital Only        
  End                                                                           As IND_HD_CD                       ,
  Case When Placement_JRC_NOUVEAU.INTRCTN_ID Is Not Null 
    Or    
            Placement_JRC_ANCIEN.INTRCTN_ID Is Not Null
    Then 1
    Else 0
  End                                                                           As IND_HD_RAP_CD                   ,
  
  Case When ACT_DIGIT.HD_RAP_DT Is Null  And Placement_JRC_NOUVEAU.INTRCTN_ID Is Not Null
    Then Current_date
    Else ACT_DIGIT.HD_RAP_DT
  End                                                                           As HD_RAP_DT_AGR                   ,
  Coalesce (ACT_DIGIT.CREATION_TS, Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0)))   As CREATION_TS                     ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                     As LAST_MODIF_TS                   ,
  ACT_DIGIT.CLOSURE_DT                                                          As CLOSURE_DT                      ,
  Null                                                                          As AUTHOR_CD                       ,
  1                                                                             As CURRENT_IN                      ,
  1                                                                             As FRESH_IN                        ,
  1                                                                             As COHERENCE_IN                    

From ${KNB_PCO_TMP}.ORD_W_${Source}_ELIG_JRC_DIGITAL      ACT_DIGIT         
Inner Join ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM               KPI_HD_PILCOM
  On  ACT_DIGIT.ACT_DT                Between (KPI_HD_PILCOM.PERIODE_DATE_DEB) 
                                      And (KPI_HD_PILCOM.PERIODE_DATE_FIN)
  And ACT_DIGIT.ACT_ACTE_FAMILLE_KPI  =    KPI_HD_PILCOM.KPI_HD
Left Outer Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC      Placement_JRC_ANCIEN    
  On  ACT_DIGIT.ACTE_ID_INTRCTN       = Placement_JRC_ANCIEN.ACTE_ID         
  And ACT_DIGIT.INTRCTN_DT            = Placement_JRC_ANCIEN.INTRCTN_DT      
Left Outer Join ${KNB_TERADATA_USER}.ORD_V_CROSS_${Source}_JRC Cross_JRC
  On Cross_JRC.ACTE_ID = ACT_DIGIT.ACTE_ID
 And Cross_JRC.ACT_DT  = ACT_DIGIT.ACT_DT
Left Outer Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC    Placement_JRC_NOUVEAU
  On  Cross_JRC.ACTE_ID_INTRCTN  = Placement_JRC_NOUVEAU.ACTE_ID
 And  Cross_JRC.INTRCTN_DT       = Placement_JRC_NOUVEAU.INTRCTN_DT
Where  
  ((ACT_DIGIT.ACT_DT + 10     =     Current_date and ACT_DIGIT.IND_HD_RAP_CD        <> -2)
  Or 
  (ACT_DIGIT.ACT_DT + 10     <=     Current_date and ACT_DIGIT.IND_HD_RAP_CD        Is Null))
  And ACT_DIGIT.ACT_DT                >= Cast('01012020' As Date Format 'DDMMYYYY')
Qualify Row_Number () Over (Partition By ACT_DIGIT.ACTE_ID Order By Coalesce (Placement_JRC_NOUVEAU.INTRCTN_TS, Placement_JRC_ANCIEN.INTRCTN_TS)) = 1;
.if errorcode <> 0 then .quit 1;                                


Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL ;
.if errorcode <> 0 then .quit 1; 



-----------------------------------
--Cas 5- Mise à jour des champs non figés pour les actes qui sont déjà figés
-----------------------------------
CREATE MULTISET VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_W_${Source}_ELIG_JRC_DIGITAL_VOL 
     (
      CODE_PROCESS VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      INTRNL_SOURCE_ID SMALLINT ,
      SOURCE_DS CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ACT_ACTE_FAMILLE_KPI VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ACTE_ID BIGINT ,
      ACT_DT DATE FORMAT 'YYYY-MM-DD' ,
      PAR_UNIFIED_PARTY_ID VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PAR_PID_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PAR_CID_ID VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC ,
      IND_HD_TEMPO_CD SMALLINT ,
      IND_HD_TEMPO_DT DATE FORMAT 'YYYY-MM-DD' ,
      RAP_PID_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      RAP_UNIFIED_PARTY_ID VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC ,
      INTRCTN_DT DATE FORMAT 'YYYY-MM-DD' ,
      DELAI INTEGER ,
      ACTE_ID_INTRCTN BIGINT ,
      INTRCTN_ID BIGINT ,
      KEYGEN_CD CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
      APPLI_SOURCE_ID CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
      UNIFIED_PARTY_ID VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC ,
      PID_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      CID_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      INT_OPRTR_ID VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_AGENT_IOBSP CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OPRTR_TEAM_HIERCH_ID VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC ,
      OPRTR_TEAM_ACTVT_ID VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC ,
      UNVRS_CD BYTEINT ,
      DIRCTN_CD BYTEINT ,
      CHANL_CD SMALLINT ,
      MEDIA_CD SMALLINT ,
      ORIGN_CD SMALLINT ,
      WAY_CD SMALLINT ,
      REASN_CD INTEGER ,
      REASN_DETL_CD INTEGER ,
      CONCLSN_CD INTEGER ,
      UNIFIED_SHOP_CD CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_REM_CHANNEL_CD VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_CHANNEL_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_SUB_CHANNEL_CD VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_SUB_SUB_CHANNEL_CD VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_GT_ACTIVITY VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_FIDELISATION VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_WEB_ACTIVITY VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_AUTO_ACTIVITY VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_EDO_ID BIGINT ,
      ORG_TYPE_EDO CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_1_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_1_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_2_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_2_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_3_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_3_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_4_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ORG_TEAM_LEVEL_4_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_1_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_1_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_2_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_2_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_3_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_3_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_4_CD VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC ,
      WORK_TEAM_LEVEL_4_DS VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC ,
      ANNUL_HD_DT DATE FORMAT 'YYYY-MM-DD' ,
      ANNUL_HD_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC ,
      IND_HD_CD SMALLINT ,
      IND_HD_RAP_CD SMALLINT ,
      HD_RAP_DT DATE FORMAT 'YYYY-MM-DD' ,
      CREATION_TS TIMESTAMP(6) ,
      CLOSURE_DT DATE FORMAT 'YYYYMMDD' )
PRIMARY INDEX  ( ACTE_ID_INTRCTN)
ON COMMIT PRESERVE ROWS;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_TERADATA_USER}.ORD_W_${Source}_ELIG_JRC_DIGITAL_VOL
(
   CODE_PROCESS
 , INTRNL_SOURCE_ID
 , SOURCE_DS
 , ACT_ACTE_FAMILLE_KPI
 , ACTE_ID
 , ACT_DT
 , PAR_UNIFIED_PARTY_ID
 , PAR_PID_ID
 , PAR_CID_ID
 , IND_HD_TEMPO_CD
 , IND_HD_TEMPO_DT
 , RAP_PID_ID
 , RAP_UNIFIED_PARTY_ID
 , INTRCTN_DT
 , DELAI
 , ACTE_ID_INTRCTN
 , INTRCTN_ID
 , KEYGEN_CD
 , APPLI_SOURCE_ID
 , UNIFIED_PARTY_ID
 , PID_ID
 , CID_ID
 , INT_OPRTR_ID
 , ORG_AGENT_IOBSP
 , OPRTR_TEAM_HIERCH_ID
 , OPRTR_TEAM_ACTVT_ID
 , UNVRS_CD
 , DIRCTN_CD
 , CHANL_CD
 , MEDIA_CD
 , ORIGN_CD
 , WAY_CD
 , REASN_CD
 , REASN_DETL_CD
 , CONCLSN_CD
 , UNIFIED_SHOP_CD
 , ORG_REM_CHANNEL_CD
 , ORG_CHANNEL_CD
 , ORG_SUB_CHANNEL_CD
 , ORG_SUB_SUB_CHANNEL_CD
 , ORG_GT_ACTIVITY
 , ORG_FIDELISATION
 , ORG_WEB_ACTIVITY
 , ORG_AUTO_ACTIVITY
 , ORG_EDO_ID
 , ORG_TYPE_EDO
 , ORG_TEAM_LEVEL_1_CD
 , ORG_TEAM_LEVEL_1_DS
 , ORG_TEAM_LEVEL_2_CD
 , ORG_TEAM_LEVEL_2_DS
 , ORG_TEAM_LEVEL_3_CD
 , ORG_TEAM_LEVEL_3_DS
 , ORG_TEAM_LEVEL_4_CD
 , ORG_TEAM_LEVEL_4_DS
 , WORK_TEAM_LEVEL_1_CD
 , WORK_TEAM_LEVEL_1_DS
 , WORK_TEAM_LEVEL_2_CD
 , WORK_TEAM_LEVEL_2_DS
 , WORK_TEAM_LEVEL_3_CD
 , WORK_TEAM_LEVEL_3_DS
 , WORK_TEAM_LEVEL_4_CD
 , WORK_TEAM_LEVEL_4_DS
 , ANNUL_HD_DT
 , ANNUL_HD_DS
 , IND_HD_CD
 , IND_HD_RAP_CD
 , HD_RAP_DT
 , CREATION_TS
 , CLOSURE_DT
)
Select
  ACT_DIGIT.CODE_PROCESS                                                        As CODE_PROCESS                   ,
  ACT_DIGIT.INTRNL_SOURCE_ID                                                    As INTRNL_SOURCE_ID               ,
  ACT_DIGIT.SOURCE_DS                                                           As SOURCE_DS                      ,
  ACT_DIGIT.ACT_ACTE_FAMILLE_KPI                                                As ACT_ACTE_FAMILLE_KPI           ,
  ACT_DIGIT.ACTE_ID                                                             As ACTE_ID                        ,
  ACT_DIGIT.ACT_DT                                                              As ACT_DT                         ,
  ACT_DIGIT.PAR_UNIFIED_PARTY_ID                                                As PAR_UNIFIED_PARTY_ID           ,
  ACT_DIGIT.PAR_PID_ID                                                          As PAR_PID_ID                     ,
  ACT_DIGIT.PAR_CID_ID                                                          As PAR_CID_ID                     ,
  1                                                                             As IND_HD_TEMPO_CD                ,
  Coalesce (ACT_DIGIT.IND_HD_TEMPO_DT, current_date)                            As IND_HD_TEMPO_DT                ,
  ACT_DIGIT.RAP_PID_ID                                                          As RAP_PID_ID                     ,
  ACT_DIGIT.RAP_UNIFIED_PARTY_ID                                                As RAP_UNIFIED_PARTY_ID           ,
  ACT_DIGIT.INTRCTN_DT                                                          As INTRCTN_DT                     ,
  ACT_DIGIT.DELAI                                                               As DELAI                          ,
  ACT_DIGIT.ACTE_ID_INTRCTN                                                     As ACTE_ID_INTRCTN                ,
  ACT_DIGIT.INTRCTN_ID                                                          As INTRCTN_ID                     ,
  ACT_DIGIT.KEYGEN_CD                                                           As KEYGEN_CD                      ,
  ACT_DIGIT.APPLI_SOURCE_ID                                                     As APPLI_SOURCE_ID                ,
  ACT_DIGIT.UNIFIED_PARTY_ID                                                    As UNIFIED_PARTY_ID               ,
  ACT_DIGIT.PID_ID                                                              As PID_ID                         ,
  ACT_DIGIT.CID_ID                                                              As CID_ID                        ,
  ACT_DIGIT.INT_OPRTR_ID                                                        As INT_OPRTR_ID                  ,
  ACT_DIGIT.ORG_AGENT_IOBSP                                                     As ORG_AGENT_IOBSP               ,
  ACT_DIGIT.OPRTR_TEAM_HIERCH_ID                                                As OPRTR_TEAM_HIERCH_ID           ,
  ACT_DIGIT.OPRTR_TEAM_ACTVT_ID                                                 As OPRTR_TEAM_ACTVT_ID            ,
  ACT_DIGIT.UNVRS_CD                                                            As UNVRS_CD                       ,
  ACT_DIGIT.DIRCTN_CD                                                           As DIRCTN_CD                      ,
  ACT_DIGIT.CHANL_CD                                                            As CHANL_CD                        ,
  ACT_DIGIT.MEDIA_CD                                                            As MEDIA_CD                        ,
  ACT_DIGIT.ORIGN_CD                                                            As ORIGN_CD                        ,
  ACT_DIGIT.WAY_CD                                                              As WAY_CD                          ,
  ACT_DIGIT.REASN_CD                                                            As REASN_CD                        ,
  ACT_DIGIT.REASN_DETL_CD                                                       As REASN_DETL_CD                   ,
  ACT_DIGIT.CONCLSN_CD                                                          As CONCLSN_CD                      ,
  ACT_DIGIT.UNIFIED_SHOP_CD                                                     As UNIFIED_SHOP_CD                 ,
  ACT_DIGIT.ORG_REM_CHANNEL_CD                                                  As ORG_REM_CHANNEL_CD              ,
  ACT_DIGIT.ORG_CHANNEL_CD                                                      As ORG_CHANNEL_CD                  ,
  ACT_DIGIT.ORG_SUB_CHANNEL_CD                                                  As ORG_SUB_CHANNEL_CD              ,
  ACT_DIGIT.ORG_SUB_SUB_CHANNEL_CD                                              As ORG_SUB_SUB_CHANNEL_CD          ,
  ACT_DIGIT.ORG_GT_ACTIVITY                                                     As ORG_GT_ACTIVITY                 ,
  ACT_DIGIT.ORG_FIDELISATION                                                    As ORG_FIDELISATION                ,
  ACT_DIGIT.ORG_WEB_ACTIVITY                                                    As ORG_WEB_ACTIVITY                ,
  ACT_DIGIT.ORG_AUTO_ACTIVITY                                                   As ORG_AUTO_ACTIVITY               ,
  ACT_DIGIT.ORG_EDO_ID                                                          As ORG_EDO_ID                      ,
  ACT_DIGIT.ORG_TYPE_EDO                                                        As ORG_TYPE_EDO                    ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_CD                                                 As ORG_TEAM_LEVEL_1_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_DS                                                 As ORG_TEAM_LEVEL_1_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_CD                                                 As ORG_TEAM_LEVEL_2_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_DS                                                 As ORG_TEAM_LEVEL_2_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_CD                                                 As ORG_TEAM_LEVEL_3_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_DS                                                 As ORG_TEAM_LEVEL_3_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_CD                                                 As ORG_TEAM_LEVEL_4_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_DS                                                 As ORG_TEAM_LEVEL_4_DS             ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_CD                                                As WORK_TEAM_LEVEL_1_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_DS                                                As WORK_TEAM_LEVEL_1_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_CD                                                As WORK_TEAM_LEVEL_2_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_DS                                                As WORK_TEAM_LEVEL_2_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_CD                                                As WORK_TEAM_LEVEL_3_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_DS                                                As WORK_TEAM_LEVEL_3_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_CD                                                As WORK_TEAM_LEVEL_4_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_DS                                                As WORK_TEAM_LEVEL_4_DS            ,
  ACT_DIGIT.ANNUL_HD_DT                                                         As ANNUL_HD_DT                     ,
  ACT_DIGIT.ANNUL_HD_DS                                                         As ANNUL_HD_DS                     ,
  ACT_DIGIT.IND_HD_CD                                                           As IND_HD_CD                       ,
  ACT_DIGIT.IND_HD_RAP_CD                                                       As IND_HD_RAP_CD                   ,
  ACT_DIGIT.HD_RAP_DT                                                           As HD_RAP_DT                       ,
  Coalesce (ACT_DIGIT.CREATION_TS, Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0)))   As CREATION_TS                     ,
  ACT_DIGIT.CLOSURE_DT                                                          As CLOSURE_DT                      
From ${KNB_PCO_TMP}.ORD_W_${Source}_ELIG_JRC_DIGITAL       ACT_DIGIT
Inner Join ${KNB_PCO_TMP}.ORD_KPI_HD_PILCOM             KPI_HD_PILCOM
  On  ACT_DIGIT.ACT_DT                Between (KPI_HD_PILCOM.PERIODE_DATE_DEB)
                                      And (KPI_HD_PILCOM.PERIODE_DATE_FIN)
  And ACT_DIGIT.ACT_ACTE_FAMILLE_KPI  =    KPI_HD_PILCOM.KPI_HD
Where
  ACT_DIGIT.ACT_DT + 10     <     Current_date
  And ACT_DIGIT.IND_HD_RAP_CD        <> -2 and  ACT_DIGIT.IND_HD_RAP_CD        Is Not Null
 And ACT_DIGIT.ACT_DT                 >= Cast('01012020' As Date Format 'DDMMYYYY')
 And ACT_DIGIT.ACT_ACTE_FAMILLE_KPI  Not In ('NS', 'NSTECH');
.if errorcode <> 0 then .quit 1;

Collect stat on ${KNB_TERADATA_USER}.ORD_W_${Source}_ELIG_JRC_DIGITAL_VOL Index (ACTE_ID_INTRCTN);
.if errorcode <> 0 then .quit 1;
Collect stat on ${KNB_TERADATA_USER}.ORD_W_${Source}_ELIG_JRC_DIGITAL_VOL Column (INTRCTN_DT);
.if errorcode <> 0 then .quit 1;


Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL 
(
      CODE_PROCESS                         ,
      INTRNL_SOURCE_ID                     ,
      SOURCE_DS                            ,
      ACT_ACTE_FAMILLE_KPI                 ,
      ACTE_ID                              ,
      ACT_DT                               ,
      PAR_UNIFIED_PARTY_ID                 ,
      PAR_PID_ID                           ,
      PAR_CID_ID                           ,
      IND_HD_TEMPO_CD                      ,
      IND_HD_TEMPO_DT                      ,
      RAP_PID_ID                           ,
      RAP_UNIFIED_PARTY_ID                 ,
      INTRCTN_DT                           ,
      DELAI                                ,
      ACTE_ID_INTRCTN                      ,
      INTRCTN_ID                           ,
      KEYGEN_CD                            ,
      APPLI_SOURCE_ID                      ,
      UNIFIED_PARTY_ID                     ,
      PID_ID                               ,
      CID_ID                               ,
      INT_OPRTR_ID                         ,
      ORG_AGENT_IOBSP                      ,
      OPRTR_TEAM_HIERCH_ID                 ,
      OPRTR_TEAM_ACTVT_ID                  ,
      UNVRS_CD                             ,
      DIRCTN_CD                            ,
      CHANL_CD                             ,
      MEDIA_CD                             ,
      ORIGN_CD                             ,
      WAY_CD                               ,
      REASN_CD                             ,
      REASN_DETL_CD                        ,
      CONCLSN_CD                           ,
      UNIFIED_SHOP_CD                      ,
      ORG_REM_CHANNEL_CD                   ,
      ORG_CHANNEL_CD                       ,
      ORG_SUB_CHANNEL_CD                   ,
      ORG_SUB_SUB_CHANNEL_CD               ,
      ORG_GT_ACTIVITY                      ,
      ORG_FIDELISATION                     ,
      ORG_WEB_ACTIVITY                     ,
      ORG_AUTO_ACTIVITY                    ,
      ORG_EDO_ID                           ,
      ORG_TYPE_EDO                         ,
      ORG_TEAM_LEVEL_1_CD                  ,
      ORG_TEAM_LEVEL_1_DS                  ,
      ORG_TEAM_LEVEL_2_CD                  ,
      ORG_TEAM_LEVEL_2_DS                  ,
      ORG_TEAM_LEVEL_3_CD                  ,
      ORG_TEAM_LEVEL_3_DS                  ,
      ORG_TEAM_LEVEL_4_CD                  ,
      ORG_TEAM_LEVEL_4_DS                  ,
      WORK_TEAM_LEVEL_1_CD                 ,
      WORK_TEAM_LEVEL_1_DS                 ,
      WORK_TEAM_LEVEL_2_CD                 ,
      WORK_TEAM_LEVEL_2_DS                 ,
      WORK_TEAM_LEVEL_3_CD                 ,
      WORK_TEAM_LEVEL_3_DS                 ,
      WORK_TEAM_LEVEL_4_CD                 ,
      WORK_TEAM_LEVEL_4_DS                 ,
      NEW_UNIFIED_SHOP_CD                  ,
      NEW_ORG_REM_CHANNEL_CD               ,
      NEW_ORG_CHANNEL_CD                   ,
      NEW_ORG_SUB_CHANNEL_CD               ,
      NEW_ORG_SUB_SUB_CHANNEL_CD           ,
      NEW_ORG_GT_ACTIVITY                  ,
      NEW_ORG_FIDELISATION                 ,
      NEW_ORG_WEB_ACTIVITY                 ,
      NEW_ORG_AUTO_ACTIVITY                ,
      NEW_ORG_EDO_ID                       ,
      NEW_ORG_EDO_IOBSP                    ,
      NEW_ORG_TYPE_EDO                     ,
      NEW_ORG_TEAM_LEVEL_1_CD              ,
      NEW_ORG_TEAM_LEVEL_1_DS              ,
      NEW_ORG_TEAM_LEVEL_2_CD              ,
      NEW_ORG_TEAM_LEVEL_2_DS              ,
      NEW_ORG_TEAM_LEVEL_3_CD              ,
      NEW_ORG_TEAM_LEVEL_3_DS              ,
      NEW_ORG_TEAM_LEVEL_4_CD              ,
      NEW_ORG_TEAM_LEVEL_4_DS              ,
      NEW_WORK_TEAM_LEVEL_1_CD             ,
      NEW_WORK_TEAM_LEVEL_1_DS             ,
      NEW_WORK_TEAM_LEVEL_2_CD             ,
      NEW_WORK_TEAM_LEVEL_2_DS             ,
      NEW_WORK_TEAM_LEVEL_3_CD             ,
      NEW_WORK_TEAM_LEVEL_3_DS             ,
      NEW_WORK_TEAM_LEVEL_4_CD             ,
      NEW_WORK_TEAM_LEVEL_4_DS             ,
      ANNUL_HD_DT                          ,
      ANNUL_HD_DS                          ,
      IND_HD_CD                            ,
      IND_HD_RAP_CD                        ,
      HD_RAP_DT                            ,
      CREATION_TS                          ,
      LAST_MODIF_TS                        ,
      CLOSURE_DT                           ,
      AUTHOR_CD                            ,
      CURRENT_IN                           ,
      FRESH_IN                             ,
      COHERENCE_IN                          
)
select 

--Champs du Groupe 1 (alimentÃ©s comme défini dans le tableau de mapping )
  ACT_DIGIT.CODE_PROCESS                                                        As CODE_PROCESS                   ,
  ACT_DIGIT.INTRNL_SOURCE_ID                                                    As INTRNL_SOURCE_ID               ,
  ACT_DIGIT.SOURCE_DS                                                           As SOURCE_DS                      ,
  ACT_DIGIT.ACT_ACTE_FAMILLE_KPI                                                As ACT_ACTE_FAMILLE_KPI           ,
  ACT_DIGIT.ACTE_ID                                                             As ACTE_ID                        ,
  ACT_DIGIT.ACT_DT                                                              As ACT_DT                         ,
  ACT_DIGIT.PAR_UNIFIED_PARTY_ID                                                As PAR_UNIFIED_PARTY_ID           ,
  ACT_DIGIT.PAR_PID_ID                                                          As PAR_PID_ID                     ,
  ACT_DIGIT.PAR_CID_ID                                                          As PAR_CID_ID                     ,
  1                                                                             As IND_HD_TEMPO_CD                ,
  Coalesce (ACT_DIGIT.IND_HD_TEMPO_DT, current_date)                            As IND_HD_TEMPO_DT                ,
--champs du Groupe 2
  ACT_DIGIT.RAP_PID_ID                                                          As RAP_PID_ID                     ,
  ACT_DIGIT.RAP_UNIFIED_PARTY_ID                                                As RAP_UNIFIED_PARTY_ID           ,
  ACT_DIGIT.INTRCTN_DT                                                          As INTRCTN_DT                     ,
  ACT_DIGIT.DELAI                                                               As DELAI                          ,
  ACT_DIGIT.ACTE_ID_INTRCTN                                                     As ACTE_ID_INTRCTN                ,
  ACT_DIGIT.INTRCTN_ID                                                          As INTRCTN_ID                     ,
  ACT_DIGIT.KEYGEN_CD                                                           As KEYGEN_CD                      ,
  ACT_DIGIT.APPLI_SOURCE_ID                                                     As APPLI_SOURCE_ID                ,
  ACT_DIGIT.UNIFIED_PARTY_ID                                                    As UNIFIED_PARTY_ID               ,
  ACT_DIGIT.PID_ID                                                              As PID_ID                         ,
  ACT_DIGIT.CID_ID                                                              As CID_ID                        ,
  ACT_DIGIT.INT_OPRTR_ID                                                        As INT_OPRTR_ID                  ,
  ACT_DIGIT.ORG_AGENT_IOBSP                                                     As ORG_AGENT_IOBSP               ,
  ACT_DIGIT.OPRTR_TEAM_HIERCH_ID                                                As OPRTR_TEAM_HIERCH_ID           ,
  ACT_DIGIT.OPRTR_TEAM_ACTVT_ID                                                 As OPRTR_TEAM_ACTVT_ID            ,
  ACT_DIGIT.UNVRS_CD                                                            As UNVRS_CD                       ,
  ACT_DIGIT.DIRCTN_CD                                                           As DIRCTN_CD                      ,
  ACT_DIGIT.CHANL_CD                                                            As CHANL_CD                        ,
  ACT_DIGIT.MEDIA_CD                                                            As MEDIA_CD                        ,
  ACT_DIGIT.ORIGN_CD                                                            As ORIGN_CD                        ,
  ACT_DIGIT.WAY_CD                                                              As WAY_CD                          ,
  ACT_DIGIT.REASN_CD                                                            As REASN_CD                        ,
  ACT_DIGIT.REASN_DETL_CD                                                       As REASN_DETL_CD                   ,
  ACT_DIGIT.CONCLSN_CD                                                          As CONCLSN_CD                      ,
--Champs du Groupe 3 (alimentation comme défini dans le tableau de mapping) 
  ACT_DIGIT.UNIFIED_SHOP_CD                                                     As UNIFIED_SHOP_CD                 ,
  ACT_DIGIT.ORG_REM_CHANNEL_CD                                                  As ORG_REM_CHANNEL_CD              ,
  ACT_DIGIT.ORG_CHANNEL_CD                                                      As ORG_CHANNEL_CD                  ,
  ACT_DIGIT.ORG_SUB_CHANNEL_CD                                                  As ORG_SUB_CHANNEL_CD              ,
  ACT_DIGIT.ORG_SUB_SUB_CHANNEL_CD                                              As ORG_SUB_SUB_CHANNEL_CD          ,
  ACT_DIGIT.ORG_GT_ACTIVITY                                                     As ORG_GT_ACTIVITY                 ,
  ACT_DIGIT.ORG_FIDELISATION                                                    As ORG_FIDELISATION                ,
  ACT_DIGIT.ORG_WEB_ACTIVITY                                                    As ORG_WEB_ACTIVITY                ,
  ACT_DIGIT.ORG_AUTO_ACTIVITY                                                   As ORG_AUTO_ACTIVITY               ,
  ACT_DIGIT.ORG_EDO_ID                                                          As ORG_EDO_ID                      ,
  ACT_DIGIT.ORG_TYPE_EDO                                                        As ORG_TYPE_EDO                    ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_CD                                                 As ORG_TEAM_LEVEL_1_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_1_DS                                                 As ORG_TEAM_LEVEL_1_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_CD                                                 As ORG_TEAM_LEVEL_2_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_2_DS                                                 As ORG_TEAM_LEVEL_2_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_CD                                                 As ORG_TEAM_LEVEL_3_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_3_DS                                                 As ORG_TEAM_LEVEL_3_DS             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_CD                                                 As ORG_TEAM_LEVEL_4_CD             ,
  ACT_DIGIT.ORG_TEAM_LEVEL_4_DS                                                 As ORG_TEAM_LEVEL_4_DS             ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_CD                                                As WORK_TEAM_LEVEL_1_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_1_DS                                                As WORK_TEAM_LEVEL_1_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_CD                                                As WORK_TEAM_LEVEL_2_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_2_DS                                                As WORK_TEAM_LEVEL_2_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_CD                                                As WORK_TEAM_LEVEL_3_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_3_DS                                                As WORK_TEAM_LEVEL_3_DS            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_CD                                                As WORK_TEAM_LEVEL_4_CD            ,
  ACT_DIGIT.WORK_TEAM_LEVEL_4_DS                                                As WORK_TEAM_LEVEL_4_DS            ,
--Champs du Groupe 4
  Placement_JRC_ANCIEN.UNIFIED_SHOP_CD                                          As NEW_UNIFIED_SHOP_CD             ,
  Placement_JRC_ANCIEN.ORG_REM_CHANNEL_CD                                       As NEW_ORG_REM_CHANNEL_CD          ,
  Placement_JRC_ANCIEN.ORG_CHANNEL_CD                                           As NEW_ORG_CHANNEL_CD              ,
  Placement_JRC_ANCIEN.ORG_SUB_CHANNEL_CD                                       As NEW_ORG_SUB_CHANNEL_CD          ,
  Placement_JRC_ANCIEN.ORG_SUB_SUB_CHANNEL_CD                                   As NEW_ORG_SUB_SUB_CHANNEL_CD      ,
  Placement_JRC_ANCIEN.ORG_GT_ACTIVITY                                          As NEW_ORG_GT_ACTIVITY             ,
  Placement_JRC_ANCIEN.ORG_FIDELISATION                                         As NEW_ORG_FIDELISATION            ,
  Placement_JRC_ANCIEN.ORG_WEB_ACTIVITY                                         As NEW_ORG_WEB_ACTIVITY            ,
  Placement_JRC_ANCIEN.ORG_AUTO_ACTIVITY                                        As NEW_ORG_AUTO_ACTIVITY           ,
  Placement_JRC_ANCIEN.ORG_EDO_ID                                               As NEW_ORG_EDO_ID                  ,
  Placement_JRC_ANCIEN.ORG_EDO_IOBSP                                            As NEW_ORG_EDO_IOBSP               ,
  Placement_JRC_ANCIEN.ORG_TEAM_TYPE_ID                                         As NEW_ORG_TYPE_EDO                ,
  Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_1_CD As Varchar(18)))          As NEW_ORG_TEAM_LEVEL_1_CD         ,
  Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_1_DS                                      As NEW_ORG_TEAM_LEVEL_1_DS         ,
  Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_2_CD As Varchar(18)))          As NEW_ORG_TEAM_LEVEL_2_CD         ,
  Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_2_DS                                      As NEW_ORG_TEAM_LEVEL_2_DS         ,
  Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_3_CD As Varchar(18)))          As NEW_ORG_TEAM_LEVEL_3_CD         ,
  Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_3_DS                                      As NEW_ORG_TEAM_LEVEL_3_DS         ,
  Trim (Cast(Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_4_CD As Varchar(18)))          As NEW_ORG_TEAM_LEVEL_4_CD         ,
  Placement_JRC_ANCIEN.ORG_TEAM_LEVEL_4_DS                                      As NEW_ORG_TEAM_LEVEL_4_DS         ,
  Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_1_CD As Varchar(18)))         As NEW_WORK_TEAM_LEVEL_1_CD        ,
  Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_1_DS                                     As NEW_WORK_TEAM_LEVEL_1_DS        ,
  Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_2_CD As Varchar(18)))         As NEW_WORK_TEAM_LEVEL_2_CD        ,
  Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_2_DS                                     As NEW_WORK_TEAM_LEVEL_2_DS        ,
  Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_3_CD As Varchar(18)))         As NEW_WORK_TEAM_LEVEL_3_CD        ,
  Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_3_DS                                     As NEW_WORK_TEAM_LEVEL_3_DS        ,
  Trim (Cast(Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_4_CD As Varchar(18)))         As NEW_WORK_TEAM_LEVEL_4_CD        ,
  Placement_JRC_ANCIEN.WORK_TEAM_LEVEL_4_DS                                     As NEW_WORK_TEAM_LEVEL_4_DS        ,
-- Champs du Groupe 5
  ACT_DIGIT.ANNUL_HD_DT                                                         As ANNUL_HD_DT                     ,
  ACT_DIGIT.ANNUL_HD_DS                                                         As ANNUL_HD_DS                     ,
  ACT_DIGIT.IND_HD_CD                                                           As IND_HD_CD                       ,
  ACT_DIGIT.IND_HD_RAP_CD                                                       As IND_HD_RAP_CD                   ,
  
  ACT_DIGIT.HD_RAP_DT                                                           As HD_RAP_DT_AGR                   ,
  Coalesce (ACT_DIGIT.CREATION_TS, Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0)))   As CREATION_TS                     ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                     As LAST_MODIF_TS                   ,
  ACT_DIGIT.CLOSURE_DT                                                          As CLOSURE_DT                      ,
  Null                                                                          As AUTHOR_CD                       ,
  1                                                                             As CURRENT_IN                      ,
  1                                                                             As FRESH_IN                        ,
  1                                                                             As COHERENCE_IN                    

From ${KNB_TERADATA_USER}.ORD_W_${Source}_ELIG_JRC_DIGITAL_VOL       ACT_DIGIT         
Left Outer Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC Placement_JRC_ANCIEN    
  On  ACT_DIGIT.ACTE_ID_INTRCTN       = Placement_JRC_ANCIEN.ACTE_ID         
  And ACT_DIGIT.INTRCTN_DT            = Placement_JRC_ANCIEN.INTRCTN_DT      
;
.if errorcode <> 0 then .quit 1;


Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_${Source}_DIGITAL ;
.if errorcode <> 0 then .quit 1; 
