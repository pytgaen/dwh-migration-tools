--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step1_NDS.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 01/08/2016      HLA         Creation
--------------------------------------------------------------------------------

.set width 2500;

Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_REF_PIF_NDS (
   ACTE_ID BIGINT  NOT NULL,
   ORDER_DEPOSIT_DT DATE FORMAT 'YYYYMMDD' NOT NULL,
   ORDER_DEPOSIT_TS    Timestamp(0)            ,
   SERVICE_ACCESS_ID BIGINT  NOT NULL ,
   Prio INTEGER,
   Delta INTEGER
)
    Primary Index (
     Acte_ID
  )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_REF_PIF_NDS Column( Acte_ID);
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_REF_PIF_NDS
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  ORDER_DEPOSIT_TS              ,
  SERVICE_ACCESS_ID             ,
  Prio                          ,
  Delta                         
  
)
Select * 
FROM
(
Select
  RefId.ACTE_ID                                        as  ACTE_ID                       ,
  RefId.ORDER_DEPOSIT_DT                               as  ORDER_DEPOSIT_DT              ,
  RefId.ORDER_DEPOSIT_TS                               as  ORDER_DEPOSIT_TS              ,
  Cor.ACCES_SERVICE                                    as  SERVICE_ACCESS_ID             ,
  Case When  RefId.ORDER_DEPOSIT_DT >= Cor.RELATION_DAT_DEB and  RefId.ORDER_DEPOSIT_DT <= Cor.RELATION_DAT_FIN
		Then 0
       When  RefId.ORDER_DEPOSIT_DT <=  Cor.RELATION_DAT_DEB
		then 1
		else 2
  End 				    				 			   as  Prio  ,
   Abs( Cor.RELATION_DAT_DEB - RefId.ORDER_DEPOSIT_DT) as  Delta  
        
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 RefId
  Inner join ${KNB_COM_SOC}.V_PAR_F_PARTY_KNB_CORR_ENR Cor
    On      RefId.PAR_FIXE_DS = Cor.TERMINTN_VALUE_DS 
Where 
  (1=1)
    And Cor.TERMINTN_VALUE_DS not in ('#')      
  )tmp
  qualify ROW_NUMBER() OVER (partition by tmp.ACTE_ID ORDER BY  Prio asc,delta asc) = 1            
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_REF_PIF_NDS;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------
-- Etape 2: Enrichissement DMC
----------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC (
      ACTE_ID BIGINT  NOT NULL,
      ORDER_DEPOSIT_DT DATE FORMAT 'YYYYMMDD'  NOT NULL,
      ORDER_DEPOSIT_TS               Timestamp(0)  ,
	  DMC_LINE_ID INTEGER ,
      DMC_MASTER_LINE_ID INTEGER ,
      DMC_LINE_TYPE CHAR(1) ,
      DMC_ACTIVATION_DT DATE FORMAT 'YYYYMMDD'  ,
      PAR_DEPRTMNT_ID CHAR(5) ,
      PAR_AID VARCHAR(31),
      PAR_REGRPMNT_ID VARCHAR(15) ,
	  PAR_UNIFIED_PARTY_ID VARCHAR(15)  ,
	  MAIL_ADRESS VARCHAR(100) ,
      FIRST_NAME_NM VARCHAR(64) ,
      LAST_NAME_NM VARCHAR(64) ,
      POSTAL_CD CHAR(5) ,
	  SERVICE_ACCESS_ID BIGINT ,
      PAR_INSEE_NB CHAR(5) ,
      PAR_BU_CD BYTEINT 
)
    Primary Index (
     Acte_ID
  )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC Column( Acte_ID);
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC
(
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  DMC_LINE_ID          ,
  DMC_MASTER_LINE_ID   ,
  DMC_LINE_TYPE        ,
  DMC_ACTIVATION_DT    ,
  PAR_DEPRTMNT_ID      ,
  PAR_AID              ,
  PAR_REGRPMNT_ID      ,
  PAR_UNIFIED_PARTY_ID ,
  MAIL_ADRESS          ,
  FIRST_NAME_NM        ,
  LAST_NAME_NM         ,
  POSTAL_CD            ,
  SERVICE_ACCESS_ID    ,
  PAR_INSEE_NB         ,
  PAR_BU_CD             
  
)
Select
  RefId.ACTE_ID                             AS  ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    AS  ORDER_DEPOSIT_DT       ,
  LineDmc.LINE_ID                           as  DMC_LINE_ID            ,
  LineDmc.MASTER_LINE_ID                    as  DMC_MASTER_LINE_ID     ,
  LineDmc.LINE_TYPE                         as  DMC_LINE_TYPE          ,
  LineDmc.ACTIVATION_DT                     as  DMC_ACTIVATION_DT      ,
  LineDmc.DEPRTMNT_ID                       as  PAR_DEPRTMNT_ID        ,
  LineDmc.BSS_PARTY_EXTERNL_ID              AS  PAR_AID                ,
  LineDmc.PARTY_REGRPMNT_ID                 AS  PAR_REGRPMNT_ID        ,
  LineDmc.UNIFIED_PARTY_ID                  AS  PAR_UNIFIED_PARTY_ID   ,
  LineDmc.MAIL_ADRESS                       AS  MAIL_ADRESS            ,
  LineDmc.LAST_NAME_NM                      AS  FIRST_NAME_NM          ,
  LineDmc.FIRST_NAME_NM                     AS  LAST_NAME_NM           ,
  LineDmc.POSTAL_CD                         AS  POSTAL_CD              ,
  RefId.SERVICE_ACCESS_ID                   AS  SERVICE_ACCESS_ID      ,
  LineDmc.INSEE_NB                          as  PAR_INSEE_NB           ,
  Geo.BU_CD                                 as  PAR_BU_CD               
  
From ${KNB_TERADATA_USER}.ORD_V_REF_PIF_NDS RefId


Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
 On RefId.SERVICE_ACCESS_ID = LineDmc.SERVICE_ACCESS_ID
 
Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT Geo
     On Geo.DEPT_CD = LineDmc.DEPRTMNT_ID
Where 
  (1=1)

;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC;
.if errorcode <> 0 then .quit 1
-----------------------------------------------------------
-- Etape 3: Insertion dan table tmp (DMC + Client NU)
-----------------------------------------------------------
 
Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  SERVICE_ACCESS_ID             ,
  DMC_LINE_ID                   ,
  DMC_MASTER_LINE_ID            ,
  DMC_LINE_TYPE                 ,
  DMC_ACTIVATION_DT             ,
  PAR_DEPRTMNT_ID               ,
  PAR_AID                       ,
  PAR_REGRPMNT_ID               ,
  PAR_UNIFIED_PARTY_ID          ,
  MAIL_ADRESS                   ,
  FIRST_NAME_NM                 ,
  LAST_NAME_NM                  ,
  POSTAL_CD                     ,
  PAR_INSEE_NB                  ,
  PAR_BU_CD                     ,
  CLIENT_NU                     ,
  CLIENT_NU_NEW_PORTE           ,
  DOSSIER_NU                    ,
  DOSSIER_NU_NEW_PORTE          ,
  DOSSIER_DATE_ACTIV            ,
  DOSSIER_DATE_RESIL            ,
  DOSSIER_TYPE_RESIL            ,
  DOSSIER_MOTIF_RESIL           ,
  DOSSIER_NU_IMSI                
)
Select 
  RefId.ACTE_ID                           AS  ACTE_ID                       ,
  RefId.ORDER_DEPOSIT_DT                  AS  ORDER_DEPOSIT_DT              ,
  RefId.SERVICE_ACCESS_ID                 AS  SERVICE_ACCESS_ID             ,
  RefId.DMC_LINE_ID                       as  DMC_LINE_ID                   ,
  RefId.DMC_MASTER_LINE_ID                as  DMC_MASTER_LINE_ID            ,
  RefId.DMC_LINE_TYPE                     as  DMC_LINE_TYPE                 ,
  RefId.DMC_ACTIVATION_DT                 as  DMC_ACTIVATION_DT             ,
  RefId.PAR_DEPRTMNT_ID                   as  PAR_DEPRTMNT_ID               ,
  RefId.PAR_AID              			  AS  PAR_AID                       ,
  RefId.PAR_REGRPMNT_ID                   AS  PAR_REGRPMNT_ID               ,
  RefId.PAR_UNIFIED_PARTY_ID              AS  PAR_UNIFIED_PARTY_ID          ,
  RefId.MAIL_ADRESS                       AS  MAIL_ADRESS                   ,
  RefId.LAST_NAME_NM                      AS  FIRST_NAME_NM                 ,
  RefId.FIRST_NAME_NM                     AS  LAST_NAME_NM                  ,
  RefId.POSTAL_CD                         AS  POSTAL_CD                     ,
  RefId.PAR_INSEE_NB                      as  PAR_INSEE_NB                  ,
  RefId.PAR_BU_CD                         as  PAR_BU_CD                     ,
  Dossier.DOSSIER_CLIENT_NU               as  CLIENT_NU                     ,
  NULL                                    as  CLIENT_NU_NEW_PORTE           ,
  Dossier.DOSSIER_NU                      as  DOSSIER_NU                    ,
  NULL                                    as  DOSSIER_NU_NEW_PORTE          ,
  NULL                                    as  DOSSIER_DATE_ACTIV            ,
  Dossier.DOSSIER_DT_RESIL                as  DOSSIER_DATE_RESIL            ,
  NULL                                    as  DOSSIER_TYPE_RESIL            ,
  Dossier.DOSSIER_CO_MOTRESIL             as  DOSSIER_MOTIF_RESIL           ,
  Dossier.DOSSIER_NU_IMSI                 as  DOSSIER_NU_IMSI                
  
From ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC RefId

Left outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
   On   RefId.DMC_MASTER_LINE_ID = LineDmc.MASTER_LINE_ID
 	and LineDmc.LINE_TYPE = 'M'
 --Jointure Client/Dossier
Left outer Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
     On     LineDmc.RES_VALUE_DS = Dossier.DOSSIER_NU
       and Dossier.DOSSIER_DT_CREAT <= RefId.ORDER_DEPOSIT_TS
       and RefId.ORDER_DEPOSIT_TS < Coalesce(Dossier.DOSSIER_DT_RESIL,cast('2999-12-31 00:00:00'as timestamp(0)))
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC;
.if errorcode <> 0 then .quit 1


------------------------------------------------------------------
----------------------------------------------------------------------------
-- Etape 4 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  PAR_IRIS2000_CD
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC RefId
  Inner Join ${KNB_DMU_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
    on RefId.DMC_LINE_ID = LFIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by LFIBER.LAST_MODIF_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 5 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  PAR_FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
    on RefId.DMC_LINE_ID = FIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER;
.if errorcode <> 0 then .quit 1
