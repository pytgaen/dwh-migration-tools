-- $HEADER:   ATP_PIF_Acte_Alimentation_Step0_Matrice.sql
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PIF_Acte_Alimentation_Step0_Matrice.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ORD_W_ACTE_MATRICE_PIF
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 21/09/2016     HLA         Création
---------------------------------------------------------------------------------

.set !width 2000;
-- **************************************************************
-- Alimentation de la table ORD_W_ACTE_MATRICE_PIF
-- **************************************************************

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_MATRICE_PIF all;
.if errorcode <> 0 then .quit 1
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_MATRICE_PIF
(
  PRODUCT_ID                    ,
  PERIODE_ID                    ,
  TYPE_COMMANDE_ID              ,
  SEG_COM_ID_INI                ,
  SEG_COM_ID_FINAL              ,
  ACTE_ID                       ,
  ACTE_REM_ID                   ,
  FLAG_ACT_REM                  ,
  FLAG_PEC_PERPVC               ,
  ACTE_VALO                     ,
  ACTE_FAMILLE_KPI              ,
  TAUX_MARGE                    ,
  UNITE_CD                      ,
  HUMAINDIGITAL
)
Select
  RefCat.PRODUCT_ID               as PRODUCT_ID               ,
  Matrice.PERIODE_ID              as PERIODE_ID               ,
  Matrice.TYPE_COMMANDE_ID        as TYPE_COMMANDE_ID         ,
  Matrice.SEG_COM_ID_INI          as SEG_COM_ID_INI           ,
  Matrice.SEG_COM_ID_FINAL        as SEG_COM_ID_FINAL         ,
  Matrice.ACTE_ID                 as ACTE_ID                  ,
  Acte.ACTE_REM_ID                as ACTE_REM_ID              ,
  Acte.FLAG_ACT_REM               as FLAG_ACT_REM             ,
  Acte.FLAG_PEC_PERPVC            as FLAG_PEC_PERPVC          ,
  Acte.ACTE_VALO                  as ACTE_VALO                ,
  Acte.ACTE_FAMILLE_KPI           as ACTE_FAMILLE_KPI         ,
  Acte.TAUX_MARGE                 as TAUX_MARGE               ,
  Acte.UNITE_CD                   as UNITE_CD                 ,
  RefKPI.HUMAINDIGITAL            as HUMAINDIGITAL  

  From
  ${KNB_PCO_REFCOM}.V_CAT_R_MATRICE_PILCOM  Matrice
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM Acte
      On    Matrice.PERIODE_ID              = Acte.PERIODE_ID
        And Matrice.ACTE_ID                 = Acte.ACTE_ID
        And Acte.CURRENT_IN                 = 1
        And Acte.CLOSURE_DT                 is null
  /*Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefCat
    On    Matrice.SEG_COM_ID_FINAL         =  RefCat.SEG_COM_ID
      And Matrice.PERIODE_ID               =  RefCat.PERIODE_ID
      And RefCat.CURRENT_IN                =  1
      And RefCat.CLOSURE_DT                is null
   */
  Inner Join ${KNB_COM_SOC}.V_CAT_R_REF_PRODUCT_FICTIF RefCat
     On    'PIF'                 =  RefCat.EXT_PRODUCT_ID_1
       And 'PIF'                 =  RefCat.EXT_PRODUCT_ID_2
       And Matrice.PERIODE_ID    =  RefCat.PERIODE_ID
   Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM RefKPI
      On    RefKPI.PERIODE_ID              = Acte.PERIODE_ID
        And RefKPI.FAMILLE_KPI_ID          = Acte.ACTE_FAMILLE_KPI
        And RefKPI.CURRENT_IN              = 1
        And RefKPI.CLOSURE_DT              Is Null
Where
  (1=1)
  And Matrice.CURRENT_IN                 =1
  And Matrice.CLOSURE_DT                 is null
  And Matrice.SEG_COM_ID_FINAL           in ('PIF')

Qualify Row_Number() Over (Partition by   Matrice.ACTE_ID ,
                                          Matrice.PERIODE_ID
                            Order by      RefCat.PRODUCT_ID asc
                          )=1
;


.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_MATRICE_PIF;
.if errorcode <> 0 then .quit 1
