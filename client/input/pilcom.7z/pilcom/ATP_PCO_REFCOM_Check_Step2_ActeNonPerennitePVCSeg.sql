 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ActeNonConcluPVCSeg.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des actes non conclus PVC
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000







Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_VENTE_PER_CONCLU(
  ACT_SEG_COM_ID_FINAL        Varchar(64)         Not Null  ,
  NB_PERENNITE_OK             Integer                       ,
  NB_VENTE                    Integer                       ,
  PER_PERENNITE_OK            Decimal(5,2)                  
)
Primary Index (
  ACT_SEG_COM_ID_FINAL
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1






Insert Into ${KNB_TERADATA_USER}.ORD_V_VENTE_PER_CONCLU
(
  ACT_SEG_COM_ID_FINAL        ,
  NB_PERENNITE_OK             ,
  NB_VENTE                    ,
  PER_PERENNITE_OK            
)
Select
  RefId.ACT_SEG_COM_ID_FINAL                                                                            As ACT_SEG_COM_ID_FINAL     ,
  Sum(Case When RefId.PERNNT_IN='O' then 1 else 0 end)                                                  As NB_PERENNITE_OK          ,
  Count(*)                                                                                              As NB_VENTE                 ,
  Cast(Cast(NB_PERENNITE_OK As decimal(15,2))*100/NB_VENTE as Decimal(5,2))                             As PER_PERENNITE_OK         
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED RefId
Where
  (1=1)
  And RefId.ACT_FLAG_PVC_REM              ='O'
  And RefId.HOT_IN                        = 0
  And RefId.ACT_DT                        >= Current_date -30
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_SOC}.V_CAT_R_REF_EXCLU_SEG_RT_SUS RefSegExclu
    Where
      (1=1)
      And RefId.ACT_SEG_COM_ID_FINAL      = RefSegExclu.SEG_COM_ID
      And RefSegExclu.SEGMENT_M5_VALID_IN = 1
      And RefSegExclu.CURRENT_IN          = 1
      And RefSegExclu.CLOSURE_DT          Is Null
  )
Group by
  ACT_SEG_COM_ID_FINAL
;
.if errorcode <> 0 Then .quit 1

Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_VENTE_PER_CONCLU_ERR(
  ACT_SEG_COM_ID_FINAL        Varchar(64)         Not Null  ,
  LIB1                        Varchar(100)                  ,
  NB1                         Integer                       ,
  LIB2                        Varchar(100)                  ,
  NB2                         Integer                       ,
  LIB3                        Varchar(100)                  ,
  NB3                         Integer                       ,
  LIB4                        Varchar(100)                  ,
  NB4                         Integer                       ,
  LIB5                        Varchar(100)                  ,
  NB5                         Integer                       
)
Primary Index (
  ACT_SEG_COM_ID_FINAL
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_VENTE_PER_CONCLU_ERR
(
  ACT_SEG_COM_ID_FINAL        ,
  LIB1                        ,
  NB1                         ,
  LIB2                        ,
  NB2                         ,
  LIB3                        ,
  NB3                         ,
  LIB4                        ,
  NB4                         ,
  LIB5                        ,
  NB5                         
)
Select
  RefId.ACT_SEG_COM_ID_FINAL ,
  Max(Case  When RefId.PERNNT_MOTIF = 'Cloture en Parc' Then RefId.PERNNT_MOTIF End) as Lib1,
  Sum(Case  When RefId.PERNNT_MOTIF = 'Cloture en Parc' Then 1 End) as NB1,
  Max(Case  When RefId.PERNNT_MOTIF = 'Suppression Option' Then RefId.PERNNT_MOTIF End) as Lib2,
  Sum(Case  When RefId.PERNNT_MOTIF = 'Suppression Option' Then 1 End) as NB2 ,
  Max(Case  When RefId.PERNNT_MOTIF = 'Migration' Then RefId.PERNNT_MOTIF End) as Lib3,
  Sum(Case  When RefId.PERNNT_MOTIF = 'Migration' Then 1 End) as NB3 ,
  Max(Case  When RefId.PERNNT_MOTIF = 'Résiliation' Then RefId.PERNNT_MOTIF End) as Lib4,
  Sum(Case  When RefId.PERNNT_MOTIF = 'Résiliation' Then 1 End) as NB4,
  Max(Case  When RefId.PERNNT_MOTIF not in ('Résiliation','Cloture en Parc','Suppression Option','Migration') Then Cast('Resiliation Client' as varchar(100)) End) as Lib5,
  Sum(Case  When RefId.PERNNT_MOTIF not in ('Résiliation','Cloture en Parc','Suppression Option','Migration') Then 1 End) as NB5
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED RefId
Where
  (1=1)
  And RefId.ACT_FLAG_PVC_REM              ='O'
  And RefId.HOT_IN                        = 0
  And RefId.ACT_DT                        >= Current_date -30
  And RefId.PERNNT_IN                     ='N'
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_SOC}.V_CAT_R_REF_EXCLU_SEG_RT_SUS RefSegExclu
    Where
      (1=1)
      And RefId.ACT_SEG_COM_ID_FINAL      = RefSegExclu.SEG_COM_ID
      And RefSegExclu.SEGMENT_M5_VALID_IN = 1
      And RefSegExclu.CURRENT_IN          = 1
      And RefSegExclu.CLOSURE_DT          Is Null
  )
Group by
  ACT_SEG_COM_ID_FINAL
;
.if errorcode <> 0 Then .quit 1




Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  8                                                             As REJECT_TYPE_ID         ,
  'ALL'                                                         As SOURCE_ID              ,
  Case  When SegCon.PER_PERENNITE_OK <= 85 Then 'ERR' Else Null End As CATALOG_ID             ,
  'Ventes sur le Segment : '||SegCon.ACT_SEG_COM_ID_FINAL||' '
                            ||Trim(Cast(SegCon.PER_PERENNITE_OK As Decimal Format '---9.99'))||'%  - de ventes pérennes ('
                            ||Trim(SegCon.NB_PERENNITE_OK)||'/'||Trim(SegCon.NB_VENTE)||')'     As ERROR_CD               ,
  Case  When SegCon.PER_PERENNITE_OK <> 100
          Then
            'Causes Non Pérennité : '
                                    ||Case  When SegErr.LIB1 Is Not Null Then ' - '||SegErr.LIB1 Else '' End
                                    ||Case  When SegErr.LIB1 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB1 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB2 Is Not Null Then ' - '||SegErr.LIB2 Else '' End
                                    ||Case  When SegErr.LIB2 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB2 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB3 Is Not Null Then ' - '||SegErr.LIB3 Else '' End
                                    ||Case  When SegErr.LIB3 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB3 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB4 Is Not Null Then ' - '||SegErr.LIB4 Else '' End
                                    ||Case  When SegErr.LIB4 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB4 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB5 Is Not Null Then ' - '||SegErr.LIB5 Else '' End
                                    ||Case  When SegErr.LIB5 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB5 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
  End                                                           As INFO_CD                ,
  SegCon.NB_VENTE                                               As VolumeCas              ,
  Null                                                          As DateMinRecue           ,
  Null                                                          As DateMaxRecue           
From
  ${KNB_TERADATA_USER}.ORD_V_VENTE_PER_CONCLU SegCon
  Left Outer Join ${KNB_TERADATA_USER}.ORD_V_VENTE_PER_CONCLU_ERR SegErr
    On  SegCon.ACT_SEG_COM_ID_FINAL     = SegErr.ACT_SEG_COM_ID_FINAL
;
.if errorcode <> 0 Then .quit 1





-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
