-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_MOB_Step4_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul de la l'acte full soft mobile 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 30/07/2014      HFO         MODIFICATION(flag Pérennité)
-- 30/07/2014      YZH         Evol QC 606
-- 08/09/2014      HFO         MODIFICATION (Gestion de CHAPP Pour la perennite)
--16/02/2015       MDE         Modification (Tracage ETASK)
-- 10/03/2015      HFO         MODIFICATION (ajout champs CHAPP perennité)
-- 12/03/2015      HFO         MODIFICATION QC 1002 et enlève tracage ETASK
-- 23/04/2015      AOU         PDV Point Orange à exclure du Canal AD  QC884
-- 21/05/2015      YZH         Pilcom Digital - Nouveaux champs DMC
-- 29/10/2015      MDE         Modif (Enrichissement Ref 32R)
-- 29/12/2015      MDE         Evol: Restitution en CA
-- 29/03/2016      MDE         Evol:ETASK ajout rule_id 30/31
-- 13/05/2016      GMA         Modification Axe Canal Pilcom MultiCanal
-- 03/06/2016      HLA         Evol:VAD annulation
-- 29/07/2016      ABO         Modification multi-canal: Ajout ATH
-- 03/08/2016      MDE         Modif RG alim  ORG_CANAL_ID / ETASK
-- 26/12/2016      JCR         Ajouts champs VA
-- 28/03/2017      MDE         Evol : ajout CID/PID/FIRST 
-- 13/12/2017      MEL         Evol IOBSP
-- 21/09/2019      SSI         Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
-- 28/05/2020      JCR         modification champs adresse
-- 31/07/2020      EVI         PILCOM-386 : Refonte Digital - Enrichissement SOFT via 6PO
-- 22/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
-- 10/03/2021      EVI         PILCOM-800 : REFONTE DIGITAL - Alimentation PAR_EXTERNAL_PARTY_ID
-- 14/01/2021      BCH         PILCOM-1086 : Decom ORG_WEB_PARTNER_IN
--------------------------------------------------------------------------------

.set width 2500;




Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_MOB All;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_MOB
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  OPERATOR_PROVIDER_ID              ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_EXTERNAL_ID                 ,
  INTRNL_SOURCE_ID                  ,
  ORDER_REF_EXTERNAL_ID             ,
  ORDER_OPER_ID                     ,
  ORDER_MOTV_ID                     ,
  ORDER_MOTIF_DS                    ,
  ORDER_STATUT_CD                   ,
  ORDER_STATUT_MODIF_TS             ,
  ORDER_LAST_STATUT_CD              ,
  ORDER_LAST_STATUT_MODIF_TS        ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_PRODUCT_DS_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  INB_PRESFACT_ACQ_ADV              ,
  INB_PRESFACT_ACQ_AGAP             ,
  SEG_PARC_DT_DEBUT                 ,
  INB_PARK_ID                       ,
  FLAG_HD                           ,
  ORG_CANAL_ID                      ,
  ORG_CHANEL_CD                     ,
  ORG_SUB_CHANEL_CD                 ,
  ORG_SUB_SUB_CHANEL_CD             ,
  ORG_REM_CHANEL_CD                 ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORIG_DEM                          ,
  CANALDEM_MTHD                     ,
  ORG_CANAL_ID_MACRO                ,
  ORG_CANAL_MACRO_LB                ,
  ORG_STORE_NAME                    ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_FLAG_TYPE_PTN_NTK             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  ORG_TYPE_CD                       ,
  ORG_TEAM_LEVEL_1_CD               ,
  ORG_TEAM_LEVEL_1_DS               ,
  ORG_TEAM_LEVEL_2_CD               ,
  ORG_TEAM_LEVEL_2_DS               ,
  ORG_TEAM_LEVEL_3_CD               ,
  ORG_TEAM_LEVEL_3_DS               ,
  ORG_TEAM_LEVEL_4_CD               ,
  ORG_TEAM_LEVEL_4_DS               ,
  WORK_TEAM_LEVEL_1_CD              ,
  WORK_TEAM_LEVEL_1_DS              ,
  WORK_TEAM_LEVEL_2_CD              ,
  WORK_TEAM_LEVEL_2_DS              ,
  WORK_TEAM_LEVEL_3_CD              ,
  WORK_TEAM_LEVEL_3_DS              ,
  WORK_TEAM_LEVEL_4_CD              ,
  WORK_TEAM_LEVEL_4_DS              ,
  PAR_EXTERNAL_PARTY_FREG_ID        ,
  PAR_PARTY_KNB_FREG_ID             ,
  PAR_AID                           ,
  PAR_PARTY_KNB_BSS_ID              ,
  PAR_ND                            ,
  PAR_ACCES_SERVICE                 ,
  PAR_ADV_CLIENT_NU                 ,
  PAR_ADV_DOSSIER_NU                ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_DEPRTMNT_ID                   ,
    --
  PAR_CID_ID                        ,
  PAR_PID_ID                        ,
  PAR_FIRST_IN                      ,
  ORG_EDO_IOBSP                     ,
  ORG_AGENT_IOBSP                   ,
  --
  PAR_POSTAL_CD                     ,
  PAR_INSEE_CD                      ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  PAR_IRIS2000_CD                   ,
  PAR_FIBER_IN                      ,
  REDIRECTION_CD                    ,
  OTO_OSCAR_VALUE_NU                ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_SIRET                         ,
  PAR_MARKET_SEG                    ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_CD_POSTAL                ,
  PAR_DO                            ,
  PAR_BU_CD                         ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  PAR_MOB_IMEI                      ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  PAR_MOB_IMSI                      ,
  PAR_EXTERNAL_PARTY_ID             ,
  PAR_SCORE_NU_INT                  ,
  PAR_SCORE_IN_INT                  ,
  PAR_TRESHOLD_NU_INT               ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  CONTRCT_DT_SIGN_PREC_INT          ,
  CONTRCT_DT_FIN_PREC_INT           ,
  CONTRCT_DT_DEB_SIGN_POST_INT      ,
  CONTRCT_DT_FIN_SIGN_POST_INT      ,
  DUREE_ENGAGEMENT_INT              ,
  TYPE_DUR_ENGAGEMENT_INT           ,
  CONTRCT_DT_SIGN_PREC_MOB          ,
  CONTRCT_DT_FIN_PREC_MOB           ,
  CONTRCT_DT_SIGN_POST_MOB          ,
  CONTRCT_DUREE_ENG_MOB             ,
  CONTRCT_UNIT_ENG_MOB              ,
  CONFIRMATION_IN                   ,
  CONFIRMATION_DT                   ,
  CONFIRMATION_CALC_FIN_DT          ,
  DELIVERY_IN                       ,
  DELIVERY_DT                       ,
  DELIVERY_CALC_FIN_DT              ,
  PERENNITE_IN                      ,
  PERENNITE_FIN_DT                  ,
  PERENNITE_CALC_FIN_DT             ,
  PERENNITE_PVC_IN                  ,
  PERENNITE_PVC_FIN_DT              ,
  PERENNITE_PVC_CALC_FIN_DT         ,
  SEG_COM_ID_LAST_PER               ,
  SEG_COM_ID_SOLD                   ,
  SEG_COM_ID_FIND                   ,
  SEG_FIND_LIVR_DT                  ,
  SEG_FIND_CANCEL_DT                ,
  SEG_COM_ID_NEXT_PARC              ,
  SEG_NEXT_PARC_LIVR_DT             ,
  SEG_NEXT_PARC_CANCEL_DT           ,
  SEG_COM_ID_FINAL_PARC             ,
  SEG_FINAL_PARC_LIVR_DT            ,
  SEG_FINAL_PARC_CANCEL_DT          ,
  SEG_COM_ID_LAST_IN_PARC           ,
  NB_IN_OUT_PARC                    ,
  POURCENTAGE_PRES_PARC             ,
  SEG_PRES_PARC_COMMANDE            ,
  SEG_COM_ID_ORDER_ID               ,
  SEG_ORDER_DT                      ,
  SEG_CANCEL_DT                     ,
  SEG_COM_ID_NEXT_ORDER             ,
  SEG_NEXT_ORDER_DT                 ,
  SEG_NEXT_CANCEL_DT                ,
  SEG_COM_ID_FINAL_ORDER            ,
  SEG_FINAL_ORDER_DT                ,
  SEG_FINAL_ORDER_CANCEL_DT         ,
  DELIVERY_ONTIME_IN                ,
  DELIVERY_DEAD_LINE_NU             ,
  CONCURENCE_IN                     ,
  CONCURENCE_CONCLU_IN              ,
  CONCURENCE_ID                     ,
  MIGRA_DT                          ,
  MIGRA_NEXT_OFFRE                  ,
  RESIL_INT_DT                      ,
  RESIL_INT_MOTIF                   ,
  RESIL_INT_MOTIF_DS                ,
  PERNNT_IN                         ,
  PERNNT_END_DT                     ,
  PERNNT_MOTIF                      ,
  PERNNT_CALC_END_DT                ,
  ORDER_CANCELING_DT                ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CPLT_ACTE_ID                      ,
  CPLT_EXT_INT_ID                   ,
  CPLT_EXT_INT_DELT_ID              ,
  CPLT_ORG_EDO_ID                   ,
  CPLT_ORG_TYPE_EDO                 ,
  CPLT_ORG_FLAG_PLT_CONV            ,
  CPLT_ORG_FLAG_TEAM_MKT            ,
  CPLT_ORG_FLAG_TYPE_CMP            ,
  CPLT_ORG_REM_CHANNEL_CD           ,
  CPLT_ORG_CHANNEL_CD               ,
  CPLT_ORG_SUB_CHANNEL_CD           ,
  CPLT_ORG_SUB_SUB_CHANNEL_CD       ,
  CPLT_ORG_GT_ACTIVITY              ,
  CPLT_ORG_FIDELISATION             ,
  CPLT_ORG_WEB_ACTIVITY             ,
  CPLT_ORG_AUTO_ACTIVITY            ,
  CPLT_EXTERNAL_TEAM_CD             ,
  CPLT_O3_ACTIVE_TEAM_CD            ,
  CPLT_O3_RATTACHEMENT_TEAM_CD      ,
  CPLT_AGENT_ID_UPD                 ,
  CPLT_INT_SRC                      ,
  CPLT_INT_REASON                   ,
  CPLT_INT_RESULT                   ,
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                         as ACTE_ID                            ,
  Placement.ACTE_ID                                         as ACTE_ID_GEN                        ,
  Placement.OPERATOR_PROVIDER_ID                            as OPERATOR_PROVIDER_ID               ,
  Placement.ORDER_DEPOSIT_DT                                as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                as ORDER_DEPOSIT_TS                   ,
  Placement.EXTERNAL_ORDER_ID                               as ORDER_EXTERNAL_ID                  ,
  Placement.INTRNL_SOURCE_ID                                as INTRNL_SOURCE_ID                   ,
  Placement.VAD_ORDER_ID                                    as ORDER_REF_EXTERNAL_ID              ,
  Placement.ACTE_OPERTR_ID_OT                               as ORDER_OPER_ID                      ,
  Placement.MOTV_ORDR_ID                                    as ORDER_MOTV_ID                      ,
  Case  When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_310}'
          Then  '${P_PIL_311}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_312}'
          Then  '${P_PIL_313}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_314}'
          Then  '${P_PIL_315}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_316}'
          Then  '${P_PIL_317}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_318}'
          Then  '${P_PIL_319}'
        Else    '${P_PIL_321}'
  End                                                       as ORDER_MOTIF_DS                     ,
  Placement.ORDER_STATUS_CD                                 as ORDER_STATUT_CD                    ,
  Placement.STATUS_MODIF_TS                                 as ORDER_STATUT_MODIF_TS              ,
  Placement.ORDER_LAST_STATUT_CD                            as ORDER_LAST_STATUT_CD               ,
  Placement.ORDER_LAST_STATUT_MODIF_TS                      as ORDER_LAST_STATUT_MODIF_TS         ,
  --LastStatEfb.ORDER_LAST_STATUT_EFB_CD                      as ORDER_LAST_STATUT_EFB_CD           ,
  --LastStatEfb.ORDER_LAST_STATUT_EFB_TS                      as ORDER_LAST_STATUT_EFB_TS           ,
  ActeSoft.PRODUCT_ID_PRE                                   as ACT_PRODUCT_ID_PRE                 ,
  ActeSoft.PRODUCT_DS_PRE                                   as ACT_PRODUCT_DS_PRE                 ,
  ActeSoft.SEG_COM_ID_PRE                                   as ACT_SEG_COM_ID_PRE                 ,
  ActeSoft.SEG_COM_AGG_ID_PRE                               as ACT_SEG_COM_AGG_ID_PRE             ,
  ActeSoft.CODE_MIGR_PRE                                    as ACT_CODE_MIGR_PRE                  ,
  ActeSoft.TYPE_MVT_PRE                                     as ACT_OPER_ID_PRE                    ,
  ActeSoft.PRODUCT_ID_FINAL                                 as ACT_PRODUCT_ID_FINAL               ,
  Placement.PRESFACT_CO_OFFRE_OPT_DS                        as ACT_PRODUCT_DS_FINAL               ,
  ActeSoft.SEG_COM_ID_FINAL                                 as ACT_SEG_COM_ID_FINAL               ,
  ActeSoft.SEG_COM_AGG_ID_FINAL                             as ACT_SEG_COM_AGG_ID_FINAL           ,
  ActeSoft.CODE_MIGR_FINAL                                  as ACT_CODE_MIGR_FINAL                ,
  ActeSoft.TYPE_MVT_FINAL                                   as ACT_OPER_ID_FINAL                  ,
  ActeSoft.TYPE_SERVICE_FINAL                               as ACT_TYPE_SERVICE_FINAL             ,
  Coalesce(Mat.TYPE_COMMANDE_ID, ActeSoft.TYPE_COMMANDE_ID) as ACT_TYPE_COMMANDE_ID               ,
--Unité = NB
  Case When Mat.UNITE_CD ='${P_PIL_620}'
         Then ActeSoft.DELTA_TARIF 
    --Unité  CA_MARKET )
      When Mat.UNITE_CD ='${P_PIL_623}'
           then Mat.CA_MARKETING 
       Else Coalesce(ActeSoft.DELTA_TARIF,0)
  End                                                       as ACT_DELTA_TARIF                    ,
  Mat.UNITE_CD                                              as ACT_UNITE_CD                       ,
  Case  When Mat.ACTE_ID Is Not Null
          Then  Mat.ACTE_ID
        When ActeSoft.PERIODE_ID  = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit Placé est un produit inconnu de RefCom
        When  ActeSoft.PRODUCT_ID_FINAL  = '${P_PIL_223}'
          Then  '${P_PIL_224}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        When ActeSoft.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        Else '${P_PIL_220}'
  End                                                       as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID,'${P_PIL_067}')                  as ACT_REM_ID                         ,
  Coalesce(Mat.FLAG_ACT_REM,'N')                            as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC,'N')                         as ACT_FLAG_PEC_PERPVC                ,
     --Unité = NB
  Case When Mat.UNITE_CD ='${P_PIL_620}'
         Then Mat.ACTE_VALO
  --Unité  CA_MARKET 
       When Mat.UNITE_CD  ='${P_PIL_623}' 
         Then cast(( ACT_DELTA_TARIF* Mat.TAUX_MARGE ) as Format '-----------9,99')
       Else   Coalesce(Mat.ACTE_VALO,0)
  End                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Mat.ACTE_FAMILLE_KPI,'NON PARAM')                as ACT_ACTE_FAMILLE_KPI               ,
  ActeSoft.PERIODE_ID                                       as ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                  as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            as ACT_PERIODE_CLOSURE_DT             ,
  Null                                                      as INB_PRESFACT_ACQ_ADV               ,
  Null                                                      as INB_PRESFACT_ACQ_AGAP              ,
  Null                                                      as SEG_PARC_DT_DEBUT                  ,
  Null                                                      as INB_PARK_ID                        ,
  Mat.HUMAINDIGITAL                                         as FLAG_HD                            ,
   Case When (TraceAutoEtk.ACTE_ID is not null And Placement.DISTRBTN_CHANNL_ID in (${L_PIL_990})  And ORG_CHANEL_CD_AGR='Online' )
        Then  'SCC'      
       Else  Placement.DISTRBTN_CHANNL_ID 
   End                                                      as ORG_CANAL_ID                       ,
  --Calcul du canal de vente Macro
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_CHANEL_CD     
       When  TraceAutoEtk.ACTE_ID Is  Null
        Then 
              Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                       Then OrgaPDV.ORG_CHANNEL_CD
                    When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                       Then  'Exclus'
                    When Orga.ORG_CHANEL_CD Is Not Null
                       Then  Orga.ORG_CHANEL_CD
                    When OrgaWeb.ORG_CHANEL_CD Is Not Null
                       Then  OrgaWeb.ORG_CHANEL_CD
                    When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
                       Then 'Online'
                    Else 'NONPARAM' 
                End
      Else  TraceAutoEtk.ORG_CHANEL_CD 
   End                                                    as ORG_CHANEL_CD_AGR                    ,
  --Sous Canal
  Case 
         When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_SUB_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_SUB_CHANEL_CD    
       When (NSW2.ORG_SUB_CHANEL_CD is not null or NSW3.ORG_SUB_CHANEL_CD is not null)
        Then Coalesce(NSW2.ORG_SUB_CHANEL_CD,NSW3.ORG_SUB_CHANEL_CD)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then
            Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                   Then OrgaPDV.ORG_SUB_CHANNEL_CD
                  When Orga.ORG_CHANEL_CD Is Not Null
                   Then Case When (Placement.FLAG_TYPE_CPT_NTK = 'AUTRC' AND ORG_CHANEL_CD_AGR ='Dist')
                              Then 'RC'
                            When FLAG_TYPE_PTN_NTK ='DCE'
                              Then 'Exclus'
                            Else Orga.ORG_SUB_CHANEL_CD
                         End
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                   Then Orgaweb.ORG_SUB_CHANEL_CD
                  Else 'NONPARAM'
            End
     Else  TraceAutoEtk.ORG_SUB_CHANEL_CD 
  End                                                     as ORG_SUB_CHANEL_CD_AGR                  ,
  --Sous-Sous-Canal
  Case 
           When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_SUB_SUB_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_SUB_SUB_CHANEL_CD   
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then
            Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_SUB_SUB_CHANNEL_CD
                  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
                    Then Case When FLAG_TYPE_PTN_NTK ='DCE'
                               Then 'Exclus'
                              Else Orga.ORG_SUB_SUB_CHANEL_CD
                         End
                  When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR='RC')
                    Then  Case  When FLAG_TYPE_CPT_NTK ='AUT'
                                  Then 'AUTRC'
                                When FLAG_TYPE_CPT_NTK ='GRO'
                                  Then 'GROSS'
                                Else FLAG_TYPE_CPT_NTK
                          End
                  When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP' And Placement.TYPE_EDO='INT')
                    Then 'PAP Int'
                  When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP' And Placement.TYPE_EDO='EXT')
                    Then 'PAP Ext'
                  When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR<>'RC')
                    Then 
                      Case When FLAG_TYPE_GEO Is Not Null
                       Then 'DOM'
                      Else 'Metropole'
                      End
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                    Then OrgaWeb.ORG_SUB_SUB_CHANEL_CD
                  Else 'NONPARAM'
          End
     Else  TraceAutoEtk.ORG_SUB_SUB_CHANEL_CD 
  End                                                         as ORG_SUB_SUB_CHANEL_CD_AGR              ,
  --Canal de Rem
  Case 
        When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_REM_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_REM_CHANEL_CD   
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then 
          Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                  Then OrgaPDV.ORG_REM_CHANNEL_CD
                When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                  Then  'Exclus'
                When ORG_SUB_SUB_CHANEL_CD_AGR = 'PAP Int'
                  Then 'PAP'
                When ORG_SUB_SUB_CHANEL_CD_AGR = 'PAP Ext'
                  Then 'Exclus'
                When Orga.ORG_CHANEL_CD Is Not Null  
                  Then Orga.ORG_REM_CHANEL_CD
                When OrgaWeb.ORG_CHANEL_CD Is Not Null
                  Then OrgaWeb.ORG_REM_CHANEL_CD
                When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
                 Then 'Online'
                Else 'NONPARAM'
          End
     Else  TraceAutoEtk.ORG_REM_CHANEL_CD 
  End                                                         as ORG_REM_CHANEL_CD                  ,
  --ActivitÃ©
  Case 
          When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_GT_ACTIVITY
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_GT_ACTIVITY   
       When (NSW2.ORG_GT_ACTIVITY is not null or NSW3.ORG_GT_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_GT_ACTIVITY,NSW3.ORG_GT_ACTIVITY) 
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then 
          Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                  Then OrgaPDV.ORG_GT_ACTIVITY
                When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
                  Then  'Exclus'
                When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
                  Then Orga.ORG_GT_ACTIVITY
                When ORG_CHANEL_CD_AGR = 'Dist'
                  Then
                    Case  When ORG_SUB_CHANEL_CD_AGR =  'PAP'
                            Then 'Porte a Porte'
                          When FLAG_TYPE_PTN_NTK = 'MOB'
                            Then 'Mobistore'
                          When FLAG_TYPE_PTN_NTK = 'FC'
                            Then 'CARAIBES'
                          When FLAG_TYPE_PTN_NTK Is Not Null
                           Then FLAG_TYPE_PTN_NTK
                          When ORG_SUB_CHANEL_CD_AGR='AD'
                           Then 'Boutique FT'
                          When ORG_SUB_CHANEL_CD_AGR='RC'
                           Then 'Reseau Concurrent'
                          When ORG_SUB_SUB_CHANEL_CD_AGR = 'DOM'
                              Then 'CARAIBES'
                    End
                When OrgaWeb.ORG_CHANEL_CD Is Not Null
                  Then OrgaWeb.ORG_GT_ACTIVITY            
                Else 'NONPARAM'
          End
     Else  TraceAutoEtk.ORG_GT_ACTIVITY 
  End                                                       as ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  Case When  TraceAutoEtk.ACTE_ID Is  Null 
        Then Case When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_FIDELISATION 
                  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                    Then  'Exclus'
                  When Orga.ORG_CHANEL_CD Is Not Null  
                   Then Orga.ORG_FIDELISATION
                When OrgaWeb.ORG_CHANEL_CD Is Not Null
                    Then OrgaWeb.ORG_FIDELISATION
               Else 'NONPARAM'
            End  
       Else  TraceAutoEtk.ORG_FIDELISATION 
  End                                                       as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_WEB_ACTIVITY
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_WEB_ACTIVITY 
	   When (NSW2.ORG_WEB_ACTIVITY is not null or NSW3.ORG_WEB_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_WEB_ACTIVITY,NSW3.ORG_WEB_ACTIVITY)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then Case When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_WEB_ACTIVITY 
                  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
                    Then  'Exclus'
                  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist'  )
                    Then Orga.ORG_WEB_ACTIVITY
                  When ORG_CHANEL_CD_AGR = 'Dist'
                   Then 'NON'
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                   Then OrgaWeb.ORG_WEB_ACTIVITY
                  When OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
                    Then 'OUI'
                Else 'E'
           End    
     Else  TraceAutoEtk.ORG_WEB_ACTIVITY 
  End                                                       as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_AUTO_ACTIVITY
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_AUTO_ACTIVITY 
       When (NSW2.ORG_AUTO_ACTIVITY is not null or NSW3.ORG_AUTO_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_AUTO_ACTIVITY,NSW3.ORG_AUTO_ACTIVITY)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then Case When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_AUTO_ACTIVITY 
                  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                    Then 'Exclus'
                  When ORG_CHANEL_CD_AGR = 'Dist'
                    Then 'NON'
                  When Orga.ORG_CHANEL_CD Is Not Null  
                    Then Orga.ORG_AUTO_ACTIVITY
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                    Then OrgaWeb.ORG_AUTO_ACTIVITY
                  When OrgaWeb.ORG_CHANEL_CD Is Null And  Placement.DISTRBTN_CHANNL_ID ='SCC'
                    Then 'OUI'
                 Else 'E'
             End  
        Else  TraceAutoEtk.ORG_AUTO_ACTIVITY 
  End                                                       as ORG_AUTO_ACTIVITY                  ,
  Null                                                      as ORIG_DEM                           ,
  Null                                                      as CANALDEM_MTHD                      ,
  Null                                                      as ORG_CANAL_ID_MACRO                 ,
  Null                                                      as ORG_CANAL_MACRO_LB                 ,
 Case When (TraceAutoEtk.ACTE_ID Is Not Null And Placement.DISTRBTN_CHANNL_ID in (${L_PIL_990}) And TraceAutoEtk.JOB_ID in (${L_PIL_991}))
        Then  '${P_PIL_491}'      
       When  (TraceAutoEtk.ACTE_ID Is Not Null And Placement.DISTRBTN_CHANNL_ID in (${L_PIL_990}) And TraceAutoEtk.JOB_ID in (${L_PIL_992}))
        Then  '${P_PIL_492}' 
       Else    Placement.STORE_NAME
   End                                                  as ORG_STORE_NAME                      ,
  Case When (NSW2.EDO_ID is not null or NSW3.EDO_ID is not null)
        Then Coalesce(NSW2.EDO_ID,NSW3.EDO_ID)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then  Placement.EDO_ID       
       Else  TraceAutoEtk.EDO_ID 
   End                                                    as ORG_EDO_ID                         ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.TYPE_EDO       
       Else  TraceAutoEtk.TYPE_EDO_ID 
   End                                                    as ORG_TYPE_EDO                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.NETWRK_TYP_EDO_ID       
       Else  TraceAutoEtk.NETWRK_TYP_EDO_ID 
   End                                                    as ORG_NETWRK_TYP_EDO_ID              ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_GEO       
       Else  TraceAutoEtk.FLAG_TYPE_GEO_CD 
   End                                                    as ORG_FLAG_TYPE_GEO                  ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_CPT_NTK       
       Else  TraceAutoEtk.FLAG_TYPE_CPT_NTK_NU 
  End                                                    as ORG_FLAG_TYPE_CPT_NTK              ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_PTN_NTK       
       Else  TraceAutoEtk.FLAG_TYPE_PTN_NTK_NU 
   End                                                    as ORG_FLAG_TYPE_PTN_NTK              ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  Placement.FLAG_PLT_CONV       
       Else  TraceAutoEtk.FLAG_PLT_CONV_NB 
   End                                                    as ORG_FLAG_PLT_CONV                  ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TEAM_MKT       
       Else  TraceAutoEtk.FLAG_TEAM_MKT_NB 
   End                                                    as ORG_FLAG_TEAM_MKT                  ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_CMP       
       Else  TraceAutoEtk.FLAG_TYPE_CMP_NU 
  End                                                     as ORG_FLAG_TYPE_CMP                  ,
  Null                                                    as ORG_REF_TRAV                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.AGENT_ID      
       Else  TraceAutoEtk.AGENT_ID 
   End                                                    as ORG_AGENT_ID                       ,
  Null                                                    as ORG_POC_XI                         ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Coalesce(RetourGRV.AGENT_ID_UPD,Placement.AGENT_ID)
       Else  Coalesce(RetourGRV.AGENT_ID_UPD,TraceAutoEtk.AGENT_ID)
   End                                                    as ORG_AGENT_ID_UPD                   ,
  Cast(RetourGRV.AGENT_ID_UPD_TS as date Format 'YYYYMMDD') as ORG_AGENT_ID_UPD_DT              ,
  Case When  TraceAutoEtk.ACTE_ID is  null 
        Then  Coalesce(RetourGRV.ORG_NOM,Placement.ORG_NOM)
       Else  Coalesce(RetourGRV.ORG_NOM,TraceAutoEtk.ORG_LAST_NAME_NM)
  End                                                    as ORG_NOM                            ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Coalesce(RetourGRV.ORG_PRENOM,Placement.ORG_PRENOM )
       Else  Coalesce(RetourGRV.ORG_PRENOM,TraceAutoEtk.ORG_FIRST_NAME_NM)
   End                                                      as ORG_PRENOM                         ,
  Null                                                      as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitée
  Null                                                      as ORG_ACTVT_REEL                     ,
  Null                                                      as ORG_RESP_REF_TRAV                  ,
  Null                                                      as ORG_RESP_AGENT_ID                  ,
  Null                                                      as ORG_RESP_XI                        ,
      Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then OrgO3Enri.ORG_TYPE_CD     
       Else  NULL 
   End                                                     as ORG_TYPE_CD                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.ORG_TEAM_LEVEL_1_CD  
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_1_CD 
   End                                                     as ORG_TEAM_LEVEL_1_CD                ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_1_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_1_DS 
   End                                                     as ORG_TEAM_LEVEL_1_DS                ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_2_CD      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_2_CD 
   End                                                     as ORG_TEAM_LEVEL_2_CD                ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_2_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_2_DS 
   End                                                     as ORG_TEAM_LEVEL_2_DS                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.ORG_TEAM_LEVEL_3_CD      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_3_CD 
   End                                                     as ORG_TEAM_LEVEL_3_CD                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.ORG_TEAM_LEVEL_3_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_3_DS 
   End                                                     as ORG_TEAM_LEVEL_3_DS                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_4_CD      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_4_CD 
   End                                                     as ORG_TEAM_LEVEL_4_CD                ,
      Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_4_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_4_DS 
   End                                                     as ORG_TEAM_LEVEL_4_DS                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_1_CD     
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_1_CD 
   End                                                     as WORK_TEAM_LEVEL_1_CD               ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_1_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_1_DS 
   End                                                     as WORK_TEAM_LEVEL_1_DS               ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_2_CD      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_2_CD 
   End                                                      as WORK_TEAM_LEVEL_2_CD               ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_2_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_2_DS 
   End                                                     as WORK_TEAM_LEVEL_2_DS               , 
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_3_CD      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_3_CD 
   End                                                     as WORK_TEAM_LEVEL_3_CD               ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_3_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_3_DS 
   End                                                     as WORK_TEAM_LEVEL_3_DS               ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_4_CD      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_4_CD 
   End                                                     as WORK_TEAM_LEVEL_4_CD               ,
      Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_4_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_4_DS 
   End                                                      as WORK_TEAM_LEVEL_4_DS               ,
  Placement.CUSTOMER_FGT_ID                                 as PAR_EXTERNAL_PARTY_FREG_ID         ,
  Null                                                      as PAR_PARTY_KNB_FREG_ID              ,
  Placement.CUSTOMER_BSS_ID                                 as PAR_AID                            ,
  Null                                                      as PAR_PARTY_KNB_BSS_ID               ,
  Placement.CUSTOMER_ND_AR                                  as PAR_ND                             ,
  Placement.SERVICE_ACCESS_ID                               as PAR_ACCES_SERVICE                  ,
  Placement.CUSTOMER_CLIENT_NU_ADV                          as PAR_ADV_CLIENT_NU                  ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                         as PAR_ADV_DOSSIER_NU                 ,
  Placement.LINE_ID                                         as DMC_LINE_ID                        ,
  Placement.MASTER_LINE_ID                                  as DMC_MASTER_LINE_ID                 ,
  Case When (Placement.PAR_DEPRTMNT_ID Is Null
              Or
              Substring(Trim(Placement.PAR_DEPRTMNT_ID) From 1 For 3) In ('998', '999') -- respectivement departement etranger  ou inconnu
            ) 
            And PAR_BILL_CD_POSTAL_AGR  Is Not Null
        Then
           Case When Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988')
                        Then  Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 3) -- on renseigne les departement sur 3 caracteres
                        Else    Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 2)  -- on renseigne les departement sur 2 caracteres
            End
        Else    Trim(Placement.PAR_DEPRTMNT_ID)
  End                                                       as PAR_DEPRTMNT_ID                    ,
  Placement.PAR_CID_ID                                      as PAR_CID_ID                         ,
  Placement.PAR_PID_ID                                      as PAR_PID_ID                         ,
  Placement.PAR_FIRST_IN                                    as PAR_FIRST_IN                       ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                      ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                    ,
  Placement.PAR_POSTAL_CD                                   as PAR_POSTAL_CD                      ,
  Placement.PAR_INSEE_CD                                    as PAR_INSEE_CD                       ,
  Placement.PAR_GEO_MACROZONE                               as PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                            as PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                           as PAR_PARTY_REGRPMNT_ID              ,
  Placement.PAR_IRIS2000_CD                                 as PAR_IRIS2000_CD                    ,
  Placement.PAR_FIBER_IN                                    as PAR_FIBER_IN                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
          Then  Placement.REDIRECTION_CD      
       Else  TraceAutoEtk.ORDR_ORGN_DS 
   End                                                      as REDIRECTION_CD                     ,
  Placement.OSCAR_VALUE_NU                                  as OTO_OSCAR_VALUE_NU                 ,
  Placement.CUSTOMER_LAST_NAME                              as PAR_LASTNAME                       ,
  Placement.CUSTOMER_FIRST_NAME                             as PAR_FIRSTNAME                      ,
  Placement.CUSTOMER_SIRET                                  as PAR_SIRET                          ,
  Placement.CUSTOMER_MARKET_SEG                             as PAR_MARKET_SEG                     ,
  Null                                                      as PAR_TYPE                           ,
  Null                                                      as PAR_EMAIL                          ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_STREET 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_STREET
  End                                                       as PAR_BILL_ADRESS_1                  ,
  Null                                                      as PAR_BILL_ADRESS_2                  ,
  Null                                                      as PAR_BILL_ADRESS_3                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_CITY 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_CITY
  End                                                       as PAR_BILL_ADRESS_4                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_ZIPCODE 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_ZIPCODE
  End                                                       as PAR_BILL_CD_POSTAL_AGR             ,  
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3) In (${L_PIL_034})
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3)
        When    Placement.INSTALL_ADDRESS_ZIPCODE  Is Not Null
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 2)
        Else    Null
  End                                                       as PAR_DO                             ,
  Placement.PAR_BU_CD                                       as PAR_BU_CD                          ,
  Null                                                      as PAR_USCM                           ,
  Null                                                      as PAR_USCM_DS                        ,
  Null                                                      as PAR_USCM_USCM_DS                   ,
  Null                                                      as PAR_USCM_REGUSCM                   ,
  Null                                                      as PAR_USCM_REGUSCM_DS                ,
  Placement.PAR_IMEI_CD                                     as PAR_MOB_IMEI                       ,
  Placement.PAR_TAC_CD                                      as PAR_MOB_TAC                        ,
  Null                                                      as PAR_MOB_SIM                        ,
  Placement.PAR_IMSI_CD                                     as PAR_MOB_IMSI                       ,
  Placement.PAR_EXTERNAL_PARTY_ID                           as PAR_EXTERNAL_PARTY_ID              ,
  Placement.PAR_SCORE_NU_INT                                as PAR_SCORE_NU_INT                   ,
  Placement.PAR_SCORE_IN_INT                                as PAR_SCORE_IN_INT                   ,
  Placement.PAR_TRESHOLD_NU_INT                             as PAR_TRESHOLD_NU_INT                ,
  Placement.PAR_SCORE_NU_MOB                                as PAR_SCORE_NU_MOB                   ,
  Placement.PAR_SCORE_IN_MOB                                as PAR_SCORE_IN_MOB                   ,
  Placement.PAR_TRESHOLD_NU_MOB                             as PAR_TRESHOLD_NU_MOB                ,
  Placement.CONTRCT_DT_SIGN_PREC_INT                        as CONTRCT_DT_SIGN_PREC_INT           ,
  Placement.CONTRCT_DT_FIN_PREC_INT                         as CONTRCT_DT_FIN_PREC_INT            ,
  Placement.CONTRCT_DT_DEB_SIGN_POST_INT                    as CONTRCT_DT_DEB_SIGN_POST_INT       ,
  Placement.CONTRCT_DT_FIN_SIGN_POST_INT                    as CONTRCT_DT_FIN_SIGN_POST_INT       ,
  Placement.DUREE_ENGAGEMENT_INT                            as DUREE_ENGAGEMENT_INT               ,
  Placement.TYPE_DUR_ENGAGEMENT_INT                         as TYPE_DUR_ENGAGEMENT_INT            ,
  Placement.CONTRCT_DT_SIGN_PREC_MOB                        as CONTRCT_DT_SIGN_PREC_MOB           ,
  Placement.CONTRCT_DT_FIN_PREC_MOB                         as CONTRCT_DT_FIN_PREC_MOB            ,
  Placement.CONTRCT_DT_SIGN_POST_MOB                        as CONTRCT_DT_SIGN_POST_MOB           ,
  Placement.CONTRCT_DUREE_ENG_MOB                           as CONTRCT_DUREE_ENG_MOB              ,
  Placement.CONTRCT_UNIT_ENG_MOB                            as CONTRCT_UNIT_ENG_MOB               ,
  Null                                                      as CONFIRMATION_IN                    ,
  Null                                                      as CONFIRMATION_DT                    ,
  Null                                                      as CONFIRMATION_CALC_FIN_DT           ,
  Null                                                      as DELIVERY_IN                        ,
  Perennite.SEG_FIND_LIVR_DT                                as DELIVERY_DT                        ,
  Null                                                      as DELIVERY_CALC_FIN_DT               ,
  Null                                                      as PERENNITE_IN                       ,
  Null                                                      as PERENNITE_FIN_DT                   ,
  Null                                                      as PERENNITE_CALC_FIN_DT              ,
  --Indicateur Perennité PVC
  --------------------------------------------------------------------------------------------------
  Perennite.PERENNITE_PVC_IN                                as PERENNITE_PVC_IN              ,
  Perennite.PERENNITE_PVC_FIN_DT                            as PERENNITE_PVC_FIN_DT          ,
  Perennite.PERENNITE_PVC_CALC_FIN_DT                       as PERENNITE_PVC_CALC_FIN_DT     ,
  --Indicateur Complémentaire
  --------------------------------------------------------------------------------------------------
  Perennite.SEG_COM_ID_LAST_PER                             as SEG_COM_ID_LAST_PER           ,
  Perennite.SEG_COM_ID_SOLD                                 as SEG_COM_ID_SOLD               ,
  Perennite.SEG_COM_ID_FIND                                 as SEG_COM_ID_FIND               ,
  Perennite.SEG_FIND_LIVR_DT                                as SEG_FIND_LIVR_DT              ,
  Perennite.SEG_FIND_CANCEL_DT                              as SEG_FIND_CANCEL_DT            ,
  Perennite.SEG_COM_ID_NEXT_PARC                            as SEG_COM_ID_NEXT_PARC          ,
  Perennite.SEG_NEXT_PARC_LIVR_DT                           as SEG_NEXT_PARC_LIVR_DT         ,
  Perennite.SEG_NEXT_PARC_CANCEL_DT                         as SEG_NEXT_PARC_CANCEL_DT       ,
  Perennite.SEG_COM_ID_FINAL_PARC                           as SEG_COM_ID_FINAL_PARC         ,
  Perennite.SEG_FINAL_PARC_LIVR_DT                          as SEG_FINAL_PARC_LIVR_DT        ,
  Perennite.SEG_FINAL_PARC_CANCEL_DT                        as SEG_FINAL_PARC_CANCEL_DT      ,
  Perennite.SEG_COM_ID_LAST_IN_PARC                         as SEG_COM_ID_LAST_IN_PARC       ,
  Perennite.NB_IN_OUT_PARC                                  as NB_IN_OUT_PARC                ,
  Perennite.POURCENTAGE_PRES_PARC                           as POURCENTAGE_PRES_PARC         ,
  --Indicateur Si déjà en parc lors de la commande
  ----------------------------------------------------------------------------
  Case  When SegDejaPres.ACTE_ID Is Not Null
          Then  1
        Else    0
  End                                                       as SEG_PRES_PARC_COMMANDE             ,
  -- Indicateur Sur la commande
  ---------------------------------------------------------------------------
  Null                                                      as SEG_COM_ID_ORDER_ID          ,
  Null                                                      as SEG_ORDER_DT                 ,
  Null                                                      as SEG_CANCEL_DT                ,
  Null                                                      as SEG_COM_ID_NEXT_ORDER        ,
  Null                                                      as SEG_NEXT_ORDER_DT            ,
  Null                                                      as SEG_NEXT_CANCEL_DT           ,
  Null                                                      as SEG_COM_ID_FINAL_ORDER       ,
  Null                                                      as SEG_FINAL_ORDER_DT           ,
  Null                                                      as SEG_FINAL_ORDER_CANCEL_DT    ,
  ----------------------------------------------------------------------------
  --Calcul si la livraison à eu lieu dans les temps :
  Case  When Perennite.SEG_FIND_LIVR_DT is Null
            Then 'NA'
        When Delais.DELAIS is Null 
          --Dans le cas où le delais est null alors on a pas pu évaluer : NC
          Then 'NC'
        When ( ActeSoft.ORDER_DEPOSIT_DT + Cast(Delais.DELAIS as interval day(4))) >= Perennite.SEG_FIND_LIVR_DT
          -- Dans le cas où on est dans le délais :
          Then  'O'
          --Sinon on n'est pas dans les clous
        Else    'N'
  End                                                       as DELIVERY_ONTIME_IN                 ,
  Coalesce(Delais.DELAIS,-1)                                as DELIVERY_DEAD_LINE_NU              ,
  ----------------------------------------------------------------------------
  Null                                                      as CONCURENCE_IN                      ,
  Null                                                      as CONCURENCE_CONCLU_IN               ,
  Null                                                      as CONCURENCE_ID                      ,
  --Indicateur de Migration :
  ----------------------------------------------------------------------------
  Perennite.SEG_NEXT_PARC_LIVR_DT                           as MIGRA_DT                           ,
  Perennite.SEG_COM_ID_NEXT_PARC                            as MIGRA_NEXT_OFFRE                   ,
  --Indicateur de Resiliation :
  ----------------------------------------------------------------------------
  Placement.RESIL_MOB_DT                                    as RESIL_INT_DT                       ,
  Placement.RESIL_MOB_MOTIF                                 as RESIL_INT_MOTIF                    ,
  Placement.RESIL_MOB_MOTIF_DS                              as RESIL_INT_MOTIF_DS                 ,
  ----------------------------------------------------------------------------
  /*Case  When Placement.RESIL_MOB_MOTIF='CHAPP'
          Then 'O'
        Else Perennite.PERNNT_IN
  End
  */
  Perennite.PERNNT_IN                                        As PERNNT_IN                          ,
  /*  Case  When Placement.RESIL_MOB_MOTIF='CHAPP'
          Then Null
        Else Perennite.PERNNT_END_DT
  End
  */
  Perennite.PERNNT_END_DT                                    As PERNNT_END_DT                      ,
  /*Case  When Placement.RESIL_MOB_MOTIF='CHAPP'
          Then Null
        Else Perennite.PERNNT_MOTIF
  End
  */
  Perennite.PERNNT_MOTIF                                     As PERNNT_MOTIF                       ,
  /*Case  When Placement.RESIL_MOB_MOTIF='CHAPP'
          Then Placement.ORDER_DEPOSIT_DT + 60
        Else Perennite.PERNNT_CALC_END_DT 
  End */
  Perennite.PERNNT_CALC_END_DT                               As PERNNT_CALC_END_DT                 ,
  --------------------------------------------------------------------------
  --Indicateur d'annulation :
   VADCancel.ORDER_CANCELING_DT                             as ORDER_CANCELING_DT                 ,
  ----------------------------------------------------------------------------
  Null                                                      as CHECK_INITIAL_STATUS_CD            ,
  RetournCSO.CHECK_NAT_STATUS_CD                            as CHECK_NAT_STATUS_CD                ,
  RetournCSO.CHECK_NAT_COMMENT                              as CHECK_NAT_COMMENT                  ,
  RetournCSO.CHECK_NAT_STATUS_LN                            as CHECK_NAT_STATUS_LN                ,
  RetournCSO.CHECK_LOC_STATUS_CD                            as CHECK_LOC_STATUS_CD                ,
  RetournCSO.CHECK_LOC_COMMENT                              as CHECK_LOC_COMMENT                  ,
  RetournCSO.CHECK_LOC_STATUS_LN                            as CHECK_LOC_STATUS_LN                ,
  RetournCSO.CHECK_VALIDT_DT                                as CHECK_VALIDT_DT                    ,
  --Indicateur Acte Complémentaire (tracage Automatique):
  ----------------------------------------------------------------------------
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID Is Not Null and TraceAutoEtk.EXT_APPLI_ID Is Not Null )
          Then '${P_INT_031}'
        When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID Is Not Null and TraceAutoEtk.EXT_APPLI_ID Is  Null )
          Then  '${P_PIL_520}'
       Else TraceAuto.CPLT_ACTE_ID
  End                                                     as CPLT_ACTE_ID                       ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then TraceAutoEtk.ORDR_ID
       Else  TraceAuto.CPLT_EXT_INT_ID
   End                                                    as CPLT_EXT_INT_ID                    ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_EXT_INT_DELT_ID
   End                                                    as CPLT_EXT_INT_DELT_ID               ,
  Case When (NSW2.EDO_ID is not null or NSW3.EDO_ID is not null)
        Then Coalesce(NSW2.EDO_ID,NSW3.EDO_ID)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_EDO_ID
   End                                                    as CPLT_ORG_EDO_ID                    ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_TYPE_EDO
   End                                                    as CPLT_ORG_TYPE_EDO                  ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_FLAG_PLT_CONV
   End                                                     as CPLT_ORG_FLAG_PLT_CONV            ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_FLAG_TEAM_MKT
   End                                                     as CPLT_ORG_FLAG_TEAM_MKT            ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_FLAG_TYPE_CMP
   End                                                     as CPLT_ORG_FLAG_TYPE_CMP            ,
    Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_REM_CHANNEL_CD
   End                                                    as CPLT_ORG_REM_CHANNEL_CD            ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_CHANNEL_CD
   End                                                    as CPLT_ORG_CHANNEL_CD                ,
  Case 
        When (NSW2.ORG_SUB_CHANEL_CD is not null or NSW3.ORG_SUB_CHANEL_CD is not null)
        Then Coalesce(NSW2.ORG_SUB_CHANEL_CD,NSW3.ORG_SUB_CHANEL_CD)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_SUB_CHANNEL_CD
   End                                                    as CPLT_ORG_SUB_CHANNEL_CD            ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_SUB_SUB_CHANNEL_CD
   End                                                    as CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
     Case 
       When (NSW2.ORG_GT_ACTIVITY is not null or NSW3.ORG_GT_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_GT_ACTIVITY,NSW3.ORG_GT_ACTIVITY) 
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_GT_ACTIVITY
   End                                                    as CPLT_ORG_GT_ACTIVITY                ,
   Case When(TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_FIDELISATION
   End                                                    as CPLT_ORG_FIDELISATION               ,
    Case 
        When (NSW2.ORG_WEB_ACTIVITY is not null or NSW3.ORG_WEB_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_WEB_ACTIVITY,NSW3.ORG_WEB_ACTIVITY)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_WEB_ACTIVITY
   End                                                    as CPLT_ORG_WEB_ACTIVITY               ,
    Case
        When (NSW2.ORG_AUTO_ACTIVITY is not null or NSW3.ORG_AUTO_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_AUTO_ACTIVITY,NSW3.ORG_AUTO_ACTIVITY)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_AUTO_ACTIVITY
   End                                                    as CPLT_ORG_AUTO_ACTIVITY              ,
   Case When(TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then NULL 
       Else  TraceAuto.CPLT_EXTERNAL_TEAM_CD
   End                                                    as CPLT_EXTERNAL_TEAM_CD               ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then NULL 
       Else  TraceAuto.CPLT_O3_ACTIVE_TEAM_CD
   End                                                    as CPLT_O3_ACTIVE_TEAM_CD              ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then NULL 
       Else  TraceAuto.CPLT_O3_RATTACHEMENT_TEAM_CD
   End                                                    as CPLT_O3_RATTACHEMENT_TEAM_CD        ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_AGENT_ID_UPD
   End                                                    as CPLT_AGENT_ID_UPD                   ,
    Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_INT_SRC
   End                                                    as CPLT_INT_SRC                        ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_INT_REASON
   End                                                    as CPLT_INT_REASON                     ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_INT_RESULT
   End                                                    as CPLT_INT_RESULT                     ,
  ----------------------------------------------------------------------------
  --Cas de cloture de l'acte :
  Case  When Placement.FLAG_FIRST_RECEPTION_PSF not in (0,1)
          Then Placement.ORDER_DEPOSIT_DT
        Else  Null
  End                                                       as CLOSURE_DT                         ,
  Placement.QUEUE_TS                                        as QUEUE_TS                           ,
  Placement.RUN_ID                                          as RUN_ID                             ,
  Placement.STREAMING_TS                                    as STREAMING_TS                       ,
  '${KNB_DATE_VACATION}'                                    as CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                    as LAST_MODIF_TS                      ,
  0                                                         as HOT_IN                             ,
  1                                                         as FRESH_IN                           ,
  0                                                         as COHERENCE_IN                       
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_MOB Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_CAL ActeSoft
    On    Placement.ACTE_ID           = ActeSoft.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = ActeSoft.ORDER_DEPOSIT_DT
    --Jointure récupérer les infos de la table des matrices
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On  Case  When Placement.EXT_OPER_ID = '${P_PIL_099}' And ActeSoft.TYPE_COMMANDE_ID = '${P_PIL_026}'
                Then '${P_PIL_018}'
              -- Sinon on remet le type commande de sortie
              Else  ActeSoft.TYPE_COMMANDE_ID
        End                                                 = Mat.TYPE_COMMANDE_ID
      And ActeSoft.SEG_COM_ID_FINAL                         = Mat.SEG_COM_ID_FINAL
      And ActeSoft.PERIODE_ID                               = Mat.PERIODE_ID
      And Coalesce(ActeSoft.SEG_COM_ID_PRE,'${P_PIL_211}')  = Mat.SEG_COM_ID_INI
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT Orga
    On    Placement.DISTRBTN_CHANNL_ID                        = Orga.DISTRBTN_CHANNL_ID
      And Placement.FLAG_PLT_CONV                             = Orga.FLAG_PLT_CONV
      And Placement.FLAG_TEAM_MKT                             = Orga.FLAG_TEAM_MKT
      And Placement.FLAG_TYPE_CMP                             = Orga.FLAG_TYPE_CMP
      And Orga.FRESH_IN                                       = 1
      And Orga.CURRENT_IN                                     = 1
      And Orga.CLOSURE_DT                                     is Null
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_WEB Orgaweb
    On    Placement.DISTRBTN_CHANNL_ID                        = Orgaweb.ORG_CHANNL_ID
      And Placement.STORE_NAME                                = Orgaweb.ORG_PDV_CD
      And Orgaweb.FRESH_IN                                       = 1
      And Orgaweb.CURRENT_IN                                     = 1
      And Orgaweb.CLOSURE_DT                                     is Null
    -- Jointure avec la Matrice du PDV ATH  
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_PDV OrgaPDV
    On    Placement.DISTRBTN_CHANNL_ID                        = OrgaPDV.DISTRBTN_CHANNL_ID
      And Placement.STORE_NAME                                = OrgaPDV.PDV
      And OrgaPDV.FRESH_IN                                    = 1
      And OrgaPDV.CURRENT_IN                                  = 1
      And OrgaPDV.CLOSURE_DT                                  is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID                                   = RetourGRV.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = RetourGRV.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                                   = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG                       = 1
      And RetournCSO.CURRENT_IN                               = 1
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_PER_FULL Perennite
    On    Placement.ACTE_ID                                   = Perennite.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = Perennite.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_SEGDEJPRES SegDejaPres
    On    Placement.ACTE_ID                                   = SegDejaPres.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = SegDejaPres.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_TRC_AUTO TraceAuto
    On    Placement.ACTE_ID                                   = TraceAuto.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = TraceAuto.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACT_ETASK_MOB_C_TRC_AUTO TraceAutoEtk
    On    Placement.ACTE_ID                                   = TraceAutoEtk.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = TraceAutoEtk.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_ORGO3 OrgO3Enri
    On    Placement.ACTE_ID                                   = OrgO3Enri.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = OrgO3Enri.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    ActeSoft.PERIODE_ID                                 = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                              = 1
      And EtatPeriode.FRESH_IN                                = 1
      And EtatPeriode.CLOSURE_DT                              Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais
    On    ActeSoft.TYPE_COMMANDE_ID                           = Delais.TYPE_COMMANDE_ID
      And ActeSoft.TYPE_SERVICE_FINAL                         = Delais.TYPE_SERVICE
      And ActeSoft.PERIODE_ID                                 = Delais.PERIODE_ID
      And Delais.FRESH_IN                                     = 1
      And Delais.CURRENT_IN                                   = 1
      And Delais.CLOSURE_DT                                   is Null
 Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_ORDER_CANCEL VADCancel
    On    Placement.ACTE_ID                                   = VADCancel.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = VADCancel.ORDER_DEPOSIT_DT 
 Left Outer Join  ${KNB_PCO_SOC}.ORG_R_CHANNEL_ENRICH_NSW NSW2 -- MyShop
    On    Placement.ENR6PO_ORDR_ORGN = NSW2.ORDR_MSH_ORGN_DS and Placement.ENR6PO_TYPE_PF = NSW2.ORG_CHANNL_ID And NSW2.ORG_CHANNL_ID = '${P_PIL_630}'
 Left Outer Join  ${KNB_PCO_SOC}.ORG_R_CHANNEL_ENRICH_NSW NSW3 -- MyShopDOM
    On    Placement.ENR6PO_ORDR_ORGN = NSW3.ORDR_MSH_ORGN_DS and Placement.ENR6PO_TYPE_PF = NSW3.ORG_CHANNL_ID And NSW3.ORG_CHANNL_ID = '${P_PIL_631}'
	  
Where
  (1=1)
  --Tous les RMP sont Purgés des actes car on fait porter le maintient sans la suppression
  And Placement.EXT_OPER_ID not in ('${P_PIL_098}')
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_MOB;
.if errorcode <> 0 then .quit 1


