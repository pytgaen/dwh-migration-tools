-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Acte_Consolidation_CalculActe_Step1.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul Acte EDL
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
-- 27/05/2015      HFO         MODIFICATION   QC 1060
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_ACTE_EDL_CALC all;
.if errorcode <> 0 then .quit 1


------------------------------------------------------------------------------------------
-- Calcul des cas de migrations
------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_EDL_CALC
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PERIODE_ID                  ,
  PRODUCT_ID_PRE              ,
  SEG_COM_ID_PRE              ,
  SEG_COM_AGG_ID_PRE          ,
  CODE_MIGR_PRE               ,
  PRODUCT_ID_FINAL            ,
  SEG_COM_ID_FINAL            ,
  SEG_COM_AGG_ID_FINAL        ,
  CODE_MIGR_FINAL             ,
  TYPE_SERVICE_FINAL          ,
  TYPE_COMMANDE_ID            ,
  DELTA_TARIF                 
)
Select
  ActeCreation.ACTE_ID                                                                    as ACTE_ID                        ,
  ActeCreation.INT_DEPOSIT_DT                                                             as INT_DEPOSIT_DT                 ,
  ActeCreation.PERIODE_ID                                                                 as PERIODE_ID                     ,
  --Info sur le produit Précédant :
  ActeCreation.PRODUCT_ID_PRE                                                             as PRODUCT_ID_PRE                 ,
  --On ne valorise le produit précédant que lorsqu'on a détecter une migration :
  Case  When MatMig.CODE_MIGRATION_INITIAL Is Not Null 
          Then ActeCreation.SEG_COM_ID_PRE
        Else Null
  End                                                                                     as SEG_COM_ID_PRE                 ,
  Case  When MatMig.CODE_MIGRATION_INITIAL Is Not Null 
          Then ActeCreation.SEG_COM_AGG_ID_PRE
        Else Null
  End                                                                                     as SEG_COM_AGG_ID_PRE             ,
  ActeCreation.CODE_MIGRATION_PRE                                                         as CODE_MIGR_PRE                  ,
  ActeCreation.PRODUCT_ID                                                                 as PRODUCT_ID_FINAL               ,
  ActeCreation.SEG_COM_ID                                                                 as SEG_COM_ID_FINAL               ,
  ActeCreation.SEG_COM_AGG_ID                                                             as SEG_COM_AGG_ID_FINAL           ,
  ActeCreation.CODE_MIGRATION                                                             as CODE_MIGR_FINAL                ,
  ActeCreation.TYPE_SERVICE                                                               as TYPE_SERVICE_FINAL             ,
  Case  --Lorsque le code migration précédant n'est pas valorisé :
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_016}'
          Then '${P_PIL_026}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_017}'
          Then '${P_PIL_027}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_018}'
          Then '${P_PIL_028}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_077}'
          Then '${P_PIL_078}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_045}'
          Then '${P_PIL_044}'
        --On teste ensuite si on doit ou pas calculer le delta tarif
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_101}' --Si on ne doit pas exploiter le delta tarif alors c'est le type commande (+le suffix)
          Then MatMig.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_100}' --Cas ou on doit exploiter le delta tarif
          Then DeltaTarif.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        Else Trim(ActeCreation.TYPE_COMMANDE)
  End                                                                                     as TYPE_COMMANDE_ID             ,
  (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0))             as DELTA_TARIF                  
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.INT_W_ACTE_EDL_EXRACT ActeCreation
  --Jointure sur la matrice de migration suivant le produit final + le mouvement Final
  Left Outer Join  ${KNB_PCO_REFCOM}.CAT_R_MAT_MIGR_PILCOM MatMig
    On    ActeCreation.CODE_MIGRATION                                                   = MatMig.CODE_MIGRATION_FINAL
      And 'ADD'                                                                         = MatMig.MOUVEMENT_FINAL
      And ActeCreation.CODE_MIGRATION_PRE                                               = MatMig.CODE_MIGRATION_INITIAL
      And 'RMV'                                                                         = MatMig.MOUVEMENT_INITIAL
      And ActeCreation.PERIODE_ID                                                       = MatMig.PERIODE_ID
      And MatMig.FRESH_IN                                                               = 1
      And MatMig.CURRENT_IN                                                             = 1
      And MatMig.CLOSURE_DT                                                             Is Null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PRIX_TYPE_COMMANDE DeltaTarif --On réalise le delta tarif entre l'offre avant/Apres
    On    (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0))   >= DeltaTarif.VAL_MIN
      And (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0))   <= DeltaTarif.VAL_MAX
      And ActeCreation.PERIODE_ID                                                       = DeltaTarif.PERIODE_ID
      And DeltaTarif.CURRENT_IN                                                         = 1
      And DeltaTarif.CLOSURE_DT                                                         Is Null
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE = 1
Group by
  ActeCreation.ACTE_ID                                                                    ,
  ActeCreation.INT_DEPOSIT_DT                                                             ,
  ActeCreation.PERIODE_ID                                                                 ,
  --Info sur le produit Précédant :
  ActeCreation.PRODUCT_ID_PRE                                                             ,
  --On ne valorise le produit précédant que lorsqu'on a détecter une migration :
  Case  When MatMig.CODE_MIGRATION_INITIAL Is Not Null 
          Then ActeCreation.SEG_COM_ID_PRE
        Else Null
  End                                                                                     ,
  --On ne valorise le produit précédant que lorsqu'on a détecter une migration :
  Case  When MatMig.CODE_MIGRATION_INITIAL Is Not Null 
          Then ActeCreation.SEG_COM_AGG_ID_PRE
        Else Null
  End                                                                                     ,
  ActeCreation.CODE_MIGRATION_PRE                                                         ,
  ActeCreation.PRODUCT_ID                                                                 ,
  ActeCreation.SEG_COM_ID                                                                 ,
  ActeCreation.SEG_COM_AGG_ID                                                             ,
  ActeCreation.CODE_MIGRATION                                                             ,
  ActeCreation.TYPE_SERVICE                                                               ,
  Case  --Lorsque le code migration précédant n'est pas valorisé :
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_016}'
          Then '${P_PIL_026}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_017}'
          Then '${P_PIL_027}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_018}'
          Then '${P_PIL_028}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_077}'
          Then '${P_PIL_078}'
        When ActeCreation.CODE_MIGRATION_PRE is null And ActeCreation.TYPE_COMMANDE = '${P_PIL_045}'
          Then '${P_PIL_044}'
        --On teste ensuite si on doit ou pas calculer le delta tarif
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_101}' --Si on ne doit pas exploiter le delta tarif alors c'est le type commande (+le suffix)
          Then MatMig.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_100}' --Cas ou on doit exploiter le delta tarif
          Then DeltaTarif.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        Else Trim(ActeCreation.TYPE_COMMANDE)
  End                                                                                     ,
  (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0))             


------------------------------------------------------------------------------------------
-- Calcul des cas de sans migrations
------------------------------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_ACTE_EDL_CALC
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PERIODE_ID                  ,
  PRODUCT_ID_PRE              ,
  SEG_COM_ID_PRE              ,
  SEG_COM_AGG_ID_PRE          ,
  CODE_MIGR_PRE               ,
  PRODUCT_ID_FINAL            ,
  SEG_COM_ID_FINAL            ,
  SEG_COM_AGG_ID_FINAL        ,
  CODE_MIGR_FINAL             ,
  TYPE_SERVICE_FINAL          ,
  TYPE_COMMANDE_ID            ,
  DELTA_TARIF                 
)
Select
  ActeCreation.ACTE_ID                  as ACTE_ID                ,
  ActeCreation.INT_DEPOSIT_DT           as INT_DEPOSIT_DT         ,
  ActeCreation.PERIODE_ID               as PERIODE_ID             ,
  ActeCreation.PRODUCT_ID_PRE           as PRODUCT_ID_PRE         ,
  Null                                  as SEG_COM_ID_PRE         ,
  Null                                  as SEG_COM_AGG_ID_PRE     ,
  Null                                  as CODE_MIGR_PRE          ,
  ActeCreation.PRODUCT_ID               as PRODUCT_ID_FINAL       ,
  ActeCreation.SEG_COM_ID               as SEG_COM_ID_FINAL       ,
  ActeCreation.SEG_COM_AGG_ID           as SEG_COM_AGG_ID_FINAL   ,
  ActeCreation.CODE_MIGRATION           as CODE_MIGR_FINAL        ,
  ActeCreation.TYPE_SERVICE             as TYPE_SERVICE_FINAL     ,
  ActeCreation.TYPE_COMMANDE            as TYPE_COMMANDE_ID       ,
  Coalesce(ActeCreation.TARIF_HT,0)     as DELTA_TARIF            
From
  ${KNB_PCO_TMP}.INT_W_ACTE_EDL_EXRACT ActeCreation
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE = 0
Group by
  ActeCreation.ACTE_ID                  ,
  ActeCreation.INT_DEPOSIT_DT           ,
  ActeCreation.PERIODE_ID               ,
  ActeCreation.PRODUCT_ID_PRE           ,
  ActeCreation.PRODUCT_ID               ,
  ActeCreation.SEG_COM_ID               ,
  ActeCreation.SEG_COM_AGG_ID           ,
  ActeCreation.CODE_MIGRATION           ,
  ActeCreation.TYPE_SERVICE             ,
  ActeCreation.TYPE_COMMANDE            ,
  Coalesce(ActeCreation.TARIF_HT,0)     
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_EDL_CALC;
.if errorcode <> 0 then .quit 1


.quit 0

