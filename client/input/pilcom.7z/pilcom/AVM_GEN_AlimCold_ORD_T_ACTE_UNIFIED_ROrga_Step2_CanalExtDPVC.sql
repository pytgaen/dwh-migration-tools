-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    AVM_GEN_AlimCold_ORD_T_ACTE_UNIFIED_ROrga_Step2_CanalExtDPVC.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 11/02/2015      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_DPVC All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
--Insert DPVC
Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_DPVC
(
  ACTE_ID                       ,
  ORG_CANAL_ID                  
)
Select
  RefId.ACTE_ID                                 As ACTE_ID              ,
  RefDPVC.ORG_CHANNEL_CD                        As ORG_CANAL_ID         
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG RefId
  Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_DECLAR_PVC RefDPVC
    On RefId.ACTE_ID      = RefDPVC.ACTE_ID
Where
  (1=1)
  And RefDPVC.ORG_CHANNEL_CD       in ('CCO','SCH')
Qualify Row_number() over (Partition by RefId.ACTE_ID Order By  RefDPVC.ORG_CHANNEL_CD Asc) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_DPVC;
.if errorcode <> 0 then .quit 1

.quit 0


