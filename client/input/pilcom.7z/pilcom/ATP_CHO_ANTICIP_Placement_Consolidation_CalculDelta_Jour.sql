-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_ANTICIP_Placement_Consolidation_CalculDelta_Jour.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Consolidation Calcul Palcement Chorus Anticipé
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 25/02/2014      AID         Indus
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.INT_W_EXRACT_CHO all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_EXRACT_CHO
(
  EXTERNAL_ACTE_ID        ,
  EXTERNAL_INT_ID         ,
  TYPE_SOURCE_ID          ,
  INT_DEPOSIT_TS          ,
  INT_DEPOSIT_DT          ,
  OPERATOR_PROVIDER_ID    ,
  RESOLU_ID               ,
  CONCLU_ID               ,
  TYPE_COMMANDE           ,
  PLTF_CO                 ,
  INTRNL_SOURCE_ID        ,
  SOLDOFF_SRC_CD          ,
  PRODUCT_ID              ,
  OTO_OFFER_CD            ,
  OTO_OFFER_TYPE_CD       ,
  LOGIN_CREA              ,
  LOGIN_RESP              ,
  INT_MODIF_TS            ,
  CANALVENTE              ,
  OTO_OSCAR_VALUE_NU      ,
  PRODUIT_PRINCIPAL_CHO   ,
  IN_CLIDOS               ,
  TYPE_OT_SO              
)
Select
  --Génération de la clé de la demande :
  Trim(Commande.LEAD_ID)||Trim('S')||Trim(Cast(LigneCommande.SEQNUM_NB as char(5)))           as EXTERNAL_ACTE_ID       ,
  Trim(Commande.LEAD_ID)                                                                      as EXTERNAL_INT_ID        ,
  ${IdentifiantTechniqueSource}                                                               as TYPE_SOURCE_ID         ,
  Commande.ROW_ADDED_TS                                                                       as INT_DEPOSIT_TS         ,
  Cast(Commande.ROW_ADDED_TS as date format 'YYYYMMDD')                                       as INT_DEPOSIT_DT         ,
  Commande.BUSINESS_UNIT_ID                                                                   as OPERATOR_PROVIDER_ID   ,
  Commande.LEAD_TYPE_CD                                                                       as RESOLU_ID              ,
  LigneCommande.OFFER_STATUS_CD                                                               as CONCLU_ID              ,
  -- On calcul le type de commande par défaut :
   Case
        --Dans le cas des Lignes Internet on regarde le type de ligne de panier
        --Il s'agit par exemple des migration Internet => Open
        -- Si la ligne de panier est : MCC,GOC,MOC alors c'est un Maintien
        When LigneCommande.SOLDOFF_SRC_CD in (${L_PIL_009})
          Then '${P_PIL_018}'
        -- Si la ligne de panier est : SOC alors c'est une Suppression
        When LigneCommande.SOLDOFF_SRC_CD in (${L_PIL_010})
          Then '${P_PIL_017}'
        -- Si la ligne de panier est : GCC alors c'est une Migration
        When LigneCommande.SOLDOFF_SRC_CD in (${L_PIL_011})
          Then '${P_PIL_077}'
        -- Si la ligne de panier est : NCC,AOC alors c'est une Acquisition
        When LigneCommande.SOLDOFF_SRC_CD in (${L_PIL_012})
          Then '${P_PIL_016}'
        ---------------------------------------------------------------------------------
        --Cas des lignes de commandes Internet
        -- Si c'est un OT alors le type de commande par défault est FIDELISATION
        When Substring(Trim(LigneCommande.PRODUCT_ID) from 1 for 2) in (${L_PIL_004})
          Then '${P_PIL_045}'
        -- Sinon c'est un SO donc une Acquisition
        Else '${P_PIL_016}'
  End                                                                                         as TYPE_COMMANDE          ,
  Commande.APPLI_SOURCE_ID                                                                    as PLTF_CO                ,
  ${IdSourceInterne}                                                                          as INTRNL_SOURCE_ID       ,
  LigneCommande.SOLDOFF_SRC_CD                                                                as SOLDOFF_SRC_CD         ,
  LigneCommande.PRODUCT_ID                                                                    as PRODUCT_ID             ,
  LigneCommande.OTO_OFFER_CD                                                                  as OTO_OFFER_CD           ,
  LigneCommande.OTO_OFFER_TYPE_CD                                                             as OTO_OFFER_TYPE_CD      ,
  LigneCommande.ADDED_OPRID_CD                                                                as LOGIN_CREA             ,
  LigneCommande.LASTMANT_OPRID_CD                                                             as LOGIN_RESP             ,
  LigneCommande.LASTMANT_TS                                                                   as INT_MODIF_TS           ,
  -- Le canal de vente CHORUS est dans les données de fait dans le code résolu :
  Commande.LEAD_TYPE_CD                                                                       as CANALVENTE             ,
  Commande.OTO_OSCAR_VALUE_NU                                                                 as OTO_OSCAR_VALUE_NU     ,
  --Dans Chorus on a que des demandes de type dossier
  Commande.INST_PROD_ID                                                                       as PRODUIT_PRINCIPAL_CHO  ,
  '${P_PIL_059}'                                                                              as IN_CLIDOS              ,
  Case  --On partitionnne le produit placé pour connaitre le type du produit :
        -- OT / SO / OC / OA...
        --On détermine les OT : Forfait Mobile
        When Substring(Trim(LigneCommande.PRODUCT_ID) from 1 for 2) in (${L_PIL_004})
          Then '${P_PIL_040}'
        --On détermine les SO : les options mobiles + l'OC internet
        When Substring(Trim(LigneCommande.PRODUCT_ID) from 1 for 2) in (${L_PIL_007})
          Then '${P_PIL_041}'
        --Le cas des options Internet OA : ça commence par un O
        When Substring(Trim(LigneCommande.PRODUCT_ID) from 1 for 1) in (${L_PIL_008})
          Then '${P_PIL_041}'
        --Le cas où le produit est un PCM
        When Substring(Trim(LigneCommande.PRODUCT_ID) from 1 for 3) in (${L_PIL_013})
          Then '${P_PIL_038}'
        Else Null
  End                                                                                       as TYPE_OT_SO               
From
  ${KNB_IBU_ODS}.ORD_F_ORDER_CHO Commande
  Inner Join ${KNB_IBU_ODS}.ORD_F_ORDER_LINE_CHO LigneCommande
    On    Commande.LEAD_ID = LigneCommande.LEAD_ID
Where
  (1=1)
   --Restriction sur les statut de la ligne de panier
  And LigneCommande.OFFER_STATUS_CD   In (${L_PIL_003})
  --Filtre Statut de la propostion commerciale
  And Commande.LEAD_STATUS_CD         In (${L_PIL_005})
  --Restriction sur l'opérateur de comm
  And Commande.BUSINESS_UNIT_ID       In (${L_PIL_006})
  --On supprime si on a pas de produit placé 
  And LigneCommande.OTO_OFFER_TYPE_CD is not Null
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_EXRACT_CHO;
.if errorcode <> 0 then .quit 1


