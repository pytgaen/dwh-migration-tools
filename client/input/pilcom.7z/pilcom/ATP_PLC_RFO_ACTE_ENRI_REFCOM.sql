-----------------------------------------------------------------------------------------
-- $HEADER: %HEADER%
-----------------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_PLC_HRF_ACTE_ENRI_REFCOM.sql                         $
-- TYPE         : Script SQL                                                            -
-- DESCRIPTION  : Perimetre RF - PLACEMENT - PREPARATION DES ACTES                      -
-----------------------------------------------------------------------------------------
--                 HISTORIQUE                                                           -
-- DATE            AUTEUR      CREATION/MODIFICATION                                    -
-- 26/06/13        DARTIGUE    Creation                                                 -
-- 10/01/14        AID         Modification mise ne norme DSM                           -
-- 04/09/14        YZH         EVOL VIO
-- 03/06/2016      MDE         Modif / REFCOM KNB_PCO_REFCOM 
-----------------------------------------------------------------------------------------
.SET WIDTH 2000;

-- PURGE DU TAMPON

DELETE FROM      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
                  (
                    ACTE_ID_GEN
                  , ACTE_ID
                  , ACTE_TYPOLOGIE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , FREG_PARTY_ID
                  , CONCURENCE_IN
                  , CONCURENCE_CONCLU_IN
                  , CONCURENCE_ID
                  , _CONCURENCE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , PRODUCT_ID_FINAL
                  , SEG_COM_ID_FINAL
                  , SEG_COM_AGG_ID_FINAL
                  , CODE_MIGRATION_FINAL
                  , MIGR_REGROUPEMENT_ID_FINAL
                  , TYPE_SERVICE_FINAL
                  , INTRNL_PRDCT_ID_OPENCAT_INI
                  , PRODUCT_ID_INITIAL
                  , SEG_COM_ID_INITIAL
                  , SEG_COM_AGG_ID_INITIAL
                  , CODE_MIGRATION_INITIAL
                  , MIGR_REGROUPEMENT_ID_INITIAL
                  , TYPE_COMMANDE_ID
                  , PERIODE_ID
                  )
SELECT             INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN                                                                                AS ACTE_ID_GEN
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                                    AS ACTE_ID
              ,    1                                                                                                          AS ACTE_TYPOLOGIE
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_TS                                                                          AS INT_CREATED_BY_TS
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                          AS INT_CREATED_BY_DT
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.FREG_PARTY_ID                                                                              AS FREG_PARTY_ID
              ,    NULL                                                                                                       AS CONCURENCE_IN
              ,    NULL                                                                                                       AS CONCURENCE_CONCLU_IN
              ,    NULL                                                                                                       AS CONCURENCE_ID
                  -- LES INTERACTIONS DONT LE PRODUIT EST ABSENT DU REFENTIEL NE SONT PAS ELIGIBLES AU CALCUL DE CONCURRENCE
              ,    0                                                                                                          AS _CONCURENCE
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL                                                                  AS EXTERNAL_PRODUCT_ID_FINAL
              ,    NULL                                                                                                       AS PRODUCT_ID_FINAL
              ,    NULL                                                                                                       AS SEG_COM_ID_FINAL
              ,    NULL                                                                                                       AS SEG_COM_AGG_ID_FINAL
              ,    NULL                                                                                                       AS CODE_MIGRATION_FINAL
              ,    NULL                                                                                                       AS MIGR_REGROUPEMENT_ID_FINAL
              ,    NULL                                                                                                       AS TYPE_SERVICE_FINAL
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INTRNL_PRDCT_ID_OPENCAT_INI                                                                AS INTRNL_PRDCT_ID_OPENCAT_INI
              ,    NULL                                                                                                       AS PRODUCT_ID_INITIAL
              ,    NULL                                                                                                       AS SEG_COM_ID_INITIAL
              ,    NULL                                                                                                       AS SEG_COM_AGG_ID_INITIAL
              ,    NULL                                                                                                       AS CODE_MIGRATION_INITIAL
              ,    NULL                                                                                                       AS MIGR_REGROUPEMENT_ID_INITIAL
              ,    CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_022})
                        THEN '${P_PIL_016}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_023})
                        THEN '${P_PIL_103}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024})
                        THEN '${P_PIL_012}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_025})
                        THEN '${P_PIL_102}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_103}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_106}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_102}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_107}'
                   END                                                                                                        AS TYPE_COMMANDE_ID
              ,    NULL                                                                                                       AS PERIODE_ID
FROM             ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM                                                                                  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
WHERE              1                                                                                                   =         1
AND               (
                    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL_CH
                  , INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT
                  )                                                                                                    NOT IN
                  (
                    SELECT   V_CAT_R_REF_PRODUCT_RFORCE.EXT_PRODUCT_ID_1
                           , V_CAT_R_REF_PRODUCT_RFORCE.EXT_PRODUCT_ID_2
                    FROM   ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_RFORCE                     V_CAT_R_REF_PRODUCT_RFORCE
                  -- SELECTION DES PRODUITS EN ETAT COURANT ET NON CLOTURE
                    WHERE    1                                                 =         1
                    AND      V_CAT_R_REF_PRODUCT_RFORCE.CURRENT_IN             =         1
                    AND      V_CAT_R_REF_PRODUCT_RFORCE.CLOSURE_DT             IS NULL
                  )
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
                  (
                    ACTE_ID_GEN
                  , ACTE_ID
                  , ACTE_TYPOLOGIE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , FREG_PARTY_ID
                  , CONCURENCE_IN
                  , CONCURENCE_CONCLU_IN
                  , CONCURENCE_ID
                  , _CONCURENCE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , PRODUCT_ID_FINAL
                  , SEG_COM_ID_FINAL
                  , SEG_COM_AGG_ID_FINAL
                  , CODE_MIGRATION_FINAL
                  , MIGR_REGROUPEMENT_ID_FINAL
                  , TYPE_SERVICE_FINAL
                  , INTRNL_PRDCT_ID_OPENCAT_INI
                  , PRODUCT_ID_INITIAL
                  , SEG_COM_ID_INITIAL
                  , SEG_COM_AGG_ID_INITIAL
                  , CODE_MIGRATION_INITIAL
                  , MIGR_REGROUPEMENT_ID_INITIAL
                  , TYPE_COMMANDE_ID
                  , PERIODE_ID
                  )
SELECT             INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN                                                                                AS ACTE_ID_GEN
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                                    AS ACTE_ID
              ,    13                                                                                                         AS ACTE_TYPOLOGIE
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_TS                                                                          AS INT_CREATED_BY_TS
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                          AS INT_CREATED_BY_DT
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.FREG_PARTY_ID                                                                              AS FREG_PARTY_ID
              ,    NULL                                                                                                       AS CONCURENCE_IN
              ,    NULL                                                                                                       AS CONCURENCE_CONCLU_IN
              ,    NULL                                                                                                       AS CONCURENCE_ID
                  -- LES INTERACTIONS DONT LE PRODUIT EST ABSENT DU REFENTIEL NE SONT PAS ELIGIBLES AU CALCUL DE CONCURRENCE
              ,    0                                                                                                          AS _CONCURENCE
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL                                                                  AS EXTERNAL_PRODUCT_ID_FINAL
              ,    NULL                                                                                                       AS PRODUCT_ID_FINAL
              ,    NULL                                                                                                       AS SEG_COM_ID_FINAL
              ,    NULL                                                                                                       AS SEG_COM_AGG_ID_FINAL
              ,    NULL                                                                                                       AS CODE_MIGRATION_FINAL
              ,    NULL                                                                                                       AS MIGR_REGROUPEMENT_ID_FINAL
              ,    NULL                                                                                                       AS TYPE_SERVICE_FINAL
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INTRNL_PRDCT_ID_OPENCAT_INI                                                                AS INTRNL_PRDCT_ID_OPENCAT_INI
              ,    NULL                                                                                                       AS PRODUCT_ID_INITIAL
              ,    NULL                                                                                                       AS SEG_COM_ID_INITIAL
              ,    NULL                                                                                                       AS SEG_COM_AGG_ID_INITIAL
              ,    NULL                                                                                                       AS CODE_MIGRATION_INITIAL
              ,    NULL                                                                                                       AS MIGR_REGROUPEMENT_ID_INITIAL
              ,    CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_022})
                        THEN '${P_PIL_016}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_023})
                        THEN '${P_PIL_103}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024})
                        THEN '${P_PIL_012}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_025})
                        THEN '${P_PIL_102}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_103}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_106}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_102}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_107}'
                   END                                                                                                        AS TYPE_COMMANDE_ID
              ,    NULL                                                                                                       AS PERIODE_ID
FROM             ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM                                                                                  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
LEFT JOIN        ${KNB_PCO_TMP}.CAT_W_RFORCE_REFCOM                                                                              CAT_W_RFORCE_REFCOM
ON                 1                                                                                                   =         1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL                                                           =         CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT                                                                          =         CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_2
WHERE              1                                                                                                   =         1
-- SEULS LES TRACAGES DONT LE PRODUIT EXISTE DANS LE CATALOGUE COMMERCIAL SONT CONSIDERES
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                             NOT IN
                  (
                    SELECT   INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM.ACTE_ID
                    FROM   ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM  INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
                  )
-- SEULS LES TRACAGES DONT LE COUPLE ( PRODUIT RFORCE, RESULTAT DE DETAIL DE CONTACT ) EST ABSENT SONT CONSIDEREES
AND                CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_1                                                                IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- (2) GESTION DES TRACAGES DONT LA DATE EST ABSENTE DU REFERENTIEL COMMERCIAL
-- APPLICABLE A TOUT TYPE D'ACTE: MIGRABLE OU NON MIGRABLE
-- LA DATE DU TRACAGE EST ABSENTE DU REFERENTIEL DES LORS QUE L'IDENTIFIANT DE PRODUIT EXTERNE N'EXISTE PAS POUR LA DATE CONSIDEREE DANS LE REFERENTIEL COMMERCIAL
-- IL S'AGIT D'UNE TYPOLOGIE DE TRACAGE DISTINCTE DE LA PRECEDENTE
-- L'ENSEMBLE DES ATTRIBUTS ISSUS DU REFERENTIEL COMMERCIAL NE SONT PAS VALORISES

INSERT INTO      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
                  (
                    ACTE_ID_GEN
                  , ACTE_ID
                  , ACTE_TYPOLOGIE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , FREG_PARTY_ID
                  , CONCURENCE_IN
                  , CONCURENCE_CONCLU_IN
                  , CONCURENCE_ID
                  , _CONCURENCE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , PRODUCT_ID_FINAL
                  , SEG_COM_ID_FINAL
                  , SEG_COM_AGG_ID_FINAL
                  , CODE_MIGRATION_FINAL
                  , MIGR_REGROUPEMENT_ID_FINAL
                  , TYPE_SERVICE_FINAL
                  , INTRNL_PRDCT_ID_OPENCAT_INI
                  , PRODUCT_ID_INITIAL
                  , SEG_COM_ID_INITIAL
                  , SEG_COM_AGG_ID_INITIAL
                  , CODE_MIGRATION_INITIAL
                  , MIGR_REGROUPEMENT_ID_INITIAL
                  , TYPE_COMMANDE_ID
                  , PERIODE_ID
                  )
SELECT             INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN                                                                                AS ACTE_ID_GEN
               ,   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                                    AS ACTE_ID
               ,   2                                                                                                          AS ACTE_TYPOLOGIE
               ,   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_TS                                                                          AS INT_CREATED_BY_TS
               ,   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                          AS INT_CREATED_BY_DT
               ,   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.FREG_PARTY_ID                                                                              AS FREG_PARTY_ID
               ,   NULL                                                                                                       AS CONCURENCE_IN
               ,   NULL                                                                                                       AS CONCURENCE_CONCLU_IN
               ,   NULL                                                                                                       AS CONCURENCE_ID
                  -- LES INTERACTIONS DONT LA DATE EST ABSENTE DU REFENTIEL NE SONT PAS ELIGIBLES AU CALCUL DE CONCURRENCE
               ,   0                                                                                                          AS _CONCURENCE
               ,   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL                                                                  AS EXTERNAL_PRODUCT_ID_FINAL
               ,   NULL                                                                                                       AS PRODUCT_ID_FINAL
               ,   NULL                                                                                                       AS SEG_COM_ID_FINAL
               ,   NULL                                                                                                       AS SEG_COM_AGG_ID_FINAL
               ,   NULL                                                                                                       AS CODE_MIGRATION_FINAL
               ,   NULL                                                                                                       AS MIGR_REGROUPEMENT_ID_FINAL
               ,   NULL                                                                                                       AS TYPE_SERVICE_FINAL
               ,   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INTRNL_PRDCT_ID_OPENCAT_INI                                                                AS INTRNL_PRDCT_ID_OPENCAT_INI
               ,   NULL                                                                                                       AS PRODUCT_ID_INITIAL
               ,   NULL                                                                                                       AS SEG_COM_ID_INITIAL
               ,   NULL                                                                                                       AS SEG_COM_AGG_ID_INITIAL
               ,   NULL                                                                                                       AS CODE_MIGRATION_INITIAL
               ,   NULL                                                                                                       AS MIGR_REGROUPEMENT_ID_INITIAL
               ,   CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_022})
                        THEN '${P_PIL_016}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_023})
                        THEN '${P_PIL_103}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024})
                        THEN '${P_PIL_012}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_025})
                        THEN '${P_PIL_102}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_103}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_106}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_102}'
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027}) AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_107}'
                   END                                                                                                        AS TYPE_COMMANDE_ID
               , ${P_PIL_049}                                                                                                 AS PERIODE_ID
FROM             ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM                                                                                  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
LEFT JOIN        ${KNB_PCO_TMP}.CAT_W_RFORCE_REFCOM                                                                              CAT_W_RFORCE_REFCOM
ON                 1                                                                                                   =         1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL                                                           =         CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT                                                                          =         CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_2
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                   BETWEEN   CAT_W_RFORCE_REFCOM.PERIODE_DATE_DEB
                                                                                                                       AND       CAT_W_RFORCE_REFCOM.PERIODE_DATE_FIN
WHERE              1                                                                                                   =         1
-- SEULS LES TRACAGES DONT LE PRODUIT EXISTE DANS LE CATALOGUE COMMERCIAL SONT CONSIDERES
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                             NOT IN
                  (
                    SELECT   INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM.ACTE_ID
                    FROM   ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM  INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
                  )
-- SEULS LES TRACAGES DONT LA PERIODE COMMERCIALE ASSOCIEE A LA DATE DU TRACAGE N'EXISTE PAS SONT CONSIDEREES
AND                CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_1                                                                IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- ENRICHISSEMENT PAR LES ATTRIBUTS DU REFERENTIEL COMMERCIAL

INSERT INTO      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
                  (
                    ACTE_ID_GEN
                  , ACTE_ID
                  , ACTE_TYPOLOGIE
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , FREG_PARTY_ID
                  , CONCURENCE_IN
                  , CONCURENCE_CONCLU_IN
                  , CONCURENCE_ID
                  , _CONCURENCE
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , PRODUCT_ID_FINAL
                  , SEG_COM_ID_FINAL
                  , SEG_COM_AGG_ID_FINAL
                  , CODE_MIGRATION_FINAL
                  , MIGR_REGROUPEMENT_ID_FINAL
                  , TYPE_SERVICE_FINAL
                  , INTRNL_PRDCT_ID_OPENCAT_INI
                  , PRODUCT_ID_INITIAL
                  , SEG_COM_ID_INITIAL
                  , SEG_COM_AGG_ID_INITIAL
                  , CODE_MIGRATION_INITIAL
                  , MIGR_REGROUPEMENT_ID_INITIAL
                  , TYPE_COMMANDE_ID
                  , PERIODE_ID
                  )

SELECT             INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN                                                                                          AS ACTE_ID_GEN
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                                              AS ACTE_ID

                  -- SELECTION EXCLUSIVE DES INTERACTIONS DONT LE PRODUIT PLACE EST LIE A UN SEGMENT NON SUIVI
              ,    CASE WHEN CAT_W_RFORCE_REFCOM.SEG_COM_ID = '${P_PIL_295}'
                        THEN 3
                  -- SELECTION EXCLUSIVE DES INTERACTIONS DE DEMENAGEMENTS
                        WHEN ( INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024}) )
                              /*
                               AND
                              (
                                (
                                  TYPE_SERVICE_FINAL IN (${L_PIL_104})
                                  AND CAT_W_OPENCAT_REFCOM.SEG_COM_ID = CAT_W_RFORCE_REFCOM.SEG_COM_ID
                                ) OR
                                (
                                  TYPE_SERVICE_FINAL IN (${L_PIL_105})
                                  AND CAT_W_OPENCAT_REFCOM.SEG_COM_ID IS NULL
                                )
                              )*/
                        THEN 14
                        -- VIO
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_049})
                        THEN 15
                  -- SELECTION EXCLUSIVE DES INTERACTIONS DONT LE PRODUIT PLACE EST LIE A UNE MIGRATION NON SUIVIE
                        WHEN CAT_W_RFORCE_REFCOM.MIGRATION_REGROUPEMENT_ID = '${P_PIL_295}'
                            -- LE RESULTAT DU DETAIL DE CONTACT RFORCE CORRESPOND A UN PLACEMENT
                        THEN CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_022})
-- DAE_20130914_BEGIN
                            -- LE RESULTAT DE DETAIL DE CONTACT CORRESPOND A UNE MEG ET PORTE SUR UN PRODUIT PLACE DONT LE SEGMENT AGREGE EST RTC
                                       OR  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026})
                                       AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                                       AND CAT_W_RFORCE_REFCOM.SEG_COM_AGG_ID = '${P_PIL_420}'
                            -- LE RESULTAT DE DETAIL DE CONTACT CORRESPOND A UNE MEG ET PORTE SUR UN PRODUIT PLACE DONT LE SEGMENT AGREGE EST RTC
                                       OR  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027})
                                       AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                                       AND CAT_W_RFORCE_REFCOM.SEG_COM_AGG_ID = '${P_PIL_420}'
-- DAE_20130914_END
                                  THEN 4
                            -- LE RESULTAT DU DETAIL DE CONTACT RFORCE NE CORRESPOND PAS A UN PLACEMENT
                                  ELSE 5
                             END
                  -- SELECTION EXCLUSIVE DES INTERACTIONS DONT LE RESULTAT DU DETAIL DE CONTACT CORRESPOND A UN PLACEMENT
                        WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_022})
                        THEN 6
                       -- LA GAMME DE PRODUIT RFORCE CARACTERISE UNE INTERACTION FIXE
                        ELSE CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                                  THEN 7
                                     -- LE PRODUIT PRECEDENT N'EST PAS DETERMINE
                                  ELSE CASE WHEN CAT_W_OPENCAT_REFCOM.PRODUCT_ID IS NULL
                                               -- LIGNE DMC INDETERMINEE
                                            THEN CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.LINE_TYPE IS NULL
                                                      THEN 8
                                               -- PARC PCA NON DETERMINEE
                                                      ELSE 9
                                                 END
                                     -- LE PRODUIT PRECEDENT EST LIE A UN REGROUPEMENT DE MIGRATION NON SUIVI
                                            ELSE CASE WHEN CAT_W_OPENCAT_REFCOM.MIGRATION_REGROUPEMENT_ID = '${P_PIL_295}'
                                                      THEN 10
                                     -- LE PRODUIT PRECEDENT EST SUIVI
                                                      ELSE 11
                                                 END
                                       END
                             END
                   END                                                                                                                  AS ACTE_TYPOLOGIE

              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_TS                                                                                    AS INT_CREATED_BY_TS
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                                    AS INT_CREATED_BY_DT
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.FREG_PARTY_ID                                                                                        AS FREG_PARTY_ID
              ,    NULL                                                                                                                 AS CONCURENCE_IN
              ,    NULL                                                                                                                 AS CONCURENCE_CONCLU_IN
              ,    NULL                                                                                                                 AS CONCURENCE_ID
                  -- LES INTERACTIONS DONT LE SEGMENT EST NON SUIVI NE SONT PAS ELIGIBLES AU CALCUL DE CONCURRENCE
              ,    CASE WHEN CAT_W_RFORCE_REFCOM.SEG_COM_ID = '${P_PIL_242}'
                        THEN 0
                        ELSE 1
                   END                                                                                                                  AS _CONCURENCE
              ,    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.EXTERNAL_PRODUCT_ID_FINAL                                                                            AS EXTERNAL_PRODUCT_ID_FINAL
              ,    CAT_W_RFORCE_REFCOM.PRODUCT_ID                                                                                       AS PRODUCT_ID_FINAL
              ,    CAT_W_RFORCE_REFCOM.SEG_COM_ID                                                                                       AS SEG_COM_ID_FINAL
              ,    CAT_W_RFORCE_REFCOM.SEG_COM_AGG_ID                                                                                   AS SEG_COM_AGG_ID_FINAL
              ,    CAT_W_RFORCE_REFCOM.CODE_MIGRATION                                                                                   AS CODE_MIGRATION_FINAL
              ,    CAT_W_RFORCE_REFCOM.MIGRATION_REGROUPEMENT_ID                                                                        AS MIGR_REGROUPEMENT_ID_FINAL
              ,    CAT_W_RFORCE_REFCOM.TYPE_SERVICE                                                                                     AS TYPE_SERVICE_FINAL
              ,    CASE WHEN ACTE_TYPOLOGIE > 7
                        THEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INTRNL_PRDCT_ID_OPENCAT_INI
                        ELSE NULL
                   END                                                                                                                  AS INTRNL_PRDCT_ID_OPENCAT_INI
              ,    CASE WHEN ACTE_TYPOLOGIE > 7
                        THEN
                        CAT_W_OPENCAT_REFCOM.PRODUCT_ID
                        ELSE NULL
                   END                                                                                                                  AS PRODUCT_ID_INITIAL
              ,    CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024})
                             AND  TYPE_SERVICE_FINAL IN (${L_PIL_104}, ${L_PIL_105})
                        THEN  '${P_PIL_009}'
                        WHEN ACTE_TYPOLOGIE > 7
                        THEN CAT_W_OPENCAT_REFCOM.SEG_COM_ID
                        ELSE NULL
                   END                                                                                                                 AS SEG_COM_ID_INITIAL
              ,    CASE WHEN ACTE_TYPOLOGIE > 7
                        THEN CAT_W_OPENCAT_REFCOM.SEG_COM_AGG_ID
                        ELSE NULL
                   END                                                                                                                 AS SEG_COM_AGG_ID_INITIAL
              ,    CASE WHEN INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024})
                             AND TYPE_SERVICE_FINAL IN (${L_PIL_104}, ${L_PIL_105})
                        THEN  '${P_PIL_009}'
                        WHEN ACTE_TYPOLOGIE > 7
                        THEN CAT_W_OPENCAT_REFCOM.CODE_MIGRATION
                        ELSE NULL
                   END                                                                                                                 AS CODE_MIGRATION_INITIAL
              ,    CASE WHEN ACTE_TYPOLOGIE > 7
                        THEN CAT_W_OPENCAT_REFCOM.MIGRATION_REGROUPEMENT_ID
                        ELSE NULL
                   END                                                                                                                  AS MIGR_REGROUPEMENT_ID_INITIAL
              ,    CASE WHEN  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_022})
                        THEN '${P_PIL_016}'
                        WHEN    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_023})
                        THEN '${P_PIL_103}'
-- Debut: EVOLUTION_DEMENAGEMENT ISO OFFRE (HD /RTC)
                        WHEN    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_024})
                        THEN
                            CASE WHEN TYPE_SERVICE_FINAL IN (${L_PIL_104}) -- HD
                                 THEN '${P_PIL_434}'
                                 WHEN TYPE_SERVICE_FINAL IN (${L_PIL_105})    -- FIXE
                                 THEN '${P_PIL_435}'
                                 --ELSE '${P_PIL_012}'
                            END
-- Fin: EVOLUTION_DEMENAGEMENT ISO OFFRE (HD /RTC)
                        WHEN    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_025})
                        THEN '${P_PIL_102}'
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026})
                                AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_103}'
-- DAE_20130914_BEGIN
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026})
                                AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                                AND CAT_W_RFORCE_REFCOM.SEG_COM_AGG_ID = '${P_PIL_420}'
                        THEN '${P_PIL_421}'
-- DAE_20130914_END
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_026})
                                AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_106}'
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027})
                                AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE <> ${P_PIL_343}
                        THEN '${P_PIL_102}'
-- DAE_20130914_BEGIN
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027})
                                AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                                AND CAT_W_RFORCE_REFCOM.SEG_COM_AGG_ID = '${P_PIL_420}'
                        THEN '${P_PIL_421}'
-- DAE_20130914_END
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_027})
                                AND INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.IND_GAM_TYPE = ${P_PIL_343}
                        THEN '${P_PIL_107}'
                        --VIO
                        WHEN        INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT IN (${L_PIL_049})
                        THEN '${P_PIL_102}'
                   END                                                                                                                  AS TYPE_COMMANDE_ID
              ,    CAT_W_RFORCE_REFCOM.PERIODE_ID                                                                                       AS PERIODE_ID
FROM             ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM                                                                                            INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
JOIN             ${KNB_PCO_TMP}.CAT_W_RFORCE_REFCOM                                                                                        CAT_W_RFORCE_REFCOM
ON                 1                                                                                                             =         1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.PRODUCT_ID                                                                                    =         CAT_W_RFORCE_REFCOM.PRODUCT_ID
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                             BETWEEN   CAT_W_RFORCE_REFCOM.PERIODE_DATE_DEB
                                                                                                                                 AND       CAT_W_RFORCE_REFCOM.PERIODE_DATE_FIN
-- ENRICHISSEMENT PAR LES ATTRIBUTS DU PRODUIT PRECEDENT
LEFT JOIN        ${KNB_PCO_TMP}.CAT_W_OPENCAT_REFCOM                                                                                       CAT_W_OPENCAT_REFCOM
ON                 1                                                                                                             =         1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INTRNL_PRDCT_ID_OPENCAT_INI                                                                   =         CAT_W_OPENCAT_REFCOM.PRODUCT_ID
AND                INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                             BETWEEN   CAT_W_OPENCAT_REFCOM.PERIODE_DATE_DEB
                                                                                                                                 AND       CAT_W_OPENCAT_REFCOM.PERIODE_DATE_FIN
WHERE              1                                                                                                             =         1
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

UPDATE           ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM
SET                TYPE_COMMANDE_ID                                            =       ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.TYPE_COMMANDE_ID
                 , ACTE_TYPOLOGIE                                              =         12
WHERE              1                                                           =         1
AND                INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM.CODE_MIGRATION_INITIAL                      =       ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.CODE_MIGRATION_INITIAL
AND                INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM.CODE_MIGRATION_FINAL                        =       ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.CODE_MIGRATION_FINAL
AND                INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM.PERIODE_ID                                  =       ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.PERIODE_ID
AND                INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM.ACTE_TYPOLOGIE                              =         11
AND              ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.MOUVEMENT_INITIAL      =      '${P_PIL_008}'
AND              ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.MOUVEMENT_FINAL        =      '${P_PIL_005}'
AND              ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM.CURRENT_IN             =         1
;

.IF ERRORCODE <> 0 THEN .QUIT 1;


COLLECT STATISTICS ON ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_ENRI_REFCOM;

.IF ERRORCODE <> 0 THEN .QUIT 1;
