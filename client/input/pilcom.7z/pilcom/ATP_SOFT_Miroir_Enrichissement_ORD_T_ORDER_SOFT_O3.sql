-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Miroir_Enrichissement_ORD_T_ORDER_SOFT_O3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  qui réalise l'enrichissement O3 à chaud pour la commande SOFT
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 15/01/2014      AID         Modif de KNB_COM_TMP parKNB_PCO_TMP
-- 30/07/2014      YZH         Modification (QC 606)
-- 28/07/2015      OCH         Modification le cas 'POD' sue FLAG_TYPE_PTN_NTK
-- 13/05/2016      GMA         Modification Axe Canal Pilcom MultiCanal
--------------------------------------------------------------------------------

.set width 2500;



--On calcul en avance de phase le code O3


Delete from ${KNB_PCO_TMP}.ORD_W_ORDER_SOFT_ENRI_O3;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_ORDER_SOFT_ENRI_O3
(
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  ORDER_DEPOSIT_DT              ,
  STATUS_MODIF_TS               ,
  STORE_NAME                    ,
  DISTRBTN_CHANNL_ID            ,
  FLAG_TEAM_MKT                 ,
  FLAG_TYPE_CMP                 ,
  EDO_ID                        ,
  FLAG_PLT_CONV                 ,
  TYPE_EDO                      ,
  NETWRK_TYP_EDO_ID             ,
  FLAG_TYPE_GEO                 ,
  FLAG_TYPE_CPT_NTK             ,
  FLAG_TYPE_PTN_NTK              
)
Select
  RefCom.EXTERNAL_ORDER_ID                                as EXTERNAL_ORDER_ID                ,
  RefCom.ORDER_STATUS_CD                                  as ORDER_STATUS_CD                  ,
  Cast(RefCom.ORDER_DEPOSIT_TS as date format 'YYYYMMDD') as ORDER_DEPOSIT_DT                 ,
  RefCom.STATUS_MODIF_TS                                  as STATUS_MODIF_TS                  ,
  RefCom.STORE_NAME                                       as STORE_NAME                       ,
  RefCom.DISTRBTN_CHANNL_ID                               as DISTRBTN_CHANNL_ID               ,
  --On calcul par rapport au canal ainsi que le storeName :
  Case  --Quand le canal de distrib est FID, CN2 et BFT et que les caract de 
        -- 3 à 5 sont PAE alors c'est du marketing
        When RefCom.DISTRBTN_CHANNL_ID in ('FID','CN2','BFT') And SubStr(Trim(RefCom.STORE_NAME),3,3) = 'PAE'
          Then  1
        --Quand le canal de distrib est CBO et que le canal est 92BODRCP1 ou 36PAECHATE
        -- Alors c'est du marketing
        When  RefCom.DISTRBTN_CHANNL_ID in ('CBO') And RefCom.STORE_NAME in ('92BODRCP1', '36PAECHATE')
          Then  1
        When RefCom.DISTRBTN_CHANNL_ID in ('PAE') --Canal de marketting Externe
          Then  1
        Else    0
  End                                                     as FLAG_TEAM_MKT                    ,
  Case  -- Pour ce flag il faut que le canal market soit à 1 et qu'on soit sur un PDV BO
        When FLAG_TEAM_MKT = 1 And RefCom.STORE_NAME in ('86PAEPOIT1', '92BODRCP1', '36PAECHATE')
          Then  'B'
        Else    '#'
  End                                                     as FLAG_TYPE_CMP                    ,
  RefO3.EDO_ID                                            as EDO_ID                           ,
  RefO3.FLAG_PLT_CONV                                     as FLAG_PLT_CONV                    ,
  RefO3.TYPE_EDO                                          as TYPE_EDO                         ,
  RefO3.NETWRK_TYP_EDO_ID                                 as NETWRK_TYP_EDO_ID                ,
  RefO3.FLAG_TYPE_GEO                                     as FLAG_TYPE_GEO                    ,
  RefO3.FLAG_TYPE_CPT_NTK                                 as FLAG_TYPE_CPT_NTK                ,
  --Cas Particulier pour les POD :
  Case  When  RefCom.DISTRBTN_CHANNL_ID in ('POD') And RefO3.FLAG_TYPE_ENT_NTK = 'ENT'
          Then 'DCE'
        When RefO3.FLAG_TYPE_PTN_NTK In ('PSE','PST')
          Then 'GDT'
        When RefO3.FLAG_TYPE_PTN_NTK In ('FC')
          Then 'FC'
        Else RefO3.FLAG_TYPE_PTN_NTK
  End                                                     as FLAG_TYPE_PTN_NTK                
From
  ${KNB_COM_TMP}.ATP_W_FACADE_ORDER RefCom
  Left outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFO3_JOUR RefO3
  On    RefCom.STORE_NAME                                         =   RefO3.EXTNL_VAL_COD_CD
    And Cast(RefCom.ORDER_DEPOSIT_TS as date format 'YYYYMMDD')   >=  RefO3.START_EXTNL_VAL_DT
    And Cast(RefCom.ORDER_DEPOSIT_TS as date format 'YYYYMMDD')   <=  Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
Qualify Row_Number() Over(Partition by 
                                        RefCom.EXTERNAL_ORDER_ID                                      ,
                                        RefCom.ORDER_STATUS_CD                                        ,
                                        Cast(RefCom.ORDER_DEPOSIT_TS as date format 'YYYYMMDD')       ,
                                        RefCom.STATUS_MODIF_TS                                        
                          Order by      RefO3.START_EXTNL_VAL_DT Desc                                 ,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1

;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ORDER_SOFT_ENRI_O3;
.if errorcode <> 0 then .quit 1


