-- $HEADER:   mm2pco/current/sql/ATP_BES_Placement_Consolidation_Enrichissement_Step3_NDS.sql 13_05#3 24-JUL-2017 11:19:03 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Consolidation_Enrichissement_Step3_NDS.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 13/06/2017      HLA         Creation
-- 24/07/2017      HLA         Modification
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_NDS all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_NDS
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  SERVICE_ACCESS_ID

)
Select
  RefId.ACTE_ID                             as  ACTE_ID                       ,
  RefId.ORDER_DEPOSIT_DT                    as  ORDER_DEPOSIT_DT              ,
  Cor.ACCES_SERVICE                         as  SERVICE_ACCESS_ID

From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1 RefId
  Inner join ${KNB_COM_SOC}.V_PAR_F_PARTY_KNB_CORR_ENR Cor
    On       coalesce(RefId.PAR_ND,RefId.MSISDN_NU) = Cor.TERMINTN_VALUE_DS
       and   RefId.ORDER_DEPOSIT_DT >= Cor.RELATION_DAT_DEB
       and   RefId.ORDER_DEPOSIT_DT <= Cor.RELATION_DAT_FIN
Where  (1=1)
and ( RefId.PAR_ND is not null or Substr(RefId.MSISDN_NU,1,2) in ('01','02','03','04','05') )
qualify ROW_NUMBER() OVER (partition by RefId.ACTE_ID ORDER BY  (RefId.order_deposit_dt-Cor.RELATION_DAT_DEB) ASC) = 1


;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_NDS;
.if errorcode <> 0 then .quit 1


.quit 0
