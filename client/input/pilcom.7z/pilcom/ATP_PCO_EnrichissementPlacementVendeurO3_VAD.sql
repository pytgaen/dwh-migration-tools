-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:ATP_PCO_EnrichissementPlacementVendeurO3_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 09/09/2013     GMA         Création
-- 06/02/2014     AID         Indus
-- 21/08/2014     GMA         Correction sur l'orga O3 suppression de la Règle : Si plateau SCH alors EDO convergent
-- 27/01/2014     HZO         Harmonisation des RG de calcul des Flags de Convergence (SOSH, OPEN) et SCH (1014, GSCR)
-- 03/03/2016     TPI         QC 1072 : Modification paramètres
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3 All;
.if errorcode <> 0 then .quit 1

-----------------------------------------------------------------------------------------
-- On recherche dans O3 pour les lignes "Point de vente non renseigné" et Orga = "POCSC"
-----------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
From
  (
    Select
      RefId.ACTE_ID                                             as ACTE_ID                    ,
      RefId.DATE_SAISIE                                         as DATE_SAISIE                ,
      Coalesce(RefConseil.ORG_REF_TRAV,RefId.ORG_REF_TRAV)      as ORG_REF_TRAV               ,
      Coalesce(RefConseil.ORG_GROUPE_ID,RefId.ORG_GROUPE_ID)    as ORG_GROUPE_ID              ,
      RefId.PDV                                       as PDV  
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER    RefId
      Left Outer Join  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEUR  RefConseil
        On  RefId.ACTE_ID = RefConseil.ACTE_ID
  ) RefId
  Inner Join
    (
      Select
        RefPdv.EDO_ID                                                                         as EDO_ID               ,
        RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
        RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   as TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
              Else    0
        End                                                                                   as FLAG_PLT_CONV        ,
        Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                                                   as FLAG_PLT_SCH         ,
        Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
        Case  When RefEdo.STATT_EDO_CD = '${P_PIL_437}'
                Then 1
              Else 0
        End                                                                                   as FLAG_EDO_ACT         ,
        Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
        Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT                      
      From
        ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO RefPdv
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID                      As EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoAVSC
        On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
          --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
        Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
          On    RefPdv.EDO_ID         = RefEdo.EDO_ID
            And RefEdo.CURRENT_IN     = 1
            And RefEdo.CLOSURE_DT     Is Null
      Where
        (1=1)
        And RefPdv.EXTNL_COD_CD = 'REGARDSC'
        And RefPdv.CURRENT_IN   = 1
        And RefPdv.CLOSURE_DT   Is Null
    )RefO3
    On    RefId.ORG_GROUPE_ID     = RefO3.EXTNL_VAL_COD_CD
      And RefId.DATE_SAISIE     >= RefO3.START_EXTNL_VAL_DT
      And RefId.DATE_SAISIE     <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
      And RefId.DATE_SAISIE     >= RefO3.OPEN_DT
      And RefId.DATE_SAISIE     <= RefO3.CLOSE_DT
Where
  (1=1)
      And RefId.ORG_REF_TRAV    = 'POCSC'
      And RefId.ORG_GROUPE_ID   IS NOT NULL
Qualify Row_Number() Over(Partition by RefId.ACTE_ID, RefId.DATE_SAISIE ORDER BY RefO3.START_EXTNL_VAL_DT DESC, RefO3.FLAG_EDO_ACT DESC, COALESCE(RefO3.END_EXTNL_VAL_DT, CAST('99991231' AS DATE FORMAT 'YYYYMMDD')) DESC)=1
;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
-- On recherche dans O3 pour les lignes "Point de vente non renseigné" et Orage = "OEEEDEL"
-------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
From
  (
    Select
      RefId.ACTE_ID                                             as ACTE_ID                    ,
      RefId.DATE_SAISIE                                       as DATE_SAISIE              ,
      Coalesce(RefConseil.ORG_REF_TRAV,RefId.ORG_REF_TRAV)      as ORG_REF_TRAV               ,
      Coalesce(RefConseil.ORG_GROUPE_ID,RefId.ORG_GROUPE_ID)    as ORG_GROUPE_ID              ,
      RefId.PDV                                       as PDV  
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER    RefId
      Left Outer Join  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEUR  RefConseil
        On  RefId.ACTE_ID = RefConseil.ACTE_ID
  ) RefId
  INNER JOIN
    (
      SELECT
        RefEdo.EDO_ID                                                                         AS EDO_ID               ,
        Conv.ORG_GROUPE_ID                                                                    AS ORG_GROUPE_ID        ,
        RefEdo.START_DT                                                                       AS START_DT             ,
        COALESCE(RefEdo.CLOSE_DT,CURRENT_DATE)                                                AS CLOSE_DT             ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   AS TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        CASE  WHEN RefEdoConv.EDO_ID IS NOT NULL
                THEN  1 --Si on trouve une correspondance alors c'est un plateau convergent
              ELSE    0
        END                                                                                   AS FLAG_PLT_CONV        ,
        CASE  WHEN RefEdoAVSC.EDO_ID IS NOT NULL
                THEN  1
              ELSE    0
        END                                                                                   AS FLAG_PLT_SCH         

      FROM ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
               
      INNER JOIN ${KNB_PCO_SOC}.ORG_R_TRANS_CONSEIL_O3 Conv
          ON RefEdo.EDO_ID = Conv.EDO_ID
             AND Conv.CURRENT_IN     = 1
             AND Conv.CLOSURE_DT     IS NULL
             
        LEFT OUTER JOIN
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID                      As EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        ON  RefEdo.EDO_ID   = RefEdoConv.EDO_ID
        LEFT OUTER JOIN
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          SELECT
            EDO_ID
          FROM
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          WHERE
            (1=1)
            AND EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            AND EdoAx.FRESH_IN          = 1
            AND EdoAx.CURRENT_IN        = 1
            AND EdoAx.CLOSURE_DT        IS NULL
          GROUP BY
            EDO_ID
        ) RefEdoAVSC
        ON  RefEdo.EDO_ID   = RefEdoAVSC.EDO_ID
        
      WHERE
        (1=1)
        AND RefEdo.CURRENT_IN   = 1
        AND RefEdo.CLOSURE_DT   IS NULL
    )RefO3
    ON    RefId.ORG_GROUPE_ID    = RefO3.ORG_GROUPE_ID
      AND RefId.DATE_SAISIE >= RefO3.START_DT
      AND RefId.DATE_SAISIE <=  RefO3.CLOSE_DT
WHERE
  (1=1)
  AND RefId.ORG_REF_TRAV    = 'OEEEDEL'
QUALIFY ROW_NUMBER() OVER(PARTITION BY RefId.ACTE_ID, RefId.DATE_SAISIE ORDER BY RefO3.START_DT DESC, RefO3.CLOSE_DT DESC)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- On recherche dans O3 pour les lignes "Point de Vente renseigné"
------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
From
  (
    Select
      RefId.ACTE_ID                                             as ACTE_ID                    ,
      RefId.DATE_SAISIE                                         as DATE_SAISIE                ,
      Coalesce(RefConseil.ORG_REF_TRAV,RefId.ORG_REF_TRAV)      as ORG_REF_TRAV               ,
      Coalesce(RefConseil.ORG_GROUPE_ID,RefId.ORG_GROUPE_ID)    as ORG_GROUPE_ID              ,
      RefId.PDV                                                 as PDV              
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER    RefId
      Left Outer Join  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEUR  RefConseil
        On  RefId.ACTE_ID = RefConseil.ACTE_ID
    Where Not Exists (Select 1
                      From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3 As CIB
                      Where CIB.ACTE_ID = RefId.ACTE_ID)
      And (RefId.EDO_ID Is Null Or RefConseil.ACTE_ID Is Not Null)
  ) RefId
  Inner Join
    (
      Select
        RefPdv.EDO_ID                                                                         as EDO_ID               ,
        RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
        RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   as TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
              Else    0
        End                                                                                   as FLAG_PLT_CONV        ,
        Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                                                   as FLAG_PLT_SCH         ,
        Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
        Case  When RefEdo.STATT_EDO_CD = '${P_PIL_437}'
                Then 1
              Else 0           
        End                                                                                   as FLAG_EDO_ACT         ,
        Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
        Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT             ,
        RefPdv.ROL_LINK_CD                                                                    as ROL_LINK_CD          
      From
        ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPdv
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID                      As EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoAVSC
        On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
          --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
        Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
          On    RefPdv.EDO_ID         = RefEdo.EDO_ID
            And RefEdo.CURRENT_IN     = 1
            And RefEdo.CLOSURE_DT     Is Null
      Where
        (1=1)
        And RefPdv.CURRENT_IN   = 1
        And RefPdv.CLOSURE_DT   Is Null
    )RefO3
    On    RefId.PDV               = RefO3.EXTNL_VAL_COD_CD
      And RefId.DATE_SAISIE       >= RefO3.START_EXTNL_VAL_DT
      And RefId.DATE_SAISIE       <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
      And RefId.DATE_SAISIE       >= RefO3.OPEN_DT
      And RefId.DATE_SAISIE       <= RefO3.CLOSE_DT
Where
  (1=1)
Qualify Row_Number() Over(Partition by RefId.ACTE_ID Order by RefO3.ROL_LINK_CD Asc, RefO3.FLAG_EDO_ACT Desc, RefO3.START_EXTNL_VAL_DT Desc, Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3;
.if errorcode <> 0 then .quit 1



--Recherche du INT/EXT
Update RefId
From
  (
    Select
      RefVend.ACTE_ID                             as ACTE_ID              ,
      RefId.DATE_SAISIE                           as DATE_SAISIE          ,
      Case  When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                      OrgWork.WORK_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_2_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_3_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_4_TYPE_EDO ='${P_PIL_236}'
                  )
              Then '${P_PIL_236}'
              Else '${P_PIL_235}'
      End                                         as TYPE_EDO             
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3 RefVend
      Inner Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER RefId
        On    RefVend.ACTE_ID                     =   RefId.ACTE_ID
      Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL OrgWork
        On    RefVend.EDO_ID                      =   OrgWork.WORK_TEAM_LEVEL_1_CD
          And RefId.DATE_SAISIE                   >=  OrgWork.WORK_TEAM_LEVEL_1_START_DT
          And RefId.DATE_SAISIE                   <=  OrgWork.WORK_TEAM_LEVEL_1_END_DT
          And RefId.DATE_SAISIE                   >=  OrgWork.WORK_TEAM_LEVEL_2_START_DT
          And RefId.DATE_SAISIE                   <=  OrgWork.WORK_TEAM_LEVEL_2_END_DT
          And RefId.DATE_SAISIE                   >=  OrgWork.WORK_TEAM_LEVEL_3_START_DT
          And RefId.DATE_SAISIE                   <=  OrgWork.WORK_TEAM_LEVEL_3_END_DT
          And RefId.DATE_SAISIE                   >=  OrgWork.WORK_TEAM_LEVEL_4_START_DT
          And RefId.DATE_SAISIE                   <=  OrgWork.WORK_TEAM_LEVEL_4_END_DT
    Qualify Row_Number() Over (Partition by RefVend.ACTE_ID Order by  OrgWork.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_CD Desc
                              )=1
  )RefEnri,
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3 RefId
Set
  TYPE_EDO= RefEnri.TYPE_EDO
Where
  (1=1)
  And RefId.ACTE_ID               = RefEnri.ACTE_ID
;
.if errorcode <> 0 then .quit 1



.quit 0
