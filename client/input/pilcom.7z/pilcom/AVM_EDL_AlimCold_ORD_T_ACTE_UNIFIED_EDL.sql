--$HEADER:   %HEADER% 
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_EDL_AlimCold_ORD_T_ACTE_UNIFIED_EDL.sql  $    
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source EDL dans la table ORD_T_ACTE_UNIFIED_EDL  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION                                        
-- 30/05/2013     CBR         Création                                                     
-- 26/03/2014     AID         Indus                                                        
-- 05/03/2015     HZO         Modif: Profondeur de recalcul 15 jours                       
-- 19/06/2015     OCH         Modif: digital                                               
-- 24/11/2016     HOB         Creation                                                     
-- 14/03/2017     HLA         Modification                                                 
-- 30/11/2017     MEL         IOBSP                                                        
--10/10/2019      GRH         KPI2020 : Ajout du filtre sur les NS/NSTECH pour data enabler
-- 01/07/2020     JCR         Ajout colonne SMI_EAN_CD
-- 06/10/2021     EVI         PILCOM-1026 : Refonte VU - Champs Obsolètes
-------------------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_EDL --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_EDL;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_EDL 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  ORG_AGENT_IOBSP               ,
  ORG_EDO_IOBSP                 ,
  PAR_IRIS2000_CD               ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                   
)
Select
  EDL.ACTE_ID_GEN                                                          As ACTE_ID,
  EDL.OPERATOR_PROVIDER_ID                                                 As OPERATOR_PROVIDER_ID,
  EDL.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID,
  '${P_PIL_368}'                                                           As TYPE_SOURCE_ID,
  EDL.ACTE_ID_GEN                                                          As MASTER_ACTE_ID,
  EDL.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID,
  ${P_PIL_354}                                                             As MASTER_FLAG,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND,
  Null                                                                     As CPLT_ACTE_ID,
  Null                                                                     As CPLT_INTRNL_SOURCE_ID,
  '${P_PIL_388}'                                                           As CPLT_IN,
  '${P_PIL_362}'                                                           As RULE_ID,
  Null                                                                     As OFFSET_NB,
  '${P_PIL_324}'                                                           As ACT_TYPE,
  EDL.EXTERNAL_INT_ID                                                      As ORDER_EXTERNAL_ID,
  '${P_PIL_397}'                                                           As STATUS_CD,
  Case When EDL.CONCURENCE_IN = 'O' Then '${P_PIL_385}'
       When EDL.CONFIRMATION_IN = 'N' Then '${P_PIL_386}' 
       When EDL.PERENNITE_IN = 'O' Then '${P_PIL_384}' 
       When EDL.DELIVERY_IN = 'O' And EDL.PERENNITE_IN = 'N' Then '${P_PIL_387}' 
       When EDL.DELIVERY_IN = 'O' Then '${P_PIL_383}' 
       When EDL.CONFIRMATION_IN = 'O' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                      As ACT_UNIFIED_STATUS_CD,
  EDL.INT_DEPOSIT_TS                                                       As ACT_TS,
  EDL.INT_DEPOSIT_DT                                                       As ACT_DT,
  Extract(HOUR From EDL.INT_DEPOSIT_TS)                                    As ACT_HH,
  EDL.INT_MODIF_TS                                                         As ACT_LAST_UPD_TS,
  EDL.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE,
  EDL.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE,
  EDL.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE,
  EDL.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE,
  Case When ACT_PRODUCT_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                      As ACT_OPER_ID_PRE,
  EDL.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL,
  EDL.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL,
  EDL.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL,
  EDL.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL,
  'ADD'                                                                    As ACT_OPER_ID_FINAL,
  EDL.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL,
  EDL.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID,
  EDL.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF,
  EDL.ACT_CD                                                               As ACT_CD,
  EDL.ACT_REM_ID                                                           As ACT_REM_ID,
  EDL.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM,
  EDL.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And EDL.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And EDL.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And EDL.ORG_REM_CHANNEL_CD IN (${L_PIL_043}) 
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And SFI.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And EDL.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then 'O' 
       Else 'N'  
  End                                                                      As ACT_FLAG_PVC_REM,
  EDL.ACT_ACTE_VALO                                                        As ACT_ACTE_VALO,
  EDL.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI,
  EDL.ACT_PERIODE_ID                                                       As ACT_PERIODE_ID,
  EDL.ACT_PERIODE_STATUS                                                   As ACT_PERIODE_STATUS               ,
  EDL.ACT_PERIODE_CLOSURE_DT                                               As ACT_PERIODE_CLOSURE_DT           ,
  EDL.ORIG_DEM                                                             As ORIGIN_CD                        ,
  trim(EDL.ORG_AGENT_ID)                                                   As AGENT_ID,
  trim(EDL.ORG_AGENT_ID)                                                   As AGENT_ID_UPD,
  Null                                                                     As AGENT_ID_UPD_DT,
  EDL.ORG_PRENOM                                                           As AGENT_FIRST_NAME,
  EDL.ORG_NOM                                                              As AGENT_LAST_NAME,
  Null                                                                     As UNIFIED_SHOP_CD,
  EDL.ORG_CANAL_ID_MACRO                                                   As ORG_SPE_CANAL_ID_MACRO,
  EDL.ORG_CANAL_ID                                                         As ORG_SPE_CANAL_ID,
  EDL.ORG_REM_CHANNEL_CD                                                   As ORG_REM_CHANNEL_CD,
  EDL.ORG_CHANNEL_CD                                                       As ORG_CHANNEL_CD,
  EDL.ORG_SUB_CHANNEL_CD                                                   As ORG_SUB_CHANNEL_CD,
  EDL.ORG_SUB_SUB_CHANNEL_CD                                               As ORG_SUB_SUB_CHANNEL_CD,
  EDL.ORG_GT_ACTIVITY                                                      As ORG_GT_ACTIVITY,
  EDL.ORG_FIDELISATION                                                     As ORG_FIDELISATION,
  EDL.ORG_WEB_ACTIVITY                                                     As ORG_WEB_ACTIVITY,
  EDL.ORG_AUTO_ACTIVITY                                                    As ORG_AUTO_ACTIVITY,
  EDL.ORG_EDO_ID                                                           As ORG_EDO_ID,
  EDL.ORG_TYPE_EDO                                                         As ORG_TYPE_EDO,
  EDL.ORG_FLAG_PLT_CONV                                                    As ORG_FLAG_PLT_CONV,
  EDL.ORG_FLAG_TEAM_MKT                                                    As ORG_FLAG_TEAM_MKT,
  EDL.ORG_FLAG_TYPE_CMP                                                    As ORG_FLAG_TYPE_CMP,
  Null                                                                     As ORG_RESP_EDO_ID,
  Null                                                                     As ORG_RESP_TYPE_EDO, 
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV,
  Null                                                                     As ACTIVITY_CD,
  Null                                                                     As ACTIVITY_GROUPNG_CD,
  Null                                                                     As AUTO_ACTIVITY_IN,
  CASE WHEN EDL.ORG_REF_TRAV = 'OEEEDEL' THEN 'O3'
       ELSE EDL.ORG_REF_TRAV
  END                                                                      As ORG_TYPE_CD,
  Null                                                                     As ORG_TEAM_TYPE_ID,
  Trim(EDL.ORG_TEAM_LEVEL_1_CD)                                            As ORG_TEAM_LEVEL_1_CD,
  Trim(EDL.ORG_TEAM_LEVEL_1_DS)                                            As ORG_TEAM_LEVEL_1_DS,
  Trim(EDL.ORG_TEAM_LEVEL_2_CD)                                            As ORG_TEAM_LEVEL_2_CD,
  Trim(EDL.ORG_TEAM_LEVEL_2_DS)                                            As ORG_TEAM_LEVEL_2_DS,
  Trim(EDL.ORG_TEAM_LEVEL_3_CD)                                            As ORG_TEAM_LEVEL_3_CD,
  Trim(EDL.ORG_TEAM_LEVEL_3_DS)                                            As ORG_TEAM_LEVEL_3_DS,
  Trim(EDL.ORG_TEAM_LEVEL_4_CD)                                            As ORG_TEAM_LEVEL_4_CD,
  Trim(EDL.ORG_TEAM_LEVEL_4_DS)                                            As ORG_TEAM_LEVEL_4_DS,
  Trim(EDL.WORK_TEAM_LEVEL_1_CD)                                           As WORK_TEAM_LEVEL_1_CD,
  Trim(EDL.WORK_TEAM_LEVEL_1_DS)                                           As WORK_TEAM_LEVEL_1_DS,
  Trim(EDL.WORK_TEAM_LEVEL_2_CD)                                           As WORK_TEAM_LEVEL_2_CD,
  Trim(EDL.WORK_TEAM_LEVEL_2_DS)                                           As WORK_TEAM_LEVEL_2_DS,
  Trim(EDL.WORK_TEAM_LEVEL_3_CD)                                           As WORK_TEAM_LEVEL_3_CD,
  Trim(EDL.WORK_TEAM_LEVEL_3_DS)                                           As WORK_TEAM_LEVEL_3_DS,
  Trim(EDL.WORK_TEAM_LEVEL_4_CD)                                           As WORK_TEAM_LEVEL_4_CD,
  Trim(EDL.WORK_TEAM_LEVEL_4_DS)                                           As WORK_TEAM_LEVEL_4_DS,
  EDL.CONFIRMATION_IN                                                      As CONFIRMATION_IN,
  Null                                                                     As MIGRA_DT                      ,
  Null                                                                     As MIGRA_NEXT_OFFRE              ,
  0                                                                        As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  Case  When (EDL.INT_DEPOSIT_DT + 45) >= EDL.SEG_FIND_LIVR_DT
          Then EDL.SEG_FIND_LIVR_DT
        Else Null
  End                                                                      As SEGMENT_DELIVERY_IN_PARK_DT      ,
  Null                                                                      As ORDER_CANCELING_DT ,
  EDL.DMC_LINE_ID                                                          As LINE_ID,
  EDL.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID,
  EDL.PAR_TYPE                                                             As CUST_TYPE_CD,
  Coalesce(EDL.DOSSIER_NU, '0000000000')                                   As MSISDN_ID,
  Coalesce(EDL.PAR_ND, '0000000000')                                       As NDS_VALUE_DS,
  Coalesce(EDL.CLIENT_NU, '0000000000')                                    As EXTERNAL_PARTY_ID,
  EDL.PAR_AID                                                              As RES_VALUE_DS,
  Null                                                                     As PAR_ACCES_SERVICE,
  Null                                                                     As TAC_CD, 
  Null                                                                     As IMEI_CD, 
  EDL.PAR_IMSI                                                             As IMSI_CD, 
  EDL.DMC_ACTIVATION_DT_INT                                                As HOM_START_DT, 
  EDL.DMC_ACTIVATION_DT                                                    As MOB_START_DT, 
  EDL.PAR_SCORE_NU_INT                                                     As I_SCORE_VALUE,
  EDL.PAR_TRESHOLD_NU_INT                                                  As I_SCORE_TRESHOLD,
  Case                                                                     
    When EDL.PAR_SCORE_IN_INT = 'O' Then 1                                     
    Else 0                                                                 
  End                                                                      As I_SCORE_IN,
  EDL.PAR_SCORE_NU                                                         As M_SCORE_VALUE,
  Case
    When EDL.PAR_TRESHOLD_NU > 100 Then -1
    Else EDL.PAR_TRESHOLD_NU        
  End                                                                      As M_SCORE_TRESHOLD,
    EDL.PAR_SCORE_IN                                                       As M_SCORE_IN,
  Cast(Case When EDL.OTO_OSCAR_VALUE_NU = 'SC' Then -1 
            Else EDL.OTO_OSCAR_VALUE_NU
  End As BYTEINT)                                                          As OSCAR_VALUE,
  '${P_PIL_376}'                                                           As CUST_BU_TYPE_CD,
  EDL.PAR_USCM                                                             As CUST_BU_CD,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE,
  Trim(
    Trim(Coalesce(Case When EDL.PAR_BILL_ADRESS_1 = 'null' Then Null Else PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When EDL.PAR_BILL_ADRESS_2 = 'null' Then Null Else PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When EDL.PAR_BILL_ADRESS_3 = 'null' Then Null Else PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(EDL.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(Case When EDL.PAR_BILL_ADRESS_4 = 'null' Then Null Else PAR_BILL_ADRESS_4 End,'')) || ' ' ||
    Trim(Coalesce(EDL.PAR_BILL_VILLE,'')) 
  )                                                                        As ADDRESS_CONCAT_NM,
  Coalesce(EDL.PAR_POSTAL_CD,EDL.PAR_BILL_CD_POSTAL)                       As POSTAL_CD,
  EDL.PAR_INSEE_CD                                                         As INSEE_CD, 
  EDL.PAR_BU_CD                                                            As BU_CD,
  Coalesce(EDL.PAR_DEPRTMNT_ID,EDL.PAR_DO   )                              As DEPARTMNT_ID,
  EDL.PAR_GEO_MACROZONE                                                    AS PAR_GEO_MACROZONE             ,
  EDL.PAR_UNIFIED_PARTY_ID                                                 AS PAR_UNIFIED_PARTY_ID                ,
  EDL.PAR_PARTY_REGRPMNT_ID                                                AS PAR_PARTY_REGRPMNT_ID            ,
  Null                                                                     as PAR_CID_ID                      ,
  Null                                                                     as PAR_PID_ID                      ,
  Null                                                                     as PAR_FIRST_IN                    ,
  EDL.ORG_AGENT_IOBSP                                                      as ORG_AGENT_IOBSP               ,
  EDL.ORG_EDO_IOBSP                                                        as ORG_EDO_IOBSP                 ,
  EDL.PAR_IRIS2000_CD                                                      As PAR_IRIS2000_CD,
  EDL.PAR_MOB_SIM                                                          As SIM_CD                           ,
  Null                                                                     As SIM_EAN_CD,
  Null                                                                     As CHECK_INITIAL_STATUS_CD,
  Null                                                                     As CHECK_NAT_STATUS_CD,
  Null                                                                     As CHECK_NAT_COMMENT,
  Null                                                                     As CHECK_NAT_STATUS_LN,
  Null                                                                     As CHECK_LOC_STATUS_CD,
  Null                                                                     As CHECK_LOC_COMMENT,
  Null                                                                     As CHECK_LOC_STATUS_LN,
  Null                                                                     As CHECK_VALIDT_DT,
  Null                                                                     As ACT_END_UNIFIED_DT,
  Null                                                                     As ACT_END_UNIFIED_DS,
  EDL.CLOSURE_DT                                                           As ACT_CLOSURE_DT,
  Case When EDL.CLOSURE_DT Is Not Null
       Then 'Acte Clos'        
  End                                                                      As ACT_CLOSURE_DS,
  0                                                                        As HOT_IN,
  Null                                                                     As RUN_ID,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS,
  1                                                                        As FRESH_IN,
  0                                                                        As COHERENCE_IN 
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_EDL As EDL 
  Left Outer Join ${KNB_IBU_GLB_V}.VPOCCSLMAT As VPOCCSLMAT
    On  EDL.ORG_POC_XI = VPOCCSLMAT.XI
Where
  (1=1)
  And Substr(EDL.ACT_CD,1,3)              Not In (${L_PIL_036})
  And EDL.ACT_SEG_COM_ID_FINAL            <> '${P_PIL_295}'
  And EDL.ACT_CD                          <> '${P_PIL_067}'
  And EDL.ACT_ACTE_FAMILLE_KPI  Not In (${L_PIL_626}) -- NS, NSTECH
  And EDL.ACT_PERIODE_ID                  > 12
  And EDL.INT_DEPOSIT_DT                  >= Current_date - 250
  And ((EDL.LAST_MODIF_TS                 >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And EDL.LAST_MODIF_TS  <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or EDL.INT_DEPOSIT_DT > Current_date - 15)
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_EDL;
.if errorcode <> 0 then .quit 1;
