--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_PVC_Hot_OS_Step1_Alim_Flux_DPVC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'extraction PVC OneShot pour DPVC
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 12/09/2014     GMA           Création
-- 24/09/2014     YZH           Modification - Alimentation CA
-- 25/09/2014     YZH           Modification - Suppression Alimentations Contact
-- 29/09/2014     YZH           Modification - Séparateur CA
-- 08/10/2014     YZH           Modification - SOURCE_ID    
-- 09/10/2014     YZH           Modification - ACTE_ID_EXTERNE
-- 13/11/2014     HZO           Modification - SALE_CHANNEL_DCL
-- 02/07/2015     HFO           Modification - Suppresion master
-- 04/02/2016     HZO           Modification Déclaratif en volume
-- 28/07/2020     EVI           PILCOM-624 : KPI2020 - Alimentation CA Flux à Chaud PVC
---------------------------------------------------------------------------------

.set width 5000

Delete From ${KNB_PCO_TMP}.ACT_T_PVC_DAY_HOT_OS All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ACT_T_PVC_DAY_HOT_OS
(
  RUN_ID                        ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  CUID                          ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  SALE_CHANNEL_DCL              ,
  SALE_CHANNEL_ORDER            ,
  SALE_ORIGINE                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_PARC                 ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_SIRET                ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  ID_FREGATE                    ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  OSCAR_VALUE                   ,
  DUREE_ENGMENT                 ,
  VOLUM                         ,
  VAL                           ,
  CA                            ,
  CSO_MOTIF                     ,
  CSO_MOTIF_DES                 ,
  DESCRIPTION                   ,
  ACTE_CODE                     ,
  CODE_TYPE_ORDER               ,
  TYPE_ORDER_INI                ,
  CODE_TYPE_ORDER_NEW           ,
  TYPE_ORDER_NEW                ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENITE                 ,
  CC_PLACEMENT                  ,
  DELAI_PRENEITE                ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  HOT_IN                        
)
Select
  ${RUN_ID}                                                                                 As RUN_ID                         ,
  ActeUni.ACTE_ID                                                                           As ACTE_ID                        ,
  Case When Trim(Placement.PVC_ACTE_ID_EXTERNE)=''
    Then '1'
  Else Coalesce(Placement.PVC_ACTE_ID_EXTERNE, '1')     
  End                                                                                       As ACTE_ID_EXTERNE                ,
  Null                                                                                      As ACTE_ID_CONTACTE               ,
  Null                                                                                      As ACTE_ID_DETAIL_CONTACTE        ,
  Cast(Placement.ID_PARSIFAL As BIGINT)                                                     As ACTE_ID_COMMANDE_REFERENCE     ,
  '${P_PIL_456}'                                                                            As SOURCE_ID                      ,
  --A chaud pour PVC on insert que des type 1 : : Validé Pilcom et complet
  1                                                                                         As ACTE_STATUT                    ,
  --A chaud pour PVC on insert que des creation d'acte => 1 
  1                                                                                         As ACTION_ACTE                    ,
  ActeUni.ACT_TS                                                                            As ORDER_DEPOSIT_TS               ,
  Cast(SubString(Cast(ActeSrc.CREATION_TS As Char(22)) From 1 For 19) As Timestamp(0))      As ORDER_RECEIVED_PIL_TS          ,
  Cast(
        SubString(Cast(ActeUni.LAST_MODIF_TS As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ORDER_MAJ_PIL_TS               ,
  ActeUni.STATUS_CD                                                                         As ORDER_STATUT                   ,
  Null                                                                                      As ORDER_STATUT_TS                ,
  ActeUni.AGENT_ID_UPD                                                                      As CUID                           ,
  Cast(TD_SYSFNLIB.Oreplace(ActeUni.AGENT_LAST_NAME, ';', ' ')  as Varchar(50))                         As SELLER_LAST_NAME               ,
  Cast(TD_SYSFNLIB.Oreplace(ActeUni.AGENT_FIRST_NAME, ';', ' ')  as Varchar(50))                        As SELLER_FIRST_NAME              ,
  Null                                                                                      As TEAM_DLC_DES                   ,
  Case When ActeUni.ORG_CHANNEL_CD in ('CCO','SCH') Then Null
       Else Trim(ActeUni.ORG_EDO_ID)
  End                                                                                       As TEAM_ORDER_DES                 ,
  Case When ActeUni.ORG_CHANNEL_CD IN ('Distrib','Dist','Distribution') Then 'AD'
       Else ActeUni.ORG_CHANNEL_CD
  End                                                                                       As SALE_CHANNEL_DCL               ,
  Null                                                                                      As SALE_CHANNEL_ORDER             ,
  Null                                                                                      As SALE_ORIGINE                   ,
  Coalesce(Placement.CUSTOMER_LAST_NAME,'IND')                                              As CUSTOMER_LAST_NAME             ,
  Placement.CUSTOMER_FIRST_NAME                                                             As CUSTOMER_FIRST_NAME            ,
  Coalesce(ActeUni.MSISDN_ID,'0000000000')                                                  As MISISDN                        ,
  Coalesce(ActeUni.NDS_VALUE_DS,'0000000000')                                               As ND                             ,
  Coalesce(ActeUni.EXTERNAL_PARTY_ID,'0000000000')                                          As NDIP                           ,
  Null                                                                                      As CUSTOMER_PARC                  ,
  Null                                                                                      As CUSTOMER_TYPE                  ,
  Null                                                                                      As CUSTOMER_SEG                   ,
  Null                                                                                      As CUSTOMER_SIRET                 ,
  Null                                                                                      As CUSTOMER_CAT                   ,
  Null                                                                                      As CUSTOMER_AGENCE                ,
  Placement.CUSTOMER_ZIPCODE                                                                As CUSTOMER_ZIPCODE               ,
  Null                                                                                      As ID_FREGATE                     ,
  Null                                                                                      As IMEI                           ,
  Null                                                                                      As EAN                            ,
  Null                                                                                      As SIM                            ,
  Null                                                                                      As OSCAR_VALUE                    ,
  Null                                                                                      As DUREE_ENGMENT                  ,
  '1'                                                                                       As VOLUM                          ,
  Null                                                                                      As VAL                            ,
  Case When ActeSrc.ACT_UNITE_CD = '${P_PIL_620}'
     Then Null
     Else TRIM(TD_SYSFNLIB.Oreplace(Cast(Placement.CA As Varchar(100)),',','.')) 
  End                                                                                       As CA                             ,
  Null                                                                                      As CSO_MOTIF                      ,
  Null                                                                                      As CSO_MOTIF_DES                  ,
  Null                                                                                      As DESCRIPTION                    ,
  ActeUni.ACT_REM_ID                                                                        As ACTE_CODE                      ,
  Null                                                                                      As CODE_TYPE_ORDER                ,
  Null                                                                                      As TYPE_ORDER_INI                 ,
  Null                                                                                      As CODE_TYPE_ORDER_NEW            ,
  Null                                                                                      As TYPE_ORDER_NEW                 ,
  ActeUni.ACT_PRODUCT_ID_PRE                                                                As CODE_PRODUCT_INI               ,
  Null                                                                                      As PRODUCT_DSC_INI                ,
  ActeUni.ACT_SEG_COM_ID_PRE                                                                As SEGMENT_COM_INI                ,
  ActeUni.ACT_CODE_MIGR_PRE                                                                 As CODE_MIGR_INI                  ,
  Null                                                                                      As DSC_MIGR_INI                   ,
  ActeUni.ACT_PRODUCT_ID_FINAL                                                              As CODE_PRODUCT_FIN               ,
  Cast(LibProduit.PRODUCT_DS As Varchar(50))                                                As PRODUCT_DSC_FIN                ,
  ActeUni.ACT_SEG_COM_ID_FINAL                                                              As SEGMENT_COM_FIN                ,
  ActeUni.ACT_CODE_MIGR_FINAL                                                               As CODE_MIGR_FIN                  ,
  Null                                                                                      As DSC_MIGR_FIN                   ,
  Null                                                                                      As DT_CHECK_PARC                  ,
  Null                                                                                      As DT_END_PARC                    ,
  Null                                                                                      As END_PARC_DSC                   ,
  Null                                                                                      As TAUX_PERENITE                  ,
  Null                                                                                      As CC_PLACEMENT                   ,
  Null                                                                                      As DELAI_PRENEITE                 ,
  Null                                                                                      As QUEUE_TS                       ,
  Null                                                                                      As STREAMING_TS                   ,
  Cast(
        SubString(Cast(ActeUni.CREATION_TS  As Char(22)) From 1 For 19) As Timestamp(0)
      )                                                                                     As ACT_CREATION_TS                ,
  Current_Timestamp(0)                                                                      As EXT_CREATION_TS                ,
  ActeUni.HOT_IN                                                                            As HOT_IN                         
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ActeUni
  Inner Join ${KNB_PCO_VM}.V_ACT_F_ACTE_DECLAR_PVC  ActeSrc
    On ActeUni.ACTE_ID = ActeSrc.ACTE_ID
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_DECLAR_PVC Placement
    On ActeUni.ACTE_ID = Placement.ACTE_ID
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduit
    On ActeUni.ACT_PRODUCT_ID_FINAL      = LibProduit.PRODUCT_ID
      And LibProduit.CURRENT_IN             = 1
  Left Outer Join ${KNB_SOC_O3}.V_ORG_F_EDO   RefEDO
    On ActeUni.ORG_EDO_ID                = RefEDO.EDO_ID
      And RefEDO.CURRENT_IN                 = 1
      And RefEDO.CLOSURE_DT                 Is Null      
Where
  (1=1)
  And ActeUni.CREATION_TS         = (Select Max(CREATION_TS) From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Where INTRNL_SOURCE_ID=14)
  --And ActeUni.ORG_REM_CHANNEL_CD  In (${ListeCanal})
  --And ActeUni.ACT_END_UNIFIED_DT  Is Null
  --And ActeUni.ACT_CLOSURE_DT      Is Null
  --And ActeUni.ACT_FLAG_ACT_REM    = 'O'
  --And ActeUni.MASTER_FLAG         = 1
  And ActeUni.INTRNL_SOURCE_ID    = 14
  And
      (
          RefEDO.NETWRK_TYP_EDO_ID Is Null
          Or RefEDO.NETWRK_TYP_EDO_ID = 'FT'
      )
  And Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_VM}.V_ACT_F_ACTE_SENT_PVC ActeSended
    Where
      (1=1)
      And ActeUni.ACTE_ID   = ActeSended.ACTE_ID
  )
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_T_PVC_DAY_HOT_OS;
.if errorcode <> 0 Then .quit 1;

