-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_CRF_Referentiel_ParcPCAParRefCom.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  IDENTIFICATION DES EDP ASSOCIES AUX PRODUITS AGAP PREALABLEMENT EXTRAITS
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------

DELETE FROM      ${KNB_PCO_TMP}.INB_W_PARK_HRF ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INB_W_PARK_HRF
                  (
                    PARK_ID
                  , REALZTN_DT
                  , REALIZTN_HH
                  , CANCELLNG_DT
                  , CANCELLNG_HH
                  , COMPST_OFFR_ID
                  , ATOMIC_OFFR_ID
                  , FUNCTN_ID   
                  , FUNCTN_VALUE_ID
                  , PRODUCT_ID
                  )
SELECT             INB_F_PARK.PARK_ID                                                                                                   AS PARK_ID
                 , INB_F_PARK.REALZTN_DT                                                                                                AS REALZTN_DT
                 , INB_F_PARK.REALIZTN_HH                                                                                               AS REALIZTN_HH
                 , INB_F_PARK.CANCELLNG_DT                                                                                              AS CANCELLNG_DT
                 , INB_F_PARK.CANCELLNG_HH                                                                                              AS CANCELLNG_HH
                 , INB_F_PARK.COMPST_OFFR_ID                                                                                            AS COMPST_OFFR_ID
                 , INB_F_PARK.ATOMIC_OFFR_ID                                                                                            AS ATOMIC_OFFR_ID
                 , INB_F_PARK.FUNCTN_ID                                                                                                 AS FUNCTN_ID   
                 , INB_F_PARK.FUNCTN_VALUE_ID                                                                                           AS FUNCTN_VALUE_ID
                 , CAT_R_REF_PRODUCT_HRF.PRODUCT_ID                                                                                     AS PRODUCT_ID
FROM             ${KNB_COM_SOC_V_PRS}.INB_F_PARK                                                                                           INB_F_PARK
JOIN             ${KNB_PCO_TMP}.CAT_R_REF_PRODUCT_HRF                                                                                      CAT_R_REF_PRODUCT_HRF
ON                 1                                                                                                             =         1
AND                INB_F_PARK.COMPST_OFFR_ID                                                                                     =         CAT_R_REF_PRODUCT_HRF.COMPST_OFFR_ID
AND                COALESCE(INB_F_PARK.ATOMIC_OFFR_ID, '-1')                                                                     =         COALESCE(CAT_R_REF_PRODUCT_HRF.ATOMIC_OFFR_ID, '-1')
AND                COALESCE(INB_F_PARK.FUNCTN_ID, '-1')                                                                          =         COALESCE(CAT_R_REF_PRODUCT_HRF.FUNCTN_ID, '-1')
AND                COALESCE(INB_F_PARK.FUNCTN_VALUE_ID, '-1')                                                                    =         COALESCE(CAT_R_REF_PRODUCT_HRF.FUNCTN_VALUE_ID, '-1')
WHERE              1                                                                                                             =         1
-- SELECTION DE L'ETAT COURANT DES EDP ACTIFS
AND                INB_F_PARK.CURRENT_IN                                                                                         =         1
AND                INB_F_PARK.CLOSURE_DT                                                                                         IS NULL
-- SELECTION EXCLUSIVE DU PARC INSTALLE: LA DATE D'INSTALLATION EST VALORISE
AND                INB_F_PARK.REALZTN_DT                                                                                         IS NOT NULL
-- SELECTION EXCLUSIVE DES ELEMENTS DE PARC CORRESPONDANT A DES OFFRES D'ACCES OU BIEN DES OFFRES COMPOSITES
AND                INB_F_PARK.TYP_PRODCT_EXTRNL_ID                                                                               IN     (${L_PIL_017})
;

.IF ERRORCODE <> 0 THEN .QUIT 1;
