-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_EXF_Acte_Cold_Alimentation_Step3_CalculActe.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de transformation d'acte
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 15/07/2014      OCH         Creation
-- 06/10/2014      YZH         Evol RPVC
-- 20/01/2017      JCR         Correction dernier jour periode REFCOM
-- 13/09/2017      MEL         Evol Orange Money
-- 21/11/2017      HOB         Alimentation Champs IOBSP
-- 08/11/2018      LMU         Modifications : QC 1798 : Prise en compte REINJ
-- 11/03/2019      LMU          Modifications : Calcul de l'axe canal via O3
-- 19/03/2019      SSI          Modifications : Calcul de l'axe canal via O3
-- 11/04/2019      JCR         Implementation d'une nouvelle matrice
-- 04/06/2019      JCR         Repackaging G14R50C00P02
-- 02/10/2019      EVI         Alimentation Champs KPI2020 : UNITE_CD / FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF
-- 20/04/2020      YAB         Modification d'alimentation de ACT_DELTA_TARIF  KPI2020
-- 14/01/2021      BCH         PILCOM-1086 : Decom ORG_WEB_PARTNER_IN
--------------------------------------------------------------------------------

.set width 2500;

Delete From ${KNB_PCO_TMP}.ACT_T_ACTE_EXF_C All;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ACT_T_ACTE_EXF_C
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_INJECTION_TS                ,
  ORDER_EXTERNAL_ID                 ,
  INTRNL_SOURCE_ID                  ,
  ORDER_NATURE_CD                   ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_PRODUCT_DS_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  PAR_CA_AM                         ,
  PAR_CA_LINE_AM                    ,
  FLAG_HD                           ,
  ORG_CHANEL_CD                     ,
  ORG_SUB_CHANEL_CD                 ,
  ORG_SUB_SUB_CHANEL_CD             ,
  ORG_REM_CHANEL_CD                 ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_EDO_IOBSP                     ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_TYPE_GEO_IN                   ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP                   ,
  ORG_LAST_NAME_NM                  ,
  ORG_FIRST_NAME_NM                 ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REAL_ID                 ,
  ORG_RESP_REF_TRAV_ID              ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  ORG_TYPE_CD                       ,
  ORG_TEAM_LEVEL_1_CD               ,
  ORG_TEAM_LEVEL_1_DS               ,
  ORG_TEAM_LEVEL_2_CD               ,
  ORG_TEAM_LEVEL_2_DS               ,
  ORG_TEAM_LEVEL_3_CD               ,
  ORG_TEAM_LEVEL_3_DS               ,
  ORG_TEAM_LEVEL_4_CD               ,
  ORG_TEAM_LEVEL_4_DS               ,
  WORK_TEAM_LEVEL_1_CD              ,
  WORK_TEAM_LEVEL_1_DS              ,
  WORK_TEAM_LEVEL_2_CD              ,
  WORK_TEAM_LEVEL_2_DS              ,
  WORK_TEAM_LEVEL_3_CD              ,
  WORK_TEAM_LEVEL_3_DS              ,
  WORK_TEAM_LEVEL_4_CD              ,
  WORK_TEAM_LEVEL_4_DS              ,
  PAR_LAST_NAME_CUSTOMER_NM         ,
  PAR_FIRST_NAME_CUSTOMER_NM        ,
  PAR_MISISDN_ID                    ,
  PAR_ND_ID                         ,
  PAR_NDIP_ID                       ,
  PAR_TYPE_CUSTOMER_CD              ,
  PAR_TYPE_SOURCE_CD                ,
  PAR_ENGAGMNT_NB                   ,
  PAR_OSCAR_VALUE_CD                ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLOSURE_DT                        ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN
)
Select
  Placement.ACTE_ID                                         As ACTE_ID                            ,
  Placement.ACTE_ID                                         As ACTE_ID_GEN                        ,
  Placement.ORDER_DEPOSIT_DT                                As ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                As ORDER_DEPOSIT_TS                   ,
  Placement.INJECTION_TS                                    As ORDER_INJECTION_TS                 ,
  Placement.NUM_ORDER_NU                                    As ORDER_EXTERNAL_ID                  ,
  Placement.INTRNL_SOURCE_ID                                As INTRNL_SOURCE_ID                   ,
  Placement.NATURE_CD                                       As ORDER_NATURE_CD                    ,
  Acte.PRODUCT_ID_PRE                                       As ACT_PRODUCT_ID_PRE                 ,
  Null                                                      As ACT_PRODUCT_DS_PRE                 ,
  Acte.SEG_COM_ID_PRE                                       As ACT_SEG_COM_ID_PRE                 ,
  Acte.CODE_MIGR_PRE                                        As ACT_CODE_MIGR_PRE                  ,
  Acte.SEG_COM_AGG_ID_PRE                                   As ACT_SEG_COM_AGG_ID_PRE             ,
  Null                                                      As ACT_OPER_ID_PRE                    ,
  Acte.PRODUCT_ID_FINAL                                     As ACT_PRODUCT_ID_FINAL               ,
  Null                                                      As ACT_PRODUCT_DS_FINAL               ,
  Acte.SEG_COM_ID_FINAL                                     As ACT_SEG_COM_ID_FINAL               ,
  Acte.SEG_COM_AGG_ID_FINAL                                 As ACT_SEG_COM_AGG_ID_FINAL           ,
  Acte.CODE_MIGR_FINAL                                      As ACT_CODE_MIGR_FINAL                ,
  Null                                                      As ACT_OPER_ID_FINAL                  ,
  Acte.TYPE_SERVICE_FINAL                                   As ACT_TYPE_SERVICE_FINAL             ,
  Coalesce(Acte.TYPE_COMMANDE_ID, '${P_PIL_026}')           As ACT_TYPE_COMMANDE_ID               ,
  CASE
    -- Unite = NB  
    WHEN Acte.UNITE_CD ='${P_PIL_620}' 
         THEN Case When ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
                        Then Placement.CA_LINE_AM
                        Else Null
              End
    ELSE Placement.CA_LINE_AM
  END                                                       As ACT_DELTA_TARIF                    ,         
  Acte.UNITE_CD                                             As ACT_UNITE_CD                       ,
  Acte.ACT_CD                                               As ACT_CD                             ,
  Coalesce(Acte.ACTE_REM_ID,'${P_PIL_067}')                 As ACT_REM_ID                         ,
  Coalesce(Acte.FLAG_ACT_REM,'N')                           As ACT_FLAG_ACT_REM                   ,
  Coalesce(Acte.FLAG_PEC_PERPVC,'N')                        As ACT_FLAG_PEC_PERPVC                ,
  CASE
    -- Unite = NB  
    WHEN Acte.UNITE_CD ='${P_PIL_620}' 
         THEN   Acte.ACTE_VALO
    ELSE (ACT_DELTA_TARIF  * Acte.TAUX_MARGE )
  END                                                       As ACT_ACTE_VALO                      ,         
  Coalesce(Acte.ACTE_FAMILLE_KPI,'NON PARAM')               As ACT_ACTE_FAMILLE_KPI               ,
  Acte.PERIODE_ID                                           As ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                 As ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            As ACT_PERIODE_CLOSURE_DT             ,
  Placement.CA_AM                                           As PAR_CA_AM                          ,
  --Placement.CA_LINE_AM                                      As PAR_CA_LINE_AM                     ,
  ACT_DELTA_TARIF                                           As PAR_CA_LINE_AM                     ,
  Acte.HUMAINDIGITAL                                        As FLAG_HD                            ,
  --Calcul du canal de vente Macro
  Case  When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('BTQ','PSE', 'PST','CONS','GSA','GSS')
          Then 'Dist' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL In ('OCA','ORM')
          Then 'Dist' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('GSA','GSS')
          Then 'Dist' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ATH'
          Then 'AT Home'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'SCC'
          Then 'Online'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'PAE'
          Then 'MD AS'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') 
              And (RefO3.VAL_AXS_CLSSF_ID_CVG Not In ('OPEN','SOSH') Or RefO3.VAL_AXS_CLSSF_ID_CVG Is Null)
          Then 'SCH'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') Or RefO3.VAL_AXS_CLSSF_ID_PSFL = '700'
          Then 'SCO'
        Else 'Exclus'
  End                                                      As ORG_CHANEL_CD_AGR                     ,
  --Sous Canal
  Case  When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'BTQ'
          Then 'AD'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('PSE', 'PST') Or RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OCA'
          Then 'RP'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'CONS' And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ORM'
          Then 'RC'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ORM'
          Then 'RP'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('GSA','GSS')
          Then 'RC' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ATH'
          Then 'ATH'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'SCC'
          Then 'Web'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'PAE'
          Then 'Proactif'
        When ORG_CHANEL_CD_AGR = 'SCO' And RefO3.VAL_AXS_CLSSF_ID_PSFL = '700'
          Then 'mobile'
        When ORG_CHANEL_CD_AGR = 'SCO' And RefO3.VAL_AXS_CLSSF_ID_PSFL <> '700'
          Then 'convergent'
        Else 'Exclus'
  End                                                       As ORG_SUB_CHANEL_CD                 ,
  --Sous-Sous-Canal
  Case  When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'BTQ' 
              And (RefO3.VAL_AXS_CLSSF_ID_GMM Not In ('REUNION','CARAIBES') Or RefO3.VAL_AXS_CLSSF_ID_GMM Is Null)
          Then 'Metropole'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'BTQ' And RefO3.VAL_AXS_CLSSF_ID_GMM In ('REUNION','CARAIBES')
          Then 'Dom'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('PSE', 'PST') 
              And (RefO3.VAL_AXS_CLSSF_ID_GMM Not In ('REUNION','CARAIBES') Or RefO3.VAL_AXS_CLSSF_ID_GMM Is Null)
          Then 'Metropole'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('PSE', 'PST') And RefO3.VAL_AXS_CLSSF_ID_GMM In ('REUNION','CARAIBES')
          Then 'Dom'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OCA'
          Then 'Dom'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'CONS' And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ORM'
          Then 'Dom'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ORM'
          Then 'Dom'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'GSA'
          Then 'GSA' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'GSS'
          Then 'GSS' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL In ('ATH', 'SCC')
          Then Null
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'PAE'
          Then 'Proactif'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') 
              And (RefO3.VAL_AXS_CLSSF_ID_CVG Not In ('OPEN','SOSH') Or RefO3.VAL_AXS_CLSSF_ID_CVG Is Null)
          Then 'SCH'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OFP'
          Then 'Front Prevenance'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH' ) Or RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014', 'GSCR')
              Or RefO3.VAL_AXS_CLSSF_ID_PSFL = '700'
          Then 'Front'
        Else 'Exclus'
  End                                                       As ORG_SUB_SUB_CHANEL_CD             ,
  --Canal de Rem
  Case  When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'BTQ' 
              And (RefO3.VAL_AXS_CLSSF_ID_GMM Not In ('REUNION','CARAIBES') Or RefO3.VAL_AXS_CLSSF_ID_GMM Is Null)
          Then 'AD'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'BTQ' And RefO3.VAL_AXS_CLSSF_ID_GMM In ('REUNION','CARAIBES')
          Then 'AD'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('PSE', 'PST') 
              And (RefO3.VAL_AXS_CLSSF_ID_GMM Not In ('REUNION','CARAIBES') Or RefO3.VAL_AXS_CLSSF_ID_GMM Is Null)
          Then 'Exclus'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('PSE', 'PST') And RefO3.VAL_AXS_CLSSF_ID_GMM In ('REUNION','CARAIBES')
          Then 'Exclus'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL In ('OCA', 'ORM', 'ATH')
          Then 'Exclus'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'CONS' And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ORM'
          Then 'Exclus'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'GSA'
          Then 'Exclus' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'GSS'
          Then 'Exclus' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'SCC'
          Then 'Online'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'PAE'
          Then 'MD AS'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') 
              And (RefO3.VAL_AXS_CLSSF_ID_CVG Not In ('OPEN','SOSH') Or RefO3.VAL_AXS_CLSSF_ID_CVG Is Null)
          Then 'SCO'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OFP'
              And RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') 
          Then 'SCH'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OFP'
          Then 'SCO'
        When  RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH')
          Then 'SCO'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') And RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') 
          Then 'SCH'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = '700'
          Then 'SCH'
        Else 'Exclus'
  End                                                       As ORG_REM_CHANEL_CD                 ,
  --GT/Activité
  Case  When RefO3.VAL_AXS_CLSSF_ID_SSCNL = 'BTQ'
          Then 'Boutique FT'
        When RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('PSE', 'PST')
          Then 'GDT'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OCA'
          Then 'Caraibes'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'ORM'
          Then 'Reunion'
        When RefO3.VAL_AXS_CLSSF_ID_PSFL In ('ATH', 'SCC')
          Then Null
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'POD' And RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('GSA', 'GSS')
          Then 'Reseau Concurrent' 
        When RefO3.VAL_AXS_CLSSF_ID_PSFL = 'PAE'
          Then 'Proactif'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OFP'
              And RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') 
          Then 'Front Prevenance'
        When RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') And RefO3.VAL_AXS_CLSSF_ID_PSFL = 'OFP'
          Then 'Front Prevenance'
        When  RefO3.VAL_AXS_CLSSF_ID_CVG In ('OPEN', 'SOSH') Or RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR')
          Then 'Front Open'
        When  RefO3.VAL_AXS_CLSSF_ID_SSCNL In ('1014','GSCR') Or RefO3.VAL_AXS_CLSSF_ID_PSFL = '700'
          Then 'Front'
        Else 'Exclus'
  End                                                       As ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  'NONPARAM'                                                As ORG_FIDELISATION                   ,
  --Activité Web
  Case  When RefO3.VAL_AXS_CLSSF_ID_PSFL ='SCC'
          Then 'OUI'
        Else 'NON'
  End                                                       As ORG_WEB_ACTIVITY                   ,
  --Activité Automatique
  'NON'                                                     As ORG_AUTO_ACTIVITY                  ,
  RefO3.EDO_ID                                              As ORG_EDO_ID                         ,
  RefO3.TYPE_EDO_IN                                         As ORG_TYPE_EDO                       ,
  Placement.ORG_EDO_IOBSP                                   As ORG_EDO_IOBSP                      ,
  Placement.NETWRK_TYP_EDO_ID                               As ORG_NETWRK_TYP_EDO_ID              ,
  Placement.PLT_CONV_IN                                     As ORG_FLAG_PLT_CONV                  ,
  Placement.TEAM_MKT_IN                                     As ORG_FLAG_TEAM_MKT                  ,
  Placement.TYPE_CMP_IN                                     As ORG_FLAG_TYPE_CMP                  ,
  Placement.TYPE_GEO_IN                                     As ORG_TYPE_GEO_IN                    ,
  Placement.TYPE_CPT_NTK_IN                                 As ORG_FLAG_TYPE_CPT_NTK              ,
  Null                                                      As ORG_REF_TRAV                       ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.AGENT_ID)       As ORG_AGENT_ID                       ,
  Null                                                      As ORG_POC_XI                         ,
  Coalesce(RetourGRV.AGENT_ID_UPD,Placement.ORG_AGENT_ID,Placement.AGENT_ID)  As ORG_AGENT_ID_UPD ,
  Cast(RetourGRV.AGENT_ID_UPD_TS as date Format 'YYYYMMDD') As ORG_AGENT_ID_UPD_DT                ,
  Placement.ORG_AGENT_IOBSP                                 As ORG_AGENT_IOBSP                    ,
  Coalesce(RetourGRV.ORG_NOM,Placement.ORG_LAST_NAME_NM)    As ORG_LAST_NAME_NM                   ,
  Coalesce(RetourGRV.ORG_PRENOM,Placement.ORG_FIRST_NAME_NM) As ORG_FIRST_NAME_NM                 ,
  Null                                                      As ORG_GROUPE_ID                      ,
  -- Calcul de l'activitée
  Placement.ORG_ACTVT_REAL_ID                               As ORG_ACTVT_REAL_ID                  ,
  Placement.ORG_RESP_REF_TRAV_ID                            As ORG_RESP_REF_TRAV_ID               ,
  Placement.ORG_RESP_AGENT_ID                               As ORG_RESP_AGENT_ID                  ,
  Placement.ORG_RESP_XI_ID                                  As ORG_RESP_XI                        ,
  -- Calcul des EDO
  Null                                                      As ORG_TYPE_CD                        ,
  Placement.EDO_ID                                          As ORG_TEAM_LEVEL_1_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_1_DS                ,
  Null                                                      As ORG_TEAM_LEVEL_2_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_2_DS                ,
  Null                                                      As ORG_TEAM_LEVEL_3_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_3_DS                ,
  Null                                                      As ORG_TEAM_LEVEL_4_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_4_DS                ,
  WORKO3ENR.WORK_TEAM_LEVEL_1_CD                            As WORK_TEAM_LEVEL_1_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_1_DS                            As WORK_TEAM_LEVEL_1_DS               ,
  WORKO3ENR.WORK_TEAM_LEVEL_2_CD                            As WORK_TEAM_LEVEL_2_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_2_DS                            As WORK_TEAM_LEVEL_2_DS               ,
  WORKO3ENR.WORK_TEAM_LEVEL_3_CD                            As WORK_TEAM_LEVEL_3_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_3_DS                            As WORK_TEAM_LEVEL_3_DS               ,
  WORKO3ENR.WORK_TEAM_LEVEL_4_CD                            As WORK_TEAM_LEVEL_4_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_4_DS                            As WORK_TEAM_LEVEL_4_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                           As PAR_LAST_NAME_CUSTOMER_NM          ,
  Placement.FIRST_NAME_CUSTOMER_NM                          As PAR_FIRST_NAME_CUSTOMER_NM         ,
  Placement.MISISDN_ID                                      As PAR_MISISDN_ID                     ,
  Placement.ND_ID                                           As PAR_ND_ID                          ,
  Placement.NDIP_ID                                         As PAR_NDIP_ID                        ,
  Placement.TYPE_CUSTOMER_CD                                As PAR_TYPE_CUSTOMER_CD               ,
  Placement.TYPE_SOURCE_CD                                  As PAR_TYPE_SOURCE_CD                 ,
  Placement.ENGAGMNT_NB                                     As PAR_ENGAGMNT_NB                    ,
  Placement.OSCAR_VALUE_CD                                  As PAR_OSCAR_VALUE_CD                 ,
  '${P_PIL_402}'                                            As CHECK_INITIAL_STATUS_CD            ,
  RetournCSO.CHECK_NAT_STATUS_CD                            As CHECK_NAT_STATUS_CD                ,
  RetournCSO.CHECK_NAT_COMMENT                              As CHECK_NAT_COMMENT                  ,
  RetournCSO.CHECK_NAT_STATUS_LN                            As CHECK_NAT_STATUS_LN                ,
  RetournCSO.CHECK_LOC_STATUS_CD                            As CHECK_LOC_STATUS_CD                ,
  RetournCSO.CHECK_LOC_COMMENT                              As CHECK_LOC_COMMENT                  ,
  RetournCSO.CHECK_LOC_STATUS_LN                            As CHECK_LOC_STATUS_LN                ,
  RetournCSO.CHECK_VALIDT_DT                                As CHECK_VALIDT_DT                    ,
  Case When Placement.TYPE_MOVEMENT_CD IN ('SUPP') then  Current_Timestamp(0)
       Else Null
  END                                                       As CLOSURE_DT                         ,
  '${KNB_DATE_VACATION}'                                    As CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                    As LAST_MODIF_TS                      ,
  0                                                         As HOT_IN                             ,
  1                                                         As FRESH_IN                           ,
  0                                                         As COHERENCE_IN
From
  ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_EXTR Placement
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA Acte
    On   Placement.ACT_REM_ID              = Acte.ACTE_REM_ID
    And  Acte.PERIODE_ID  = (Select PERIODE_ID
                             From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM
                             Where PERIODE_DATE_FIN >= PLACEMENT.ORDER_DEPOSIT_DT
                             And  PERIODE_DATE_DEB <= PLACEMENT.ORDER_DEPOSIT_DT
                             And CURRENT_IN=1
                             And FRESH_IN=1)
  Left Outer Join ${KNB_PCO_TMP}.ACT_W_ACTE_EXF_C_O3 WORKO3ENR
    On    Placement.ACTE_ID                       = WORKO3ENR.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT              = WORKO3ENR.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID           = RetourGRV.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RetourGRV.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                       = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG           = 1
      And RetournCSO.CURRENT_IN                   = 1
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    Acte.PERIODE_ID                                   = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                               = 1
      And EtatPeriode.FRESH_IN                                 = 1
      And EtatPeriode.CLOSURE_DT                               Is Null
  Left Outer Join ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3 RefO3 -- Nouveau calcul axe canal via O3
    On    Placement.ACTE_ID           = RefO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RefO3.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_PDV Soft_pdv
    On    RefO3.EXTNL_VAL_COD_CD = Soft_pdv.PDV
  
Where
  (1=1)
  And Placement.EDO_ID Is Not Null
  Qualify Row_Number() Over(Partition by
                                        Placement.ACTE_ID,
                                        Placement.ORDER_DEPOSIT_DT order by 1 Asc )=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ACT_T_ACTE_EXF_C;
.if errorcode <> 0 then .quit 1
