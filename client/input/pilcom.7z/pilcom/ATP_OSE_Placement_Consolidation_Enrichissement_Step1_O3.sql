--$HEADER:   mm2pco/current/sql/ATP_OSE_Placement_Consolidation_Enrichissement_Step1_O3.sql 13_05#3 21-MAR-2019 14:50:01 LXQG9925
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_OSE_Placement_Consolidation_Enrichissement_Step1_O3.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/07/2018       LMU         Creation
-- 17/09/2018       JCR         Modif
--------------------------------------------------------------------------------

.set width 2500;


.set width 2000;


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_HIERO3 all;
.if errorcode <> 0 then .quit 1



Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_HIERO3
(
      ACTE_ID                       ,
      ORDER_DEPOSIT_DT              ,
      WORK_TEAM_LEVEL_1_CD          ,
      WORK_TEAM_LEVEL_1_DS          ,
      WORK_TEAM_LEVEL_2_CD          ,
      WORK_TEAM_LEVEL_2_DS          ,
      WORK_TEAM_LEVEL_3_CD          ,
      WORK_TEAM_LEVEL_3_DS          ,
      WORK_TEAM_LEVEL_4_CD          ,
      WORK_TEAM_LEVEL_4_DS          
 )
Select
      Placement.ACTE_ID             ,
      Placement.ORDER_DEPOSIT_DT    ,
      Hier_Hie.ORG_TEAM_LEVEL_1_CD  ,
      Hier_Hie.ORG_TEAM_LEVEL_1_DS  ,
      Hier_Hie.ORG_TEAM_LEVEL_2_CD  ,
      Hier_Hie.ORG_TEAM_LEVEL_2_DS  ,
      Hier_Hie.ORG_TEAM_LEVEL_3_CD  ,
      Hier_Hie.ORG_TEAM_LEVEL_3_DS  ,
      Hier_Hie.ORG_TEAM_LEVEL_4_CD  ,
      Hier_Hie.ORG_TEAM_LEVEL_4_DS  
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_1 Placement
  Left Outer Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL As Hier_Hie
    On    Placement.EXTRNL_EDO_ID          = Hier_Hie.ORG_TEAM_LEVEL_1_CD
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_1_START_DT And Hier_Hie.ORG_TEAM_LEVEL_1_END_DT
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_2_START_DT And Hier_Hie.ORG_TEAM_LEVEL_2_END_DT
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_3_START_DT And Hier_Hie.ORG_TEAM_LEVEL_3_END_DT
      And Placement.ORDER_DEPOSIT_DT  Between Hier_Hie.ORG_TEAM_LEVEL_4_START_DT And Hier_Hie.ORG_TEAM_LEVEL_4_END_DT
Where
  (1=1)
  And (     Placement.EXTRNL_EDO_ID Is Not Null      )
Qualify Row_Number() Over(Partition by Placement.ACTE_ID Order By         Hier_Hie.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          Hier_Hie.ORG_TEAM_LEVEL_4_CD Desc
                        )=1
;
.if errorcode <> 0 then .quit 1

Collect Stats On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_OSE_HIERO3;
.if errorcode <> 0 then .quit 1
