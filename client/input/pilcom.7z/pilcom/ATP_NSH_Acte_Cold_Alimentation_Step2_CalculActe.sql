-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Acte_Cold_Alimentation_Step2_CalculActe.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de calcul des produit ini et final
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 18/03/2014      MCA         Creation
-- 18/07/2014      MCA         Indus
-- 04/12/2014      MCA         Ajout et alim des champs perform
-- 02/02/2015      YZH         Annul PERFORM
-- 27/05/2015      HFO         MODIFICATION   QC 1060
--------------------------------------------------------------------------------

.set width 2500;

--------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_C_CAL All;
.if errorcode <> 0 then .quit 1
--------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
--On realise le calcul pour les produits non migrable
-----------------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_C_CAL
(
  ACTE_ID                                       ,
  EXTERNAL_ORDER_ID                             ,
  ORDER_DEPOSIT_DT                              ,
  OTO_OSCAR_VALUE_NU                            ,
  PERIODE_ID                                    ,
  EXTERNAL_PRODUCT_ID_PRE                       ,
  PRODUCT_ID_PRE                                ,
  SEG_COM_ID_PRE                                ,
  SEG_COM_AGG_ID_PRE                            ,
  CODE_MIGR_PRE                                 ,
  PRODUCT_ID_FINAL                              ,
  SEG_COM_ID_FINAL                              ,
  SEG_COM_AGG_ID_FINAL                          ,
  CODE_MIGR_FINAL                               ,
  TYPE_SERVICE_FINAL                            ,
  TYPE_COMMANDE_ID                              ,
  DELTA_TARIF                                   ,
  PAYMNT_FORMLTN_ID                             ,
  MONTHL_PRIC                                   ,
  MONTHL_PERD                                   

)
Select
  ActeCreation.ACTE_ID                                                        as ACTE_ID                        ,
  ActeCreation.EXTERNAL_ORDER_ID                                              as EXTERNAL_ORDER_ID              ,
  ActeCreation.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT               ,
  ActeCreation.OTO_OSCAR_VALUE_NU                                             as OTO_OSCAR_VALUE_NU             ,
  ActeCreation.PERIODE_ID                                                     as PERIODE_ID                     ,
  ActeCreation.EXTERNAL_PRODUCT_ID_PRE                                        as EXTERNAL_PRODUCT_ID_PRE        ,
  ActeCreation.PRODUCT_ID_PRE                                                 as PRODUCT_ID                     ,
  ActeCreation.SEG_COM_ID_PRE                                                 as SEG_COM_ID_PRE                 ,
  ActeCreation.SEG_COM_AGG_ID_PRE                                             as SEG_COM_AGG_ID_PRE             ,
  ActeCreation.CODE_MIGRATION_PRE                                             as CODE_MIGR_PRE                  ,
  ActeCreation.PRODUCT_ID                                                     as PRODUCT_ID_FINAL               ,
  ActeCreation.SEG_COM_ID                                                     as SEG_COM_ID_FINAL               ,
  ActeCreation.SEG_COM_AGG_ID                                                 as SEG_COM_AGG_ID_FINAL           ,
  ActeCreation.CODE_MIGRATION                                                 as CODE_MIGR_FINAL                ,
  ActeCreation.TYPE_SERVICE                                                   as TYPE_SERVICE_FINAL             ,
  --Calcul Du Type de commande
  Case  When MatMig.FLAG_EXPL_TARIF = '${P_PIL_101}' --Si on ne doit pas exploiter le delta tarif alors c'est le type commande (+le suffix)
          Then MatMig.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        When MatMig.FLAG_EXPL_TARIF = '${P_PIL_100}' --Cas ou on doit exploiter le delta tarif
          Then DeltaTarif.TYPE_COMMANDE_ID||Coalesce(MatMig.SUFFIXE_TYPE_CDE,'')
        Else Coalesce(DeltaTarif.TYPE_COMMANDE_ID,'${P_PIL_103}')
  End                                                                         as TYPE_COMMANDE_ID               ,
  (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0)) as DELTA_TARIF                    ,
  ActeCreation.PAYMNT_FORMLTN_ID                                              as PAYMNT_FORMLTN_ID              ,
  ActeCreation.MONTHL_PRIC                                                    as MONTHL_PRIC                    ,
  ActeCreation.MONTHL_PERD                                                    as MONTHL_PERD                    
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_C_PRECAL ActeCreation
  --Jointure sur la matrice de migration suivant le produit final + le mouvement Final
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM MatMig
    On ActeCreation.CODE_MIGRATION        = MatMig.CODE_MIGRATION_FINAL
      And '${P_PIL_005}'                  = MatMig.MOUVEMENT_FINAL
      And ActeCreation.PERIODE_ID         = MatMig.PERIODE_ID
      And ActeCreation.CODE_MIGRATION_PRE = MatMig.CODE_MIGRATION_INITIAL
      And '${P_PIL_008}'                  = MatMig.MOUVEMENT_INITIAL
      And MatMig.CURRENT_IN               = 1
      And MatMig.CLOSURE_DT               is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PRIX_TYPE_COMMANDE DeltaTarif --On realise le delta tarif entre l'offre avant/Apres
    On    (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0))   >= DeltaTarif.VAL_MIN
      And (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0))   <= DeltaTarif.VAL_MAX
      And ActeCreation.PERIODE_ID                                                       = DeltaTarif.PERIODE_ID
      And DeltaTarif.CURRENT_IN                                                         = 1
      And DeltaTarif.CLOSURE_DT                                                         Is Null
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE   = ${P_PIL_019}
  And ActeCreation.SEG_COM_ID_PRE       Is Not Null
Qualify Row_Number() Over (Partition by ActeCreation.ACTE_ID order by ActeCreation.CODE_MIGRATION desc)=1

-----------------------------------------------------------------------------------------------------
--On realise le calcul pour les produits non migrable
-----------------------------------------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_C_CAL
(
  ACTE_ID                                       ,
  EXTERNAL_ORDER_ID                             ,
  ORDER_DEPOSIT_DT                              ,
  OTO_OSCAR_VALUE_NU                            ,
  PERIODE_ID                                    ,
  EXTERNAL_PRODUCT_ID_PRE                       ,
  PRODUCT_ID_PRE                                ,
  SEG_COM_ID_PRE                                ,
  SEG_COM_AGG_ID_PRE                            ,
  CODE_MIGR_PRE                                 ,
  PRODUCT_ID_FINAL                              ,
  SEG_COM_ID_FINAL                              ,
  SEG_COM_AGG_ID_FINAL                          ,
  CODE_MIGR_FINAL                               ,
  TYPE_SERVICE_FINAL                            ,
  TYPE_COMMANDE_ID                              ,
  DELTA_TARIF                                   ,
  PAYMNT_FORMLTN_ID                             ,
  MONTHL_PRIC                                   ,
  MONTHL_PERD                                   
)
Select
  ActeCreation.ACTE_ID                                                        as ACTE_ID                        ,
  ActeCreation.EXTERNAL_ORDER_ID                                              as EXTERNAL_ORDER_ID              ,
  ActeCreation.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT               ,
  ActeCreation.OTO_OSCAR_VALUE_NU                                             as OTO_OSCAR_VALUE_NU             ,
  ActeCreation.PERIODE_ID                                                     as PERIODE_ID                     ,
  Null                                                                        as EXTERNAL_PRODUCT_ID_PRE        ,
  Null                                                                        as PRODUCT_ID_PRE                 ,
  --On ne valorise le produit precedant que lorsqu'on a detecter une migration :
  Null                                                                        as SEG_COM_ID_PRE                 ,
  Null                                                                        as SEG_COM_AGG_ID_PRE             ,
  Null                                                                        as CODE_MIGR_PRE                  ,
  ActeCreation.PRODUCT_ID                                                     as PRODUCT_ID_FINAL               ,
  ActeCreation.SEG_COM_ID                                                     as SEG_COM_ID_FINAL               ,
  ActeCreation.SEG_COM_AGG_ID                                                 as SEG_COM_AGG_ID_FINAL           ,
  ActeCreation.CODE_MIGRATION                                                 as CODE_MIGR_FINAL                ,
  ActeCreation.TYPE_SERVICE                                                   as TYPE_SERVICE_FINAL             ,
  --Calcul Du Type de commande
  '${P_PIL_026}'                                                              as TYPE_COMMANDE_ID               ,
  (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeCreation.TARIF_HT_PRE,0)) as DELTA_TARIF                    ,
  ActeCreation.PAYMNT_FORMLTN_ID                                              as PAYMNT_FORMLTN_ID              ,
  ActeCreation.MONTHL_PRIC                                                    as MONTHL_PRIC                    ,
  ActeCreation.MONTHL_PERD                                                    as MONTHL_PERD                    
From
  --Pannel des Actes a rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_C_PRECAL ActeCreation
Where
  (1=1)
  And  ( ActeCreation.MIGRATION_POSSIBLE=0
        Or ActeCreation.SEG_COM_ID_PRE Is Null
        )
;
.if errorcode <> 0 then .quit 1
