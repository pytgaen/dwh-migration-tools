--$HEADER:  %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_ERDV_AlimHot_ORD_T_ACTE_UNIFIED_ERDV.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données chaudes de la source ERDV dans la table ORD_T_ACTE_UNIFIED_H_ERDV 
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 09/12/2014     KBH         Création
-- 09/03/2015     YZH         Correction
-- 10/03/2015     YZH         Modification
-- 19/06/2015     OCH         Modif: digital
-- 02/11/2016     HOB         Modification VA
-- 14/03/2017     HLA         Modification 
-- 21/11/2017     HOB         Alimentation Champs IOBSP
-- 23/09/2019     SSI         Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
-- 07/07/2020     EVI         PILCOM-504 : Indicateur eSim - New Champ SIM_EAN_CD
-- 19/10/2021     EVI         PILCOM-965 : Refonte VU - Decom Champs Obsolètes
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_H_ERDV --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_ERDV;
.if errorcode <> 0 then .quit 1;

-- ERDV

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_ERDV 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_EDO_IOBSP                 ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  ACT_CA_LINE_AM                ,
  --EAN_CD                        ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  ERDV.ACTE_ID                                                              As ACTE_ID                         ,
  Null                                                                      As OPERATOR_PROVIDER_ID            ,
  ERDV.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID                ,
  'RDV'                                                                     As TYPE_SOURCE_ID                  ,
  ERDV.ACTE_ID                                                              As MASTER_ACTE_ID                  ,
  ERDV.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID         ,
  ${P_PIL_354}                                                              As MASTER_FLAG                     ,
  ${P_PIL_375}                                                              As MASTER_NB_FOUND                 ,
  Null                                                                      As CPLT_ACTE_ID                    ,
  Null                                                                      As CPLT_INTRNL_SOURCE_ID           ,
  '${P_PIL_388}'                                                            As CPLT_IN                         ,
  '${P_PIL_362}'                                                            As RULE_ID                         ,
  Null                                                                      As OFFSET_NB                       ,
  '${P_PIL_324}'                                                            As ACT_TYPE                        ,
  ERDV.EXTERNAL_ORDER_ID                                                    As ORDER_EXTERNAL_ID               ,
  '${P_PIL_397}'                                                            As STATUS_CD                       ,
  '${P_PIL_381}'                                                            As ACT_UNIFIED_STATUS_CD           ,
  ERDV.ORDER_DEPOSIT_TS                                                     As ACT_TS                          ,
  ERDV.ORDER_DEPOSIT_DT                                                     As ACT_DT                          ,
  Extract(HOUR From ERDV.ORDER_DEPOSIT_TS)                                  As ACT_HH                          ,
  ERDV.ORDER_DEPOSIT_TS                                                     As ACT_LAST_UPD_TS                 ,
  ERDV.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE              ,
  ERDV.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE              ,
  ERDV.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE          ,
  ERDV.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE               ,
  Case When ACT_PRODUCT_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                       As ACT_OPER_ID_PRE                 ,
  ERDV.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL            ,
  ERDV.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL            ,
  ERDV.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL        ,
  ERDV.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL             ,
  ERDV.ACT_OPER_ID_FINAL                                                    As ACT_OPER_ID_FINAL               ,
  ERDV.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL          ,
  ERDV.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID            ,
  ERDV.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF                 ,
  ERDV.ACT_CD                                                               As ACT_CD                          ,
  ERDV.ACT_REM_ID                                                           As ACT_REM_ID                      ,
  ERDV.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM                ,
  ERDV.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC             ,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And ERDV.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And ERDV.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And ERDV.ORG_REM_CHANNEL_CD In (${L_PIL_043})
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And ERDV.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And ERDV.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                    -- Edo interne
                    And ( ERDV.ORG_TYPE_EDO        = 'INT' Or ERDV.ORG_TYPE_EDO  is Null )
                    
                )
        Then 'O' 
       Else 'N'  
  End                                                                       As ACT_FLAG_PVC_REM                ,
  ERDV.ACT_ACTE_VALO                                                        As ACT_ACTE_VALO                   ,
  ERDV.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI            ,
  ERDV.ACT_PERIODE_ID                                                       As ACT_PERIODE_ID                  ,
  Null                                                                      As ORIGIN_CD                       ,
  trim(ERDV.ORG_AGENT_ID )                                                  As AGENT_ID                        ,
  trim(ERDV.ORG_AGENT_ID )                                                  As AGENT_ID_UPD                    ,
  Null                                                                      As AGENT_ID_UPD_DT                 ,
  ERDV.ORG_AGENT_IOBSP                                                      As ORG_AGENT_IOBSP                 ,
  ERDV.ORG_PRENOM                                                           As AGENT_FIRST_NAME                ,
  ERDV.ORG_NOM                                                              As AGENT_LAST_NAME                 ,
  Null                                                                      As UNIFIED_SHOP_CD                 ,
  Null                                                                      As ORG_SPE_CANAL_ID_MACRO          ,
  Null                                                                      As ORG_SPE_CANAL_ID                ,
  ERDV.ORG_REM_CHANNEL_CD                                                   As ORG_REM_CHANNEL_CD              ,
  ERDV.ORG_CHANNEL_CD                                                       As ORG_CHANNEL_CD                  ,
  ERDV.ORG_SUB_CHANNEL_CD                                                   As ORG_SUB_CHANNEL_CD              ,
  ERDV.ORG_SUB_SUB_CHANNEL_CD                                               As ORG_SUB_SUB_CHANNEL_CD          ,
  ERDV.ORG_GT_ACTIVITY                                                      As ORG_GT_ACTIVITY                 ,
  ERDV.ORG_FIDELISATION                                                     As ORG_FIDELISATION                ,
  ERDV.ORG_WEB_ACTIVITY                                                     As ORG_WEB_ACTIVITY                ,
  ERDV.ORG_AUTO_ACTIVITY                                                    As ORG_AUTO_ACTIVITY               ,
  ERDV.ORG_EDO_ID                                                           As ORG_EDO_ID                      ,
  ERDV.ORG_TYPE_EDO                                                         As ORG_TYPE_EDO                    ,
  ERDV.ORG_EDO_IOBSP                                                        As ORG_EDO_IOBSP                   ,
  ERDV.ORG_FLAG_PLT_CONV                                                    As ORG_FLAG_PLT_CONV               ,
  ERDV.ORG_FLAG_TEAM_MKT                                                    As ORG_FLAG_TEAM_MKT               ,
  ERDV.ORG_FLAG_TYPE_CMP                                                    As ORG_FLAG_TYPE_CMP               ,
  Null                                                                      As ORG_RESP_EDO_ID                 ,
  Null                                                                      As ORG_RESP_TYPE_EDO               ,
  Null                                                                      As ORG_RESP_FLAG_PLT_CONV          ,
  Null                                                                      As ACTIVITY_CD                     ,
  Null                                                                      As ACTIVITY_GROUPNG_CD             ,
  Null                                                                      As AUTO_ACTIVITY_IN                ,
  CASE WHEN ERDV.ORG_EDO_ID IS NOT NULL THEN 'O3'
       ELSE ERDV.ORG_REF_TRAV
  END                                                                       As ORG_TYPE_CD                     ,
  Null                                                                      As ORG_TEAM_TYPE_ID                ,
  ERDV.ORG_TEAM_LEVEL_1_CD                                                  As ORG_TEAM_LEVEL_1_CD             ,
  ERDV.ORG_TEAM_LEVEL_1_DS                                                  As ORG_TEAM_LEVEL_1_DS             ,
  ERDV.ORG_TEAM_LEVEL_2_CD                                                  As ORG_TEAM_LEVEL_2_CD             ,
  ERDV.ORG_TEAM_LEVEL_2_DS                                                  As ORG_TEAM_LEVEL_2_DS             ,
  ERDV.ORG_TEAM_LEVEL_3_CD                                                  As ORG_TEAM_LEVEL_3_CD             ,
  ERDV.ORG_TEAM_LEVEL_3_DS                                                  As ORG_TEAM_LEVEL_3_DS             ,
  ERDV.ORG_TEAM_LEVEL_4_CD                                                  As ORG_TEAM_LEVEL_4_CD             ,
  ERDV.ORG_TEAM_LEVEL_4_DS                                                  As ORG_TEAM_LEVEL_4_DS             ,
  ERDV.WORK_TEAM_LEVEL_1_CD                                                 As WORK_TEAM_LEVEL_1_CD            ,
  ERDV.WORK_TEAM_LEVEL_1_DS                                                 As WORK_TEAM_LEVEL_1_DS            ,
  ERDV.WORK_TEAM_LEVEL_2_CD                                                 As WORK_TEAM_LEVEL_2_CD            ,
  ERDV.WORK_TEAM_LEVEL_2_DS                                                 As WORK_TEAM_LEVEL_2_DS            ,
  ERDV.WORK_TEAM_LEVEL_3_CD                                                 As WORK_TEAM_LEVEL_3_CD            ,
  ERDV.WORK_TEAM_LEVEL_3_DS                                                 As WORK_TEAM_LEVEL_3_DS            ,
  ERDV.WORK_TEAM_LEVEL_4_CD                                                 As WORK_TEAM_LEVEL_4_CD            ,
  ERDV.WORK_TEAM_LEVEL_4_DS                                                 As WORK_TEAM_LEVEL_4_DS            ,
  Null                                                                      As CONFIRMATION_IN                 ,
  Null                                                                     As MIGRA_DT                         ,
  Null                                                                     As MIGRA_NEXT_OFFRE                 ,
  Null                                                                     As LINE_ID                          ,
  Null                                                                     As MASTER_LINE_ID                   ,
  Null                                                                     As PAR_GEO_MACROZONE                ,
  Null                                                                     As PAR_UNIFIED_PARTY_ID             ,
  Null                                                                     As PAR_PARTY_REGRPMNT_ID            ,
  Null                                                                     as PAR_CID_ID                       ,
  Null                                                                     as PAR_PID_ID                       ,
  Null                                                                     as PAR_FIRST_IN                     ,
  Null                                                                     As CUST_TYPE_CD                     ,
  '0000000000'                                                             As MSISDN_ID                        ,
  ERDV.PAR_ND                                                              As NDS_VALUE_DS                     ,
  '0000000000'                                                             As EXTERNAL_PARTY_ID                ,
  Null                                                                     As RES_VALUE_DS                     ,
  Null                                                                     As PAR_ACCES_SERVICE                ,
  Null                                                                     As TAC_CD                           ,
  Null                                                                     As IMEI_CD                          ,
  Null                                                                     As IMSI_CD                          ,
  Null                                                                     As HOM_START_DT                     ,
  Null                                                                     As MOB_START_DT                     ,
  Null                                                                     As I_SCORE_VALUE                    ,
  Null                                                                     As I_SCORE_TRESHOLD                 ,
  Null                                                                     As I_SCORE_IN                       ,
  Null                                                                     As M_SCORE_VALUE                    ,
  Null                                                                     As M_SCORE_TRESHOLD                 ,
  Null                                                                     As M_SCORE_IN                       ,
  Null                                                                     As OSCAR_VALUE                      ,
  '${P_PIL_376}'                                                           As CUST_BU_TYPE_CD                  ,
  Null                                                                     As CUST_BU_CD                       ,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE                     ,
  Null                                                                     As ADDRESS_CONCAT_NM                ,
  Null                                                                     As POSTAL_CD                        ,
  Null                                                                     As INSEE_CD                         ,
  Null                                                                     As BU_CD                            ,
  Null                                                                     As DEPARTMNT_ID                     ,
  ERDV.ACT_DELTA_TARIF                                                     As ACT_CA_LINE_AM                   ,
  --Null                                                                     As EAN_CD                           ,
  Null                                                                     As SIM_CD                           ,
  Null                                                                     As SIM_EAN_CD                       ,
  ERDV.CHECK_INITIAL_STATUS_CD                                             As CHECK_INITIAL_STATUS_CD          ,
  ERDV.CHECK_NAT_STATUS_CD                                                 As CHECK_NAT_STATUS_CD              ,
  ERDV.CHECK_NAT_COMMENT                                                   As CHECK_NAT_COMMENT                ,
  ERDV.CHECK_NAT_STATUS_LN                                                 As CHECK_NAT_STATUS_LN              ,
  ERDV.CHECK_LOC_STATUS_CD                                                 As CHECK_LOC_STATUS_CD              ,
  ERDV.CHECK_LOC_COMMENT                                                   As CHECK_LOC_COMMENT                ,
  ERDV.CHECK_LOC_STATUS_LN                                                 As CHECK_LOC_STATUS_LN              ,
  ERDV.CHECK_VALIDT_DT                                                     As CHECK_VALIDT_DT                  ,
  Null                                                                     As ACT_END_UNIFIED_DT               ,
  Null                                                                     As ACT_END_UNIFIED_DS               ,
  ERDV.CLOSURE_DT                                                          As ACT_CLOSURE_DT                   ,
  Case When ERDV.CLOSURE_DT Is Not Null
       Then 'Acte Clos'
  End                                                                      As ACT_CLOSURE_DS                   ,
  ERDV.HOT_IN                                                              As HOT_IN                           ,
  ERDV.RUN_ID                                                              As RUN_ID                           ,
  Cast(SubString(Cast(QUEUE_TS as Char(22)) From 1 For 19) AS Timestamp(0))     As QUEUE_TS                    ,
  Cast(SubString(Cast(STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0)) As STREAMING_TS                ,
  ERDV.CREATION_TS                                                         As ACT_CREATION_TS                  ,
  Current_Timestamp(0)                                                     As EXT_CREATION_TS                  ,
  ERDV.CREATION_TS                                                         As CREATION_TS                      ,
  Null                                                                     As LAST_MODIF_TS                    ,
  1                                                                        As FRESH_IN                         ,
  0                                                                        As COHERENCE_IN 
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_ERDV ERDV 
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
      On  ERDV.ACT_PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                           = 1
      And EtatPeriode.FRESH_IN                             = 1
      And EtatPeriode.CLOSURE_DT                           Is Null
Where
  (1=1)
  And Substr(ACT_CD,1,3)          Not In (${L_PIL_036})
  And ERDV.ACT_SEG_COM_ID_FINAL    Not In ('ACCINTERF','ACCINTERS','ACCINTERC')
  And ERDV.ACT_SEG_COM_ID_FINAL  <> '${P_PIL_295}'
  And ERDV.ACT_CD                <> '${P_PIL_067}'
  And ERDV.HOT_IN                = 1
  And ERDV.CLOSURE_DT            Is Null
  -- la periode n est pas close
  And ERDV.ORDER_DEPOSIT_DT >= Current_date - 20
  And ( EtatPeriode.PERIODE_STATUS is Null Or EtatPeriode.PERIODE_STATUS = 'O' )
  And ERDV.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
; 
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_ERDV;
.if errorcode <> 0 then .quit 1;
