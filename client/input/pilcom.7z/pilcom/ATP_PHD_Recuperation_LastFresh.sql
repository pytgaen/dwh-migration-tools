-- $HEADER: %HEADER%
----------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_PHD_Recuperation_LastFresh.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de récuperation de la date de dernière extraction dans la FLW_H_EXTRACT
--
--------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE             AUTEUR      CREATION/MODIFICATION
-- 25/11/2019       EVI         Création
--------------------------------------------------------------------------------------------------------

.set width 2000

----------------------------------------------------------------------------------------------
-- Recuperation de la dernière fraicheur de la table Humain et Digital : ORD_F_ACTE_DIGITAL
----------------------------------------------------------------------------------------------
SELECT COALESCE( CAST( MAX(IND_HD_TEMPO_DT) AS TIMESTAMP(0) ) , CAST('2019-01-01 00:00:00' AS TIMESTAMP(0) ))
(TITLE'')
FROM ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL
;
.if errorcode <> 0 then .quit 1
