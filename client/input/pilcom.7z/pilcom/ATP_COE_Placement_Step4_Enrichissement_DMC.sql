--$HEADER:   mm2pco/current/sql/ATP_COE_Placement_Step4_Enrichissement_DMC.sql 13_05#1 25-OCT-2018 14:44:33 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_COE_Placement_Step4_Enrichissement_DMC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissement clients
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 10/10/2018      HOB         Creation
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Enrichissement client/dossier                                                ----
----------------------------------------------------------------------------------------------

--Purge de la table temporaire avant insertion

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_DMC All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
--Etape 2-1 : Alimentation de la table temporaire avec l'enrichissement MSISDN Mobile
----------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_DMC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  DMC_LINE_TYPE             ,
  DMC_START_DT              ,
  DMC_ACTIVATION_DT         ,
  DMC_CUST_TYPE_CD          ,
  DMC_NDS_VALUE_DS          ,
  DMC_EXTERNAL_PARTY_ID     ,
  DMC_RES_VALUE_DS          ,
  DMC_SERVICE_ACCESS_ID     ,
  DMC_DEPRTMNT_ID           ,
  DMC_POSTAL_CD             ,
  PAR_INSEE_NB              ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID     ,
  PAR_CID_ID                ,
  PAR_PID_ID                ,
  PAR_FIRST_IN              ,
  ADDRESS_CONCAT_NM         ,
  ADDRESS_TYPE              ,
  DMC_CUST_BU_CD            ,
  PAR_BU_CD                 ,
  DMC_CONVERGENT_IN         ,
  PAR_FIBER_IN              

)
Select
  Placement.ACTE_ID                                        as ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                               as ORDER_DEPOSIT_DT           ,
  Ldmc.LINE_ID                                             as DMC_LINE_ID                ,
  Ldmc.MASTER_LINE_ID                                      as DMC_MASTER_LINE_ID         ,
  Ldmc.LINE_TYPE_CD                                        as DMC_LINE_TYPE              ,
  Ldmc.LINE_START_DT                                       as DMC_START_DT               ,
  Ldmc.ACTIVATION_DT                                       as DMC_ACTIVATION_DT          ,
  Ldmc.TYPE_CD                                             as DMC_CUST_TYPE_CD           ,
  Ldmc.TERMINTN_VALUE_DS                                   as DMC_NDS_VALUE_DS           ,
  Ldmc.EXTERNAL_PARTY_ID                                   as DMC_EXTERNAL_PARTY_ID      ,
  Ldmc.RES_VALUE_DS                                        as DMC_RES_VALUE_DS           ,
  Ldmc.SERVICE_ACCESS_ID                                   as DMC_SERVICE_ACCESS_ID      ,
  Ldmc.DEPRTMNT_ID                                         as DMC_DEPRTMNT_ID            ,
  Ldmc.POSTAL_CD                                           as DMC_POSTAL_CD              ,
  Ldmc.INSEE_NB                                            as PAR_INSEE_NB               ,
  Ldmc.UNIFIED_PARTY_ID                                    as PAR_UNIFIED_PARTY_ID       ,
  Ldmc.PARTY_REGRPMNT_ID                                   as PAR_PARTY_REGRPMNT_ID      ,
  Ldmc.CID_ID                                              as PAR_CID_ID                 ,
  Ldmc.PID_ID                                              as PAR_PID_ID                 ,
  LFirst.FIRST_IN                                          as PAR_FIRST_IN               ,
  Trim(Coalesce(Adre.BILL_ADDRESS1_NM, Adre.MAIN_ADDRESS3_NM) ||  Ldmc.POSTAL_CD)         
                                                           as ADDRESS_CONCAT_NM          ,
  'FAC'                                                    as ADDRESS_TYPE               ,
  Adre.DR_USM_CD                                           as DMC_CUST_BU_CD             ,
  Geo.BU_CD                                                as PAR_BU_CD                  ,
  Ldmc.CONVERGENT_IN                                       as DMC_CONVERGENT_IN          ,
  Ldmc.FIBER_IN                                            as PAR_FIBER_IN                

From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_1 Placement
  Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_ACH  Ldmc
    On       Placement.EXTRNL_DOSSIER_NU          =  Ldmc.MOBILE_PHONE_NU
       And   Placement.ORDER_DEPOSIT_DT           >=  Ldmc.START_DT
       And   Placement.ORDER_DEPOSIT_DT           < Ldmc.END_DT
       And   Ldmc.LINE_TYPE_CD in ('M', 'P')  
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Adre
    On Ldmc.LINE_ID = Adre.LINE_ID   
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT Geo
    On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_FIRST_VM  LFirst
    On Ldmc.LINE_ID = LFirst.LINE_ID                 

Where
  (1=1)
  And Placement.DMC_LINE_ID is Null 
   Qualify  Row_Number() over (Partition by ACTE_ID order by coalesce(Ldmc.business_offer_end_dt,Ldmc.end_dt) desc, coalesce(Ldmc.business_offer_begin_dt,Ldmc.start_dt) desc, Ldmc.line_id desc  ) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_DMC ;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 2 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------

--Purge de la table temporaire avant insertion

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_IRIS All;
.if errorcode <> 0 then .quit 1

--Alimentation de la table temporaire avec l'enrichissement IRIS2000

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_IRIS
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  DMC_LINE_ID                   ,
  PAR_IRIS2000_CD               ,
  PAR_GEO_MACROZONE              
)
Select
  Placement.ACTE_ID                               as ACTE_ID                        ,
  Placement.ORDER_DEPOSIT_DT                      as ORDER_DEPOSIT_DT               ,
  Placement.DMC_LINE_ID                           as DMC_LINE_ID                    ,
  FIBER.IRIS2000_CD                               as PAR_IRIS2000_CD                ,
  FIBER.RESERV_4                                  as PAR_GEO_MACROZONE               
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_DMC  Placement
  Inner Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB FIBER
  on Placement.DMC_LINE_ID = FIBER.LINE_ID
  Where
  (1=1)
Qualify Row_Number() Over (Partition by Placement.ACTE_ID, Placement.ORDER_DEPOSIT_DT Order by FIBER.LAST_MODIF_TS Desc)=1

  ;

.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_IRIS;
.if errorcode <> 0 then .quit 1


.quit 0

