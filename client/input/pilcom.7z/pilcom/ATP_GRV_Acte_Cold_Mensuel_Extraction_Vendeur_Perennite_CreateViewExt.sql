-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GRV_Acte_Cold_Mensuel_Extraction_Vendeur_Perennite_CreateViewExt.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 29/10/2014      GMA         Modif
-- 27/11/2014      HFO         MODIFICATION (remplacé point par virgule)
-- 14/04/2016      HLA         MODIFICATION nouveaux calcul de pérennité
-- 15/06/2016      HLA         MODIFICATION Taux volume
--------------------------------------------------------------------------------

.set width 2500;

-- Etape 1:

Replace View ${KNB_PCO_VM}.V_EXT_F_SELLER_SUSTNBL_RATE_VM_M
  As  locking ${KNB_PCO_VM}.ORD_F_SELLER_SUSTNBL_RATE_VM_M for access
Select
  Trim(SubStr(MONTH_APPLICATION,1,6)(Varchar(20)))                                            As PERIODE_PVC                            ,
  Trim(Cast('${KNB_PILCOM_EXTRACT_PERIODE}' as Varchar(20)))                                  As PERIODE_DE_CALCUL                      ,
  Trim(Upper(ORG_AGENT_ID)(Varchar(20)))                                                      As CUID                                   ,
  trim( SUBSTRING(Trim(Cast(RATE_VALUATION_PER_EDITED as Decimal(6,2) Format '---9.99')) 
        FROM 1 FOR POSITION('.' IN Trim(Cast(RATE_VALUATION_PER_EDITED as Decimal(6,2) Format '---9.99')))-1)
      )||','||trim( SUBSTRING(Trim(Cast(RATE_VALUATION_PER_EDITED as Decimal(6,2) Format '---9.99')) 
                      FROM  POSITION('.' IN Trim(Cast(RATE_VALUATION_PER_EDITED as Decimal(6,2) Format '---9.99')))+1 FOR 2)
                  )                                                                           As TAUX_VALO                              ,
  trim( SUBSTRING(Trim(Cast(RATE_SALE_PER as Decimal(6,2) Format '---9.99'))  
            FROM 1 FOR POSITION('.' IN Trim(Cast(RATE_SALE_PER as Decimal(6,2) Format '---9.99')))-1)
      )||','||trim( SUBSTRING(Trim(Cast(RATE_SALE_PER as Decimal(6,2) Format '---9.99'))  
                      FROM  POSITION('.' IN Trim(Cast(RATE_SALE_PER as Decimal(6,2) Format '---9.99'))        )+1 FOR 2)
                  )                                                                           As TAUX_VOLUME                            ,
  trim( SUBSTRING(Trim(NUMBER_VALUATION) FROM 1 FOR POSITION('.' IN Trim(NUMBER_VALUATION))-1)
      )||','||trim( SUBSTRING(Trim(NUMBER_VALUATION)  FROM  POSITION('.' IN Trim(NUMBER_VALUATION) )+1 FOR 2)
                  )                                                                           As REALISE_VALO_BRUT                      ,
  trim( SUBSTRING(Trim(NUMBER_VALUATION_PER)  FROM 1 FOR POSITION('.' IN Trim(NUMBER_VALUATION_PER))-1)
      )||','||trim( SUBSTRING(Trim(NUMBER_VALUATION_PER) 
                      FROM  POSITION('.' IN Trim(NUMBER_VALUATION_PER) )+1 FOR 2)
                  )                                                                           As REALISE_VALO_PERENNE                   ,
  Trim(AMOUNT_SALE)                                                                           As REALISE_VOLUME_BRUT                    ,
  Trim(AMOUNT_SALE_PER)                                                                       As REALISE_VOLUME_PERENNE                 
From
  ${KNB_PCO_VM}.V_ORD_F_SELLER_SUSTNBL_RATE_VM_M
  
Where
  (1=1)
  And MONTH_CALC  = '${KNB_PILCOM_EXTRACT_MOIS}'
  And FRESH_IN = 1  
;
.if errorcode <> 0 then .quit 1

-- Etape 2:
Replace View ${KNB_PCO_VM_GLB_V}.EXT_F_SELLER_SUSTNBL_RATE_VM_M
  As  locking ${KNB_PCO_VM}.ORD_F_SELLER_SUSTNBL_RATE_VM_M for access
Select * from ${KNB_PCO_VM}.V_EXT_F_SELLER_SUSTNBL_RATE_VM_M

;
.if errorcode <> 0 then .quit 1
.quit 0


