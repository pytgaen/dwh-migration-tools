-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_PVC_Cold_Alim_Switch_Delete_On.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script pour réactiver l'envoi PVC en suppression
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 05/03/2015     YZH         Création
---------------------------------------------------------------------------------

.set width 2000;


Update ${KNB_PCO_TMP}.ACT_T_PVC_DAY  
From ${KNB_PCO_VM}.ACT_F_PVC_CUR ExtCur
Set
   FLAG_ETAT_GRV='SV', -- On les remet à "suppression vraies" de nouveau
   ACTION_ACTE=5       -- On les associe à une autre action d'acte
Where (1=1)
And ExtCur.ACTE_ID=ACT_T_PVC_DAY.ACTE_ID
And ExtCur.ACTION_ACTE=9 -- Supppressions à réactiver        
;
  
.if errorcode <> 0 Then .quit 1



-- Collecter les stats    
Collect Stat On ${KNB_PCO_TMP}.ACT_T_PVC_DAY;

.if errorcode <> 0 Then .quit 1

.quit 0
