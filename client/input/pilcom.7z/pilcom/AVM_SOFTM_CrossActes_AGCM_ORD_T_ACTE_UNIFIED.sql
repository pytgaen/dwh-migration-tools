-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_SOFTM_CrossActes_AGCM_ORD_T_ACTE_UNIFIED.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de croisement de la source SOFTM et AGCM
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2014     YZH         Création
-- 09/04/2019     SII         Modification les rapprochements historiques
-- 20/06/2019     JCR         Correction du rule_id de 24 vers 25
-- 06/04/2020     EVI         PILCOM-398 : eSim - Ajout Regle 55 Rapprochement SOFTM/AGCM
-- 01/07/2020     JCR         Ajout colonne SIM_EAN_CD et SIM_CD
-- 11/12/2020     EVI         PILCOM-759 : Optimisation rapprochement SOFTM/AGCM
-- 31/03/2021     EVI         PILCOM-869 : eSim - Rapprochement sur 30 au lieu de 15 jours
-- 28/06/2021     EVI         PILCOM-945 : Suppression Champs Obsolète VU 
---------------------------------------------------------------------------------

.set width 5000

--------------------------------                                        
-- Table : ORD_T_ACTE_UNIFIED --
--------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-----------------------------------------------------------------------                                        
-- Identification Croisement : Règle 25  
-----------------------------------------------------------------------                                        

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
(
  MASTER_ACTE_ID                  ,
  SLAVE_ACTE_ID                   ,
  MASTER_SOURCE_ID                ,
  SLAVE_SOURCE_ID                 ,
  MASTER_NB_FOUND                 ,
  SIM_CD                          ,
  SIM_EAN_CD                      ,
  RULE_ID                         ,
  OFFSET_SEC                      ,
  OFFSET 
)
Select 
  RES.MASTER_ACTE_ID                  ,
  RES.SLAVE_ACTE_ID                   ,
  RES.MASTER_SOURCE_ID                ,
  RES.SLAVE_SOURCE_ID                 ,
  RES.MASTER_NB_FOUND                 ,
  RES.SIM_CD                          ,
  RES.SIM_EAN_CD                      ,
  RES.RULE_ID                         ,
  RES.OFFSET_SEC                      ,
  RES.OFFSET    
From 
(
  Select
    MASTER.ACTE_ID                                                                            As MASTER_ACTE_ID,
    SLAVE.ACTE_ID                                                                             As SLAVE_ACTE_ID,
    MASTER.INTRNL_SOURCE_ID                                                                   As MASTER_SOURCE_ID,
    SLAVE.INTRNL_SOURCE_ID                                                                    As SLAVE_SOURCE_ID,
    Count(*) Over (Partition By SLAVE.ACTE_ID)                                                As MASTER_NB_FOUND,
    SLAVE.SIM_CD                                                                              As SIM_CD,
    SLAVE.SIM_EAN_CD                                                                          As SIM_EAN_CD,
    25                                                                                        As RULE_ID,
    Abs((MASTER.ACT_TS - SLAVE.ACT_TS) Day(4) To Second)                                      As DIFF_TS, 
    (Extract(Day From DIFF_TS) * 86400) + (Extract(Hour From DIFF_TS) * 3600) + 
    (Extract(Minute From DIFF_TS) * 60) + Extract(Second From DIFF_TS)                        As OFFSET_SEC,
    MASTER.ACT_DT - SLAVE.ACT_DT                                                              As OFFSET 
  From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} ${SourceTmp}
  Inner join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ${SourceSoc}
    On  ${SourceTmp}.ACT_SEG_COM_ID_FINAL = ${SourceSoc}.ACT_SEG_COM_ID_FINAL
    And ${SourceSoc}.ACT_DT               = ${SourceTmp}.ACT_DT
    And (
         ${SourceSoc}.IMSI_CD = ${SourceTmp}.IMSI_CD
        Or 
         ${SourceSoc}.MSISDN_ID = ${SourceTmp}.MSISDN_ID
        )
    And Not (${SourceSoc}.IMSI_CD is Null And ${SourceSoc}.MSISDN_ID = '0000000000' )                        
  Where (1=1)
  And ${SourceTmp}.INTRNL_SOURCE_ID = '${SourceAlimId}' 
  And ${SourceTmp}.TYPE_SOURCE_ID In ( '${SourceAlimTyp}' )
  And ${SourceTmp}.ACT_CLOSURE_DT Is Null 
  And ${SourceTmp}.ACT_END_UNIFIED_DT Is Null 
  And ${SourceSoc}.INTRNL_SOURCE_ID = '${SourceEnrId}' 
  And ${SourceSoc}.TYPE_SOURCE_ID In ( '${SourceEnrTyp}' )
  And ${SourceSoc}.ACT_CLOSURE_DT Is Null 
  And ${SourceSoc}.ACT_END_UNIFIED_DT Is Null 
  Qualify Row_Number() Over(Partition By SLAVE.ACTE_ID Order By OFFSET_SEC Asc) = 1
)RES;
.if errorcode <> 0 then .quit 1;

-----------------------------------------------------------------------                                        
-- Identification Rapprochement eSim : Règle 55 (Activation Montre Connectée)
-----------------------------------------------------------------------          

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
(
  MASTER_ACTE_ID                  ,
  SLAVE_ACTE_ID                   ,
  MASTER_SOURCE_ID                ,
  SLAVE_SOURCE_ID                 ,
  MASTER_NB_FOUND                 ,
  SIM_CD                          ,
  SIM_EAN_CD                      ,
  RULE_ID                         ,
  -- Axe Conseiller
  AGENT_ID                        ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  ORG_AGENT_IOBSP                 ,
  -- Axe Canal
  ORG_CHANNEL_CD                  ,
  ORG_REM_CHANNEL_CD              ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_GT_ACTIVITY                 , 
  ORG_WEB_ACTIVITY                , 
  ORG_AUTO_ACTIVITY               , 
  -- Axe Organisation
  ORG_EDO_ID                      ,      
  ORG_EDO_IOBSP                   ,     
  ORG_TEAM_LEVEL_1_CD             ,     
  ORG_TEAM_LEVEL_1_DS             ,     
  ORG_TEAM_LEVEL_2_CD             ,     
  ORG_TEAM_LEVEL_2_DS             ,     
  ORG_TEAM_LEVEL_3_CD             ,     
  ORG_TEAM_LEVEL_3_DS             ,     
  ORG_TEAM_LEVEL_4_CD             ,     
  ORG_TEAM_LEVEL_4_DS             ,     
  ORG_TEAM_TYPE_ID                ,     
  ORG_TYPE_CD                     ,     
  ORG_TYPE_EDO                    ,     
  WORK_TEAM_LEVEL_1_CD            ,     
  WORK_TEAM_LEVEL_1_DS            ,     
  WORK_TEAM_LEVEL_2_CD            ,     
  WORK_TEAM_LEVEL_2_DS            ,     
  WORK_TEAM_LEVEL_3_CD            ,     
  WORK_TEAM_LEVEL_3_DS            ,     
  WORK_TEAM_LEVEL_4_CD            ,     
  WORK_TEAM_LEVEL_4_DS            ,     
  OFFSET_SEC                      ,
  OFFSET 
)
Select 
  RES.MASTER_ACTE_ID                  ,
  RES.SLAVE_ACTE_ID                   ,
  RES.MASTER_SOURCE_ID                ,
  RES.SLAVE_SOURCE_ID                 ,
  RES.MASTER_NB_FOUND                 ,
  RES.SIM_CD                          ,
  RES.SIM_EAN_CD                      ,
  RES.RULE_ID                         ,
  -- Axe Conseiller
  RES.AGENT_ID                        ,
  RES.AGENT_ID_UPD                    ,
  RES.AGENT_ID_UPD_DT                 ,
  RES.AGENT_FIRST_NAME                ,
  RES.AGENT_LAST_NAME                 ,
  RES.ORG_AGENT_IOBSP                 ,
  -- Axe Canal
  RES.ORG_CHANNEL_CD                  ,
  RES.ORG_REM_CHANNEL_CD              ,
  RES.ORG_SUB_CHANNEL_CD              ,
  RES.ORG_SUB_SUB_CHANNEL_CD          ,
  RES.ORG_GT_ACTIVITY                 ,
  RES.ORG_WEB_ACTIVITY                ,
  RES.ORG_AUTO_ACTIVITY               ,
  -- Axe Organisation
  RES.ORG_EDO_ID                      ,
  RES.ORG_EDO_IOBSP                   ,
  RES.ORG_TEAM_LEVEL_1_CD             ,
  RES.ORG_TEAM_LEVEL_1_DS             ,
  RES.ORG_TEAM_LEVEL_2_CD             ,
  RES.ORG_TEAM_LEVEL_2_DS             ,
  RES.ORG_TEAM_LEVEL_3_CD             ,
  RES.ORG_TEAM_LEVEL_3_DS             ,
  RES.ORG_TEAM_LEVEL_4_CD             ,
  RES.ORG_TEAM_LEVEL_4_DS             ,
  RES.ORG_TEAM_TYPE_ID                ,
  RES.ORG_TYPE_CD                     ,
  RES.ORG_TYPE_EDO                    ,
  RES.WORK_TEAM_LEVEL_1_CD            ,
  RES.WORK_TEAM_LEVEL_1_DS            ,
  RES.WORK_TEAM_LEVEL_2_CD            ,
  RES.WORK_TEAM_LEVEL_2_DS            ,
  RES.WORK_TEAM_LEVEL_3_CD            ,
  RES.WORK_TEAM_LEVEL_3_DS            ,
  RES.WORK_TEAM_LEVEL_4_CD            ,
  RES.WORK_TEAM_LEVEL_4_DS            ,
  RES.OFFSET_SEC                      ,
  RES.OFFSET    
From 
(
  Select
    MASTER.ACTE_ID                                                                            As MASTER_ACTE_ID        ,
    SLAVE.ACTE_ID                                                                             As SLAVE_ACTE_ID         ,
    MASTER.INTRNL_SOURCE_ID                                                                   As MASTER_SOURCE_ID      ,
    SLAVE.INTRNL_SOURCE_ID                                                                    As SLAVE_SOURCE_ID       ,
    Count(*) Over (Partition By SLAVE.ACTE_ID)                                                As MASTER_NB_FOUND       ,
    SLAVE.SIM_CD                                                                              As SIM_CD                ,
    SLAVE.SIM_EAN_CD                                                                          As SIM_EAN_CD            ,
    55                                                                                        As RULE_ID               ,
    --Axe Conseiller
    SLAVE.AGENT_ID                                                                            As AGENT_ID              ,
    CASE 
      WHEN MASTER.AGENT_ID_UPD_DT Is Not NULL
        THEN CASE 
              WHEN MASTER.AGENT_ID = SLAVE.AGENT_ID 
                THEN MASTER.AGENT_ID_UPD 
              ELSE   SLAVE.AGENT_ID_UPD 
             END
      ELSE SLAVE.AGENT_ID_UPD
    END                                                                                       As AGENT_ID_UPD          ,
    CASE
      WHEN MASTER.AGENT_ID_UPD_DT Is Not NULL
        THEN CASE 
              WHEN MASTER.AGENT_ID = SLAVE.AGENT_ID 
                THEN MASTER.AGENT_ID_UPD_DT 
              ELSE   Null 
             END
    END                                                                                       As AGENT_ID_UPD_DT       ,
    SLAVE.AGENT_FIRST_NAME                                                                    As AGENT_FIRST_NAME      ,
    SLAVE.AGENT_LAST_NAME                                                                     As AGENT_LAST_NAME       ,
    SLAVE.ORG_AGENT_IOBSP                                                                     As ORG_AGENT_IOBSP       ,
    --Axe Canal
    SLAVE.ORG_CHANNEL_CD                                                                      As ORG_CHANNEL_CD        ,
    SLAVE.ORG_REM_CHANNEL_CD                                                                  As ORG_REM_CHANNEL_CD    ,
    SLAVE.ORG_SUB_CHANNEL_CD                                                                  As ORG_SUB_CHANNEL_CD    ,
    SLAVE.ORG_SUB_SUB_CHANNEL_CD                                                              As ORG_SUB_SUB_CHANNEL_CD,
    SLAVE.ORG_GT_ACTIVITY                                                                     As ORG_GT_ACTIVITY       ,
    SLAVE.ORG_WEB_ACTIVITY                                                                    As ORG_WEB_ACTIVITY      ,
    SLAVE.ORG_AUTO_ACTIVITY                                                                   As ORG_AUTO_ACTIVITY     ,
    --Axe Organisation
    SLAVE.ORG_EDO_ID                                                                          As ORG_EDO_ID            ,
    SLAVE.ORG_EDO_IOBSP                                                                       As ORG_EDO_IOBSP         ,
    SLAVE.ORG_TEAM_LEVEL_1_CD                                                                 As ORG_TEAM_LEVEL_1_CD   ,
    SLAVE.ORG_TEAM_LEVEL_1_DS                                                                 As ORG_TEAM_LEVEL_1_DS   ,
    SLAVE.ORG_TEAM_LEVEL_2_CD                                                                 As ORG_TEAM_LEVEL_2_CD   ,
    SLAVE.ORG_TEAM_LEVEL_2_DS                                                                 As ORG_TEAM_LEVEL_2_DS   ,
    SLAVE.ORG_TEAM_LEVEL_3_CD                                                                 As ORG_TEAM_LEVEL_3_CD   ,
    SLAVE.ORG_TEAM_LEVEL_3_DS                                                                 As ORG_TEAM_LEVEL_3_DS   ,
    SLAVE.ORG_TEAM_LEVEL_4_CD                                                                 As ORG_TEAM_LEVEL_4_CD   ,
    SLAVE.ORG_TEAM_LEVEL_4_DS                                                                 As ORG_TEAM_LEVEL_4_DS   ,
    SLAVE.ORG_TEAM_TYPE_ID                                                                    As ORG_TEAM_TYPE_ID      ,
    SLAVE.ORG_TYPE_CD                                                                         As ORG_TYPE_CD           ,
    SLAVE.ORG_TYPE_EDO                                                                        As ORG_TYPE_EDO          ,
    SLAVE.WORK_TEAM_LEVEL_1_CD                                                                As WORK_TEAM_LEVEL_1_CD  ,
    SLAVE.WORK_TEAM_LEVEL_1_DS                                                                As WORK_TEAM_LEVEL_1_DS  ,
    SLAVE.WORK_TEAM_LEVEL_2_CD                                                                As WORK_TEAM_LEVEL_2_CD  ,
    SLAVE.WORK_TEAM_LEVEL_2_DS                                                                As WORK_TEAM_LEVEL_2_DS  ,
    SLAVE.WORK_TEAM_LEVEL_3_CD                                                                As WORK_TEAM_LEVEL_3_CD  ,
    SLAVE.WORK_TEAM_LEVEL_3_DS                                                                As WORK_TEAM_LEVEL_3_DS  ,
    SLAVE.WORK_TEAM_LEVEL_4_CD                                                                As WORK_TEAM_LEVEL_4_CD  ,
    SLAVE.WORK_TEAM_LEVEL_4_DS                                                                As WORK_TEAM_LEVEL_4_DS  ,
    Abs((MASTER.ACT_TS - SLAVE.ACT_TS) Day(4) To Second)                                      As DIFF_TS               , 
    (Extract(Day From DIFF_TS) * 86400) + (Extract(Hour From DIFF_TS) * 3600) + 
    (Extract(Minute From DIFF_TS) * 60) + Extract(Second From DIFF_TS)                        As OFFSET_SEC            ,
    MASTER.ACT_DT - SLAVE.ACT_DT                                                              As OFFSET 
  From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} ${SourceTmp}
  Inner join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ${SourceSoc}
    On  ${SourceTmp}.LINE_ID          = ${SourceSoc}.LINE_ID
    And (
           (    MASTER.ACT_DT      <  Cast('01/04/2021' As Date Format 'DD/MM/YYYY') 
            And SLAVE.ACT_DT      Between MASTER.ACT_DT - 15 And MASTER.ACT_DT)
             Or 
            (   MASTER.ACT_DT      >= Cast('01/04/2021' As Date Format 'DD/MM/YYYY') 
            And SLAVE.ACT_DT      Between MASTER.ACT_DT - 30 And MASTER.ACT_DT)
        )
  Where 
    (1=1)
    And ${SourceTmp}.INTRNL_SOURCE_ID     = '${SourceAlimId}' 
    And ${SourceTmp}.TYPE_SOURCE_ID       In ( '${SourceAlimTyp}' )
    And ${SourceTmp}.ACT_CLOSURE_DT       Is Null 
    And ${SourceTmp}.ACT_END_UNIFIED_DT   Is Null 
    And ${SourceSoc}.INTRNL_SOURCE_ID     = '${SourceEnrId}' 
    And ${SourceSoc}.TYPE_SOURCE_ID       In ( '${SourceEnrTyp}' )
    And ${SourceSoc}.ACT_CLOSURE_DT       Is Null 
    And ${SourceSoc}.ACT_END_UNIFIED_DT   Is Null 
    And MASTER.ACT_CD                     = 'ACQ/OPT_MULTISIM_AI_ESIM'
    And SLAVE.ACT_CD                      = 'INIT/OPT_MULTISIM_AI_ESIMM'
    And SLAVE.AGENT_ID                    Is Not Null
  Qualify Row_Number() Over(Partition By SLAVE.ACTE_ID Order By OFFSET_SEC Asc) = 1
)RES;
.if errorcode <> 0 then .quit 1;


Collect Stats On ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-- Alimentation des maîtres ou esclaves dans le TMP 
-- Récupération de données esclaves/master depuis la VU et les insérer dans la table temporaire pour les recalculer  
Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} 
(
  ACTE_ID
, OPERATOR_PROVIDER_ID
, INTRNL_SOURCE_ID
, TYPE_SOURCE_ID
, MASTER_ACTE_ID
, MASTER_INTRNL_SOURCE_ID
, MASTER_FLAG
, MASTER_NB_FOUND
, CPLT_ACTE_ID
, CPLT_INTRNL_SOURCE_ID
, CPLT_IN
, RULE_ID
, OFFSET_NB
, ACT_TYPE
, ORDER_EXTERNAL_ID
, STATUS_CD
, ACT_UNIFIED_STATUS_CD
, ACT_TS
, ACT_DT
, ACT_HH
, ACT_LAST_UPD_TS
, ACT_PRODUCT_ID_PRE
, ACT_SEG_COM_ID_PRE
, ACT_SEG_COM_AGG_ID_PRE
, ACT_CODE_MIGR_PRE
, ACT_OPER_ID_PRE
, ACT_PRODUCT_ID_FINAL
, ACT_SEG_COM_ID_FINAL
, ACT_SEG_COM_AGG_ID_FINAL
, ACT_CODE_MIGR_FINAL
, ACT_OPER_ID_FINAL
, ACT_TYPE_SERVICE_FINAL
, ACT_TYPE_COMMANDE_ID
, ACT_DELTA_TARIF
, ACT_CD
, ACT_REM_ID
, ACT_FLAG_ACT_REM
, ACT_FLAG_PEC_PERPVC
, ACT_FLAG_PVC_REM
, ACT_ACTE_VALO
, ACT_ACTE_FAMILLE_KPI
, ACT_PERIODE_ID
, ACT_PERIODE_STATUS
, ACT_PERIODE_CLOSURE_DT
, ORIGIN_CD
, AGENT_ID
, AGENT_ID_UPD
, AGENT_ID_UPD_DT
, ORG_AGENT_IOBSP
, AGENT_FIRST_NAME
, AGENT_LAST_NAME
, UNIFIED_SHOP_CD
, ORG_SPE_CANAL_ID_MACRO
, ORG_SPE_CANAL_ID
, ORG_REM_CHANNEL_CD
, ORG_CHANNEL_CD
, ORG_SUB_CHANNEL_CD
, ORG_SUB_SUB_CHANNEL_CD
, ORG_GT_ACTIVITY
, ORG_FIDELISATION
, ORG_WEB_ACTIVITY
, ORG_AUTO_ACTIVITY
, ORG_EDO_ID
, ORG_TYPE_EDO
, ORG_EDO_IOBSP
, ORG_FLAG_PLT_CONV
, ORG_FLAG_TEAM_MKT
, ORG_FLAG_TYPE_CMP
, ORG_RESP_EDO_ID
, ORG_RESP_TYPE_EDO
, ORG_RESP_FLAG_PLT_CONV
, ACTIVITY_CD
, ACTIVITY_GROUPNG_CD
, AUTO_ACTIVITY_IN
, ORG_TYPE_CD
, ORG_TEAM_TYPE_ID
, ORG_TEAM_LEVEL_1_CD
, ORG_TEAM_LEVEL_1_DS
, ORG_TEAM_LEVEL_2_CD
, ORG_TEAM_LEVEL_2_DS
, ORG_TEAM_LEVEL_3_CD
, ORG_TEAM_LEVEL_3_DS
, ORG_TEAM_LEVEL_4_CD
, ORG_TEAM_LEVEL_4_DS
, WORK_TEAM_LEVEL_1_CD
, WORK_TEAM_LEVEL_1_DS
, WORK_TEAM_LEVEL_2_CD
, WORK_TEAM_LEVEL_2_DS
, WORK_TEAM_LEVEL_3_CD
, WORK_TEAM_LEVEL_3_DS
, WORK_TEAM_LEVEL_4_CD
, WORK_TEAM_LEVEL_4_DS
, CONFIRMATION_IN
, CONCLDD_IN
, COMPTTN_IN
, COMPTTN_ID
, PERNNT_IN
, PERNNT_END_DT
, PERNNT_MOTIF
, PERNNT_CALC_END_DT
, MIGRA_DT
, MIGRA_NEXT_OFFRE
, PRES_SEGMENT_IN_PARK_BEFORE_IN
, SEGMENT_DELIVERY_IN_PARK_DT
, ORDER_CANCELING_DT
, LINE_ID
, MASTER_LINE_ID
, CUST_TYPE_CD
, MSISDN_ID
, NDS_VALUE_DS
, EXTERNAL_PARTY_ID
, RES_VALUE_DS
, PAR_ACCES_SERVICE
, TAC_CD
, IMEI_CD
, IMSI_CD
, HOM_START_DT
, MOB_START_DT
, I_SCORE_VALUE
, I_SCORE_TRESHOLD
, I_SCORE_IN
, M_SCORE_VALUE
, M_SCORE_TRESHOLD
, M_SCORE_IN
, OSCAR_VALUE
, CUST_BU_TYPE_CD
, CUST_BU_CD
, ADDRESS_TYPE
, ADDRESS_CONCAT_NM
, POSTAL_CD
, INSEE_CD
, BU_CD
, DEPARTMNT_ID
, PAR_GEO_MACROZONE
, PAR_UNIFIED_PARTY_ID
, PAR_PARTY_REGRPMNT_ID
, PAR_CID_ID
, PAR_PID_ID
, PAR_FIRST_IN
, PAR_IRIS2000_CD
, COMMARTICLE_RP_REFPRIX_CD
, ACT_CA_LINE_AM
, ACT_CA_TTC_AM
, EAN_CD
, SIM_CD
, SIM_EAN_CD
, ORG_RESP_ID
, EAN_PREVIOUS_CD
, TAC_PREVIOUS_CD
, IMEI_PREVIOUS_CD
, PCM_PREVIOUS_OFFRE_CD
, PCM_COMMTMNT_PERIOD_NU
, PCM_LEVEL_POINT_NU
, PCM_OFFRE_CD
, PCM_EFFCTV_NEXT_OFFRE_DT
, PCM_TYPE_OFFRE_MOBILE_CD
, PCM_POINT_UTIL_NU
, PCM_BALANCE_POINT_NU
, PCM_STATUT_POINT_CD
, PCM_POINT_DUE_NU
, PAR_ELIGIBLE_FIBER_IN
, CHECK_INITIAL_STATUS_CD
, CHECK_NAT_STATUS_CD
, CHECK_NAT_COMMENT
, CHECK_NAT_STATUS_LN
, CHECK_LOC_STATUS_CD
, CHECK_LOC_COMMENT
, CHECK_LOC_STATUS_LN
, CHECK_VALIDT_DT
, ACT_END_UNIFIED_DT
, ACT_END_UNIFIED_DS
, ACT_CLOSURE_DT
, ACT_CLOSURE_DS
, HOT_IN
, RUN_ID
, CREATION_TS
, LAST_MODIF_TS
, FRESH_IN
, COHERENCE_IN)
Select
  SOC.ACTE_ID
, SOC.OPERATOR_PROVIDER_ID
, SOC.INTRNL_SOURCE_ID
, SOC.TYPE_SOURCE_ID
, SOC.MASTER_ACTE_ID
, SOC.MASTER_INTRNL_SOURCE_ID
, SOC.MASTER_FLAG
, SOC.MASTER_NB_FOUND
, SOC.CPLT_ACTE_ID
, SOC.CPLT_INTRNL_SOURCE_ID
, SOC.CPLT_IN
, SOC.RULE_ID
, SOC.OFFSET_NB
, SOC.ACT_TYPE
, SOC.ORDER_EXTERNAL_ID
, SOC.STATUS_CD
, SOC.ACT_UNIFIED_STATUS_CD
, SOC.ACT_TS
, SOC.ACT_DT
, SOC.ACT_HH
, SOC.ACT_LAST_UPD_TS
, SOC.ACT_PRODUCT_ID_PRE
, SOC.ACT_SEG_COM_ID_PRE
, SOC.ACT_SEG_COM_AGG_ID_PRE
, SOC.ACT_CODE_MIGR_PRE
, SOC.ACT_OPER_ID_PRE
, SOC.ACT_PRODUCT_ID_FINAL
, SOC.ACT_SEG_COM_ID_FINAL
, SOC.ACT_SEG_COM_AGG_ID_FINAL
, SOC.ACT_CODE_MIGR_FINAL
, SOC.ACT_OPER_ID_FINAL
, SOC.ACT_TYPE_SERVICE_FINAL
, SOC.ACT_TYPE_COMMANDE_ID
, SOC.ACT_DELTA_TARIF
, SOC.ACT_CD
, SOC.ACT_REM_ID
, SOC.ACT_FLAG_ACT_REM
, SOC.ACT_FLAG_PEC_PERPVC
, SOC.ACT_FLAG_PVC_REM
, SOC.ACT_ACTE_VALO
, SOC.ACT_ACTE_FAMILLE_KPI
, SOC.ACT_PERIODE_ID
, SOC.ACT_PERIODE_STATUS
, SOC.ACT_PERIODE_CLOSURE_DT
, SOC.ORIGIN_CD
, SOC.AGENT_ID
, SOC.AGENT_ID_UPD
, SOC.AGENT_ID_UPD_DT
, SOC.ORG_AGENT_IOBSP
, SOC.AGENT_FIRST_NAME
, SOC.AGENT_LAST_NAME
, SOC.UNIFIED_SHOP_CD
, SOC.ORG_SPE_CANAL_ID_MACRO
, SOC.ORG_SPE_CANAL_ID
, SOC.ORG_REM_CHANNEL_CD
, SOC.ORG_CHANNEL_CD
, SOC.ORG_SUB_CHANNEL_CD
, SOC.ORG_SUB_SUB_CHANNEL_CD
, SOC.ORG_GT_ACTIVITY
, SOC.ORG_FIDELISATION
, SOC.ORG_WEB_ACTIVITY
, SOC.ORG_AUTO_ACTIVITY
, SOC.ORG_EDO_ID
, SOC.ORG_TYPE_EDO
, SOC.ORG_EDO_IOBSP
, SOC.ORG_FLAG_PLT_CONV
, SOC.ORG_FLAG_TEAM_MKT
, SOC.ORG_FLAG_TYPE_CMP
, SOC.ORG_RESP_EDO_ID
, SOC.ORG_RESP_TYPE_EDO
, SOC.ORG_RESP_FLAG_PLT_CONV
, SOC.ACTIVITY_CD
, SOC.ACTIVITY_GROUPNG_CD
, SOC.AUTO_ACTIVITY_IN
, SOC.ORG_TYPE_CD
, SOC.ORG_TEAM_TYPE_ID
, SOC.ORG_TEAM_LEVEL_1_CD
, SOC.ORG_TEAM_LEVEL_1_DS
, SOC.ORG_TEAM_LEVEL_2_CD
, SOC.ORG_TEAM_LEVEL_2_DS
, SOC.ORG_TEAM_LEVEL_3_CD
, SOC.ORG_TEAM_LEVEL_3_DS
, SOC.ORG_TEAM_LEVEL_4_CD
, SOC.ORG_TEAM_LEVEL_4_DS
, SOC.WORK_TEAM_LEVEL_1_CD
, SOC.WORK_TEAM_LEVEL_1_DS
, SOC.WORK_TEAM_LEVEL_2_CD
, SOC.WORK_TEAM_LEVEL_2_DS
, SOC.WORK_TEAM_LEVEL_3_CD
, SOC.WORK_TEAM_LEVEL_3_DS
, SOC.WORK_TEAM_LEVEL_4_CD
, SOC.WORK_TEAM_LEVEL_4_DS
, SOC.CONFIRMATION_IN
, SOC.CONCLDD_IN
, SOC.COMPTTN_IN
, SOC.COMPTTN_ID
, SOC.PERNNT_IN
, SOC.PERNNT_END_DT
, SOC.PERNNT_MOTIF
, SOC.PERNNT_CALC_END_DT
, SOC.MIGRA_DT
, SOC.MIGRA_NEXT_OFFRE
, SOC.PRES_SEGMENT_IN_PARK_BEFORE_IN
, SOC.SEGMENT_DELIVERY_IN_PARK_DT
, SOC.ORDER_CANCELING_DT
, SOC.LINE_ID
, SOC.MASTER_LINE_ID
, SOC.CUST_TYPE_CD
, SOC.MSISDN_ID
, SOC.NDS_VALUE_DS
, SOC.EXTERNAL_PARTY_ID
, SOC.RES_VALUE_DS
, SOC.PAR_ACCES_SERVICE
, SOC.TAC_CD
, SOC.IMEI_CD
, SOC.IMSI_CD
, SOC.HOM_START_DT
, SOC.MOB_START_DT
, SOC.I_SCORE_VALUE
, SOC.I_SCORE_TRESHOLD
, SOC.I_SCORE_IN
, SOC.M_SCORE_VALUE
, SOC.M_SCORE_TRESHOLD
, SOC.M_SCORE_IN
, SOC.OSCAR_VALUE
, SOC.CUST_BU_TYPE_CD
, SOC.CUST_BU_CD
, SOC.ADDRESS_TYPE
, SOC.ADDRESS_CONCAT_NM
, SOC.POSTAL_CD
, SOC.INSEE_CD
, SOC.BU_CD
, SOC.DEPARTMNT_ID
, SOC.PAR_GEO_MACROZONE
, SOC.PAR_UNIFIED_PARTY_ID
, SOC.PAR_PARTY_REGRPMNT_ID
, SOC.PAR_CID_ID
, SOC.PAR_PID_ID
, SOC.PAR_FIRST_IN
, SOC.PAR_IRIS2000_CD
, SOC.COMMARTICLE_RP_REFPRIX_CD
, SOC.ACT_CA_LINE_AM
, SOC.ACT_CA_TTC_AM
, SOC.EAN_CD
, SOC.SIM_CD
, SOC.SIM_EAN_CD
, SOC.ORG_RESP_ID
, SOC.EAN_PREVIOUS_CD
, SOC.TAC_PREVIOUS_CD
, SOC.IMEI_PREVIOUS_CD
, SOC.PCM_PREVIOUS_OFFRE_CD
, SOC.PCM_COMMTMNT_PERIOD_NU
, SOC.PCM_LEVEL_POINT_NU
, SOC.PCM_OFFRE_CD
, SOC.PCM_EFFCTV_NEXT_OFFRE_DT
, SOC.PCM_TYPE_OFFRE_MOBILE_CD
, SOC.PCM_POINT_UTIL_NU
, SOC.PCM_BALANCE_POINT_NU
, SOC.PCM_STATUT_POINT_CD
, SOC.PCM_POINT_DUE_NU
, SOC.PAR_ELIGIBLE_FIBER_IN
, SOC.CHECK_INITIAL_STATUS_CD
, SOC.CHECK_NAT_STATUS_CD
, SOC.CHECK_NAT_COMMENT
, SOC.CHECK_NAT_STATUS_LN
, SOC.CHECK_LOC_STATUS_CD
, SOC.CHECK_LOC_COMMENT
, SOC.CHECK_LOC_STATUS_LN
, SOC.CHECK_VALIDT_DT
, SOC.ACT_END_UNIFIED_DT
, SOC.ACT_END_UNIFIED_DS
, SOC.ACT_CLOSURE_DT
, SOC.ACT_CLOSURE_DS
, SOC.HOT_IN
, SOC.RUN_ID
, SOC.CREATION_TS
, SOC.LAST_MODIF_TS
, SOC.FRESH_IN
, SOC.COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED SOC 
Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} SRC
On  SOC.ACTE_ID = SRC.${SourceSoc}_ACTE_ID 
And SOC.INTRNL_SOURCE_ID = '${SourceEnrId}' 
And SOC.TYPE_SOURCE_ID In ( '${SourceEnrTyp}' )
Qualify Row_Number() Over (Partition by SOC.ACTE_ID Order by SOC.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1;

-- Enrichissement Esclave depuis maître

Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
     ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} SRC
Set
  MASTER_ACTE_ID = SRC.MASTER_ACTE_ID,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID,
  MASTER_FLAG = ${P_PIL_355},
  MASTER_NB_FOUND = SRC.MASTER_NB_FOUND,
  OFFSET_NB = SRC.OFFSET,
  CPLT_ACTE_ID = Null,
  CPLT_INTRNL_SOURCE_ID = Null,
  CPLT_IN = '${P_PIL_388}'   
Where (1=1)
And CIB.ACTE_ID = SRC.SLAVE_ACTE_ID
And SRC.RULE_ID = 25;
.if errorcode <> 0 then .quit 1;

-- On met a jour les maitres : attention il n'y a pas besoin de filtre sur l'omnicanal car l'update ne les impacte pas.
-- Mais il faut garder à l'esprit qu'on ne doit pas ecraser les champs 'omnicanal'
Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET) = 1
) SRC
Set
  MASTER_ACTE_ID = SRC.MASTER_ACTE_ID,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID,
  MASTER_FLAG = ${P_PIL_354},
  OFFSET_NB = SRC.OFFSET,
  CPLT_ACTE_ID = SRC.SLAVE_ACTE_ID,
  CPLT_INTRNL_SOURCE_ID = SRC.SLAVE_SOURCE_ID,
  CPLT_IN = '${P_PIL_356}', 
  SIM_CD = SRC.SIM_CD,
  SIM_EAN_CD = SRC.SIM_EAN_CD, 
  RULE_ID = SRC.RULE_ID
Where 
  (1=1)
  And CIB.ACTE_ID = SRC.MASTER_ACTE_ID
  And SRC.RULE_ID = 25;
.if errorcode <> 0 then .quit 1;


-- Mise à jour des Actes Maitre SOFT Rapprochement eSim. 
-- Il n'y a pas de notion Maitre/Esclave sur eSim, car les deux Actes restent Maitres.
Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET) = 1
) SRC
Set
  OFFSET_NB               = SRC.OFFSET                ,
  CPLT_ACTE_ID            = SRC.SLAVE_ACTE_ID         ,
  CPLT_INTRNL_SOURCE_ID   = SRC.SLAVE_SOURCE_ID       ,
  CPLT_IN                 = '${P_PIL_356}'            , 
  RULE_ID                 = SRC.RULE_ID               ,
  -- Axe Conseiller
  AGENT_ID                = SRC.AGENT_ID              ,     
  AGENT_ID_UPD            = SRC.AGENT_ID_UPD          ,     
  AGENT_ID_UPD_DT         = SRC.AGENT_ID_UPD_DT       ,     
  AGENT_FIRST_NAME        = SRC.AGENT_FIRST_NAME      ,     
  AGENT_LAST_NAME         = SRC.AGENT_LAST_NAME       ,     
  ORG_AGENT_IOBSP         = SRC.ORG_AGENT_IOBSP       ,     
  -- Axe Canal
  ORG_CHANNEL_CD          = SRC.ORG_CHANNEL_CD        ,     
  ORG_REM_CHANNEL_CD      = SRC.ORG_REM_CHANNEL_CD    ,     
  ORG_SUB_CHANNEL_CD      = SRC.ORG_SUB_CHANNEL_CD    ,     
  ORG_SUB_SUB_CHANNEL_CD  = SRC.ORG_SUB_SUB_CHANNEL_CD,     
  ORG_GT_ACTIVITY         = SRC.ORG_GT_ACTIVITY       ,     
  ORG_WEB_ACTIVITY        = SRC.ORG_WEB_ACTIVITY      ,     
  ORG_AUTO_ACTIVITY       = SRC.ORG_AUTO_ACTIVITY     ,     
  -- Axe Organisation
  ORG_EDO_ID              = SRC.ORG_EDO_ID            ,     
  ORG_EDO_IOBSP           = SRC.ORG_EDO_IOBSP         ,     
  ORG_TEAM_LEVEL_1_CD     = SRC.ORG_TEAM_LEVEL_1_CD   ,     
  ORG_TEAM_LEVEL_1_DS     = SRC.ORG_TEAM_LEVEL_1_DS   ,     
  ORG_TEAM_LEVEL_2_CD     = SRC.ORG_TEAM_LEVEL_2_CD   ,     
  ORG_TEAM_LEVEL_2_DS     = SRC.ORG_TEAM_LEVEL_2_DS   ,     
  ORG_TEAM_LEVEL_3_CD     = SRC.ORG_TEAM_LEVEL_3_CD   ,     
  ORG_TEAM_LEVEL_3_DS     = SRC.ORG_TEAM_LEVEL_3_DS   ,     
  ORG_TEAM_LEVEL_4_CD     = SRC.ORG_TEAM_LEVEL_4_CD   ,     
  ORG_TEAM_LEVEL_4_DS     = SRC.ORG_TEAM_LEVEL_4_DS   ,     
  ORG_TEAM_TYPE_ID        = SRC.ORG_TEAM_TYPE_ID      ,     
  ORG_TYPE_CD             = SRC.ORG_TYPE_CD           ,     
  ORG_TYPE_EDO            = SRC.ORG_TYPE_EDO          ,     
  WORK_TEAM_LEVEL_1_CD    = SRC.WORK_TEAM_LEVEL_1_CD  ,     
  WORK_TEAM_LEVEL_1_DS    = SRC.WORK_TEAM_LEVEL_1_DS  ,     
  WORK_TEAM_LEVEL_2_CD    = SRC.WORK_TEAM_LEVEL_2_CD  ,     
  WORK_TEAM_LEVEL_2_DS    = SRC.WORK_TEAM_LEVEL_2_DS  ,     
  WORK_TEAM_LEVEL_3_CD    = SRC.WORK_TEAM_LEVEL_3_CD  ,     
  WORK_TEAM_LEVEL_3_DS    = SRC.WORK_TEAM_LEVEL_3_DS  ,     
  WORK_TEAM_LEVEL_4_CD    = SRC.WORK_TEAM_LEVEL_4_CD  ,     
  WORK_TEAM_LEVEL_4_DS    = SRC.WORK_TEAM_LEVEL_4_DS  ,
  SIM_CD                  = SRC.SIM_CD                ,
  SIM_EAN_CD              = SRC.SIM_EAN_CD 
  
Where 
  (1=1)
  And CIB.ACTE_ID = SRC.MASTER_ACTE_ID
  And SRC.RULE_ID = 55;
.if errorcode <> 0 then .quit 1;

.quit 0

