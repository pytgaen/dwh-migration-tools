-- $HEADER: mm2pco/current/sql/ATP_AGC_Placement_Hot_Alimentation_ORD_W_PLACEMENT_AGC_MOB.sql 13_05#2 13-MAI-2019 10:12:40 LXQG9925
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_Placement_Hot_Alimentation_ORD_W_PLACEMENT_AGC_MOB.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table W placement pour AGC MOB
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/03/2014      YZH         Creation
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H
(
    ACTE_ID                               ,
    INTRNL_SOURCE_ID                      ,
    TYPE_SOURCE_ID                        ,
    EXTERNAL_ACTE_ID                      ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    ORDER_TYPE_CD                         ,
    PRODUCT_TYPE                          ,
    EXTERNAL_PRODUCT_ID                   ,
    MOUVEMENT                             ,
    MOBILE_MSISDN_ID                      ,
    MSISDN_PORTED                         ,
    IMEI_CD                               ,
    SIM_CD                                ,
    SIM_EAN_CD                            ,
    INVOICE_ADDRESS_MAIL_NM
)
Select 
      ActeId.ACTE_ID                                                                                         AS ACTE_ID             ,
      Placement.INTRNL_SOURCE_ID                                                                             AS INTRNL_SOURCE_ID    ,
      Placement.TYPE_SOURCE_ID                                                                               AS TYPE_SOURCE_ID      ,
      Placement.EXTERNAL_ACTE_ID                                                                             AS EXTERNAL_ACTE_ID    ,
      Placement.CONTEXT_ID                                                                                   AS CONTEXT_ID          ,
      Placement.EXTERNAL_ORDER_ID                                                                            AS EXTERNAL_ORDER_ID   ,
      Placement.ORDER_DEPOSIT_TS                                                                             AS ORDER_DEPOSIT_TS    ,
      Placement.ORDER_DEPOSIT_DT                                                                             AS ORDER_DEPOSIT_DT    ,
      Placement.ORDER_TYPE_CD                                                                                AS ORDER_TYPE_CD       ,
      Placement.PRODUCT_TYPE                                                                                 AS PRODUCT_TYPE        ,
      Placement.EXTERNAL_PRODUCT_ID                                                                          AS EXTERNAL_PRODUCT_ID ,
      Placement.MOUVEMENT                                                                                    AS MOUVEMENT           ,
      Placement.MOBILE_MSISDN_ID                                                                             AS MOBILE_MSISDN_ID    ,
      Placement.MSISDN_PORTED                                                                                AS MSISDN_PORTED       ,
      Placement.IMEI_CD                                                                                      AS IMEI_CD             ,
      Placement.SIM_CD                                                                                       AS SIM_CD              ,
      Placement.SIM_EAN_CD                                                                                   AS SIM_EAN_CD          ,
      Placement.INVOICE_ADDRESS_MAIL_NM                                                                      AS INVOICE_ADDRESS_MAIL_NM
From  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H_EXT      Placement
Inner Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN                ActeId
  On  Placement.EXTERNAL_ACTE_ID    =     ActeId.EXTERNAL_ACTE_ID
  And Placement.TYPE_SOURCE_ID      =     ActeId.TYPE_SOURCE_ID
;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H;
.if errorcode <> 0 then .quit 1

.quit 0
