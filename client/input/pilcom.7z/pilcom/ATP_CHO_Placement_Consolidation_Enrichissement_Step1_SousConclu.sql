-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_Enrichissement_Step1_SousConclu.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_SSCONCLU all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_SSCONCLU
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  OPERATOR_PROVIDER_ID    ,
  PRODUCT_ID              ,
  SSCONCLU_ID             
)
Select
  RefId.ACTE_ID                               as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                        as INT_DEPOSIT_DT         ,
  RefId.OPERATOR_PROVIDER_ID                  as OPERATOR_PROVIDER_ID   ,
  RefId.PRODUCT_ID                            as PRODUCT_ID             ,
  Case  --Si le produit est retrouvé dans le Catalogue des produits Chorus :
        When  ProduitCho.PRODREF_PRODUCT_ID  is not Null
          Then  --On test si c'est un PCM :
                Case  When RefId.SOLDOFF_SRC_CD  = 'PCM'
                        Then  Coalesce(ProduitCho.PRODREF_PROD_CATEGORY,'1INC['||RefId.OPERATOR_PROVIDER_ID||','||RefId.PRODUCT_ID||']')
                      --Dans les autres Cas que le PCM 
                      Else    Coalesce(ProduitCho.PRODREF_KL_PRD_EXT_ID,'2INC['||RefId.OPERATOR_PROVIDER_ID||','||RefId.PRODUCT_ID||']')
                End
        --Si le Produit n'est pas dans le catalogue Chorus :
        When RefId.SOLDOFF_SRC_CD is not Null
          Then  Coalesce(RefId.OTO_OFFER_CD,RefId.OTO_OFFER_TYPE_CD,'###')
        Else Null
  End                                         as SSCONCLU_ID            
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_1 RefId
  Left Outer Join ${KNB_IBU_SOC}.V_TDPRODREF ProduitCho
    On    RefId.OPERATOR_PROVIDER_ID  = ProduitCho.PRODREF_SETID
      And RefId.PRODUCT_ID            = ProduitCho.PRODREF_PRODUCT_ID
      And ProduitCho.CURRENT_IN       = 1
      And ProduitCho.CLOSURE_DT       Is Null
Where
  (1=1)
  And RefId.SSCONCLU_ID Is Null
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_SSCONCLU;
.if errorcode <> 0 then .quit 1

