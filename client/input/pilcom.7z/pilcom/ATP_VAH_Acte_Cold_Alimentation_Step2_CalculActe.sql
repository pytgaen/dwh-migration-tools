--$HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_VAH_Acte_Cold_Alimentation_Step2_CalculActe.sql   $
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  de calcul acte VAD_HOME à froid
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 07/12/2015      HFO         CREATION
-- 29/04/2015      MDE         Modif / Correction RG sous sous canal  
-- 07/12/2016      HOB         Modif VA
-- 27/11/2017      MEL         Ajout indicateur IOBSP
-- 30/07/2019      SSI         Modification Evolution de l’alimentation de l’acte_val
-- 27/09/2019      GRH         Ajout & Alimentation des champs ACT_UNITE_CD / FLAG_HD/ ACT_DELTA_TARIF/ ACT_ACTE_VALO
-- 09/10/2019      GRH         Modification de la jointure Calipso 
-- 15/04/2020      EVI         PILCOM-414 : KPI200 Lot2 - Alimentation ACT_DELTA_TARIF
-- 09/11/2021      TCL         Suppression jointure activity (pris désormais dans la matrice VAH) + suppression orga
--------------------------------------------------------------------------------


.set width 2000;


Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_VAH all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_VAH
(
 ACTE_ID                            ,
 ACTE_ID_GEN                        ,
 ORDER_DEPOSIT_DT                   ,
 ORDER_DEPOSIT_TS                   ,
 EAN_CD                             ,
 ORDER_EXTERNAL_ID                  ,
 ORDER_LAST_STATUS                  ,
 ORDER_CANCELING_DT                 ,
 ORDER_LAST_STATUS_TS               ,
 INTRNL_SOURCE_ID                   ,
 ACT_PRODUCT_ID_PRE                 ,
 ACT_SEG_COM_ID_PRE                 ,
 ACT_CODE_MIGR_PRE                  ,
 ACT_SEG_COM_AGG_ID_PRE             ,
 ACT_PRODUCT_ID_FINAL               ,
 ACT_SEG_COM_ID_FINAL               ,
 ACT_SEG_COM_AGG_ID_FINAL           ,
 ACT_CODE_MIGR_FINAL                ,
 ACT_TYPE_SERVICE_FINAL             ,
 ACT_TYPE_COMMANDE_ID               ,
 ACT_DELTA_TARIF                    ,
-- Ajout de ACT_UNITE_CD             
 ACT_UNITE_CD                       ,
 ACT_CD                             ,
 ACT_REM_ID                         ,
 ACT_FLAG_ACT_REM                   ,
 ACT_FLAG_PEC_PERPVC                ,
 ACT_ACTE_VALO                      ,
 ACT_ACTE_FAMILLE_KPI               ,
 ACT_PERIODE_ID                     ,
 ACT_PERIODE_STATUS                 ,
 ACT_PERIODE_CLOSURE_DT             ,
 ORG_EDO_ID                         ,
 ORG_TYPE_EDO                       ,
 FLAG_PLT_CONV                      ,
 FLAG_PLT_SCH                       ,
 FLAG_PLT_AD                        ,
 FLAG_PLT_PRO                       ,
 FLAG_TEAM_MKT                      ,
 FLAG_TYPE_CMP                      ,
 NETWRK_TYP_EDO_ID                  ,
 FLAG_TYPE_GEO                      ,
 FLAG_TYPE_CPT_NTK                  ,
 FLAG_TYPE_PTN_NTK                  ,
 --Ajout FLAG_HD                     
 FLAG_HD                            ,
 ORG_CHANNEL_CD                     ,
 ORG_SUB_CHANNEL_CD                 ,
 ORG_SUB_SUB_CHANNEL_CD             ,
 ORG_REM_CHANNEL_CD                 ,
 ORG_GT_ACTIVITY                    ,
 ORG_FIDELISATION                   ,
 ORG_WEB_ACTIVITY                   ,
 ORG_AUTO_ACTIVITY                  ,
 ORG_REF_TRAV                       ,
 ORG_AGENT_ID                       ,
 ORG_AGENT_ID_UPD                   ,
 ORG_AGENT_ID_UPD_DT                ,
 ORG_NOM                            ,
 ORG_PRENOM                         ,
 ORG_GROUPE_ID                      ,
 ORG_ACTVT_REEL                     ,
 ORG_RESP_REF_TRAV                  ,
 ORG_RESP_AGENT_ID                  ,
 ORG_RESP_XI                        ,
 ORG_TYPE_CD                        ,
 ORG_TEAM_LEVEL_1_CD                ,
 ORG_TEAM_LEVEL_1_DS                ,
 ORG_TEAM_LEVEL_2_CD                ,
 ORG_TEAM_LEVEL_2_DS                ,
 ORG_TEAM_LEVEL_3_CD                ,
 ORG_TEAM_LEVEL_3_DS                ,
 ORG_TEAM_LEVEL_4_CD                ,
 ORG_TEAM_LEVEL_4_DS                ,
 WORK_TEAM_LEVEL_1_CD               ,
 WORK_TEAM_LEVEL_1_DS               ,
 WORK_TEAM_LEVEL_2_CD               ,
 WORK_TEAM_LEVEL_2_DS               ,
 WORK_TEAM_LEVEL_3_CD               ,
 WORK_TEAM_LEVEL_3_DS               ,
 WORK_TEAM_LEVEL_4_CD               ,
 WORK_TEAM_LEVEL_4_DS               ,
 CHECK_INITIAL_STATUS_CD            ,
 CHECK_NAT_STATUS_CD                ,
 CHECK_NAT_COMMENT                  ,
 CHECK_NAT_STATUS_LN                ,
 CHECK_LOC_STATUS_CD                ,
 CHECK_LOC_COMMENT                  ,
 CHECK_LOC_STATUS_LN                ,
 CHECK_VALIDT_DT                    ,
 CLIENT_NU                          ,
 CLIENT_NU_NEW_PORTE                ,
 DOSSIER_NU                         ,
 DOSSIER_NU_NEW_PORTE               ,
 DOSSIER_DATE_ACTIV_DT              ,
 DOSSIER_DATE_RESIL_DT              ,
 DOSSIER_TYPE_RESIL                 ,
 DOSSIER_MOTIF_RESIL                ,
 DOSSIER_NU_IMSI                    ,
 DMC_LINE_ID                        ,
 DMC_MASTER_LINE_ID                 ,
 PAR_DEPRTMNT_ID                    ,
 PAR_CD_POSTAL                      ,
 PAR_INSEE_NB                       ,
 PAR_BU_CD                          ,
 PAR_GEO_MACROZONE                  ,
 PAR_UNIFIED_PARTY_ID               ,
 PAR_PARTY_REGRPMNT_ID              ,
 PAR_CID_ID                         ,
 PAR_PID_ID                         ,
 PAR_FIRST_IN                       ,
 ORG_AGENT_IOBSP                    ,
 ORG_EDO_IOBSP                      ,
 PAR_IRIS2000_CD                    ,
 PAR_FIBER_IN                       ,
 DMC_LINE_TYPE                      ,
 DMC_ACTIVATION_DT                  ,
 DMC_CONVERGENT_IN                  ,
 PAR_AID                            ,
 PAR_ND                             ,
 PAR_LASTNAME                       ,
 PAR_FIRSTNAME                      ,
 PAR_TYPE                           ,
 PAR_EMAIL                          ,
 PAR_INSEE_CD                       ,
 PAR_BILL_ADRESS_1                  ,
 PAR_BILL_ADRESS_2                  ,
 PAR_BILL_ADRESS_3                  ,
 PAR_BILL_ADRESS_4                  ,
 PAR_BILL_VILLE                     ,
 PAR_BILL_CD_POSTAL                 ,
 PAR_DO                             ,
 PAR_SCORE_NU_MOB                   ,
 PAR_SCORE_IN_MOB                   ,
 PAR_TRESHOLD_NU_MOB                ,
 PAR_SCORE_NU_INT                   ,
 PAR_SCORE_IN_INT                   ,
 PAR_TRESHOLD_NU_INT                ,
 PAR_MOB_TAC                        ,
 PAR_MOB_SIM                        ,
 PAR_MOB_IMEI                       ,
 CONTRCT_DT_SIGN_PREC               ,
 CONTRCT_DT_FIN_PREC                ,
 CONTRCT_DT_SIGN_POST               ,
 CONTRCT_DUREE_ENG                  ,
 CONTRCT_UNIT_ENG                   ,
 PAR_USCM                           ,
 PAR_USCM_DS                        ,
 PAR_USCM_USCM_DS                   ,
 PAR_USCM_REGUSCM                   ,
 PAR_USCM_REGUSCM_DS                ,
 PERNNT_IN                          ,
 PERNNT_END_DT                      ,
 PERNNT_MOTIF                       ,
 PERNNT_CALC_END_DT                 ,
 CONCURENCE_IN                      ,
 CONCURENCE_CONCLU_IN               ,
 CONCURENCE_ID                      ,
 DELIVERY_ONTIME_IN                 ,
 DELIVERY_DEAD_LINE_NU              ,
 ID_QUANTITE                        ,
 CLOSURE_DT                         ,
 CREATION_TS                        ,
 LAST_MODIF_TS                      ,
 HOT_IN                             ,
 FRESH_IN                           ,
 COHERENCE_IN                        
)

Select
  Placement.ACTE_ID                                                                     as ACTE_ID                            ,
  Placement.ACTE_ID                                                                     as ACTE_ID_GEN                        ,
  Placement.ORDER_DEPOSIT_DT                                                            as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                                            as ORDER_DEPOSIT_TS                   ,
  Placement.EAN_CD                                                                      as EAN_CD                             ,
  Placement.ORDR_ID                                                                     as ORDER_EXTERNAL_ID                  ,
  Placement.ORDER_LAST_STATUS                                                           as ORDER_LAST_STATUS                  ,
  Placement.ORDER_CANCELING_DT                                                          as ORDER_CANCELING_DT                 ,
  Placement.ORDER_LAST_STATUS_TS                                                        as ORDER_LAST_STATUS_TS               ,
  Placement.INTRNL_SOURCE_ID                                                            as INTRNL_SOURCE_ID                   ,
  Acte.PRODUCT_ID_PRE                                                                   as ACT_PRODUCT_ID_PRE                 ,
  Acte.SEG_COM_ID_PRE                                                                   as ACT_SEG_COM_ID_PRE                 ,
  Acte.CODE_MIGR_PRE                                                                    as ACT_CODE_MIGR_PRE                  ,
  Acte.SEG_COM_AGG_ID_PRE                                                               as ACT_SEG_COM_AGG_ID_PRE             ,
  Acte.PRODUCT_ID_FINAL                                                                 as ACT_PRODUCT_ID_FINAL               ,
  Acte.SEG_COM_ID_FINAL                                                                 as ACT_SEG_COM_ID_FINAL               ,
  Acte.SEG_COM_AGG_ID_FINAL                                                             as ACT_SEG_COM_AGG_ID_FINAL           ,
  Acte.CODE_MIGR_FINAL                                                                  as ACT_CODE_MIGR_FINAL                ,
  Acte.TYPE_SERVICE_FINAL                                                               as ACT_TYPE_SERVICE_FINAL             ,
  
  Coalesce(Mat.TYPE_COMMANDE_ID, '${P_PIL_026}')                                        as ACT_TYPE_COMMANDE_ID               ,
  Case    
    --Unité = NB                                
          When Mat.UNITE_CD ='${P_PIL_620}' Then        
             Case 
               When Mat.ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
                 then Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0) 
               Else NULL
             End
    --Unité= CA                                     
          When Mat.UNITE_CD ='${P_PIL_490}'         
          then Placement.UNIT_PRIC_HT_AM            
     --Unité = MKT                                  
          When Mat.UNITE_CD ='${P_PIL_623}'         
          then Mat.CA_MARKETING                     
    -- Unite = CA_CALIPSO (TMX)
          When Mat.UNITE_CD ='${P_PIL_622}'
          Then  Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)
     Else Null
  End                                                                                   as ACT_DELTA_TARIF                   ,
  Mat.UNITE_CD                                                                          as ACT_UNITE_CD                      ,
  Case
        When  Mat.ACTE_ID Is Not Null
          Then  Mat.ACTE_ID
        --Cas de rejet sur les pÃ©riodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  Acte.PERIODE_ID         = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit PlacÃ© est un produit inconnu de RefCom
        When  Acte.PRODUCT_ID_FINAL   = '${P_PIL_021}'
          Then '${P_PIL_224}'
        When Acte.SEG_COM_ID_FINAL    in ('NS')
          Then  '${P_PIL_221}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        --Sinon c'est un problÃ¨me dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                                                   as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID,'${P_PIL_067}')                                              as ACT_REM_ID                         ,
  Coalesce(Mat.FLAG_ACT_REM,'N')                                                        as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC,'N')                                                     as ACT_FLAG_PEC_PERPVC                ,
  
       --Unité = NB 
  Case When Mat.UNITE_CD ='${P_PIL_620}'                           
       Then Mat.ACTE_VALO                                          
   --Unité= CA                                                     
       When Mat.UNITE_CD ='${P_PIL_490}'                           
       Then ( Placement.UNIT_PRIC_HT_AM * Mat.TAUX_MARGE)          
   --Unité = MKT                                                   
      When Mat.UNITE_CD in ('${P_PIL_623}')                        
      Then ( Mat.CA_MARKETING * Mat.TAUX_MARGE )                   
    --Unité  CA_Calipso (TMX)                                      
       When Mat.UNITE_CD in ('${P_PIL_622}')                       
       Then ( Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0) * Mat.TAUX_MARGE )                                  
   Else Null                                                                                                                   
  End                                                                                   as ACT_ACTE_VALO                      ,
  
  Coalesce(Mat.ACTE_FAMILLE_KPI,'NON PARAM')                                            as ACT_ACTE_FAMILLE_KPI               ,
  Acte.PERIODE_ID                                                                       as ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                                             as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                                                        as ACT_PERIODE_CLOSURE_DT             ,
  RefOrga.ORG_EDO_ID                                                                    as ORG_EDO_ID                         ,
  RefOrga.ORG_TYPE_EDO                                                                  as ORG_TYPE_EDO                       ,
  Placement.FLAG_PLT_CONV                                                               as FLAG_PLT_CONV                      ,
  Placement.FLAG_PLT_SCH                                                                as FLAG_PLT_SCH                       ,
  Placement.FLAG_PLT_AD                                                                 as FLAG_PLT_AD                        ,
  Placement.FLAG_PLT_PRO                                                                as FLAG_PLT_PRO                       ,
  Placement.FLAG_TEAM_MKT                                                               as FLAG_TEAM_MKT                      ,
  Placement.FLAG_TYPE_CMP                                                               as FLAG_TYPE_CMP                      ,
  Placement.NETWRK_TYP_EDO_ID                                                           as NETWRK_TYP_EDO_ID                  ,
  Placement.FLAG_TYPE_GEO                                                               as FLAG_TYPE_GEO                      ,
  Placement.FLAG_TYPE_CPT_NTK                                                           as FLAG_TYPE_CPT_NTK                  ,
  Placement.FLAG_TYPE_PTN_NTK                                                           as FLAG_TYPE_PTN_NTK                  ,
  Mat.HUMAINDIGITAL                                                                     as FLAG_HD                            ,
 --Calcul du canal de vente Macro
  Coalesce(RefOrga.ORG_CHANEL_CD,'NONPARAM')                                            as ORG_CHANNEL_CD                     ,
  --Sous Canal

  Coalesce(RefOrga.ORG_SUB_CHANEL_CD,'NONPARAM')                                        as ORG_SUB_CHANNEL_CD                 ,
  --Sous-Sous-Canal
  Coalesce(RefOrga.ORG_SUB_SUB_CHANEL_CD,'NONPARAM')                                   as ORG_SUB_SUB_CHANNEL_CD             ,
  --Canal de Rem
  Coalesce(RefOrga.ORG_REM_CHANEL_CD,'NONPARAM')                                        as ORG_REM_CHANNEL_CD                 ,
  --ActivitÃ©
  Coalesce(RefOrga.ORG_GT_ACTIVITY,'NONPARAM')                                        as ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  null                                                                                  as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
  RefOrga.ORG_WEB_ACTIVITY                                                              as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique
  RefOrga.ORG_AUTO_ACTIVITY                                                             as ORG_AUTO_ACTIVITY                  ,

  Null                                                                                  as ORG_REF_TRAV                       ,
  Placement.AGENT_ID                                                                    as ORG_AGENT_ID                       ,
  Placement.AGENT_ID                                                                    as ORG_AGENT_ID_UPD                   ,
  Null                                                                                  as ORG_AGENT_ID_UPD_DT                ,
  Null                                                                                  as ORG_NOM                            ,
  Null                                                                                  as ORG_PRENOM                         ,
  Null                                                                                  as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitÃ©e
  Null                                                                                  as ORG_ACTVT_REEL                     ,
  Null                                                                                  as ORG_RESP_REF_TRAV                  ,
  Null                                                                                  as ORG_RESP_AGENT_ID                  ,
  Null                                                                                  as ORG_RESP_XI                        ,
  -- Calcul des EDO
  Null                                                                                  as ORG_TYPE_CD                        ,
  Trim(HierO3.ORG_TEAM_LEVEL_1_CD)                                                      as ORG_TEAM_LEVEL_1_CD                ,
  HierO3.ORG_TEAM_LEVEL_1_DS                                                            as ORG_TEAM_LEVEL_1_DS                ,
  Trim(HierO3.ORG_TEAM_LEVEL_2_CD)                                                      as ORG_TEAM_LEVEL_2_CD                ,
  HierO3.ORG_TEAM_LEVEL_2_DS                                                            as ORG_TEAM_LEVEL_2_DS                ,
  Trim(HierO3.ORG_TEAM_LEVEL_3_CD)                                                      as ORG_TEAM_LEVEL_3_CD                ,
  HierO3.ORG_TEAM_LEVEL_3_DS                                                            as ORG_TEAM_LEVEL_3_DS                ,
  Trim(HierO3.ORG_TEAM_LEVEL_4_CD)                                                      as ORG_TEAM_LEVEL_4_CD                ,
  HierO3.ORG_TEAM_LEVEL_4_DS                                                            as ORG_TEAM_LEVEL_4_DS                ,
  Trim(HierO3.WORK_TEAM_LEVEL_1_CD)                                                     as WORK_TEAM_LEVEL_1_CD               ,
  HierO3.WORK_TEAM_LEVEL_1_DS                                                           as WORK_TEAM_LEVEL_1_DS               ,
  Trim(HierO3.WORK_TEAM_LEVEL_2_CD)                                                     as WORK_TEAM_LEVEL_2_CD               ,
  HierO3.WORK_TEAM_LEVEL_2_DS                                                           as WORK_TEAM_LEVEL_2_DS               ,
  Trim(HierO3.WORK_TEAM_LEVEL_3_CD)                                                     as WORK_TEAM_LEVEL_3_CD               ,
  HierO3.WORK_TEAM_LEVEL_3_DS                                                           as WORK_TEAM_LEVEL_3_DS               ,
  Trim(HierO3.WORK_TEAM_LEVEL_4_CD )                                                    as WORK_TEAM_LEVEL_4_CD               ,
  HierO3.WORK_TEAM_LEVEL_4_DS                                                           as WORK_TEAM_LEVEL_4_DS               ,
  Null                                                                                  as CHECK_INITIAL_STATUS_CD            ,
  RetournCSO.CHECK_NAT_STATUS_CD                                                        as CHECK_NAT_STATUS_CD                ,
  RetournCSO.CHECK_NAT_COMMENT                                                          as CHECK_NAT_COMMENT                  ,
  RetournCSO.CHECK_NAT_STATUS_LN                                                        as CHECK_NAT_STATUS_LN                ,
  RetournCSO.CHECK_LOC_STATUS_CD                                                        as CHECK_LOC_STATUS_CD                ,
  RetournCSO.CHECK_LOC_COMMENT                                                          as CHECK_LOC_COMMENT                  ,
  RetournCSO.CHECK_LOC_STATUS_LN                                                        as CHECK_LOC_STATUS_LN                ,
  RetournCSO.CHECK_VALIDT_DT                                                            as CHECK_VALIDT_DT                    ,
  Placement.CLIENT_NU                                                                   as CLIENT_NU                          ,
  Placement.CLIENT_NU_NEW_PORTE                                                         as CLIENT_NU_NEW_PORTE                ,
  Placement.DOSSIER_NU                                                                  as DOSSIER_NU                         ,
  Placement.DOSSIER_NU_NEW_PORTE                                                        as DOSSIER_NU_NEW_PORTE               ,
  Placement.DOSSIER_ACTIV_DT                                                            as DOSSIER_DATE_ACTIV_DT              ,
  Placement.DOSSIER_RESIL_DT                                                            as DOSSIER_DATE_RESIL_DT              ,
  Placement.DOSSIER_TYPE_RESIL                                                          as DOSSIER_TYPE_RESIL                 ,
  Placement.DOSSIER_MOTIF_RESIL                                                         as DOSSIER_MOTIF_RESIL                ,
  Placement.DOSSIER_NU_IMSI                                                             as DOSSIER_NU_IMSI                    ,
  Placement.DMC_LINE_ID                                                                 as DMC_LINE_ID                        ,
  Placement.DMC_MASTER_LINE_ID                                                          as DMC_MASTER_LINE_ID                 ,
  Placement.PAR_DEPRTMNT_ID                                                             as PAR_DEPRTMNT_ID                    ,
  Placement.PAR_CD_POSTAL                                                               as PAR_CD_POSTAL                      ,
  Placement.PAR_INSEE_NB                                                                as PAR_INSEE_NB                       ,
  Placement.PAR_BU_CD                                                                   as PAR_BU_CD                          ,
  Placement.PAR_GEO_MACROZONE                                                           as PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                                                        as PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                                                       as PAR_PARTY_REGRPMNT_ID              ,
  Placement.PAR_CID_ID                                                                  as PAR_CID_ID                         ,
  Placement.PAR_PID_ID                                                                  as PAR_PID_ID                         ,
  Placement.PAR_FIRST_IN                                                                as PAR_FIRST_IN                       ,
  Placement.ORG_AGENT_IOBSP                                                             as ORG_AGENT_IOBSP                    ,
  Placement.ORG_EDO_IOBSP                                                               as ORG_EDO_IOBSP                      ,
  Placement.PAR_IRIS2000_CD                                                             as PAR_IRIS2000_CD                    ,
  Placement.PAR_FIBER_IN                                                                as PAR_FIBER_IN                       ,
  Placement.DMC_LINE_TYPE                                                               as DMC_LINE_TYPE                      ,
  Placement.DMC_ACTIVATION_DT                                                           as DMC_ACTIVATION_DT                  ,
  Placement.DMC_CONVERGENT_IN                                                           as DMC_CONVERGENT_IN                  ,
  Placement.PAR_AID                                                                     as PAR_AID                            ,
  Placement.PAR_ND                                                                      as PAR_ND                             ,
  Placement.PAR_LASTNAME                                                                as PAR_LASTNAME                       ,
  Placement.PAR_FIRSTNAME                                                               as PAR_FIRSTNAME                      ,
  Placement.PAR_TYPE                                                                    as PAR_TYPE                           ,
  Placement.PAR_EMAIL                                                                   as PAR_EMAIL                          ,
  Placement.PAR_INSEE_CD                                                                as PAR_INSEE_CD                       ,
  Placement.PAR_BILL_ADRESS_1                                                           as PAR_BILL_ADRESS_1                  ,
  Placement.PAR_BILL_ADRESS_2                                                           as PAR_BILL_ADRESS_2                  ,
  Placement.PAR_BILL_ADRESS_3                                                           as PAR_BILL_ADRESS_3                  ,
  Placement.PAR_BILL_ADRESS_4                                                           as PAR_BILL_ADRESS_4                  ,
  Placement.PAR_BILL_VILLE                                                              as PAR_BILL_VILLE                     ,
  Placement.PAR_BILL_CD_POSTAL                                                          as PAR_BILL_CD_POSTAL                 ,
  Placement.PAR_DO                                                                      as PAR_DO                             ,
  Placement.PAR_SCORE_NU_MOB                                                            as PAR_SCORE_NU_MOB                   ,
  Placement.PAR_SCORE_IN_MOB                                                            as PAR_SCORE_IN_MOB                   ,
  Placement.PAR_TRESHOLD_NU_MOB                                                         as PAR_TRESHOLD_NU_MOB                ,
  Null                                                                                  as PAR_SCORE_NU_INT                   ,
  Null                                                                                  as PAR_SCORE_IN_INT                   ,
  Null                                                                                  as PAR_TRESHOLD_NU_INT                ,
  Placement.PAR_MOB_TAC                                                                 as PAR_MOB_TAC                        ,
  Placement.PAR_MOB_SIM                                                                 as PAR_MOB_SIM                        ,
  Placement.PAR_IMEI_CD                                                                 as PAR_MOB_IMEI                       ,
  Placement.CONTRCT_DT_SIGN_PREC                                                        as CONTRCT_DT_SIGN_PREC               ,
  Placement.CONTRCT_DT_FIN_PREC                                                         as CONTRCT_DT_FIN_PREC                ,
  Placement.CONTRCT_DT_SIGN_POST                                                        as CONTRCT_DT_SIGN_POST               ,
  Placement.CONTRCT_DUREE_ENG                                                           as CONTRCT_DUREE_ENG                  ,
  Placement.CONTRCT_UNIT_ENG                                                            as CONTRCT_UNIT_ENG                   ,
  Placement.PAR_USCM                                                                    as PAR_USCM                           ,
  Placement.PAR_USCM_DS                                                                 as PAR_USCM_DS                        ,
  Placement.PAR_USCM_USCM_DS                                                            as PAR_USCM_USCM_DS                   ,
  Placement.PAR_USCM_REGUSCM                                                            as PAR_USCM_REGUSCM                   ,
  Placement.PAR_USCM_REGUSCM_DS                                                         as PAR_USCM_REGUSCM_DS                ,
  Null                                                                                  as PERNNT_IN                          ,
  Null                                                                                  as PERNNT_END_DT                      ,
  Null                                                                                  as PERNNT_MOTIF                       ,
  Null                                                                                  as PERNNT_CALC_END_DT                 ,
  'NA'                                                                                  as CONCURENCE_IN                      ,
  'NA'                                                                                  as CONCURENCE_CONCLU_IN               ,
  Null                                                                                  as CONCURENCE_ID                      ,
  NULL                                                                                  as DELIVERY_ONTIME_IN                 ,
  Coalesce(Delais.DELAIS,-1)                                                            as DELIVERY_DEAD_LINE_NU              ,
  Placement.ID_QUANTITE                                                                 as ID_QUANTITE                        ,
  Null                                                                                  as CLOSURE_DT                         ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS                      ,
  0                                                                                     as HOT_IN                             ,
  1                                                                                     as FRESH_IN                           ,
  0                                                                                     as COHERENCE_IN                        
From 
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_VAH Placement                                  
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_VAH_CAL Acte                               
    On    Placement.ACTE_ID                       = Acte.ACTE_ID                  
      And Placement.ORDER_DEPOSIT_DT              = Acte.ORDER_DEPOSIT_DT         
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_DELAIS_PILCOM Delais              
    On    Acte.TYPE_COMMANDE_ID                          = Delais.TYPE_COMMANDE_ID
      And Acte.TYPE_SERVICE_FINAL                        = Delais.TYPE_SERVICE    
      And Acte.PERIODE_ID                                = Delais.PERIODE_ID      
      And Delais.FRESH_IN                                 = 1                     
      And Delais.CURRENT_IN                               = 1                     
      And Delais.CLOSURE_DT                               is Null                 
    --Jointure rÃ©cupÃ©rer les infos de la table des matrices
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat               
    --On rÃ©interprete ici les commandes qui Ã©tait en ADP et qui sorte en aquisition => On le remet en maintient
    On    Acte.TYPE_COMMANDE_ID                   = Mat.TYPE_COMMANDE_ID          
      And '${P_PIL_211}'                          = Mat.SEG_COM_ID_INI            
      And Acte.SEG_COM_ID_FINAL                   = Mat.SEG_COM_ID_FINAL          
      And Acte.PERIODE_ID                         = Mat.PERIODE_ID                
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode      
    On    Acte.PERIODE_ID                                   = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                               = 1                  
      And EtatPeriode.FRESH_IN                                 = 1                  
      And EtatPeriode.CLOSURE_DT                               Is Null              
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_ACTE_PILCOM    RefActeSC                  
    On    Mat.ACTE_ID                                     = RefActeSC.ACTE_ID       
      And Mat.PERIODE_ID                                  = RefActeSC.PERIODE_ID    
      And RefActeSC.FRESH_IN                              = 1                       
      And RefActeSC.CURRENT_IN                            = 1                       
      And RefActeSC.CLOSURE_DT                            Is Null                   
Left Outer  Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_VAH RefOrga                         
    On    Placement.EXT_SOURCE_ORDR_ID                 = RefOrga.EXT_SOURCE_ORDR_ID 
      And Placement.CHANNL_ID                          = RefOrga.ORG_CHANNL_ID      
      And RefOrga.CURRENT_IN                              = 1
      And RefOrga.CLOSURE_DT                              Is Null

  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                               = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG                   = 1
      And RetournCSO.CURRENT_IN                           = 1
  Left Outer Join ${KNB_PCO_TMP}.ORD_T_CALC_ACT_VAH_O3 HierO3
    On    Placement.ACTE_ID                               = HierO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                        = HierO3.ORDER_DEPOSIT_DT
    
--KPI2020 : Jointure Referentiel CALIPSO 
Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB           
     On EAN_Canal_WEB.EAN_CD = Substr(Placement.EAN_CD ,1,13)        
     And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
     
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM 
     On  EAN_Canal_DOM.EAN_CD = Substr(Placement.EAN_CD ,1,13)
     And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'
Where
  (1=1)
;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_VAH;
.if errorcode <> 0 then .quit 1


.quit 0

