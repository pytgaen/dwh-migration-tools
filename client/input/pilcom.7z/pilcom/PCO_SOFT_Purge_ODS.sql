-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   PCO_SOFT_Purge_ODS.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/01/2014      AID         Creation
--------------------------------------------------------------------------------

.set width 2500;

Create Volatile Table ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER (
      EXTERNAL_ORDER_ID   VARCHAR(19)  CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      ORDER_STATUS_CD     VARCHAR(20)  CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL,
      STATUS_MODIF_TS     TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS'         NOT NULL)     
PRIMARY INDEX ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD , STATUS_MODIF_TS )
On Commit Preserve Rows
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER COLUMN EXTERNAL_ORDER_ID;
Collect Stat On ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER COLUMN ORDER_STATUS_CD;
Collect Stat On ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER COLUMN STATUS_MODIF_TS;
.if ErrorCode <> 0 Then .Quit 1;


-----------------------------------------------------------------------------------------------------------------------------
-- On extrait les Ids de la Table ATP_O_FACADE_ORDER :
-----------------------------------------------------------------------------------------------------------------------------


Insert into ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER
(
  EXTERNAL_ORDER_ID     ,
  ORDER_STATUS_CD       ,
  STATUS_MODIF_TS                
)
Select
  EXTERNAL_ORDER_ID    ,
  ORDER_STATUS_CD      ,
  STATUS_MODIF_TS
From
  ${KNB_ODS_MM2}.ATP_O_FACADE_ORDER
Where
  QUEUE_TS < (CURRENT_TIMESTAMP(0) - INTERVAL '${NBJours}' DAY)
;
.if ErrorCode <> 0 Then .Quit 1;

-----------------------------------------------------------------------------------------------------------------------------
-- On Supprime les Ids des tables FACADE_ORDER
-----------------------------------------------------------------------------------------------------------------------------


Delete from ${KNB_ODS_MM2}.ATP_O_FACADE_ORDER
WHERE 
(1=1)
And ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD , STATUS_MODIF_TS )
 In
	(
         Select
		EXTERNAL_ORDER_ID     ,
                ORDER_STATUS_CD       ,
                STATUS_MODIF_TS
         From
		${KNB_TERADATA_USER}.INB_V_FACADE_ORDER
	)
;

.if ErrorCode <> 0 Then .Quit 1;


Delete from ${KNB_ODS_MM2}.ATP_O_FACADE_ORDER_LINE_INT
WHERE
(1=1)
And ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD , STATUS_MODIF_TS )
 In
        (
         Select
                EXTERNAL_ORDER_ID     ,
                ORDER_STATUS_CD       ,
                STATUS_MODIF_TS
         From
                ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER
        )
;

.if ErrorCode <> 0 Then .Quit 1;

Delete from ${KNB_ODS_MM2}.ATP_O_FACADE_ORDER_LINE_PCM
WHERE
(1=1)
And ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD , STATUS_MODIF_TS )
 In
        (
         Select
                EXTERNAL_ORDER_ID     ,
                ORDER_STATUS_CD       ,
                STATUS_MODIF_TS
         From
                ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER
        )
;

.if ErrorCode <> 0 Then .Quit 1;

Delete from ${KNB_ODS_MM2}.ATP_O_FACADE_ORDER_LINE_MOB
WHERE
(1=1)
And ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD , STATUS_MODIF_TS )
 In
        (
         Select
                EXTERNAL_ORDER_ID     ,
                ORDER_STATUS_CD       ,
                STATUS_MODIF_TS
         From
                ${KNB_TERADATA_USER}.INB_V_FACADE_ORDER
        )
;

.if ErrorCode <> 0 Then .Quit 1;

.quit 0


