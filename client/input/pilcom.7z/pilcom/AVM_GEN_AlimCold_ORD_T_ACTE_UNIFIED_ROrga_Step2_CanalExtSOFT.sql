-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    AVM_GEN_AlimCold_ORD_T_ACTE_UNIFIED_ROrga_Step2_CanalExtSOFT.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 02/05/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;




--Dédoublonnage de la table d'activitée Rforce :

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_SOFT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
--Insert SOFT Internet
Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_SOFT
(
  ACTE_ID                       ,
  ORG_CANAL_ID                  
)
Select
  RefId.ACTE_ID                                 As ACTE_ID              ,
  RefSOFT.ORG_CANAL_ID                          As ORG_CANAL_ID        
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG RefId
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT RefSOFT
    On RefId.ACTE_ID      = RefSOFT.ACTE_ID
Where
  (1=1)
  And RefSOFT.ORG_CANAL_ID in ('700','OFP','TEL','CTC','DOM','FID')
Qualify Row_number() over (Partition by RefId.ACTE_ID Order By  RefSOFT.ORG_CANAL_ID Asc) = 1

--Insert des actes SOFT
;Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_SOFT
(
  ACTE_ID                       ,
  ORG_CANAL_ID                  
)
Select
  RefId.ACTE_ID                                 As ACTE_ID              ,
  RefSOFT.ORG_CANAL_ID                          As ORG_CANAL_ID        
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG RefId
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB RefSOFT
    On RefId.ACTE_ID      = RefSOFT.ACTE_ID
Where
  (1=1)
  And RefSOFT.ORG_CANAL_ID in ('700','OFP','TEL','CTC','DOM','FID')
Qualify Row_number() over (Partition by RefId.ACTE_ID Order By  RefSOFT.ORG_CANAL_ID Asc) = 1

--Insert des SOFT PCM
;Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_SOFT
(
  ACTE_ID                       ,
  ORG_CANAL_ID                  
)
Select
  RefId.ACTE_ID                                 As ACTE_ID              ,
  RefSOFT.ORG_CANAL_ID                          As ORG_CANAL_ID        
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG RefId
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_PCM RefSOFT
    On RefId.ACTE_ID      = RefSOFT.ACTE_ID
Where
  (1=1)
  And RefSOFT.ORG_CANAL_ID in ('700','OFP','TEL','CTC','DOM','FID')
Qualify Row_number() over (Partition by RefId.ACTE_ID Order By  RefSOFT.ORG_CANAL_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACT_UNI_CHANNEL_EXT_SOFT;
.if errorcode <> 0 then .quit 1

.quit 0


