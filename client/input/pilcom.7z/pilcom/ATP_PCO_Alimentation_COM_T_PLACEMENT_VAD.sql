-- $HEADER: mm2pco/current/sql/ATP_PCO_Alimentation_COM_T_PLACEMENT_VAD.sql 13_05#12 14-JAN-2019 17:38:21 NNGS2043
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_PCO_Alimentation_COM_T_PLACEMENT_VAD.sql$
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table COM_T_PLACEMENT_VAD_INTER
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     MHA         Création
-- 06/02/2014     AID         Indus
-- 22/09/2014     HZO         Modification : Perform
-- 05/01/2015     MDE         Evol: ajout TARIF_HT
-- 13/04/2016     MDE         Evol  : profondeur calcul 100 jrs
-- 24/03/2016     OCH         Ajout BCR_ID
-- 16/01/2017     HOB         Ajout Champs VA
-- 05/10/2018     LMU         Ajout champs VAD Mobile (RS lot 2)
-- 17/06/2020     TCL         Ajout du champ NSCE pour les KPI ESIM
---------------------------------------------------------------------------------

.set width 2000;


-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER
-- **************************************************************

--Paramètre attendu : Les bornes de dates

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER
(
  ACTE_ID               ,
  APPLI_SOURCE_ID       ,
  CDE_REFERENCE         ,
  DATE_SAISIE           ,
  DATE_SAISIE_TS        ,
  DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE ,
  CLIENT_NU             ,
  PAR_IMSI              ,
  PAR_MOB_SIM           ,
  DOSSIER_DT_CREAT      ,
  DOSSIER_DT_RESIL      ,
  DOSSIER_DATE_RESIL    ,
  DOSSIER_TYPE_RESIL    ,
  DOSSIER_MOTIF_RESIL   ,
  PRESFACT_CO_COM       ,
  PARC_DT_DEBUT         ,
  PARC_DT_FIN           ,
  PRESFACT_CO_PREC      ,
  USCM_CO               ,
  PDV                   ,
  STATUT_CDE            ,
  DUREE_ENGAGEMENT      ,
  TYPE_DUR_ENGAGEMENT   ,
  TYPE_LIG_CDE          ,
  CDE_LIG_ID            ,
  EXT_PRODUCT_ID        ,
  PRIX_HT               ,
  DATEVALIDATION        ,
  DATE_DECLA_SACHEM     ,
  DATE_LIVRAISON        ,
  NUMEROIMEI            ,
  CODEVENDEUR           ,
  EAN_FTT               ,
  CODE_TAC              ,
  TERM_PERFORM_IND      ,
  CODEVENDEUR_MOD       ,
  STATUT_CLOS           ,
  STATUT_ANNUL          ,
  AID                   ,
  ND                    ,
  BCR_ID                ,
  TYPPROD_CO            ,
  TARIF_HT              ,
  RCS_IN                , -- RCS
  RCS_MOTIF_ID          , -- RCS
  RCS_CODE_ADV_MOTIF    , -- RCS
  CLOSURE_DT            ,
  CREATION_TS           ,
  LAST_MODIF_TS         ,
  FRESH_IN              ,
  COHERENCE_IN          
)
Select
  Gen.ACTE_ID             as ACTE_ID              ,
  Vad.APPLI_SOURCE_ID     as APPLI_SOURCE_ID      ,
  Vad.CDE_REFERENCE       as CDE_REFERENCE        ,
  Vad.DATE_SAISIE         as DATE_SAISIE          ,
  Vad.DATE_SAISIE_TS      as DATE_SAISIE_TS       ,
  Vad.DOSSIER_NU          as DOSSIER_NU           ,
  Null                    as DOSSIER_NU_PREC_PORTE,
  Vad.CLIENT_NU           as CLIENT_NU            ,
  Null                    as PAR_IMSI             ,
  Vad.NSCE                as PAR_MOB_SIM          ,
  Null                    as DOSSIER_DT_CREAT     ,
  Null                    as DOSSIER_DT_RESIL     ,
  Null                    as DOSSIER_DATE_RESIL   ,
  Null                    as DOSSIER_TYPE_RESIL   ,
  Null                    as DOSSIER_MOTIF_RESIL  ,
  Vad.PRESFACT_CO_COM     as PRESFACT_CO_COM      ,
  Null                    as PARC_DT_DEBUT        ,
  Null                    as PARC_DT_FIN          ,
  Vad.PRESFACT_CO_PREC    as PRESFACT_CO_PREC     ,
  Vad.USCM_CO             as USCM_CO              ,
  Vad.PDV                 as PDV                  ,
  Vad.STATUT_CDE          as STATUT_CDE           ,
  Vad.DUREE_ENGAGEMENT    as DUREE_ENGAGEMENT     ,
  Vad.TYPE_DUR_ENGAGEMENT as TYPE_DUR_ENGAGEMENT  ,
  Vad.TYPE_LIG_CDE        as TYPE_LIG_CDE         ,
  Vad.CDE_LIG_ID          as CDE_LIG_ID           ,
  Vad.EXT_PRODUCT_ID      as EXT_PRODUCT_ID       ,
  Vad.PRIX_HT             as PRIX_HT              ,
  Vad.DATEVALIDATION      as DATEVALIDATION       ,
  Vad.DATE_DECLA_SACHEM   as DATE_DECLA_SACHEM    ,
  Vad.DATE_LIVRAISON      as DATE_LIVRAISON       ,
  Vad.NUMEROIMEI          as NUMEROIMEI           ,
  Vad.CODEVENDEUR         as CODEVENDEUR          ,
  Vad.EAN_FTT             as EAN_FTT              ,
  Vad.CODE_TAC            as CODE_TAC             ,
  Vad.TERM_PERFORM_IND    as TERM_PERFORM_IND     ,
  Vad.CODEVENDEUR_MOD     as CODEVENDEUR_MOD      ,
  Vad.STATUT_CLOS         as STATUT_CLOS          ,
  Vad.STATUT_ANNUL        as STATUT_ANNUL         ,
  Vad.AID                 as AID                  ,
  Vad.ND                  as ND                   ,
  Vad.BCR_ID              as BCR_ID               ,
  Vad.TYPPROD_CO          as TYPPROD_CO           ,
  Vad.TARIF_HT            as TARIF_HT             ,
  Vad.RCS_IN              as RCS_IN               , -- RCS
  Vad.RCS_MOTIF_ID        as RCS_MOTIF_ID         , -- RCS
  Vad.RCS_CODE_ADV_MOTIF  as RCS_CODE_ADV_MOTIF   , -- RCS
  Null                    as CLOSURE_DT           ,
  '${KNB_DATE_VACATION}'  as CREATION_TS          ,
  '${KNB_DATE_VACATION}'  as LAST_MODIF_TS        ,
  1                       as FRESH_IN             ,
  0                       as COHERENCE_IN         
From
  ${KNB_PCO_TMP}.COM_T_CALCUL_PL_VAD Vad
  Inner Join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN Gen
    On  Vad.EXTERNAL_ACTE_ID  = Gen.EXTERNAL_ACTE_ID
      And Vad.TYPE_SOURCE_ID  = Gen.TYPE_SOURCE_ID
;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER;
.if errorcode <> 0 then .quit 1


--On update les attributs de pérénité s'ils sont déjà calculé
Update Tmp
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER  Tmp,
  ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD      Socle
Set
  PARC_DT_DEBUT             = Coalesce(Socle.PARC_DT_DEBUT,Tmp.PARC_DT_DEBUT)                 ,
  PARC_DT_FIN               = Coalesce(Socle.PARC_DT_FIN,Tmp.PARC_DT_FIN)                     ,
  DOSSIER_NU                = Coalesce(Socle.DOSSIER_NU,Tmp.DOSSIER_NU)                       ,
  DOSSIER_NU_PREC_PORTE     = Coalesce(Socle.DOSSIER_NU_PREC_PORTE,Tmp.DOSSIER_NU_PREC_PORTE) ,
  DOSSIER_DT_CREAT          = Coalesce(Socle.DOSSIER_DT_CREAT,Tmp.DOSSIER_DT_CREAT)           ,
  DOSSIER_DT_RESIL          = Coalesce(Socle.DOSSIER_DT_RESIL,Tmp.DOSSIER_DT_RESIL)           ,
  DOSSIER_DATE_RESIL        = Coalesce(Socle.DOSSIER_DATE_RESIL,Tmp.DOSSIER_DATE_RESIL)       ,
  DOSSIER_TYPE_RESIL        = Coalesce(Socle.DOSSIER_TYPE_RESIL,Tmp.DOSSIER_TYPE_RESIL)       ,
  DOSSIER_MOTIF_RESIL       = Coalesce(Socle.DOSSIER_MOTIF_RESIL,Tmp.DOSSIER_MOTIF_RESIL)     ,
  CONTRCT_DT_SIGN_PREC      = Coalesce(Socle.CONTRCT_DT_SIGN_PREC,Tmp.CONTRCT_DT_SIGN_PREC)   ,
  CONTRCT_DT_FIN_PREC       = Coalesce(Socle.CONTRCT_DT_FIN_PREC,Tmp.CONTRCT_DT_FIN_PREC)     ,
  CONTRCT_DT_SIGN_POST      = Coalesce(Socle.CONTRCT_DT_SIGN_POST,Tmp.CONTRCT_DT_SIGN_POST)   ,
  CONTRCT_DUREE_ENG         = Coalesce(Socle.CONTRCT_DUREE_ENG,Tmp.CONTRCT_DUREE_ENG)         ,
  CONTRCT_UNIT_ENG          = Coalesce(Socle.CONTRCT_UNIT_ENG,Tmp.CONTRCT_UNIT_ENG)           ,
  EDO_ID                    = Coalesce(Socle.EDO_ID, Tmp.EDO_ID)                              ,
  FLAG_PLT_CONV             = Coalesce(Socle.FLAG_PLT_CONV, Tmp.FLAG_PLT_CONV)                ,
  FLAG_PLT_SCH              = Coalesce(Socle.FLAG_PLT_SCH, Tmp.FLAG_PLT_SCH)                  ,
  FLAG_TEAM_MKT             = Coalesce(Socle.FLAG_TEAM_MKT, Tmp.FLAG_TEAM_MKT)                ,
  FLAG_TYPE_CMP             = Coalesce(Socle.FLAG_TYPE_CMP, Tmp.FLAG_TYPE_CMP)                ,
  TYPE_EDO                  = Coalesce(Socle.TYPE_EDO, Tmp.TYPE_EDO)                          ,
  ORG_REF_TRAV              = Coalesce(Socle.ORG_REF_TRAV,Tmp.ORG_REF_TRAV)                   ,
  TERM_PERFORM_IND          = Coalesce(Socle.TERM_PERFORM_IND,Tmp.TERM_PERFORM_IND)           ,
  ORG_AGENT_ID              = Coalesce(Socle.ORG_AGENT_ID,Tmp.ORG_AGENT_ID)                   ,
  ORG_POC_XI                = Coalesce(Socle.ORG_POC_XI,Tmp.ORG_POC_XI)                       ,
  ORG_NOM                   = Coalesce(Socle.ORG_NOM,Tmp.ORG_NOM)                             ,
  ORG_PRENOM                = Coalesce(Socle.ORG_PRENOM,Tmp.ORG_PRENOM)                       ,
  ORG_ACTVT_REEL            = Coalesce(Socle.ORG_ACTVT_REEL,Tmp.ORG_ACTVT_REEL)               ,
  ORG_GROUPE_ID             = Coalesce(Socle.ORG_GROUPE_ID,Tmp.ORG_GROUPE_ID)                 ,
  ORG_POC_XI_RESP           = Coalesce(Socle.ORG_POC_XI_RESP,Tmp.ORG_POC_XI_RESP)             ,
  ORG_AGENT_RESP_ID         = Coalesce(Socle.ORG_AGENT_RESP_ID,Tmp.ORG_AGENT_RESP_ID)         ,
  DMC_LINE_ID               = Coalesce(Socle.DMC_LINE_ID, Tmp.DMC_LINE_ID)                    , -- RCS
  DMC_MASTER_LINE_ID        = Coalesce(Socle.DMC_MASTER_LINE_ID, Tmp.DMC_MASTER_LINE_ID)      , -- RCS
  DMC_LINE_TYPE             = Coalesce(Socle.DMC_LINE_TYPE, Tmp.DMC_LINE_TYPE)                , -- RCS
  RCS_MOTIV_INVC_CD         = Coalesce(Socle.RCS_MOTIV_INVC_CD, Tmp.RCS_MOTIV_INVC_CD)        ,
  RCS_ENR_ACTE_ID           = Coalesce(Socle.RCS_ENR_ACTE_ID, Tmp.RCS_ENR_ACTE_ID)            ,
  PAR_DEPARTMNT_ID          = Coalesce(Socle.PAR_DEPARTMNT_ID, Tmp.PAR_DEPARTMNT_ID)          ,
  PAR_BU_CD                 = Coalesce(Socle.PAR_BU_CD, Tmp.PAR_BU_CD)                        ,
  PAR_CID_ID                = Coalesce(Socle.PAR_CID_ID   , Tmp.PAR_CID_ID  )                 ,
  PAR_PID_ID                = Coalesce(Socle.PAR_PID_ID   , Tmp.PAR_PID_ID  )                 ,
  PAR_FIRST_IN              = Coalesce(Socle.PAR_FIRST_IN , Tmp.PAR_FIRST_IN)                 ,
  PAR_POSTAL_CD             = Coalesce(Socle.PAR_POSTAL_CD, Tmp.PAR_POSTAL_CD)                ,
  PAR_INSEE_CD              = Coalesce(Socle.PAR_INSEE_CD, Tmp.PAR_INSEE_CD)                  ,
  PAR_GEO_MACROZONE         = Coalesce(Socle.PAR_GEO_MACROZONE, Tmp.PAR_GEO_MACROZONE)        ,
  PAR_UNIFIED_PARTY_ID      = Coalesce(Socle.PAR_UNIFIED_PARTY_ID, Tmp.PAR_UNIFIED_PARTY_ID)  ,
  PAR_PARTY_REGRPMNT_ID     = Coalesce(Socle.PAR_PARTY_REGRPMNT_ID, Tmp.PAR_PARTY_REGRPMNT_ID),
  PAR_IRIS2000_CD           = Coalesce(Socle.PAR_IRIS2000_CD, Tmp.PAR_IRIS2000_CD)            ,
  PAR_LASTNAME              = Coalesce(Socle.PAR_LASTNAME,Tmp.PAR_LASTNAME)                   ,
  PAR_FIRSTNAME             = Coalesce(Socle.PAR_FIRSTNAME,Tmp.PAR_FIRSTNAME)                 ,
  PAR_TYPE                  = Coalesce(Socle.PAR_TYPE,Tmp.PAR_TYPE)                           ,
  PAR_EMAIL                 = Coalesce(Socle.PAR_EMAIL,Tmp.PAR_EMAIL)                         ,
  PAR_BILL_ADRESS_1         = Coalesce(Socle.PAR_BILL_ADRESS_1,Tmp.PAR_BILL_ADRESS_1)         ,
  PAR_BILL_ADRESS_2         = Coalesce(Socle.PAR_BILL_ADRESS_2,Tmp.PAR_BILL_ADRESS_2)         ,
  PAR_BILL_ADRESS_3         = Coalesce(Socle.PAR_BILL_ADRESS_3,Tmp.PAR_BILL_ADRESS_3)         ,
  PAR_BILL_ADRESS_4         = Coalesce(Socle.PAR_BILL_ADRESS_4,Tmp.PAR_BILL_ADRESS_4)         ,
  PAR_BILL_VILLE            = Coalesce(Socle.PAR_BILL_VILLE,Tmp.PAR_BILL_VILLE)               ,
  PAR_BILL_CD_POSTAL        = Coalesce(Socle.PAR_BILL_CD_POSTAL,Tmp.PAR_BILL_CD_POSTAL)       ,
  PAR_DO                    = Coalesce(Socle.PAR_DO,Tmp.PAR_DO)                               ,
  PAR_SCORE_NU              = Coalesce(Socle.PAR_SCORE_NU,Tmp.PAR_SCORE_NU)                   ,
  PAR_SCORE_IN              = Coalesce(Socle.PAR_SCORE_IN,Tmp.PAR_SCORE_IN)                   ,
  PAR_TRESHOLD_NU           = Coalesce(Socle.PAR_TRESHOLD_NU,Tmp.PAR_TRESHOLD_NU)             ,
  --Pendant 200 Jours on test le réenrichissement du PAR_IMSI
  PAR_IMSI                  = Case  When (Tmp.DATE_SAISIE + 200) >= Current_Date
                                      Then Coalesce(Socle.PAR_IMSI,Tmp.PAR_IMSI)
                                    Else Null
                              End,
  PAR_MOB_SIM               = Coalesce(Socle.PAR_MOB_SIM,Tmp.PAR_MOB_SIM)             
Where
      Tmp.ACTE_ID     = Socle.ACTE_ID
--  And Tmp.TYPE_LIG_CDE in ('OT','SO')






;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER
(
  ACTE_ID               ,
  APPLI_SOURCE_ID       ,
  CDE_REFERENCE         ,
  DATE_SAISIE           ,
  DATE_SAISIE_TS        ,
  DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE ,
  CLIENT_NU             ,
  PAR_IMSI              ,
  PAR_MOB_SIM           ,
  DMC_LINE_ID           ,
  DMC_MASTER_LINE_ID    ,
  DMC_LINE_TYPE         , -- RCS
  RCS_MOTIV_INVC_CD     , -- RCS
  RCS_ENR_ACTE_ID       , -- RCS
  PAR_DEPARTMNT_ID      ,
  PAR_BU_CD             ,
  PAR_CID_ID            ,
  PAR_PID_ID            ,
  PAR_FIRST_IN          ,
  PAR_POSTAL_CD         ,
  PAR_INSEE_CD          ,
  PAR_GEO_MACROZONE     ,
  PAR_UNIFIED_PARTY_ID  ,
  PAR_PARTY_REGRPMNT_ID ,
  PAR_IRIS2000_CD       ,
  PAR_FIBER_IN          ,
  DOSSIER_DT_CREAT      ,
  DOSSIER_DT_RESIL      ,
  DOSSIER_DATE_RESIL    ,
  DOSSIER_TYPE_RESIL    ,
  DOSSIER_MOTIF_RESIL   ,
  PRESFACT_CO_COM       ,
  PARC_DT_DEBUT         ,
  PARC_DT_FIN           ,
  PRESFACT_CO_PREC      ,
  USCM_CO               ,
  PDV                   ,
  STATUT_CDE            ,
  DUREE_ENGAGEMENT      ,
  TYPE_DUR_ENGAGEMENT   ,
  TYPE_LIG_CDE          ,
  CDE_LIG_ID            ,
  EXT_PRODUCT_ID        ,
  PRIX_HT               ,
  DATEVALIDATION        ,
  DATE_DECLA_SACHEM     ,
  DATE_LIVRAISON        ,
  NUMEROIMEI            ,
  CODEVENDEUR           ,
  EAN_FTT               ,
  CODE_TAC              ,
  CODEVENDEUR_MOD       ,
  STATUT_CLOS           ,
  STATUT_ANNUL          ,
  AID                   ,
  ND                    ,
  BCR_ID                ,
  TYPPROD_CO            ,
  CONTRCT_DT_SIGN_PREC  ,
  CONTRCT_DT_FIN_PREC   ,
  CONTRCT_DT_SIGN_POST  ,
  CONTRCT_DUREE_ENG     ,
  CONTRCT_UNIT_ENG      ,
  EDO_ID                ,
  FLAG_PLT_CONV         ,
  FLAG_PLT_SCH          ,
  FLAG_TEAM_MKT         ,
  FLAG_TYPE_CMP         ,
  TYPE_EDO              ,
  ORG_REF_TRAV          ,
  TERM_PERFORM_IND      ,
  ORG_AGENT_ID          ,
  ORG_POC_XI            ,
  ORG_NOM               ,
  ORG_PRENOM            ,
  ORG_ACTVT_REEL        ,
  ORG_GROUPE_ID         ,
  ORG_POC_XI_RESP       ,
  ORG_AGENT_RESP_ID     ,
  PAR_LASTNAME          ,
  PAR_FIRSTNAME         ,
  PAR_TYPE              ,
  PAR_EMAIL             ,
  PAR_BILL_ADRESS_1     ,
  PAR_BILL_ADRESS_2     ,
  PAR_BILL_ADRESS_3     ,
  PAR_BILL_ADRESS_4     ,
  PAR_BILL_VILLE        ,
  PAR_BILL_CD_POSTAL    ,
  PAR_DO                ,
  PAR_SCORE_NU          ,
  PAR_SCORE_IN          ,
  PAR_TRESHOLD_NU       ,
  TARIF_HT              ,
  RCS_IN                , -- RCS
  RCS_MOTIF_ID          , -- RCS
  RCS_CODE_ADV_MOTIF    , -- RCS
  CLOSURE_DT            ,
  CREATION_TS           ,
  LAST_MODIF_TS         ,
  FRESH_IN              ,
  COHERENCE_IN          
)
Select
  Vad.ACTE_ID                     as ACTE_ID                ,
  Vad.APPLI_SOURCE_ID             as APPLI_SOURCE_ID        ,
  Vad.CDE_REFERENCE               as CDE_REFERENCE          ,
  Vad.DATE_SAISIE                 as DATE_SAISIE            ,
  Vad.DATE_SAISIE_TS              as DATE_SAISIE_TS         ,
  Vad.DOSSIER_NU                  as DOSSIER_NU             ,
  Vad.DOSSIER_NU_PREC_PORTE       as DOSSIER_NU_PREC_PORTE  ,
  Vad.CLIENT_NU                   as CLIENT_NU              ,
  Vad.PAR_IMSI                    as PAR_IMSI               ,
  Vad.PAR_MOB_SIM                 as PAR_MOB_SIM            ,
  Vad.DMC_LINE_ID                 as DMC_LINE_ID            ,
  Vad.DMC_MASTER_LINE_ID          as DMC_MASTER_LINE_ID     ,
  Vad.DMC_LINE_TYPE               as DMC_LINE_TYPE          ,
  Vad.RCS_MOTIV_INVC_CD           as RCS_MOTIV_INVC_CD      ,
  Vad.RCS_ENR_ACTE_ID             as RCS_ENR_ACTE_ID        ,
  Vad.PAR_DEPARTMNT_ID            as PAR_DEPARTMNT_ID       ,
  Vad.PAR_BU_CD                   as PAR_BU_CD              ,
  Vad.PAR_CID_ID                  as PAR_CID_ID             ,
  Vad.PAR_PID_ID                  as PAR_PID_ID             ,
  Vad.PAR_FIRST_IN                as PAR_FIRST_IN           ,
  Vad.PAR_POSTAL_CD               as PAR_POSTAL_CD          , --Décalage du champs
  Vad.PAR_INSEE_CD                as PAR_INSEE_CD           ,
  Vad.PAR_GEO_MACROZONE	          as PAR_GEO_MACROZONE      ,
  Vad.PAR_UNIFIED_PARTY_ID        as PAR_UNIFIED_PARTY_ID   ,
  Vad.PAR_PARTY_REGRPMNT_ID       as PAR_PARTY_REGRPMNT_ID  ,
  Vad.PAR_IRIS2000_CD             as PAR_IRIS2000_CD        ,
  Vad.PAR_FIBER_IN                as PAR_FIBER_IN           ,
  Vad.DOSSIER_DT_CREAT            as DOSSIER_DT_CREAT       ,
  Vad.DOSSIER_DT_RESIL            as DOSSIER_DT_RESIL       ,
  Vad.DOSSIER_DATE_RESIL          as DOSSIER_DATE_RESIL     ,
  Vad.DOSSIER_TYPE_RESIL          as DOSSIER_TYPE_RESIL     ,
  Vad.DOSSIER_MOTIF_RESIL         as DOSSIER_MOTIF_RESIL    ,
  Vad.PRESFACT_CO_COM             as PRESFACT_CO_COM        ,
  Vad.PARC_DT_DEBUT               as PARC_DT_DEBUT          ,
  Vad.PARC_DT_FIN                 as PARC_DT_FIN            ,
  Vad.PRESFACT_CO_PREC            as PRESFACT_CO_PREC       ,
  Vad.USCM_CO                     as USCM_CO                ,
  Vad.PDV                         as PDV                    ,
  Vad.STATUT_CDE                  as STATUT_CDE             ,
  Vad.DUREE_ENGAGEMENT            as DUREE_ENGAGEMENT       ,
  Vad.TYPE_DUR_ENGAGEMENT         as TYPE_DUR_ENGAGEMENT    ,
  Vad.TYPE_LIG_CDE                as TYPE_LIG_CDE           ,
  Vad.CDE_LIG_ID                  as CDE_LIG_ID             ,
  Vad.EXT_PRODUCT_ID              as EXT_PRODUCT_ID         ,
  Vad.PRIX_HT                     as PRIX_HT                ,
  Vad.DATEVALIDATION              as DATEVALIDATION         ,
  Vad.DATE_DECLA_SACHEM           as DATE_DECLA_SACHEM      ,
  Vad.DATE_LIVRAISON              as DATE_LIVRAISON         ,
  Vad.NUMEROIMEI                  as NUMEROIMEI             ,
  Vad.CODEVENDEUR                 as CODEVENDEUR            ,
  Vad.EAN_FTT                     as EAN_FTT                ,
  Vad.CODE_TAC                    as CODE_TAC               ,
  Vad.CODEVENDEUR_MOD             as CODEVENDEUR_MOD        ,
  Vad.STATUT_CLOS                 as STATUT_CLOS            ,
  Vad.STATUT_ANNUL                as STATUT_ANNUL           ,
  Vad.AID                         as AID                    ,
  Vad.ND                          as ND                     ,
  Vad.BCR_ID                      as BCR_ID                 ,
  Vad.TYPPROD_CO                  as TYPPROD_CO             ,
  Vad.CONTRCT_DT_SIGN_PREC        as CONTRCT_DT_SIGN_PREC   ,
  Vad.CONTRCT_DT_FIN_PREC         as CONTRCT_DT_FIN_PREC    ,
  Vad.CONTRCT_DT_SIGN_POST        as CONTRCT_DT_SIGN_POST   ,
  Vad.CONTRCT_DUREE_ENG           as CONTRCT_DUREE_ENG      ,
  Vad.CONTRCT_UNIT_ENG            as CONTRCT_UNIT_ENG       ,
  Vad.EDO_ID                      as EDO_ID                 ,
  Vad.FLAG_PLT_CONV               as FLAG_PLT_CONV          ,
  Vad.FLAG_PLT_SCH                as FLAG_PLT_SCH           ,
  Vad.FLAG_TEAM_MKT               as FLAG_TEAM_MKT          ,
  Vad.FLAG_TYPE_CMP               as FLAG_TYPE_CMP          ,
  Vad.TYPE_EDO                    as TYPE_EDO               ,
  Vad.ORG_REF_TRAV                as ORG_REF_TRAV           ,
  Vad.TERM_PERFORM_IND            as TERM_PERFORM_IND       ,
  Vad.ORG_AGENT_ID                as ORG_AGENT_ID           ,
  Vad.ORG_POC_XI                  as ORG_POC_XI             ,
  Vad.ORG_NOM                     as ORG_NOM                ,
  Vad.ORG_PRENOM                  as ORG_PRENOM             ,
  Vad.ORG_ACTVT_REEL              as ORG_ACTVT_REEL         ,
  Vad.ORG_GROUPE_ID               as ORG_GROUPE_ID          ,
  Vad.ORG_POC_XI_RESP             as ORG_POC_XI_RESP        ,
  Vad.ORG_AGENT_RESP_ID           as ORG_AGENT_RESP_ID      ,
  Vad.PAR_LASTNAME                as PAR_LASTNAME           ,
  Vad.PAR_FIRSTNAME               as PAR_FIRSTNAME          ,
  Vad.PAR_TYPE                    as PAR_TYPE               ,
  Vad.PAR_EMAIL                   as PAR_EMAIL              ,
  Vad.PAR_BILL_ADRESS_1           as PAR_BILL_ADRESS_1      ,
  Vad.PAR_BILL_ADRESS_2           as PAR_BILL_ADRESS_2      ,
  Vad.PAR_BILL_ADRESS_3           as PAR_BILL_ADRESS_3      ,
  Vad.PAR_BILL_ADRESS_4           as PAR_BILL_ADRESS_4      ,
  Vad.PAR_BILL_VILLE              as PAR_BILL_VILLE         ,
  Vad.PAR_BILL_CD_POSTAL          as PAR_BILL_CD_POSTAL     ,
  Vad.PAR_DO                      as PAR_DO                 ,
  Vad.PAR_SCORE_NU                as PAR_SCORE_NU           ,
  Vad.PAR_SCORE_IN                as PAR_SCORE_IN           ,
  Vad.PAR_TRESHOLD_NU             as PAR_TRESHOLD_NU        ,
  Vad.TARIF_HT                    as TARIF_HT               ,
  Vad.RCS_IN                      as RCS_IN                 ,
  Vad.RCS_MOTIF_ID                as RCS_MOTIF_ID           ,
  Vad.RCS_CODE_ADV_MOTIF          as RCS_CODE_ADV_MOTIF     , 
  Vad.CLOSURE_DT                  as CLOSURE_DT             ,
  '${KNB_DATE_VACATION}'          as CREATION_TS            ,
  '${KNB_DATE_VACATION}'          as LAST_MODIF_TS          ,
  1                               as FRESH_IN               ,
  0                               as COHERENCE_IN           
From
  ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD Vad
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER VadRecu
    On    Vad.ACTE_ID             = VadRecu.ACTE_ID
Where
  (1=1)
  And Vad.DATE_SAISIE          >= (Current_date - ${P_PIL_542})
  And VadRecu.ACTE_ID             Is Null
;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER;
.if errorcode <> 0 then .quit 1

.quit 0
