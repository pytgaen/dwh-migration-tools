-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_BasculeIDActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Bascule Id Actes
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1 all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1
(
  ACTE_ID                     ,
  DEMANDE_ID                  ,
  EXTERNAL_INT_ID             ,
  INT_DEPOSIT_TS              ,
  INT_DEPOSIT_DT              ,
  OPERATOR_PROVIDER_ID        ,
  RESOLU_ID                   ,
  CONCLU_ID                   ,
  SSCONCLU_ID                 ,
  TYPE_COMMANDE               ,
  PLTF_CO                     ,
  INTRNL_SOURCE_ID            ,
  CONSEIL_XI_CREA             ,
  CONSEIL_XI_RESP             ,
  INT_MODIF_TS                ,
  IN_CLIDOS                   ,
  TYPE_OT_SO                  ,
  CANALDEM                    ,
  CLIENT_NU                   ,
  DOSSIER_NU                  ,
  PRESFACT_CO_PRECED          ,
  PRESFACT_CO_OFFRE_OPT_ACQ   ,
  INB_PRESFACT_ACQ_ADV        ,
  INB_PRESFACT_ACQ_AGAP       ,
  PARC_DT_DEBUT               ,
  PARC_DT_FIN                 ,
  ORDAGD_DT_CONF              ,
  CONTRCT_DT_SIGN_PREC        ,
  CONTRCT_DT_FIN_PREC         ,
  CONTRCT_DT_SIGN_POST        ,
  CONTRCT_DUREE_ENG           ,
  CONTRCT_UNIT_ENG            ,
  EDO_ID                      ,
  FLAG_PLT_CONV               ,
  FLAG_PLT_SCH                ,
  FLAG_TEAM_MKT               ,
  FLAG_TYPE_CMP               ,
  TYPE_EDO                    ,
  EDO_ID_HIER                 ,
  TYPE_EDO_HIER               ,
  ORG_REF_TRAV                ,
  ORG_AGENT_ID                ,
  ORG_POC_XI                  ,
  ORG_NOM                     ,
  ORG_PRENOM                  ,
  ORG_GROUPE_ID               ,
  ORG_GROUPE_ID_HIER          ,
  ORG_ACTVT_REEL              ,
  ORG_RESP_REF_TRAV           ,
  ORG_RESP_AGENT_ID           ,
  ORG_RESP_XI                 ,
  PAR_LASTNAME                ,
  PAR_FIRSTNAME               ,
  PAR_TYPE                    ,
  PAR_IMSI                    ,
  PAR_EMAIL                   ,
  PAR_BILL_ADRESS_1           ,
  PAR_BILL_ADRESS_2           ,
  PAR_BILL_ADRESS_3           ,
  PAR_BILL_ADRESS_4           ,
  PAR_BILL_CD_POSTAL          ,
  PAR_DO                      ,
  PAR_USCM                    ,
  PAR_USCM_DS                 ,
  PAR_USCM_USCM_DS            ,
  PAR_USCM_REGUSCM            ,
  PAR_USCM_REGUSCM_DS         ,
  PAR_AID                     ,
  PAR_ND                      ,
  PAR_MOB_IMEI                ,
  PAR_MOB_TAC                 ,
  PAR_MOB_SIM                 ,
  PAR_SCORE_NU                ,
  PAR_SCORE_IN                ,
  PAR_TRESHOLD_NU             ,
  CLOSURE_DT                  
)
Select
  TblGen.ACTE_ID                    as ACTE_ID                  ,
  Commande.EXTERNAL_ACTE_ID         as DEMANDE_ID               ,
  Commande.EXTERNAL_INT_ID          as EXTERNAL_INT_ID          ,
  Commande.INT_DEPOSIT_TS           as INT_DEPOSIT_TS           ,
  Commande.INT_DEPOSIT_DT           as INT_DEPOSIT_DT           ,
  Commande.OPERATOR_PROVIDER_ID     as OPERATOR_PROVIDER_ID     ,
  Commande.RESOLU_ID                as RESOLU_ID                ,
  Commande.CONCLU_ID                as CONCLU_ID                ,
  Commande.SSCONCLU_ID              as SSCONCLU_ID              ,
  Commande.TYPE_COMMANDE            as TYPE_COMMANDE            ,
  Commande.PLTF_CO                  as PLTF_CO                  ,
  Commande.INTRNL_SOURCE_ID         as INTRNL_SOURCE_ID         ,
  Commande.CONSEIL_XI_CREA          as CONSEIL_XI_CREA          ,
  Commande.CONSEIL_XI_RESP          as CONSEIL_XI_RESP          ,
  Commande.INT_MODIF_TS             as INT_MODIF_TS             ,
  Commande.IN_CLIDOS                as IN_CLIDOS                ,
  Null                              as TYPE_OT_SO               ,
  Commande.CANALDEM                 as CANALDEM                 ,
  Commande.CLIENT_NU                as CLIENT_NU                ,
  Commande.DOSSIER_NU               as DOSSIER_NU               ,
  Null                              as PRESFACT_CO_PRECED       ,
  Null                              as PRESFACT_CO_OFFRE_OPT_ACQ,
  Null                              as INB_PRESFACT_ACQ_ADV     ,
  Null                              as INB_PRESFACT_ACQ_AGAP    ,
  Null                              as PARC_DT_DEBUT            ,
  Null                              as PARC_DT_FIN              ,
  Null                              as ORDAGD_DT_CONF           ,
  Null                              as CONTRCT_DT_SIGN_PREC     ,
  Null                              as CONTRCT_DT_FIN_PREC      ,
  Null                              as CONTRCT_DT_SIGN_POST     ,
  Null                              as CONTRCT_DUREE_ENG        ,
  Null                              as CONTRCT_UNIT_ENG         ,
  Null                              as EDO_ID                   ,
  Null                              as FLAG_PLT_CONV            ,
  Null                              as FLAG_PLT_SCH             ,
  Null                              as FLAG_TEAM_MKT            ,
  Null                              as FLAG_TYPE_CMP            ,
  Null                              as TYPE_EDO                 ,
  Null                              as EDO_ID_HIER              ,
  Null                              as TYPE_EDO_HIER            ,
  Null                              as ORG_REF_TRAV             ,
  Null                              as ORG_AGENT_ID             ,
  Null                              as ORG_POC_XI               ,
  Null                              as ORG_NOM                  ,
  Null                              as ORG_PRENOM               ,
  Null                              as ORG_GROUPE_ID            ,
  Null                              as ORG_GROUPE_ID_HIER       , 
  Null                              as ORG_ACTVT_REEL           ,
  Null                              as ORG_RESP_REF_TRAV        ,
  Null                              as ORG_RESP_AGENT_ID        ,
  Null                              as ORG_RESP_XI              ,
  Null                              as PAR_LASTNAME             ,
  Null                              as PAR_FIRSTNAME            ,
  Null                              as PAR_TYPE                 ,
  Null                              as PAR_IMSI                 ,
  Null                              as PAR_EMAIL                ,
  Null                              as PAR_BILL_ADRESS_1        ,
  Null                              as PAR_BILL_ADRESS_2        ,
  Null                              as PAR_BILL_ADRESS_3        ,
  Null                              as PAR_BILL_ADRESS_4        ,
  Null                              as PAR_BILL_CD_POSTAL       ,
  Null                              as PAR_DO                   ,
  Null                              as PAR_USCM                 ,
  Null                              as PAR_USCM_DS              ,
  Null                              as PAR_USCM_USCM_DS         ,
  Null                              as PAR_USCM_REGUSCM         ,
  Null                              as PAR_USCM_REGUSCM_DS      ,
  Null                              as PAR_AID                  ,
  Null                              as PAR_ND                   ,
  Null                              as PAR_MOB_IMEI             ,
  Null                              as PAR_MOB_TAC              ,
  Null                              as PAR_MOB_SIM              ,
  Null                              as PAR_SCORE_NU             ,
  Null                              as PAR_SCORE_IN             ,
  Null                              as PAR_TRESHOLD_NU          ,
  Commande.CLOSURE_DT               as CLOSURE_DT               
From
  ${KNB_PCO_TMP}.INT_W_EXRACT_EDL Commande
  Inner Join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN TblGen
    On    Commande.EXTERNAL_ACTE_ID = TblGen.EXTERNAL_ACTE_ID
      And Commande.TYPE_SOURCE_ID   = TblGen.TYPE_SOURCE_ID
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1;
.if errorcode <> 0 then .quit 1
.quit 0

