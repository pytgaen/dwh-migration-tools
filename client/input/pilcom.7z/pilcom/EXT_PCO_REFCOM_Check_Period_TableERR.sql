--$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   EXT_PCO_REFCOM_Check_Period_TableERR.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des tables de manque de période
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     MDE         Création
----------------------------------------------------------------------------------

.set width 5000

Select 
  Trim('$NomFichier')     (title '')  ,
  Trim('$NomTable')       (title '')  ,
  trim(Count(*))          (title '')  
From 
  ${KNB_PCO_REFCOM}.V_$NomTable
Where   PERIODE_ID    = $PeriodeAttendue
  And   CURRENT_IN    = 1
  And   FRESH_IN      = 1
;
.if errorcode <> 0 Then .quit 1

.quit 0
