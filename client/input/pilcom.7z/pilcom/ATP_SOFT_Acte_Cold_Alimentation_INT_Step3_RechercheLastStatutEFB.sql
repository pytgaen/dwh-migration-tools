-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step3_RechercheCommandeEFB.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de calcul du dernier statut EFB
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_LASTSTAT_EFB All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On recherche le dernier statut dans EFB
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_LASTSTAT_EFB
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ORDR_ID_EFB               ,
  ORDER_LAST_STATUT_EFB_CD  ,
  ORDER_LAST_STATUT_EFB_TS
)
Select
  Acte.ACTE_ID                                                                                  As ACTE_ID                    ,
  Acte.ORDER_DEPOSIT_DT                                                                         As ORDER_DEPOSIT_DT           ,
  Acte.ORDR_ID_EFB                                                                              As ORDR_ID_EFB                ,
  RefEFB.COD_STTT_OPRT_COMM                                                                     As ORDER_LAST_STATUT_EFB_CD   ,
  Cast((RefEFB.DAT_STTT_OPRT||' '||Cast(RefEFB.HEUR_STTT_OPRT as char(8))) as timestamp(0))     As ORDER_LAST_STATUT_EFB_TS   
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI Acte
  Inner Join ${KNB_COM_SOC_V_PRS}.VF_ORD_F_ORDR RefEFB
    On    Acte.ORDR_ID_EFB  = RefEFB.ORDR_ID
Where
  (1=1)
  And Acte.ORDR_ID_EFB Is Not Null
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order By Cast((RefEFB.DAT_STTT_OPRT||' '||Cast(RefEFB.HEUR_STTT_OPRT as char(8))) as timestamp(0)) Desc) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_LASTSTAT_EFB;
.if errorcode <> 0 then .quit 1


.quit 0
