--$HEADER: %HEADER%
------------------------------------------------------------------------------------------------------------------------
--                                                                                                                                                             -
-- NOM FICHIER  : $Workfile:   ATP_PCO_CreationTableRepriseSOFT.sql                                                          -
-- TYPE         : Script SQL                                                                                                                   -
-- DESCRIPTION  : Script de création des Tables de reprise SOFT                                           -
--                                                                                                                                                             -
------------------------------------------------------------------------------------------------------------------------
--                HISTORIQUE                                                                                                                   -
--                                                                                                                                                             -
-- DATE           AUTEUR      CREATION/MODIFICATION                                                                                    -
-- 18/11/2019      TCL          Creation
------------------------------------------------------------------------------------------------------------------------

.set width 2000

/*==============================================================*/
/* Table : REP_O_ORDER_AGC_COM                          */
/*==============================================================*/
.LABEL CREATE1
sel 1 from dbc.tablesV where tablename ='REP_O_FACADE_ORDER' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO CREATE2
.if errorcode <> 0 then .quit 1

Create Multiset Table ${KNB_PCO_TMP}.REP_O_FACADE_ORDER(
  EXTERNAL_ORDER_ID VARCHAR(19)   TITLE 'Identifiant FACADE de la commande' NOT NULL,
      ORDER_STATUS_CD VARCHAR(20)      TITLE 'Statut de la commande' NOT NULL,
      STATUS_MODIF_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de modification de la commande' NOT NULL,
      BCR_ID DECIMAL(10,0) FORMAT '---------9' TITLE 'Identifiant BCR référent à la commande',
      ETASK_ORDER_ID VARCHAR(20)      TITLE 'Identifiant ETASK référent à la commande',
      PARSIFAL_ORDER_ID VARCHAR(20)      TITLE 'Identifiant PARSIFAL référent à la commande',
      VAD_ORDER_ID VARCHAR(20)      TITLE 'Identifiant VAD référent à la commande',
      ORDER_DEPOSIT_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de dépôt de la commande' NOT NULL,
      ORDER_VALIDATION_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de validation de la commande',
      ORDER_DELIVERY_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de livraison prévue de la commande',
      AGENT_ID VARCHAR(15)     TITLE 'Code alliance vendeur',
      DISTRBTN_CHANNL_ID CHAR(10)      TITLE 'Canal de vente' COMPRESS ('700       ','B2P       ','BFT       ','BOP       ','CBO       ','CN2       ','CRE       ','CTC       ','DEF       ','DOM       ','DVI       ','FID       ','FIP       ','MPP       ','OCA       ','PAE       ','PAP       ','POD       ','SCC       ','TEL       ','TEP       '),
      STORE_NAME VARCHAR(10)      TITLE 'Point de vente de rattachement Hierarchique Ref REGARD',
      REAL_STORE_NAME VARCHAR(10)      TITLE 'Point de vente ou à réellement eu lieu la commande',
      MOTV_ORDR_ID CHAR(5)      TITLE 'Motif de la commande' COMPRESS ('DCNDU','DEMGT','DNNDU','ORDST'),
      FLAG_ORDER_CREATE_SIMUL CHAR(1)      TITLE 'Indicateur création simultanée' COMPRESS ('0','1'),
      ORDER_TYPE_CD CHAR(40)      TITLE 'Type de la commande' COMPRESS ('CDE_NORMALE                             ','CDE_SANS_ND_INCOMPLETE                  ','CDE_SUR_CDE_EN_COURS                    ','CD_SANS_ND_COMPLETEE                    '),
      ORDER_TYPE_ID CHAR(3)      TITLE 'Type de la commande NBH ou BSS' COMPRESS ('BSS','NBH'),
      CANCEL_MOTV_DS VARCHAR(255)      TITLE 'Motif d annulation de la commande',
      ACTE_OPERTR_ID_COMPST_OFFR CHAR(16)      TITLE 'Opération sur offre composée' COMPRESS ('CREAT           ','DEMGT           ','MIGRA           ','MODIF           '),
      COMPST_OFFR_ID VARCHAR(16)      TITLE 'Référence de l OC',
      COMPST_OFFR_DS VARCHAR(200)      TITLE 'Libellé Référence de l OC',
      PREVIOUS_COMPST_OFFR_ID VARCHAR(16)      TITLE 'Référence de l OC Précédante',
      PREVIOUS_COMPST_OFFR_DS VARCHAR(200)      TITLE 'Libellé Référence de l OC Précédante',
      ACTE_OPERTR_ID_OT CHAR(16)      TITLE 'Opération sur OT Mobile' COMPRESS ('CREAT           ','DEMGT           ','MIGRA           ','MODIF           '),
      OFFRE_TYPE_ID CHAR(5)      TITLE 'Référence de l OT Mobile',
      OFFRE_TYPE_DS VARCHAR(200)      TITLE 'Libellé Référence de l OT Mobile',
      PREVIOUS_OFFRE_TYPE_ID CHAR(5)      TITLE 'Référence de l OT Mobile Précédante' COMPRESS ,
      PREVIOUS_OFFRE_TYPE_DS VARCHAR(200)      TITLE 'Libellé Référence de l OT Mobile Précédante',
      CUSTOMER_CIVILITY CHAR(5)      TITLE 'Civilité du client' COMPRESS ('M.   ','Melle','Mme  '),
      CUSTOMER_LAST_NAME VARCHAR(50)      TITLE 'Nom ou raison sociale du client',
      CUSTOMER_FIRST_NAME VARCHAR(50)      TITLE 'Prénom du client',
      CUSTOMER_MARKET_SEG VARCHAR(20)     TITLE 'segment de marché' COMPRESS ('Residential','Professional','Internal','Company'),
      CUSTOMER_SIRET VARCHAR(30)      TITLE 'Code Siret du client',
      CUSTOMER_BSS_ID VARCHAR(30)      TITLE 'Identifiant Client BSS / AID / PseudoAID',
      CUSTOMER_FGT_ID VARCHAR(30)      TITLE 'Identifiant Client FGT',
      CUSTOMER_ND CHAR(10)      TITLE 'ND du client',
      CUSTOMER_CPT_FAC_FGT VARCHAR(30)      TITLE 'Compte de facturation Fregate',
      CUSTOMER_CLIENT_NU_ADV CHAR(10)      TITLE 'Numéro du Client ADV' COMPRESS ,
      CUSTOMER_DOSSIER_NU_ADV CHAR(10)      TITLE 'Numéro Dossier ADV' COMPRESS ,
      CUSTOMER_BO_ID CHAR(31)      TITLE 'Identifiant BO Du client',
      CUSTOMER_ND_AR CHAR(10)      TITLE 'ND AR Porteur du client',
      INSTALL_ADDRESS_STREET VARCHAR(140)      TITLE 'Voirie adresse Installation ',
      INSTALL_ADDRESS_ZIPCODE VARCHAR(6)      TITLE 'Code postal adresse Installation',
      INSTALL_ADDRESS_CITY VARCHAR(60)      TITLE 'Ville adresse Installation',
      INSTALL_ADDRESS_COUNTRY VARCHAR(50)      TITLE 'Pays adresse Installation',
      INSTALL_REGIONAL_DIRCTN_ID CHAR(2)      TITLE 'DR de l adresse d installation' COMPRESS ('1G','2G','3G','4G','A0','B2','C0','E0','F4','H3','H5','J1','J2','J4','K2','L1','M1','N2','P0','Q2','R0','S0','T1','U1','U2','U3','U6','W4'),
      CONTACT_CIVILITY VARCHAR(30)      TITLE 'civilité de l interlocuteur',
      CONTACT_LAST_NAME VARCHAR(50)      TITLE 'Nom de l interlocuteur ',
      CONTACT_FIRST_NAME VARCHAR(50)      TITLE 'Prénom  de l interlocuteur ',
      CONTACT_MOBILE_NUMBER VARCHAR(10)      TITLE 'Numéro mobile de l interlocuteur ',
      CONTACT_MAIL_ADDRESS VARCHAR(64)      TITLE 'Adresse e-mail de l interlocuteur ',
      CONTACT_ADDRESS_STREET VARCHAR(140)      TITLE 'Voirie de l interlocuteur ',
      CONTACT_ADDRESS_ZIPCODE VARCHAR(6)      TITLE 'Code postal de l interlocuteur ',
      CONTACT_ADDRESS_CITY VARCHAR(60)      TITLE 'Ville de l interlocuteur ',
      CONTACT_ADDRESS_COUNTRY VARCHAR(50)      TITLE 'Pays de l interlocuteur ',
      SHIPMENT_ADDRESS_RELAY_ID CHAR(5)      TITLE 'Point de relai de l adresse d expédition',
      SHIPMENT_ADDRESS_STREET VARCHAR(140)      TITLE 'Voirie adresse d expédition',
      SHIPMENT_ADDRESS_ZIPCODE VARCHAR(6)      TITLE 'Code postal adresse Installation',
      SHIPMENT_ADDRESS_CITY VARCHAR(60)      TITLE 'Ville adresse Installation',
      SHIPMENT_ADDRESS_COUNTRY VARCHAR(50)      TITLE 'Pays adresse Installation',
      NB_LINE_ORDER_INT INTEGER TITLE 'Nombre de lignes de commande Internet',
      NB_LINE_ORDER_MOB INTEGER TITLE 'Nombre de lignes de commande Mobile',
      NB_LINE_ORDER_PCM INTEGER TITLE 'Nombre de lignes de commande PCM',
      BO_AGENT_ID VARCHAR(15)      TITLE 'Code alliance acteur BO ayant repris la commande',
      PARSIFAL_ERROR_CD CHAR(5)      TITLE 'Code erreur en cas d échec Parsifal',
      PARSIFAL_ERROR_DS VARCHAR(250)      TITLE 'Libellé de l erreur en cas d échec Parsifal',
      COMMENT_ETASK VARCHAR(250)      TITLE 'Commentaire ETask du BO',
      COMMENT_SOFT_ORIGINE VARCHAR(20)      TITLE 'Origine du commentaire (SoftCU..) lors de la prise de com',
      COMMENT_SOFT_TYPE VARCHAR(20)      TITLE 'Type de commentaire lors de la prise de com',
      COMMENT_SOFT_FULL_DS VARCHAR(250)      TITLE 'Contenu du commentaire Soft lors de la prise de com',
      COMMENT_SOFT_SUMMARY VARCHAR(50)      TITLE 'Résumé du commentaire lors de la prise de com',
      CODE_ETALEMENT_PAIEMENT VARCHAR(10)      TITLE 'Code SO de l étalement de paiement du terminal placé',
      PARAM_ETALEMENT_PAIEMENT VARCHAR(9)      TITLE 'Param Comptable associé à l etalement paiment - Perform',
      CONTEXT_ID VARCHAR(9)      TITLE 'Id du contxte Ioda/AGC',
      QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
      STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion' NOT NULL,
      ORDER_COMPLETED BYTEINT TITLE 'Indicateur Pour savoir si la commande est complete' NOT NULL
      )
PRIMARY INDEX NUPI_REP_O_FACADE_ORDER ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD ,STATUS_MODIF_TS );
.if errorcode <> 0 then .quit 1;


/*==============================================================*/
/* Table : REP_O_FACADE_ORDER_LINE_INT                          */
/*==============================================================*/
.LABEL CREATE2
sel 1 from dbc.tablesV where tablename ='REP_O_FACADE_ORDER_LINE_INT' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO CREATE3
.if errorcode <> 0 then .quit 1

CREATE MULTISET TABLE ${KNB_PCO_TMP}.REP_O_FACADE_ORDER_LINE_INT
     (
      EXTERNAL_ORDER_ID VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant FACADE de la commande' NOT NULL,
      ORDER_STATUS_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Statut de la commande' NOT NULL,
      STATUS_MODIF_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de modification de la commande' NOT NULL,
      ORDER_DEPOSIT_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de dépôt de la commande' NOT NULL,
      ORDER_LINE_EXTERNAL_ID INTEGER TITLE 'Numéro de séquence FACADE de la ligne de commande',
      EXT_OPER_ID CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Opérateur sur la ligne de commande : ADD/RMV/CHG/INI' COMPRESS ('ADD','CHG','INI','RMV'),
      ATOMIC_OFFR_ID VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code RPS OpenCat de l.Offre Atomique',
      ATOMIC_OFFR_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Libellé OpenCat de l.Offre Atomique',
      FUNCTN_ID VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code RPS OpenCat de la Fonction',
      FUNCTN_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Libellé OpenCat de la Fonction',
      FUNCTN_VALUE_ID VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code RPS de la valeur de fonction Ou Val Simple Enumérée',
      FUNCTN_VALUE_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Libllé de la valeur de fonction Ou Val Simple Enumérée',
      PREVIOUS_FUNCTN_VALUE_ID VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code de la valeur de fonc Ou Val Simple Enum Precédante',
      PREVIOUS_FUNCTN_VALUE_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Libllé de la valeur de fonc Ou Val Simple Enum Precédante',
      QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
      STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion' NOT NULL)
PRIMARY INDEX NUPI_REP_O_FAC_ORDR_LINE_INT ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD ,STATUS_MODIF_TS );
.if errorcode <> 0 then .quit 1;

/*==============================================================*/
/* Table : REP_O_FACADE_ORDER_LINE_MOB                          */
/*==============================================================*/
.LABEL CREATE3
sel 1 from dbc.tablesV where tablename ='REP_O_FACADE_ORDER_LINE_MOB' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO CREATE4
.if errorcode <> 0 then .quit 1

CREATE MULTISET TABLE ${KNB_PCO_TMP}.REP_O_FACADE_ORDER_LINE_MOB
     (
      EXTERNAL_ORDER_ID VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant FACADE de la commande' NOT NULL,
      ORDER_STATUS_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Statut de la commande' NOT NULL,
      STATUS_MODIF_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de modification de la commande' NOT NULL,
      ORDER_DEPOSIT_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de dépôt de la commande' NOT NULL,
      EXT_OPER_ID CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Opérateur sur la ligne de commande' COMPRESS ('NEW       ','OLD       ','UNCHANGE  '),
      SERVICE_OPTIONNEL_ID VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code AGAP Du Service Optionnel',
      SERVICE_OPTIONNEL_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Libellé AGAP Du Service Optionnel',
      QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
      STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion' NOT NULL)
PRIMARY INDEX NUPI_REP_O_FAC_ORDR_LINE_MOB ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD ,STATUS_MODIF_TS );


/*==============================================================*/
/* Table : REP_O_FACADE_ORDER_LINE_PCM                          */
/*==============================================================*/
.LABEL CREATE4
sel 1 from dbc.tablesV where tablename ='REP_O_FACADE_ORDER_LINE_PCM' and databasename='${KNB_PCO_TMP}';
.if activitycount = 1 then .GOTO FIN
.if errorcode <> 0 then .quit 1

CREATE MULTISET TABLE ${KNB_PCO_TMP}.REP_O_FACADE_ORDER_LINE_PCM
     (
      EXTERNAL_ORDER_ID VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Identifiant FACADE de la commande' NOT NULL,
      ORDER_STATUS_CD VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Statut de la commande' NOT NULL,
      STATUS_MODIF_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de modification de la commande' NOT NULL,
      ORDER_DEPOSIT_TS TIMESTAMP(0) FORMAT 'DD/MM/YYYYBHH:MI:SS' TITLE 'Date de dépôt de la commande' NOT NULL,
      TERMINAL_CODE_EAN CHAR(13) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code EAN du terminal Vendu' COMPRESS ,
      TERMINAL_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Libellé du Terminal Vendu',
      TERMINAL_PRICE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Prix Total TTC du terminal',
      NB_POINT_USED VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nombre de point Utilisé',
      DUREE_REENGAGEMENT VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Durée de réengagement',
      OSCAR_SEGEMENT CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Catégorie Oscar du client',
      CODE_DIGIT_TERMINAL_ID VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code Digit du Terminal',
      TYPE_TARIF_ID VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Type de taif commande Perform E/C' COMPRESS ('E','C'),
      IMEI_ID VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code IMEI du Terminal placé',
      PRIX_TTC_PAYE VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Pris TTC Payé en apport initial',
      MONTANT_TTC_SUBVTN VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Montant TTC de la subvention Terminal',
      MODE_REMISE VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Mode de remise',
      NSCESIM VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'id physique de la carte SIM remise',
      CODE_EAN_SIM_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Code EAN de carte SIM',
      CODE_OFFR_VAD_ID VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'code de l offre fictive demandée par VAD Perform',
      LIBELLE_OFFRE_VAD_DS VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'libellé de l’offre fictive demandée par VAD Perform',
      QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' TITLE 'Timestamp d insertion dans le Queue Joram' NOT NULL,
      STREAMING_TS TIMESTAMP(2) TITLE 'Timestamp d insertion' NOT NULL)
PRIMARY INDEX NUPI_REP_O_FAC_ORDR_LINE_PCM ( EXTERNAL_ORDER_ID ,ORDER_STATUS_CD ,STATUS_MODIF_TS );

.LABEL FIN
.if errorcode <> 0 then .quit 1


