--------------------------------------------------------------------------------
-- $HEADER: %HEADER%
-- NOM FICHIER  : $Workfile:   ATP_AGC_MOB_Acte_Cold_CalculHierarchieO3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de creation de la table hierarchie O3 pour AGC MOB.
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 16/04/2014      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_AGCM_C_O3 all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_AGCM_C_O3
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ORG_TEAM_LEVEL_1_CD       ,
  ORG_TEAM_LEVEL_1_DS       ,
  ORG_TEAM_LEVEL_2_CD       ,
  ORG_TEAM_LEVEL_2_DS       ,
  ORG_TEAM_LEVEL_3_CD       ,
  ORG_TEAM_LEVEL_3_DS       ,
  ORG_TEAM_LEVEL_4_CD       ,
  ORG_TEAM_LEVEL_4_DS       
)
Select
  RefIdAuto.ACTE_ID                      as ACTE_ID                   ,
  RefIdAuto.ORDER_DEPOSIT_DT             as ORDER_DEPOSIT_DT          ,
  ORG.ORG_TEAM_LEVEL_1_CD                as ORG_TEAM_LEVEL_1_CD       ,
  ORG.ORG_TEAM_LEVEL_1_DS                as ORG_TEAM_LEVEL_1_DS       ,
  ORG.ORG_TEAM_LEVEL_2_CD                as ORG_TEAM_LEVEL_2_CD       ,
  ORG.ORG_TEAM_LEVEL_2_DS                as ORG_TEAM_LEVEL_2_DS       ,
  ORG.ORG_TEAM_LEVEL_3_CD                as ORG_TEAM_LEVEL_3_CD       ,
  ORG.ORG_TEAM_LEVEL_3_DS                as ORG_TEAM_LEVEL_3_DS       ,
  ORG.ORG_TEAM_LEVEL_4_CD                as ORG_TEAM_LEVEL_4_CD       ,
  ORG.ORG_TEAM_LEVEL_4_DS                as ORG_TEAM_LEVEL_4_DS
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C RefIdAuto
  --On jointe dans l'orga de Travail
  Left Outer Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL ORG
    On    RefIdAuto.EDO_ID                        =   ORG.ORG_TEAM_LEVEL_1_CD
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  ORG.ORG_TEAM_LEVEL_1_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  ORG.ORG_TEAM_LEVEL_1_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  ORG.ORG_TEAM_LEVEL_2_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  ORG.ORG_TEAM_LEVEL_2_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  ORG.ORG_TEAM_LEVEL_3_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  ORG.ORG_TEAM_LEVEL_3_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  ORG.ORG_TEAM_LEVEL_4_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  ORG.ORG_TEAM_LEVEL_4_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition By RefIdAuto.ACTE_ID Order By        ORG.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          ORG.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          ORG.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          ORG.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          ORG.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          ORG.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          ORG.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          ORG.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          ORG.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          ORG.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          ORG.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          ORG.ORG_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if ErrorCode <> 0 Then .Quit 1;

Collect Stat On ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL;
.if ErrorCode <> 0 Then .Quit 1;

