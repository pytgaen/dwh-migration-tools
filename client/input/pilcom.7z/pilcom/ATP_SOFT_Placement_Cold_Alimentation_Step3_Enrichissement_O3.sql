-- $HEADER:   mm2pco/current/sql/ATP_SOFT_Placement_Cold_Alimentation_Step3_Enrichissement_O3.sql 13_05#8 24-NOV-2017 14:51:07 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Cold_Alimentation_Step3_Enrichissement_O3.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de enrichissement de l'organisation O3 pour le placement SOFT 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 08/04/2014      AID         EVOL
-- 28/07/2014      YZH         Modification (ajouts des flags canaux)
-- 28/07/2015      OCH         Modification le cas 'POD' sue FLAG_TYPE_PTN_NTK
-- 13/05/2016      GMA         Modification Axe Canal Pilcom MultiCanal
-- 10/10/2016      JCR         Modification crade du champ OPEN_DT a la demande Denis
-- 31/10/2017      HOB         Modification du Calcul d'axe classifiction OPEN/SOSH
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_O3 all;
.if errorcode <> 0 then .quit 1




Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_O3
(
  EXTERNAL_ORDER_ID               ,
  ORDER_STATUS_CD                 ,
  STATUS_MODIF_TS                 ,
  ORDER_DEPOSIT_DT                ,
  STORE_NAME                      ,
  EDO_ID                          ,
  FLAG_PLT_CONV                   ,
  TYPE_EDO                        ,
  DISTRBTN_CHANNL_ID              ,
  NETWRK_TYP_EDO_ID               ,
  FLAG_TYPE_GEO                   ,
  FLAG_TYPE_CPT_NTK               ,
  FLAG_TYPE_PTN_NTK               ,
  START_VAL_AXS_DT                ,
  END_VAL_AXS_DT                  
)
Select
  RefId.EXTERNAL_ORDER_ID               as EXTERNAL_ORDER_ID    ,
  RefId.ORDER_STATUS_CD                 as ORDER_STATUS_CD      ,
  RefId.STATUS_MODIF_TS                 as STATUS_MODIF_TS      ,
  RefId.ORDER_DEPOSIT_DT                as ORDER_DEPOSIT_DT     ,
  RefId.STORE_NAME                      as STORE_NAME           ,
  RefO3.EDO_ID                          as EDO_ID               ,
  RefO3.FLAG_PLT_CONV                   as FLAG_PLT_CONV        ,
  RefO3.TYPE_EDO                        as TYPE_EDO             ,
  RefId.DISTRBTN_CHANNL_ID              as DISTRBTN_CHANNL_ID   ,
  RefO3.NETWRK_TYP_EDO_ID               as NETWRK_TYP_EDO_ID    ,
  RefO3.FLAG_TYPE_GEO                   as FLAG_TYPE_GEO        ,
  RefO3.FLAG_TYPE_CPT_NTK               as FLAG_TYPE_CPT_NTK    ,
  Case  When RefO3.FLAG_CLSSFF_CONC In ('MOBI')
          Then 'MOB'
        When RefO3.FLAG_CLSSFF_CONC In ('MOBI','PSE','PST')
          Then 'GDT'
        When RefO3.FLAG_CLSSFF_CONC In ('FC')
          Then 'FC'
        When (RefO3.FLAG_CLSSFF_ENT = 'AE' and RefId.DISTRBTN_CHANNL_ID ='POD')
          Then 'DCE'
  End                                  as FLAG_TYPE_PTN_NTK      ,
  RefO3.START_VAL_AXS_DT               as START_VAL_AXS_DT       ,
  Coalesce(RefO3.END_VAL_AXS_DT,Cast('99991231' as Date Format 'YYYYMMDD'))                 as END_VAL_AXS_DT         
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_REFIDCD RefId
  Inner Join
  (
    Select
      RefPdv.EDO_ID                                                                         as EDO_ID               ,
      RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
      RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
      --On détermine si c'est un plateau Interne ou Externe
      Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT' 
              Then  '${P_PIL_235}'
            Else    '${P_PIL_236}'
      End                                                                                   as TYPE_EDO             ,
      --On vérifie si le plateau travail sur du convergent ou pas
      Case  When RefEdoConv.EDO_ID Is Not Null
              Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
            Else    0
      End                                                                                   as FLAG_PLT_CONV        ,
      Coalesce(RefPdv.END_EXTNL_VAL_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
      Coalesce(RefEdo.START_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
      Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT             ,
      RefPdv.ROL_LINK_CD                                                                    as ROL_LINK_CD          ,
      RefEdo.NETWRK_TYP_EDO_ID                                                              as NETWRK_TYP_EDO_ID    ,
      RefEdoDOM.AXS_CLSSF_ID                                                                as FLAG_TYPE_GEO        ,
      RefEdoCompNetwork.AXS_CLSSF_ID                                                        as FLAG_TYPE_CPT_NTK    ,
      RefEdoENT.AXS_CLSSF_ID                                                                as FLAG_CLSSFF_ENT      ,
      RefEdoConcNetwork.AXS_CLSSF_ID                                                        as FLAG_CLSSFF_CONC     ,
      Coalesce( RefEdoConv.START_VAL_AXS_DT,RefEdoDOM.START_VAL_AXS_DT,RefEdoCompNetwork.START_VAL_AXS_DT,RefEdoConcNetwork.START_VAL_AXS_DT,RefEdoENT.START_VAL_AXS_DT) as START_VAL_AXS_DT,
      Coalesce( RefEdoConv.END_VAL_AXS_DT,RefEdoDOM.END_VAL_AXS_DT,RefEdoCompNetwork.END_VAL_AXS_DT,RefEdoConcNetwork.END_VAL_AXS_DT,RefEdoENT.END_VAL_AXS_DT)           as END_VAL_AXS_DT
    From
      ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPdv
      Left Outer Join
      (
      --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
      Select
        EDO_ID                           as EDO_ID            ,
        START_VAL_AXS_DT                 as START_VAL_AXS_DT  ,
        END_VAL_AXS_DT                   as END_VAL_AXS_DT
      From
        ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In (${L_PIL_110})
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
   Qualify Row_number() Over (Partition By EDO_ID Order By Creation_TS DESC)=1
      ) RefEdoConv
      On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
      Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
        On    RefPdv.EDO_ID         = RefEdo.EDO_ID
          And RefEdo.CURRENT_IN     = 1
      --On va dans le referentiel axs_edo pour remonter les flags GEO
      Left Outer Join
      (
        Select
          EDO_ID                           As EDO_ID             ,
          VAL_AXS_CLSSF_ID                 As AXS_CLSSF_ID       ,
          START_VAL_AXS_DT                 As START_VAL_AXS_DT   ,
          END_VAL_AXS_DT                   As END_VAL_AXS_DT
        From
          ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111})
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoDOM
      On  RefPdv.EDO_ID   = RefEdoDOM.EDO_ID         
      --On va dans le referentiel axs_edo pour remonter le flag de réseau compétitif
      Left Outer Join
      (
        Select
         EDO_ID                          As EDO_ID             ,
         VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       ,
         START_VAL_AXS_DT                As START_VAL_AXS_DT   ,
         END_VAL_AXS_DT                  As END_VAL_AXS_DT
        From
          ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112})
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoCompNetwork
      On  RefPdv.EDO_ID   = RefEdoCompNetwork.EDO_ID
    --On va dans le referentiel axs_edo pour remonter le flag de réseau concurrentiel
    Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       ,
          START_VAL_AXS_DT                 As START_VAL_AXS_DT  ,
          END_VAL_AXS_DT                   As END_VAL_AXS_DT
        From
          ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_130}) -- 'MOBI','PSE','PST'
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoConcNetwork
      On  RefPdv.EDO_ID   = RefEdoConcNetwork.EDO_ID
    Left Outer Join
      (
        Select
          EDO_ID                           As EDO_ID             ,
          VAL_AXS_CLSSF_ID                 As AXS_CLSSF_ID       ,
          START_VAL_AXS_DT                 As START_VAL_AXS_DT   ,
          END_VAL_AXS_DT                   As END_VAL_AXS_DT
        From 
          ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_131})
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoENT
      On  RefPdv.EDO_ID   = RefEdoENT.EDO_ID
    Where
      (1=1)
      And RefPdv.EXTNL_COD_CD = '${P_PIL_335}'
  )RefO3
  On    RefId.STORE_NAME        = RefO3.EXTNL_VAL_COD_CD
    And RefId.ORDER_DEPOSIT_DT >= RefO3.START_EXTNL_VAL_DT
    And RefId.ORDER_DEPOSIT_DT < Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
    And RefId.ORDER_DEPOSIT_DT >= RefO3.OPEN_DT
    And RefId.ORDER_DEPOSIT_DT < RefO3.CLOSE_DT
Qualify Row_Number() Over(Partition by  RefId.EXTERNAL_ORDER_ID,
                                        RefId.ORDER_STATUS_CD,
                                        RefId.STATUS_MODIF_TS,
                                        RefId.ORDER_DEPOSIT_DT
                          Order by      RefO3.ROL_LINK_CD Asc,
                                        RefO3.START_EXTNL_VAL_DT Desc,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1
;
.if errorcode <> 0 then .quit 1





Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_O3;
.if errorcode <> 0 then .quit 1



Update RefId
From
  (
    Select
      RefVend.EXTERNAL_ORDER_ID                   as EXTERNAL_ORDER_ID      ,
      RefVend.ORDER_STATUS_CD                     as ORDER_STATUS_CD        ,
      RefVend.STATUS_MODIF_TS                     as STATUS_MODIF_TS        ,
      RefVend.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT       ,
      Case  When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                      OrgWork.WORK_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_2_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_3_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_4_TYPE_EDO ='${P_PIL_236}'
                  )
              Then '${P_PIL_236}'
              Else '${P_PIL_235}'
      End                                         as TYPE_EDO             
    From
      ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_O3 RefVend
      Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL OrgWork
        On    RefVend.EDO_ID                      =   OrgWork.WORK_TEAM_LEVEL_1_CD
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_1_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_1_END_DT
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_2_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_2_END_DT
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_3_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_3_END_DT
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_4_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_4_END_DT
    Qualify Row_Number() Over (Partition by RefVend.EXTERNAL_ORDER_ID,RefVend.ORDER_STATUS_CD,RefVend.STATUS_MODIF_TS,RefVend.ORDER_DEPOSIT_DT 
                               Order by OrgWork.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                        OrgWork.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                        OrgWork.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                        OrgWork.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                        OrgWork.WORK_TEAM_LEVEL_1_START_DT Desc,
                                        OrgWork.WORK_TEAM_LEVEL_2_START_DT Desc,
                                        OrgWork.WORK_TEAM_LEVEL_3_START_DT Desc,
                                        OrgWork.WORK_TEAM_LEVEL_4_START_DT Desc,
                                        OrgWork.WORK_TEAM_LEVEL_1_CD Desc,
                                        OrgWork.WORK_TEAM_LEVEL_2_CD Desc,
                                        OrgWork.WORK_TEAM_LEVEL_3_CD Desc,
                                        OrgWork.WORK_TEAM_LEVEL_4_CD Desc
                              )=1
  )RefEnri,
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_O3 RefId
Set
  TYPE_EDO= RefEnri.TYPE_EDO
Where
  (1=1)
  And RefId.EXTERNAL_ORDER_ID   = RefEnri.EXTERNAL_ORDER_ID
  And RefId.ORDER_STATUS_CD     = RefEnri.ORDER_STATUS_CD
  And RefId.STATUS_MODIF_TS     = RefEnri.STATUS_MODIF_TS
  And RefId.ORDER_DEPOSIT_DT    = RefEnri.ORDER_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1

.quit 0

