-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PER_CalculPerenniteActe_PCM.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de génération des identifiants Internes
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     GMA         Création
-- 06/02/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;


----------------------------------------------------------------------------------------------
-- Etape 1 : On récupère du socle les donnée à traiter                                    ----
----------------------------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.ORD_T_ENRI_ACT_PCM_PER all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_ENRI_ACT_PCM_PER
(
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  STATUT_SAISIE_CAL         ,
  STATUT_VALID_CAL          ,
  STATUT_VALID_BCR          ,
  STATUT_CLOS               ,
  STATUT_TRANSM_BO          ,
  STATUT_ANNUL              
)
Select
  ACTE_ID                   as ACTE_ID          ,
  DATESAISIEBCR             as DATESAISIEBCR    ,
  STATUT_SAISIE_CAL         as STATUT_SAISIE_CAL,
  STATUT_VALID_CAL          as STATUT_VALID_CAL ,
  STATUT_VALID_BCR          as STATUT_VALID_BCR ,
  STATUT_CLOS               as STATUT_CLOS      ,
  STATUT_TRANSM_BO          as STATUT_TRANSM_BO ,
  STATUT_ANNUL              as STATUT_ANNUL     
From
  ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM Placement
Where
  (1=1)
  And Placement.DATESAISIEBCR >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD') 
 --Filtre A supprimer: sert à limiter la profondeur
  And Placement.DATESAISIEBCR>='20080101'

;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ENRI_ACT_PCM_PER;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : On Lance le calcul
----------------------------------------------------------------------------------------------


Delete from ${KNB_PCO_TMP}.ORD_T_CALC_ACT_PCM_PER all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_CALC_ACT_PCM_PER
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  CONFIRMATION_IN           ,
  CONFIRMATION_DT           ,
  CONFIRMATION_CALC_FIN_DT  ,
  DELIVERY_IN               ,
  DELIVERY_DT               ,
  DELIVERY_CALC_FIN_DT      ,
  PERENNITE_IN              ,
  PERENNITE_FIN_DT          ,
  PERENNITE_CALC_FIN_DT     
)
Select
  CalculTmp.ACTE_ID                   as ACTE_ID                  ,
  CalculTmp.ORDER_DEPOSIT_DT          as ORDER_DEPOSIT_DT         ,
  --Calcul de la confirmation
  CalculTmp.CONFIRMATION_IN           as CONFIRMATION_IN          ,
  CalculTmp.CONFIRMATION_DT           as CONFIRMATION_DT          ,
  CalculTmp.CONFIRMATION_CALC_FIN_DT  as CONFIRMATION_CALC_FIN_DT ,
  CalculTmp.DELIVERY_IN               as DELIVERY_IN              ,
  CalculTmp.DELIVERY_DT               as DELIVERY_DT              ,
  CalculTmp.DELIVERY_CALC_FIN_DT      as DELIVERY_CALC_FIN_DT     ,
  CalculTmp.PERENNITE_IN              as PERENNITE_IN             ,
  CalculTmp.PERENNITE_FIN_DT          as PERENNITE_FIN_DT         ,
  CalculTmp.PERENNITE_CALC_FIN_DT     as PERENNITE_CALC_FIN_DT    
From
  (
    Select
      RefId.ACTE_ID                   as ACTE_ID              ,
      RefId.DATESAISIEBCR             as ORDER_DEPOSIT_DT     ,
      -----------------------------------------------------------------------------------------------------
      --Flag de confirmation
      Case  When RefAct.CONFIRMATION_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.CONFIRMATION_IN
            Else  --Dans le cas où le calcul est toujours possible
              Case  When RefId.STATUT_ANNUL is Null --Si la commande n'est pas annulée
                        Then 'O'
                    Else
                          Case  When RefId.STATUT_ANNUL > (RefId.DATESAISIEBCR + ${P_PIL_090})
                                  Then 'O'
                                Else 'N'
                          End
              End
      End                             as CONFIRMATION_IN        ,
      --Date de confirmation
      Case  When RefAct.CONFIRMATION_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.CONFIRMATION_DT
            Else  --Dans le cas où le calcul est toujours possible
              Case  When RefId.STATUT_ANNUL is Null --Si la commande n'est pas annulée
                        Then (RefId.DATESAISIEBCR + 1)
                    Else
                          Case  When RefId.STATUT_ANNUL > (RefId.DATESAISIEBCR + ${P_PIL_090})
                                  Then (RefId.DATESAISIEBCR + 1)
                                Else Null
                          End
              End
      End                             as CONFIRMATION_DT        ,
      --Date de dernier calcul de la confirmation
      Case  When RefAct.CONFIRMATION_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.CONFIRMATION_CALC_FIN_DT
            Else  --Dans le cas où le calcul est toujours possible
                    --Dans le cas où une annulation est trouvée on positionne la date de fin de calcul
              Case  When RefId.STATUT_ANNUL > (RefId.DATESAISIEBCR + ${P_PIL_090})
                      Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                    --Dans le cas où le delais est dépassé on positionne la date de fin de calcul
                    When  Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD') > (RefId.DATESAISIEBCR + ${P_PIL_090})
                      Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                    Else Null
              End
      End                             as CONFIRMATION_CALC_FIN_DT,
      -----------------------------------------------------------------------------------------------------
      --Flag de Livraison
      Case  When RefAct.DELIVERY_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.DELIVERY_IN
            Else  --Dans le cas où le calcul est toujours possible
              Case  When RefId.STATUT_CLOS is Not Null --Si la commande n'est pas annulée
                        Then  'O'
                    Else      'N'
              End
      End                             as DELIVERY_IN            ,
      --Date de confirmation
      Case  When RefAct.DELIVERY_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.DELIVERY_DT
            Else  --Dans le cas où le calcul est toujours possible
              Case  When RefId.STATUT_CLOS is Not Null --Si la commande n'est pas annulée
                        Then  RefId.STATUT_CLOS
                    Else      Null
              End
      End                             as DELIVERY_DT            ,
      --Date de dernier calcul de la confirmation
      Case  When RefAct.DELIVERY_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.DELIVERY_CALC_FIN_DT
            Else  --Dans le cas où le calcul est toujours possible
                    --Dans le cas où La commande est livrée on positionne la date
              Case  When RefId.STATUT_CLOS is Not Null
                      Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                    --Dans le cas où les 200 jours sont passés :
                    When ( RefId.DATESAISIEBCR + ${P_PIL_055} ) <= Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                      Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                    Else Null
              End
      End                             as DELIVERY_CALC_FIN_DT   ,
      -----------------------------------------------------------------------------------------------------
      --Flag de Pérénité
      Case  When RefAct.PERENNITE_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.PERENNITE_IN
            Else  --Dans le cas où le calcul est toujours possible
              Case  When ((RefId.STATUT_ANNUL is Not Null) And (RefId.STATUT_ANNUL >=Coalesce(RefId.STATUT_CLOS,Cast('19000101' as date format 'YYYYMMDD'))))--Si la commande n'est pas annulée
                        Then  'N'
                    Else      'O'
              End
      End                             as PERENNITE_IN            ,
      --Date de confirmation
      Case  When RefAct.PERENNITE_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.PERENNITE_FIN_DT
            Else  --Dans le cas où le calcul est toujours possible
              Case  When ((RefId.STATUT_ANNUL is Not Null) And (RefId.STATUT_ANNUL >=Coalesce(RefId.STATUT_CLOS,Cast('19000101' as date format 'YYYYMMDD')))) --Si la commande n'est pas annulée
                        Then  RefId.STATUT_ANNUL
                    Else      Null
              End
      End                             as PERENNITE_FIN_DT            ,
      --Date de dernier calcul de la confirmation
      Case  When RefAct.PERENNITE_CALC_FIN_DT is not Null --Dans le cas où l'on a arreter le calcul
                Then RefAct.PERENNITE_CALC_FIN_DT
            Else  --Dans le cas où le calcul est toujours possible
                    --Dans le cas où La commande est livrée on positionne la date
              Case  When ((RefId.STATUT_ANNUL is Not Null) And (RefId.STATUT_ANNUL >=Coalesce(RefId.STATUT_CLOS,Cast('19000101' as date format 'YYYYMMDD'))))
                      Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                    --Dans le cas où les 200 jours sont passés :
                    When ( RefId.DATESAISIEBCR + ${P_PIL_055} ) <= Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                      Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                    Else Null
              End
      End                             as PERENNITE_CALC_FIN_DT   
    From
      ${KNB_PCO_TMP}.ORD_T_ENRI_ACT_PCM_PER RefId
      Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM  RefAct
        On    RefId.ACTE_ID           = RefAct.ACTE_ID
          And RefId.DATESAISIEBCR     = RefAct.ORDER_DEPOSIT_DT
  )CalculTmp
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ENRI_ACT_PCM_PER;
.if errorcode <> 0 then .quit 1


