-- $HEADER:   mm2pco/current/sql/ATP_NSH_Placement_Cold_ParcPrecedent.sql 13_05#1 19-FEV-2018 16:58:02 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_ParcPrecedent.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Calcul de la fonctionnalité de recherche en PARC
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/01/2018        HOB         Creation
--------------------------------------------------------------------------------
.set width 2500;
Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_PARCPRE all;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_PARCPRE

(
  ACTE_ID                 ,
  ORDER_DEPOSIT_DT        ,
  PRESFACT_CO_PRECED
)
Select
  RefId.ACTE_ID                             as ACTE_ID                  ,
  RefId.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT         ,
  Prestation.PRESFACT_CO_FORM               as PRESFACT_CO_PRECED
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP   RefId
  Inner Join ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
    On    RefId.PAR_ADV_DOSSIER_NU                 = ParcADV.SRVFCDOS_DOSSIER_NU
      And RefId.PAR_ADV_CLIENT_NU                  = ParcADV.SRVFCDOS_CLIENT_NU
      And RefId.ORDER_DEPOSIT_DT                   >= ParcADV.SRVFCDOS_DT_DEBUT
      And RefId.ORDER_DEPOSIT_DT                   <= coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('99991231' as date format 'YYYYMMDD'))

  Inner Join ${KNB_IBU_SOC}.V_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO    = Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT      = '${P_PIL_065}'
      And Prestation.CURRENT_IN           = 1
Where
  (1=1)
  And RefId.PRESFACT_CO_PRECED Is Null
Qualify Row_Number() Over (Partition By RefId.ACTE_ID
 Order By Coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('99991231' as date format 'YYYYMMDD')) desc, ParcADV.SRVFCDOS_DT_DEBUT desc, ParcADV.CLOSURE_DT asc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1
;


.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_PARCPRE ;
.if errorcode <> 0 then .quit 1

.quit 0