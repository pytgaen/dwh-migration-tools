-- $HEADER: mm2pco/current/sql/ATP_GEN_Alimentation_Ref_Orga_POCC_Step1_Enrichissement_Equi_TRAV.sql 13_05#7 02-NOV-2018 11:39:02 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GEN_Alimentation_Ref_Orga_POCC_Step1_Enrichissement_Equi_TRAV.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 23/04/2014      HZO          Creation
-- 12/04/2016      GMA          Modification des prios
-- 02/11/2018      JCR          Intégration de la derniere date de fin (Cas des EDO fermes)
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_POCC All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_POCC(
  UPPER_ID_FT             ,
  CSLORGA_DT_DEB          ,
  CSLORGA_DT_FIN          ,
  TRAV_ORGA_EQUI_CO_GRP   ,
  EDO_ID_EQUI_TRAV        ,
  FLAG_SCH_EQUI_TRAV      ,
  FLAG_EDO_TRAV           ,
  FLAG_PLT_CONV_TRAV      
)
Select
  Tmp.UPPER_ID_FT               as UPPER_ID_FT            ,
  Tmp.NEW_DATE_DEB              as CSLORGA_DT_DEB         ,
  Tmp.CSLORGA_DT_FIN            as CSLORGA_DT_FIN         ,
  Tmp.TRAV_ORGA_EQUI_CO_GRP     as TRAV_ORGA_EQUI_CO_GRP  ,
  Tmp.EDO_ID_EQUI_TRAV          as EDO_ID_EQUI_TRAV       ,
  Tmp.FLAG_SCH_EQUI_TRAV        as FLAG_SCH_EQUI_TRAV     ,
  Tmp.FLAG_EDO_TRAV             as FLAG_EDO_TRAV          ,
  Tmp.FLAG_PLT_CONV_TRAV        as FLAG_PLT_CONV_TRAV     
From
  (
    Select
      ReqPrio.UPPER_ID_FT                                                                   as UPPER_ID_FT            ,
      ReqPrio.CSLORGA_DT_DEB                                                                as CSLORGA_DT_DEB         ,
      ReqPrio.CSLORGA_DT_FIN                                                                as CSLORGA_DT_FIN         ,
      ReqPrio.OPEN_DT_EDO                                                                   as OPEN_DT_EDO            ,
      ReqPrio.END_DT_EDO                                                                    as END_DT_EDO             ,
      Case  When FLAG_PRIO_NEW = 1
              Then ReqPrio.NEW_DATE_DEB
            Else  ReqPrio.CSLORGA_DT_DEB
      End                                                                                   as NEW_DATE_DEB           ,
      ReqPrio.TRAV_ORGA_EQUI_CO_GRP                                                         as TRAV_ORGA_EQUI_CO_GRP  ,
      ReqPrio.EDO_ID_EQUI_TRAV                                                              as EDO_ID_EQUI_TRAV       ,
      ReqPrio.FLAG_SCH_EQUI_TRAV                                                            as FLAG_SCH_EQUI_TRAV     ,
      ReqPrio.FLAG_EDO_TRAV                                                                 as FLAG_EDO_TRAV          ,
      ReqPrio.FLAG_PLT_CONV_TRAV                                                            as FLAG_PLT_CONV_TRAV     ,
      Case  When FLAG_CONCURR = 1 and ReqPrio.FLAG_PRIO = 2
              Then 1
            Else ReqPrio.FLAG_PRIO
      End                                                                                   as FLAG_PRIO_NEW          ,
      ReqPrio.NEX_TS                                                                        as NEX_TS                 ,
      Case    When Min(ReqPrio.CSLORGA_DT_DEB ) Over  (Partition by    UPPER_ID_FT
                                                          order by    CSLORGA_DT_DEB asc,
                                                                      Coalesce( OPEN_DT_EDO ,Cast( '19000101' AS Date Format 'YYYYMMDD'  ))
                                                        rows Between 1 preceding and 1 preceding
                                                      )  = CSLORGA_DT_DEB
                   And
                   Min(ReqPrio.END_DT_EDO ) Over (Partition by UPPER_ID_FT  
                                                      order by    CSLORGA_DT_DEB asc,
                                                      Coalesce( OPEN_DT_EDO , Cast( '19000101' AS Date Format 'YYYYMMDD'  ))
                                                  rows Between 1 preceding and 1 preceding
                                            )  < OPEN_DT_EDO
                Then 1
              Else 0
      End                                                                                    as FLAG_CONCURR          
    From
        (
          Select
            POC.CUID                                                                                  as UPPER_ID_FT            ,
            POC.DT_DEBUT                                                                              as CSLORGA_DT_DEB         ,
            POC.DT_FIN                                                                                as CSLORGA_DT_FIN         ,
            RefEdo.OPEN_DT                                                                            as OPEN_DT_EDO            ,
            Coalesce( RefEdo.CLOSE_DT , Cast( '99991231' AS Date Format 'YYYYMMDD'  ) )               as END_DT_EDO             ,
            Case  When POC.DT_DEBUT < RefEdo.OPEN_DT And (Coalesce(NEX_TS ,Cast( '99991231' AS Date Format 'YYYYMMDD'  ))> RefEdo.OPEN_DT)
                    Then Cast(RefEdo.OPEN_DT  as timestamp(0)) 
                  Else POC.DT_DEBUT
            End                                                                                       as NEW_DATE_DEB           ,
            POC.TRAV_ORGA_EQUI_CO_GRP                                                                 as TRAV_ORGA_EQUI_CO_GRP  ,
            EDO.EDO_ID                                                                                as EDO_ID_EQUI_TRAV       ,
            Case  When RefEdoAVSC.EDO_ID Is Not Null
                    Then 1
                  Else   0
            End                                                                                       as FLAG_SCH_EQUI_TRAV     ,
            Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                    Then  'INT' --'${P_PIL_235}'
                  Else    'EXT' --'${P_PIL_236}'
            End                                                                                       as FLAG_EDO_TRAV          ,
            Case  --Si on trouve une correspondance alors c'est un plateau convergent
                  When RefEdoConv.EDO_ID Is Not Null
                    Then  1
                  Else    0
            End                                                                                       as FLAG_PLT_CONV_TRAV     ,
            Case
                  When POC.DT_DEBUT <= Coalesce( RefEdo.CLOSE_DT , Cast( '99991231' AS Date Format 'YYYYMMDD'  ) ) And POC.DT_DEBUT >= Coalesce( RefEdo.OPEN_DT , Cast( '19000101' AS Date Format 'YYYYMMDD'  ) )
                    Then 3
                   When POC.DT_DEBUT < RefEdo.OPEN_DT
                    then 2
                  Else 0
            End                                                                                       as FLAG_PRIO              ,
            Case  When POC.DT_DEBUT < RefEdo.OPEN_DT
                    Then 1
                  Else 0
            End                                                                                       as FLAG_CHECK_NEXT        ,
            Max( POC.DT_DEBUT ) Over  (  Partition by  POC.CUID
                                            Order  by  POC.DT_DEBUT asc,
                                                        Coalesce( RefEdo.OPEN_DT , Cast( '19000101' As Date Format 'YYYYMMDD'  ))
                                            rows Between 1 following and 1 following
                                              )                                                       as NEX_TS
          From
            ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_POCC as POC
              Inner Join
              ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO as EDO
              On POC.TRAV_ORGA_EQUI_CO_GRP = EDO.EXTNL_VAL_COD_CD
                  And EDO.CURRENT_IN     = 1
                Left Outer Join 
                  ${KNB_COM_SOC}.V_ORG_F_EDO RefEdo
                  On    EDO.EDO_ID         = RefEdo.EDO_ID
                    And RefEdo.CURRENT_IN     = 1
                    And RefEdo.CLOSURE_DT     Is Null
                      Left Outer Join
                      (
                      --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
                          Select
                            EDO_ID
                          From
                            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
                          Where
                            (1=1)
                            And EdoAx.VAL_AXS_CLSSF_ID  In (${L_PIL_110})
                            And EdoAx.FRESH_IN          = 1
                            And EdoAx.CURRENT_IN        = 1
                            And EdoAx.CLOSURE_DT        Is Null
                          Group By
                            EDO_ID
                      ) RefEdoConv
                      On  RefEdo.EDO_ID   = RefEdoConv.EDO_ID
                          Left Outer Join
                          (
                            --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
                            Select
                              EDO_ID
                            From
                              ${KNB_COM_SOC}.V_ORG_F_AXS_EDO EdoAx
                            Where
                              (1=1)
                              And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113})
                              And EdoAx.FRESH_IN          = 1
                              And EdoAx.CURRENT_IN        = 1
                              And EdoAx.CLOSURE_DT        Is Null
                            Group By
                              EDO_ID
                          ) RefEdoAVSC
                          On  RefEdo.EDO_ID             = RefEdoAVSC.EDO_ID
          Where
            POC.TRAV_ORGA_EQUI_CO_GRP <> 'NR'
        ) as ReqPrio
    )Tmp
Qualify Row_Number() Over ( Partition By Tmp.UPPER_ID_FT, Tmp.NEW_DATE_DEB Order By Tmp.FLAG_PRIO_NEW Desc, Tmp.END_DT_EDO Desc, Tmp.EDO_ID_EQUI_TRAV Asc ) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_POCC;
.if errorcode <> 0 then .quit 1

.quit 0
