-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_Enrichissement_ClientIMEI.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement client IMEI
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/03/2014      MCA         Creation
-- 31/07/2014      MCA         Indus
--------------------------------------------------------------------------------

.set width 2500;

------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_IMEI All ;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_SIM All;
.if errorcode <> 0 then .quit 1
------------------------------------------------------------------


------------------------------------------------------------------
-- On récupère le numéro IMEI du client à partir de TFMOBIL
------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_IMEI
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  PAR_MOB_IMEI              ,
  PAR_MOB_TAC               
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT       ,
  --Récupération du code IMEI + Code TAC du terminal
  Mobile.MOBILE_CO_IMEI                     as PAR_MOB_IMEI           ,
  Mobile.MOBILE_CO_TAC                      as PAR_MOB_TAC            
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP RefId
  Inner Join ${KNB_IBU_SOC}.V_TFMOBILE Mobile
    On    RefId.PAR_ADV_DOSSIER_NU                     =   Mobile.MOBILE_DOSSIER_NU
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Mobile.CREATION_TS desc)=1
------------------------------------------------------------------
-- On récupère le numéro SIM du client à partir de TDDOSSIER
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_SIM
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  PAR_MOB_SIM               ,
  PAR_MOB_IMSI              
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT       ,
  --Récupération du numéro carte sim
  Dossier.DOSSIER_NU_SIM                    as PAR_MOB_SIM            ,
  --Récupération du numéro imsi
  Dossier.DOSSIER_NU_IMSI                   as PAR_MOB_IMSI
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP RefId
  Inner Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
    On    RefId.PAR_ADV_CLIENT_NU                      =   Dossier.DOSSIER_CLIENT_NU
      And RefId.PAR_ADV_DOSSIER_NU                     =   Dossier.DOSSIER_NU
      --On ajout un delais afin de gérer la désynchronisation / Activation
      And (RefId.ORDER_DEPOSIT_DT + interval '${P_PIL_093}' day)  >=  Dossier.DOSSIER_DT_CREAT
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Dossier.DOSSIER_DT_CREAT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_IMEI;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_SIM
;
.if errorcode <> 0 then .quit 1

.quit 0
