--$HEADER:   mm2pco/current/sql/ATP_ADV_Acte_Alimentation_Step1_Extract.sql 13_05#1 05-SEP-2018 10:25:38 GXPZ7694
--------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_ADV_Acte_Alimentation_Step1_Extract.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 01/08/2018      HOB         Creation

--------------------------------------------------------------------------------

.set width 2500;

---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des placements
--et réorganisation pour pouvoir jointer dans la table des catalogues
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.BIL_W_ACTE_ADV_EXT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.BIL_W_ACTE_ADV_EXT
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ORDR_TYP_CD               ,
  EXTRNL_OPSRV_CD           ,
  EXTRNL_OPSRV_DS           ,
  TYPE_PRODUCT              ,
  PERIODE_ID                
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.ORDR_TYP_CD                                           as ORDR_TYP_CD                ,
  Placement.EXTRNL_OPSRV_CD                                       as EXTRNL_OPSRV_CD            ,
  Placement.EXTRNL_OPSRV_DS                                       as EXTRNL_OPSRV_DS            ,
  Null                                                            as TYPE_PRODUCT               ,
  --Période
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )          as PERIODE_ID                 
From
   ${KNB_PCO_SOC}.V_BIL_F_PLACEMENT_ADV Placement
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
Where
  (1=1)
  And  Placement.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_524})
;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.BIL_W_ACTE_ADV_EXT;
.if errorcode <> 0 then .quit 1

.quit 0

