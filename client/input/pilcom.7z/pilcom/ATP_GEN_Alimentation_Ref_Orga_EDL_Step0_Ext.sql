-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_GEN_Alimentation_Ref_Orga_EDL_Step0_Ext.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 10/06/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table de travail                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_EDL All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table de travail                                          ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_EDL(
  SOURCE                    ,
  CUID                      ,
  NOM                       ,
  PRENOM                    ,
  DT_DEBUT                  ,
  DT_FIN                    ,
  RAT_ORGA_EQUI_CO_GRP      ,
  EDO_ID_EQUI_RAT           ,
  FLAG_SCH_EQUI_RAT         ,
  FLAG_HIER_EQUI_RAT        ,
  FLAG_PLT_CONV_EQUI_RAT    ,
  TRAV_ORGA_EQUI_CO_GRP     ,
  EDO_ID_EQUI_TRAV          ,
  FLAG_SCH_EQUI_TRAV        ,
  FLAG_HIER_EQUI_TRAV       ,
  FLAG_PLT_CONV_EQUI_TRAV   
)
Select
  'EDL'                                                                       As SOURCE                           ,
  Trim(Edl.CONSEIL_LB_UTIL)                                                   As CUID                             ,
  Edl.CONSEIL_LB_NOM                                                          As NOM                              ,
  Edl.CONSEIL_LB_PRENOM                                                       As PRENOM                           ,
  Edl.CONSEIL_DT_DEB                                                          As DT_DEBUT                         ,
  Coalesce(Edl.CONSEIL_DT_FIN, Cast('29991231000000' As Timestamp(0) Format 'YYYYMMDDHHMISS'))  As DT_FIN                           ,
  Edl.CONSEIL_ID_GRP                                                          As RAT_ORGA_EQUI_CO_GRP             ,
  Edo.EDO_ID_EQUI_RAT                                                         As EDO_ID_EQUI_RAT                  ,
  Null                                                                        As FLAG_SCH_EQUI_RAT                ,
  Null                                                                        As FLAG_HIER_EQUI_RAT               ,
  Null                                                                        As FLAG_PLT_CONV_EQUI_RAT           ,
  Null                                                                        As TRAV_ORGA_EQUI_CO_GRP            ,
  Edo.EDO_ID_EQUI_RAT                                                         As EDO_ID_EQUI_TRAV                 ,
  Null                                                                        As FLAG_SCH_EQUI_TRAV               ,
  Null                                                                        As FLAG_HIER_EQUI_TRAV              ,
  Null                                                                        As FLAG_PLT_CONV_EQUI_TRAV          
From 
  ${KNB_IBU_SOC_V}.TDCONSEIL Edl
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_OEE_EDL_HRF_LNK_EDO Edo
    On Edo.EDL_CD =  Edl.CONSEIL_ID_GRP
    And Edl.CONSEIL_ID_GRP is not null
    And Edo.CURRENT_IN = 1
Where
  (1=1)
  And (Edl.CONSEIL_DT_FIN is null or Edl.CONSEIL_DT_FIN >= (Current_date - 200)) 
  And Trim(Edl.CONSEIL_LB_UTIL) is not in ('USAGER PURGE','ALOES') 
  And Edl.CONSEIL_ID <> 'NR'
  And Substring(Edl.CONSEIL_ID_GRP From 1 For 1)= 'E'
  And Edo.EDO_ID_EQUI_RAT is not null
Qualify Row_Number() Over (Partition By Edl.CONSEIL_DT_DEB, Edl.CONSEIL_ID_GRP, Trim( Edl.CONSEIL_LB_UTIL) order by  Edo.EDO_ID_EQUI_RAT Desc) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_EDL;
.if errorcode <> 0 then .quit 1

