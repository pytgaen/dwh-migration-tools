-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Hot_Alimentation_Step3_Enrichissement_O3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 11/06/2014      HZO         Modification des RG de calcul de Flags
-- 06/08/2014      HZO         Indus
-- 02/03/2016      TPI         QC 1072 : Modification paramètres
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_O3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_O3
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  CODE_CDR                  ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  ,
  FLAG_TYPE_GEO             ,
  FLAG_TYPE_CPT_NTK         ,
  NETWRK_TYP_EDO_ID         
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT            as ORDER_DEPOSIT_DT     ,
  RefId.CODE_CDR                    as CODE_CDR             ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             ,
  RefO3.FLAG_TYPE_GEO               as FLAG_TYPE_GEO        ,
  RefO3.FLAG_TYPE_CPT_NTK           as FLAG_TYPE_CPT_NTK    ,
  RefO3.NETWRK_TYP_EDO_ID           as NETWRK_TYP_EDO_ID    
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_PL RefId
  Inner Join
    (
      Select
        RefPdv.EDO_ID                                                                         as EDO_ID               ,
        RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
        RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   as TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
              Else    0
        End                                                                                   as FLAG_PLT_CONV        ,
         Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                                                   as FLAG_PLT_SCH         ,
        RefEdoDOM.AXS_CLSSF_ID                                                                as FLAG_TYPE_GEO        ,
        RefEdoCompNetwork.AXS_CLSSF_ID                                                        as FLAG_TYPE_CPT_NTK    ,
        RefEdo.NETWRK_TYP_EDO_ID                                                              as NETWRK_TYP_EDO_ID    ,
        Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     
      From
        ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO RefPdv
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID                      As EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        --On va dans le referentiel axs_edo pour remonter les CARAIBES et REUNION
        Left Outer Join
        (
          Select
            EDO_ID                          As EDO_ID             ,
            VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111}) -- 'CARAIBES','REUNION'
            And EdoAx.FRESH_IN              = 1
            And EdoAx.CURRENT_IN            = 1
            And EdoAx.CLOSURE_DT            Is Null
          Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
        ) RefEdoDOM
        On  RefPdv.EDO_ID   = RefEdoDOM.EDO_ID
        --On va dans le referentiel axs_edo pour remonter les GSS et GSA
        Left Outer Join
        (
          Select
            EDO_ID                          As EDO_ID             ,
            VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112}) -- 'GSS','GSA','AUTRC'
            And EdoAx.FRESH_IN              = 1
            And EdoAx.CURRENT_IN            = 1
            And EdoAx.CLOSURE_DT            Is Null
          Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
        ) RefEdoCompNetwork
        On  RefPdv.EDO_ID   = RefEdoCompNetwork.EDO_ID
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoAVSC
        On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
          --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
        Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
          On    RefPdv.EDO_ID         = RefEdo.EDO_ID
            And RefEdo.CURRENT_IN     = 1
            And RefEdo.CLOSURE_DT     Is Null
      Where
        (1=1)
        And RefPdv.EXTNL_COD_CD = 'CDR'
        And RefPdv.CURRENT_IN   = 1
        And RefPdv.CLOSURE_DT   Is Null
    )RefO3
    On    RefId.CODE_CDR          = RefO3.EXTNL_VAL_COD_CD
      And RefId.ORDER_DEPOSIT_DT  >= RefO3.START_EXTNL_VAL_DT
      And RefId.ORDER_DEPOSIT_DT  <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
Where
  (1=1)
Qualify Row_Number() Over(Partition by
                                        RefId.ACTE_ID,
                                        RefId.ORDER_DEPOSIT_DT
                          Order by      RefO3.START_EXTNL_VAL_DT Desc,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_O3;
.if errorcode <> 0 then .quit 1



Update RefId
From
  (
    Select
      RefVend.ACTE_ID                             as ACTE_ID                ,
      RefVend.ORDER_DEPOSIT_DT                    as ORDER_DEPOSIT_DT       ,
      Case  When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                      OrgWork.WORK_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_2_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_3_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_4_TYPE_EDO ='${P_PIL_236}'
                  )
              Then '${P_PIL_236}'
              Else '${P_PIL_235}'
      End                                         as TYPE_EDO             
    From
      ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_O3 RefVend
      Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL OrgWork
        On    RefVend.EDO_ID                      =   OrgWork.WORK_TEAM_LEVEL_1_CD
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_1_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_1_END_DT
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_2_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_2_END_DT
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_3_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_3_END_DT
          And RefVend.ORDER_DEPOSIT_DT            >=  OrgWork.WORK_TEAM_LEVEL_4_START_DT
          And RefVend.ORDER_DEPOSIT_DT            <=  OrgWork.WORK_TEAM_LEVEL_4_END_DT
    Qualify Row_Number() Over (Partition by RefVend.ACTE_ID Order by  OrgWork.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_CD Desc
                              )=1
  )RefEnri,
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_O3 RefId
Set
  TYPE_EDO= RefEnri.TYPE_EDO
Where
  (1=1)
  And RefId.ACTE_ID             = RefEnri.ACTE_ID
  And RefId.ORDER_DEPOSIT_DT    = RefEnri.ORDER_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1

.quit 0
