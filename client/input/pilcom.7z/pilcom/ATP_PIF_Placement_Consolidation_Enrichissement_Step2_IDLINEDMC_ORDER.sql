--$HEADER:   mm2pco/current/sql/ATP_PIF_Placement_Consolidation_Enrichissement_Step2_IDLINEDMC_ORDER.sql 13_05#10 19-DEC-2017 11:17:16 CLHH1829
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step2_IDLINEDMC_ORDER.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- O7/10/2016      HLA         Creation
-- 05/10/2017      MEL         Ajout de l'alimentation des champs CID/PIF/FIRST 
--------------------------------------------------------------------------------

.set width 2500;


--Purge de la table temporaire avant insertion

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER all;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC Avec SERVICE_ACCESS_ID
----------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER
(
  ACTE_ID                           ,
  ORDER_DEPOSIT_DT                  ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  DMC_LINE_TYPE                     ,
  DMC_ACTIVATION_DT                 ,
  PAR_DEPRTMNT_ID                   ,
  PAR_AID                           ,
  MAIL_ADRESS                       ,
  FIRST_NAME_NM                     ,
  LAST_NAME_NM                      ,
  POSTAL_CD                         ,
  PAR_INSEE_NB                      ,
  PAR_BU_CD                         ,
  PAR_CID_ID                        ,
  PAR_PID_ID                        ,
  PAR_FIRST_IN                      ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             
)
Select
  RefId.ACTE_ID                             As  ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    As  ORDER_DEPOSIT_DT       ,
  LineDmc.LINE_ID                           As  DMC_LINE_ID            ,
  LineDmc.LINE_ID                           As  DMC_MASTER_LINE_ID     ,
  Ldmc.LINE_TYPE                            As  DMC_LINE_TYPE          ,
  LineDmc.ACTIVATION_DT                     As  DMC_ACTIVATION_DT      ,
  Ldmc.DEPRTMNT_ID                          As  PAR_DEPRTMNT_ID        ,
  Ldmc.BSS_PARTY_EXTERNL_ID                 As  PAR_AID                ,
  Ldmc.MAIL_ADRESS                          As  MAIL_ADRESS            ,
  Ldmc.LAST_NAME_NM                         As  LAST_NAME_NM           ,
  Ldmc.FIRST_NAME_NM                        As  FIRST_NAME_NM          ,
  Ldmc.POSTAL_CD                            As  POSTAL_CD              ,
  Ldmc.INSEE_NB                             As  PAR_INSEE_NB           ,
  Geo.BU_CD                                 As  PAR_BU_CD              ,
  LineDmc.CID_ID                            AS  PAR_CID_ID             ,
  LineDmc.PID_ID                            AS  PAR_PID_ID             ,
  LFirst.FIRST_IN                           AS  PAR_FIRST_IN           ,
  Ldmc.UNIFIED_PARTY_ID                     As  PAR_UNIFIED_PARTY_ID   ,
  Ldmc.PARTY_REGRPMNT_ID                    As  PAR_PARTY_REGRPMNT_ID   
  
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 RefId
Inner Join ${KNB_DMU_DMC_VM_V}.PAR_H_AR_VM_ACH LineDmc
 On RefId.SERVICE_ACCESS_ID = LineDmc.SERVICE_ACCESS_ID
    And RefId.ORDER_DEPOSIT_DT          >= LineDmc.START_DT
    And RefId.ORDER_DEPOSIT_DT           < LineDmc.END_DT
    And LineDmc.LINE_TYPE_CD in ('I')
Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
    On LineDmc.LINE_ID = Ldmc.LINE_ID
Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
    On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_H_FIRST_VM  LFirst
    On LineDmc.LINE_ID = LFirst.LINE_ID
    AND LFirst.CREATION_TS   >=  LineDmc.START_DT
    AND LFirst.LAST_MODIF_TS < Coalesce(LineDmc.END_DT, cast( '31129999' as date format 'DDMMYYYY' ))

Where 
  (1=1)
  -- PIF TRANS
  And RefId.DATE_TRANS_TS is not null
  And RefId.DATE_REM_TS  is null
 Qualify  Row_Number() over (Partition by ACTE_ID order by coalesce(LineDmc.business_offer_end_dt,LineDmc.end_dt) desc, coalesce(LineDmc.business_offer_begin_dt,LineDmc.start_dt) desc, LineDmc.line_id desc  ) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 2 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS_ORDER All;
.if errorcode <> 0 then .quit 1
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS_ORDER
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  PAR_IRIS2000_CD           ,
  PAR_GEO_MACROZONE          
)
Select
  RefId.ACTE_ID                                   as ACTE_ID               ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT      ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID           ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD       ,
  LFIBER.RESERV_4                                 as PAR_GEO_MACROZONE     
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER RefId
  Inner Join ${KNB_DMU_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
    on RefId.DMC_LINE_ID = LFIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by LFIBER.LAST_MODIF_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IRIS_ORDER;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 4 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER_ORDER All;
.if errorcode <> 0 then .quit 1
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER_ORDER
(
  ACTE_ID             ,
  ORDER_DEPOSIT_DT    ,
  DMC_LINE_ID         ,
  PAR_FIBER_IN         
)
Select
  RefId.ACTE_ID                                   as ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT     ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID          ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN         
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC_ORDER RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
    on RefId.DMC_LINE_ID = FIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBER_ORDER;
.if errorcode <> 0 then .quit 1

