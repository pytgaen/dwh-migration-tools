--$HEADER:   mm2pco/current/sql/ATP_PVC_Cold_Alim_Step3_Flux_PIF.sql
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PVC_Cold_Alim_Step3_Flux_PIF.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'extraction des actes a traiter
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 23/11/2016     HLA         CREATION
-- 12/03/2020     EVI         PILCOM-221 : Optimisation Traitement PVC
-- 26/03/2020     YAB         PILCOM-284 : ONYX - étape 2 - alimentation du champ code équipe commande
-- 14/04/2020     EVI         PILCOM-420 : KPI2020 - Lot2 - Modification Regle Alimentation CA
---------------------------------------------------------------------------------

.set width 5000

Insert Into ${KNB_PCO_TMP}.ACT_T_PVC_DAY
(
  EXT_DT                        ,
  EXT_SOURCE_ID                 ,
  ACTE_ID                       ,
  ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE              ,
  ACTE_ID_DETAIL_CONTACTE       ,
  ACTE_ID_COMMANDE_REFERENCE    ,
  SOURCE_ID                     ,
  ACTE_STATUT                   ,
  ACTION_ACTE                   ,
  ORDER_DEPOSIT_TS              ,
  ORDER_RECEIVED_PIL_TS         ,
  ORDER_MAJ_PIL_TS              ,
  CUID                          ,
  ORDER_STATUT                  ,
  ORDER_STATUT_TS               ,
  SELLER_LAST_NAME              ,
  SELLER_FIRST_NAME             ,
  SALE_CHANNEL_DLC              ,
  SALE_CHANNEL_ORDER            ,
  CODE_PARC_CLI                 ,
  ORIGINE_DLC_DS                ,
  CUSTOMER_TYPE                 ,
  CUSTOMER_SEG                  ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_SIRET                ,
  MISISDN                       ,
  ND                            ,
  NDIP                          ,
  CUSTOMER_CAT                  ,
  CUSTOMER_AGENCE               ,
  CUSTOMER_ZIPCODE              ,
  VOLUME                        ,
  VALEUR                        ,
  CA                            ,
  STATUT_CSO                    ,
  STATUT_CSO_DS                 ,
  COMMENTAIRE_DS                ,
  TEAM_DLC_DES                  ,
  TEAM_ORDER_DES                ,
  ACT_CD                        ,
  ACT_TYPE_COMMANDE_ID          ,
  TYPE_COMMANDE_INI             ,
  CODE_COMMANDE_FIN             ,
  TYPE_COMMANDE_FIN             ,
  CODE_PRODUCT_FIN              ,
  PRODUCT_DSC_FIN               ,
  SEGMENT_COM_FIN               ,
  CODE_PRODUCT_INI              ,
  PRODUCT_DSC_INI               ,
  SEGMENT_COM_INI               ,
  CODE_MIGR_INI                 ,
  DSC_MIGR_INI                  ,
  CODE_MIGR_FIN                 ,
  DSC_MIGR_FIN                  ,
  ID_FREGATE                    ,
  DT_CHECK_PARC                 ,
  DT_END_PARC                   ,
  END_PARC_DSC                  ,
  TAUX_PERENNITE                ,
  DELAIS_PERENNITE              ,
  OSCAR_VALUE                   ,
  DUREE_ENG                     ,
  IMEI                          ,
  EAN                           ,
  SIM                           ,
  ID_PARSIFAL                   ,
  MOTIF_DLC_DS                  ,
  FLAG_ETAT_GRV                 ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN
)
Select
  '${DateJour}'                                                                                       As EXT_DT                               ,
  '${nomFluxSource}'                                                                                  As EXT_SOURCE_ID                        ,
  ActeUni.ACTE_ID                                                                                     As ACTE_ID                              ,
  ActeSrc.PIF_ORDER_ID                                                                                As ACTE_ID_EXTERNE                      ,
  1                                                                                                   As ACTE_ID_CONTACTE                     ,
  1                                                                                                   As ACTE_ID_DETAIL_CONTACTE              ,
  1                                                                                                   As ACTE_ID_COMMANDE_REFERENCE           ,
  'PIF'                                                                                               As SOURCE_ID                            ,
 Case
        --On controle que le CSO n'a pas modifier la vente -> Si 2 on supprime
        When ActeUni.CHECK_NAT_STATUS_CD in (2) Or ActeUni.CHECK_LOC_STATUS_CD in (2)
          Then  6
       Else     1
  End                                                                                                 AS ACTE_STATUT                          ,
  Null                                                                                                As ACTION_ACTE                          ,
  ActeUni.ACT_TS                                                                                      As ORDER_DEPOSIT_TS                     ,
  Cast(SubString(Cast(ActeSrc.CREATION_TS As Char(22)) From 1 For 19) As Timestamp(0))                As ORDER_RECEIVED_PIL_TS                ,
  Cast(SubString(Cast(ActeUni.LAST_MODIF_TS  As Char(22)) From 1 For 19) As Timestamp(0))             As ORDER_MAJ_PIL_TS                     ,
  ActeUni.AGENT_ID_UPD                                                                                As CUID                                 ,
  Null                                                                                                As ORDER_STATUT                         ,
  Null                                                                                                As ORDER_STATUT_TS                      ,
  TD_SYSFNLIB.Oreplace(ActeUni.AGENT_LAST_NAME, ';', ' ')                                                         As SELLER_LAST_NAME                     ,
  TD_SYSFNLIB.Oreplace(ActeUni.AGENT_FIRST_NAME, ';', ' ')                                                        As SELLER_FIRST_NAME                    ,
  Null                                                                                                As SALE_CHANNEL_DLC                     ,
  Case When ActeUni.ORG_CHANNEL_CD IN ('Distrib','Dist','Distribution') Then 'AD'
       Else ActeUni.ORG_CHANNEL_CD
  End                                                                                                 As SALE_CHANNEL_ORDER                   ,
  ActeUni.CUST_BU_CD                                                                                  As CODE_PARC_CLI                        ,
  ActeUni.ORIGIN_CD                                                                                   As ORIGINE_DLC_DS                       ,
  Null                                                                                                As CUSTOMER_TYPE                        ,
  Null                                                                                                As CUSTOMER_SEG                         ,
  Coalesce(TD_SYSFNLIB.Oreplace(ActeSrc.PAR_LASTNAME, ';', ' '),'IND')                                            As CUSTOMER_LAST_NAME                   ,
  TD_SYSFNLIB.Oreplace(ActeSrc.PAR_FIRSTNAME, ';', ' ')                                                           As CUSTOMER_FIRST_NAME                  ,
  null                                                                                                As CUSTOMER_SIRET                       ,
  ActeUni.MSISDN_ID                                                                                   As MISISDN                              ,
  '0000000000'                                                                                        As ND                                   ,
  NDS_VALUE_DS                                                                                        As NDIP                                 ,
  CASE WHEN TRIM(ActeUni.OSCAR_VALUE) = '-1' THEN NULL
       ELSE ActeUni.OSCAR_VALUE
  END                                                                                                 As CUSTOMER_CAT                         ,
  Null                                                                                                As CUSTOMER_AGENCE                      ,
  ActeUni.POSTAL_CD                                                                                   As CUSTOMER_ZIPCODE                     ,
  1                                                                                                   As VOLUME                               ,
  Null                                                                                                As VALEUR                               ,
  Case When ActeSrc.ACT_UNITE_CD = '${P_PIL_620}'
       Then Null
       Else TRIM(TD_SYSFNLIB.Oreplace(Cast(ActeUni.ACT_CA_LINE_AM As Varchar(100)),'.',','))
  End                                                                                                 As CA                                   ,
  Case When Coalesce(ActeUni.CHECK_LOC_STATUS_CD,ActeUni.CHECK_NAT_STATUS_CD,ActeUni.CHECK_INITIAL_STATUS_CD) IN ('6', '7') THEN NULL
       Else Coalesce(ActeUni.CHECK_LOC_STATUS_CD,ActeUni.CHECK_NAT_STATUS_CD,ActeUni.CHECK_INITIAL_STATUS_CD, '5')
  End                                                                                                 As STATUT_CSO                     ,
  Case When Coalesce(ActeUni.CHECK_LOC_STATUS_CD,ActeUni.CHECK_NAT_STATUS_CD,ActeUni.CHECK_INITIAL_STATUS_CD) IN ('6', '7') THEN NULL
       When Coalesce(ActeUni.CHECK_LOC_STATUS_CD,ActeUni.CHECK_NAT_STATUS_CD,ActeUni.CHECK_INITIAL_STATUS_CD) = '5' THEN 'Valide AUTO'
       When Coalesce(ActeUni.CHECK_LOC_STATUS_CD,ActeUni.CHECK_NAT_STATUS_CD,ActeUni.CHECK_INITIAL_STATUS_CD) = '4' THEN 'Non controlÃ©'
       Else Coalesce(ActeUni.CHECK_LOC_STATUS_LN,ActeUni.CHECK_NAT_STATUS_LN, 'Valide AUTO')
  End                                                                                                 As STATUT_CSO_DS                        ,
  Case When Coalesce(ActeUni.CHECK_LOC_STATUS_CD,ActeUni.CHECK_NAT_STATUS_CD,ActeUni.CHECK_INITIAL_STATUS_CD) IN ('6', '7') THEN NULL
       Else Coalesce(ActeUni.CHECK_LOC_COMMENT,ActeUni.CHECK_NAT_COMMENT)
  End                                                                                                 As COMMENTAIRE_DS                       ,
  Null                                                                                                As TEAM_DLC_DES                         ,
  /* Case When ActeUni.ORG_CHANNEL_CD in ('SCO','CCO','SCH') Then Null
       Else Trim(Both From ActeUni.ORG_EDO_ID )
  End                                                                                                 As TEAM_ORDER_DES                       ,*/
  Trim(Both From ActeUni.ORG_EDO_ID )                                                                 As TEAM_ORDER_DES                       ,
  ActeUni.ACT_REM_ID                                                                                  As ACT_CD                               ,
  ActeUni.ACT_TYPE_COMMANDE_ID                                                                        As ACT_TYPE_COMMANDE_ID                 ,
  Null                                                                                                As TYPE_COMMANDE_INI                    ,
  Null                                                                                                As CODE_COMMANDE_FIN                    ,
  Null                                                                                                As TYPE_COMMANDE_FIN                    ,
  ActeUni.ACT_PRODUCT_ID_FINAL                                                                        As CODE_PRODUCT_FIN                     ,
  LibProduit.PRODUCT_DS                                                                               As PRODUCT_DSC_FIN                      ,
  ActeUni.ACT_SEG_COM_ID_FINAL                                                                        As SEGMENT_COM_FIN                      ,
  ActeUni.ACT_PRODUCT_ID_PRE                                                                          As CODE_PRODUCT_INI                     ,
  LibProduitPre.PRODUCT_DS                                                                            As PRODUCT_DSC_INI                      ,
  ActeUni.ACT_SEG_COM_ID_PRE                                                                          As SEGMENT_COM_INI                      ,
  ActeUni.ACT_CODE_MIGR_PRE                                                                           As CODE_MIGR_INI                        ,
  Null                                                                                                As DSC_MIGR_INI                         ,
  ActeUni.ACT_CODE_MIGR_FINAL                                                                         As CODE_MIGR_FIN                        ,
  Null                                                                                                As DSC_MIGR_FIN                         ,
  ActeUni.EXTERNAL_PARTY_ID                                                                           As ID_FREGATE                           ,
  Null                                                                                                As DT_CHECK_PARC                        ,
  ActeUni.PERENNITE_FIN_DT                                                                            As DT_END_PARC                          ,
  Null                                                                                                As END_PARC_DSC                         ,
  Null                                                                                                As TAUX_PERENNITE                       ,
  Null                                                                                                As DELAIS_PERENNITE                     ,
  CASE WHEN TRIM(ActeUni.OSCAR_VALUE) = '-1' THEN NULL
       ELSE ActeUni.OSCAR_VALUE
  END                                                                                                 As OSCAR_VALUE                          ,
  Null                                                                                                As DUREE_ENG                            ,
  Null                                                                                                As IMEI                                 ,
  Null                                                                                                As EAN                                  ,
  Null                                                                                                As SIM                                  ,
  Null                                                                                                As ID_PARSIFAL                          ,
  Null                                                                                                As MOTIF_DLC_DS                         ,
  Null                                                                                                As FLAG_ETAT_GRV                        ,
  '${KNB_DATE_VACATION}'                                                                              As CREATION_TS                          ,
  '${KNB_DATE_VACATION}'                                                                              As LAST_MODIF_TS                        ,
  1                                                                                                   As FRESH_IN                             ,
  1                                                                                                   As COHERENCE_IN
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ActeUni
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_PIF ActeSrc
    On    ActeUni.ACTE_ID                   = ActeSrc.ACTE_ID
      And ActeUni.ACT_DT                    = ActeSrc.ORDER_DEPOSIT_DT
      And ActeSrc.CLOSURE_DT                Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduit
    On    ActeUni.ACT_PRODUCT_ID_FINAL      = LibProduit.PRODUCT_ID
      And LibProduit.CURRENT_IN             = 1
      And LibProduit.CLOSURE_DT             Is Null
  Left Outer Join ${KNB_PCO_SOC}.V_CAT_R_PRODUCT_LIB LibProduitPre
    On    ActeUni.ACT_PRODUCT_ID_PRE        = LibProduitPre.PRODUCT_ID
      And LibProduitPre.CURRENT_IN          = 1
      And LibProduitPre.CLOSURE_DT          Is Null
  Left Outer Join ${KNB_SOC_O3}.V_ORG_F_EDO   RefEDO
    On    ActeUni.ORG_EDO_ID                = RefEDO.EDO_ID
      And RefEDO.CURRENT_IN                 = 1
      And RefEDO.CLOSURE_DT                 Is Null
Where
  (1=1)
  And ActeUni.ACT_FLAG_PVC_REM       = 'O'
  And (ActeUni.HOT_IN                =  0 or (ActeUni.HOT_IN              = 1 and current_date - cast(ActeUni.creation_ts as date) <= 2) )
  And(ActeUni.ACT_PERIODE_STATUS     = 'O' Or ActeUni.ACT_PERIODE_STATUS is Null )
  And ActeUni.ACT_DT                >= Current_Date - 90
  And ActeUni.INTRNL_SOURCE_ID       = 24 -- Source PIF

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_T_PVC_DAY;
.if errorcode <> 0 Then .quit 1;

