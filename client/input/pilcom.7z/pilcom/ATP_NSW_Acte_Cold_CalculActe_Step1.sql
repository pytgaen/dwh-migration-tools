--$HEADER:   mm2pco/current/sql/ATP_NSW_Acte_Cold_CalculActe_Step1.sql 13_05#2 12-JAN-2017 14:51:47 FDGX6201 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSW_Acte_Cold_CalculActe_Step1.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/11/2015      OCH         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_NSW_CALC all;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------------------------
-- Calcul des cas de sans migrations
------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_NSW_CALC
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  PERIODE_ID                  ,
  PRODUCT_ID_PRE              ,
  SEG_COM_ID_PRE              ,
  SEG_COM_AGG_ID_PRE          ,
  CODE_MIGR_PRE               ,
  PRODUCT_ID_FINAL            ,
  SEG_COM_ID_FINAL            ,
  SEG_COM_AGG_ID_FINAL        ,
  CODE_MIGR_FINAL             ,
  TYPE_SERVICE_FINAL          ,
  TYPE_COMMANDE_ID            ,
  DELTA_TARIF                 
)
Select
  ActeCreation.ACTE_ID                  as ACTE_ID                ,
  ActeCreation.ORDER_DEPOSIT_DT         as ORDER_DEPOSIT_DT       ,
  ActeCreation.PERIODE_ID               as PERIODE_ID             ,
  ActeCreation.PRODUCT_ID_PRE           as PRODUCT_ID_PRE         ,
  Null                                  as SEG_COM_ID_PRE         ,
  Null                                  as SEG_COM_AGG_ID_PRE     ,
  Null                                  as CODE_MIGR_PRE          ,
  ActeCreation.PRODUCT_ID               as PRODUCT_ID_FINAL       ,
  ActeCreation.SEG_COM_ID               as SEG_COM_ID_FINAL       ,
  ActeCreation.SEG_COM_AGG_ID           as SEG_COM_AGG_ID_FINAL   ,
  ActeCreation.CODE_MIGRATION           as CODE_MIGR_FINAL        ,
  ActeCreation.TYPE_SERVICE             as TYPE_SERVICE_FINAL     ,
  ActeCreation.TYPE_COMMANDE            as TYPE_COMMANDE_ID       ,
  Coalesce(ActeCreation.TARIF_HT,0)     as DELTA_TARIF            
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_NSW_EXRACT ActeCreation
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE = 0
Group by
  ActeCreation.ACTE_ID                  ,
  ActeCreation.ORDER_DEPOSIT_DT         ,
  ActeCreation.PERIODE_ID               ,
  ActeCreation.PRODUCT_ID_PRE           ,
  ActeCreation.PRODUCT_ID               ,
  ActeCreation.SEG_COM_ID               ,
  ActeCreation.SEG_COM_AGG_ID           ,
  ActeCreation.CODE_MIGRATION           ,
  ActeCreation.TYPE_SERVICE             ,
  ActeCreation.TYPE_COMMANDE            ,
  Coalesce(ActeCreation.TARIF_HT,0)     
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_NSW_CALC;
.if errorcode <> 0 then .quit 1


.quit 0

