-- $HEADER: mm2pco/current/sql/ATP_PSV_Placement_Step8_Enrichissement_EnrichissementO3.sql 13_05#4 14-JUN-2017 12:38:12 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PSV_Placement_Step5_Enrichissement_O3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissement Canal Macro
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 30/03/2017      HOB         Creation
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP    Calcul Hier                                        ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_HIERO3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_HIERO3 
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  ORG_TEAM_LEVEL_1_CD         ,
  ORG_TEAM_LEVEL_1_DS         ,
  ORG_TEAM_LEVEL_2_CD         ,
  ORG_TEAM_LEVEL_2_DS         ,
  ORG_TEAM_LEVEL_3_CD         ,
  ORG_TEAM_LEVEL_3_DS         ,
  ORG_TEAM_LEVEL_4_CD         ,
  ORG_TEAM_LEVEL_4_DS         ,
  WORK_TEAM_LEVEL_1_CD        ,
  WORK_TEAM_LEVEL_1_DS        ,
  WORK_TEAM_LEVEL_2_CD        ,
  WORK_TEAM_LEVEL_2_DS        ,
  WORK_TEAM_LEVEL_3_CD        ,
  WORK_TEAM_LEVEL_3_DS        ,
  WORK_TEAM_LEVEL_4_CD        ,
  WORK_TEAM_LEVEL_4_DS

)
Select
  PSV.ACTE_ID                               AS ACTE_ID                     ,
  PSV.ORDER_DEPOSIT_DT                      AS ORDER_DEPOSIT_DT            ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As ORG_TEAM_LEVEL_1_CD         ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As ORG_TEAM_LEVEL_1_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As ORG_TEAM_LEVEL_2_CD         ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As ORG_TEAM_LEVEL_2_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As ORG_TEAM_LEVEL_3_CD         ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As ORG_TEAM_LEVEL_3_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As ORG_TEAM_LEVEL_4_CD         ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As ORG_TEAM_LEVEL_4_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As WORK_TEAM_LEVEL_1_CD        ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As WORK_TEAM_LEVEL_1_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As WORK_TEAM_LEVEL_2_CD        ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As WORK_TEAM_LEVEL_2_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As WORK_TEAM_LEVEL_3_CD        ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As WORK_TEAM_LEVEL_3_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As WORK_TEAM_LEVEL_4_CD        ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As WORK_TEAM_LEVEL_4_DS
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_PL   PSV    
  --On jointe dans l'orga Hierarchique
  Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL WLvl1
    On    PSV.EDO_ID                           =    WLvl1.ORG_TEAM_LEVEL_1_CD
      And PSV.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_1_START_DT
      And PSV.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_1_END_DT
      And PSV.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_2_START_DT
      And PSV.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_2_END_DT
      And PSV.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_3_START_DT
      And PSV.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_3_END_DT
      And PSV.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_4_START_DT
      And PSV.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_4_END_DT
 
Where
  (1=1)
  And PSV.ORG_TEAM_LEVEL_1_CD is Null
  And PSV.ORG_TEAM_LEVEL_1_DS is Null

Qualify Row_Number() Over (Partition By PSV.ACTE_ID,PSV.ORDER_DEPOSIT_DT Order By   WLvl1.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_HIERO3;
.if errorcode <> 0 then .quit 1
.quit 0





