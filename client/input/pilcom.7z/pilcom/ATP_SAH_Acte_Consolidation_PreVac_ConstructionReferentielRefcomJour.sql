-- $HEADER: mm2pco/current/sql/ATP_SAH_Acte_Consolidation_PreVac_ConstructionReferentielRefcomJour.sql 13_05#2 08-AOU-2017 10:06:36 FQJR5800
-------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_SAH_Acte_Alimentation_Step2_PreCalcul.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/07/2017      MDE         Creation
--------------------------------------------------------------------------------
.set width 2000;


----------------------------------------------------------
--STEP1 : limitation des periodes
---------------------------------------------------------

Create Volatile Table ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM (
  PERIODE_ID               INTEGER                       Not null           ,
  PERIODE_DATE_DEB         DATE FORMAT 'YYYYMMDD'                           ,
  PERIODE_DATE_FIN         DATE FORMAT 'YYYYMMDD'                           ,
  FRESH_IN                 BYTEINT                                          ,
  CURRENT_IN               BYTEINT                                          ,
  CLOSURE_DT               DATE FORMAT 'YYYYMMDD'
)
Primary Index (PERIODE_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

-- Limitation des periodes sur 6 mois

Insert into ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM
(
  PERIODE_ID                   ,
  PERIODE_DATE_DEB             ,
  PERIODE_DATE_FIN             ,
  FRESH_IN                     ,
  CURRENT_IN                   ,
  CLOSURE_DT
)
Select
  RefPeriod.PERIODE_ID                          As PERIODE_ID             ,
  RefPeriod.PERIODE_DATE_DEB                    As PERIODE_DATE_DEB       ,
  RefPeriod.PERIODE_DATE_FIN                    As PERIODE_DATE_FIN       ,
  RefPeriod.FRESH_IN                            As FRESH_IN               ,
  RefPeriod.CURRENT_IN                          As CURRENT_IN             ,
  RefPeriod.CLOSURE_DT                          As CLOSURE_DT
  From
  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM RefPeriod
  Where
  (1=1)
    And RefPeriod.FRESH_IN                        = 1
    And RefPeriod.CURRENT_IN                      = 1
    And RefPeriod.CLOSURE_DT                      Is Null
    And RefPeriod.PERIODE_ID >=  (  Select
                                      min (MinRefPeriod.PERIODE_ID)
                                    From
                                    ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM MinRefPeriod
                                    Where
                                       (1=1)
                                         And MinRefPeriod.FRESH_IN                        = 1
                                         And MinRefPeriod.CURRENT_IN                      = 1
                                         And MinRefPeriod.CLOSURE_DT                      Is Null
                                         And ( MinRefPeriod.PERIODE_DATE_FIN  >=  add_months(current_date ,-6) And MinRefPeriod.PERIODE_DATE_DEB  <= add_months(current_date ,-6))
                                  )
;
.if errorcode <> 0 then .quit 1
Collect stat On ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM Column (PERIODE_ID);
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------------------------------
--Alimentation de la table Temporaire de la rÃ©organisation
--Du catalogue REFCOM => Pour le MS !
---------------------------------------------------------
Delete From  ${KNB_PCO_TMP}.CAT_W_SAH_REFCOM_JOUR
;Insert into ${KNB_PCO_TMP}.CAT_W_SAH_REFCOM_JOUR
(
  PRODUCT_ID                ,
  TYPE_PRODUIT              ,
  EXT_PRODUCT_ID_1          ,
  EXT_PRODUCT_ID_2          ,
  EXT_PRODUCT_ID_3          ,
  PRODUCT_DS                ,
  PERIODE_ID                ,
  SEG_COM_ID                ,
  SEG_COM_AGG_ID            ,
  TYPE_SERVICE              ,
  TARIF_HT                  ,
  START_COMM_DT             ,
  END_COMM_DT
)
Select
  RefProduit.PRODUCT_ID                                                                     as PRODUCT_ID                 ,
  RefProduit.TYPE_PRODUCT                                                                   as TYPE_PRODUIT               ,
  RefProduit.EXT_PRODUCT_ID_1                                                               as EXT_PRODUCT_ID_1           ,
  RefProduit.EXT_PRODUCT_ID_2                                                               as EXT_PRODUCT_ID_2           ,
  RefProduit.EXT_PRODUCT_ID_4                                                               as EXT_PRODUCT_ID_3           ,
  RefProduit.PRODUIT_DS                                                                     as PRODUCT_DS                 ,
  Coalesce(RefProduit.PERIODE_ID              ,'${P_PIL_049}')                              as PERIODE_ID                 ,
  Coalesce(RefSegCom.SEG_COM_ID               ,'${P_PIL_022}')                              as SEG_COM_ID                 ,
  Coalesce(RefSegType.SEG_COM_AGG_ID          ,'${P_PIL_022}')                              as SEG_COM_AGG_ID             ,
  RefSegCom.TYPE_SERVICE                                                                    as TYPE_SERVICE               ,
  Coalesce(RefProduit.TARIF_HT                ,0)                                           as TARIF_HT                   ,
  RefProduit.DATE_DEBUT                                                                     as START_COMM_DT              ,
  RefProduit.DATE_FIN                                                                       as END_COMM_DT
From
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_SAVI RefProduit
  Inner Join  ${KNB_TERADATA_USER}.CAT_V_PERIODE_COM_PILCOM   RefPeriod
    On      RefPeriod.PERIODE_ID            = RefProduit.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
      On    RefProduit.PRODUCT_ID           = RefSegCom.PRODUCT_ID
        And RefProduit.PERIODE_ID           = RefSegCom.PERIODE_ID
        And RefSegCom.CURRENT_IN            = 1
        And RefSegCom.CLOSURE_DT            is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSegType
    On    RefSegCom.SEG_COM_ID              = RefSegType.SEG_COM_ID
      And RefSegCom.PERIODE_ID              = RefSegType.PERIODE_ID
      And RefSegType.FRESH_IN               = 1
      And RefSegType.CURRENT_IN             = 1
      And RefSegType.CLOSURE_DT             is null
 
Where
  (1=1)
  And RefProduit.CURRENT_IN                 =1
  And RefProduit.CLOSURE_DT                 is null
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.CAT_W_SAH_REFCOM_JOUR;
.if errorcode <> 0 then .quit 1



.quit 0


