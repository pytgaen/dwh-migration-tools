-- $HEADER: mm2pco/current/sql/ATP_ETASK_Acte_Cold_Alimentation_INT_Step3_RechercheTracageAutomatique.sql 13_05#7 25-AOU-2016 09:48:32 FQJR5800
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ETASk_Acte_Cold_Alimentation_INT_Step3_RechercheTracageAutomatique.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 10/02/2015      MDE         Creation
-- 27/10/2015      MDE         Evol: tracage Ref 32R
-- 19/02/2016      MDE         Evol: ajout filtre  (ORDER_DEPOSIT_DT >=  '20160101')
-- 27/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
--------------------------------------------------------------------------------


.set width 2000;

--SOFT INT

Delete From ${KNB_PCO_TMP}.ORD_W_ACT_ETASK_INT_C_TRC_AUTO All;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_ACT_ETASK_INT_C_TRC_AUTO
(
  ACTE_ID                                        ,
  ORDER_DEPOSIT_DT                               ,
  AGENT_ID                                       ,
  EDO_ID                                         ,
  FLAG_PLT_CONV_NB                               ,
  TYPE_EDO_ID                                    ,
  NETWRK_TYP_EDO_ID                              ,
  FLAG_TYPE_GEO_CD                               ,
  FLAG_TYPE_CPT_NTK_NU                           ,
  FLAG_TYPE_PTN_NTK_NU                           ,
  ORG_LAST_NAME_NM                               ,
  ORG_FIRST_NAME_NM                              ,
  ORG_CANAL_ID                                   ,
  ORG_CHANEL_CD                                  ,
  ORG_SUB_CHANEL_CD                              ,
  ORG_SUB_SUB_CHANEL_CD                          ,
  ORG_REM_CHANEL_CD                              ,
  ORG_GT_ACTIVITY                                ,
  ORG_FIDELISATION                               ,
  ORG_WEB_ACTIVITY                               ,
  ORG_AUTO_ACTIVITY                              ,
  ORG_TEAM_LEVEL_1_CD                            ,
  ORG_TEAM_LEVEL_1_DS                            ,
  ORG_TEAM_LEVEL_2_CD                            ,
  ORG_TEAM_LEVEL_2_DS                            ,
  ORG_TEAM_LEVEL_3_CD                            ,
  ORG_TEAM_LEVEL_3_DS                            ,
  ORG_TEAM_LEVEL_4_CD                            ,
  ORG_TEAM_LEVEL_4_DS                            ,
  WORK_TEAM_LEVEL_1_CD                           ,
  WORK_TEAM_LEVEL_1_DS                           ,
  WORK_TEAM_LEVEL_2_CD                           ,
  WORK_TEAM_LEVEL_2_DS                           ,
  WORK_TEAM_LEVEL_3_CD                           ,
  WORK_TEAM_LEVEL_3_DS                           ,
  WORK_TEAM_LEVEL_4_CD                           ,
  WORK_TEAM_LEVEL_4_DS                           ,
  STORE_NM                                       ,
  JOB_ID                                         ,
  EXT_APPLI_ID                                   ,
  FLAG_TEAM_MKT_NB                               ,
  FLAG_TYPE_CMP_NU                               ,
  ORDR_ID                                        ,
  ORDR_ORGN_DS                                   ,
  DEPARTMNT_ID                                   ,
  BU_CD                                          ,
  POSTAL_CD                                      ,
  INSEE_CD                                       ,
  PAR_IRIS2000_CD                                ,
  PAR_FIBER_IN                                   

)
Select
  Acte.ACTE_ID                                   as  ACTE_ID                                        ,
  Acte.ORDER_DEPOSIT_DT                          as  ORDER_DEPOSIT_DT                               ,
  Etask.AGENT_ID                                 as  AGENT_ID                                       ,
  Etask.EDO_ID                                   as  EDO_ID                                         ,
  Etask.FLAG_PLT_CONV_NB                         as  FLAG_PLT_CONV_NB                               ,
  Etask.TYPE_EDO_ID                              as  TYPE_EDO_ID                                    ,
  Etask.NETWRK_TYP_EDO_ID                        as  NETWRK_TYP_EDO_ID                              ,
  Etask.FLAG_TYPE_GEO_CD                         as  FLAG_TYPE_GEO_CD                               ,
  Etask.FLAG_TYPE_CPT_NTK_NU                     as  FLAG_TYPE_CPT_NTK_NU                           ,
  Etask.FLAG_TYPE_PTN_NTK_NU                     as  FLAG_TYPE_PTN_NTK_NU                           ,
  Etask.ORG_LAST_NAME_NM                         as  ORG_LAST_NAME_NM                               ,
  Etask.ORG_FIRST_NAME_NM                        as  ORG_FIRST_NAME_NM                              ,
  Etask.ORG_CANAL_ID                             as  ORG_CANAL_ID                                   ,
  Etask.ORG_CHANEL_CD                            as  ORG_CHANEL_CD                                  ,
  Etask.ORG_SUB_CHANEL_CD                        as  ORG_SUB_CHANEL_CD                              ,
  Etask.ORG_SUB_SUB_CHANEL_CD                    as  ORG_SUB_SUB_CHANEL_CD                          ,
  Etask.ORG_REM_CHANEL_CD                        as  ORG_REM_CHANEL_CD                              ,
  Etask.ORG_GT_ACTIVITY                          as  ORG_GT_ACTIVITY                                ,
  Etask.ORG_FIDELISATION                         as  ORG_FIDELISATION                               ,
  Etask.ORG_WEB_ACTIVITY                         as  ORG_WEB_ACTIVITY                               ,
  Etask.ORG_AUTO_ACTIVITY                        as  ORG_AUTO_ACTIVITY                              ,
  Etask.ORG_TEAM_LEVEL_1_CD                      as  ORG_TEAM_LEVEL_1_CD                            ,
  Etask.ORG_TEAM_LEVEL_1_DS                      as  ORG_TEAM_LEVEL_1_DS                            ,
  Etask.ORG_TEAM_LEVEL_2_CD                      as  ORG_TEAM_LEVEL_2_CD                            ,
  Etask.ORG_TEAM_LEVEL_2_DS                      as  ORG_TEAM_LEVEL_2_DS                            ,
  Etask.ORG_TEAM_LEVEL_3_CD                      as  ORG_TEAM_LEVEL_3_CD                            ,
  Etask.ORG_TEAM_LEVEL_3_DS                      as  ORG_TEAM_LEVEL_3_DS                            ,
  Etask.ORG_TEAM_LEVEL_4_CD                      as  ORG_TEAM_LEVEL_4_CD                            ,
  Etask.ORG_TEAM_LEVEL_4_DS                      as  ORG_TEAM_LEVEL_4_DS                            ,
  Etask.WORK_TEAM_LEVEL_1_CD                     as  WORK_TEAM_LEVEL_1_CD                           ,
  Etask.WORK_TEAM_LEVEL_1_DS                     as  WORK_TEAM_LEVEL_1_DS                           ,
  Etask.WORK_TEAM_LEVEL_2_CD                     as  WORK_TEAM_LEVEL_2_CD                           ,
  Etask.WORK_TEAM_LEVEL_2_DS                     as  WORK_TEAM_LEVEL_2_DS                           ,
  Etask.WORK_TEAM_LEVEL_3_CD                     as  WORK_TEAM_LEVEL_3_CD                           ,
  Etask.WORK_TEAM_LEVEL_3_DS                     as  WORK_TEAM_LEVEL_3_DS                           ,
  Etask.WORK_TEAM_LEVEL_4_CD                     as  WORK_TEAM_LEVEL_4_CD                           ,
  Etask.WORK_TEAM_LEVEL_4_DS                     as  WORK_TEAM_LEVEL_4_DS                           ,
  Etask.STORE_NM                                 as  STORE_NM                                       ,
  Etask.JOB_ID                                   as  JOB_ID                                         ,
  Etask.EXT_APPLI_ID                             as  EXT_APPLI_ID                                   ,
  Etask.FLAG_TEAM_MKT_NB                         as  FLAG_TEAM_MKT_NB                               ,
  Etask.FLAG_TYPE_CMP_NU                         as  FLAG_TYPE_CMP_NU                               ,
  Etask.ORDR_ID                                  as  ORDR_ID                                        ,
  Etask.ORDR_ORGN_DS                             as  ORDR_ORGN_DS                                   ,
  Etask.DEPARTMNT_ID                             as  DEPARTMNT_ID                                   ,
  Etask.BU_CD                                    as  BU_CD                                          ,
  Etask.POSTAL_CD                                as  POSTAL_CD                                      ,
  Etask.INSEE_CD                                 as  INSEE_CD                                       ,
  Etask.PAR_IRIS2000_CD                          as  PAR_IRIS2000_CD                                ,
  Etask.PAR_FIBER_IN                             as  PAR_FIBER_IN                                   
From
  --Pannel des Actes Ã  rechercher
 ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI Acte
  Inner Join ${KNB_PCO_SOC}.V_ORD_F_REF_32R Etask
    On  Acte.PARSIFAL_ORDER_ID    = Etask.EXTERNAL_ORDER_ID
  Inner Join ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_INT RefSoft
    On    Acte.ACTE_ID          = RefSoft.ACTE_ID
    And Acte.ORDER_DEPOSIT_DT = RefSoft.ORDER_DEPOSIT_DT
Where
  (1=1)
  And  Etask.FLAG_TRC_IN=1
  And Etask.ORG_CANAL_ID Is Not Null 
  And 
      (
        Coalesce(RefSoft.DISTRBTN_CHANNL_ID,'#')  in ('CBO','CN2')
        or
           ( Coalesce(RefSoft.DISTRBTN_CHANNL_ID,'#') in ('SCC') And Coalesce(etask.ORG_CHANEL_CD,'#') in ('Online'))
      )
  And Coalesce(RefSoft.AGENT_ID,'#')             Not in ('TVEP0000')
  And Acte.ORDER_DEPOSIT_DT  >= '${P_PIL_516}'
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order By Etask.ORDER_DEPOSIT_TS  Desc) = 1
;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.ORD_W_ACT_ETASK_INT_C_TRC_AUTO;
.if errorcode <> 0 then .quit 1


.quit 0


