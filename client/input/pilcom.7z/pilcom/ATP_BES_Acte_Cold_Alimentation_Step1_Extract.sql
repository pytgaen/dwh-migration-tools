-- $HEADER: mm2pco/current/sql/ATP_BES_Acte_Cold_Alimentation_Step1_Extract.sql 13_05#6 22-AOU-2017 10:47:04 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Acte_Cold_Alimentation_Step1_Extract.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/03/2014      HZO         Creation
-- 07/04/2016      MDE         Evol  : profondeur calcul 100 jrs
-- 17/07/2017      HOB         Modif TERMINAUX Nus
-- 22/09/2021      EVI         PILCOM-792 : Gestion Retour/Annulation DSTAR
--------------------------------------------------------------------------------

.set width 2500;

---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des placements
--et réorganisation pour pouvoir jointer dans la table des catalogues
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_BESTAR_C_EXT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_BESTAR_C_EXT
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  TYPE_PRODUCT              ,
  EXT_OPER_ID               ,
  CODE_EAN                  ,
  NUM_LIGNE                 ,
  EDO_ID                    ,
  TERMINAL_DS               ,
  TERMINAL_PRICE            ,
  TERMINAL_PRICE_HT         ,
  PERIODE_ID                ,
  MSISDN_ID                 ,
  IMEI_CD                   ,
  PAR_ND                    ,
  ID_PANIER                
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Null                                                            as TYPE_PRODUCT               ,
  --Reformatage des champs de mouvements
  'ACQ'                                                           as EXT_OPER_ID                ,
  --Code EAN
  Placement.CODE_EAN                                              as CODE_EAN                   ,
  Placement.NUM_LIGNE                                             as NUM_LIGNE                    ,

  Placement.EDO_ID                                                as EDO_ID                     ,
  --Lib Terminal
  Null                                                            as TERMINAL_DS                ,
  --Prix
  Placement.CA_LINE                                               as TERMINAL_PRICE             ,
  Placement.CA_LINE - Placement.TVA_LINE_NU                       as TERMINAL_PRICE_HT          ,
  --Période
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )          as PERIODE_ID                 ,
  Placement.MSISDN_NU                                             as MSISDN_ID                  ,
  Placement.PAR_MOB_IMEI                                          as IMEI_CD                     ,
  Placement.PAR_ND                                                as PAR_ND                      ,
  Placement.ID_PANIER                                             as ID_PANIER                    
From
   ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_BESTAR Placement
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
Where
  (1=1)
  And  Placement.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_524})
  And  Placement.TYPE_VENTE = 'VENTE'

;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_BESTAR_C_EXT;
.if errorcode <> 0 then .quit 1

.quit 0

