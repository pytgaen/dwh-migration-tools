-- $HEADER: mm2pco/current/sql/ATP_GEN_Alimentation_Ref_Orga_ETASK_AD_Step2.sql 13_05#3 25-AOU-2016 09:48:36 FQJR5800
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GEN_Alimentation_Ref_Orga_ETASK_AD_Step2.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  Ref O3 AD 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/04/2015      MDE         Creation
-- 02/03/2016      TPI         QC 1072 : Modification paramètres
-- 13/04/2016      MDE         Modif ACTIVITY 
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORG_T_AGENT_LNK_AD_EDO All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORG_T_AGENT_LNK_AD_EDO  
(
  SOURCE                  ,
  CUID                    ,
  DT_DEBUT                ,
  DT_FIN                  ,
  EDO_ID                  ,
  TYPE_EDO                ,
  DISTRBTN_CHANNL_ID      ,
  STORE_NM                ,
  ACTIVITY                ,
  FLAG_PLT_CONV_NB        ,
  FLAG_TYPE_GEO_CD        ,
  FLAG_TYPE_CPT_NTK_NU    ,
  NETWRK_TYP_EDO_ID       ,
  CREATION_TS             ,
  LAST_MODIF_TS           ,
  FRESH_IN                ,
  COHERENCE_IN

)

Select
  SOURCE                                                      As SOURCE           ,
  RFOREdoMerged.CUID                                          As CUID             ,
  RFOREdoMerged.DT_DEBUT,
  Coalesce( Max((RFOREdoMerged.DT_DEBUT - Interval '1' second )) Over (
                                                Partition by RFOREdoMerged.CUID
                                                   Order by RFOREdoMerged.DT_DEBUT rows between 1  following and 1 following
                                              )
                                              , Cast('29991231000000' As Timestamp(0) Format 'YYYYMMDDHHMISS')   )
                                                             As DT_FIN                    ,
  RFOREdoMerged.EDO_ID                                       As EDO_ID                    ,
  RFOREdoMerged.TYPE_EDO                                     As TYPE_EDO                  ,
  RFOREdoMerged.DISTRBTN_CHANNL_ID                           AS DISTRBTN_CHANNL_ID        , 
  RFOREdoMerged.STORE_NAME                                   As STORE_NM                  ,
  RFOREdoMerged.ACTIVITY                                     As ACTIVITY                  ,
  RFOREdoMerged.FLAG_PLT_CONV                                As FLAG_PLT_CONV_NB          ,
  RFOREdoMerged.FLAG_TYPE_GEO                                As FLAG_TYPE_GEO_CD          ,
  RFOREdoMerged.FLAG_TYPE_CPT_NTK                            As FLAG_TYPE_CPT_NTK_NU      ,
  RFOREdoMerged.NETWRK_TYP_EDO_ID                            As NETWRK_TYP_EDO_ID         ,
  '${KNB_DATE_VACATION}'                                     As CREATION_TS               ,
  '${KNB_DATE_VACATION}'                                     As LAST_MODIF_TS             ,
  1                                                          As FRESH_IN                  ,
  1                                                          As COHERENCE_IN

from (
Select 
  SOURCE                                                     As SOURCE            ,
  SOFTIEdo.CUID                                              As CUID              ,
  SOFTIEdo.DT_DEBUT                                          As DT_DEBUT          ,
  SOFTIEdo.DT_FIN                                            As DT_FIN            ,
  SOFTIEdo.EDO_ID                                            As EDO_ID            ,
  SOFTIEdo.FLAG_PLT_CONV                                     As FLAG_PLT_CONV     ,
  SOFTIEdo.TYPE_EDO                                          As TYPE_EDO          ,
  SOFTIEdo.FLAG_TYPE_GEO                                     As FLAG_TYPE_GEO     ,
  SOFTIEdo.FLAG_TYPE_CPT_NTK                                 As FLAG_TYPE_CPT_NTK ,
  SOFTIEdo.DISTRBTN_CHANNL_ID                                AS DISTRBTN_CHANNL_ID,
  SOFTIEdo.STORE_NAME                                        AS STORE_NAME        ,
  case when SOFTIEdo.DISTRBTN_CHANNL_ID = 'PAP'   
          THEN   'Porte a porte'
      when SOFTIEdo.DISTRBTN_CHANNL_ID  = 'POD'
          THEN 'Reseau Concurrent'
      when SOFTIEdo.DISTRBTN_CHANNL_ID = 'OCA' and SOFTIEdo.STORE_NAME   like '%MOB%'
          THEN 'Mobistore'
      when SOFTIEdo.DISTRBTN_CHANNL_ID = 'OCA' and SOFTIEdo.STORE_NAME   like '%PHS%'
          THEN 'GDT'
      when SOFTIEdo.DISTRBTN_CHANNL_ID = 'CRE' and SOFTIEdo.STORE_NAME   like '%MOB%'
          THEN 'Mobistore'
      when SOFTIEdo.DISTRBTN_CHANNL_ID = 'CRE' and SOFTIEdo.STORE_NAME   like '%PHS%'
          THEN 'GDT'
      when SOFTIEdo.DISTRBTN_CHANNL_ID = 'BFT' 
          THEN 'Boutique FT'
    
 END                                                       AS ACTIVITY              ,
  
  SOFTIEdo.NETWRK_TYP_EDO_ID                               As NETWRK_TYP_EDO_ID,
  Case  When max(SOFTIEdo.EDO_ID) Over (Partition by SOFTIEdo.CUID
                                                    Order by SOFTIEdo.DT_DEBUT rows between 1 preceding  and 1 preceding
                                      ) = SOFTIEdo.EDO_ID

                Then 1
              Else 0
  End                                                      As TO_BE_MERGED
from 
(
    Select
      'SOFTI'                                                                    AS SOURCE                ,
      SOFT.AGENT_ID                                                              AS CUID                  ,
      SOFT.ORDER_DEPOSIT_TS                                                      AS DT_DEBUT              ,
      Cast('29991231000000' As Timestamp(0) Format 'YYYYMMDDHHMISS')             AS DT_FIN                ,
      SOFT.STORE_NAME                                                            AS STORE_NAME            ,
      SOFT.DISTRBTN_CHANNL_ID                                                    AS DISTRBTN_CHANNL_ID    ,
      RefO3.EDO_ID                                                               AS EDO_ID                ,
      RefO3.FLAG_PLT_CONV                                                        AS FLAG_PLT_CONV         ,
      RefO3.TYPE_EDO                                                             AS TYPE_EDO              ,
      RefO3.FLAG_TYPE_GEO                                                        AS FLAG_TYPE_GEO         ,
      RefO3.FLAG_TYPE_CPT_NTK                                                    AS FLAG_TYPE_CPT_NTK     ,
      RefO3.NETWRK_TYP_EDO_ID                                                    AS NETWRK_TYP_EDO_ID
From
${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM as SOFT
Inner Join
  (
    Select
      RefPdv.EDO_ID                                                                         as EDO_ID               ,
      RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
      RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
      --On détermine si c'est un plateau Interne ou Externe
      Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
              Then  'INT'
            Else    'EXT'
      End                                                                                   as TYPE_EDO             ,
      --On vérifie si le plateau travail sur du convergent ou pas
      Case  When RefEdoConv.EDO_ID Is Not Null
              Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
            Else    0
      End                                                                                   as FLAG_PLT_CONV        ,
      Coalesce(RefPdv.END_EXTNL_VAL_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
      Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
      Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT             ,
      RefPdv.ROL_LINK_CD                                                                    as ROL_LINK_CD          ,
      RefEdo.NETWRK_TYP_EDO_ID                                                              as NETWRK_TYP_EDO_ID    ,
      RefEdoDOM.AXS_CLSSF_ID                                                                as FLAG_TYPE_GEO        ,
      RefEdoCompNetwork.AXS_CLSSF_ID                                                        as FLAG_TYPE_CPT_NTK
    From
      ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPdv
      Left Outer Join
      (
        Select
          EDO_ID
        From
          ${KNB_COM_SOC}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID
            in ('SOSH','OPEN')
          And EdoAx.FRESH_IN          = 1
          And EdoAx.CURRENT_IN        = 1
          And EdoAx.CLOSURE_DT        Is Null
        Group By
          EDO_ID
      ) RefEdoConv
      On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
      Inner Join ${KNB_COM_SOC}.V_ORG_F_EDO RefEdo
        On    RefPdv.EDO_ID         = RefEdo.EDO_ID
          And RefEdo.CURRENT_IN     = 1
      --On va dans le referentiel axs_edo pour remonter les flags GEO
      Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
        From
          ${KNB_COM_SOC}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111}) -- 'CARAIBES','REUNION'
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoDOM
      On  RefPdv.EDO_ID   = RefEdoDOM.EDO_ID
      --On va dans le referentiel axs_edo pour remonter le flag de réseau compétitif
      Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
        From
          ${KNB_COM_SOC}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112}) -- 'GSS','GSA','AUTRC'
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
) RefEdoCompNetwork
      On  RefPdv.EDO_ID   = RefEdoCompNetwork.EDO_ID
    Where
      (1=1)
      And RefPdv.EXTNL_COD_CD = 'ADV'
  )RefO3
On    SOFT.STORE_NAME        = RefO3.EXTNL_VAL_COD_CD
    And SOFT.ORDER_DEPOSIT_DT >= RefO3.START_EXTNL_VAL_DT
    And SOFT.ORDER_DEPOSIT_DT <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
    And SOFT.ORDER_DEPOSIT_DT >= RefO3.OPEN_DT
    And SOFT.ORDER_DEPOSIT_DT <= RefO3.CLOSE_DT
Qualify Row_Number() Over(Partition by  SOFT.EXTERNAL_ORDER_ID,
                                        SOFT.ORDER_STATUS_CD,
                                        SOFT.STATUS_MODIF_TS,
                                        SOFT.ORDER_DEPOSIT_DT
                          Order by      RefO3.ROL_LINK_CD Asc,
                                        RefO3.START_EXTNL_VAL_DT Desc,
                                       Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1
          And  Row_number() over (Partition By AGENT_ID, ORDER_DEPOSIT_TS order by CREATION_TS desc) = 1
Where 
SOFT.AGENT_ID is not null

  And SOFT.DISTRBTN_CHANNL_ID in ('BFT', 'CRE',' OCA','POD','PAP')
  And SOFT.STORE_NAME not like '%PAE%' 
  And char_length(trim(SOFT.agent_id))=8
  And  lower(substr(SOFT.agent_id, 1,1)) between 'a' and 'z'
  And  lower(substr(SOFT.agent_id, 2,1)) between 'a' and 'z'
  And  lower(substr(SOFT.agent_id, 3,1)) between 'a' and 'z'
  And  lower(substr(SOFT.agent_id, 4,1))  between 'a' and 'z' 
  And  substr(SOFT.agent_id, 5,1)  between '0' and '9'
  And  substr(SOFT.agent_id, 6,1)  between '0' and '9'
  And  substr(SOFT.agent_id, 7,1)  between '0' and '9'
  And  substr(SOFT.agent_id, 8,1)  between '0' and '9'

) as  SOFTIEdo
Qualify TO_BE_MERGED = 0

) RFOREdoMerged

;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORG_T_AGENT_LNK_AD_EDO;
.if errorcode <> 0 then .quit 1

.quit 0



