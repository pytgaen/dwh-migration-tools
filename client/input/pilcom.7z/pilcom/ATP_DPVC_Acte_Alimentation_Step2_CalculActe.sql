-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_DPVC_Acte_Alimentation_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 27/03/2014      HZO         Creation
-- 15/10/2014      OCH         QC 795
-- 22/10/2014      HZO         Evolution Declaratif CCO (RG des données ORGA)
-- 11/01/2016      MDE         Evol : Calcul CA
-- 04/02/2016      HZO         Modification Déclaratif en volume
-- 04/02/2016      MDE         Evol Pilcom Digital 
-- 07/04/2015      MDE         Evol  : profondeur calcul 100 jrs
-- 05/01/2017      HOB         Modif Ajout Champs Ventes Ass
-- 22/11/2017      MEL         Ajout indicateur IOBSP
-- 03/10/2019      GRH         Ajouts & Alimentation des champs ACT_UNITE_CD / FLAG_HD/ ACT_DELTA_TARIF/ ACT_ACTE_VALO
-- 20/01/2020      JCR         Correction du cast en decimal du CA en provenance des placements 
-- 17/04/2020      YAB         Modification d'alimentation de ACT_DELTA_TARIF KPI2020
--------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------
--Jointure avec le catalogue pour récupérer les attributs pour la migration et Calcul de l'acte 
---------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ACT_T_ACTE_DECLAR_PVC all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ACT_T_ACTE_DECLAR_PVC
(
  ACTE_ID                         ,
  ACTE_ID_GEN                     ,
  OPERATOR_PROVIDER_ID            ,
  INTRNL_SOURCE_ID                ,
  TYPE_SOURCE_ID                  ,
  MASTER_ACTE_ID                  ,
  MASTER_INTRNL_SOURCE_ID         ,
  MASTER_FLAG                     ,
  MASTER_NB_FOUND                 ,
  CPLT_ACTE_ID                    ,
  CPLT_INTRNL_SOURCE_ID           ,
  CPLT_IN                         ,
  RULE_ID                         ,
  OFFSET_NB                       ,
  ACT_TYPE                        ,
  ORDER_EXTERNAL_ID               ,
  STATUS_CD                       ,
  ACT_UNIFIED_STATUS_CD           ,
  ACT_TS                          ,
  ACT_DT                          ,
  ACT_HH                          ,
  ACT_LAST_UPD_TS                 ,
  ACT_PRODUCT_ID_PRE              ,
  ACT_SEG_COM_ID_PRE              ,
  ACT_SEG_COM_AGG_ID_PRE          ,
  ACT_CODE_MIGR_PRE               ,
  ACT_OPER_ID_PRE                 ,
  ACT_PRODUCT_ID_FINAL            ,
  ACT_SEG_COM_ID_FINAL            ,
  ACT_SEG_COM_AGG_ID_FINAL        ,
  ACT_CODE_MIGR_FINAL             ,
  ACT_OPER_ID_FINAL               ,
  ACT_TYPE_SERVICE_FINAL          ,
  ACT_TYPE_COMMANDE_ID            ,
  ACT_DELTA_TARIF                 ,
  -- Ajout de ACT_UNITE_CD         
  ACT_UNITE_CD                    ,
  ACT_CD                          ,
  ACT_REM_ID                      ,
  ACT_FLAG_ACT_REM                ,
  ACT_FLAG_PEC_PERPVC             ,
  ACT_FLAG_PVC_REM                ,
  ACT_ACTE_VALO                   ,
  ACT_ACTE_FAMILLE_KPI            ,
  ACT_PERIODE_ID                  ,
  ACT_PERIODE_STATUS              ,
  ACT_PERIODE_CLOSURE_DT          ,
  ORIGIN_CD                       ,
  REASON_CD                       ,
  RESULT_CD                       ,
  AGENT_ID                        ,
  AGENT_ID_UPD                    ,
  AGENT_ID_UPD_DT                 ,
  AGENT_FIRST_NAME                ,
  AGENT_LAST_NAME                 ,
  UNIFIED_SHOP_CD                 ,
  ORG_SPE_CANAL_ID_MACRO          ,
  ORG_SPE_CANAL_ID                ,
  ORG_REM_CHANNEL_CD              ,
  --Ajout FLAG_HD                  
  FLAG_HD                         ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  ACTIVITY_CD                     ,
  ACTIVITY_GROUPNG_CD             ,
  REAL_ACTIVITY_CD                ,
  AUTO_ACTIVITY_IN                ,
  ORG_TYPE_CD                     ,
  ORG_TEAM_TYPE_ID                ,
  ORG_TEAM_LEVEL_1_CD             ,
  ORG_TEAM_LEVEL_1_DS             ,
  ORG_TEAM_LEVEL_2_CD             ,
  ORG_TEAM_LEVEL_2_DS             ,
  ORG_TEAM_LEVEL_3_CD             ,
  ORG_TEAM_LEVEL_3_DS             ,
  ORG_TEAM_LEVEL_4_CD             ,
  ORG_TEAM_LEVEL_4_DS             ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            ,
  CONFIRMATION_IN                 ,
  UNCONFIRM_REASON_LL             ,
  CONFIRMATION_DT                 ,
  CONFIRMATION_CALC_FIN_DT        ,
  DELIVERY_IN                     ,
  DELIVERY_DT                     ,
  DELIVERY_CALC_FIN_DT            ,
  PERENNITE_IN                    ,
  PERENNITE_FIN_DT                ,
  PERENNITE_CALC_FIN_DT           ,
  CONCURENCE_IN                   ,
  CONCURENCE_CONCLU_IN            ,
  CONCURENCE_ID                   ,
  CONCLU_PVC_IN                   ,
  PERENNITE_PVC_IN                ,
  PERENNITE_PVC_FIN_DT            ,
  PERENNITE_PVC_CALC_FIN_DT       ,
  CONCLDD_IN                      ,
  COMPTTN_IN                      ,
  COMPTTN_ID                      ,
  PERNNT_IN                       ,
  PERNNT_END_DT                   ,
  PERNNT_MOTIF                    ,
  PERNNT_CALC_END_DT              ,
  CONTRCT_NB_MONTH                ,
  CONTRCT_NB_MONTH_REMAINING      ,
  CONTRCT_DT_SIGN_POST            ,
  MIGRA_DT                        ,
  MIGRA_NEXT_OFFRE                ,
  RESIL_INT_DT                    ,
  RESIL_INT_MOTIF                 ,
  RESIL_INT_MOTIF_DS              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN  ,
  SEGMENT_DELIVERY_IN_PARK_DT     ,
  DELIVERY_ONTIME_IN              ,
  DELIVERY_DEAD_LINE_NU           ,
  ORDER_CANCELING_DT              ,
  LINE_ID                         ,
  MASTER_LINE_ID                  ,
  CUST_TYPE_CD                    ,
  MSISDN_ID                       ,
  NDS_VALUE_DS                    ,
  EXTERNAL_PARTY_ID               ,
  RES_VALUE_DS                    ,
  PAR_ACCES_SERVICE               ,
  TAC_CD                          ,
  IMEI_CD                         ,
  IMSI_CD                         ,
  HOM_START_DT                    ,
  MOB_START_DT                    ,
  I_SCORE_VALUE                   ,
  I_SCORE_TRESHOLD                ,
  I_SCORE_IN                      ,
  M_SCORE_VALUE                   ,
  M_SCORE_TRESHOLD                ,
  M_SCORE_IN                      ,
  OSCAR_VALUE                     ,
  CUST_BU_TYPE_CD                 ,
  CUST_BU_CD                      ,
  ADDRESS_TYPE                    ,
  ADDRESS_CONCAT_NM               ,
  ADDRESS_NM_1                    ,
  ADDRESS_NM_2                    ,
  ADDRESS_NM_3                    ,
  ADDRESS_NM_4                    ,
  ADDRESS_NM_5                    ,
  ADDRESS_NM_6                    ,
  POSTAL_CD                       ,
  INSEE_CD                        ,
  BU_CD                           ,
  DEPARTMNT_ID                    ,
  CLIENT_NU                       ,
  PAR_GEO_MACROZONE               ,
  PAR_UNIFIED_PARTY_ID            ,
  PAR_PARTY_REGRPMNT_ID           ,
  PAR_CID_ID                      ,
  PAR_PID_ID                      ,
  PAR_FIRST_IN                    ,
  ORG_AGENT_IOBSP                 ,
  ORG_EDO_IOBSP                   ,
  PAR_IRIS2000_CD                 ,
  PAR_FIBER_IN                    ,
  DMC_LINE_TYPE                   ,
  DMC_ACTIVATION_DT               ,
  CHECK_INITIAL_STATUS_CD         ,
  CHECK_NAT_STATUS_CD             ,
  CHECK_NAT_COMMENT               ,
  CHECK_NAT_STATUS_LN             ,
  CHECK_LOC_STATUS_CD             ,
  CHECK_LOC_COMMENT               ,
  CHECK_LOC_STATUS_LN             ,
  CHECK_VALIDT_DT                 ,
  ACT_END_UNIFIED_DT              ,
  ACT_END_UNIFIED_DS              ,
  ACT_CLOSURE_DT                  ,
  ACT_CLOSURE_DS                  ,
  HOT_IN                          ,
  RUN_ID                          ,
  CREATION_TS                     ,
  LAST_MODIF_TS                   ,
  FRESH_IN                        ,
  COHERENCE_IN                    

)
Select
  Placement.ACTE_ID                                         As ACTE_ID                         ,
  Placement.ACTE_ID                                         As ACTE_ID_GEN                     ,
  Null                                                      As OPERATOR_PROVIDER_ID            ,
  Placement.INTRNL_SOURCE_ID                                As INTRNL_SOURCE_ID                ,
  'DEC'                                                     As TYPE_SOURCE_ID                  ,-------------
  Placement.ACTE_ID                                         As MASTER_ACTE_ID                  ,
  Placement.INTRNL_SOURCE_ID                                As MASTER_INTRNL_SOURCE_ID         ,
  1                                                         As MASTER_FLAG                     ,
  0                                                         As MASTER_NB_FOUND                 ,
  Null                                                      As CPLT_ACTE_ID                    ,
  Null                                                      As CPLT_INTRNL_SOURCE_ID           ,
  'N'                                                       As CPLT_IN                         ,
  0                                                         As RULE_ID                         ,
  Null                                                      As OFFSET_NB                       ,
  'DEC'                                                     As ACT_TYPE                        ,-------------
  Trim(Placement.PVC_ACTE_ID)                               As ORDER_EXTERNAL_ID               ,-------------
  Placement.ORDER_STATUT                                    As STATUS_CD                       ,
  Null                                                      As ACT_UNIFIED_STATUS_CD           ,
  Placement.ORDER_DEPOSIT_TS                                As ACT_TS                          ,
  Placement.ORDER_DEPOSIT_DT                                As ACT_DT                          ,
  Extract(HOUR From Placement.ORDER_DEPOSIT_TS)             As ACT_HH                          ,
  Placement.LAST_MODIF_TS                                   As ACT_LAST_UPD_TS                 ,
  MatDec.PRODUCT_ID_PRE                                     As ACT_PRODUCT_ID_PRE              ,
  MatDec.SEG_COM_ID_PRE                                     As ACT_SEG_COM_ID_PRE              ,
  MatDec.SEG_COM_AGG_ID_PRE                                 As ACT_SEG_COM_AGG_ID_PRE          ,
  MatDec.CODE_MIGR_PRE                                      As ACT_CODE_MIGR_PRE               ,
  MatDec.OPER_ID_PRE                                        As ACT_OPER_ID_PRE                 ,
  MatDec.PRODUCT_ID_FINAL                                   As ACT_PRODUCT_ID_FINAL            ,
  MatDec.SEG_COM_ID_FINAL                                   As ACT_SEG_COM_ID_FINAL            ,
  MatDec.SEG_COM_AGG_ID_FINAL                               As ACT_SEG_COM_AGG_ID_FINAL        ,
  MatDec.CODE_MIGR_FINAL                                    As ACT_CODE_MIGR_FINAL             ,
  MatDec.OPER_ID_FINAL                                      As ACT_OPER_ID_FINAL               ,
  MatDec.TYPE_SERVICE_FINAL                                 As ACT_TYPE_SERVICE_FINAL          ,
  MatDec.TYPE_COMMANDE_ID                                   As ACT_TYPE_COMMANDE_ID            ,
 Case
    -- Unité <> NB 
    When MatDec.UNITE_CD IN ('${P_PIL_490}','${P_PIL_623}','${P_PIL_622}')                 
         And COM_O${KNB_SUFFIX}.IsNumber(TD_SYSFNLIB.Oreplace(Placement.CA,',','')) = 1
      Then  Cast(TD_SYSFNLIB.Oreplace(Placement.CA,',','.') as Decimal(16,2) FORMAT '-------.99')
    When MatDec.UNITE_CD='${P_PIL_620}' 
          And COM_O${KNB_SUFFIX}.IsNumber(TD_SYSFNLIB.Oreplace(Placement.CA,',','')) = 1
      Then case 
             When ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
                  Then Cast(TD_SYSFNLIB.Oreplace(Placement.CA,',','.') as Decimal(16,2) FORMAT '-------.99')
                  Else Null
              End
    Else Null
 End                                                        As ACT_DELTA_TARIF                 ,

  MatDec.UNITE_CD                                           As ACT_UNITE_CD                    ,
  Case
        When  MatDec.ACTE_REM_ID Is Not Null
          Then  MatDec.ACTE_REM_ID          
        --Si le produit Placé est un produit inconnu de RefCom
        When MatDec.SEG_COM_ID_FINAL    in ('NS')
          Then  '${P_PIL_221}'                   
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        -- Sinon c'est un problème dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                       As ACT_CD                          ,
  Placement.ACT_CD                                          As ACT_REM_ID                      ,
  MatDec.FLAG_ACT_REM                                       As ACT_FLAG_ACT_REM                ,
  MatDec.FLAG_PEC_PERPVC                                    As ACT_FLAG_PEC_PERPVC             ,
  Null                                                      As ACT_FLAG_PVC_REM                ,
  
  
  
  
  
  
    Case
    -- Unite = NB
         When  MatDec.UNITE_CD ='${P_PIL_620}'
         Then   MatDec.ACTE_VALO
    -- Unite <> NB
         When MatDec.UNITE_CD IN('${P_PIL_490}','${P_PIL_623}','${P_PIL_622}')
              And COM_O${KNB_SUFFIX}.IsNumber(TD_SYSFNLIB.Oreplace(Placement.CA,',','')) = 1
         Then ( Cast(TD_SYSFNLIB.Oreplace(Placement.CA,',','.') as Decimal(16,2) FORMAT '-------.99')  * MatDec.TAUX_MARGE )
    Else Null
  END                                                       As ACT_ACTE_VALO                   ,
  MatDec.ACTE_FAMILLE_KPI                                   As ACT_ACTE_FAMILLE_KPI            ,
  MatDec.PERIODE_ID                                         As ACT_PERIODE_ID                  ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                  As ACT_PERIODE_STATUS              ,
  EtatPeriode.PERIODE_CLOSURE_DT                            As ACT_PERIODE_CLOSURE_DT          ,
  Null                                                      As ORIGIN_CD                       ,
  Null                                                      As REASON_CD                       ,
  Null                                                      As RESULT_CD                       ,
  Placement.CUID                                            As AGENT_ID                        ,
  Upper(Placement.CUID)                                     As AGENT_ID_UPD                    ,
  Null                                                      As AGENT_ID_UPD_DT                 ,
  Placement.SELLER_FIRST_NAME                               As AGENT_FIRST_NAME                ,
  Placement.SELLER_LAST_NAME                                As AGENT_LAST_NAME                 ,
  Null                                                      As UNIFIED_SHOP_CD                 ,
  Null                                                      As ORG_SPE_CANAL_ID_MACRO          ,
  Null                                                      As ORG_SPE_CANAL_ID                ,
  Case  When RefO3.CHANNEL_CD = 'Dist'
            Then 
              Case  When RefO3.NETWRK_TYP_EDO_ID = 'FT'
                  Then 'AD'
                Else 'NONPARAM'
              End
          Else
            Case  When Coalesce(RefO3.FLAG_PLT_SCH,1)  = 1
                Then 'SCH'
              Else 'CCO'
            End
  End                                                       As ORG_REM_CHANNEL_CD              ,
  MatDec.HUMAINDIGITAL                                      As FLAG_HD                          ,
  RefO3.CHANNEL_CD                                          As ORG_CHANNEL_CD                  ,
  Case  When RefO3.CHANNEL_CD = 'Dist'
          Then 
            Case  When RefO3.NETWRK_TYP_EDO_ID = 'FT'
                Then 'AD'
              Else 'NONPARAM'
            End
          Else
            Case  When Coalesce(RefO3.FLAG_PLT_CONV,0)  = 1
                Then 'Convergent'
              Else 
                Case  When Coalesce(RefO3.FLAG_PLT_SCH,1)  = 1
                    Then 'Home'
                  Else 'Mobile'
                End
            End
  End                                                       As ORG_SUB_CHANNEL_CD              ,
  Case  When RefO3.CHANNEL_CD = 'Dist'
            Then 
              Case When RefO3.FLAG_TYPE_GEO Is Not Null
                    Then 'DOM'
                   Else 'Metropole'
              End
          Else Null
  End                                                       As ORG_SUB_SUB_CHANNEL_CD          ,
  Case  When RefO3.CHANNEL_CD = 'Dist'
            Then 'Boutique FT'
          Else Null
  End                                                       As ORG_GT_ACTIVITY                 ,
  Null                                                      As ORG_FIDELISATION                ,
  'NON'                                                     As ORG_WEB_ACTIVITY                ,
  'NON'                                                     As ORG_AUTO_ACTIVITY               ,
  Placement.TEAM_ORDER_DES                                  As ORG_EDO_ID                      ,
  RefO3.TYPE_EDO                                            As ORG_TYPE_EDO                    ,
  RefO3.FLAG_PLT_CONV                                       As ORG_FLAG_PLT_CONV               ,
  RefO3.FLAG_TYPE_CPT_NTK                                   As ORG_FLAG_TEAM_MKT               ,
  Null                                                      As ORG_FLAG_TYPE_CMP               ,
  Null                                                      As ORG_RESP_EDO_ID                 ,
  Null                                                      As ORG_RESP_TYPE_EDO               ,
  Null                                                      As ORG_RESP_FLAG_PLT_CONV          ,
  Null                                                      As ACTIVITY_CD                     ,
  Null                                                      As ACTIVITY_GROUPNG_CD             ,
  Null                                                      As REAL_ACTIVITY_CD                ,
  Null                                                      As AUTO_ACTIVITY_IN                ,
  Null                                                      As ORG_TYPE_CD                     ,
  Null                                                      As ORG_TEAM_TYPE_ID                ,
  Null                                                      As ORG_TEAM_LEVEL_1_CD             ,
  Null                                                      As ORG_TEAM_LEVEL_1_DS             ,
  Null                                                      As ORG_TEAM_LEVEL_2_CD             ,
  Null                                                      As ORG_TEAM_LEVEL_2_DS             ,
  Null                                                      As ORG_TEAM_LEVEL_3_CD             ,
  Null                                                      As ORG_TEAM_LEVEL_3_DS             ,
  Null                                                      As ORG_TEAM_LEVEL_4_CD             ,
  Null                                                      As ORG_TEAM_LEVEL_4_DS             ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_1_CD)                      As WORK_TEAM_LEVEL_1_CD            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_1_DS)                      As WORK_TEAM_LEVEL_1_DS            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_2_CD)                      As WORK_TEAM_LEVEL_2_CD            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_2_DS)                      As WORK_TEAM_LEVEL_2_DS            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_3_CD)                      As WORK_TEAM_LEVEL_3_CD            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_3_DS)                      As WORK_TEAM_LEVEL_3_DS            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_4_CD)                      As WORK_TEAM_LEVEL_4_CD            ,
  Trim(RefHierO3.WORK_TEAM_LEVEL_4_DS)                      As WORK_TEAM_LEVEL_4_DS            ,
  Null                                                      As CONFIRMATION_IN                 ,
  Null                                                      As UNCONFIRM_REASON_LL             ,
  Null                                                      As CONFIRMATION_DT                 ,
  Null                                                      As CONFIRMATION_CALC_FIN_DT        ,
  Null                                                      As DELIVERY_IN                     ,
  Null                                                      As DELIVERY_DT                     ,
  Null                                                      As DELIVERY_CALC_FIN_DT            ,
  Null                                                      As PERENNITE_IN                    ,
  Null                                                      As PERENNITE_FIN_DT                ,
  Null                                                      As PERENNITE_CALC_FIN_DT           ,
  Null                                                      As CONCURENCE_IN                   ,
  Null                                                      As CONCURENCE_CONCLU_IN            ,
  Null                                                      As CONCURENCE_ID                   ,
  Null                                                      As CONCLU_PVC_IN                   ,
  Null                                                      As PERENNITE_PVC_IN                ,
  Null                                                      As PERENNITE_PVC_FIN_DT            ,
  Null                                                      As PERENNITE_PVC_CALC_FIN_DT       ,
  Null                                                      As CONCLDD_IN                      ,
  Null                                                      As COMPTTN_IN                      ,
  Null                                                      As COMPTTN_ID                      ,
  Null                                                      As PERNNT_IN                       ,
  Null                                                      As PERNNT_END_DT                   ,
  Null                                                      As PERNNT_MOTIF                    ,
  Null                                                      As PERNNT_CALC_END_DT              ,
  Null                                                      As CONTRCT_NB_MONTH                ,
  Null                                                      As CONTRCT_NB_MONTH_REMAINING      ,
  Null                                                      As CONTRCT_DT_SIGN_POST            ,
  Null                                                      As MIGRA_DT                        ,
  Null                                                      As MIGRA_NEXT_OFFRE                ,
  Null                                                      As RESIL_INT_DT                    ,
  Null                                                      As RESIL_INT_MOTIF                 ,
  Null                                                      As RESIL_INT_MOTIF_DS              ,
  Null                                                      As PRES_SEGMENT_IN_PARK_BEFORE_IN  ,
  Null                                                      As SEGMENT_DELIVERY_IN_PARK_DT     ,
  Null                                                      As DELIVERY_ONTIME_IN              ,
  Null                                                      As DELIVERY_DEAD_LINE_NU           ,
  Null                                                      As ORDER_CANCELING_DT              ,
  Placement.DMC_LINE_ID                                     As LINE_ID                         ,
  Placement.DMC_MASTER_LINE_ID                              As MASTER_LINE_ID                  ,
  Null                                                      As CUST_TYPE_CD                    ,
  Placement.MISISDN                                         As MSISDN_ID                       ,
  Placement.ND                                              As NDS_VALUE_DS                    ,
  Placement.NDIP                                            As EXTERNAL_PARTY_ID               ,
  Null                                                      As RES_VALUE_DS                    ,
  Placement.SERVICE_ACCESS_ID                               As PAR_ACCES_SERVICE               ,
  Null                                                      As TAC_CD                          ,
  Null                                                      As IMEI_CD                         ,
  Placement.PAR_IMSI_CD                                     As IMSI_CD                         ,
  Null                                                      As HOM_START_DT                    ,
  Null                                                      As MOB_START_DT                    ,
  Null                                                      As I_SCORE_VALUE                   ,
  Null                                                      As I_SCORE_TRESHOLD                ,
  Null                                                      As I_SCORE_IN                      ,
  Null                                                      As M_SCORE_VALUE                   ,
  Null                                                      As M_SCORE_TRESHOLD                ,
  Null                                                      As M_SCORE_IN                      ,
  Null                                                      As OSCAR_VALUE                     ,
  Null                                                      As CUST_BU_TYPE_CD                 ,
  Null                                                      As CUST_BU_CD                      ,
  Null                                                      As ADDRESS_TYPE                    ,
  Null                                                      As ADDRESS_CONCAT_NM               ,
  Null                                                      As ADDRESS_NM_1                    ,
  Null                                                      As ADDRESS_NM_2                    ,
  Null                                                      As ADDRESS_NM_3                    ,
  Null                                                      As ADDRESS_NM_4                    ,
  Null                                                      As ADDRESS_NM_5                    ,
  Null                                                      As ADDRESS_NM_6                    ,
  Placement.PAR_POSTAL_CD                                   As POSTAL_CD                       ,
  Placement.PAR_INSEE_CD                                    As INSEE_CD                        ,
  Placement.PAR_BU_CD                                       As BU_CD                           ,
  Placement.PAR_DEPARTMNT_ID                                As DEPARTMNT_ID                    ,
  Placement.CLIENT_NU                                       As CLIENT_NU                       ,
  Placement.PAR_GEO_MACROZONE                               as PAR_GEO_MACROZONE               ,
  Placement.PAR_UNIFIED_PARTY_ID                            as PAR_UNIFIED_PARTY_ID            ,
  Placement.PAR_PARTY_REGRPMNT_ID                           as PAR_PARTY_REGRPMNT_ID           ,
  Placement.PAR_CID_ID                                      as PAR_CID_ID                      ,
  Placement.PAR_PID_ID                                      as PAR_PID_ID                      ,
  Placement.PAR_FIRST_IN                                    as PAR_FIRST_IN                    ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                 ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                   ,
  Placement.PAR_IRIS2000_CD                                 As PAR_IRIS2000_CD                 ,
  Placement.PAR_FIBER_IN                                    As PAR_FIBER_IN                    ,
  Placement.DMC_LINE_TYPE                                   As DMC_LINE_TYPE                   ,
  Placement.DMC_ACTIVATION_DT                               As DMC_ACTIVATION_DT               ,
  Coalesce(Placement.STATUT_CSO,'6')                        As CHECK_INITIAL_STATUS_CD         ,
  RetournCSO.CHECK_NAT_STATUS_CD                            As CHECK_NAT_STATUS_CD             ,
  RetournCSO.CHECK_NAT_COMMENT                              As CHECK_NAT_COMMENT               ,
  RetournCSO.CHECK_NAT_STATUS_LN                            As CHECK_NAT_STATUS_LN             ,
  RetournCSO.CHECK_LOC_STATUS_CD                            As CHECK_LOC_STATUS_CD             ,
  RetournCSO.CHECK_LOC_COMMENT                              As CHECK_LOC_COMMENT               ,
  RetournCSO.CHECK_LOC_STATUS_LN                            As CHECK_LOC_STATUS_LN             ,
  RetournCSO.CHECK_VALIDT_DT                                As CHECK_VALIDT_DT                 ,
  Null                                                      As ACT_END_UNIFIED_DT              ,
  Null                                                      As ACT_END_UNIFIED_DS              ,
  Null                                                      As ACT_CLOSURE_DT                  ,
  Null                                                      As ACT_CLOSURE_DS                  ,
  0                                                         As HOT_IN                          ,
  Null                                                      As RUN_ID                          ,
  Current_Timestamp(0)                                      As CREATION_TS                     ,
  Current_Timestamp(0)                                      As LAST_MODIF_TS                   ,
  1                                                         As FRESH_IN                        ,
  0                                                         As COHERENCE_IN                    
From 
  ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_DECLAR_PVC Placement
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA MatDec
    On    Placement.ACT_CD                        = MatDec.ACTE_REM_ID
      And Periode.PERIODE_ID                      = MatDec.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    Periode.PERIODE_ID                      = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                  = 1
      And EtatPeriode.FRESH_IN                    = 1
      And EtatPeriode.CLOSURE_DT                  Is Null
  Left Outer Join  ${KNB_PCO_TMP}.ACT_W_ACTE_DECLAR_PVC_O3 RefHierO3
    On    Placement.ACTE_ID                       = RefHierO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT              = RefHierO3.ORDER_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.ACT_W_ACTE_DPVC_O3 RefO3
    On    Placement.ACTE_ID                       = RefO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT              = RefO3.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                       = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG           = 1
      And RetournCSO.CURRENT_IN                   = 1                                     
Where
  (1=1)  
  And Placement.ORDER_DEPOSIT_DT  >= (Current_date - ${P_PIL_526}) 
;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------------------------------------------
--Gestion du cas de suppression
---------------------------------------------------------------------------------------------------------------
Update ActeTmp
From
  ${KNB_PCO_TMP}.ACT_T_ACTE_DECLAR_PVC          ActeTmp    ,
  ${KNB_PCO_TMP}.ACT_T_PLACEMENT_DECLAR_PVC     Placement  
Set
  ACT_CLOSURE_DT  =  Current_date
Where
  (1=1)
  And Placement.ACTION_ACTE  =  6
  And ActeTmp.ACTE_ID = Placement.ACTE_ID
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ACT_T_ACTE_DECLAR_PVC;
.if errorcode <> 0 then .quit 1

.quit 0
