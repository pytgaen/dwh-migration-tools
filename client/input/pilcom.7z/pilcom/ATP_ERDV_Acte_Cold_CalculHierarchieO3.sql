-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Acte_Cold_CalculHierarchieO3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de creation de la table hierarchie O3 pour  ERDV
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 11/12/2014      KBH           Creation
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_ERDV_C_O3 all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_ERDV_C_O3
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  WORK_TEAM_LEVEL_1_CD        ,
  WORK_TEAM_LEVEL_1_DS        ,
  WORK_TEAM_LEVEL_2_CD        ,
  WORK_TEAM_LEVEL_2_DS        ,
  WORK_TEAM_LEVEL_3_CD        ,
  WORK_TEAM_LEVEL_3_DS        ,
  WORK_TEAM_LEVEL_4_CD        ,
  WORK_TEAM_LEVEL_4_DS        
 )
Select
  RefIdAuto.ACTE_ID                         as ACTE_ID                    ,
  RefIdAuto.ORDER_DEPOSIT_DT                as ORDER_DEPOSIT_DT           ,
  WLvl1.WORK_TEAM_LEVEL_1_CD                as WORK_TEAM_LEVEL_1_CD       ,
  WLvl1.WORK_TEAM_LEVEL_1_DS                as WORK_TEAM_LEVEL_1_DS       ,
  WLvl1.WORK_TEAM_LEVEL_2_CD                as WORK_TEAM_LEVEL_2_CD       ,
  WLvl1.WORK_TEAM_LEVEL_2_DS                as WORK_TEAM_LEVEL_2_DS       ,
  WLvl1.WORK_TEAM_LEVEL_3_CD                as WORK_TEAM_LEVEL_3_CD       ,
  WLvl1.WORK_TEAM_LEVEL_3_DS                as WORK_TEAM_LEVEL_3_DS       ,
  WLvl1.WORK_TEAM_LEVEL_4_CD                as WORK_TEAM_LEVEL_4_CD       ,
  WLvl1.WORK_TEAM_LEVEL_4_DS                as WORK_TEAM_LEVEL_4_DS       
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_ERDV_C RefIdAuto
  --On jointe dans l'orga de Travail
  Left Outer Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL WLvl1
    On    RefIdAuto.EDO_ID       =   WLvl1.WORK_TEAM_LEVEL_1_CD
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_1_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_1_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_2_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_2_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_3_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_3_END_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              >=  WLvl1.WORK_TEAM_LEVEL_4_START_DT
      And RefIdAuto.ORDER_DEPOSIT_DT              <=  WLvl1.WORK_TEAM_LEVEL_4_END_DT
Where
  (1=1)
Qualify Row_Number() Over (Partition By RefIdAuto.ACTE_ID Order By        WLvl1.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.WORK_TEAM_LEVEL_4_CD Desc
                          ) = 1
;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_ERDV_C_O3;
.if errorcode <> 0 then .quit 1

.quit 0
