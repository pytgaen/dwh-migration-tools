-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Placement_Consolidation_Enrichissement_Step2_Vendeur_Creation.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrichissement Vendeur
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
--------------------------------------------------------------------------------

.set width 2500;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR All;
.if errorcode <> 0 then .quit 1


-------------------------------------------------------------------
-- Implémentation des RGs sur la recherche du XI associé au code vendeur
-- On recherche Ici le conseiller ayant réaliser la vente
-------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_REF_TRAV              ,
  ORG_AGENT_ID              ,
  ORG_POC_XI                ,
  ORG_NOM                   ,
  ORG_PRENOM                ,
  ORG_GROUPE_ID             ,
  ORG_GROUPE_ID_HIER
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  --Lorsqu'on trouve l'orga POC
  'POCSC'                           as ORG_REF_TRAV         ,
  --Code Aliance du vendeur :
  RefId.CUID                        as ORG_AGENT_ID         ,
  --Code Xi du Vendeur :CLIENT_CO_TYPCLI 
  MatPoc.XI                         as ORG_POC_XI           ,
  --Nom du Vendeur :
  MatPoc.CSL_NOM                    as ORG_NOM              ,
  --Prénom du vendeur :
  MatPoc.CSL_PRENOM                 as ORG_PRENOM           ,
  --Groupe de travail
  MatPoc.TRAV_ORGA_EQUI_CO_GRP      as ORG_GROUPE_ID        ,  
  --Groupe Organisationnel
  MatPoc.RAT_ORGA_EQUI_CO_GRP       as ORG_GROUPE_ID_HIER   
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_1 RefId
  Inner Join ${KNB_IBU_GLB_V}.VPOCCSLMAT MatPoc
    On    RefId.CUID              =   MatPoc.UPPER_ID_FT
    And   RefId.INT_DEPOSIT_TS    >=  MatPoc.CSLORGA_DT_DEB
    And   RefId.INT_DEPOSIT_TS    <   MatPoc.CSLORGA_DT_FIN
Where
  (1=1)
  And (     RefId.ORG_POC_XI Is Null
          Or
            RefId.ORG_REF_TRAV='OEEEDEL'
      )
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by MatPoc.CSLORGA_DT_DEB Asc)=1
;
.if errorcode <> 0 then .quit 1


--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR;
.if errorcode <> 0 then .quit 1



--On insert les lignes dont on calcul par l'orga OEE EDEL : TDCONSEIL:

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_REF_TRAV              ,
  ORG_AGENT_ID              ,
  ORG_POC_XI                ,
  ORG_NOM                   ,
  ORG_PRENOM                ,
  ORG_GROUPE_ID             ,
  ORG_GROUPE_ID_HIER
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  --Lorsqu'on trouve Dans l'orga OEEEDEL
  'OEEEDEL'                         as ORG_REF_TRAV         ,
  --Code Aliance du vendeur :
  Conseil.CONSEIL_LB_UTIL           as ORG_AGENT_ID         ,
  --Code Xi du Vendeur :CLIENT_CO_TYPCLI
  Conseil.CONSEIL_XI                as ORG_POC_XI           ,
  --Nom du Vendeur :
  Conseil.CONSEIL_LB_NOM            as ORG_NOM              ,
  --Prénom du vendeur :
  Conseil.CONSEIL_LB_PRENOM         as ORG_PRENOM           ,
  --Groupe de travail
  Conseil.CONSEIL_ID_GROUPE         as ORG_GROUPE_ID        ,
  --Groupe Organisationnel
  Null                              as ORG_GROUPE_ID_HIER      
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDCONSEIL Conseil
    On    RefId.CONSEIL_XI          =   Conseil.CONSEIL_XI
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR RefIdVend
    On    RefId.ACTE_ID           = RefIdVend.ACTE_ID
      And RefId.INT_DEPOSIT_DT    = RefIdVend.INT_DEPOSIT_DT
Where
  (1=1)
  And (     RefId.ORG_POC_XI Is Null
        Or
            RefId.ORG_REF_TRAV='OEEEDEL'
      )
  And RefIdVend.ACTE_ID is null
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Conseil.CONSEIL_XI desc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_VENDEUR;
.if errorcode <> 0 then .quit 1


.quit 0
