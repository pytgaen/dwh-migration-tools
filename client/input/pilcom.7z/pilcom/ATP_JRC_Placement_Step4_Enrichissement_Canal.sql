--$HEADER:   %HEADER% 
---------------------------------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile       :ATP_JRC_Placement_Step4_Enrichissement_Canal.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissements Canal des  Interactions Relations Clients
---------------------------------------------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/08/2018       HOB         Creation
-- 24/09/2018       TCL         modif UNIFIED_SHOP_CD
-- 25/09/2018       HOB         Correction
-- 07/01/2019       JCR         Modif pour Humain Digital sprint 1 (Service Client)
-- 07/06/2019       SSI         MODIFICATION H&D indust
-- 01/03/2021       EVI         PILCOM-815 : H&D - Ajout source H2H
-- 18/06/2021       EVI         PILCOM-937 : Optimisation utilisation CAT_W_PILCOM_REFO3_JOUR
---------------------------------------------------------------------------------------------------------------------------------
.set width 2500                                                                                                                 ;
---------------------------------------------------------------------------------------------------------------------------------
-- Etape 1 : Purge de la table temporaire avant insertion
---------------------------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL All                                                                      ;
.if errorcode <> 0 then .quit 1

Delete from  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_JRC_ACT all                                                                         ;
.if errorcode <> 0 then .quit 1

---------------------------------------------------------------------------------------------------------------------------------
--Etape 2-- Détermination de l'activité
---------------------------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL
(
  ACTE_ID                                                                                                                       ,
  INTRCTN_DT                                                                                                                    ,
  ORG_CHANNEL_CD                                                                                                                ,
  ORG_SUB_CHANNEL_CD                                                                                                            ,
  ORG_SUB_SUB_CHANNEL_CD                                                                                                        ,
  ORG_GT_ACTIVITY                                                                                                               ,
  ORG_REM_CHANNEL_CD                                                                                                            ,
  ORG_FIDELISATION                                                                                                              ,
  ORG_WEB_ACTIVITY                                                                                                              ,
  ORG_AUTO_ACTIVITY                                                                                                             ,
  EDO_ID                                                                                                                        ,
  ORG_TEAM_TYPE_ID                                                                                                              ,
  UNIFIED_SHOP_CD                                                                                                               ,
  NETWRK_TYP_EDO_ID                                                                                                             ,
  FLAG_PLT_CONV_NB                                                                                                              ,
  FLAG_PLT_SCH_IN                                                                                                               ,
  FLAG_TYPE_GEO_CD                                                                                                              ,
  FLAG_TYPE_CPT_NTK                                                                                                             ,
  FLAG_TYPE_PTN_NTK                                                                                                             ,
  FLAG_AD_SC                                                                                                                    ,
  PRIO
)

Select
  RefInt.ACTE_ID                                                          As ACTE_ID                                            ,
  RefInt.INTRCTN_DT                                                       As INTRCTN_DT                                         ,
    --Canal de vente Macro = Dist
  Case when RefEDO.FLAG_PLT_AD = 1 or   RefEDO.NETWRK_TYP_EDO_ID = 'RP'
       Then 'Dist'
       Else 'Exclus'
  End                                                                     As ORG_CHANNEL_CD_AGR                                 ,
    --Sous Canal
  Case  When ORG_CHANNEL_CD_AGR ='Dist' 
          Then 
                Case when   RefEdoAxs.CANAL = 'SUB_CHANNEL'
                           Then RefEdoAxs.SUB_CHANNEL
                End
        Else 'Exclus'
  End                                                                     As ORG_SUB_CHANNEL_CD_AGR                             ,
  --Sous Sous Canal
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then
                Case When   RefEdoAxs.CANAL = 'SUB_SUB_CHANNEL'
                   Then RefEdoAxs.SUB_SUB_CHANNEL
                   Else 'Metropole'
              End
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then
                Case When   RefEdoAxs.CANAL = 'SUB_SUB_CHANNEL'
                   Then RefEdoAxs.SUB_SUB_CHANNEL
                   Else 'Metropole'
              End
        Else 'Exclus'
  End                                                                     As ORG_SUB_SUB_CHANNEL_CD                             ,
  -- GT/Activité
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'Boutique FT'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'GDT'
        Else 'Exclus'
  End                                                                     As ORG_GT_ACTIVITY                                    ,

  --Canal de Rem
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'AD'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'Exclus'
        Else 'Exclus'
 End                                                                      As ORG_REM_CHANNEL_CD                                 ,





  Null                                                                    As ORG_FIDELISATION                                   ,
  'omnicanal'                                                             As ORG_WEB_ACTIVITY                                   ,
  'NON'                                                                   As ORG_AUTO_ACTIVITY                                  ,
  RefEDO.EDO_ID                                                           As EDO_ID                                             ,

  -- Équipes Internes / Équipes Externes.
  Case When ORG_SUB_CHANNEL_CD_AGR='AD'
        Then 'Interne'
        Else 'Externe'
  End                                                                     As ORG_TEAM_TYPE_ID                                   ,
  Null                                                                    As UNIFIED_SHOP_CD                                    ,
  RefEDO.NETWRK_TYP_EDO_ID                                                As NETWRK_TYP_EDO_ID                                  ,
  RefEDO.FLAG_PLT_CONV                                                    As FLAG_PLT_CONV_NB                                   ,
  RefEDO.FLAG_PLT_SCH                                                     As FLAG_PLT_SCH_IN                                    ,
  RefEDO.FLAG_TYPE_GEO                                                    As FLAG_TYPE_GEO_CD                                   ,
  RefEDO.FLAG_TYPE_CPT_NTK                                                As FLAG_TYPE_CPT_NTK                                  ,
  RefEDO.FLAG_TYPE_PTN_NTK                                                As FLAG_TYPE_PTN_NTK                                  ,
  1                                                                       As FLAG_AD_SC                                         ,
  1                                                                       As Prio

From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 RefInt
  Left Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    Coalesce (RefInt.OPRTR_TEAM_ACTVT_ID,RefInt.OPRTR_TEAM_HIERCH_ID)    = RefEDO.EXTNL_VAL_COD_CD
    And   RefInt.INTRCTN_DT              Between RefEDO.START_EXTNL_VAL_DT
    And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Left Outer Join
    (
      Select
        EdoAx.EDO_ID                    As EDO_ID             ,
        EdoAx.VAL_AXS_CLSSF_ID          As VAL_AXS_CLSSF_ID   ,
        EdoAx.START_VAL_AXS_DT          As START_VAL_AXS_DT   ,
        EdoAx.END_VAL_AXS_DT            As END_VAL_AXS_DT     ,
        Case When VAL_AXS_CLSSF_ID  In ('PST', 'PSE')
          Then 'RP'
          Else 'AD'
        End                             As SUB_CHANNEL        ,
        'NA'                            As SUB_SUB_CHANNEL    ,
        'SUB_CHANNEL'                   As CANAL              
      From
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
        And EdoAx.VAL_AXS_CLSSF_ID  In ('PST', 'PSE','BTQ')
        
        Union All
        
        Select
        EdoAx.EDO_ID                    As EDO_ID             ,
        EdoAx.VAL_AXS_CLSSF_ID          As VAL_AXS_CLSSF_ID   ,
        EdoAx.START_VAL_AXS_DT          As START_VAL_AXS_DT   ,
        EdoAx.END_VAL_AXS_DT            As END_VAL_AXS_DT     ,
        'NA'                            As SUB_CHANNEL        ,
        'Dom'                           As SUB_SUB_CHANNEL    ,
        'SUB_SUB_CHANNEL'               As CANAL              

      From
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
        And EdoAx.VAL_AXS_CLSSF_ID  In ('REUNION','CARAIBES')

      ) RefEdoAxs

  On  RefEDO.EDO_ID   = RefEdoAxs.EDO_ID
    And RefInt.INTRCTN_DT >= RefEdoAxs.START_VAL_AXS_DT
    And RefInt.INTRCTN_DT < Coalesce(RefEdoAxs.END_VAL_AXS_DT, Cast('99991231' as Date Format 'YYYYMMDD'))

Where
  (1=1)
  And (RefInt.OPRTR_TEAM_ACTVT_ID Is Not Null
      Or RefInt.OPRTR_TEAM_HIERCH_ID Is Not Null
      )
  And RefInt.APPLI_SOURCE_ID In ('98I')

Qualify Row_number() over (Partition by RefInt.ACTE_ID,RefInt.INTRCTN_DT Order By RefEDO.EDO_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL;
.if errorcode <> 0 then .quit 1

---------------------------------------------------------------------------------------------------------------------------------
--Etape 3 -- Calcul de l'activité
---------------------------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_JRC_ACT
(
  ACTE_ID                                                                                                                       ,
  INTRCTN_DT                                                                                                                    ,
  AGENT_ID                                                                                                                      ,
  START_ACTIVITY_TS                                                                                                             ,
  END_ACTIVITY_TS                                                                                                               ,
  ACTIVITY                                                                                                                      ,
  SOURCE                                                                                                                        ,
  PRIO
)
Select
  ACTE_ID                                                                                                                       ,
  INTRCTN_DT                                                                                                                    ,
  AGENT_ID                                                                                                                      ,
  START_ACTIVITY_TS                                                                                                             ,
  END_ACTIVITY_TS                                                                                                               ,
  ACTIVITY                                                                                                                      ,
  SOURCE                                                                                                                        ,
  PRIO
From
(
  Select
    RefId.ACTE_ID                           As ACTE_ID                                                                          ,
    RefId.INTRCTN_DT                        As INTRCTN_DT                                                                       ,
    ACTIVITY.CUID                           As AGENT_ID                                                                         ,
    ACTIVITY.START_ACTIVITY_TS              As START_ACTIVITY_TS                                                                ,
    ACTIVITY.END_ACTIVITY_TS                As END_ACTIVITY_TS                                                                  ,
    ACTIVITY.ACTIVITY                       As ACTIVITY                                                                         ,
    ACTIVITY.SOURCE                         As SOURCE                                                                           ,
    Case  When ACTIVITY.SOURCE = 'RFOR'
            Then 1
          When ACTIVITY.SOURCE = 'CHO'
            Then 2
          Else 3
    End                                     As PRIO
  From
    ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 As RefId
    Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_ACTIVITY As ACTIVITY
      On    RefId.INT_OPRTR_ID    =   ACTIVITY.CUID
        And RefId.INTRCTN_TS      >=  ACTIVITY.START_ACTIVITY_TS
        And RefId.INTRCTN_TS      <=  ACTIVITY.END_ACTIVITY_TS
  Where
    (1=1)
Qualify Row_number() over
              (Partition by
                  RefId.ACTE_ID                                                                                                 ,
                  RefId.INTRCTN_DT
               Order By
                  PRIO ASC                                                                                                      ,
                  ACTIVITY.START_ACTIVITY_TS Desc                                                                               ,
                  ACTIVITY.END_ACTIVITY_TS Desc
              ) = 1
 ) RefAct
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_JRC_ACT;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------------------------------------------------------------
--Etape 4-- Traitement des réseaux GDT et boutiques en s'appuyant sur OPRTR_TEAM_ACTVT_ID
---------------------------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL
(
  ACTE_ID                                                                                                                       ,
  INTRCTN_DT                                                                                                                    ,
  ORG_CHANNEL_CD                                                                                                                ,
  ORG_SUB_CHANNEL_CD                                                                                                            ,
  ORG_SUB_SUB_CHANNEL_CD                                                                                                        ,
  ORG_GT_ACTIVITY                                                                                                               ,
  ORG_REM_CHANNEL_CD                                                                                                            ,
  ORG_FIDELISATION                                                                                                              ,
  ORG_WEB_ACTIVITY                                                                                                              ,
  ORG_AUTO_ACTIVITY                                                                                                             ,
  EDO_ID                                                                                                                        ,
  ORG_TEAM_TYPE_ID                                                                                                              ,
  UNIFIED_SHOP_CD                                                                                                               ,
  NETWRK_TYP_EDO_ID                                                                                                             ,
  FLAG_PLT_CONV_NB                                                                                                              ,
  FLAG_PLT_SCH_IN                                                                                                               ,
  FLAG_TYPE_GEO_CD                                                                                                              ,
  FLAG_TYPE_CPT_NTK                                                                                                             ,
  FLAG_TYPE_PTN_NTK                                                                                                             ,
  FLAG_AD_SC                                                                                                                    ,
  PRIO
)

Select
  RefInt.ACTE_ID                                                                  As ACTE_ID                                    ,
  RefInt.INTRCTN_DT                                                               As INTRCTN_DT                                 ,
  -- Canal macro
  Case When FLAG_PLT_CONV_NB = 1 
    Then 'SCO'
       When FLAG_PLT_CONV_NB = 0 
    Then ORG_REM_CHANNEL_CD_AGR
    Else 'Exclus'
  End                                                                             As ORG_CHANNEL_CD_AGR                       ,
  
    --Sous Canal
  Case When FLAG_PLT_CONV_NB = 1
    Then 'Convergent'
       When FLAG_PLT_CONV_NB = 0 And ORG_CHANNEL_CD_AGR = 'SCO'
    Then 'Mobile'
       When FLAG_PLT_CONV_NB = 0 And ORG_CHANNEL_CD_AGR = 'SCH' 
    Then 'Home'
    Else 'Exclus'
  End                                                                             As ORG_SUB_CHANNEL_CD_AGR                   ,
  
  --Sous Sous Canal
  Case When Act.SOURCE = 'RFOR' And ORG_GT_ACTIVITY_AGR Like '%CTC%'
    Then 'CTC'
       When Act.SOURCE = 'RFOR' And ORG_GT_ACTIVITY_AGR Not Like '%CTC%'
    Then 'Front'
       When Act.SOURCE = 'CHO' And ORG_GT_ACTIVITY_AGR Like '%CTC%'
    Then 'CTC'
       When Act.SOURCE = 'CHO' And ORG_GT_ACTIVITY_AGR Like '%FRPREV%'
    Then 'Front Prevenance'
       When Act.SOURCE = 'CHO' And ORG_GT_ACTIVITY_AGR Not Like '%FRPREV%' 
                               And ORG_GT_ACTIVITY_AGR Not Like '%CTC%'
    Then 'Front'
    Else 'Exclus'
  End                                                                             As ORG_SUB_SUB_CHANNEL_CD                   ,
  
  -- GT/Activité 
  Case When Act.SOURCE In ('RFOR', 'CHO')And Act.ACTIVITY Like '%CTC%'
    Then Act.ACTIVITY
       When Act.SOURCE = 'RFOR' And Act.ACTIVITY Not Like '%CTC%'
    Then Act.ACTIVITY
       When Act.SOURCE = 'CHO' And Act.ACTIVITY Like '%FRPREV%' 
                               And ORG_SUB_CHANNEL_CD_AGR = 'Convergent'
    Then 'Front Prevenance Open'
       When Act.SOURCE = 'CHO' And Act.ACTIVITY Not Like '%FRPREV%'
                               And Act.ACTIVITY Not Like '%CTC%' 
                               And ORG_SUB_CHANNEL_CD_AGR = 'Convergent'
    Then 'Front Open'
       When Act.SOURCE = 'CHO' And Act.ACTIVITY Like '%FRPREV%' 
                               And ORG_SUB_CHANNEL_CD_AGR In ( 'Mobile', 'Home')
    Then 'Front Prevenance Mobile'
       When Act.SOURCE = 'CHO' And Act.ACTIVITY Not Like '%FRPREV%'
                               And Act.ACTIVITY Not Like '%CTC%' 
                               And ORG_SUB_CHANNEL_CD_AGR In ( 'Mobile', 'Home')
    Then 'Front Mobile'
    Else 'Exclus'
  End                                                                             As ORG_GT_ACTIVITY_AGR                      ,
  
  --Canal de Rem
  Case When Act.SOURCE = 'RFOR'
    Then 'SCH'
       When Act.SOURCE = 'CHO' And FLAG_PLT_SCH_IN = 1
    Then 'SCH'
       When Act.SOURCE = 'CHO' And FLAG_PLT_SCH_IN = 0
    Then 'SCO'
    Else 'Exclus'
  End                                                                             As ORG_REM_CHANNEL_CD_AGR                   ,
  Null                                                                            As ORG_FIDELISATION                         ,
  'omnicanal'                                                                     As ORG_WEB_ACTIVITY                         ,
  'NON'                                                                           As ORG_AUTO_ACTIVITY                        ,
  RefInt.ORG_EDO_ID                                                               As EDO_ID                                   ,
  Case When RefEdo.NETWRK_TYP_EDO_ID = 'FT' 
        Then 'Interne' 
        Else 'Externe'
  End                                                                             As ORG_TEAM_TYPE_ID                         ,
  Null                                                                            As UNIFIED_SHOP_CD                          ,
  Null                                                                            As NETWRK_TYP_EDO_ID                        ,
  ORGSC.FLAG_PLT_CONV_EQUI_TRAV                                                   As FLAG_PLT_CONV_NB                         ,
  ORGSC.FLAG_SCH_EQUI_TRAV                                                        As FLAG_PLT_SCH_IN                          ,
  Null                                                                            As FLAG_TYPE_GEO_CD                         ,
  Null                                                                            As FLAG_TYPE_CPT_NTK                        ,
  Null                                                                            As FLAG_TYPE_PTN_NTK                        ,
  0                                                                               As FLAG_AD_SC                               ,
  Case  When ORGSC.SOURCE = 'MCRM'
           Then 1
         When ORGSC.SOURCE = 'POCC'
           Then 2
         When ORGSC.SOURCE = 'HRF'
           Then 3
         When ORGSC.SOURCE = 'RFOR'
           Then 4
         When ORGSC.SOURCE = 'EDL'
           Then 5
         When ORGSC.SOURCE = 'OEE'
           Then 6
         Else 7
   End                                                                             As PRIO

From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 RefInt
   Left Outer Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORGSC
    On  RefInt.INT_OPRTR_ID   =   ORGSC.CUID
    And RefInt.INTRCTN_DT     >=  ORGSC.DT_DEBUT
    And RefInt.INTRCTN_DT     <=  ORGSC.DT_FIN
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_JRC_ACT Act
    On  RefInt.ACTE_ID        =   Act.ACTE_ID
    And RefInt.INTRCTN_DT     =   Act.INTRCTN_DT
  Left Outer Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
    On  RefInt.ORG_EDO_ID     =   RefEdo.EDO_ID
    And RefEdo.CURRENT_IN     =   1

Where
  (1=1)
  And RefInt.APPLI_SOURCE_ID In ('MCR', 'OEE', 'CHO')
Qualify Row_number() over (Partition by RefInt.ACTE_ID,RefInt.INTRCTN_DT Order By Prio Asc,
                                                                         ORGSC.DT_DEBUT Desc,
                                                                         ORGSC.EDO_ID_EQUI_RAT Asc,
                                                                         ORGSC.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------------------------------------------------------------
--Etape 5-- Détermination de l'activité H2H
---------------------------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL
(
  ACTE_ID                                                                                                                       ,
  INTRCTN_DT                                                                                                                    ,
  ORG_CHANNEL_CD                                                                                                                ,
  ORG_SUB_CHANNEL_CD                                                                                                            ,
  ORG_SUB_SUB_CHANNEL_CD                                                                                                        ,
  ORG_GT_ACTIVITY                                                                                                               ,
  ORG_REM_CHANNEL_CD                                                                                                            ,
  ORG_FIDELISATION                                                                                                              ,
  ORG_WEB_ACTIVITY                                                                                                              ,
  ORG_AUTO_ACTIVITY                                                                                                             ,
  EDO_ID                                                                                                                        ,
  ORG_TEAM_TYPE_ID                                                                                                              ,
  UNIFIED_SHOP_CD                                                                                                               ,
  NETWRK_TYP_EDO_ID                                                                                                             ,
  FLAG_PLT_CONV_NB                                                                                                              ,
  FLAG_PLT_SCH_IN                                                                                                               ,
  FLAG_TYPE_GEO_CD                                                                                                              ,
  FLAG_TYPE_CPT_NTK                                                                                                             ,
  FLAG_TYPE_PTN_NTK                                                                                                             ,
  FLAG_AD_SC                                                                                                                    ,
  PRIO
)

Select
  RefInt.ACTE_ID                                                          As ACTE_ID                                            ,
  RefInt.INTRCTN_DT                                                       As INTRCTN_DT                                         ,
    --Canal de vente Macro = Dist
  Case when RefEDO.FLAG_PLT_AD = 1 or   RefEDO.NETWRK_TYP_EDO_ID = 'RP'
       Then 'Dist'
       Else 'Exclus'
  End                                                                     As ORG_CHANNEL_CD_AGR                                 ,
    --Sous Canal
  Case  When ORG_CHANNEL_CD_AGR ='Dist' 
          Then 
                Case when   RefEdoAxs.CANAL = 'SUB_CHANNEL'
                           Then RefEdoAxs.SUB_CHANNEL
                End
        Else 'Exclus'
  End                                                                     As ORG_SUB_CHANNEL_CD_AGR                             ,
  --Sous Sous Canal
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then
                Case When   RefEdoAxs.CANAL = 'SUB_SUB_CHANNEL'
                   Then RefEdoAxs.SUB_SUB_CHANNEL
                   Else 'Metropole'
              End
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then
                Case When   RefEdoAxs.CANAL = 'SUB_SUB_CHANNEL'
                   Then RefEdoAxs.SUB_SUB_CHANNEL
                   Else 'Metropole'
              End
        Else 'Exclus'
  End                                                                     As ORG_SUB_SUB_CHANNEL_CD                             ,
  -- GT/Activité
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'Boutique FT'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'GDT'
        Else 'Exclus'
  End                                                                     As ORG_GT_ACTIVITY                                    ,

  --Canal de Rem
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'AD'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'Exclus'
        Else 'Exclus'
 End                                                                      As ORG_REM_CHANNEL_CD                                 ,





  Null                                                                    As ORG_FIDELISATION                                   ,
  'omnicanal'                                                             As ORG_WEB_ACTIVITY                                   ,
  'NON'                                                                   As ORG_AUTO_ACTIVITY                                  ,
  RefEDO.EDO_ID                                                           As EDO_ID                                             ,

  -- Équipes Internes / Équipes Externes.
  Case When ORG_SUB_CHANNEL_CD_AGR='AD'
        Then 'Interne'
        Else 'Externe'
  End                                                                     As ORG_TEAM_TYPE_ID                                   ,
  Null                                                                    As UNIFIED_SHOP_CD                                    ,
  RefEDO.NETWRK_TYP_EDO_ID                                                As NETWRK_TYP_EDO_ID                                  ,
  RefEDO.FLAG_PLT_CONV                                                    As FLAG_PLT_CONV_NB                                   ,
  RefEDO.FLAG_PLT_SCH                                                     As FLAG_PLT_SCH_IN                                    ,
  RefEDO.FLAG_TYPE_GEO                                                    As FLAG_TYPE_GEO_CD                                   ,
  RefEDO.FLAG_TYPE_CPT_NTK                                                As FLAG_TYPE_CPT_NTK                                  ,
  RefEDO.FLAG_TYPE_PTN_NTK                                                As FLAG_TYPE_PTN_NTK                                  ,
  1                                                                       As FLAG_AD_SC                                         ,
  1                                                                       As Prio

From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 RefInt
  Left Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    Cast(Trim (Coalesce (RefInt.OPRTR_TEAM_ACTVT_ID,RefInt.OPRTR_TEAM_HIERCH_ID)) As BigInt)    = RefEDO.EDO_ID
    And   RefInt.INTRCTN_DT              Between RefEDO.START_EXTNL_VAL_DT
    And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Left Outer Join
    (
      Select
        EdoAx.EDO_ID                    As EDO_ID             ,
        EdoAx.VAL_AXS_CLSSF_ID          As VAL_AXS_CLSSF_ID   ,
        EdoAx.START_VAL_AXS_DT          As START_VAL_AXS_DT   ,
        EdoAx.END_VAL_AXS_DT            As END_VAL_AXS_DT     ,
        Case When VAL_AXS_CLSSF_ID  In ('PST', 'PSE')
          Then 'RP'
          Else 'AD'
        End                             As SUB_CHANNEL        ,
        'NA'                            As SUB_SUB_CHANNEL    ,
        'SUB_CHANNEL'                   As CANAL              
      From
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
        And EdoAx.VAL_AXS_CLSSF_ID  In ('PST', 'PSE','BTQ')
        
        Union All
        
        Select
        EdoAx.EDO_ID                    As EDO_ID             ,
        EdoAx.VAL_AXS_CLSSF_ID          As VAL_AXS_CLSSF_ID   ,
        EdoAx.START_VAL_AXS_DT          As START_VAL_AXS_DT   ,
        EdoAx.END_VAL_AXS_DT            As END_VAL_AXS_DT     ,
        'NA'                            As SUB_CHANNEL        ,
        'Dom'                           As SUB_SUB_CHANNEL    ,
        'SUB_SUB_CHANNEL'               As CANAL              

      From
        ${KNB_SOC_O3}.V_ORG_H_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
        And EdoAx.VAL_AXS_CLSSF_ID  In ('REUNION','CARAIBES')

      ) RefEdoAxs

  On  RefEDO.EDO_ID   = RefEdoAxs.EDO_ID
    And RefInt.INTRCTN_DT >= RefEdoAxs.START_VAL_AXS_DT
    And RefInt.INTRCTN_DT < Coalesce(RefEdoAxs.END_VAL_AXS_DT, Cast('99991231' as Date Format 'YYYYMMDD'))

Where
  (1=1)
  And (RefInt.OPRTR_TEAM_ACTVT_ID Is Not Null
      Or RefInt.OPRTR_TEAM_HIERCH_ID Is Not Null
      )
  And RefInt.APPLI_SOURCE_ID In ('H2H')

Qualify Row_number() over (Partition by RefInt.ACTE_ID,RefInt.INTRCTN_DT Order By RefEDO.EDO_ID Asc) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_CHANNEL;
.if errorcode <> 0 then .quit 1
