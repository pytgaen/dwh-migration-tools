-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_VAD_Acte_Consolidation_Step2_CalculPerennitePVCSegmentOptionACQ.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul de Perennite PVC Segment Option ACQ
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 06/02/2014      AID         Indus
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEEK_SEG_SO All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEEK_SEG_SO
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PAR_IMSI                ,
  SEG_COM_ID              ,
  TYPE_SERVICE            ,
  TYPE_COMMANDE           ,
  TYPE_OT_SO              
)
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.DATE_SAISIE                      as INT_DEPOSIT_DT         ,
  Acte.PAR_IMSI                         as PAR_IMSI               ,
  Acte.SEG_COM_ID                       as SEG_COM_ID             ,
  Acte.TYPE_SERVICE                     as TYPE_SERVICE           ,
  'ACQ'                                 as TYPE_COMMANDE          ,
  Acte.TYPE_PRODUIT                     as TYPE_OT_SO             
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD Acte
Where
  (1=1)
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID             Not In ('NS','OPTTECH','OPT_INC')
  And Acte.TYPE_PRODUIT           in ('SO')
  And Acte.PAR_IMSI               Is Not Null
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEEK_SEG_SO;
.if errorcode <> 0 then .quit 1



-------------------------------------------------------------------------------------------
--Step 2 :  On realise la recherche en parc
-------------------------------------------------------------------------------------------
Delete from ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEG_SO_ACQ all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEG_SO_ACQ
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PAR_IMSI                    ,
  SEG_COM_ID                  ,
  TYPE_SERVICE                ,
  REALZTN_DT                  ,
  CANCELLNG_DT                ,
  NB_DAY_IN_PARC              ,
  DATE_IN_PARC_NEXT           ,
  NB_DAY_OUT_PARC_CUR_NEXT    ,
  DATE_OUT_PARC_NEXT          ,
  DATE_IN_PARC_FINAL          ,
  DATE_OUT_PARC_FINAL         ,
  NB_IN_OUT_PARC              ,
  NB_DAY_OUT_PARC             ,
  DUREE_TOTAL                 ,
  NB_DAY_PARC_TOTAL           ,
  POURCENTAGE_PRES_PARC       
)
Select
  Tmp.ACTE_ID                                                                 as ACTE_ID                  ,
  Tmp.INT_DEPOSIT_DT                                                          as INT_DEPOSIT_DT           ,
  Tmp.PAR_IMSI                                                                as PAR_IMSI                 ,
  Tmp.SEG_COM_ID                                                              as SEG_COM_ID               ,
  Tmp.TYPE_SERVICE                                                            as TYPE_SERVICE             ,
  Tmp.REALZTN_DT                                                              as REALZTN_DT               ,
  Tmp.CANCELLNG_DT                                                            as CANCELLNG_DT             ,
  Case  When Tmp.CANCELLNG_DT = '29991231'
          Then 999999
        Else (Tmp.CANCELLNG_DT - Tmp.REALZTN_DT)
  End                                                                         as NB_DAY_IN_PARC           ,
  Tmp.DATE_IN_PARC_NEXT                                                       as DATE_IN_PARC_NEXT        ,
  Tmp.NB_DAY_OUT_PARC_TMP                                                     as NB_DAY_OUT_PARC_CUR_NEXT ,
  Tmp.DATE_OUT_PARC_NEXT                                                      as DATE_OUT_PARC_NEXT       ,
  Tmp.DATE_IN_PARC_FINAL                                                      as DATE_IN_PARC_FINAL       ,
  Tmp.DATE_OUT_PARC_FINAL                                                     as DATE_OUT_PARC_FINAL      ,
  --Indicateur le nombre de fois ou le client apres l'acte à fait une entrée sortie de parc
  Max(NUMBER_LINE)      Over (Partition by Tmp.ACTE_ID)                       as NB_IN_OUT_PARC           ,
  --Indicateur le nombre de jour que le client à passer out du parc
  Sum(NB_DAY_OUT_PARC_TMP)  Over (Partition by Tmp.ACTE_ID)                   as NB_DAY_OUT_PARC          ,
  Case  When DATE_OUT_PARC_FINAL = '29991231'
          --Dans le cas de la valeur par défaut alors on met la date courrante
          Then (Current_date - Tmp.REALZTN_DT)
          --Sinon on prend la date de fin de parc
        Else  (Coalesce(Tmp.DATE_OUT_PARC_FINAL,Tmp.CANCELLNG_DT)  - Tmp.REALZTN_DT)
  End                                                                         as DUREE_TOTAL              ,
  (DUREE_TOTAL - NB_DAY_OUT_PARC)                                             as NB_DAY_PARC_TOTAL        ,
  Case  When DUREE_TOTAL = 0
          Then 0
        Else  Cast(NB_DAY_PARC_TOTAL as decimal(15,2))*100 / DUREE_TOTAL
  End                                                                         as POURCENTAGE_PRES_PARC    
From
  (
    Select
      Refid.ACTE_ID                 as ACTE_ID            ,
      Refid.INT_DEPOSIT_DT          as INT_DEPOSIT_DT     ,
      Refid.PAR_IMSI                as PAR_IMSI           ,
      Refid.SEG_COM_ID              as SEG_COM_ID         ,
      Refid.TYPE_SERVICE            as TYPE_SERVICE       ,
      --On récupère les dates  D'entrée et fin de parc
      ParcSeg.PARC_BEGIN_DT         as REALZTN_DT         ,
      ParcSeg.PARC_END_DT           as CANCELLNG_DT       ,
      --On récupère la date de réentré en parc suivant :
      Max(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    Refid.ACTE_ID           
                                          order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                      )         as DATE_IN_PARC_NEXT  ,
      --On calcul le nombre de jour entre la date de fin de parc et sa réentré en parc
      Case  When DATE_IN_PARC_NEXT is Not Null And ParcSeg.PARC_END_DT is Not Null
              Then (DATE_IN_PARC_NEXT - ParcSeg.PARC_END_DT)
            Else 0
      End                           as NB_DAY_OUT_PARC_TMP,
      Max(ParcSeg.PARC_END_DT) Over  (  Partition by    Refid.ACTE_ID           
                                             order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 following and 1 following
                                      )         as DATE_OUT_PARC_NEXT  ,
      Max(ParcSeg.PARC_BEGIN_DT)   Over (  Partition by    Refid.ACTE_ID           
                                          order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 Following and Unbounded Following
                                    )         as DATE_IN_PARC_FINAL  ,
      Max(ParcSeg.PARC_END_DT) Over (  Partition by  Refid.ACTE_ID           
                                          order by    ParcSeg.PARC_BEGIN_DT asc rows Between 1 Following and Unbounded Following
                                    )         as DATE_OUT_PARC_FINAL  ,
      Row_Number()              Over (  Partition by Refid.ACTE_ID
                                          Order by ParcSeg.PARC_BEGIN_DT asc
                                     ) as NUMBER_LINE
    From
      ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEEK_SEG_SO Refid
      Inner Join ${KNB_PCO_TMP}.INB_W_PARC_MOB_RCI_SEG_FUS_SO ParcSeg
        On    Refid.PAR_IMSI                          = ParcSeg.DOSSIER_NU_IMSI
          And Refid.SEG_COM_ID                        = ParcSeg.SEG_COM_ID
    Where
      (1=1)
      And Refid.INT_DEPOSIT_DT    <= ParcSeg.PARC_BEGIN_DT
  )Tmp
Where
  (1=1)
Qualify Tmp.NUMBER_LINE=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_VAD_SEG_SO_ACQ;
.if errorcode <> 0 then .quit 1



.quit 0


