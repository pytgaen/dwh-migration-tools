-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_CRS_Acte_Alimentation_Step2_CalculActe.sql $
-- TYPE         : Script SQL                                                       
-- DESCRIPTION  : SQL de transformation d'acte CRS
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 31/12/2014      OCH         Creation
-- 12/04/2016      MDE         Evol  : profondeur calcul 100 jrs
-- 23/11/2017      MEL         Ajout indicateur IOBSP                                                    
-- 13/02/2018      JCR         Correction axe canal                                                      
-- 22/10/2019      SSI         Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
-- 27/11/2019      GRH         Modification de l'alimentation  PAR_CA_LINE_AM                   
-- 15/04/2020      YAB         Modification de l'alimentation KPI2020 ACT_DELTA_TARIF (KPI2020)        
-------------------------------------------------------------------------------------------------------- 

.set width 2500;

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_C_CRS All;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_C_CRS
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_ID                          ,
  INTRNL_SOURCE_ID                  ,
  ORDER_NATURE_CD                   ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_PRODUCT_DS_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  PAR_CA_AM                         ,
  PAR_CA_LINE_AM                    ,
  ORG_ADV_STORE_CD                  ,
  FLAG_HD                           ,
  ORG_CHANEL_CD                     ,
  ORG_SUB_CHANEL_CD                 ,
  ORG_SUB_SUB_CHANEL_CD             ,
  ORG_REM_CHANEL_CD                 ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_TYPE_GEO_IN                   ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_LAST_NAME_NM                  ,
  ORG_FIRST_NAME_NM                 ,
  PAR_CID_ID                        ,
  PAR_PID_ID                        ,
  PAR_FIRST_IN                      ,
  ORG_AGENT_IOBSP                   ,
  ORG_EDO_IOBSP                     ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REAL_ID                 ,
  ORG_RESP_REF_TRAV_ID              ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  ORG_TYPE_CD                       ,
  ORG_TEAM_LEVEL_1_CD               ,
  ORG_TEAM_LEVEL_1_DS               ,
  ORG_TEAM_LEVEL_2_CD               ,
  ORG_TEAM_LEVEL_2_DS               ,
  ORG_TEAM_LEVEL_3_CD               ,
  ORG_TEAM_LEVEL_3_DS               ,
  ORG_TEAM_LEVEL_4_CD               ,
  ORG_TEAM_LEVEL_4_DS               ,
  WORK_TEAM_LEVEL_1_CD              ,
  WORK_TEAM_LEVEL_1_DS              ,
  WORK_TEAM_LEVEL_2_CD              ,
  WORK_TEAM_LEVEL_2_DS              ,
  WORK_TEAM_LEVEL_3_CD              ,
  WORK_TEAM_LEVEL_3_DS              ,
  WORK_TEAM_LEVEL_4_CD              ,
  WORK_TEAM_LEVEL_4_DS              ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  PAR_LAST_NAME_CUSTOMER_NM         ,
  PAR_FIRST_NAME_CUSTOMER_NM        ,
  PAR_MISISDN_ID                    ,
  PAR_ND_ID                         ,
--- Ajout champs KPI 2020
  CODE_EAN                          ,
  IMEI_CD                           ,
  DOM_TYPE                          ,
------------
  PAR_NDIP_ID                       ,
  PAR_TYPE_CUSTOMER_CD              ,
  PAR_TYPE_SOURCE_CD                ,
  PAR_ENGAGMNT_NB                   ,
  PAR_OSCAR_VALUE_CD                ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLOSURE_DT                        ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                         As ACTE_ID                            ,
  Placement.ACTE_ID                                         As ACTE_ID_GEN                        ,
  Placement.ORDER_DEPOSIT_DT                                As ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                As ORDER_DEPOSIT_TS                   ,
  Placement.ORDER_ID                                        As ORDER_ID                           ,
  Placement.INTRNL_SOURCE_ID                                As INTRNL_SOURCE_ID                   ,
  Null                                                      As ORDER_NATURE_CD                    ,
  Acte.PRODUCT_ID_PRE                                       As ACT_PRODUCT_ID_PRE                 ,
  Null                                                      As ACT_PRODUCT_DS_PRE                 ,
  Acte.SEG_COM_ID_PRE                                       As ACT_SEG_COM_ID_PRE                 ,
  Acte.CODE_MIGR_PRE                                        As ACT_CODE_MIGR_PRE                  ,
  Acte.SEG_COM_AGG_ID_PRE                                   As ACT_SEG_COM_AGG_ID_PRE             ,
  Null                                                      As ACT_OPER_ID_PRE                    ,
  Acte.PRODUCT_ID_FINAL                                     As ACT_PRODUCT_ID_FINAL               ,
  Null                                                      As ACT_PRODUCT_DS_FINAL               ,
  Acte.SEG_COM_ID_FINAL                                     As ACT_SEG_COM_ID_FINAL               ,
  Acte.SEG_COM_AGG_ID_FINAL                                 As ACT_SEG_COM_AGG_ID_FINAL           ,
  Acte.CODE_MIGR_FINAL                                      As ACT_CODE_MIGR_FINAL                ,
  Null                                                      As ACT_OPER_ID_FINAL                  ,
  Acte.TYPE_SERVICE_FINAL                                   As ACT_TYPE_SERVICE_FINAL             ,
  Coalesce(Acte.TYPE_COMMANDE_ID, '${P_PIL_026}')           As ACT_TYPE_COMMANDE_ID               ,
  --Unité = NB
  Case When Acte.UNITE_CD ='${P_PIL_620}'
          then
            case When ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
                  Then
                    case When Placement.DOM_TYPE ='R'
                           Then Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT,0)
                         When Placement.DOM_TYPE ='C' 
                           Then Placement.CA_HT
                    End
                Else null
            End
   --Unité = CA
       When Acte.UNITE_CD='${P_PIL_490}'
           then Placement.CA_HT
    --Unité  CA_MARKET
      When Acte.UNITE_CD ='${P_PIL_623}'
           then Acte.CA_MARKETING 
    --Unité  CA_Calipco
      When Acte.UNITE_CD ='${P_PIL_622}'
          Then 
                Case when Placement.DOM_TYPE ='R'
                        Then  Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT,0)
                      When Placement.DOM_TYPE ='C'
                        Then Placement.CA_HT
                End
      Else null
  END                                                       as ACT_DELTA_TARIF                    ,
  Acte.unite_cd                                             as ACT_UNITE_CD                       ,
  Acte.ACT_CD                                               As ACT_CD                             ,
  Coalesce(Acte.ACTE_REM_ID,'${P_PIL_067}')                 As ACT_REM_ID                         ,
  Coalesce(Acte.FLAG_ACT_REM,'N')                           As ACT_FLAG_ACT_REM                   ,
  Coalesce(Acte.FLAG_PEC_PERPVC,'N')                        As ACT_FLAG_PEC_PERPVC                ,
  Case When Acte.UNITE_CD ='${P_PIL_620}'
         Then Acte.ACTE_VALO
  --Unité  CA_MARKET et CA_Calipso
       When Acte.UNITE_CD in ('${P_PIL_490}','${P_PIL_623}','${P_PIL_622}') 
         Then ( ACT_DELTA_TARIF * Acte.TAUX_MARGE ) 
       Else   Coalesce(Acte.ACTE_VALO,0)
  End                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Acte.ACTE_FAMILLE_KPI,'NON PARAM')               As ACT_ACTE_FAMILLE_KPI               ,
  Periode.PERIODE_ID                                        As ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                 as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            as ACT_PERIODE_CLOSURE_DT             ,
  Null                                                      As PAR_CA_AM                          ,
  --Placement.CA_HT                                         As PAR_CA_LINE_AM                     ,
    ACT_DELTA_TARIF                                         As PAR_CA_LINE_AM                     ,
  ADV_STORE_CD                                              As ORG_ADV_STORE_CD                   ,
  Acte.HUMAINDIGITAL                                        as FLAG_HD                            ,
  --Calcul du canal de vente Macro
  Case
        When  Coalesce(Placement.FLAG_PLT_AD_IN,0)  = 1
          Then 'Dist'
        When Coalesce(Placement.FLAG_PLT_SCH_IN,0)  = 1
          Then 'SCH'
        When Placement.NETWRK_TYP_EDO_ID in ('RC', 'RP')
          Then 'Dist'
        Else 'CCO'
  End                                                       As ORG_CHANEL_CD                     ,
  --Sous Canal
  Case
        When ORG_CHANEL_CD ='Dist'
          Then 
          Case  When Placement.NETWRK_TYP_EDO_ID = 'FT'
                Then 'AD'
                Else Placement.NETWRK_TYP_EDO_ID
            End
        Else Case  when Coalesce(Placement.FLAG_PLT_CONV_IN,0)  = 1
                    Then 'Convergent'
                   Else
                      Case  When Coalesce(Placement.FLAG_PLT_SCH_IN,1)  = 1
                              Then 'Home'
                             Else 'Mobile'
                      End
            End
  End                                                       As ORG_SUB_CHANEL_CD                 ,
  --Sous-Sous-Canal
  Case
        When ORG_CHANEL_CD ='Dist'
          Then
            Case
              When Placement.FLAG_TYPE_GEO_IN is not null
                Then 'DOM'
              Else 'Metropole'
            end
          Else 
              Case  
               When ORG_CHANEL_CD ='SCH' or ORG_CHANEL_CD ='CCO'
                 Then 'Front'
                Else 'NONPARAM'
               End
  End                                                       As ORG_SUB_SUB_CHANEL_CD             ,
  --Canal de Rem
  Case
        When ORG_CHANEL_CD ='Dist'
          Then  Case  When Placement.NETWRK_TYP_EDO_ID = 'FT'
                    Then 'AD'
                    Else 'Exclus'
                End
         Else
            Case  When Coalesce(Placement.FLAG_PLT_SCH_IN,1)  = 1
                Then 'SCH'
              Else 'CCO'
            End              
  End                                                       As ORG_REM_CHANEL_CD                 ,
  --Activite
  Case
        When Placement.NETWRK_TYP_EDO_ID = 'FT' And ORG_CHANEL_CD ='Dist'
          Then 'Boutique FT'
        When Placement.FLAG_TYPE_GEO_IN Is Not Null And ORG_CHANEL_CD ='Dist'
          Then Placement.FLAG_TYPE_GEO_IN
        Else 'Front Mobile'
  End                                                       As ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  'NONPARAM'                                                As ORG_FIDELISATION                   ,
  --Activite Web
  'NON'                                                     As ORG_WEB_ACTIVITY                   ,
  --Activite AutoActeique
  'NON'                                                     As ORG_AUTO_ACTIVITY                  ,
  Placement.EDO_ID                                          As ORG_EDO_ID                         ,
  Placement.TYPE_EDO_ID                                     As ORG_TYPE_EDO                       ,
  Placement.NETWRK_TYP_EDO_ID                               As ORG_NETWRK_TYP_EDO_ID              ,
  Placement.FLAG_PLT_CONV_IN                                As ORG_FLAG_PLT_CONV                  ,
  Placement.FLAG_TEAM_MKT_IN                                As ORG_FLAG_TEAM_MKT                  ,
  Placement.FLAG_TYPE_CMP_IN                                As ORG_FLAG_TYPE_CMP                  ,
  Placement.FLAG_TYPE_GEO_IN                                As ORG_TYPE_GEO_IN                    ,
  Placement.FLAG_TYPE_CPT_NTK_IN                            As ORG_FLAG_TYPE_CPT_NTK              ,
  Null                                                      As ORG_REF_TRAV                       ,
  Placement.AGENT_ID                                        As ORG_AGENT_ID                       ,
  Null                                                      As ORG_POC_XI                         ,
  Coalesce(RetourGRV.AGENT_ID_UPD,Placement.AGENT_ID)       As ORG_AGENT_ID_UPD                   ,
  Cast(RetourGRV.AGENT_ID_UPD_TS as date Format 'YYYYMMDD') As ORG_AGENT_ID_UPD_DT                ,
  Coalesce(RetourGRV.ORG_NOM,Placement.AGENT_LAST_NAME_NM)  As ORG_LAST_NAME_NM                   ,
  Coalesce(RetourGRV.ORG_PRENOM,Placement.AGENT_FIRST_NAME_NM) As ORG_FIRST_NAME_NM                ,
  Placement.PAR_CID_ID                                      As PAR_CID_ID                          ,
  Placement.PAR_PID_ID                                      As PAR_PID_ID                          ,
  Placement.PAR_FIRST_IN                                    As PAR_FIRST_IN                        ,
  Placement.ORG_AGENT_IOBSP                                 As ORG_AGENT_IOBSP                     ,
  Placement.ORG_EDO_IOBSP                                   As ORG_EDO_IOBSP                       ,
  Null                                                      As ORG_GROUPE_ID                      ,
  -- Calcul de l'activitee
  Null                                                      As ORG_ACTVT_REAL_ID                  ,
  Null                                                      As ORG_RESP_REF_TRAV_ID               ,
  Null                                                      As ORG_RESP_AGENT_ID                  ,
  Null                                                      As ORG_RESP_XI                        ,
  -- Calcul des EDO 
  Null                                                      As ORG_TYPE_CD                        ,
  Placement.EDO_ID                                          As ORG_TEAM_LEVEL_1_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_1_DS                ,
  Null                                                      As ORG_TEAM_LEVEL_2_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_2_DS                ,
  Null                                                      As ORG_TEAM_LEVEL_3_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_3_DS                ,
  Null                                                      As ORG_TEAM_LEVEL_4_CD                ,
  Null                                                      As ORG_TEAM_LEVEL_4_DS                ,
  WORKO3ENR.WORK_TEAM_LEVEL_1_CD                            As WORK_TEAM_LEVEL_1_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_1_DS                            As WORK_TEAM_LEVEL_1_DS               ,
  WORKO3ENR.WORK_TEAM_LEVEL_2_CD                            As WORK_TEAM_LEVEL_2_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_2_DS                            As WORK_TEAM_LEVEL_2_DS               ,
  WORKO3ENR.WORK_TEAM_LEVEL_3_CD                            As WORK_TEAM_LEVEL_3_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_3_DS                            As WORK_TEAM_LEVEL_3_DS               ,
  WORKO3ENR.WORK_TEAM_LEVEL_4_CD                            As WORK_TEAM_LEVEL_4_CD               ,
  WORKO3ENR.WORK_TEAM_LEVEL_4_DS                            As WORK_TEAM_LEVEL_4_DS               ,
  Placement.PAR_GEO_MACROZONE                               As PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                            As PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                           As PAR_PARTY_REGRPMNT_ID              ,
  Placement.CUSTOMER_LAST_NAME_NM                           As PAR_LAST_NAME_CUSTOMER_NM          ,
  Placement.CUSTOMER_FIRST_NAME_NM                          As PAR_FIRST_NAME_CUSTOMER_NM         ,
  Placement.CUSTOMER_MSISDN_ID                              As PAR_MISISDN_ID                     ,
  Placement.CUSTOMER_DN_ID                                  As PAR_ND_ID                          ,
  Placement.CODE_EAN                                        as CODE_EAN                           ,
  Placement.IMEI_CD                                         as IMEI_CD                            ,
  Placement.DOM_TYPE                                        as DOM_TYPE                           ,
  Null                                                      As PAR_NDIP_ID                        ,
  Placement.CUSTOMER_MARKET_SEG_CD                          As PAR_TYPE_CUSTOMER_CD               ,
  Placement.TYPE_SOURCE_ID                                  As PAR_TYPE_SOURCE_CD                 ,
  Null                                                      As PAR_ENGAGMNT_NB                    ,
  Null                                                      As PAR_OSCAR_VALUE_CD                 ,
  '${P_PIL_402}'                                            As CHECK_INITIAL_STATUS_CD            ,
  RetournCSO.CHECK_NAT_STATUS_CD                            As CHECK_NAT_STATUS_CD                ,
  RetournCSO.CHECK_NAT_COMMENT                              As CHECK_NAT_COMMENT                  ,
  RetournCSO.CHECK_NAT_STATUS_LN                            As CHECK_NAT_STATUS_LN                ,
  RetournCSO.CHECK_LOC_STATUS_CD                            As CHECK_LOC_STATUS_CD                ,
  RetournCSO.CHECK_LOC_COMMENT                              As CHECK_LOC_COMMENT                  ,
  RetournCSO.CHECK_LOC_STATUS_LN                            As CHECK_LOC_STATUS_LN                ,
  RetournCSO.CHECK_VALIDT_DT                                As CHECK_VALIDT_DT                    ,
  Null                                                      As CLOSURE_DT                         ,
  '${KNB_DATE_VACATION}'                                    As CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                    As LAST_MODIF_TS                      ,
  0                                                         As HOT_IN                             ,
  1                                                         As FRESH_IN                           ,
  0                                                         As COHERENCE_IN                       
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_CRS Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Periode.PERIODE_DATE_FIN >= PLACEMENT.ORDER_DEPOSIT_DT
      And Periode.PERIODE_DATE_DEB <= PLACEMENT.ORDER_DEPOSIT_DT
      And Periode.CURRENT_IN=1
      And Periode.FRESH_IN=1
      And Periode.CLOSURE_DT is Null
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_REFCOM_MAT_JOUR_DECLA Acte
    On    Placement.ACT_REM_ID              = Acte.ACTE_REM_ID
      And Periode.PERIODE_ID                = Acte.PERIODE_ID
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_CRS_O3 WORKO3ENR 
    On    Placement.ACTE_ID                       = WORKO3ENR.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT              = WORKO3ENR.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID           = RetourGRV.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RetourGRV.ORDER_DEPOSIT_DT          
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID                       = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG           = 1
      And RetournCSO.CURRENT_IN                   = 1
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    Periode.PERIODE_ID                                   = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                               = 1
      And EtatPeriode.FRESH_IN                                 = 1
      And EtatPeriode.CLOSURE_DT                               Is Null
  Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB
   On EAN_Canal_WEB.EAN_CD = Placement.CODE_EAN
   And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format'DD/MM/YYYY'))
   And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM
  On  EAN_Canal_DOM.EAN_CD = Placement.CODE_EAN
  And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format'DD/MM/YYYY'))
  And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'

Where
  (1=1)
  And Placement.ORDER_DEPOSIT_DT >= Cast ( '01042015' as Date Format'DDMMYYYY')
  And Placement.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_536}) 
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ACT_T_ACTE_EXF_C;
.if errorcode <> 0 then .quit 1

