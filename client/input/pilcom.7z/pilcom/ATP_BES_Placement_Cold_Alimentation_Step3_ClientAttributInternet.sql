-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Cold_Alimentation_Step3_ClientAttributInternet.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL calcul  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/09/2015      MDE         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_CL_AT_INT all;
.if errorcode <> 0 then .quit 1

-----------------------------------------------------------
-- Calcul des Attributs Internet du client
-----------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_CL_AT_INT
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  PAR_AID                     ,
  PAR_ND
)
Select
  RefId.ACTE_ID                               as ACTE_ID                  ,
  RefId.ORDER_DEPOSIT_DT                      as ORDER_DEPOSIT_DT         ,
  --RÃ©cupÃ©ration de l'AID (id Bss du client) :
  Max (
        Case  When TfServTech.SRVTECH_CO_SERVBASE='${P_PIL_060}'
                Then Substr(Trim(TfServTech.SRVTECH_NU_TEL),2,Character_Length(TfServTech.SRVTECH_NU_TEL)-1)
              Else Null
        End
      )                                     as PAR_AID                ,
  --RÃ©cupÃ©ration du ND :
  Max (
        Case  When  TfServTech.SRVTECH_CO_SERVBASE='${P_PIL_061}'
                Then Trim(TfServTech.SRVTECH_NU_TEL)
              Else Null
        End
      )                                     as PAR_ND
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TFSRVTECH TfServTech
    On    RefId.CLIENT_NU                             =   TfServTech.SRVTECH_CLIENT_NU
      And RefId.DOSSIER_NU                            =   TfServTech.SRVTECH_DOSSIER_NU
Where
  (1=1)
  And ( RefId.PAR_AID Is Null Or RefId.PAR_ND Is null)
  And TfServTech.SRVTECH_CO_SERVBASE  In ('${P_PIL_060}','${P_PIL_061}')
  And TfServTech.SRVTECH_PLTF_CO      Not In ('${P_PIL_062}','${P_PIL_063}')
  And TfServTech.SRVTECH_IN_SRV_ACTIF = '${P_PIL_064}'
Group By
  RefId.ACTE_ID           ,
  RefId.ORDER_DEPOSIT_DT
 ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_CL_AT_INT;
.if errorcode <> 0 then .quit 1


.quit 0
