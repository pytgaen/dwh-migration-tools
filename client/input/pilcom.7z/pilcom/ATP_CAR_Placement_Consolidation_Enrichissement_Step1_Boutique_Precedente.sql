--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CAR_Placement_Consolidation_Enrichissement_Step1_Boutique_Precedente.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/07/2015      AOU         Creation
--------------------------------------------------------------------------------
.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_BTQ_PREC all;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_BTQ_PREC
(
  ACTE_ID                        ,
  ORD_DEPOSIT_DT                 , 
  ORD_DEPOSIT_TS                 ,
  ORD_TRACEUNI_TS                ,
  REDIRECTION_CD       
)
Select
  RefId.ACTE_ID                                                                                                                     As  ACTE_ID                       ,
  RefId.ORD_DEPOSIT_DT                                                                                                              As  ORD_DEPOSIT_DT                ,
  RefId.ORD_DEPOSIT_TS                                                                                                              As   ORD_DEPOSIT_TS                ,
  CAST (TRIM(TRIM(CAST (Tr.TRACEUNI_JOU_DT AS DATE FORMAT 'YYYY-MM-DD'))|| ' ' ||TRIM(Tr.TRACEUNI_LIB_HEUREPAS)) AS  TIMESTAMP(0))  As ORD_TRACEUNI_TS_AGR             ,
  tr.TRACEUNI_APPLICATION_EMET                                                                                                      As REDIRECTION_CD 
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_1 RefId
  Inner join ${KNB_IBU_SOC}.V_TFTRACEUNI Tr
   on RefId.DOSSIER_NU=Tr.TRACEUNI_NUM_MSISDN
Where
  (1=1)
  and RefId.TRACEUNI_NUM_SESSION  <> Tr.TRACEUNI_NUM_SESSION
  and Tr.TRACEUNI_CANAL_ID        not in ('1','8')
  and ORD_TRACEUNI_TS_AGR         < RefId.ORD_DEPOSIT_TS
  and ORD_TRACEUNI_TS_AGR         > (RefId.ORD_DEPOSIT_TS - interval '1' day)
Qualify row_number() over (PARTITION BY RefId.ACTE_ID order by ORD_TRACEUNI_TS_AGR desc) = 1 
; 
       

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_BTQ_PREC;
.if errorcode <> 0 then .quit 1
