-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_GEN_Alimentation_Ref_Orga_POCC_Step0_Ext.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 23/04/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table de travail                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_POCC All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table de travail                                                ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_POCC(
  SOURCE                    ,
  CUID                      ,
  NOM                       ,
  PRENOM                    ,
  DT_DEBUT                  ,
  DT_FIN                    ,
  RAT_ORGA_EQUI_CO_GRP      ,
  EDO_ID_EQUI_RAT           ,
  FLAG_SCH_EQUI_RAT         ,
  FLAG_HIER_EQUI_RAT        ,
  FLAG_PLT_CONV_EQUI_RAT    ,
  TRAV_ORGA_EQUI_CO_GRP     ,
  EDO_ID_EQUI_TRAV          ,
  FLAG_SCH_EQUI_TRAV        ,
  FLAG_HIER_EQUI_TRAV       ,
  FLAG_PLT_CONV_EQUI_TRAV
)

Select
  'POCC'                                                        as SOURCE                           ,
  POCC.UPPER_ID_FT                                              as CUID                             ,
  POCC.CSL_NOM                                                  as NOM                              ,
  POCC.CSL_PRENOM                                               as PRENOM                           ,
  POCC.CSLORGA_DT_DEB                                           as DT_DEBUT                         ,
  Coalesce(POCC.CSLORGA_DT_FIN, Cast('29991231000000' As Timestamp(0) Format 'YYYYMMDDHHMISS')) as DT_FIN   ,
  POCC.RAT_ORGA_EQUI_CO_GRP                                     as RAT_ORGA_EQUI_CO_GRP             ,
  Null                                                          as EDO_ID_EQUI_RAT                  ,
  Null                                                          as FLAG_SCH_EQUI_RAT                ,
  Null                                                          as FLAG_HIER_EQUI_RAT               ,
  Null                                                          as FLAG_PLT_CONV_EQUI_RAT           ,
  POCC.TRAV_ORGA_EQUI_CO_GRP                                    as TRAV_ORGA_EQUI_CO_GRP            ,
  Null                                                          as EDO_ID_EQUI_TRAV                 ,
  Null                                                          as FLAG_SCH_EQUI_TRAV               ,
  Null                                                          as FLAG_HIER_EQUI_TRAV              ,
  Null                                                          as FLAG_PLT_CONV_EQUI_TRAV
From 
  ${KNB_IBU_GLB_V}.VPOCCSLMAT POCC
Where
  POCC.RAT_ORGA_EQUI_CO_GRP Not Like 'NR'
    and POCC.TRAV_ORGA_EQUI_CO_GRP Not Like 'NR'

;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_POCC;
.if errorcode <> 0 then .quit 1
