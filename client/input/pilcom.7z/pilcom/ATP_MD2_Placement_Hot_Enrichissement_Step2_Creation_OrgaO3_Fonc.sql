-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_MD2_Placement_Hot_Enrichissement_Step2_Creation_OrgaO3_Fonc.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/08/2014      HFO         CREATION
--------------------------------------------------------------------------------

.set width 2500;



Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_VEND_O3 all;
.if errorcode <> 0 then .quit 1



------------------------------------------------------------------
-- Implémentation des RGs sur la recherche de l'EDO_ID fonctionnel EDO_ID_HIER
-- On recherche Ici le conseiller ayant réaliser la vente
-------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_VEND_O3
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_1 RefId
  Inner Join
    ${KNB_PCO_TMP}.ORG_W_Ref_O3_POCSC RefO3
    On    RefId.ORG_GROUPE_ID = RefO3.CODE_GRP_ID
      And RefId.INT_DEPOSIT_DT      >= RefO3.START_EXTNL_VAL_DT
      And RefId.INT_DEPOSIT_DT      <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
      And RefId.INT_DEPOSIT_DT      >= RefO3.OPEN_DT
      And RefId.INT_DEPOSIT_DT      <= RefO3.CLOSE_DT
Where
  (1=1)
  --And RefId.ORG_REF_TRAV    = 'POCSC'
  And RefId.ORG_GROUPE_ID   Is Not Null
  --Calcul pendant 200 jours
  --And RefId.EDO_ID          Is Null
Qualify Row_Number() Over(Partition by
                                        RefId.ACTE_ID,
                                        RefId.INT_DEPOSIT_DT
                          Order by
                                        RefO3.START_EXTNL_VAL_DT Desc,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc
                          )=1
;
.if errorcode <> 0 then .quit 1


--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHOH_VEND_O3;
.if errorcode <> 0 then .quit 1



.quit 0

