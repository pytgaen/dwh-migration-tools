--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ASO_ODS_Alim_ATP_F_TFCOMMARTICLE_PCM.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'd'alimentation de la table ATP_F_TFCOMMARTICLE_PCM
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 08/01/2014     XKN         Création
---------------------------------------------------------------------------------

.set width 5000

-----------------------------
-- ATP_F_TFCOMMARTICLE_PCM --
-----------------------------

DELETE FROM ${KNB_IBU_ODS}.ATP_F_TFCOMMARTICLE_PCM;
.if errorcode <> 0 then .quit 1

INSERT INTO ${KNB_IBU_ODS}.ATP_F_TFCOMMARTICLE_PCM
(
      COMMARTICLE_ID_BCR,
      COMMARTICLE_REFARTICLE,
      COMMARTICLE_ID_MODELE,
      COMMARTICLE_QUANTITE,
      COMMARTICLE_NBPOINTSUTIL,
      COMMARTICLE_COMPLEMENT,
      COMMARTICLE_CODEPRESTATION,
      COMMARTICLE_PRIXARTICLE,
      COMMARTICLE_MONTANTPRIME,
      COMMARTICLE_REFPRIX_OD,
      COMMARTICLE_REFPRIX_OA,
      CREATION_TS,
      LAST_MODIF_TS,
      FRESH_IN,
      COHERENCE_IN
)
SELECT 
      COMMARTICLE_ID_BCR,
      COMMARTICLE_REFARTICLE,
      COMMARTICLE_ID_MODELE,
      COMMARTICLE_QUANTITE,
      COMMARTICLE_NBPOINTSUTIL,
      COMMARTICLE_COMPLEMENT,
      COMMARTICLE_CODEPRESTATION,
      COMMARTICLE_PRIXARTICLE,
      COMMARTICLE_MONTANTPRIME,
      COMMARTICLE_REFPRIX_OD,
      COMMARTICLE_REFPRIX_OA,
      CREATION_TS,
      LAST_MODIF_TS,
      FRESH_IN,
      COHERENCE_IN
FROM ${KNB_IBU_TMP}.ATP_T_TFCOMMARTICLE;
.if errorcode <> 0 then .quit 1

COLLECT STATS ON ${KNB_IBU_ODS}.ATP_F_TFCOMMARTICLE_PCM;
.if errorcode <> 0 then .quit 1

