---$HEADER:   %HEADER%
------------------------------------------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_DIGITAL_SOFTI_Alimentation_ELIG_JRC_Recyclage.sql  $                                                  
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL  alimentation de la table ORD_W_SOFTI_ELIG_JRC_DIGITAL avec  les actes digitaux éligibles de ORD_F_ACTE_DIGITAL
--------------------------------------------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION 
--19/07/2019      GRH         CREATION              
--22/07/2019      GRH         MODIFICATION            
-------------------------------------------------------------------------------

.set width 5000
---les actes qui sont déjà  dans la [Table des actes digitaux]
--------------------------------------------------------------
-- Table : ORD_W_SOFTI_ELIG_JRC_DIGITAL-----------------------
--------------------------------------------------------------


merge Into ${KNB_PCO_TMP}.ORD_W_SOFTI_ELIG_JRC_DIGITAL  Tmp
Using
  (
Select
  SOFTI_DIGIT.CODE_PROCESS              As CODE_PROCESS                    ,
  SOFTI_DIGIT.INTRNL_SOURCE_ID          As INTRNL_SOURCE_ID                ,
  SOFTI_DIGIT.SOURCE_DS                 As SOURCE_DS                       ,
  SOFTI_DIGIT.ACT_ACTE_FAMILLE_KPI      As ACT_ACTE_FAMILLE_KPI            ,
  SOFTI_DIGIT.ACTE_ID                   As ACTE_ID                         ,
  SOFTI_DIGIT.ACT_DT                    As ACT_DT                          ,
  SOFTI_DIGIT.PAR_UNIFIED_PARTY_ID      As PAR_UNIFIED_PARTY_ID            ,
  SOFTI_DIGIT.PAR_PID_ID                As PAR_PID_ID                      ,
  SOFTI_DIGIT.PAR_CID_ID                As PAR_CID_ID                      ,
  SOFTI_DIGIT.IND_HD_TEMPO_CD           As IND_HD_TEMPO_CD                 ,
  SOFTI_DIGIT.IND_HD_TEMPO_DT           As IND_HD_TEMPO_DT                 ,
  SOFTI_DIGIT.RAP_PID_ID                As RAP_PID_ID                      ,
  SOFTI_DIGIT.RAP_UNIFIED_PARTY_ID      As RAP_UNIFIED_PARTY_ID            ,
  SOFTI_DIGIT.INTRCTN_DT                As INTRCTN_DT                      ,
  SOFTI_DIGIT.DELAI                     As DELAI                           ,
  SOFTI_DIGIT.ACTE_ID_INTRCTN           As ACTE_ID_INTRCTN                 ,
  SOFTI_DIGIT.INTRCTN_ID                As INTRCTN_ID                      ,
  SOFTI_DIGIT.KEYGEN_CD                 As KEYGEN_CD                       ,
  SOFTI_DIGIT.APPLI_SOURCE_ID           As APPLI_SOURCE_ID                 ,
  SOFTI_DIGIT.UNIFIED_PARTY_ID          As UNIFIED_PARTY_ID                ,
  SOFTI_DIGIT.PID_ID                    As PID_ID                          ,
  SOFTI_DIGIT.CID_ID                    As CID_ID                          ,
  SOFTI_DIGIT.INT_OPRTR_ID              As INT_OPRTR_ID                    ,
  SOFTI_DIGIT.ORG_AGENT_IOBSP           As ORG_AGENT_IOBSP                 ,
  SOFTI_DIGIT.OPRTR_TEAM_HIERCH_ID      As OPRTR_TEAM_HIERCH_ID            ,
  SOFTI_DIGIT.OPRTR_TEAM_ACTVT_ID       As OPRTR_TEAM_ACTVT_ID             ,
  SOFTI_DIGIT.UNVRS_CD                  As UNVRS_CD                        ,
  SOFTI_DIGIT.DIRCTN_CD                 As DIRCTN_CD                       ,
  SOFTI_DIGIT.CHANL_CD                  As CHANL_CD                        ,
  SOFTI_DIGIT.MEDIA_CD                  As MEDIA_CD                        ,
  SOFTI_DIGIT.ORIGN_CD                  As ORIGN_CD                        ,
  SOFTI_DIGIT.WAY_CD                    As WAY_CD                          ,
  SOFTI_DIGIT.REASN_CD                  As REASN_CD                        ,
  SOFTI_DIGIT.REASN_DETL_CD             As REASN_DETL_CD                   ,
  SOFTI_DIGIT.CONCLSN_CD                As CONCLSN_CD                      ,
  SOFTI_DIGIT.UNIFIED_SHOP_CD           As UNIFIED_SHOP_CD                 ,
  SOFTI_DIGIT.ORG_REM_CHANNEL_CD        As ORG_REM_CHANNEL_CD              ,
  SOFTI_DIGIT.ORG_CHANNEL_CD            As ORG_CHANNEL_CD                  ,
  SOFTI_DIGIT.ORG_SUB_CHANNEL_CD        As ORG_SUB_CHANNEL_CD              ,
  SOFTI_DIGIT.ORG_SUB_SUB_CHANNEL_CD    As ORG_SUB_SUB_CHANNEL_CD          ,
  SOFTI_DIGIT.ORG_GT_ACTIVITY           As ORG_GT_ACTIVITY                 ,
  SOFTI_DIGIT.ORG_FIDELISATION          As ORG_FIDELISATION                ,
  SOFTI_DIGIT.ORG_WEB_ACTIVITY          As ORG_WEB_ACTIVITY                ,
  SOFTI_DIGIT.ORG_AUTO_ACTIVITY         As ORG_AUTO_ACTIVITY               ,
  SOFTI_DIGIT.ORG_EDO_ID                As ORG_EDO_ID                      ,
  SOFTI_DIGIT.ORG_TYPE_EDO              As ORG_TYPE_EDO                    ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_1_CD       As ORG_TEAM_LEVEL_1_CD             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_1_DS       As ORG_TEAM_LEVEL_1_DS             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_2_CD       As ORG_TEAM_LEVEL_2_CD             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_2_DS       As ORG_TEAM_LEVEL_2_DS             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_3_CD       As ORG_TEAM_LEVEL_3_CD             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_3_DS       As ORG_TEAM_LEVEL_3_DS             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_4_CD       As ORG_TEAM_LEVEL_4_CD             ,
  SOFTI_DIGIT.ORG_TEAM_LEVEL_4_DS       As ORG_TEAM_LEVEL_4_DS             ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_1_CD      As WORK_TEAM_LEVEL_1_CD            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_1_DS      As WORK_TEAM_LEVEL_1_DS            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_2_CD      As WORK_TEAM_LEVEL_2_CD            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_2_DS      As WORK_TEAM_LEVEL_2_DS            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_3_CD      As WORK_TEAM_LEVEL_3_CD            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_3_DS      As WORK_TEAM_LEVEL_3_DS            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_4_CD      As WORK_TEAM_LEVEL_4_CD            ,
  SOFTI_DIGIT.WORK_TEAM_LEVEL_4_DS      As WORK_TEAM_LEVEL_4_DS            ,
  SOFTI_DIGIT.ANNUL_HD_DT               As ANNUL_HD_DT                     ,
  SOFTI_DIGIT.ANNUL_HD_DS               As ANNUL_HD_DS                     ,
  SOFTI_DIGIT.IND_HD_CD                 As IND_HD_CD                       ,
  SOFTI_DIGIT.IND_HD_RAP_CD             As IND_HD_RAP_CD                   ,
  SOFTI_DIGIT.HD_RAP_DT                 As HD_RAP_DT                       ,
  SOFTI_DIGIT.CREATION_TS               As CREATION_TS                     ,
  SOFTI_DIGIT.CLOSURE_DT                As CLOSURE_DT                      


from ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL as SOFTI_DIGIT                      


where
        SOFTI_DIGIT.ACT_DT             >=  Current_date - 100               
   And  SOFTI_DIGIT.CURRENT_IN         =  1
   And  SOFTI_DIGIT.SOURCE_DS          =  'SOFTI'

   ) SOFTI_DIGIT_ELIG
    on          Tmp.ACTE_ID      = SOFTI_DIGIT_ELIG.ACTE_ID                 
    And         Tmp.ACT_DT       = SOFTI_DIGIT_ELIG.ACT_DT

 When matched then

--  Les champs figés
  Update set

   RAP_PID_ID                   = SOFTI_DIGIT_ELIG.RAP_PID_ID                       ,
   RAP_UNIFIED_PARTY_ID         = SOFTI_DIGIT_ELIG.RAP_UNIFIED_PARTY_ID             ,
   INTRCTN_DT                   = SOFTI_DIGIT_ELIG.INTRCTN_DT                       ,
   DELAI                        = SOFTI_DIGIT_ELIG.DELAI                            ,
   ACTE_ID_INTRCTN              = SOFTI_DIGIT_ELIG.ACTE_ID_INTRCTN                  ,
   INTRCTN_ID                   = SOFTI_DIGIT_ELIG.INTRCTN_ID                       ,
   KEYGEN_CD                    = SOFTI_DIGIT_ELIG.KEYGEN_CD                        ,
   APPLI_SOURCE_ID              = SOFTI_DIGIT_ELIG.APPLI_SOURCE_ID                  ,
   UNIFIED_PARTY_ID             = SOFTI_DIGIT_ELIG.UNIFIED_PARTY_ID                 ,
   IND_HD_TEMPO_DT              = SOFTI_DIGIT_ELIG.IND_HD_TEMPO_DT                  ,
   PID_ID                       = SOFTI_DIGIT_ELIG.PID_ID                           ,
   CID_ID                       = SOFTI_DIGIT_ELIG.CID_ID                           ,
   INT_OPRTR_ID                 = SOFTI_DIGIT_ELIG.INT_OPRTR_ID                     ,
   ORG_AGENT_IOBSP              = SOFTI_DIGIT_ELIG.ORG_AGENT_IOBSP                  ,
   OPRTR_TEAM_HIERCH_ID         = SOFTI_DIGIT_ELIG.OPRTR_TEAM_HIERCH_ID             ,
   OPRTR_TEAM_ACTVT_ID          = SOFTI_DIGIT_ELIG.OPRTR_TEAM_ACTVT_ID              ,
   UNVRS_CD                     = SOFTI_DIGIT_ELIG.UNVRS_CD                         ,
   DIRCTN_CD                    = SOFTI_DIGIT_ELIG.DIRCTN_CD                        ,
   CHANL_CD                     = SOFTI_DIGIT_ELIG.CHANL_CD                         ,
   MEDIA_CD                     = SOFTI_DIGIT_ELIG.MEDIA_CD                         ,
   ORIGN_CD                     = SOFTI_DIGIT_ELIG.ORIGN_CD                         ,
   WAY_CD                       = SOFTI_DIGIT_ELIG.WAY_CD                           ,
   REASN_CD                     = SOFTI_DIGIT_ELIG.REASN_CD                         ,
   REASN_DETL_CD                = SOFTI_DIGIT_ELIG.REASN_DETL_CD                    ,
   CONCLSN_CD                   = SOFTI_DIGIT_ELIG.CONCLSN_CD                       ,
   IND_HD_CD                    = SOFTI_DIGIT_ELIG.IND_HD_CD                        ,
   IND_HD_RAP_CD                = SOFTI_DIGIT_ELIG.IND_HD_RAP_CD                    ,
   HD_RAP_DT                    = SOFTI_DIGIT_ELIG.HD_RAP_DT                        

   --les champs non figés
When Not Matched Then
  INSERT
(

  SOFTI_DIGIT_ELIG.CODE_PROCESS             ,
  SOFTI_DIGIT_ELIG.INTRNL_SOURCE_ID         ,
  SOFTI_DIGIT_ELIG.SOURCE_DS                ,
  SOFTI_DIGIT_ELIG.ACT_ACTE_FAMILLE_KPI     ,
  SOFTI_DIGIT_ELIG.ACTE_ID                  ,
  SOFTI_DIGIT_ELIG.ACT_DT                   ,
  SOFTI_DIGIT_ELIG.PAR_UNIFIED_PARTY_ID     ,
  SOFTI_DIGIT_ELIG.PAR_PID_ID               ,
  SOFTI_DIGIT_ELIG.PAR_CID_ID               ,
  SOFTI_DIGIT_ELIG.IND_HD_TEMPO_CD          ,
  SOFTI_DIGIT_ELIG.IND_HD_TEMPO_DT          ,
  SOFTI_DIGIT_ELIG.RAP_PID_ID               ,
  SOFTI_DIGIT_ELIG.RAP_UNIFIED_PARTY_ID     ,
  SOFTI_DIGIT_ELIG.INTRCTN_DT               ,
  SOFTI_DIGIT_ELIG.DELAI                    ,
  SOFTI_DIGIT_ELIG.ACTE_ID_INTRCTN          ,
  SOFTI_DIGIT_ELIG.INTRCTN_ID               ,
  SOFTI_DIGIT_ELIG.KEYGEN_CD                ,
  SOFTI_DIGIT_ELIG.APPLI_SOURCE_ID          ,
  SOFTI_DIGIT_ELIG.UNIFIED_PARTY_ID         ,
  SOFTI_DIGIT_ELIG.PID_ID                   ,
  SOFTI_DIGIT_ELIG.CID_ID                   ,
  SOFTI_DIGIT_ELIG.INT_OPRTR_ID             ,
  SOFTI_DIGIT_ELIG.ORG_AGENT_IOBSP          ,
  SOFTI_DIGIT_ELIG.OPRTR_TEAM_HIERCH_ID     ,
  SOFTI_DIGIT_ELIG.OPRTR_TEAM_ACTVT_ID      ,
  SOFTI_DIGIT_ELIG.UNVRS_CD                 ,
  SOFTI_DIGIT_ELIG.DIRCTN_CD                ,
  SOFTI_DIGIT_ELIG.CHANL_CD                 ,
  SOFTI_DIGIT_ELIG.MEDIA_CD                 ,
  SOFTI_DIGIT_ELIG.ORIGN_CD                 ,
  SOFTI_DIGIT_ELIG.WAY_CD                   ,
  SOFTI_DIGIT_ELIG.REASN_CD                 ,
  SOFTI_DIGIT_ELIG.REASN_DETL_CD            ,
  SOFTI_DIGIT_ELIG.CONCLSN_CD               ,
  SOFTI_DIGIT_ELIG.UNIFIED_SHOP_CD          ,
  SOFTI_DIGIT_ELIG.ORG_REM_CHANNEL_CD       ,
  SOFTI_DIGIT_ELIG.ORG_CHANNEL_CD           ,
  SOFTI_DIGIT_ELIG.ORG_SUB_CHANNEL_CD       ,
  SOFTI_DIGIT_ELIG.ORG_SUB_SUB_CHANNEL_CD   ,
  SOFTI_DIGIT_ELIG.ORG_GT_ACTIVITY          ,
  SOFTI_DIGIT_ELIG.ORG_FIDELISATION         ,
  SOFTI_DIGIT_ELIG.ORG_WEB_ACTIVITY         ,
  SOFTI_DIGIT_ELIG.ORG_AUTO_ACTIVITY        ,
  SOFTI_DIGIT_ELIG.ORG_EDO_ID               ,
  SOFTI_DIGIT_ELIG.ORG_TYPE_EDO             ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_1_CD      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_1_DS      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_2_CD      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_2_DS      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_3_CD      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_3_DS      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_4_CD      ,
  SOFTI_DIGIT_ELIG.ORG_TEAM_LEVEL_4_DS      ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_1_CD     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_1_DS     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_2_CD     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_2_DS     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_3_CD     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_3_DS     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_4_CD     ,
  SOFTI_DIGIT_ELIG.WORK_TEAM_LEVEL_4_DS     ,
  SOFTI_DIGIT_ELIG.ANNUL_HD_DT              ,
  SOFTI_DIGIT_ELIG.ANNUL_HD_DS              ,
  SOFTI_DIGIT_ELIG.IND_HD_CD                ,
  SOFTI_DIGIT_ELIG.IND_HD_RAP_CD            ,
  SOFTI_DIGIT_ELIG.HD_RAP_DT                ,
  SOFTI_DIGIT_ELIG.CREATION_TS              ,
  SOFTI_DIGIT_ELIG.CLOSURE_DT                
)
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_W_SOFTI_ELIG_JRC_DIGITAL;
.if errorcode <> 0 then .quit 1;


-- On 'annule' les actes digitaux qui ne le sont plus (cad que leur axe canal a change et n'est plus Online ou DNU)

Update DIGIT
From
  ${KNB_PCO_TMP}.ORD_W_SOFTI_ELIG_JRC_DIGITAL DIGIT,
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT PSOFTI
Set 
ANNUL_HD_DT = Coalesce (DIGIT.ANNUL_HD_DT, current_date),
ANNUL_HD_DS = Coalesce (DIGIT.ANNUL_HD_DS, 'Canal different de Online Dnu') 
Where 
  1 = 1
  And DIGIT.ACTE_ID       =   PSOFTI.ACTE_ID
  And DIGIT.ACT_DT        =   PSOFTI.ORDER_DEPOSIT_DT
  And PSOFTI.ORG_CHANEL_CD Not In ('Online','DNU')
  And DIGIT.ACT_DT        >=  Current_date - 100
  And DIGIT.IND_HD_RAP_CD <> -2
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_W_SOFTI_ELIG_JRC_DIGITAL;
.if errorcode <> 0 then .quit 1;
