-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_PRP_Placement_Cold_Enrichissement_O3.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation à froid de la table de travail O3  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/03/2014      YZH         Creation
-- 25/04/2016      MDE         Evol : Axe Canal sur AGC  ajout   FLAG_TYPE_PTN_NTK
-- 31/05/2021      EVI         PILCOM-802 : Remplacement CAT_W_NSH_REFO3_JOUR par CAT_W_PILCOM_REFO3_JOUR
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_C_O3 All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_C_O3
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  FLAG_TEAM_MKT                 ,
  FLAG_TYPE_CMP                 ,
  EDO_ID                        ,
  FLAG_PLT_CONV                 ,
  TYPE_EDO                      , 
  NETWRK_TYP_EDO_ID             ,
  FLAG_TYPE_GEO                 ,
  FLAG_TYPE_CPT_NTK             ,
  FLAG_TYPE_PTN_NTK              
)
Select
  Placement.ACTE_ID                                                               as ACTE_ID                          ,
  Cast(Placement.ORDER_DEPOSIT_DT as date format 'YYYYMMDD')                      as ORDER_DEPOSIT_DT                 ,
  NULL                                                                            as FLAG_TEAM_MKT                    ,
  '#'                                                                             as FLAG_TYPE_CMP                    ,
  Case When RefO3.EDO_ID Is Null
         Then RefO3Adv.EDO_ID
       Else RefO3.EDO_ID
  End                                                                             as EDO_ID                           ,
  Case When RefO3.FLAG_PLT_CONV Is Null
         Then RefO3Adv.FLAG_PLT_CONV
       Else RefO3.FLAG_PLT_CONV
  End                                                                             as FLAG_PLT_CONV                    ,
  Case When RefO3.TYPE_EDO is null
         Then RefO3Adv.TYPE_EDO
       Else RefO3.TYPE_EDO
  End                                                                             as TYPE_EDO                         ,
  Case When RefO3.NETWRK_TYP_EDO_ID is null
         Then RefO3Adv.NETWRK_TYP_EDO_ID
       Else RefO3.NETWRK_TYP_EDO_ID
  End                                                                             as NETWRK_TYP_EDO_ID                ,
  Case When RefO3.FLAG_TYPE_GEO is null
         Then RefO3Adv.FLAG_TYPE_GEO
       Else RefO3.FLAG_TYPE_GEO
  End                                                                             as FLAG_TYPE_GEO                    ,
  Case When RefO3.FLAG_TYPE_CPT_NTK is null
         Then RefO3Adv.FLAG_TYPE_CPT_NTK
       Else RefO3.FLAG_TYPE_CPT_NTK
  End                                                                             as FLAG_TYPE_CPT_NTK                 ,
  Case When RefO3.FLAG_TYPE_PTN_NTK is null
         Then RefO3Adv.FLAG_TYPE_PTN_NTK
       Else RefO3.FLAG_TYPE_PTN_NTK
  End                                                                             as FLAG_TYPE_PTN_NTK                 
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_C_EXTR Placement
  Left outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefO3
    On  Placement.STORE_CD           =  RefO3.EXTNL_VAL_COD_CD
    And Placement.ORDER_DEPOSIT_DT  >=  RefO3.START_EXTNL_VAL_DT
    And Placement.ORDER_DEPOSIT_DT  <=  Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
  Left outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefO3Adv
    On  Placement.ADV_STORE_CD       =  RefO3Adv.EXTNL_VAL_COD_CD
    And Placement.ORDER_DEPOSIT_DT  >=  RefO3Adv.START_EXTNL_VAL_DT
    And Placement.ORDER_DEPOSIT_DT  <=  Coalesce(RefO3Adv.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
Qualify Row_Number() Over(Partition by ACTE_ID
                          Order by      RefO3.START_EXTNL_VAL_DT Desc                                 ,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc

                         )=1
;

.if errorcode <> 0 then .quit 1

                                                            
Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGCR_C_O3;

.if errorcode <> 0 then .quit 1

.quit 0
