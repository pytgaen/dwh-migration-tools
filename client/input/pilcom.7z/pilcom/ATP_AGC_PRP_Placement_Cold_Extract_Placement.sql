-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_PRP_Placement_Cold_Extract_Placement.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'extraction de données de placement à froid pour AGC PRP
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 15/04/2014      YZH         Creation
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_C_EXTR All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_C_EXTR
(
    ACTE_ID                           ,
    EXTERNAL_ACTE_ID                  ,
    INTRNL_SOURCE_ID                  ,
    CONTEXT_ID                        ,     
    EXTERNAL_ORDER_ID                 ,
    ORDER_DEPOSIT_TS                  ,
    ORDER_DEPOSIT_DT                  ,
    ORDER_TYPE_CD                     ,
    PRODUCT_TYPE                      ,
    EXTERNAL_PRODUCT_ID               ,
    EXTERNAL_PRODUCT_ID_SEC           ,
    MOUVEMENT                         ,
    MSISDN_PORTED                     ,
    PAR_IMEI_CD                       ,
    PAR_IMSI_CD                       ,
    PAR_SIM_CD                        ,
    SIM_EAN_CD                        ,
    MAIN_MSISDN_ID                    ,
    SECOND_MSISDN_ID                  ,
    HOLDER_CIVILITY                   ,
    HOLDER_LAST_NAME                  ,
    HOLDER_FIRST_NAME                 ,
    HOLDER_SIRET                      ,
    HOLDER_ADDRESS_NM_1               ,
    HOLDER_ADDRESS_NM_2               ,
    HOLDER_ADDRESS_NM_3               ,
    HOLDER_ADDRRESS_NM_4              ,
    HOLDER_ADDRESS_POSTAL_CD          ,
    HOLDER_CITY                       ,
    HOLDER_BANK_CD                    ,
    HOLDER_OFFICE_CD                  ,
    HOLRDER_ACCOUNT_CD                ,
    HOLDER_RIB_KEY_CD                 ,
    HOLDER_MAIL                       ,
    CUSTOMER_CLIENT_NU_ADV            ,
    CUSTOMER_DOSSIER_NU_ADV           ,
    CUSTOMER_MARKET_SEG               ,
    CUSTOMER_CIVILITY                 ,
    CUSTOMER_LAST_NAME_NM             ,
    CUSTOMER_FIRST_NAME_NM            ,
    CUSTOMER_NAME_NM                  ,
    CUSTOMER_SIRET                    ,
    CUSTOMER_ADDRESS_1_NM             ,
    CUSTOMER_ADDRESS_2_NM             ,
    CUSTOMER_ADDRESS_3_NM             ,
    CUSTOMER_ADDRESS_4_NM             ,
    CUSTOMER_ADDRESS_POSTAL_CD        ,
    CUSTOMER_CITY                     ,
    CUSTOMER_CATEGORIE                ,
    SERVICE_ACCESS_ID                 ,
    LINE_ID                           ,
    MASTER_LINE_ID                    ,
    CONVERGENT_IN                     ,
    BSS_PARTY_KNB_ID                  ,
    BSS_PARTY_EXTERNL_ID              ,
    FREG_PARTY_KNB_ID                 ,
    FREG_PARTY_EXTERNL_ID             ,
    STORE_CD                          ,
    ADV_STORE_CD                      ,
    FLAG_TYPE_PTN_NTK                 ,
    AGENT_ID                          ,
    AGENT_LAST_NAME_NM                ,
    AGENT_FIRST_NAME_NM               ,
    EDO_ID                            ,
    TYPE_EDO                          ,
    NETWRK_TYP_EDO_ID                 ,
    FLAG_PLT_CONV                     ,
    FLAG_TEAM_MKT                     ,
    FLAG_TYPE_CMP                     ,
    FLAG_TYPE_GEO                     ,
    FLAG_TYPE_CPT_NTK                 ,
    CLOSURE_DT                        ,
    QUEUE_TS                          ,
    RUN_ID                            ,
    STREAMING_TS                      ,
    CREATION_TS                       ,
    LAST_MODIF_TS                     ,
    HOT_IN                            ,
    FRESH_IN                          ,
    COHERENCE_IN
)
Select                                                                                                    
      Placement.ACTE_ID                                        AS ACTE_ID                    , 
      Placement.EXTERNAL_ACTE_ID                               AS EXTERNAL_ACTE_ID           , 
      Placement.INTRNL_SOURCE_ID                               AS INTRNL_SOURCE_ID           ,
      Placement.CONTEXT_ID                                     AS CONTEXT_ID                 , 
      Placement.EXTERNAL_ORDER_ID                              AS EXTERNAL_ORDER_ID          , 
      Placement.ORDER_DEPOSIT_TS                               AS ORDER_DEPOSIT_TS           ,
      Placement.ORDER_DEPOSIT_DT                               AS ORDER_DEPOSIT_DT           ,
      Placement.ORDER_TYPE_CD                                  AS ORDER_TYPE_CD              , 
      Placement.PRODUCT_TYPE                                   AS PRODUCT_TYPE               , 
      Placement.EXTERNAL_PRODUCT_ID                            AS EXTERNAL_PRODUCT_ID        , 
      Placement.EXTERNAL_PRODUCT_ID_SEC                        AS EXTERNAL_PRODUCT_ID_SEC    , 
      Placement.MOUVEMENT                                      AS MOUVEMENT                  ,
      Placement.MSISDN_PORTED                                  AS MSISDN_PORTED              ,    
      Placement.PAR_IMEI_CD                                    AS PAR_IMEI_CD                ,
      Placement.PAR_IMSI_CD                                    AS PAR_IMSI_CD                ,
      Placement.PAR_SIM_CD                                     AS PAR_SIM_CD                 ,
      Placement.SIM_EAN_CD                                     AS SIM_EAN_CD                  ,
      Placement.MAIN_MSISDN_ID                                 AS MAIN_MSISDN_ID             ,
      Placement.SECOND_MSISDN_ID                               AS SECOND_MSISDN_ID           ,
      Placement.HOLDER_CIVILITY                                AS HOLDER_CIVILITY            ,
      Placement.HOLDER_LAST_NAME                               AS HOLDER_LAST_NAME           ,
      Placement.HOLDER_FIRST_NAME                              AS HOLDER_FIRST_NAME          ,
      Placement.HOLDER_SIRET                                   AS HOLDER_SIRET               ,
      Placement.HOLDER_ADDRESS_NM_1                            AS HOLDER_ADDRESS_NM_1        ,
      Placement.HOLDER_ADDRESS_NM_2                            AS HOLDER_ADDRESS_NM_2        ,
      Placement.HOLDER_ADDRESS_NM_3                            AS HOLDER_ADDRESS_NM_3        ,
      Placement.HOLDER_ADDRRESS_NM_4                           AS HOLDER_ADDRRESS_NM_4       ,
      Placement.HOLDER_ADDRESS_POSTAL_CD                       AS HOLDER_ADDRESS_POSTAL_CD   ,
      Placement.HOLDER_CITY                                    AS HOLDER_CITY                ,
      Placement.HOLDER_BANK_CD                                 AS HOLDER_BANK_CD             ,
      Placement.HOLDER_OFFICE_CD                               AS HOLDER_OFFICE_CD           ,
      Placement.HOLRDER_ACCOUNT_CD                             AS HOLRDER_ACCOUNT_CD         ,
      Placement.HOLDER_RIB_KEY_CD                              AS HOLDER_RIB_KEY_CD          ,
      Placement.HOLDER_MAIL                                    AS HOLDER_MAIL                ,
      Placement.CUSTOMER_CLIENT_NU_ADV                         AS CUSTOMER_CLIENT_NU_ADV     ,
      Placement.CUSTOMER_DOSSIER_NU_ADV                        AS CUSTOMER_DOSSIER_NU_ADV    ,
      Placement.CUSTOMER_MARKET_SEG                            AS CUSTOMER_MARKET_SEG        ,
      Placement.CUSTOMER_CIVILITY                              AS CUSTOMER_CIVILITY          ,
      Placement.CUSTOMER_LAST_NAME_NM                          AS CUSTOMER_LAST_NAME_NM      ,
      Placement.CUSTOMER_FIRST_NAME_NM                         AS CUSTOMER_FIRST_NAME_NM     ,
      Placement.CUSTOMER_NAME_NM                               AS CUSTOMER_NAME_NM           ,
      Placement.CUSTOMER_SIRET                                 AS CUSTOMER_SIRET             ,
      Placement.CUSTOMER_ADDRESS_1_NM                          AS CUSTOMER_ADDRESS_1_NM      ,
      Placement.CUSTOMER_ADDRESS_2_NM                          AS CUSTOMER_ADDRESS_2_NM      ,
      Placement.CUSTOMER_ADDRESS_3_NM                          AS CUSTOMER_ADDRESS_3_NM      ,
      Placement.CUSTOMER_ADDRESS_4_NM                          AS CUSTOMER_ADDRESS_4_NM      ,
      Placement.CUSTOMER_ADDRESS_POSTAL_CD                     AS CUSTOMER_ADDRESS_POSTAL_CD ,
      Placement.CUSTOMER_CITY                                  AS CUSTOMER_CITY              ,
      Placement.CUSTOMER_CATEGORIE                             AS CUSTOMER_CATEGORIE         ,
      Placement.SERVICE_ACCESS_ID                              AS SERVICE_ACCESS_ID          ,
      Placement.LINE_ID                                        AS LINE_ID                    ,
      Placement.MASTER_LINE_ID                                 AS MASTER_LINE_ID             ,
      Placement.CONVERGENT_IN                                  AS CONVERGENT_IN              ,
      Placement.BSS_PARTY_KNB_ID                               AS BSS_PARTY_KNB_ID           ,
      Placement.BSS_PARTY_EXTERNL_ID                           AS BSS_PARTY_EXTERNL_ID       ,
      Placement.FREG_PARTY_KNB_ID                              AS FREG_PARTY_KNB_ID          ,
      Placement.FREG_PARTY_EXTERNL_ID                          AS FREG_PARTY_EXTERNL_ID      ,
      Placement.STORE_CD                                       AS STORE_CD                   ,
      Placement.ADV_STORE_CD                                   AS ADV_STORE_CD               ,
      Placement.FLAG_TYPE_PTN_NTK                              AS FLAG_TYPE_PTN_NTK          , 
      Placement.AGENT_ID                                       AS AGENT_ID                   ,
      Placement.AGENT_LAST_NAME_NM                             AS AGENT_LAST_NAME_NM         ,
      Placement.AGENT_FIRST_NAME_NM                            AS AGENT_FIRST_NAME_NM        ,
      Placement.EDO_ID                                         AS EDO_ID                     ,
      Placement.TYPE_EDO                                       AS TYPE_EDO                   ,
      Placement.NETWRK_TYP_EDO_ID                              AS NETWRK_TYP_EDO_ID          ,
      Placement.FLAG_PLT_CONV                                  AS FLAG_PLT_CONV              ,
      Placement.FLAG_TEAM_MKT                                  AS FLAG_TEAM_MKT              ,
      Placement.FLAG_TYPE_CMP                                  AS FLAG_TYPE_CMP              ,
      Placement.FLAG_TYPE_GEO                                  AS FLAG_TYPE_GEO              ,
      Placement.FLAG_TYPE_CPT_NTK                              AS FLAG_TYPE_CPT_NTK          ,          
      Placement.CLOSURE_DT                                     AS CLOSURE_DT                 ,
      Placement.QUEUE_TS                                       AS QUEUE_TS                   ,
      Placement.RUN_ID                                         AS RUN_ID                     ,
      Placement.STREAMING_TS                                   AS STREAMING_TS               ,
      Current_Timestamp(0)                                     AS CREATION_TS                ,
      Current_Timestamp(0)                                     AS LAST_MODIF_TS              ,
      0                                                        AS HOT_IN                     ,
      1                                                        AS FRESH_IN                   ,
      0                                                        AS COHERENCE_IN                                                                                            
From  
      ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_AGC_PRP    Placement
Where Placement.ORDER_DEPOSIT_DT              >=  Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')  
And   Placement.ORDER_DEPOSIT_DT              <=  Cast('${KNB_PILCOM_ACTE_BORNE_MAX}' as Date Format 'YYYYMMDD')  
   
;                          
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_C_EXTR;
.if errorcode <> 0 then .quit 1

.quit 0
