-- $HEADER: %HEADERS%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PXF_Acte_Consolidation_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Transformation en Acte des placements PXF
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 04/12/2020      EVI         Creation
--------------------------------------------------------------------------------

.set width 2500;

------------------------------------------------------------------------------------------
-- Suppression Table 
------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_PXF All;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------------------------
-- Alimentation Table Acte GDT
------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_PXF
(
ACTE_ID                  ,
ACTE_ID_GEN              ,
ORDER_DEPOSIT_DT         ,
ORDER_DEPOSIT_TS         ,
ORDER_EXTERNAL_ID        ,
INTRNL_SOURCE_ID         ,
STATUS_CD                ,
ACT_UNIFIED_STATUS_CD    ,
ACT_PRODUCT_ID_FINAL     ,
ACT_PRODUCT_DS_FINAL     ,
ACT_SEG_COM_ID_FINAL     ,
ACT_SEG_COM_AGG_ID_FINAL ,
ACT_CODE_MIGR_FINAL      ,
ACT_OPER_ID_FINAL        ,
ACT_TYPE_COMMANDE_ID     ,
ACT_DELTA_TARIF          ,
ACT_TYPE_SERVICE_FINAL   ,
ACT_CD                   ,
ACT_REM_ID               ,
ACT_FLAG_ACT_REM         ,
ACT_FLAG_PEC_PERPVC      ,
ACT_VALO                 ,
ACT_ACTE_FAMILLE_KPI     ,
ACT_UNITE_CD             ,
ACT_PERIODE_ID           ,
ACT_PERIODE_STATUS       ,
ACT_PERIODE_CLOSURE_DT   ,
AGENT_ID                 ,
AGENT_ID_IOBSP           ,
AGENT_ID_UPD             ,
AGENT_ID_UPD_DT          ,
ORG_SPE_CANAL_ID_MACRO   ,
ORG_CHANNEL_CD           ,
ORG_SUB_CHANNEL_CD       ,
ORG_SUB_SUB_CHANNEL_CD   ,
ORG_REM_CHANNEL_CD       ,
ORG_GT_ACTIVITY          ,
ORG_WEB_ACTIVITY         ,
ORG_AUTO_ACTIVITY        ,
UNIFIED_SHOP_CD          ,
ORG_EDO_ID               ,
ORG_EDO_IOBSP            ,
ORG_TYPE_CD              ,
ORG_TYPE_EDO             ,
WORK_TEAM_LEVEL_1_CD     ,
WORK_TEAM_LEVEL_1_DS     ,
WORK_TEAM_LEVEL_2_CD     ,
WORK_TEAM_LEVEL_2_DS     ,
WORK_TEAM_LEVEL_3_CD     ,
WORK_TEAM_LEVEL_3_DS     ,
WORK_TEAM_LEVEL_4_CD     ,
WORK_TEAM_LEVEL_4_DS     ,
LINE_ID                  ,
MASTER_LINE_ID           ,
CUST_TYPE_CD             ,
NDS_VALUE_DS             ,
MSISDN_ID                ,
EXTERNAL_PARTY_ID        ,
RES_VALUE_DS             ,
PAR_ACCES_SERVICE        ,
POSTAL_CD                ,
INSEE_CD                 ,
BU_CD                    ,
DEPARTMNT_ID             ,
PAR_GEO_MACROZONE        ,
PAR_UNIFIED_PARTY_ID     ,
PAR_PARTY_REGRPMNT_ID    ,
PAR_IRIS2000_CD          ,
EAN_CD                   ,
PAR_FIBER_IN             ,
PAR_CID_ID               ,
PAR_PID_ID               ,
PAR_FIRST_IN             ,
ORDER_CANCELING_DT       ,
ORDER_CANCELING_TS       ,
CLOSURE_DT               ,
CREATION_TS              ,
LAST_MODIF_TS            ,
FRESH_IN                 ,
COHERENCE_IN             

)
Select
Placement.ACTE_ID                                                   As ACTE_ID                  ,
Placement.ACTE_ID                                                   As ACTE_ID_GEN              ,
Placement.ORDER_DEPOSIT_DT                                          As ORDER_DEPOSIT_DT         ,
Placement.ORDER_DEPOSIT_TS                                          As ORDER_DEPOSIT_TS         ,
Placement.EXTRNL_ORDER_ID                                           As ORDER_EXTERNAL_ID        ,
Placement.INTRNL_SOURCE_ID                                          As INTRNL_SOURCE_ID         ,
Placement.EXTRNL_STATUS_CD                                          As STATUS_CD                ,            
Placement.STATUS_UNIFIED_CD                                         As ACT_UNIFIED_STATUS_CD    ,
ActeRef.PRODUCT_ID_FINAL                                            As ACT_PRODUCT_ID_FINAL     ,
ActeRef.PRODUCT_DS_FINAL                                            As ACT_PRODUCT_DS_FINAL     ,
ActeRef.SEG_COM_ID_FINAL                                            As ACT_SEG_COM_ID_FINAL     ,
ActeRef.SEG_COM_AGG_ID_FINAL                                        As ACT_SEG_COM_AGG_ID_FINAL ,
ActeRef.CODE_MIGR_FINAL                                             As ACT_CODE_MIGR_FINAL      ,
ActeRef.OPER_ID_FINAL                                               As ACT_OPER_ID_FINAL        ,
ActeRef.TYPE_COMMANDE_ID                                            As ACT_TYPE_COMMANDE_ID     ,
ActeRef.ACT_DELTA_TARIF                                             As ACT_DELTA_TARIF          ,
ActeRef.TYPE_SERVICE_FINAL                                          As ACT_TYPE_SERVICE_FINAL   ,
ActeRef.ACT_CD                                                      As ACT_CD                   ,
ActeRef.ACT_REM_ID                                                  As ACT_REM_ID               ,
ActeRef.FLAG_ACT_REM                                                As ACT_FLAG_ACT_REM         ,
ActeRef.FLAG_PEC_PERPVC                                             As ACT_FLAG_PEC_PERPVC      ,
ActeRef.ACTE_VALO                                                   As ACT_VALO                 ,
ActeRef.ACTE_FAMILLE_KPI                                            As ACT_ACTE_FAMILLE_KPI     ,
ActeRef.ACT_UNITE_CD                                                As ACT_UNITE_CD             ,
ActeRef.PERIODE_ID                                                  As ACT_PERIODE_ID           ,
Coalesce(EtatPeriode.PERIODE_STATUS,'O')                            As ACT_PERIODE_STATUS       ,
EtatPeriode.PERIODE_CLOSURE_DT                                      As ACT_PERIODE_CLOSURE_DT   ,
Placement.ORG_AGENT_ID                                              As AGENT_ID                 ,
Placement.ORG_AGENT_IOBSP                                           As AGENT_ID_IOBSP           ,
Coalesce(RetourPVC.AGENT_ID_UPD,Placement.ORG_AGENT_ID)             As AGENT_ID_UPD             ,
Cast(RetourPVC.AGENT_ID_UPD_TS as date Format 'YYYYMMDD')           As AGENT_ID_UPD_DT          ,
Placement.EXTRNL_TYPE_AGENCE                                        As ORG_SPE_CANAL_ID_MACRO   ,
Placement.ORG_CHANNEL_CD                                            As ORG_CHANNEL_CD           ,
Placement.ORG_SUB_CHANNEL_CD                                        As ORG_SUB_CHANNEL_CD       ,
Placement.ORG_SUB_SUB_CHANNEL_CD                                    As ORG_SUB_SUB_CHANNEL_CD   ,
Placement.ORG_REM_CHANNEL_CD                                        As ORG_REM_CHANNEL_CD       ,
Placement.ORG_GT_ACTIVITY                                           As ORG_GT_ACTIVITY          ,
Placement.ORG_WEB_ACTIVITY                                          As ORG_WEB_ACTIVITY         ,
Placement.ORG_AUTO_ACTIVITY                                         As ORG_AUTO_ACTIVITY        ,
Placement.UNIFIED_SHOP_CD                                           As UNIFIED_SHOP_CD          ,
Placement.ORG_EDO_ID                                                As ORG_EDO_ID               ,
Placement.ORG_EDO_IOBSP                                             As ORG_EDO_IOBSP            ,
Placement.ORG_TYPE_CD                                               As ORG_TYPE_CD              ,
Placement.ORG_TYPE_EDO                                              As ORG_TYPE_EDO             ,
Placement.WORK_TEAM_LEVEL_1_CD                                      As WORK_TEAM_LEVEL_1_CD     ,
Placement.WORK_TEAM_LEVEL_1_DS                                      As WORK_TEAM_LEVEL_1_DS     ,
Placement.WORK_TEAM_LEVEL_2_CD                                      As WORK_TEAM_LEVEL_2_CD     ,
Placement.WORK_TEAM_LEVEL_2_DS                                      As WORK_TEAM_LEVEL_2_DS     ,
Placement.WORK_TEAM_LEVEL_3_CD                                      As WORK_TEAM_LEVEL_3_CD     ,
Placement.WORK_TEAM_LEVEL_3_DS                                      As WORK_TEAM_LEVEL_3_DS     ,
Placement.WORK_TEAM_LEVEL_4_CD                                      As WORK_TEAM_LEVEL_4_CD     ,
Placement.WORK_TEAM_LEVEL_4_DS                                      As WORK_TEAM_LEVEL_4_DS     ,
Placement.DMC_LINE_ID                                               As LINE_ID                  ,
Placement.DMC_MASTER_LINE_ID                                        As MASTER_LINE_ID           ,
Placement.DMC_CUST_TYPE_CD                                          As CUST_TYPE_CD             ,
Case When Coalesce(Placement.DMC_NDS_VALUE_DS,'0000000000') = '0000000000'
     And  Placement.EXTRNL_PHONE_NUMBER Is Not Null
     And  substr(Placement.EXTRNL_PHONE_NUMBER,1,2) Not In ('06','07')
        Then Placement.EXTRNL_PHONE_NUMBER
     Else Coalesce(Placement.DMC_NDS_VALUE_DS,'0000000000')
End                                                                 As NDS_VALUE_DS             ,
Case When Coalesce(Placement.DMC_MSISDN_ID,'0000000000') = '0000000000'
     And  Placement.EXTRNL_PHONE_NUMBER Is Not Null
     And  substr(Placement.EXTRNL_PHONE_NUMBER,1,2) In ('06','07')
        Then Placement.EXTRNL_PHONE_NUMBER
     Else Coalesce(Placement.DMC_MSISDN_ID,'0000000000')
End                                                                 As MSISDN_ID                ,
Coalesce(Placement.DMC_EXTERNAL_PARTY_ID,'0000000000')              As EXTERNAL_PARTY_ID        ,
Placement.DMC_RES_VALUE_DS                                          As RES_VALUE_DS             ,
Placement.DMC_SERVICE_ACCESS_ID                                     As PAR_ACCES_SERVICE        ,
Coalesce(Placement.DMC_POSTAL_CD, Placement.EXTRNL_POSTAL_CODE)     As POSTAL_CD                ,
Placement.PAR_INSEE_NB                                              As INSEE_CD                 ,
Placement.PAR_BU_CD                                                 As BU_CD                    ,
Placement.DEPARTMNT_ID                                              As DEPARTMNT_ID             ,
Placement.PAR_GEO_MACROZONE                                         As PAR_GEO_MACROZONE        ,
Placement.PAR_UNIFIED_PARTY_ID                                      As PAR_UNIFIED_PARTY_ID     ,
Placement.PAR_PARTY_REGRPMNT_ID                                     As PAR_PARTY_REGRPMNT_ID    ,
Placement.PAR_IRIS2000_CD                                           As PAR_IRIS2000_CD          ,
Placement.EXTRNL_EAN_CD                                             As EAN_CD                   ,
Placement.PAR_FIBER_IN                                              As PAR_FIBER_IN             ,
Placement.PAR_CID_ID                                                As PAR_CID_ID               ,
Placement.PAR_PID_ID                                                As PAR_PID_ID               ,
Placement.PAR_FIRST_IN                                              As PAR_FIRST_IN             ,
Placement.ORDER_CANCELING_DT                                        As ORDER_CANCELING_DT       ,
Placement.ORDER_CANCELING_TS                                        As ORDER_CANCELING_TS       ,
Null                                                                As CLOSURE_DT               ,
Current_Timestamp(0)                                                As CREATION_TS              ,
Current_Timestamp(0)                                                As LAST_MODIF_TS            ,
1                                                                   As FRESH_IN                 ,
0                                                                   As COHERENCE_IN              
From
    ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_PXF Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_PXF_CALC ActeRef
    On  Placement.ACTE_ID                       = ActeRef.ACTE_ID
    And Placement.ORDER_DEPOSIT_DT              = ActeRef.ORDER_DEPOSIT_DT
  --Jointure avec V_CAT_R_CLOSED_PERIOD_PILCOM
  Left outer join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On  EtatPeriode.PERIODE_ID     = ActeRef.PERIODE_ID
    And EtatPeriode.CURRENT_IN     = 1
    And EtatPeriode.FRESH_IN       = 1
    And EtatPeriode.CLOSURE_DT     Is Null
-- Prise en compte du retour PVC pour mise à jour du CUID
  Left Outer Join  ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourPVC
    On  Placement.ACTE_ID          = RetourPVC.ACTE_ID
    And Placement.ORDER_DEPOSIT_DT = RetourPVC.ORDER_DEPOSIT_DT

Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_PXF;
.if errorcode <> 0 then .quit 1


.quit 0

