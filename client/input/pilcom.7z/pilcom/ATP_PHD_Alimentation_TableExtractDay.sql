-- $HEADER: %HEADER%
----------------------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_PHD_Alimentation_TableExtractDay.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'alimentation pour initialiser la table tampon
--
--------------------------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE             AUTEUR      CREATION/MODIFICATION
--26/11/2019        EVI         CREATION
--27/10/2020        EVI         PILCOM-750 : Contrôle sur Champs Obligatoires
--------------------------------------------------------------------------------------------------------

.set width 5000

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP des extraction des actes                              ----
----------------------------------------------------------------------------------------------
DELETE FROM ${KNB_PCO_TMP}.ACT_T_PHD_DAY;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP des extraction des actes 
----------------------------------------------------------------------------------------------
INSERT INTO ${KNB_PCO_TMP}.ACT_T_PHD_DAY
(
    ACT_ID          
  , ACT_ID_INCR     
  , SERV_PARTN_ID   
  , CUST_PARTN_ID   
  , DEAL_PARTN_ID   
  , BIL_RUL         
  , TYPE_OPERATION  
  , OFFER_CD        
  , OFFER_LB        
  , SERV_DEB_DT     
  , INTERST_DT      
  , INTERST_ENTT_ID 
  , INTERST_AGENT_ID
  , INTERST_CHANL_CD
  , SUBSCR_DT       
  , SUBSCR_ENTT_ID  
  , SUBSCR_AGENT_ID 
  , SUBSCR_CHANL_CD 
  , RESIL_DT        
  , NUM_1           
  , NUM_2             
  , NUM_3             
  , DATE_1            
  , DATE_2            
  , DATE_3            
  , TEXT_1            
  , TEXT_2            
  , TEXT_3            
  , TEXT_4            
  , TEXT_5            
  , EXTRACT_TS
  , CREATION_TS       
  , CURRENT_IN        
  , FRESH_IN          
  , COHERENCE_IN      
)
Select 
    'O-HD' || Trim(VU.ACTE_ID)                                As MANDATORY_ACT_ID          
  , VU.ACTE_ID                                                As ACT_ID_INCR     
  , 'O-HD'                                                    As SERV_PARTN_ID                         
  , VU.EXTERNAL_PARTY_ID                                      As MANDATORY_CUST_PARTN_ID                         
  , VU.MSISDN_ID                                              As MANDATORY_DEAL_PARTN_ID                         
  , Case                                                      
       When VU.ACT_TYPE_COMMANDE_ID = 'ACQ'                   
          Then 'M_ACQ'                                        
       Else                                                   
               'M_MEG'                                        
    End                                                       As BIL_RUL                                
  , 'REMU'                                                    As TYPE_OPERATION                                         
  , VU.ACT_PRODUCT_ID_FINAL                                   As OFFER_CD                               
  , VU.ACT_SEG_COM_ID_FINAL                                   As OFFER_LB                               
  , Coalesce(CAST(VU.DELIVERY_DT AS timestamp(0)),VU.ACT_TS)  As MANDATORY_SERV_DEB_DT                            
  , Null                                                      As INTERST_DT                             
  , Null                                                      As INTERST_ENTT_ID                        
  , Null                                                      As INTERST_AGENT_ID                       
  , Null                                                      As INTERST_CHANL_CD                       
  , VU.ACT_TS                                                 As SUBSCR_DT                              
  , VU.UNIFIED_SHOP_CD                                        As MANDATORY_SUBSCR_ENTT_ID                                         
  , VU.AGENT_ID                                               As MANDATORY_SUBSCR_AGENT_ID                                        
  , 'SELFCARE'                                                As SUBSCR_CHANL_CD                                        
  , Null                                                      As RESIL_DT                                               
  , Null                                                      As NUM_1                                 
  , Null                                                      As NUM_2                                 
  , Null                                                      As NUM_3                                 
  , Null                                                      As DATE_1                                
  , Null                                                      As DATE_2                                
  , Null                                                      As DATE_3                                
  , Null                                                      As TEXT_1                                
  , Null                                                      As TEXT_2                                
  , Null                                                      As TEXT_3                                
  , Null                                                      As TEXT_4                                
  , Null                                                      As TEXT_5                                
  , CAST('${KNB_BATCH_DATE}' AS timestamp(0))                 As EXTRACT_TS
  , CAST('${KNB_BATCH_DATE}' AS timestamp(0))                 As CREATION_TS
  , 1                                                         As CURRENT_IN
  , 1                                                         As FRESH_IN
  , 0                                                         As COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED VU
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL DIGITAL
      On    VU.ACTE_ID              = DIGITAL.ACTE_ID
        And VU.ACT_DT               = DIGITAL.ACT_DT
        And DIGITAL.CURRENT_IN      = 1
  Inner Join ${KNB_PCO_REFCOM}.V_CAT_R_KPI_PILCOM RefKPI
      On    RefKPI.PERIODE_ID       = VU.ACT_PERIODE_ID
        And RefKPI.FAMILLE_KPI_ID   = VU.ACT_ACTE_FAMILLE_KPI
        And RefKPI.CURRENT_IN       = 1
        And RefKPI.PROTOSCORE       = 'O'
        And RefKPI.CLOSURE_DT       Is Null
  Left  Join ${KNB_PCO_VM}.V_ACT_E_PHD_DAY EXT
      On    EXT.ACT_ID_INCR         = DIGITAL.ACTE_ID
        And EXT.CURRENT_IN          = 1
        And EXT.FRESH_IN            = 1
Where 
(1=1)
  And VU.UNIFIED_SHOP_CD            Is Not Null
  And VU.ORG_CHANNEL_CD             In ('Dist')
  And VU.ORG_SUB_CHANNEL_CD         In ('RP')
  And VU.ORG_WEB_ACTIVITY           In ('Omnicanal')
  And VU.ACT_TYPE_COMMANDE_ID       In ('ACQ', 'MEG')
  And VU.ACT_CLOSURE_DT             Is NULL
  And VU.MASTER_FLAG                = 1
  And (VU.CONCLDD_IN <> 'N'  
   Or  VU.CONCLDD_IN IS NULL )
  And ( -- Recuperation Acte H&D à la date de la dernière fraicheur
         DIGITAL.IND_HD_TEMPO_DT      > cast ('${LAST_FRESH_TS}' as TIMESTAMP(0)) 
         Or
        -- Recuperation Acte H&D non remonté lors du traitement précédent pour diverse raison : Traitement en amont retardé, incidenté,..
       (DIGITAL.IND_HD_TEMPO_DT       = cast ('${LAST_FRESH_TS}' as TIMESTAMP(0)) 
        And EXT.ACT_ID                Is Null)
      )
  -- Contrôle sur Champs Obligatoire
  And MANDATORY_ACT_ID           Is Not Null
  And MANDATORY_CUST_PARTN_ID    Is Not Null
  And MANDATORY_DEAL_PARTN_ID    Is Not Null
  And MANDATORY_SERV_DEB_DT      Is Not Null
  And MANDATORY_SUBSCR_ENTT_ID   Is Not Null
  And MANDATORY_SUBSCR_AGENT_ID  Is Not Null
;
.if errorcode <> 0 then .quit 1
