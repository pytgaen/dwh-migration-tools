-- $HEADER:   mm2pco/current/sql/ATP_SOFT_Acte_Cold_Alimentation_INT_Step3_CalculActeNonValo.sql 13_05#10 19-DEC-2017 11:30:41 CLHH1829
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step3_CalculActeNonValo.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql de calcul de l'acte Pilcom directe dans le cas des erreurs
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 30/07/2014      YZH         Evol QC 606
-- 23/04/2015      AOU         PDV Point Orange à exclure du Canal AD  QC884
-- 21/05/2015      YZH         Pilcom Digital - Nouveaux champs DMC
-- 28/03/2017      MDE         Evol : ajout CID/PID/FIRST 
-- 07/08/2017      HOB         Evol Calcul Canal
-- 13/12/2017      MEL         Evol IOBSP
-- 28/05/2020      JCR         modification champs adresse
-- 21/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
-- 14/01/2021      BCH         PILCOM-1086 : Decom ORG_WEB_PARTNER_IN
--------------------------------------------------------------------------------

.set width 2500;





Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_INT All;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_INT
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  OPERATOR_PROVIDER_ID              ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_EXTERNAL_ID                 ,
  INTRNL_SOURCE_ID                  ,
  ORDER_REF_EXTERNAL_ID             ,
  ORDER_OPER_ID                     ,
  ORDER_MOTV_ID                     ,
  ORDER_MOTIF_DS                    ,
  ORDER_STATUT_CD                   ,
  ORDER_STATUT_MODIF_TS             ,
  ORDER_LAST_STATUT_CD              ,
  ORDER_LAST_STATUT_MODIF_TS        ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  INB_PRESFACT_ACQ_ADV              ,
  INB_PRESFACT_ACQ_AGAP             ,
  SEG_PARC_DT_DEBUT                 ,
  INB_PARK_ID                       ,
  INB_VALDTN_DT                     ,
  INB_REALZTN_DT                    ,
  INB_CONTRCT_DT                    ,
  INB_CANCELLNG_DT                  ,
  ORG_CANAL_ID                      ,
  ORG_CHANEL_CD                     ,
  ORG_SUB_CHANEL_CD                 ,
  ORG_SUB_SUB_CHANEL_CD             ,
  ORG_REM_CHANEL_CD                 ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORIG_DEM                          ,
  CANALDEM_MTHD                     ,
  ORG_CANAL_ID_MACRO                ,
  ORG_CANAL_MACRO_LB                ,
  ORG_STORE_NAME                    ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_FLAG_TYPE_PTN_NTK             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  PAR_EXTERNAL_PARTY_FREG_ID        ,
  PAR_PARTY_KNB_FREG_ID             ,
  PAR_AID                           ,
  PAR_PARTY_KNB_BSS_ID              ,
  PAR_ND                            ,
  PAR_ACCES_SERVICE                 ,
  PAR_ADV_CLIENT_NU                 ,
  PAR_ADV_DOSSIER_NU                ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_DEPRTMNT_ID                   ,
  --
  PAR_CID_ID                        ,
  PAR_PID_ID                        ,
  PAR_FIRST_IN                      ,
  ORG_EDO_IOBSP                     ,
  ORG_AGENT_IOBSP                   ,
  --
  PAR_POSTAL_CD                     ,
  PAR_INSEE_CD                      ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  PAR_IRIS2000_CD                   ,
  PAR_FIBER_IN                      ,
  REDIRECTION_CD                    ,
  OTO_OSCAR_VALUE_NU                ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_SIRET                         ,
  PAR_MARKET_SEG                    ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_CD_POSTAL                ,
  PAR_DO                            ,
  PAR_BU_CD                         ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  PAR_MOB_IMEI                      ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  PAR_MOB_IMSI                      ,
  PAR_SCORE_NU_INT                  ,
  PAR_SCORE_IN_INT                  ,
  PAR_TRESHOLD_NU_INT               ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  CONTRCT_DT_SIGN_PREC_INT          ,
  CONTRCT_DT_FIN_PREC_INT           ,
  CONTRCT_DT_DEB_SIGN_POST_INT      ,
  CONTRCT_DT_FIN_SIGN_POST_INT      ,
  DUREE_ENGAGEMENT_INT              ,
  TYPE_DUR_ENGAGEMENT_INT           ,
  CONTRCT_DT_SIGN_PREC_MOB          ,
  CONTRCT_DT_FIN_PREC_MOB           ,
  CONTRCT_DT_SIGN_POST_MOB          ,
  CONTRCT_DUREE_ENG_MOB             ,
  CONTRCT_UNIT_ENG_MOB              ,
  CONFIRMATION_IN                   ,
  CONFIRMATION_DT                   ,
  CONFIRMATION_CALC_FIN_DT          ,
  DELIVERY_IN                       ,
  DELIVERY_DT                       ,
  DELIVERY_CALC_FIN_DT              ,
  PERENNITE_IN                      ,
  PERENNITE_FIN_DT                  ,
  PERENNITE_CALC_FIN_DT             ,
  PERENNITE_PVC_IN                  ,
  PERENNITE_PVC_FIN_DT              ,
  PERENNITE_PVC_CALC_FIN_DT         ,
  SEG_COM_ID_LAST_PER               ,
  SEG_COM_ID_SOLD                   ,
  SEG_COM_ID_FIND                   ,
  SEG_FIND_LIVR_DT                  ,
  SEG_FIND_CANCEL_DT                ,
  SEG_COM_ID_NEXT_PARC              ,
  SEG_NEXT_PARC_LIVR_DT             ,
  SEG_NEXT_PARC_CANCEL_DT           ,
  SEG_COM_ID_FINAL_PARC             ,
  SEG_FINAL_PARC_LIVR_DT            ,
  SEG_FINAL_PARC_CANCEL_DT          ,
  SEG_COM_ID_LAST_IN_PARC           ,
  NB_IN_OUT_PARC                    ,
  POURCENTAGE_PRES_PARC             ,
  SEG_PRES_PARC_COMMANDE            ,
  DELIVERY_ONTIME_IN                ,
  CONCURENCE_IN                     ,
  CONCURENCE_CONCLU_IN              ,
  CONCURENCE_ID                     ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                       as ACTE_ID                            ,
  Placement.ACTE_ID                                       as ACTE_ID_GEN                        ,
  Placement.OPERATOR_PROVIDER_ID                          as OPERATOR_PROVIDER_ID               ,
  Placement.ORDER_DEPOSIT_DT                              as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                              as ORDER_DEPOSIT_TS                   ,
  Placement.EXTERNAL_ORDER_ID                             as ORDER_EXTERNAL_ID                  ,
  Placement.INTRNL_SOURCE_ID                              as INTRNL_SOURCE_ID                   ,
  Placement.PARSIFAL_ORDER_ID                             as ORDER_REF_EXTERNAL_ID              ,
  Placement.ACTE_OPERTR_ID_COMPST_OFFR                    as ORDER_OPER_ID                      ,
  Placement.MOTV_ORDR_ID                                  as ORDER_MOTV_ID                      ,
  Case  When  Placement.ACTE_OPERTR_ID_COMPST_OFFR = '${P_PIL_310}'
          Then  '${P_PIL_311}'
        When  Placement.ACTE_OPERTR_ID_COMPST_OFFR = '${P_PIL_312}'
          Then  '${P_PIL_313}'
        When  Placement.ACTE_OPERTR_ID_COMPST_OFFR = '${P_PIL_314}'
          Then  '${P_PIL_315}'
        When  Placement.ACTE_OPERTR_ID_COMPST_OFFR = '${P_PIL_316}'
          Then  '${P_PIL_317}'
        When  Placement.ACTE_OPERTR_ID_COMPST_OFFR = '${P_PIL_318}'
          Then  '${P_PIL_319}'
        Else    '${P_PIL_321}'
  End                                                     as ORDER_MOTIF_DS                     ,
  Placement.ORDER_STATUS_CD                               as ORDER_STATUT_CD                    ,
  Placement.STATUS_MODIF_TS                               as ORDER_STATUT_MODIF_TS              ,
  Placement.ORDER_LAST_STATUT_CD                          as ORDER_LAST_STATUT_CD               ,
  Placement.ORDER_LAST_STATUT_MODIF_TS                    as ORDER_LAST_STATUT_MODIF_TS         ,
  Null                                                    as ACT_PRODUCT_ID_PRE                 ,
  Null                                                    as ACT_SEG_COM_ID_PRE                 ,
  Null                                                    as ACT_SEG_COM_AGG_ID_PRE             ,
  Null                                                    as ACT_CODE_MIGR_PRE                  ,
  Null                                                    as ACT_OPER_ID_PRE                    ,
  ActeSoft.PRODUCT_ID                                     as ACT_PRODUCT_ID_FINAL               ,
  Case  When  Placement.TYPE_PRODUCT = 'OC'
          Then Placement.COMPST_OFFR_DS
        When  Placement.TYPE_PRODUCT = 'OA'
          Then Coalesce(Placement.COMPST_OFFR_DS,'')||' - '||Coalesce(Placement.ATOMIC_OFFR_DS,'')
        When  Placement.TYPE_PRODUCT = 'FVF'
          Then Coalesce(Placement.COMPST_OFFR_DS,'')||' - '||Coalesce(Placement.ATOMIC_OFFR_DS,'')||' - '||Coalesce(Placement.FUNCTN_DS,'')||' - '||Coalesce(Placement.FUNCTN_VALUE_DS,'')
  End                                                     as ACT_PRODUCT_DS_FINAL               ,
  ActeSoft.SEG_COM_ID                                     as ACT_SEG_COM_ID_FINAL               ,
  ActeSoft.SEG_COM_AGG_ID                                 as ACT_SEG_COM_AGG_ID_FINAL           ,
  ActeSoft.CODE_MIGRATION                                 as ACT_CODE_MIGR_FINAL                ,
  --On réalise ici le formatage de l'opérateur
  Case  When Placement.EXT_OPER_ID = '${P_PIL_099}'
          --Si le placement était ADP et qu'il sort en acquisition alors => INI
          Then '${P_PIL_007}'
        Else -- Sinon on remet l'opérateur calculé
          ActeSoft.EXT_OPER_ID
  End                                                     as ACT_OPER_ID_FINAL                  ,
  ActeSoft.TYPE_SERVICE                                   as ACT_TYPE_SERVICE_FINAL             ,
  --Reformatage du type de commande (Migration)
  Case  When Placement.EXT_OPER_ID = '${P_PIL_099}'  --Si c'est un ADP et sorti en ACQ alors on le remet en maintien
          Then '${P_PIL_018}'
        --Sinon on met la valeur issu du calcul :
        When ActeSoft.EXT_OPER_ID_INIT = '${P_PIL_005}'
          Then '${P_PIL_016}'
        When ActeSoft.EXT_OPER_ID_INIT = '${P_PIL_008}'
          Then '${P_PIL_017}'
        When ActeSoft.EXT_OPER_ID_INIT = '${P_PIL_007}'
          Then '${P_PIL_018}'
  End                                                     as ACT_TYPE_COMMANDE_ID               ,
  0                                                       as ACT_DELTA_TARIF                    ,
  --Calcul de l'acte avec les différents cas de rejets :
  Case  --Cas de rejet sur les périodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  ActeSoft.PERIODE_ID      = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit Placé est un produit inconnu de RefCom
        When  ActeSoft.PRODUCT_ID  = '${P_PIL_223}'
          Then '${P_PIL_224}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        When ActeSoft.SEG_COM_ID in ('NS')
          Then  '${P_PIL_221}'
        Else '${P_PIL_067}'
  End                                                     as ACT_CD                             ,
  '${P_PIL_067}'                                          as ACT_REM_ID                         ,
  'N'                                                     as ACT_FLAG_ACT_REM                   ,
  'N'                                                     as ACT_FLAG_PEC_PERPVC                ,
  0                                                       as ACT_ACTE_VALO                      ,
  'WAR_NS'                                                as ACT_ACTE_FAMILLE_KPI               ,
  ActeSoft.PERIODE_ID                                     as ACT_PERIODE_ID                     ,
  Null                                                    as INB_PRESFACT_ACQ_ADV               ,
  Null                                                    as INB_PRESFACT_ACQ_AGAP              ,
  Null                                                    as SEG_PARC_DT_DEBUT                  ,
  Null                                                    as INB_PARK_ID                        ,
  Null                                                    as INB_VALDTN_DT                      ,
  Null                                                    as INB_REALZTN_DT                     ,
  Null                                                    as INB_CONTRCT_DT                     ,
  Null                                                    as INB_CANCELLNG_DT                   ,
  Placement.DISTRBTN_CHANNL_ID                            as ORG_CANAL_ID                       ,
  --Calcul du canal de vente Macro
  Case  
  
        When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
         Then  'Exclus'
         When Orga.ORG_CHANEL_CD Is Not Null  
         Then  Orga.ORG_CHANEL_CD
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
         Then  OrgaWeb.ORG_CHANEL_CD
        When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
         Then 'Online'
       When Placement.DISTRBTN_CHANNL_ID ='ORM'
         Then 'Dist'
        Else 'NONPARAM' 
  End                                                      as ORG_CHANEL_CD_AGR                    ,
  --Sous Canal
  Case  When Orga.ORG_CHANEL_CD Is Not Null
        Then Case When (Placement.FLAG_TYPE_CPT_NTK = 'AUTRC' AND ORG_CHANEL_CD_AGR ='Dist')
                    Then 'RC'
                  When FLAG_TYPE_PTN_NTK ='DCE'
                    Then 'Exclus'
                  Else Orga.ORG_SUB_CHANEL_CD
               End
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
         Then Orgaweb.ORG_SUB_CHANEL_CD
        When ( ORG_CHANEL_CD_AGR='Dist'  And Placement.DISTRBTN_CHANNL_ID ='ORM'And Placement.NETWRK_TYP_EDO_ID ='RP')
         Then 'RP'
       When ( ORG_CHANEL_CD_AGR='Dist'  And Placement.DISTRBTN_CHANNL_ID ='ORM'And Placement.NETWRK_TYP_EDO_ID ='RC')
         Then 'RC'
        Else 'NONPARAM'
  End                                                     as ORG_SUB_CHANEL_CD_AGR                  ,
  --Sous-Sous-Canal
  Case  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
          Then Case When FLAG_TYPE_PTN_NTK ='DCE'
                     Then 'Exclus'
                    Else Orga.ORG_SUB_SUB_CHANEL_CD
               End
         When ( ORG_CHANEL_CD_AGR='Dist'  And Placement.DISTRBTN_CHANNL_ID ='ORM')
        Then 'Dom'
        When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR='RC')
          Then FLAG_TYPE_CPT_NTK
        When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP')
          Then Null
        When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR<>'RC')
          Then 
            Case When FLAG_TYPE_GEO Is Not Null
             Then 'DOM'
            Else 'Metropole'
            End
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_SUB_SUB_CHANEL_CD
        Else 'NONPARAM'
  End                                                     as ORG_SUB_SUB_CHANEL_CD              ,
  --Canal de Rem
  Case  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
          Then  'Exclus'
        When ( ORG_CHANEL_CD_AGR='Dist'  And Placement.DISTRBTN_CHANNL_ID ='ORM')
       Then 'Exclus'
        When Orga.ORG_CHANEL_CD Is Not Null  
          Then Orga.ORG_REM_CHANEL_CD
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_REM_CHANEL_CD
        When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
         Then 'Online'
        Else 'NONPARAM'     
  End                                                     as ORG_REM_CHANEL_CD                  ,
  --ActivitÃ©
  Case  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
          Then  'Exclus'
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist'  )
          Then Orga.ORG_GT_ACTIVITY
        When ORG_CHANEL_CD_AGR = 'Dist' 
          Then
            Case When FLAG_TYPE_PTN_NTK Is Not Null
                   Then FLAG_TYPE_PTN_NTK
                 When ORG_SUB_CHANEL_CD_AGR='AD'
                   Then 'Boutique FT'
                 When Placement.DISTRBTN_CHANNL_ID ='ORM'
                  Then 'Reunion'
                 When ORG_SUB_CHANEL_CD_AGR='RC'
                   Then 'Reseau Concurrent' 
            End
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_GT_ACTIVITY
        Else 'NONPARAM'
  End                                                     as ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  Case  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
          Then  'Exclus'
        When Orga.ORG_CHANEL_CD Is Not Null  
          Then Orga.ORG_FIDELISATION
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_FIDELISATION
         When Placement.DISTRBTN_CHANNL_ID ='ORM'
              Then Null
        Else 'NONPARAM'
  End                                                     as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
  Case  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
          Then  'Exclus'
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist'  )
          Then Orga.ORG_WEB_ACTIVITY
        When ORG_CHANEL_CD_AGR = 'Dist'
          Then 'NON'
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_WEB_ACTIVITY
        When OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
          Then 'OUI'
        Else 'E'
  End                                                     as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique
  Case  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
          Then 'Exclus'
        When Orga.ORG_CHANEL_CD Is Not Null  
          Then Orga.ORG_AUTO_ACTIVITY
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_AUTO_ACTIVITY
        When OrgaWeb.ORG_CHANEL_CD Is Null And  Placement.DISTRBTN_CHANNL_ID ='SCC'
          Then 'OUI'
        Else 'E'
  End                                                     as ORG_AUTO_ACTIVITY                  ,
  Null                                                    as ORIG_DEM                           ,
  Null                                                    as CANALDEM_MTHD                      ,
  Null                                                    as ORG_CANAL_ID_MACRO                 ,
  Null                                                    as ORG_CANAL_MACRO_LB                 ,
  Placement.STORE_NAME                                    as ORG_STORE_NAME                     ,
  Placement.EDO_ID                                        as ORG_EDO_ID                         ,
  Placement.TYPE_EDO                                      as ORG_TYPE_EDO                       ,
  Placement.NETWRK_TYP_EDO_ID                             as ORG_NETWRK_TYP_EDO_ID              ,
  Placement.FLAG_TYPE_GEO                                 as ORG_FLAG_TYPE_GEO                  ,
  Placement.FLAG_TYPE_CPT_NTK                             as ORG_FLAG_TYPE_CPT_NTK              ,
  Placement.FLAG_TYPE_PTN_NTK                             as ORG_FLAG_TYPE_PTN_NTK              ,
  Placement.FLAG_PLT_CONV                                 as ORG_FLAG_PLT_CONV                  ,
  Placement.FLAG_TEAM_MKT                                 as ORG_FLAG_TEAM_MKT                  ,
  Placement.FLAG_TYPE_CMP                                 as ORG_FLAG_TYPE_CMP                  ,
  Null                                                    as ORG_REF_TRAV                       ,
  Placement.AGENT_ID                                      as ORG_AGENT_ID                       ,
  Null                                                    as ORG_POC_XI                         ,
--  Coalesce(RetourGRV.AGENT_ID_UPD,Placement.AGENT_ID)     as ORG_AGENT_ID_UPD                   ,
  Placement.AGENT_ID                                      as ORG_AGENT_ID_UPD                   ,
--  Cast(RetourGRV.AGENT_ID_UPD_TS as date Format 'YYYYMMDD') as ORG_AGENT_ID_UPD_DT              ,
  Null                                                    as ORG_AGENT_ID_UPD_DT                ,
--  Coalesce(RetourGRV.ORG_NOM,Placement.ORG_NOM)           as ORG_NOM                            ,
  Placement.ORG_NOM                                       as ORG_NOM                            ,
  --Coalesce(RetourGRV.ORG_PRENOM,Placement.ORG_PRENOM)     as ORG_PRENOM                         ,
  Placement.ORG_PRENOM                                    as ORG_PRENOM                         ,
  Null                                                    as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitée
  Null                                                    as ORG_ACTVT_REEL                     ,
  Null                                                    as ORG_RESP_REF_TRAV                  ,
  Null                                                    as ORG_RESP_AGENT_ID                  ,
  Null                                                    as ORG_RESP_XI                        ,
  Placement.CUSTOMER_FGT_ID                               as PAR_EXTERNAL_PARTY_FREG_ID         ,
  Placement.FREG_PARTY_KNB_ID                             as PAR_PARTY_KNB_FREG_ID              ,
  Placement.CUSTOMER_BSS_ID                               as PAR_AID                            ,
  Placement.BSS_PARTY_KNB_ID                              as PAR_PARTY_KNB_BSS_ID               ,
  Placement.CUSTOMER_ND_AR                                as PAR_ND                             ,
  Placement.SERVICE_ACCESS_ID                             as PAR_ACCES_SERVICE                  ,
  Placement.CUSTOMER_CLIENT_NU_ADV                        as PAR_ADV_CLIENT_NU                  ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                       as PAR_ADV_DOSSIER_NU                 ,
  Placement.LINE_ID                                       as DMC_LINE_ID                        ,
  Placement.MASTER_LINE_ID                                as DMC_MASTER_LINE_ID                 ,
  Case When (Placement.PAR_DEPRTMNT_ID Is Null
              Or
              Substring(Trim(Placement.PAR_DEPRTMNT_ID) From 1 For 3) In ('998', '999') -- respectivement departement etranger  ou inconnu
            ) 
            And PAR_BILL_CD_POSTAL_AGR  Is Not Null
        Then
           Case When Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988')
                        Then  Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 3) -- on renseigne les departement sur 3 caracteres
                        Else    Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 2)  -- on renseigne les departement sur 2 caracteres
            End
        Else    Trim(Placement.PAR_DEPRTMNT_ID)
  End                                                     as PAR_DEPRTMNT_ID                    ,
  Placement.PAR_CID_ID                                    as PAR_CID_ID                         ,
  Placement.PAR_PID_ID                                    as PAR_PID_ID                         ,
  Placement.PAR_FIRST_IN                                  as PAR_FIRST_IN                       ,
  Placement.ORG_EDO_IOBSP                                 as ORG_EDO_IOBSP                      ,
  Placement.ORG_AGENT_IOBSP                               as ORG_AGENT_IOBSP                    ,
  Placement.PAR_POSTAL_CD                                 as PAR_POSTAL_CD                      ,
  Placement.PAR_INSEE_CD                                  as PAR_INSEE_CD                       ,
  Placement.PAR_GEO_MACROZONE                             as PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                          as PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                         as PAR_PARTY_REGRPMNT_ID              ,
  Placement.PAR_IRIS2000_CD                               as PAR_IRIS2000_CD                    ,
  Placement.PAR_FIBER_IN                                  as PAR_FIBER_IN                       ,
  Placement.REDIRECTION_CD                                as REDIRECTION_CD                     ,
  Placement.OSCAR_VALUE_NU                                as OTO_OSCAR_VALUE_NU                 ,
  Placement.CUSTOMER_LAST_NAME                            as PAR_LASTNAME                       ,
  Placement.CUSTOMER_FIRST_NAME                           as PAR_FIRSTNAME                      ,
  Placement.CUSTOMER_SIRET                                as PAR_SIRET                          ,
  Placement.CUSTOMER_MARKET_SEG                           as PAR_MARKET_SEG                     ,
  Null                                                    as PAR_TYPE                           ,
  Null                                                    as PAR_EMAIL                          ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_STREET 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_STREET
  End                                                       as PAR_BILL_ADRESS_1                  ,
  Null                                                      as PAR_BILL_ADRESS_2                  ,
  Null                                                      as PAR_BILL_ADRESS_3                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_CITY 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_CITY
  End                                                       as PAR_BILL_ADRESS_4                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_ZIPCODE 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_ZIPCODE
  End                                                       as PAR_BILL_CD_POSTAL_AGR                 ,  
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3) In (${L_PIL_034})
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3)
        When    Placement.INSTALL_ADDRESS_ZIPCODE  Is Not Null
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 2)
        Else    Null
  End                                                     as PAR_DO                             ,
  Placement.PAR_BU_CD                                     as PAR_BU_CD                          ,
  Null                                                    as PAR_USCM                           ,
  Null                                                    as PAR_USCM_DS                        ,
  Null                                                    as PAR_USCM_USCM_DS                   ,
  Null                                                    as PAR_USCM_REGUSCM                   ,
  Null                                                    as PAR_USCM_REGUSCM_DS                ,
  Placement.PAR_IMEI_CD                                   as PAR_MOB_IMEI                       ,
  Placement.PAR_TAC_CD                                    as PAR_MOB_TAC                        ,
  Null                                                    as PAR_MOB_SIM                        ,
  Placement.PAR_IMSI_CD                                   as PAR_MOB_IMSI                       ,
  Placement.PAR_SCORE_NU_INT                              as PAR_SCORE_NU_INT                   ,
  Placement.PAR_SCORE_IN_INT                              as PAR_SCORE_IN_INT                   ,
  Placement.PAR_TRESHOLD_NU_INT                           as PAR_TRESHOLD_NU_INT                ,
  Placement.PAR_SCORE_NU_MOB                              as PAR_SCORE_NU_MOB                   ,
  Placement.PAR_SCORE_IN_MOB                              as PAR_SCORE_IN_MOB                   ,
  Placement.PAR_TRESHOLD_NU_MOB                           as PAR_TRESHOLD_NU_MOB                ,
  Placement.CONTRCT_DT_SIGN_PREC_INT                      as CONTRCT_DT_SIGN_PREC_INT           ,
  Placement.CONTRCT_DT_FIN_PREC_INT                       as CONTRCT_DT_FIN_PREC_INT            ,
  Placement.CONTRCT_DT_DEB_SIGN_POST_INT                  as CONTRCT_DT_DEB_SIGN_POST_INT       ,
  Placement.CONTRCT_DT_FIN_SIGN_POST_INT                  as CONTRCT_DT_FIN_SIGN_POST_INT       ,
  Placement.DUREE_ENGAGEMENT_INT                          as DUREE_ENGAGEMENT_INT               ,
  Placement.TYPE_DUR_ENGAGEMENT_INT                       as TYPE_DUR_ENGAGEMENT_INT            ,
  Placement.CONTRCT_DT_SIGN_PREC_MOB                      as CONTRCT_DT_SIGN_PREC_MOB           ,
  Placement.CONTRCT_DT_FIN_PREC_MOB                       as CONTRCT_DT_FIN_PREC_MOB            ,
  Placement.CONTRCT_DT_SIGN_POST_MOB                      as CONTRCT_DT_SIGN_POST_MOB           ,
  Placement.CONTRCT_DUREE_ENG_MOB                         as CONTRCT_DUREE_ENG_MOB              ,
  Placement.CONTRCT_UNIT_ENG_MOB                          as CONTRCT_UNIT_ENG_MOB               ,
  Null                                                    as CONFIRMATION_IN                    ,
  Null                                                    as CONFIRMATION_DT                    ,
  Null                                                    as CONFIRMATION_CALC_FIN_DT           ,
  Null                                                    as DELIVERY_IN                        ,
  Null                                                    as DELIVERY_DT                        ,
  Null                                                    as DELIVERY_CALC_FIN_DT               ,
  Null                                                    as PERENNITE_IN                       ,
  Null                                                    as PERENNITE_FIN_DT                   ,
  Null                                                    as PERENNITE_CALC_FIN_DT              ,
  Null                                                    as PERENNITE_PVC_IN                   ,
  Null                                                    as PERENNITE_PVC_FIN_DT               ,
  Null                                                    as PERENNITE_PVC_CALC_FIN_DT          ,
  Null                                                    as SEG_COM_ID_LAST_PER                ,
  Null                                                    as SEG_COM_ID_SOLD                    ,
  Null                                                    as SEG_COM_ID_FIND                    ,
  Null                                                    as SEG_FIND_LIVR_DT                   ,
  Null                                                    as SEG_FIND_CANCEL_DT                 ,
  Null                                                    as SEG_COM_ID_NEXT_PARC               ,
  Null                                                    as SEG_NEXT_PARC_LIVR_DT              ,
  Null                                                    as SEG_NEXT_PARC_CANCEL_DT            ,
  Null                                                    as SEG_COM_ID_FINAL_PARC              ,
  Null                                                    as SEG_FINAL_PARC_LIVR_DT             ,
  Null                                                    as SEG_FINAL_PARC_CANCEL_DT           ,
  Null                                                    as SEG_COM_ID_LAST_IN_PARC            ,
  Null                                                    as NB_IN_OUT_PARC                     ,
  Null                                                    as POURCENTAGE_PRES_PARC              ,
  Null                                                    as SEG_PRES_PARC_COMMANDE             ,
  Null                                                    as CONCURENCE_IN                      ,
  Null                                                    as CONCURENCE_CONCLU_IN               ,
  Null                                                    as CONCURENCE_ID                      ,
  Null                                                    as DELIVERY_ONTIME_IN                 ,
  Null                                                    as CHECK_INITIAL_STATUS_CD            ,
  Null                                                    as CHECK_NAT_STATUS_CD                ,
  Null                                                    as CHECK_NAT_COMMENT                  ,
  Null                                                    as CHECK_NAT_STATUS_LN                ,
  Null                                                    as CHECK_LOC_STATUS_CD                ,
  Null                                                    as CHECK_LOC_COMMENT                  ,
  Null                                                    as CHECK_LOC_STATUS_LN                ,
  Null                                                    as CHECK_VALIDT_DT                    ,
  --Cas de cloture de l'acte :
  Case  When Placement.FLAG_FIRST_RECEPTION_PSF not in (0,1)
          Then Placement.ORDER_DEPOSIT_DT
        Else  Null
  End                                                     as CLOSURE_DT                         ,
  Placement.QUEUE_TS                                      as QUEUE_TS                           ,
  Placement.RUN_ID                                        as RUN_ID                             ,
  Placement.STREAMING_TS                                  as STREAMING_TS                       ,
  '${KNB_DATE_VACATION}'                                  as CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                  as LAST_MODIF_TS                      ,
  0                                                       as HOT_IN                             ,
  1                                                       as FRESH_IN                           ,
  0                                                       as COHERENCE_IN                       
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_INT Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_PRECAL ActeSoft
    On    Placement.ACTE_ID           = ActeSoft.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = ActeSoft.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_SOFT Orga
    On    Placement.DISTRBTN_CHANNL_ID                        = Orga.DISTRBTN_CHANNL_ID
      And Placement.FLAG_PLT_CONV                             = Orga.FLAG_PLT_CONV
      And Placement.FLAG_TEAM_MKT                             = Orga.FLAG_TEAM_MKT
      And Placement.FLAG_TYPE_CMP                             = Orga.FLAG_TYPE_CMP
      And Orga.FRESH_IN                                       = 1
      And Orga.CURRENT_IN                                     = 1
      And Orga.CLOSURE_DT                                     is Null
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_WEB Orgaweb
    On    Placement.DISTRBTN_CHANNL_ID                        = Orgaweb.ORG_CHANNL_ID
      And Placement.STORE_NAME                                = Orgaweb.ORG_PDV_CD
      And Orgaweb.FRESH_IN                                    = 1
      And Orgaweb.CURRENT_IN                                  = 1
      And Orgaweb.CLOSURE_DT                                  is Null
  --Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_GRV RetourGRV
  --  On    Placement.ACTE_ID           = RetourGRV.ACTE_ID
  --    And Placement.ORDER_DEPOSIT_DT  = RetourGRV.ORDER_DEPOSIT_DT
Where
  (1=1)
  --Tous les RMP sont Purgés des actes car on fait porter le maintient sans la suppression
  And Placement.EXT_OPER_ID not in ('${P_PIL_098}')
  -- On insert ici les lignes directe
  And
      ( 
        --On veut suivre les produits :
            --Qui sont sur une période valable :
                ActeSoft.PERIODE_ID  = ${P_PIL_049}
            --Dont le produit est défini dans le référentiel 
            Or ActeSoft.PRODUCT_ID  in ('${P_PIL_223}')
            --Et qui sont sur un segment suivi
            Or ActeSoft.SEG_COM_ID  in ('${P_PIL_022}','${P_PIL_295}')
      )
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_INT;
.if errorcode <> 0 then .quit 1

--Pour aller la charge on supprime les lignes qui sont valorisée
Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_PRECAL Where SEG_COM_ID in ('${P_PIL_022}','NS');
.if errorcode <> 0 then .quit 1


.quit 0


