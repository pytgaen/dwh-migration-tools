-- $HEADER: mm2pco/current/sql/ATP_PCO_PreCalcul_ACTE_VAD.sql 13_05#18 20-DEC-2018 10:41:12 LXQG9925
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_PreCalcul_ACTE_VAD.sql$
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     CDR         Création
-- 08/03/2013     XKN         Modification : Modification de la jointure avec PERIODE (inner --> Left) afin de tracer les erreurs PERIODE_ID inocnnues
-- 06/02/2014     AID         Indus
-- 22/09/2014     HZO         Modification : Perform
-- 10/03/2015     HFO         MODIFICATION (ajout champs CHAPP perennité)
-- 18/05/2015     HFO         MODIFICATION (Jointure SO,OT avec AGAP)
-- 18/05/2015     HFO         MODIFICATION (Jointure SO,OT avec AGAP enlève première requete)
-- 06/07/2015     HFO         MODIFICATION (QC 712 nouveaux champs Ajout TARIF_HT)
-- 07/08/2015     HLA         Transofrmation en acte EAN
-- 05/01/2016     MDE         Evol : Calcul CA - TARIF_HT
-- 13/04/2015     MDE         Evol  : profondeur calcul 100 jrs
-- 24/03/2016     OCH         Ajout BCR_ID
-- 28/02/2017     HOB         Terminaux vendus OnLine (sans subvention) aux clients SOSH
-- 16/05/2017     HLA         Modif Pilotag Terminaux
-- 28/12/2017     MEL         Evol Placement EAN
-- 05/10/2018     LMU         Modifications VAD Mobile (RS lot 2)
-- 06/03/2020     EVI         PILCOM-327 : Correction Bornes Dates
-- 21/07/2021     EVI         PILCOM-974 : Migration Assurance Mobile
---------------------------------------------------------------------------------

.set width 2000;

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD 
-- **************************************************************

Delete from ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
(
  ACTE_ID                   ,
  DATE_SAISIE               ,
  CDE_REFERENCE             ,
  SEGMENTVALEURCLIENT       ,
  EXT_OPER_ID               ,
  TYPE_PRODUIT              ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  RGR_TYPE_SRV_CD           ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  PAR_IMSI                  ,
  DOSSIER_DATE_RESIL        ,
  DOSSIER_TYPE_RESIL        ,
  DOSSIER_MOTIF_RESIL       ,
  --debut QC 712
  TARIF_HT                  ,
  BCR_ID                    ,
  --Fin QC 712
  TERM_PERFORM_IND          ,
  IMEI_CD                   ,
  MSISDN_ID                 ,
  CLIENT_NU                 ,
  DOSSIER_NU       
  )
Select
  CalculTypeVAD.ACTE_ID                                       as ACTE_ID                  ,
  CalculTypeVAD.DATE_SAISIE                                   as DATE_SAISIE              ,
  CalculTypeVAD.CDE_REFERENCE                                 as CDE_REFERENCE            ,
  CalculTypeVAD.SEGMENTVALEURCLIENT                           as SEGMENTVALEURCLIENT      ,
  CalculTypeVAD.EXT_OPER_ID                                   as EXT_OPER_ID              ,
  CalculTypeVAD.TYPE_PRODUIT                                  as TYPE_PRODUIT             ,
  CalculTypeVAD.EXT_PRODUCT_ID                                as EXT_PRODUCT_ID           ,
  CalculTypeVAD.PERIODE_ID                                    as PERIODE_ID               ,
  Coalesce(RefProduit.PRODUCT_ID,'${P_PIL_223}')              as PRODUCT_ID_F             ,
  Coalesce(RefSegCom.SEG_COM_ID,'${P_PIL_022}')               as SEG_COM_ID               ,
  RefSegCom.RGR_TYPE_SRV_CD                                   as RGR_TYPE_SRV_CD          ,
  RefSegCom.TYPE_SERVICE                                      as TYPE_SERVICE             ,
  RefSeg.SEG_COM_AGG_ID                                       as SEG_COM_AGG_ID           ,
  Coalesce(RefCat.CODE_MIGRATION,'${P_PIL_024}')              as CODE_MIGRATION           ,
  Coalesce(RefCat.MIGRATION_REGROUPEMENT_ID,'${P_PIL_023}')   as MIGRATION_REGROUPEMENT_ID,
  Coalesce(RegMigPossible.MIGRATION_POSSIBLE,'${P_PIL_020}')  as MIGRATION_POSSIBLE       ,
  CalculTypeVAD.PAR_IMSI                                      as PAR_IMSI                 ,
  CalculTypeVAD.DOSSIER_DATE_RESIL                            as DOSSIER_DATE_RESIL       ,
  CalculTypeVAD.DOSSIER_TYPE_RESIL                            as DOSSIER_TYPE_RESIL       ,
  CalculTypeVAD.DOSSIER_MOTIF_RESIL                           as DOSSIER_MOTIF_RESIL      ,
  --debut QC 712
  Coalesce(CalculTypeVAD.TARIF_HT,RefProduit.TARIF_HT,0)      as TARIF_HT                 ,
  CalculTypeVAD.BCR_ID                                        as BCR_ID                   ,
  --Fin QC 712
  CalculTypeVAD.TERM_PERFORM_IND                              as TERM_PERFORM_IND         ,
  CalculTypeVAD.IMEI_CD                                       as IMEI_CD                  ,
  CalculTypeVAD.MSISDN_ID                                     as MSISDN_ID                ,
  CalculTypeVAD.CLIENT_NU                                     as CLIENT_NU                ,
  CalculTypeVAD.DOSSIER_NU                                    as DOSSIER_NU         
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATE_SAISIE                                             as DATE_SAISIE          ,
      TmpCalc.CDE_REFERENCE                                           as CDE_REFERENCE        ,
      --On Privilégie la jointure sur le produit
      refEAN.PRODUCT_ID                                               as EXT_PRODUCT_ID       ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      '${P_PIL_005}'                                                  as EXT_OPER_ID          ,
      TmpCalc.TYPE_PRODUIT                                            as TYPE_PRODUIT         ,
      TmpCalc.PAR_IMSI                                                as PAR_IMSI             ,
      TmpCalc.DOSSIER_DATE_RESIL                                      as DOSSIER_DATE_RESIL   ,
      TmpCalc.DOSSIER_TYPE_RESIL                                      as DOSSIER_TYPE_RESIL   ,
      TmpCalc.DOSSIER_MOTIF_RESIL                                     as DOSSIER_MOTIF_RESIL  ,
      TmpCalc.BCR_ID                                                  as BCR_ID               ,
      TmpCalc.TERM_PERFORM_IND                                        as TERM_PERFORM_IND     ,
      TmpCalc.TARIF_HT                                                as TARIF_HT             ,
      TmpCalc.IMEI_CD                                                 as IMEI_CD              ,
      TmpCalc.MSISDN_ID                                               as MSISDN_ID            ,
      TmpCalc.CLIENT_NU                                               as CLIENT_NU            ,
      TmpCalc.DOSSIER_NU                                              as DOSSIER_NU     
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                    ,
          Placement.DATE_SAISIE                     as DATE_SAISIE                ,
          Placement.CDE_REFERENCE                   as CDE_REFERENCE              ,
          Case  When    Placement.TYPE_LIG_CDE='T' --Cas d'un Terminal
                  Then  'VAD_TERM'
                When    Placement.TYPE_LIG_CDE='ACC' --Cas d'un Accessoire
                  Then  'VAD_ACC'
                Else    'ERREUR'
          End                                       as PRODUCT_TYPE               ,
          'SC'                                      as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          Placement.EAN_FTT                         as EAN_FTT                    ,
          Placement.TYPE_LIG_CDE                    as TYPE_PRODUIT               ,
          Placement.PAR_IMSI                        as PAR_IMSI                   ,
          Placement.DOSSIER_DATE_RESIL              as DOSSIER_DATE_RESIL         ,
          Placement.DOSSIER_TYPE_RESIL              as DOSSIER_TYPE_RESIL         ,
          Placement.DOSSIER_MOTIF_RESIL             as DOSSIER_MOTIF_RESIL        ,
          Placement.BCR_ID                          as BCR_ID                     ,
          Case  When TYPE_LIG_CDE = 'T'
                  Then Placement.TERM_PERFORM_IND
                Else Null
          End                                       as TERM_PERFORM_IND           ,
          Placement.TARIF_HT                        as TARIF_HT                   ,
          Placement.NUMEROIMEI                      as IMEI_CD                    ,
          Placement.DOSSIER_NU                      as MSISDN_ID                  ,
          Placement.CLIENT_NU                       as CLIENT_NU                  ,  
          Placement.DOSSIER_NU                      as DOSSIER_NU             
        From
          ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD Placement
          Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Period
            On    Placement.DATE_SAISIE >= Period.PERIODE_DATE_DEB
              And Placement.DATE_SAISIE <= Period.PERIODE_DATE_FIN
              And Period.FRESH_IN       = 1
              And Period.CURRENT_IN     = 1
              And Period.CLOSURE_DT     Is null
        Where (1=1)
          And TYPE_LIG_CDE              in ('T','ACC') -- selection des accessoires et terminaux uniquement
          And Placement.CLOSURE_DT      Is null
          And Placement.DATE_SAISIE     >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')      
          And Placement.DATE_SAISIE     >= (Current_date - ${P_PIL_542}) 
      )TmpCalc
      --Jointure pour récupérer les code EAN
        Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_EAN refEAN
                On refEAN.CODE_EAN = TmpCalc.EAN_FTT
                and refEAN.PERIODE_ID = TmpCalc.PERIODE_ID
                And refEAN.CODE_EAN Is not null
                And refEAN.CURRENT_IN      =  1
                And refEAN.CLOSURE_DT      Is null

  )CalculTypeVAD
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefProduit
    On    CalculTypeVAD.EXT_PRODUCT_ID      = RefProduit.EXT_PRODUCT_ID1
      And CalculTypeVAD.PERIODE_ID          = RefProduit.PERIODE_ID  
      And RefProduit.FRESH_IN               = 1
      And RefProduit.CURRENT_IN             = 1
      And RefProduit.CLOSURE_DT             Is null
  Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
    On    RefProduit.PRODUCT_ID             = RefSegCom.PRODUCT_ID
      And RefSegCom.FRESH_IN                = 1
      And RefSegCom.CURRENT_IN              = 1
      And RefSegCom.CLOSURE_DT              Is null
      And RefSegCom.PERIODE_ID              = CalculTypeVAD.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSeg
    On    RefSegCom.SEG_COM_ID              = RefSeg.SEG_COM_ID
      And RefSeg.FRESH_IN                   = 1
      And RefSeg.CURRENT_IN                 = 1
      And RefSeg.CLOSURE_DT                 is null
      And RefSeg.PERIODE_ID=RefSegCom.PERIODE_ID  
  Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_LIEN_SEGCOM_PILCOM RefCat
    On    RefSegCom.SEG_COM_ID              = RefCat.SEG_COM_ID
      And RefCat.FRESH_IN                   = 1
      And RefCat.CURRENT_IN                 = 1
      And RefCat.CLOSURE_DT                 is null
      And RefCat.PERIODE_ID                 = RefSegCom.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_REGR_MIGR_PILCOM RegMigPossible
    On    RefCat.MIGRATION_REGROUPEMENT_ID  = RegMigPossible.MIGRATION_REGROUPEMENT_ID
      And RegMigPossible.FRESH_IN           = 1
      And RegMigPossible.CURRENT_IN         = 1
      And RegMigPossible.CLOSURE_DT         Is null
      And RegMigPossible.PERIODE_ID         = RefCat.PERIODE_ID
Where PRODUCT_ID_F Not In ('${P_PIL_223}')
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
(
  ACTE_ID                   ,
  DATE_SAISIE               ,
  CDE_REFERENCE             ,
  SEGMENTVALEURCLIENT       ,
  EXT_OPER_ID               ,
  TYPE_PRODUIT              ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  RGR_TYPE_SRV_CD           ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  PAR_IMSI                  ,
  DOSSIER_DATE_RESIL        ,
  DOSSIER_TYPE_RESIL        ,
  DOSSIER_MOTIF_RESIL       ,
  --debut QC 712
  TARIF_HT                  ,
  BCR_ID                    ,
  --Fin QC 712
  TERM_PERFORM_IND          ,
  IMEI_CD                   ,
  MSISDN_ID                 ,
  CLIENT_NU                 ,
  DOSSIER_NU       
)
Select
  CalculTypeVAD.ACTE_ID                                       as ACTE_ID                  ,
  CalculTypeVAD.DATE_SAISIE                                   as DATE_SAISIE              ,
  CalculTypeVAD.CDE_REFERENCE                                 as CDE_REFERENCE            ,
  CalculTypeVAD.SEGMENTVALEURCLIENT                           as SEGMENTVALEURCLIENT      ,
  CalculTypeVAD.EXT_OPER_ID                                   as EXT_OPER_ID              ,
  CalculTypeVAD.TYPE_PRODUIT                                  as TYPE_PRODUIT             ,
  CalculTypeVAD.EXT_PRODUCT_ID                                as EXT_PRODUCT_ID           ,
  CalculTypeVAD.PERIODE_ID                                    as PERIODE_ID               ,
  Coalesce(RefProduit.PRODUCT_ID,'${P_PIL_223}')              as PRODUCT_ID               ,
  Coalesce(RefSegCom.SEG_COM_ID,'${P_PIL_022}')               as SEG_COM_ID               ,
  RefSegCom.RGR_TYPE_SRV_CD                                   as RGR_TYPE_SRV_CD          ,
  RefSegCom.TYPE_SERVICE                                      as TYPE_SERVICE             ,
  RefSeg.SEG_COM_AGG_ID                                       as SEG_COM_AGG_ID           ,
  Coalesce(RefCat.CODE_MIGRATION,'${P_PIL_024}')              as CODE_MIGRATION           ,
  Coalesce(RefCat.MIGRATION_REGROUPEMENT_ID,'${P_PIL_023}')   as MIGRATION_REGROUPEMENT_ID,
  Case  When CalculTypeVAD.TYPE_PRODUIT ='OT'
          Then Coalesce(RegMigPossible.MIGRATION_POSSIBLE,'${P_PIL_020}')
        When CalculTypeVAD.TYPE_PRODUIT ='SO' 
          Then 
            Case When RefSeg.SEG_COM_AGG_ID = 'ASSURMOB'
                    Then Coalesce(RegMigPossible.MIGRATION_POSSIBLE,'${P_PIL_020}')
                  Else '${P_PIL_020}'
            End
        Else   '${P_PIL_020}'
  End                                                         as MIGRATION_POSSIBLE       ,
  CalculTypeVAD.PAR_IMSI                                      as PAR_IMSI                 ,
  CalculTypeVAD.DOSSIER_DATE_RESIL                            as DOSSIER_DATE_RESIL       ,
  CalculTypeVAD.DOSSIER_TYPE_RESIL                            as DOSSIER_TYPE_RESIL       ,
  CalculTypeVAD.DOSSIER_MOTIF_RESIL                           as DOSSIER_MOTIF_RESIL      ,
  --debut QC 712
  Coalesce(RefProduit.TARIF_HT,0)                             as TARIF_HT                 ,
  CalculTypeVAD.BCR_ID                                        as BCR_ID                   ,
  --Fin QC 712
  CalculTypeVAD.TERM_PERFORM_IND                              as TERM_PERFORM_IND         ,
  CalculTypeVAD.IMEI_CD                                       as IMEI_CD                  ,
  CalculTypeVAD.MSISDN_ID                                     as MSISDN_ID                ,
  CalculTypeVAD.CLIENT_NU                                     as CLIENT_NU                ,
  CalculTypeVAD.DOSSIER_NU                                    as DOSSIER_NU         
From
  (
    Select
      Placement.ACTE_ID                       as ACTE_ID                    ,
      Placement.DATE_SAISIE                   as DATE_SAISIE                ,
      Placement.CDE_REFERENCE                 as CDE_REFERENCE              ,
      'SC'                                    as SEGMENTVALEURCLIENT        ,
      '${P_PIL_005}'                          as EXT_OPER_ID                ,
      Placement.TYPE_LIG_CDE                  as TYPE_PRODUIT               ,
      Coalesce(Period.PERIODE_ID, ${P_PIL_049})         as PERIODE_ID       ,
      Placement.EXT_PRODUCT_ID                as EXT_PRODUCT_ID             ,
      Placement.PAR_IMSI                      as PAR_IMSI                   ,
      Placement.DOSSIER_DATE_RESIL            as DOSSIER_DATE_RESIL         ,
      Placement.DOSSIER_TYPE_RESIL            as DOSSIER_TYPE_RESIL         ,
      Placement.DOSSIER_MOTIF_RESIL           as DOSSIER_MOTIF_RESIL        ,
      Placement.BCR_ID                        as BCR_ID                     ,
      Null                                    as TERM_PERFORM_IND           ,
      Placement.NUMEROIMEI                    as IMEI_CD                    ,
      Placement.DOSSIER_NU                    as MSISDN_ID                  ,
      Placement.CLIENT_NU                     as CLIENT_NU                  ,  
      Placement.DOSSIER_NU                    as DOSSIER_NU             
    From
      ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD Placement
      Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
        On    Placement.DATE_SAISIE >= Period.PERIODE_DATE_DEB
          And Placement.DATE_SAISIE <= Period.PERIODE_DATE_FIN
          And Period.FRESH_IN       = 1
          And Period.CURRENT_IN     = 1
          And Period.CLOSURE_DT     Is null
    Where
      (1=1)
      And TYPE_LIG_CDE in ('OT','SO') -- selection des OT et SO
      And Placement.CLOSURE_DT Is null
      And Placement.DATE_SAISIE     >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
      And Placement.DATE_SAISIE     >= (Current_date - ${P_PIL_542}) 
  )CalculTypeVAD
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefProduit
    On    CalculTypeVAD.EXT_PRODUCT_ID      = RefProduit.EXT_PRODUCT_ID1
      And CalculTypeVAD.TYPE_PRODUIT        = Case  When RefProduit.TYPE_PRODUIT in ('OA','OC','NS')
                                                      Then 'SO'
                                                    Else RefProduit.TYPE_PRODUIT
                                              End
      And CalculTypeVAD.PERIODE_ID          = RefProduit.PERIODE_ID 
      And RefProduit.FRESH_IN               = 1
      And RefProduit.CURRENT_IN             = 1
      And RefProduit.CLOSURE_DT             Is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
    On    RefProduit.PRODUCT_ID           = RefSegCom.PRODUCT_ID
      And RefSegCom.PERIODE_ID            = CalculTypeVAD.PERIODE_ID
      And RefSegCom.FRESH_IN              = 1
      And RefSegCom.CURRENT_IN            = 1
      And RefSegCom.CLOSURE_DT            Is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSeg
    On    RefSegCom.SEG_COM_ID            = RefSeg.SEG_COM_ID
      And RefSeg.FRESH_IN                 = 1
      And RefSeg.CURRENT_IN               = 1
      And RefSeg.CLOSURE_DT               is null
      And RefSeg.PERIODE_ID=RefSegCom.PERIODE_ID  
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCat
    On    RefSegCom.SEG_COM_ID            = RefCat.SEG_COM_ID
      And RefCat.PERIODE_ID               = RefSegCom.PERIODE_ID
      And RefCat.FRESH_IN                 = 1
      And RefCat.CURRENT_IN               = 1
      And RefCat.CLOSURE_DT               is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REGR_MIGR_PILCOM RegMigPossible
    On    RefCat.MIGRATION_REGROUPEMENT_ID  = RegMigPossible.MIGRATION_REGROUPEMENT_ID
      And RegMigPossible.PERIODE_ID         = RefCat.PERIODE_ID
      And RegMigPossible.FRESH_IN           = 1
      And RegMigPossible.CURRENT_IN         = 1
      And RegMigPossible.CLOSURE_DT         Is null
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
(
  ACTE_ID                   ,
  DATE_SAISIE               ,
  CDE_REFERENCE             ,
  SEGMENTVALEURCLIENT       ,
  EXT_OPER_ID               ,
  TYPE_PRODUIT              ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  RGR_TYPE_SRV_CD           ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  PAR_IMSI                  ,
  DOSSIER_DATE_RESIL        ,
  DOSSIER_TYPE_RESIL        ,
  DOSSIER_MOTIF_RESIL       ,
    --debut QC 712
  TARIF_HT                  ,
  BCR_ID                    ,
  --Fin QC 712
  TERM_PERFORM_IND          ,
  IMEI_CD                   ,
  MSISDN_ID                 ,
  CLIENT_NU                 ,
  DOSSIER_NU       
)
Select
  CalculTypeVAD.ACTE_ID                                       as ACTE_ID                  ,
  CalculTypeVAD.DATE_SAISIE                                   as DATE_SAISIE              ,
  CalculTypeVAD.CDE_REFERENCE                                 as CDE_REFERENCE            ,
  CalculTypeVAD.SEGMENTVALEURCLIENT                           as SEGMENTVALEURCLIENT      ,
  CalculTypeVAD.EXT_OPER_ID                                   as EXT_OPER_ID              ,
  CalculTypeVAD.TYPE_PRODUIT                                  as TYPE_PRODUIT             ,
  CalculTypeVAD.EXT_PRODUCT_ID                                as EXT_PRODUCT_ID           ,
  CalculTypeVAD.PERIODE_ID                                    as PERIODE_ID               ,
  Coalesce(CalculTypeVAD.PRODUCT_ID,'${P_PIL_223}')           as PRODUCT_ID               ,
  Coalesce(CalculTypeVAD.SEG_COM_ID,'${P_PIL_022}')           as SEG_COM_ID               ,
  CalculTypeVAD.RGR_TYPE_SRV_CD                               as RGR_TYPE_SRV_CD          ,
  CalculTypeVAD.TYPE_SERVICE                                  as TYPE_SERVICE             ,
  CalculTypeVAD.SEG_COM_AGG_ID                                as SEG_COM_AGG_ID           ,
  Coalesce(CalculTypeVAD.CODE_MIGRATION,'${P_PIL_024}')       as CODE_MIGRATION           ,
  Coalesce(CalculTypeVAD.MIGRATION_REGROUPEMENT_ID,'${P_PIL_023}')   as MIGRATION_REGROUPEMENT_ID,
  Coalesce(CalculTypeVAD.MIGRATION_POSSIBLE,'${P_PIL_020}')   as MIGRATION_POSSIBLE       ,
  CalculTypeVAD.PAR_IMSI                                      as PAR_IMSI                 ,
  CalculTypeVAD.DOSSIER_DATE_RESIL                            as DOSSIER_DATE_RESIL       ,
  CalculTypeVAD.DOSSIER_TYPE_RESIL                            as DOSSIER_TYPE_RESIL       ,
  CalculTypeVAD.DOSSIER_MOTIF_RESIL                           as DOSSIER_MOTIF_RESIL      ,
  --debut QC 712
  Coalesce(CalculTypeVAD.TARIF_PL_HT,CalculTypeVAD.TARIF_HT,0)     as TARIF_HT                 ,
  CalculTypeVAD.BCR_ID                                        as BCR_ID                   ,
  --Fin QC 712
  CalculTypeVAD.TERM_PERFORM_IND                              as TERM_PERFORM_IND         ,
  CalculTypeVAD.IMEI_CD                                       as IMEI_CD                  ,
  CalculTypeVAD.MSISDN_ID                                     as MSISDN_ID                ,
  CalculTypeVAD.CLIENT_NU                                     as CLIENT_NU                ,
  CalculTypeVAD.DOSSIER_NU                                    as DOSSIER_NU         
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATE_SAISIE                                             as DATE_SAISIE          ,
      TmpCalc.CDE_REFERENCE                                           as CDE_REFERENCE        ,
      --On Privilégie la jointure sur le produit
     'NULL'                                                           as EXT_PRODUCT_ID       ,
      TypeEAN.PRODUCT_ID                                              as PRODUCT_ID           ,
      TypeEAN.SEG_COM_ID                                              as SEG_COM_ID           ,
      TypeEAN.RGR_TYPE_SRV_CD                                         as RGR_TYPE_SRV_CD      ,
      TypeEAN.TYPE_SERVICE                                            as TYPE_SERVICE         ,
      TypeEAN.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID       ,
      TypeEAN.CODE_MIGRATION                                          as CODE_MIGRATION       ,
      TypeEAN.MIGRATION_REGROUPEMENT_ID                               as MIGRATION_REGROUPEMENT_ID ,
      TypeEAN.MIGRATION_POSSIBLE                                      as MIGRATION_POSSIBLE   ,
      TypeEAN.TARIF_HT                                                as TARIF_HT             ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      '${P_PIL_005}'                                                  as EXT_OPER_ID          ,
      TmpCalc.TYPE_PRODUIT                                            as TYPE_PRODUIT         ,
      TmpCalc.PAR_IMSI                                                as PAR_IMSI             ,
      TmpCalc.DOSSIER_DATE_RESIL                                      as DOSSIER_DATE_RESIL   ,
      TmpCalc.DOSSIER_TYPE_RESIL                                      as DOSSIER_TYPE_RESIL   ,
      TmpCalc.DOSSIER_MOTIF_RESIL                                     as DOSSIER_MOTIF_RESIL  ,
      TmpCalc.BCR_ID                                                  as BCR_ID               ,
      TmpCalc.TERM_PERFORM_IND                                        as TERM_PERFORM_IND     ,
      TmpCalc.TARIF_HT                                                as TARIF_PL_HT          ,
      TmpCalc.IMEI_CD                                                 as IMEI_CD              ,
      TmpCalc.MSISDN_ID                                               as MSISDN_ID            ,
      TmpCalc.CLIENT_NU                                               as CLIENT_NU            ,
      TmpCalc.DOSSIER_NU                                              as DOSSIER_NU     
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                    ,
          Placement.DATE_SAISIE                     as DATE_SAISIE                ,
          Placement.CDE_REFERENCE                   as CDE_REFERENCE              ,
          Case  When    Placement.TYPE_LIG_CDE='T' --Cas d'un Terminal
                  Then  'VAD_TERM'
                When    Placement.TYPE_LIG_CDE='ACC' --Cas d'un Accessoire
                  Then  'VAD_ACC'
                Else    'ERREUR'
          End                                       as PRODUCT_TYPE               ,
          'SC'                                      as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          Placement.EAN_FTT                         as EAN_FTT                    ,
          Placement.TYPE_LIG_CDE                    as TYPE_PRODUIT               ,
          Placement.PAR_IMSI                        as PAR_IMSI                   ,
          Placement.DOSSIER_DATE_RESIL              as DOSSIER_DATE_RESIL         ,
          Placement.DOSSIER_TYPE_RESIL              as DOSSIER_TYPE_RESIL         ,
          Placement.DOSSIER_MOTIF_RESIL             as DOSSIER_MOTIF_RESIL        ,
          Placement.BCR_ID                          as BCR_ID                     ,
          Case  When TYPE_LIG_CDE = 'T'
                  Then Placement.TERM_PERFORM_IND
                Else Null
          End                                       as TERM_PERFORM_IND           ,
          Placement.TARIF_HT                        as TARIF_HT                   ,
          Placement.NUMEROIMEI                      as IMEI_CD                    ,
          Placement.DOSSIER_NU                      as MSISDN_ID                  ,
          Placement.CLIENT_NU                       as CLIENT_NU                  ,  
          Placement.DOSSIER_NU                      as DOSSIER_NU             
        From
          ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD Placement
          Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Period
            On    Placement.DATE_SAISIE >= Period.PERIODE_DATE_DEB
              And Placement.DATE_SAISIE <= Period.PERIODE_DATE_FIN
              And Period.FRESH_IN       = 1
              And Period.CURRENT_IN     = 1
              And Period.CLOSURE_DT     Is null
        Where (1=1)
          And TYPE_LIG_CDE              in ('T','ACC') -- selection des accessoires et terminaux uniquement
          And Placement.CLOSURE_DT      Is null
          And Placement.DATE_SAISIE     >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')      
          And Placement.DATE_SAISIE     >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
          And Placement.DATE_SAISIE     >= (Current_date - ${P_PIL_542})
      )TmpCalc
      --Jointure pour récupérer les code EAN
      Inner Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN TypeEAN
        On      TmpCalc.EAN_FTT                     = TypeEAN.CODE_EAN
            And TmpCalc.PERIODE_ID                  = TypeEAN.PERIODE_ID
      Where
      (1=1)
      And Not Exists
          (
              Select
                1
              From
                ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD RefId
              Where
                (1=1)
                And TmpCalc.ACTE_ID           = RefId.ACTE_ID
                And TmpCalc.DATE_SAISIE       = RefId.DATE_SAISIE
          )
  )CalculTypeVAD
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
(
  ACTE_ID                   ,
  DATE_SAISIE               ,
  CDE_REFERENCE             ,
  SEGMENTVALEURCLIENT       ,
  EXT_OPER_ID               ,
  TYPE_PRODUIT              ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  RGR_TYPE_SRV_CD           ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  PAR_IMSI                  ,
  DOSSIER_DATE_RESIL        ,
  DOSSIER_TYPE_RESIL        ,
  DOSSIER_MOTIF_RESIL       ,
  --debut QC 712
  TARIF_HT                  ,
  BCR_ID                    ,
  --Fin QC 712
  TERM_PERFORM_IND          ,
  IMEI_CD                   ,
  MSISDN_ID                 ,
  CLIENT_NU                 ,
  DOSSIER_NU       

)
Select
  CalculTypeVAD.ACTE_ID                                       as ACTE_ID                  ,
  CalculTypeVAD.DATE_SAISIE                                   as DATE_SAISIE              ,
  CalculTypeVAD.CDE_REFERENCE                                 as CDE_REFERENCE            ,
  CalculTypeVAD.SEGMENTVALEURCLIENT                           as SEGMENTVALEURCLIENT      ,
  CalculTypeVAD.EXT_OPER_ID                                   as EXT_OPER_ID              ,
  CalculTypeVAD.TYPE_PRODUIT                                  as TYPE_PRODUIT             ,
  CalculTypeVAD.EXT_PRODUCT_ID                                as EXT_PRODUCT_ID           ,
  CalculTypeVAD.PERIODE_ID                                    as PERIODE_ID               ,
  Coalesce(CalculTypeVAD.PRODUCT_ID,'${P_PIL_223}')           as PRODUCT_ID               ,
  Coalesce(CalculTypeVAD.SEG_COM_ID,'${P_PIL_022}')           as SEG_COM_ID               ,
  CalculTypeVAD.RGR_TYPE_SRV_CD                               as RGR_TYPE_SRV_CD          ,
  CalculTypeVAD.TYPE_SERVICE                                  as TYPE_SERVICE             ,
  CalculTypeVAD.SEG_COM_AGG_ID                                as SEG_COM_AGG_ID           ,
  Coalesce(CalculTypeVAD.CODE_MIGRATION,'${P_PIL_024}')       as CODE_MIGRATION           ,
  Coalesce(CalculTypeVAD.MIGRATION_REGROUPEMENT_ID,'${P_PIL_023}')   as MIGRATION_REGROUPEMENT_ID,
  Coalesce(CalculTypeVAD.MIGRATION_POSSIBLE,'${P_PIL_020}')   as MIGRATION_POSSIBLE       ,
  CalculTypeVAD.PAR_IMSI                                      as PAR_IMSI                 ,
  CalculTypeVAD.DOSSIER_DATE_RESIL                            as DOSSIER_DATE_RESIL       ,
  CalculTypeVAD.DOSSIER_TYPE_RESIL                            as DOSSIER_TYPE_RESIL       ,
  CalculTypeVAD.DOSSIER_MOTIF_RESIL                           as DOSSIER_MOTIF_RESIL      ,
  --debut QC 712
  Coalesce(CalculTypeVAD.TARIF_PL_HT,CalculTypeVAD.TARIF_HT,0) as TARIF_HT                 ,
  CalculTypeVAD.BCR_ID                                        as BCR_ID                     ,
  --Fin QC 712
  CalculTypeVAD.TERM_PERFORM_IND                              as TERM_PERFORM_IND         ,
  CalculTypeVAD.IMEI_CD                                       as IMEI_CD                  ,
  CalculTypeVAD.MSISDN_ID                                     as MSISDN_ID                ,
  CalculTypeVAD.CLIENT_NU                                     as CLIENT_NU                ,
  CalculTypeVAD.DOSSIER_NU                                    as DOSSIER_NU         
  
From

  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATE_SAISIE                                             as DATE_SAISIE          ,
      TmpCalc.CDE_REFERENCE                                           as CDE_REFERENCE        ,
      --On Privilégie la jointure sur le produit
      'NULL'                                                          as EXT_PRODUCT_ID       ,
      TypeEAN.PRODUCT_ID                                              as PRODUCT_ID           ,
      TypeEAN.SEG_COM_ID                                              as SEG_COM_ID           ,
      RefSegCom.RGR_TYPE_SRV_CD                                       as RGR_TYPE_SRV_CD      ,
      TypeEAN.TYPE_SERVICE                                            as TYPE_SERVICE         ,
      TypeEAN.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID ,
      TypeEAN.CODE_MIGRATION                                          as CODE_MIGRATION      ,
      TypeEAN.MIGRATION_REGROUPEMENT_ID                               as MIGRATION_REGROUPEMENT_ID ,
      TypeEAN.MIGRATION_POSSIBLE                                      as MIGRATION_POSSIBLE      ,
      TypeEAN.TARIF_HT                                                as TARIF_HT    ,  
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      '${P_PIL_005}'                                                  as EXT_OPER_ID          ,
      TmpCalc.TYPE_PRODUIT                                            as TYPE_PRODUIT         ,
      TmpCalc.PAR_IMSI                                                as PAR_IMSI             ,
      TmpCalc.DOSSIER_DATE_RESIL                                      as DOSSIER_DATE_RESIL   ,
      TmpCalc.DOSSIER_TYPE_RESIL                                      as DOSSIER_TYPE_RESIL   ,
      TmpCalc.DOSSIER_MOTIF_RESIL                                     as DOSSIER_MOTIF_RESIL  ,
      TmpCalc.BCR_ID                                                  as BCR_ID               ,
      TmpCalc.TERM_PERFORM_IND                                        as TERM_PERFORM_IND     ,
      TmpCalc.TARIF_HT                                                as TARIF_PL_HT          ,
      TmpCalc.IMEI_CD                                                 as IMEI_CD              ,
      TmpCalc.MSISDN_ID                                               as MSISDN_ID            ,
      TmpCalc.CLIENT_NU                                               as CLIENT_NU            ,
      TmpCalc.DOSSIER_NU                                              as DOSSIER_NU     
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                    ,
          Placement.DATE_SAISIE                     as DATE_SAISIE                ,
          Placement.CDE_REFERENCE                   as CDE_REFERENCE              ,
          Case  When    Placement.TYPE_LIG_CDE='T' --Cas d'un Terminal
                  Then  'VAD_TERM'
                When    Placement.TYPE_LIG_CDE='ACC' --Cas d'un Accessoire
                  Then  'VAD_ACC'
                Else    'ERREUR'
          End                                       as PRODUCT_TYPE               ,
          'SC'                                      as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          Placement.EAN_FTT                         as EAN_FTT                    ,
          Placement.TYPE_LIG_CDE                    as TYPE_PRODUIT               ,
          Placement.PAR_IMSI                        as PAR_IMSI                   ,
          Placement.DOSSIER_DATE_RESIL              as DOSSIER_DATE_RESIL         ,
          Placement.DOSSIER_TYPE_RESIL              as DOSSIER_TYPE_RESIL         ,
          Placement.DOSSIER_MOTIF_RESIL             as DOSSIER_MOTIF_RESIL        ,
          Placement.BCR_ID                          as BCR_ID                     ,
          Case  When TYPE_LIG_CDE = 'T'
                  Then Placement.TERM_PERFORM_IND
                Else Null
          End                                       as TERM_PERFORM_IND            ,
          Placement.TARIF_HT                        as TARIF_HT                    ,
          Placement.NUMEROIMEI                      as IMEI_CD                    ,
          Placement.DOSSIER_NU                      as MSISDN_ID                  ,
          Placement.CLIENT_NU                       as CLIENT_NU                  ,  
          Placement.DOSSIER_NU                      as DOSSIER_NU             
        From
          ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD Placement
          Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Period
            On    Placement.DATE_SAISIE >= Period.PERIODE_DATE_DEB
              And Placement.DATE_SAISIE <= Period.PERIODE_DATE_FIN
              And Period.FRESH_IN       = 1
              And Period.CURRENT_IN     = 1
              And Period.CLOSURE_DT     Is null
        Where (1=1)
          And TYPE_LIG_CDE              in ('T','ACC') -- selection des accessoires et terminaux uniquement
          And Placement.CLOSURE_DT      Is null
          And Placement.DATE_SAISIE     >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')      
          And Placement.DATE_SAISIE     >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
          And Placement.DATE_SAISIE     >= (Current_date - ${P_PIL_542})
      )TmpCalc
      --Jointure pour récupérer EAN
        Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB TypeEAN
            On  Case  When TmpCalc.TYPE_PRODUIT = 'T'
                        Then 'PV_0000005'
                      When TmpCalc.TYPE_PRODUIT = 'ACC'
                        Then 'PV_0000003'
                End                                = TypeEAN.PRODUCT_ID
            And TmpCalc.PERIODE_ID                 = TypeEAN.PERIODE_ID
        Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
            On RefSegCom.PRODUCT_ID   = TypeEAN.PRODUCT_ID
           And RefSegCom.PERIODE_ID = TmpCalc.PERIODE_ID
           And RefSegCom.FRESH_IN              = 1
           And RefSegCom.CURRENT_IN            = 1
           And RefSegCom.CLOSURE_DT            Is null
            Where 
                (1=1)
                And Not Exists
                    (
                        Select
                         1
                        From
                          ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD RefId
                        Where
                         (1=1)
                         And TmpCalc.ACTE_ID           = RefId.ACTE_ID
                         And TmpCalc.DATE_SAISIE       = RefId.DATE_SAISIE
                    )
     
            --Jointure pour récupérer 
  )CalculTypeVAD
;
.if errorcode <> 0 then .quit 1

-- *************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
-- Partie RCS
-- **************************************************************
Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD
(
  ACTE_ID                   ,
  DATE_SAISIE               ,
  CDE_REFERENCE             ,
  SEGMENTVALEURCLIENT       ,
  EXT_OPER_ID               ,
  TYPE_PRODUIT              ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  RGR_TYPE_SRV_CD           ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  PAR_IMSI                  ,
  DOSSIER_DATE_RESIL        ,
  DOSSIER_TYPE_RESIL        ,
  DOSSIER_MOTIF_RESIL       ,
  --debut QC 712
  TARIF_HT                  ,
  BCR_ID                    ,
  --Fin QC 712
  TERM_PERFORM_IND          ,
  IMEI_CD                   ,
  MSISDN_ID                 ,
  CLIENT_NU                 ,
  DOSSIER_NU       
)
Select
  CalculTypeVAD.ACTE_ID                                              as ACTE_ID                  ,
  CalculTypeVAD.DATE_SAISIE                                          as DATE_SAISIE              ,
  CalculTypeVAD.CDE_REFERENCE                                        as CDE_REFERENCE            ,
  CalculTypeVAD.SEGMENTVALEURCLIENT                                  as SEGMENTVALEURCLIENT      ,
  CalculTypeVAD.EXT_OPER_ID                                          as EXT_OPER_ID              ,
  CalculTypeVAD.TYPE_PRODUIT                                         as TYPE_PRODUIT             ,
  CalculTypeVAD.EXT_PRODUCT_ID                                       as EXT_PRODUCT_ID           ,
  CalculTypeVAD.PERIODE_ID                                           as PERIODE_ID               ,
  Coalesce(CalculTypeVAD.PRODUCT_ID,'${P_PIL_223}')                  as PRODUCT_ID               ,
  Coalesce(CalculTypeVAD.SEG_COM_ID,'${P_PIL_022}')                  as SEG_COM_ID               ,
  CalculTypeVAD.RGR_TYPE_SRV_CD                                      as RGR_TYPE_SRV_CD          ,
  CalculTypeVAD.TYPE_SERVICE                                         as TYPE_SERVICE             ,
  CalculTypeVAD.SEG_COM_AGG_ID                                       as SEG_COM_AGG_ID           ,
  Coalesce(CalculTypeVAD.CODE_MIGRATION,'${P_PIL_024}')              as CODE_MIGRATION           ,
  Coalesce(CalculTypeVAD.MIGRATION_REGROUPEMENT_ID,'${P_PIL_023}')   as MIGRATION_REGROUPEMENT_ID,
  Coalesce(CalculTypeVAD.MIGRATION_POSSIBLE,'${P_PIL_020}')          as MIGRATION_POSSIBLE       ,
  CalculTypeVAD.PAR_IMSI                                             as PAR_IMSI                 ,
  CalculTypeVAD.DOSSIER_DATE_RESIL                                   as DOSSIER_DATE_RESIL       ,
  CalculTypeVAD.DOSSIER_TYPE_RESIL                                   as DOSSIER_TYPE_RESIL       ,
  CalculTypeVAD.DOSSIER_MOTIF_RESIL                                  as DOSSIER_MOTIF_RESIL      ,
  --debut QC 712
  Coalesce(CalculTypeVAD.TARIF_PL_HT,CalculTypeVAD.TARIF_HT,0)       as TARIF_HT                 ,
  CalculTypeVAD.BCR_ID                                               as BCR_ID                     ,
  --Fin QC 712
  CalculTypeVAD.TERM_PERFORM_IND                                     as TERM_PERFORM_IND         ,
  CalculTypeVAD.IMEI_CD                                              as IMEI_CD                  ,
  CalculTypeVAD.MSISDN_ID                                            as MSISDN_ID                ,
  CalculTypeVAD.CLIENT_NU                                            as CLIENT_NU                ,
  CalculTypeVAD.DOSSIER_NU                                           as DOSSIER_NU         
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATE_SAISIE                                             as DATE_SAISIE          ,
      TmpCalc.CDE_REFERENCE                                           as CDE_REFERENCE        ,
      --On Privilégie la jointure sur le produit
      'NULL'                                                          as EXT_PRODUCT_ID       ,
      RCS_Refcom.PRODUCT_ID                                           as PRODUCT_ID           ,
      RCS_Refcom.SEG_COM_ID                                           as SEG_COM_ID           ,
      RCS_Refcom.RGR_TYPE_SRV_CD                                      as RGR_TYPE_SRV_CD      ,
      RCS_Refcom.TYPE_SERVICE                                         as TYPE_SERVICE         ,
      RCS_Refcom.SEG_COM_AGG_ID                                       as SEG_COM_AGG_ID ,
      Null                                                            as CODE_MIGRATION      ,
      Null                                                            as MIGRATION_REGROUPEMENT_ID ,
      Null                                                            as MIGRATION_POSSIBLE      ,
      RCS_Refcom.TARIF_HT                                             as TARIF_HT    ,  
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      '${P_PIL_005}'                                                  as EXT_OPER_ID          ,
      TmpCalc.TYPE_PRODUIT                                            as TYPE_PRODUIT         ,
      TmpCalc.PAR_IMSI                                                as PAR_IMSI             ,
      TmpCalc.DOSSIER_DATE_RESIL                                      as DOSSIER_DATE_RESIL   ,
      TmpCalc.DOSSIER_TYPE_RESIL                                      as DOSSIER_TYPE_RESIL   ,
      TmpCalc.DOSSIER_MOTIF_RESIL                                     as DOSSIER_MOTIF_RESIL  ,
      TmpCalc.BCR_ID                                                  as BCR_ID               ,
      TmpCalc.TERM_PERFORM_IND                                        as TERM_PERFORM_IND     ,
      TmpCalc.TARIF_HT                                                as TARIF_PL_HT          ,
      TmpCalc.IMEI_CD                                                 as IMEI_CD              ,
      TmpCalc.MSISDN_ID                                               as MSISDN_ID            ,
      TmpCalc.CLIENT_NU                                               as CLIENT_NU            ,
      TmpCalc.DOSSIER_NU                                              as DOSSIER_NU     
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                    ,
          Placement.DATE_SAISIE                     as DATE_SAISIE                ,
          Placement.CDE_REFERENCE                   as CDE_REFERENCE              ,
          Null                                      as PRODUCT_TYPE               ,
          'SC'                                      as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          Placement.RCS_CODE_ADV_MOTIF              as EXT_PRODUCT_ID             ,
          Placement.EAN_FTT                         as EAN_FTT                    ,
          Placement.TYPE_LIG_CDE                    as TYPE_PRODUIT               ,
          Placement.PAR_IMSI                        as PAR_IMSI                   ,
          Placement.DOSSIER_DATE_RESIL              as DOSSIER_DATE_RESIL         ,
          Placement.DOSSIER_TYPE_RESIL              as DOSSIER_TYPE_RESIL         ,
          Placement.DOSSIER_MOTIF_RESIL             as DOSSIER_MOTIF_RESIL        ,
          Placement.BCR_ID                          as BCR_ID                     ,
          Null                                      as TERM_PERFORM_IND           ,
          Placement.TARIF_HT                        as TARIF_HT                   ,
          Placement.NUMEROIMEI                      as IMEI_CD                    ,
          Placement.DOSSIER_NU                      as MSISDN_ID                  ,
          Placement.CLIENT_NU                       as CLIENT_NU                  ,  
          Placement.DOSSIER_NU                      as DOSSIER_NU             
        From
          ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD Placement
          Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Period
            On    Placement.DATE_SAISIE >= Period.PERIODE_DATE_DEB
              And Placement.DATE_SAISIE <= Period.PERIODE_DATE_FIN
              And Period.FRESH_IN       = 1
              And Period.CURRENT_IN     = 1
              And Period.CLOSURE_DT     Is null
        Where (1=1)
          And Placement.TYPE_LIG_CDE    = 'RCS' -- selection des RCS
          And Placement.CLOSURE_DT      Is null
          And Placement.DATE_SAISIE     >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')      
          And Placement.DATE_SAISIE     >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
          And Placement.DATE_SAISIE     >= (Current_date - ${P_PIL_542})
      )TmpCalc
  -- Jointure avec le catalogue regroupant tous les RCS / Refcom de toutes les sources concernees par les RCS
      Left Outer Join ${KNB_PCO_TMP}.CAT_W_RCS_REFCOM_JOUR RCS_Refcom
           On    TmpCalc.EXT_PRODUCT_ID            = RCS_Refcom.EXT_PRODUCT_ID_1
             And TmpCalc.PERIODE_ID                = RCS_Refcom.PERIODE_ID
             --And RCS_Refcom.FRESH_IN               = 1
             --And RCS_Refcom.CURRENT_IN             = 1
             --And RCS_Refcom.CLOSURE_DT             Is null
  )CalculTypeVAD
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD;
.if errorcode <> 0 then .quit 1

.quit 0

