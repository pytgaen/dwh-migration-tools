-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    AVM_GEN_AlimCold_ORD_T_ACTE_UNIFIED_ROrga_Step1_Extraction.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 02/05/2014      HZO          Creation
-- 11/02/2015      HZO          Modification : Ajout des sources EDEL,Déclaratif PVC et ERC dans les actes Eligibles (4,13,14)
-- 09/04/2015      HZO          Modification : Ajout des actes Soft rapprochés de VAD (Rule_id = 10) dans les actes Eligibles
-- 01/06/2015      HZO          Modification : Ajout de la source ERDV dans les actes Eligibles (8)
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG
(
  ACTE_ID     ,
  AGENT_ID    ,
  ACT_TS      
)
Select
  Act.ACTE_ID             as ACTE_ID      ,
  Act.AGENT_ID_UPD        as AGENT_ID     ,
  Act.ACT_TS              as ACT_TS       
From
  ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${Source} As Act
Where
  (1=1)
  --On selectionne le Acte maitre n'ayant pas été rapprocher sur les sources de commandes
  -- VAD / SOFT / PCM 
  -- Pour recadrer les données d'organisation sur les CUID
  And ACT.MASTER_FLAG               = 1
  And (ACT.CPLT_ACTE_ID             Is Null 
    Or ACT.RULE_ID                  in (10,5,4))
  And ACT.INTRNL_SOURCE_ID          In (1,4,5,6,13,14)
  And ACT.ACT_END_UNIFIED_DT        Is Null
  And ACT.ACT_CLOSURE_DT            Is Null
  And ACT.AGENT_ID_UPD              Is Not Null
  And ACT.AGENT_ID_UPD              Not In ('CLIENTIP','CLIENTEB')
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_UNIFIED_ELIG;
.if errorcode <> 0 then .quit 1

.quit 0

