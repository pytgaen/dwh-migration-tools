-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_EnrichissementPlacementScore_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2011     CDR         Création
-- 06/02/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_SCORE All;
.if errorcode <> 0 then .quit 1

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_TFINDICOM
-- **************************************************************

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_SCORE
(
  ACTE_ID                   ,
  PAR_SCORE_NU              ,
  PAR_SCORE_IN              ,
  PAR_TRESHOLD_NU           
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  SegCom.SCORE_NU                   as PAR_SCORE_NU         ,
  SegCom.SCORE_IN                   as PAR_SCORE_IN         ,
  SegCom.TRESHOLD_NU                as PAR_TRESHOLD_NU      
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_COM_SOC_V_PRS}.VF_SGM_H_SEGMENT_IPS SegCom
    On    Inter.CLIENT_NU       =   SegCom.RBTBILLSYSACCTID
      And Inter.DOSSIER_NU      =   SegCom.MSISDN_ID
      And Inter.DATE_SAISIE     >=  SegCom.VALIDITY_START_TS
      And Inter.DATE_SAISIE     <=  SegCom.VALIDITY_END_TS
Where
  (1=1)
  And (Inter.PAR_SCORE_NU Is null Or Inter.PAR_SCORE_IN Is null Or Inter.PAR_TRESHOLD_NU Is null)
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by SegCom.VALIDITY_START_TS asc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_SCORE;
.if errorcode <> 0 then .quit 1

.quit 0

