 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ActeNonPerennitePVCSeg.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications de la perennité PVC
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000







Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_VENTE_SEG_CONCLU(
  ACT_SEG_COM_ID_FINAL        Varchar(64)         Not Null  ,
  NB_VENTE_OK                 Integer                       ,
  NB_VENTE                    Integer                       ,
  PER_VENTE_OK                Decimal(5,2)                  
)
Primary Index (
  ACT_SEG_COM_ID_FINAL
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1






Insert Into ${KNB_TERADATA_USER}.ORD_V_VENTE_SEG_CONCLU
(
  ACT_SEG_COM_ID_FINAL        ,
  NB_VENTE_OK                 ,
  NB_VENTE                    ,
  PER_VENTE_OK                
)
Select
  RefId.ACT_SEG_COM_ID_FINAL                                                                            As ACT_SEG_COM_ID_FINAL     ,
  Sum(Case When RefId.ACT_FLAG_PVC_REM='O' then 1 else 0 end)                                           As NB_VENTE_OK              ,
  Count(*)                                                                                              As NB_VENTE                 ,
  Cast(Cast(NB_VENTE_OK As decimal(15,2))*100/NB_VENTE as Decimal(5,2))                                 As PER_VENTE_OK             
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED RefId
Where
  (1=1)
  And RefId.MASTER_FLAG                   = 1
  And RefId.ACT_FLAG_ACT_REM              = 'O'
  And RefId.HOT_IN                        = 0
  And RefId.ACT_DT                        >= Current_date -30
  And RefId.AGENT_ID_UPD                  Is Not Null
  And RefId.ORG_REM_CHANNEL_CD            In ('SCH','CCO','AD','SCO')
  And RefId.ACT_CLOSURE_DT                Is Null
  And RefId.ACT_END_UNIFIED_DT            Is Null
  And (RefId.ORG_TYPE_EDO        = 'INT' Or  RefId.ORG_TYPE_EDO  is Null )
Group by
  ACT_SEG_COM_ID_FINAL
;
.if errorcode <> 0 Then .quit 1

Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_VENTE_SEG_CONCLU_ERR(
  ACT_SEG_COM_ID_FINAL        Varchar(64)         Not Null  ,
  LIB1                        Varchar(100)                  ,
  NB1                         Integer                       ,
  LIB2                        Varchar(100)                  ,
  NB2                         Integer                       ,
  LIB3                        Varchar(100)                  ,
  NB3                         Integer                       ,
  LIB4                        Varchar(100)                  ,
  NB4                         Integer                       ,
  LIB5                        Varchar(100)                  ,
  NB5                         Integer                       ,
  LIB6                        Varchar(100)                  ,
  NB6                         Integer                       ,
  LIB7                        Varchar(100)                  ,
  NB7                         Integer                       
)
Primary Index (
  ACT_SEG_COM_ID_FINAL
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_VENTE_SEG_CONCLU_ERR
(
  ACT_SEG_COM_ID_FINAL        ,
  LIB1                        ,
  NB1                         ,
  LIB2                        ,
  NB2                         ,
  LIB3                        ,
  NB3                         ,
  LIB4                        ,
  NB4                         ,
  LIB5                        ,
  NB5                         ,
  LIB6                        ,
  NB6                         ,
  LIB7                        ,
  NB7                         
)
Select
  RefId.ACT_SEG_COM_ID_FINAL                                                                                                                      as ACT_SEG_COM_ID_FINAL   ,
  Max(Case  When RefId.PRES_SEGMENT_IN_PARK_BEFORE_IN  = 1 Then  Cast('Presence En Parc' as varchar(100)) End)                                    as Lib1                   ,
  Sum(Case  When RefId.PRES_SEGMENT_IN_PARK_BEFORE_IN  = 1 Then 1 End)                                                                            as NB1                    ,
  Max(Case  When RefId.PRES_SEGMENT_IN_PARK_BEFORE_IN  <> 1 And RefId.COMPTTN_ID  Is Not Null Then Cast('Concurrence Acte' as varchar(100)) End)  as Lib2                   ,
  Sum(Case  When RefId.PRES_SEGMENT_IN_PARK_BEFORE_IN  <> 1 And RefId.COMPTTN_ID  Is Not Null Then 1 End)                                         as NB2                    ,
  Max(Case  When RefId.ORDER_CANCELING_DT Is Not Null And TYPE_SOURCE_ID ='MOB' Then Cast('Annulation Ordres Agendés ADV' as varchar(100)) End)   as Lib3                   ,
  Sum(Case  When RefId.ORDER_CANCELING_DT Is Not Null And TYPE_SOURCE_ID ='MOB' Then 1 End)                                                       as NB3                    ,
  Max(Case  When RefId.ORDER_CANCELING_DT Is Not Null And TYPE_SOURCE_ID ='INT' Then Cast('Annulation Parsifal' as varchar(100)) End)             as Lib4                   ,
  Sum(Case  When RefId.ORDER_CANCELING_DT Is Not Null And TYPE_SOURCE_ID ='INT' Then 1 End)                                                       as NB4                    ,
  Max(Case  When RefId.ORDER_CANCELING_DT Is Not Null And TYPE_SOURCE_ID ='PCM' Then Cast('Annulation du PCM' as varchar(100)) End)               as Lib5                   ,
  Sum(Case  When RefId.ORDER_CANCELING_DT Is Not Null And TYPE_SOURCE_ID ='PCM' Then 1 End)                                                       as NB5                    ,
  Max(Case  When RefId.CHECK_NAT_STATUS_CD In (2) Then Cast('Invalidation CSO Nationnal' as varchar(100)) End)                                    as Lib6                   ,
  Sum(Case  When RefId.CHECK_NAT_STATUS_CD In (2) Then 1 End)                                                                                     as NB6                    ,
  Max(Case  When RefId.CHECK_LOC_STATUS_CD In (2) Then Cast('Invalidation CSO Nationnal motif' as varchar(100)) End)                              as Lib7                   ,
  Sum(Case  When RefId.CHECK_LOC_STATUS_CD In (2) Then 1 End)                                                                                     as NB7                    
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED RefId
Where
  (1=1)
  And RefId.MASTER_FLAG                   = 1
  And RefId.ACT_FLAG_ACT_REM              ='O'
  And RefId.HOT_IN                        = 0
  And RefId.ACT_DT                        >= Current_date -30
  And RefId.AGENT_ID_UPD                  Is Not Null
  And RefId.ORG_REM_CHANNEL_CD            In ('SCH','CCO','AD','SCO')
  And RefId.ACT_CLOSURE_DT                Is Null
  And RefId.ACT_END_UNIFIED_DT            Is Null
  And (RefId.ORG_TYPE_EDO        = 'INT' Or  RefId.ORG_TYPE_EDO  is Null )
  And RefId.ACT_FLAG_PVC_REM              ='N'
Group by
  ACT_SEG_COM_ID_FINAL
;
.if errorcode <> 0 Then .quit 1




Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  7                                                             As REJECT_TYPE_ID         ,
  'ALL'                                                         As SOURCE_ID              ,
  Case  When SegCon.PER_VENTE_OK <= 80 Then 'ERR' Else Null End As CATALOG_ID             ,
  'Ventes sur le Segment : '||SegCon.ACT_SEG_COM_ID_FINAL||' '
                            ||Trim(Cast(SegCon.PER_VENTE_OK As Decimal Format '---9.99'))||'%  - de ventes conclues ('
                            ||Trim(SegCon.NB_VENTE_OK)||'/'||Trim(SegCon.NB_VENTE)||')'     As ERROR_CD               ,
  Case  When SegCon.PER_VENTE_OK <> 100
          Then
            'Causes Non Conclue : '
                                    ||Case  When SegErr.LIB1 Is Not Null Then ' - '||SegErr.LIB1 Else '' End
                                    ||Case  When SegErr.LIB1 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB1 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB2 Is Not Null Then ' - '||SegErr.LIB2 Else '' End
                                    ||Case  When SegErr.LIB2 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB2 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB3 Is Not Null Then ' - '||SegErr.LIB3 Else '' End
                                    ||Case  When SegErr.LIB3 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB3 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB4 Is Not Null Then ' - '||SegErr.LIB4 Else '' End
                                    ||Case  When SegErr.LIB4 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB4 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB5 Is Not Null Then ' - '||SegErr.LIB5 Else '' End
                                    ||Case  When SegErr.LIB5 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB5 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB6 Is Not Null Then ' - '||SegErr.LIB6 Else '' End
                                    ||Case  When SegErr.LIB6 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB6 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
                                    ||Case  When SegErr.LIB7 Is Not Null Then ' - '||SegErr.LIB7 Else '' End
                                    ||Case  When SegErr.LIB7 Is Not Null Then ' : '||Trim(Cast(Cast(SegErr.NB7 as Decimal(15,2))*100/SegCon.NB_VENTE as Decimal(5,2) Format '---9.99'))||'% ' Else '' End
  End                                                           As INFO_CD                ,
  SegCon.NB_VENTE                                               As VolumeCas              ,
  Null                                                          As DateMinRecue           ,
  Null                                                          As DateMaxRecue           
From
  ${KNB_TERADATA_USER}.ORD_V_VENTE_SEG_CONCLU SegCon
  Left Outer Join ${KNB_TERADATA_USER}.ORD_V_VENTE_SEG_CONCLU_ERR SegErr
    On  SegCon.ACT_SEG_COM_ID_FINAL     = SegErr.ACT_SEG_COM_ID_FINAL
;
.if errorcode <> 0 Then .quit 1





-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
