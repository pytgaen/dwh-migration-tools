-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:ATP_PCO_EnrichissementPlacementClient_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2011     CDR         Création
-- 06/02/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT_VAD All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_BAL All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ADR All
;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- Alimentation des Attributs clients Nom Prenom
-- On requete dans TDDOSSIER uniquement pour les clients Prépaid
------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT_VAD
(
  ACTE_ID                   ,
  PAR_LASTNAME              ,
  PAR_FIRSTNAME             
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Récupération du Nom
  Vad.CDE_NOM                       as PAR_LASTNAME         ,
  --Récupération du Nom
  Vad.CDE_PRENOM                    as PAR_FIRSTNAME        
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_ORD_F_ORDER_VAD Vad
    On    Inter.CDE_REFERENCE       =   Vad.CDE_REFERENCE
Where
  (1=1)
  And ( Inter.PAR_LASTNAME Is Null )
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Vad.CREATION_TS Desc)=1


------------------------------------------------------------------
-- Alimentation des Attributs clients Nom Prenom
-- On requete dans TDCLIENT uniquement pour les clients PostPaid
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT
(
  ACTE_ID                   ,
  PAR_LASTNAME              ,
  PAR_FIRSTNAME             ,
  PAR_TYPE                  
)
Select
  Inter.ACTE_ID                          as ACTE_ID              ,
  -- Dans le cas des clients Pro on met tous dans le Nom :
  Client.CLIENT_LL_NOM                   as PAR_LASTNAME         ,
  -- Dans le cas des clients Post Paid on ne peut pas séparer le nom
  -- du prénom
  Null                                   as PAR_FIRSTNAME        ,
  Client.CLIENT_CO_TYPCLI                as PAR_TYPE             
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_TDCLIENT Client
    On    Inter.CLIENT_NU =   Client.CLIENT_NU
Where
  (1=1)
  And ( Inter.PAR_TYPE Is Null)
  --On ne fait n'exclu pas les prépaid pour récupérer leur le code Type Client
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Client.CREATION_TS Desc)=1


------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Mail
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_BAL
(
  ACTE_ID                   ,
  PAR_EMAIL                 
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  --Récupération de l'adresse mail
  Vad.EMAIL                         as PAR_EMAIL            
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_ORD_F_ORDER_VAD Vad
    On    Inter.CDE_REFERENCE       =   Vad.CDE_REFERENCE
Where
  (1=1)
  And ( Inter.PAR_EMAIL Is Null )
  And ( Vad.EMAIL Is Not Null )
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Vad.CREATION_TS Desc)=1

------------------------------------------------------------------
-- Alimentation des Attributs clients Adresse Postale
------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ADR
(
  ACTE_ID                   ,
  PAR_BILL_ADRESS_1         ,
  PAR_BILL_ADRESS_2         ,
  PAR_BILL_ADRESS_3         ,
  PAR_BILL_ADRESS_4         ,
  PAR_BILL_VILLE            ,
  PAR_BILL_CD_POSTAL        ,
  PAR_DO                    
)
Select
  Inter.ACTE_ID                                       as ACTE_ID              ,
  --Récupération de l'adresse du client
  Vad.CDE_VOIE                                        as PAR_BILL_ADRESS_1    ,
  Vad.CDE_BAT                                         as PAR_BILL_ADRESS_2    ,
  Vad.CDE_COMP                                        as PAR_BILL_ADRESS_3    ,
  Vad.CDE_LD                                          as PAR_BILL_ADRESS_4    ,
  Vad.CDE_VILLE                                       as PAR_BILL_VILLE       ,
  --Calcul du code Postale => 5 Premier caractère du code (Car le champ : Code Postal + INSEE)
  Substring(Trim(Vad.CDE_CP) From 1 For 5) as PAR_BILL_CD_POSTAL ,
  --Calcul De la DO : En fonction du département Pour la métropole 2 1er caractère
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Vad.CDE_CP) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988','998','999')
          Then  Substring(Trim(Vad.CDE_CP) From 1 For 3)
        When    Vad.CDE_CP Is Not Null
          Then  Substring(Trim(Vad.CDE_CP) From 1 For 2)
        Else    '999'
  End                                                 as PAR_DO             
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_ORD_F_ORDER_VAD Vad
    On    Inter.CDE_REFERENCE       =   Vad.CDE_REFERENCE
Where
  (1=1)
  And ( Inter.PAR_BILL_CD_POSTAL Is Null )
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Vad.CREATION_TS Desc)=1
;

.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT_VAD;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_BAL;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ADR;
.if errorcode <> 0 then .quit 1

.quit 0

