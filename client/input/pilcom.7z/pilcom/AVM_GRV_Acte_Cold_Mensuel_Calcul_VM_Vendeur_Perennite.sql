-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_GRV_Acte_Cold_Mensuel_Calcul_VM_Vendeur_Perennite.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 26/11/2014      HFO         Mise en normes
-- 22/01/2016      HFO         MODIFICATION nouveaux calcul de pérennité
-- 14/04/2016      HLA         MODIFICATION nouveaux calcul de pérennité
--------------------------------------------------------------------------------

.set width 2500;


--------------------------------------------------------------------------------
-- Setp 1 : On fait le delete des Lignes du mois Pour les KPI
--------------------------------------------------------------------------------
--TODO A Sup à l'indus
Delete From ${KNB_PCO_VM}.ORD_F_SELLER_SUSTNBL_RATE_VM_M Where FRESH_IN = 0;
.if ErrorCode <> 0 Then .Quit 1;


Update ${KNB_PCO_VM}.ORD_F_SELLER_SUSTNBL_RATE_VM_M
Set
  FRESH_IN      = 0 ,
  COHERENCE_IN  = 1
Where
  (1=1)
  And MONTH_CALC = '${KNB_PILCOM_EXTRACT_MOIS}'
;
.if ErrorCode <> 0 Then .Quit 1;


--------------------------------------------------------------------------------
-- Setp 2 : Mise à jour du Socle
--------------------------------------------------------------------------------


Insert into ${KNB_PCO_VM}.ORD_F_SELLER_SUSTNBL_RATE_VM_M
(
  ORG_AGENT_ID                  ,
  MONTH_CALC                    ,
  MONTH_APPLICATION             ,
  PERIODE_ID_REFCOM_APPLICATION ,
  MONTH_REF_CALCUL              ,
  AMOUNT_SALE                   ,
  AMOUNT_SALE_PER               ,
  NUMBER_VALUATION              ,
  NUMBER_VALUATION_PER          ,
  RATE_SALE_PER                 ,
  RATE_VALUATION_PER            ,
  FLAG_MISSED_MONTH             ,
  RATE_SALE_PER_EDITED          ,
  RATE_VALUATION_PER_EDITED     ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  ORG_AGENT_ID                                                                              as ORG_AGENT_ID                     ,
  MONTH_CALC                                                                                as MONTH_CALC                       ,
  MONTH_APPLICATION                                                                         as MONTH_APPLICATION                ,
  PERIODE_ID_REFCOM_APPLICATION                                                             as PERIODE_ID_REFCOM_APPLICATION    ,
  MONTH_REF_CALCUL                                                                          as MONTH_REF_CALCUL                 ,
  --Calcul du taux par KPI
  AMOUNT_SALE                                                                               as AMOUNT_SALE                      ,
  AMOUNT_SALE_PER                                                                           as AMOUNT_SALE_PER                  ,
  --Calcul par la valo
  NUMBER_VALUATION                                                                          as NUMBER_VALUATION                 ,
  NUMBER_VALUATION_PER                                                                      as NUMBER_VALUATION_PER             ,
  --Calcul des Ratio
  RATE_SALE_PER                                                                             as RATE_SALE_PER                    ,
  RATE_VALUATION_PER                                                                        as RATE_VALUATION_PER               ,
  --Calcul des recadrage de données
  FLAG_MISSED_MONTH                                                                         as FLAG_MISSED_MONTH                ,
  RATE_SALE_PER_EDITED                                                                      as RATE_SALE_PER_EDITED             ,
  RATE_VALUATION_PER_EDITED                                                                 as RATE_VALUATION_PER_EDITED        ,
  Current_Timestamp(0)                                                                      as CREATION_TS                      ,
  Current_Timestamp(0)                                                                      as LAST_MODIF_TS                    ,
  1                                                                                         as FRESH_IN                         ,
  0                                                                                         as COHERENCE_IN                     
From
   ${KNB_PCO_TMP}.COM_T_VENDOR_KPI_VM_M
Where
  (1=1)
;
.if ErrorCode <> 0 Then .Quit 1;


--On collecte les stats sur la table 
Collect Stat On ${KNB_PCO_VM}.ORD_F_SELLER_SUSTNBL_RATE_VM_M;
.if ErrorCode <> 0 Then .Quit 1;


.quit 0


