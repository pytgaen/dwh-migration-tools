-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    AVM_GEN_AlimCold_ORD_T_ACTE_UNIFIED_ROrga_Step3_Edo_Hier.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 02/05/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_HIER_O3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_HIER_O3
(
  ACTE_ID                     ,
  AGENT_ID                    ,
  UNIFIED_SHOP_CD             ,
  ORG_TEAM_LEVEL_1_CD         ,
  ORG_TEAM_LEVEL_1_DS         ,
  ORG_TEAM_LEVEL_2_CD         ,
  ORG_TEAM_LEVEL_2_DS         ,
  ORG_TEAM_LEVEL_3_CD         ,
  ORG_TEAM_LEVEL_3_DS         ,
  ORG_TEAM_LEVEL_4_CD         ,
  ORG_TEAM_LEVEL_4_DS         
)
Select
  ACTEDO.ACTE_ID                            As ACTE_ID                    ,
  ACTEDO.AGENT_ID                           As AGENT_ID                   ,
  RefPDV.EXTNL_VAL_COD_CD                   As UNIFIED_SHOP_CD            ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As ORG_TEAM_LEVEL_1_CD        ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As ORG_TEAM_LEVEL_1_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As ORG_TEAM_LEVEL_2_CD        ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As ORG_TEAM_LEVEL_2_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As ORG_TEAM_LEVEL_3_CD        ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As ORG_TEAM_LEVEL_3_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As ORG_TEAM_LEVEL_4_CD        ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As ORG_TEAM_LEVEL_4_DS        
From
  ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_HIER ACTEDO
  --On jointe dans l'orga Hierarchique
  Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL WLvl1
    On    ACTEDO.EDO_ID_EQUI_RAT        =   WLvl1.ORG_TEAM_LEVEL_1_CD
      And ACTEDO.ACT_TS                 >=  WLvl1.ORG_TEAM_LEVEL_1_START_DT
      And ACTEDO.ACT_TS                 <=  WLvl1.ORG_TEAM_LEVEL_1_END_DT
      And ACTEDO.ACT_TS                 >=  WLvl1.ORG_TEAM_LEVEL_2_START_DT
      And ACTEDO.ACT_TS                 <=  WLvl1.ORG_TEAM_LEVEL_2_END_DT
      And ACTEDO.ACT_TS                 >=  WLvl1.ORG_TEAM_LEVEL_3_START_DT
      And ACTEDO.ACT_TS                 <=  WLvl1.ORG_TEAM_LEVEL_3_END_DT
      And ACTEDO.ACT_TS                 >=  WLvl1.ORG_TEAM_LEVEL_4_START_DT
      And ACTEDO.ACT_TS                 <=  WLvl1.ORG_TEAM_LEVEL_4_END_DT
  Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPDV
    On ACTEDO.EDO_ID_EQUI_RAT           =   RefPDV.EDO_ID
      And RefPDV.CURRENT_IN             =   1
      And RefPDV.CLOSURE_DT             Is Null
      And RefPDV.EXTNL_COD_CD           =   'ADV'
Where
  (1=1)
Qualify Row_Number() Over (Partition By ACTEDO.ACTE_ID Order By           WLvl1.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_ACT_UNI_EDO_HIER_O3;
.if errorcode <> 0 then .quit 1

.quit 0

