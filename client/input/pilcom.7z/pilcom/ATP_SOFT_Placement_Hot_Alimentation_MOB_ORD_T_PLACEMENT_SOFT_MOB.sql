-- $HEADER: mm2pco/current/sql/ATP_SOFT_Placement_Hot_Alimentation_MOB_ORD_T_PLACEMENT_SOFT_MOB.sql 13_05#3 29-NOV-2017 18:04:58 CLHH1829
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Hot_Alimentation_INT_ORD_T_PLACEMENT_SOFT_MOB.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de génération des placement SOFT Mobile à partir de l'id Externe => Acte ID
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 15/01/2014      AID         Modif de KNB_COM_TMP parKNB_PCO_TMP
-- 26/03/2015      MDE         Modif : Ajout enrichissement du CC/Ve  QC446
-- 27/11/2017      MEL         Ajout indicateur IOBSP
--------------------------------------------------------------------------------

.set width 2500;





Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_MOB
Where
  TYPE_PRODUCT='${TypeLigne}'
;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------------------------------------------
-- Cas 1 : Si c'est une opération CREAT,MODIF,MIGRA,RESIL On alimente directement
--         Et dans le cas des déménagement avec changement d'OC : on est sur que ce n'est pas une aquisition
---------------------------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_MOB
(
  ACTE_ID                       ,
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  INTRNL_SOURCE_ID              ,
  TYPE_PRODUCT                  ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_DEPOSIT_DT              ,
  VAD_ORDER_ID                  ,
  ORDER_DEPOSIT_TS              ,
  ORDER_VALIDATION_TS           ,
  ORDER_DELIVERY_TS             ,
  AGENT_ID                      ,
  ORG_NOM                       ,
  ORG_PRENOM                    ,
  DISTRBTN_CHANNL_ID            ,
  STORE_NAME                    ,
  EDO_ID                        ,
  FLAG_PLT_CONV                 ,
  FLAG_TEAM_MKT                 ,
  FLAG_TYPE_CMP                 ,
  TYPE_EDO                      ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  ORG_AGENT_IOBSP               ,
  ORG_EDO_IOBSP                 ,
  NETWRK_TYP_EDO_ID             ,
  FLAG_TYPE_GEO                 ,
  FLAG_TYPE_CPT_NTK             ,
  FLAG_TYPE_PTN_NTK             ,
  MOTV_ORDR_ID                  ,
  ORDER_TYPE_CD                 ,
  ORDER_TYPE_ID                 ,
  CANCEL_MOTV_DS                ,
  ACTE_OPERTR_ID_OT             ,
  CUSTOMER_CIVILITY             ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_MARKET_SEG           ,
  CUSTOMER_SIRET                ,
  CUSTOMER_BSS_ID               ,
  CUSTOMER_FGT_ID               ,
  CUSTOMER_ND                   ,
  CUSTOMER_CPT_FAC_FGT          ,
  CUSTOMER_CLIENT_NU_ADV        ,
  CUSTOMER_DOSSIER_NU_ADV       ,
  CUSTOMER_BO_ID                ,
  CUSTOMER_ND_AR                ,
  INSTALL_ADDRESS_STREET        ,
  INSTALL_ADDRESS_ZIPCODE       ,
  INSTALL_ADDRESS_CITY          ,
  INSTALL_ADDRESS_COUNTRY       ,
  INSTALL_REGIONAL_DIRCTN_ID    ,
  CONTACT_CIVILITY              ,
  CONTACT_LAST_NAME             ,
  CONTACT_FIRST_NAME            ,
  CONTACT_MOBILE_NUMBER         ,
  CONTACT_MAIL_ADDRESS          ,
  CONTACT_ADDRESS_STREET        ,
  CONTACT_ADDRESS_ZIPCODE       ,
  CONTACT_ADDRESS_CITY          ,
  CONTACT_ADDRESS_COUNTRY       ,
  SHIPMENT_ADDRESS_RELAY_ID     ,
  SHIPMENT_ADDRESS_STREET       ,
  SHIPMENT_ADDRESS_ZIPCODE      ,
  SHIPMENT_ADDRESS_CITY         ,
  SHIPMENT_ADDRESS_COUNTRY      ,
  BO_AGENT_ID                   ,
  ORDER_LINE_EXTERNAL_ID        ,
  EXT_OPER_ID                   ,
  PRESFACT_CO_OFFRE_OPT         ,
  PRESFACT_CO_OFFRE_OPT_DS      ,
  OSCAR_VALUE_NU                ,
  ORDER_COMPLETED               ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT ,
  QUEUE_TS                      ,
  RUN_ID                        ,
  STREAMING_TS                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  HOT_IN                        ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  ACTE_ID                                                                                                       as ACTE_ID                        ,
  Commande.EXTERNAL_ORDER_ID                                                                                    as EXTERNAL_ORDER_ID              ,
  Commande.ORDER_STATUS_CD                                                                                      as ORDER_STATUS_CD                ,
  Commande.STATUS_MODIF_TS                                                                                      as STATUS_MODIF_TS                ,
  Commande.INTRNL_SOURCE_ID                                                                                     as INTRNL_SOURCE_ID               ,
  Commande.TYPE_PRODUCT                                                                                         as TYPE_PRODUCT                   ,
  Commande.OPERATOR_PROVIDER_ID                                                                                 as OPERATOR_PROVIDER_ID           ,
  Commande.ORDER_DEPOSIT_DT                                                                                     as ORDER_DEPOSIT_DT               ,
  Commande.VAD_ORDER_ID                                                                                         as VAD_ORDER_ID                   ,
  Commande.ORDER_DEPOSIT_TS                                                                                     as ORDER_DEPOSIT_TS               ,
  Commande.ORDER_VALIDATION_TS                                                                                  as ORDER_VALIDATION_TS            ,
  Commande.ORDER_DELIVERY_TS                                                                                    as ORDER_DELIVERY_TS              ,
  Commande.AGENT_ID                                                                                             as AGENT_ID                       ,
  RefConseiller.ORG_NOM                                                                                         as ORG_NOM                        ,
  RefConseiller.ORG_PRENOM                                                                                      as ORG_PRENOM                     ,
  Commande.DISTRBTN_CHANNL_ID                                                                                   as DISTRBTN_CHANNL_ID             ,
  Commande.STORE_NAME                                                                                           as STORE_NAME                     ,
  RefO3.EDO_ID                                                                                                  as EDO_ID                         ,
  RefO3.FLAG_PLT_CONV                                                                                           as FLAG_PLT_CONV                  ,
  RefO3.FLAG_TEAM_MKT                                                                                           as FLAG_TEAM_MKT                  ,
  RefO3.FLAG_TYPE_CMP                                                                                           as FLAG_TYPE_CMP                  ,
  RefO3.TYPE_EDO                                                                                                as TYPE_EDO                       ,
  Null                                                                                                          as PAR_CID_ID                     ,
  Null                                                                                                          as PAR_PID_ID                     ,
  Null                                                                                                          as PAR_FIRST_IN                   ,
  Null                                                                                                          as ORG_AGENT_IOBSP                ,
  Null                                                                                                          as ORG_EDO_IOBSP                  ,
  RefO3.NETWRK_TYP_EDO_ID                                                                                       as NETWRK_TYP_EDO_ID              ,
  RefO3.FLAG_TYPE_GEO                                                                                           as FLAG_TYPE_GEO                  ,
  RefO3.FLAG_TYPE_CPT_NTK                                                                                       as FLAG_TYPE_CPT_NTK              ,
  RefO3.FLAG_TYPE_PTN_NTK                                                                                       as FLAG_TYPE_PTN_NTK              ,
  Commande.MOTV_ORDR_ID                                                                                         as MOTV_ORDR_ID                   ,
  Commande.ORDER_TYPE_CD                                                                                        as ORDER_TYPE_CD                  ,
  Commande.ORDER_TYPE_ID                                                                                        as ORDER_TYPE_ID                  ,
  Commande.CANCEL_MOTV_DS                                                                                       as CANCEL_MOTV_DS                 ,
  Commande.ACTE_OPERTR_ID_OT                                                                                    as ACTE_OPERTR_ID_OT              ,
  Commande.CUSTOMER_CIVILITY                                                                                    as CUSTOMER_CIVILITY              ,
  Commande.CUSTOMER_LAST_NAME                                                                                   as CUSTOMER_LAST_NAME             ,
  Commande.CUSTOMER_FIRST_NAME                                                                                  as CUSTOMER_FIRST_NAME            ,
  Commande.CUSTOMER_MARKET_SEG                                                                                  as CUSTOMER_MARKET_SEG            ,
  Commande.CUSTOMER_SIRET                                                                                       as CUSTOMER_SIRET                 ,
  Commande.CUSTOMER_BSS_ID                                                                                      as CUSTOMER_BSS_ID                ,
  Commande.CUSTOMER_FGT_ID                                                                                      as CUSTOMER_FGT_ID                ,
  Commande.CUSTOMER_ND                                                                                          as CUSTOMER_ND                    ,
  Commande.CUSTOMER_CPT_FAC_FGT                                                                                 as CUSTOMER_CPT_FAC_FGT           ,
  Commande.CUSTOMER_CLIENT_NU_ADV                                                                               as CUSTOMER_CLIENT_NU_ADV         ,
  Commande.CUSTOMER_DOSSIER_NU_ADV                                                                              as CUSTOMER_DOSSIER_NU_ADV        ,
  Commande.CUSTOMER_BO_ID                                                                                       as CUSTOMER_BO_ID                 ,
  Commande.CUSTOMER_ND_AR                                                                                       as CUSTOMER_ND_AR                 ,
  Commande.INSTALL_ADDRESS_STREET                                                                               as INSTALL_ADDRESS_STREET         ,
  Commande.INSTALL_ADDRESS_ZIPCODE                                                                              as INSTALL_ADDRESS_ZIPCODE        ,
  Commande.INSTALL_ADDRESS_CITY                                                                                 as INSTALL_ADDRESS_CITY           ,
  Commande.INSTALL_ADDRESS_COUNTRY                                                                              as INSTALL_ADDRESS_COUNTRY        ,
  Commande.INSTALL_REGIONAL_DIRCTN_ID                                                                           as INSTALL_REGIONAL_DIRCTN_ID     ,
  Commande.CONTACT_CIVILITY                                                                                     as CONTACT_CIVILITY               ,
  Commande.CONTACT_LAST_NAME                                                                                    as CONTACT_LAST_NAME              ,
  Commande.CONTACT_FIRST_NAME                                                                                   as CONTACT_FIRST_NAME             ,
  Commande.CONTACT_MOBILE_NUMBER                                                                                as CONTACT_MOBILE_NUMBER          ,
  Commande.CONTACT_MAIL_ADDRESS                                                                                 as CONTACT_MAIL_ADDRESS           ,
  Commande.CONTACT_ADDRESS_STREET                                                                               as CONTACT_ADDRESS_STREET         ,
  Commande.CONTACT_ADDRESS_ZIPCODE                                                                              as CONTACT_ADDRESS_ZIPCODE        ,
  Commande.CONTACT_ADDRESS_CITY                                                                                 as CONTACT_ADDRESS_CITY           ,
  Commande.CONTACT_ADDRESS_COUNTRY                                                                              as CONTACT_ADDRESS_COUNTRY        ,
  Commande.SHIPMENT_ADDRESS_RELAY_ID                                                                            as SHIPMENT_ADDRESS_RELAY_ID      ,
  Commande.SHIPMENT_ADDRESS_STREET                                                                              as SHIPMENT_ADDRESS_STREET        ,
  Commande.SHIPMENT_ADDRESS_ZIPCODE                                                                             as SHIPMENT_ADDRESS_ZIPCODE       ,
  Commande.SHIPMENT_ADDRESS_CITY                                                                                as SHIPMENT_ADDRESS_CITY          ,
  Commande.SHIPMENT_ADDRESS_COUNTRY                                                                             as SHIPMENT_ADDRESS_COUNTRY       ,
  Commande.BO_AGENT_ID                                                                                          as BO_AGENT_ID                    ,
  Commande.ORDER_LINE_EXTERNAL_ID                                                                               as ORDER_LINE_EXTERNAL_ID         ,
  Commande.EXT_OPER_ID                                                                                          as EXT_OPER_ID                    ,
  Commande.PRESFACT_CO_OFFRE_OPT                                                                                as PRESFACT_CO_OFFRE_OPT          ,
  Commande.PRESFACT_CO_OFFRE_OPT_DS                                                                             as PRESFACT_CO_OFFRE_OPT_DS       ,
  Commande.OSCAR_VALUE_NU                                                                                       as OSCAR_VALUE_NU                 ,
  Commande.ORDER_COMPLETED                                                                                      as ORDER_COMPLETED                ,
  Commande.FLAG_FIRST_RECEPTION_COM                                                                             as FLAG_FIRST_RECEPTION_COM       ,
  Commande.FLAG_FIRST_RECEPTION_COM_STAT                                                                        as FLAG_FIRST_RECEPTION_COM_STAT  ,
  Commande.QUEUE_TS                                                                                             as QUEUE_TS                       ,
  Commande.RUN_ID                                                                                               as RUN_ID                         ,
  Commande.STREAMING_TS                                                                                         as STREAMING_TS                   ,
  Commande.CREATION_TS                                                                                          as CREATION_TS                    ,
  Commande.LAST_MODIF_TS                                                                                        as LAST_MODIF_TS                  ,
  Commande.HOT_IN                                                                                               as HOT_IN                         ,
  Commande.FRESH_IN                                                                                             as FRESH_IN                       ,
  Commande.COHERENCE_IN                                                                                         as COHERENCE_IN                   
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_${TypeLigne} Commande
  Inner Join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN  GenID
    On    Commande.EXTERNAL_ACTE_ID   = GenID.EXTERNAL_ACTE_ID
      And Commande.TYPE_SOURCE_ID     = GenID.TYPE_SOURCE_ID
  Inner Join ${KNB_PCO_TMP}.ORD_W_ORDER_SOFT_ENRI_O3 RefO3
    On    Commande.EXTERNAL_ORDER_ID  = RefO3.EXTERNAL_ORDER_ID
      And Commande.ORDER_STATUS_CD    = RefO3.ORDER_STATUS_CD
      And Commande.ORDER_DEPOSIT_DT   = RefO3.ORDER_DEPOSIT_DT
      And Commande.STATUS_MODIF_TS    = RefO3.STATUS_MODIF_TS
   Inner Join ${KNB_PCO_TMP}.ORD_W_ORDER_SOFT_ENRI_CONSEIL RefConseiller
    On    Commande.EXTERNAL_ORDER_ID  = RefConseiller.EXTERNAL_ORDER_ID
      And Commande.ORDER_STATUS_CD    = RefConseiller.ORDER_STATUS_CD
      And Commande.ORDER_DEPOSIT_DT   = RefConseiller.ORDER_DEPOSIT_DT
      And Commande.STATUS_MODIF_TS    = RefConseiller.STATUS_MODIF_TS
Where
  (1=1)
  Qualify Row_Number() Over (Partition by ACTE_ID,Commande.EXTERNAL_ORDER_ID, Commande.ORDER_STATUS_CD,Commande.ORDER_DEPOSIT_DT,Commande.STATUS_MODIF_TS
   Order by Commande.ORDER_DEPOSIT_DT Desc )=1
;

.if errorcode <> 0 then .quit 1

--Collect stat on ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_MOB;
--.if errorcode <> 0 then .quit 1


