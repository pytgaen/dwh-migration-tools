--$HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GDT_Placement_Step1_Enrichissement_dmc.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissement dmc
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 31/07/2019      EVI         Creation
-- 21/01/2020      EVI         US-279 : Modification alimentation DEPARTMNT_ID
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                           ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_DMC All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_CLIADR All;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- Etape 2 : Alimentation des Attributs clients 
------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_DMC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  EXTERNAL_PARTY_ID         ,
  LINE_ID                   ,
  MSISDN_ID                 ,
  MASTER_LINE_ID            ,
  NDS_VALUE_DS              ,
  PAR_ACCES_SERVICE         ,
  RES_VALUE_DS              ,
  PAR_CID_ID                ,
  PAR_PID_ID                ,
  PAR_FIRST_IN              ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID     ,
  POSTAL_CD                 ,
  INSEE_CD                  ,
  BU_CD                     ,
  DEPARTMNT_ID              ,
  PAR_IRIS2000_CD           ,
  PAR_GEO_MACROZONE         
  
)
Select
  GDT.ACTE_ID                                        As ACTE_ID                ,
  GDT.ORDER_DEPOSIT_DT                               As ORDER_DEPOSIT_DT       ,
  Coalesce(Ldmc.EXTERNAL_PARTY_ID, '0000000000')     As EXTERNAL_PARTY_ID      ,
  LineDmc.LINE_ID                                    As LINE_ID                ,
  Coalesce(Ldmc.MOBILE_PHONE_NU, '0000000000')       As MSISDN_ID              ,
  LineDmc.LINE_ID                                    As MASTER_LINE_ID         ,
  Coalesce(Ldmc.NDS_VALUE_DS, '0000000000')          As NDS_VALUE_DS           ,
  Null                                               As PAR_ACCES_SERVICE      ,
  Null                                               As RES_VALUE_DS           ,
  Ldmc.CID_ID                                        As PAR_CID_ID             ,
  Ldmc.PID_ID                                        As PAR_PID_ID             ,
  Fi.FIRST_IN                                        As PAR_FIRST_IN           ,
  Ldmc.UNIFIED_PARTY_ID                              As PAR_UNIFIED_PARTY_ID   ,
  Ldmc.PARTY_REGRPMNT_ID                             AS PAR_PARTY_REGRPMNT_ID  ,
  Ldmc.POSTAL_CD                                     As POSTAL_CD              ,
  Ldmc.INSEE_NB                                      As INSEE_CD               ,
  Geo.BU_CD                                          As BU_CD                  ,
  Case 
    When LineDmc.LINE_ID Is Null
      Then substr(GDT.PAR_POSTAL_CD,1,2)
    Else Ldmc.DEPRTMNT_ID
  End                                                As DEPARTMNT_ID           ,
  Fiber.IRIS2000_CD                                  As PAR_IRIS2000_CD        ,
  Fiber.RESERV_4                                     As PAR_GEO_MACROZONE

From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_EXTR GDT
  Left Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_CLIENT ClientGDT
     On ClientGDT.ACTE_ID = GDT.ACTE_ID
    And ClientGDT.ORDER_DEPOSIT_DT = GDT.ORDER_DEPOSIT_DT
  -- Identifiant DMC
  Left Join ${KNB_DMU_DMC_VM_V}.PAR_F_LNK_AR LineDmc
     On ClientGDT.DOSSIER_NU = LineDmc.RES_VALUE_DS
    And ClientGDT.CLIENT_NU = LineDmc.ADV_CLIENT_NU
    And LineDmc.CLOSURE_DT  Is Null
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On LineDmc.LINE_ID = Ldmc.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_FIRST_VM Fi
    On LineDmc.LINE_ID = Fi.LINE_ID
  -- Code IRIS200
  Left Outer Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB Fiber
    On LineDmc.LINE_ID  = Fiber.LINE_ID

Where
  (1=1)
  And GDT.DMC_LINE_ID Is Null
;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- Etape 3 : Alimentation des Attributs clients Adresse
------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_CLIADR
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ADDRESS_CONCAT_NM         ,
  ADDRESS_TYPE              
  
)
Select
  GDT.ACTE_ID                                                                                                As ACTE_ID                ,
  GDT.ORDER_DEPOSIT_DT                                                                                       As ORDER_DEPOSIT_DT       ,
  --Récupération de l'adresse du client Depuis ADRCLI
  Trim(
   Trim(Coalesce(Case When Adr.ADRCLI_LB_ADR1 = 'null' Then Null Else Adr.ADRCLI_LB_ADR1 End,'')) || ' ' ||
   Trim(Coalesce(Case When Adr.ADRCLI_LB_ADR2 = 'null' Then Null Else Adr.ADRCLI_LB_ADR2 End,'')) || ' ' ||
   Trim(Coalesce(Case When Adr.ADRCLI_LB_ADR3 = 'null' Then Null Else Adr.ADRCLI_LB_ADR3 End,'')) || ' ' ||
   Trim(Coalesce(Case When Adr.ADRCLI_LB_ADR4 = 'null' Then Null Else Adr.ADRCLI_LB_ADR4 End,'')) || ' ' ||
   Trim(Coalesce(Substring(Trim(Adr.ADRCLI_CODPOST_CO) From 1 For 5),'')) || ' ' ||
   Trim(Coalesce(CodePost.CODPOST_LB_LOCAL,''))
  )                                                                                                          As ADDRESS_CONCAT_NM      ,
  '${P_PIL_372}'                                                                                             As ADDRESS_TYPE           

From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_EXTR GDT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_CLIENT ClientGDT
     On ClientGDT.ACTE_ID = GDT.ACTE_ID
    And ClientGDT.ORDER_DEPOSIT_DT = GDT.ORDER_DEPOSIT_DT
  -- Addresse
  Left Outer Join ${KNB_IBU_SOC}.V_THADRCLI Adr
    On    ClientGDT.CLIENT_NU               =   Adr.ADRCLI_CLIENT_NU
      And  ClientGDT.ORDER_DEPOSIT_DT      >=  Adr.ADRCLI_DT_DEB
      And  ClientGDT.ORDER_DEPOSIT_DT      <   Coalesce (Adr.ADRCLI_DT_FIN, Cast ('31/12/2999' As Date Format 'DD/MM/YYYY'))
  -- Code Postal
  Left Outer Join ${KNB_IBU_SOC}.V_TDCODPOST CodePost
    On    Adr.ADRCLI_CODPOST_CO                   =   CodePost.CODPOST_CO
      And CodePost.CURRENT_IN                     =   1
      And CodePost.CLOSURE_DT                     Is Null

Where
  (1=1)
  And GDT.DMC_LINE_ID Is Null
Qualify Row_Number() Over (Partition by GDT.ACTE_ID,GDT.ORDER_DEPOSIT_DT Order by Adr.ADRCLI_DT_DEB Asc)=1
;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- Etape 4 : Coolect Stats
------------------------------------------------------------------

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_DMC;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_GDT_C_CLIADR;
.if errorcode <> 0 then .quit 1

.quit 0





