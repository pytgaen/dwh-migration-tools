--$HEADER: %HEADERS%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PXF_Placement_Step2_BasculeIDActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'Extraction pour la creation des placements PXF
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/12/2020      EVI         Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_EXTR All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_EXTR
(
   ACTE_ID                ,
   EXTRNL_ORDER_ID        ,
   TYPE_SOURCE_ID         ,
   INTRNL_SOURCE_ID       ,
   ORDER_DEPOSIT_TS       ,
   ORDER_DEPOSIT_DT       ,
   LAST_UPDATE_TS         ,
   ORDER_CANCELING_DT     ,
   ORDER_CANCELING_TS     ,
   EXTRNL_STATUS_CD       ,
   STATUS_UNIFIED_CD      ,
   EXTRNL_EAN_CD          ,
   -- Axe Client
   EXTRNL_PHONE_NUMBER    ,
   EXTRNL_MOBILE_NUMBER   ,
   EXTRNL_POSTAL_CODE     ,
   EXTRNL_CUSTOMER_STATUS ,
   DEPARTMNT_ID           ,
   DMC_ACTIVATION_DT      ,
   DMC_LINE_ID            ,
   DMC_MASTER_LINE_ID     ,
   DMC_CUST_TYPE_CD       ,
   DMC_NDS_VALUE_DS       ,
   DMC_MSISDN_ID          ,
   DMC_EXTERNAL_PARTY_ID  ,
   DMC_RES_VALUE_DS       ,
   DMC_SERVICE_ACCESS_ID  ,
   DMC_LINE_TYPE          ,
   DMC_START_DT           ,
   DMC_POSTAL_CD          ,
   PAR_INSEE_NB           ,
   PAR_BU_CD              ,
   DMC_DEPRTMNT_ID        ,
   PAR_GEO_MACROZONE      ,   
   PAR_UNIFIED_PARTY_ID   ,
   PAR_PARTY_REGRPMNT_ID  ,
   PAR_IRIS2000_CD        ,
   PAR_CID_ID             ,
   PAR_PID_ID             ,
   PAR_FIRST_IN           ,
   PAR_FIBER_IN           ,
   -- Axe Organisation
   ORG_AGENT_ID           ,
   ORG_AGENT_IOBSP        ,
   EXTRNL_TYPE_AGENCE     ,
   EXTRNL_EDO_ID          ,
   ORG_EDO_ID             ,
   ORG_EDO_IOBSP          ,
   ORG_TYPE_CD            ,
   ORG_TYPE_EDO           ,
   WORK_TEAM_LEVEL_1_CD   ,
   WORK_TEAM_LEVEL_1_DS   ,
   WORK_TEAM_LEVEL_2_CD   ,
   WORK_TEAM_LEVEL_2_DS   ,
   WORK_TEAM_LEVEL_3_CD   ,
   WORK_TEAM_LEVEL_3_DS   ,
   WORK_TEAM_LEVEL_4_CD   ,
   WORK_TEAM_LEVEL_4_DS   ,
   -- Axe Canal
   ORG_CHANNEL_CD         ,
   ORG_SUB_CHANNEL_CD     ,
   ORG_SUB_SUB_CHANNEL_CD ,
   ORG_REM_CHANNEL_CD     ,
   ORG_GT_ACTIVITY        ,
   ORG_WEB_ACTIVITY       ,
   ORG_AUTO_ACTIVITY      ,
   UNIFIED_SHOP_CD        ,
   -- Champs Techniques 
   CREATION_TS            ,
   LAST_MODIF_TS          ,
   FRESH_IN               ,
   COHERENCE_IN
)
Select
 
  TblGen.ACTE_ID                    As ACTE_ID                ,
  DeltaPXF.EXTRNL_ORDER_ID          As EXTRNL_ORDER_ID        ,
  DeltaPXF.TYPE_SOURCE_ID           As TYPE_SOURCE_ID         ,
  DeltaPXF.INTRNL_SOURCE_ID         As INTRNL_SOURCE_ID       ,
  DeltaPXF.ORDER_DEPOSIT_TS         As ORDER_DEPOSIT_TS       ,
  DeltaPXF.ORDER_DEPOSIT_DT         As ORDER_DEPOSIT_DT       ,
  DeltaPXF.LAST_UPDATE_TS           As LAST_UPDATE_TS         ,
  DeltaPXF.ORDER_CANCELING_DT       As ORDER_CANCELING_DT     ,
  DeltaPXF.ORDER_CANCELING_TS       As ORDER_CANCELING_TS     ,
  DeltaPXF.EXTRNL_STATUS_CD         As EXTRNL_STATUS_CD       ,
  DeltaPXF.STATUS_UNIFIED_CD        As STATUS_UNIFIED_CD      ,
  DeltaPXF.EXTRNL_EAN_CD            As EXTRNL_EAN_CD          ,
  -- Axe Client
  DeltaPXF.EXTRNL_PHONE_NUMBER      As EXTRNL_PHONE_NUMBER    ,
  DeltaPXF.EXTRNL_MOBILE_NUMBER     As EXTRNL_MOBILE_NUMBER   ,
  DeltaPXF.EXTRNL_POSTAL_CODE       As EXTRNL_POSTAL_CODE     ,
  DeltaPXF.EXTRNL_CUSTOMER_STATUS   As EXTRNL_CUSTOMER_STATUS ,
  Null                              As DEPARTMNT_ID           ,
  Null                              As DMC_ACTIVATION_DT      ,
  Null                              As DMC_LINE_ID            ,
  Null                              As DMC_MASTER_LINE_ID     ,
  Null                              As DMC_CUST_TYPE_CD       ,
  Null                              As DMC_NDS_VALUE_DS       ,
  Null                              As DMC_MSISDN_ID          ,
  Null                              As DMC_EXTERNAL_PARTY_ID  ,
  Null                              As DMC_RES_VALUE_DS       ,
  Null                              As DMC_SERVICE_ACCESS_ID  ,
  Null                              As DMC_LINE_TYPE          ,
  Null                              As DMC_START_DT           ,
  Null                              As DMC_POSTAL_CD          ,
  Null                              As PAR_INSEE_NB           ,
  Null                              As PAR_BU_CD              ,
  Null                              As DMC_DEPRTMNT_ID        ,
  Null                              As PAR_GEO_MACROZONE      ,   
  Null                              As PAR_UNIFIED_PARTY_ID   ,
  Null                              As PAR_PARTY_REGRPMNT_ID  ,
  Null                              As PAR_IRIS2000_CD        ,
  Null                              As PAR_CID_ID             ,
  Null                              As PAR_PID_ID             ,
  Null                              As PAR_FIRST_IN           ,
  Null                              As PAR_FIBER_IN           ,
  -- Axe Organisation
  DeltaPXF.ORG_AGENT_ID             As ORG_AGENT_ID           ,
  Null                              As ORG_AGENT_IOBSP        ,
  DeltaPXF.EXTRNL_TYPE_AGENCE       As EXTRNL_TYPE_AGENCE     ,
  DeltaPXF.EXTRNL_EDO_ID            As EXTRNL_EDO_ID          ,
  Null                              As ORG_EDO_ID             ,
  Null                              As ORG_EDO_IOBSP          ,
  Null                              As ORG_TYPE_CD            ,
  Null                              As ORG_TYPE_EDO           ,
  Null                              As WORK_TEAM_LEVEL_1_CD   ,
  Null                              As WORK_TEAM_LEVEL_1_DS   ,
  Null                              As WORK_TEAM_LEVEL_2_CD   ,
  Null                              As WORK_TEAM_LEVEL_2_DS   ,
  Null                              As WORK_TEAM_LEVEL_3_CD   ,
  Null                              As WORK_TEAM_LEVEL_3_DS   ,
  Null                              As WORK_TEAM_LEVEL_4_CD   ,
  Null                              As WORK_TEAM_LEVEL_4_DS   ,
  -- Axe Canal
  Null                              As ORG_CHANNEL_CD         ,
  Null                              As ORG_SUB_CHANNEL_CD     ,
  Null                              As ORG_SUB_SUB_CHANNEL_CD ,
  Null                              As ORG_REM_CHANNEL_CD     ,
  Null                              As ORG_GT_ACTIVITY        ,
  Null                              As ORG_WEB_ACTIVITY       ,
  Null                              As ORG_AUTO_ACTIVITY      ,
  Null                              As UNIFIED_SHOP_CD        ,
  -- Champs Techniques 
  Current_timestamp(0)              As CREATION_TS            ,
  Current_Timestamp(0)              As LAST_MODIF_TS          ,
  1                                 As FRESH_IN               ,
  1                                 As COHERENCE_IN
  From
 ${KNB_PCO_TMP}.ORD_W_EXTRACT_PXF DeltaPXF
Inner Join ${KNB_PCO_SOC}.V_ACT_F_ACTE_GEN TblGen
   On    DeltaPXF.EXTERNAL_ACTE_ID  =   TblGen.EXTERNAL_ACTE_ID
   And   DeltaPXF.TYPE_SOURCE_ID    =   TblGen.TYPE_SOURCE_ID
;   
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_EXTR;
.if errorcode <> 0 then .quit 1

.quit 0
