-- $HEADER: mm2pco/current/sql/ATP_PSV_Placement_Cold_Step7_Fusion.sql 13_05#3 14-JUN-2017 12:47:30 GXPZ7694
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PSV_Placement_Step6_Fusion.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'alimentation des placements 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 30/03/2017      HOB         Creation
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_PL All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_PL
(   
   ACTE_ID                             ,
   EXTERNAL_ACTE_ID                    ,
   TYPE_SOURCE_ID                      ,
   INTRNL_SOURCE_ID                    ,
   ORDER_DEPOSIT_TS                    ,
   ORDER_DEPOSIT_DT                    ,
   ORDER_WEEK_CD                       ,
   ORDER_STATUS                        ,
   REASON_STATUS_DS                    ,
   ORDER_CANCELING_DT                  ,
   ORDER_CANCELING_TS                  ,
   ORDER_TRACE_DT                      ,
   ORDER_TRACE_TS                      ,
   ORDER_TRACE_WEEK_CD                 ,
   ORDR_TYP_CD                         ,
   EAN_CD                              ,
   EXTRNL_OPSRV_DS                     ,
   MOBL_BRAND_DS                       ,
   MOBL_MODEL_DS                       ,
   APPLY_IMEI_CD                       ,
   ORG_AGENT_ID                        ,
   ORG_NOM                             ,
   ORG_PRENOM                          ,
   PAR_LASTNAME                        ,
   PAR_FIRSTNAME                       ,
   PAR_MSISDN_ID                       ,
   PAR_AID                             ,
   PAR_NDS                             ,
   PAR_ADRESS_NM                       ,
   ORDER_POSTAL_CD                     ,
   PAR_POSTAL_CD                       ,
   PAR_CITY_LN                         ,
   PAR_PARTY_FREG_ID                   ,
   PAR_MAIL_DS                         ,
   PAR_MAIL_CENTRIX_DS                 ,
   OTAP_IDNT_MSG_DS                    ,
   OTAP_CONF_MSG_DS                    ,
   OTAP_APPS_MSG_DS                    ,
   DMC_LINE_ID                         ,
   DMC_MASTER_LINE_ID                  ,
   DMC_LINE_TYPE                       ,
   DMC_ACTIVATION_DT                   ,
   SERVICE_ACCESS_ID                   ,
   PAR_DEPRTMNT_ID                     ,
   PAR_INSEE_NB                        ,
   PAR_BU_CD                           ,
   CLIENT_NU                           ,
   DOSSIER_NU                          ,
   PAR_FIBER_IN                        ,
   PAR_GEO_MACROZONE                   ,
   ORDER_PARTY_DRAKKAR_ID              ,
   PAR_UNIFIED_PARTY_ID                ,
   PAR_PARTY_REGRPMNT_ID               ,
   PAR_IRIS2000_CD                     ,
   PAR_PID_ID                          ,
   PAR_CID_ID                          ,
   PAR_FIRST_IN                        ,
   ADDRESS_CONCAT_NM                   ,
   ADDRESS_TYPE                        ,
   CUST_BU_CD                          ,
   UNIFIED_SHOP_CD                     ,
   EDO_ID                              ,
   TYPE_EDO_ID                         ,
   DISTRBTN_CHANNL_ID                  ,
   ACTIVITY                            ,
   FLAG_PLT_SCH_IN                     ,
   FLAG_PLT_CONV_NB                    ,
   FLAG_TYPE_GEO_CD                    ,
   FLAG_TYPE_CPT_NTK                   ,
   NETWRK_TYP_EDO_ID                   ,
   FLAG_TYPE_PTN_NTK                   ,
   FLAG_AD_SC                          ,
   ORG_CHANNEL_CD                      ,
   ORG_SUB_CHANNEL_CD                  ,
   ORG_SUB_SUB_CHANNEL_CD              ,
   ORG_GT_ACTIVITY                     ,
   ORG_FIDELISATION                    ,
   ORG_WEB_ACTIVITY                    ,
   ORG_AUTO_ACTIVITY                   ,
   ORG_REM_CHANNEL_CD                  ,
   ORG_TEAM_LEVEL_1_CD                 ,
   ORG_TEAM_LEVEL_1_DS                 ,
   ORG_TEAM_LEVEL_2_CD                 ,
   ORG_TEAM_LEVEL_2_DS                 ,
   ORG_TEAM_LEVEL_3_CD                 ,
   ORG_TEAM_LEVEL_3_DS                 ,
   ORG_TEAM_LEVEL_4_CD                 ,
   ORG_TEAM_LEVEL_4_DS                 ,
   WORK_TEAM_LEVEL_1_CD                ,
   WORK_TEAM_LEVEL_1_DS                ,
   WORK_TEAM_LEVEL_2_CD                ,
   WORK_TEAM_LEVEL_2_DS                ,
   WORK_TEAM_LEVEL_3_CD                ,
   WORK_TEAM_LEVEL_3_DS                ,
   WORK_TEAM_LEVEL_4_CD                ,
   WORK_TEAM_LEVEL_4_DS                ,
   CREATION_TS                         ,
   DATE_REM_TS                         ,
   CLOSURE_FONC_DT                     ,
   CLOSURE_FONC_CD                      
)
Select 
 
   Placement.ACTE_ID                                                          as ACTE_ID                   ,
   Placement.EXTERNAL_ACTE_ID                                                as EXTERNAL_ACTE_ID          ,
   Placement.TYPE_SOURCE_ID                                                  as TYPE_SOURCE_ID            ,
   Placement.INTRNL_SOURCE_ID                                                as INTRNL_SOURCE_ID          ,
   Placement.ORDER_DEPOSIT_TS                                                as ORDER_DEPOSIT_TS          ,
   Placement.ORDER_DEPOSIT_DT                                                as ORDER_DEPOSIT_DT          ,
   Placement.ORDER_WEEK_CD                                                   as ORDER_WEEK_CD             ,
   Placement.ORDER_STATUS                                                    as ORDER_STATUS              ,
   Placement.REASON_STATUS_DS                                                as REASON_STATUS_DS          ,
   Placement.ORDER_CANCELING_DT                                              as ORDER_CANCELING_DT        ,
   Placement.ORDER_CANCELING_TS                                              as ORDER_CANCELING_TS        ,
   Placement.ORDER_TRACE_DT                                                  as ORDER_TRACE_DT            ,
   Placement.ORDER_TRACE_TS                                                  as ORDER_TRACE_TS            ,
   Placement.ORDER_TRACE_WEEK_CD                                             as ORDER_TRACE_WEEK_CD       ,
   Placement.ORDR_TYP_CD                                                     as ORDR_TYP_CD               ,
   Placement.EAN_CD                                                          as EAN_CD                    ,
   Placement.EXTRNL_OPSRV_DS                                                 as EXTRNL_OPSRV_DS           ,
   Placement.MOBL_BRAND_DS                                                   as MOBL_BRAND_DS             ,
   Placement.MOBL_MODEL_DS                                                   as MOBL_MODEL_DS             ,
   Placement.APPLY_IMEI_CD                                                   as APPLY_IMEI_CD             ,
   Placement.ORG_AGENT_ID                                                    as ORG_AGENT_ID              ,
   Coalesce(RefCUID.ORG_NOM , Placement.ORG_NOM )                            as ORG_NOM                   ,
   Coalesce(RefCUID.ORG_PRENOM , Placement.ORG_PRENOM)                       as ORG_PRENOM                ,
   Placement.PAR_LASTNAME                                                    as PAR_LASTNAME              ,
   Placement.PAR_FIRSTNAME                                                   as PAR_FIRSTNAME             ,
   Placement.PAR_MSISDN_ID                                                   as PAR_MSISDN_ID             ,
   Placement.PAR_AID                                                         as PAR_AID                   ,
   Placement.PAR_NDS                                                         as PAR_NDS                   ,
   Placement.PAR_ADRESS_NM                                                   as PAR_ADRESS_NM             ,
   Placement.ORDER_POSTAL_CD                                                 as ORDER_POSTAL_CD           ,
   Coalesce(Dmc.PAR_POSTAL_CD,Placement.PAR_POSTAL_CD )                      as PAR_POSTAL_CD             ,
   Placement.PAR_CITY_LN                                                     as PAR_CITY_LN               ,
   Placement.PAR_PARTY_FREG_ID                                               as PAR_PARTY_FREG_ID         ,
   Placement.PAR_MAIL_DS                                                     as PAR_MAIL_DS               ,
   Placement.PAR_MAIL_CENTRIX_DS                                             as PAR_MAIL_CENTRIX_DS       ,
   Placement.OTAP_IDNT_MSG_DS                                                as OTAP_IDNT_MSG_DS          ,
   Placement.OTAP_CONF_MSG_DS                                                as OTAP_CONF_MSG_DS          ,
   Placement.OTAP_APPS_MSG_DS                                                as OTAP_APPS_MSG_DS          ,
   Coalesce(Dmc.DMC_LINE_ID,Placement.DMC_LINE_ID)                           as DMC_LINE_ID               ,
   Coalesce(Dmc.DMC_MASTER_LINE_ID,Placement.DMC_MASTER_LINE_ID)             as MASTER_LINE_ID            ,
   Coalesce(Dmc.DMC_LINE_TYPE ,Placement.DMC_LINE_TYPE)                      as DMC_LINE_TYPE             ,
   Coalesce(Dmc.DMC_ACTIVATION_DT ,Placement.DMC_ACTIVATION_DT)              as DMC_ACTIVATION_DT         ,
   Coalesce(Dmc.SERVICE_ACCESS_ID,Placement.SERVICE_ACCESS_ID)               as SERVICE_ACCESS_ID         ,
   Coalesce(Dmc.PAR_DEPRTMNT_ID ,Placement.PAR_DEPRTMNT_ID)                  as PAR_DEPRTMNT_ID           ,
   Coalesce(Dmc.PAR_INSEE_NB,Placement.PAR_INSEE_NB)                         as PAR_INSEE_NB              ,
   Coalesce(Dmc.PAR_BU_CD ,Placement.PAR_BU_CD)                              as PAR_BU_CD                 ,
   Coalesce(Dmc.CLIENT_NU,Placement.CLIENT_NU)                               as CLIENT_NU                 ,
   Coalesce(Dmc.DOSSIER_NU,Placement.DOSSIER_NU)                             as DOSSIER_NU                ,
   Coalesce(Fiber.PAR_FIBER_IN ,Placement.PAR_FIBER_IN)                      as PAR_FIBER_IN              ,
   Coalesce(Iris.PAR_GEO_MACROZONE ,Placement.PAR_GEO_MACROZONE)             as PAR_GEO_MACROZONE         ,
   Placement.ORDER_PARTY_DRAKKAR_ID                                          as ORDER_PARTY_DRAKKAR_ID    ,
   Coalesce(Dmc.PAR_UNIFIED_PARTY_ID,Placement.PAR_UNIFIED_PARTY_ID)         as PAR_UNIFIED_PARTY_ID      ,
   Coalesce(Dmc.PAR_PARTY_REGRPMNT_ID ,Placement.PAR_PARTY_REGRPMNT_ID)      as PAR_REGRPMNT_ID           ,
   Coalesce(Iris.PAR_IRIS2000_CD , Placement.PAR_IRIS2000_CD)                as PAR_IRIS2000_CD           ,
   Coalesce(Dmc.PAR_PID_ID ,Placement.PAR_PID_ID)                            as PAR_PID_ID                ,
   Coalesce(Dmc.PAR_CID_ID,Placement.PAR_CID_ID)                             as PAR_CID_ID                ,
   Coalesce(Dmc.PAR_FIRST_IN , Placement.PAR_FIRST_IN)                       as PAR_FIRST_IN              ,
   Coalesce(Dmc.ADDRESS_CONCAT_NM,Placement.ADDRESS_CONCAT_NM)               as ADDRESS_CONCAT_NM         ,
   Coalesce(Dmc.ADDRESS_TYPE ,Placement.ADDRESS_TYPE)                        as ADDRESS_TYPE              ,
   Coalesce(Dmc.CUST_BU_CD ,Placement.CUST_BU_CD)                            as CUST_BU_CD                ,
   Placement.UNIFIED_SHOP_CD                                                 as UNIFIED_SHOP_CD           ,
   Coalesce(Placement.EDO_ID ,CHANNEL.EDO_ID)                                as EDO_ID                    ,
   Coalesce(Placement.TYPE_EDO_ID ,CHANNEL.TYPE_EDO_ID)                      as TYPE_EDO_ID               ,
   Placement.DISTRBTN_CHANNL_ID                                              as DISTRBTN_CHANNL_ID        ,
   Placement.ACTIVITY                                                        as ACTIVITY                  ,
   Coalesce(CHANNEL.FLAG_PLT_SCH_IN,Placement.FLAG_PLT_SCH_IN)               as FLAG_PLT_SCH_IN           ,
   Coalesce(CHANNEL.FLAG_PLT_CONV_NB,Placement.FLAG_PLT_CONV_NB)             as FLAG_PLT_CONV_NB          ,
   Coalesce(CHANNEL.FLAG_TYPE_GEO_CD,Placement.FLAG_TYPE_GEO_CD)             as FLAG_TYPE_GEO_CD          ,
   Coalesce(CHANNEL.FLAG_TYPE_CPT_NTK,Placement.FLAG_TYPE_CPT_NTK)           as FLAG_TYPE_CPT_NTK         ,
   Coalesce(CHANNEL.NETWRK_TYP_EDO_ID,Placement.NETWRK_TYP_EDO_ID )          as NETWRK_TYP_EDO_ID         ,
   Coalesce(CHANNEL.FLAG_TYPE_PTN_NTK ,Placement.FLAG_TYPE_PTN_NTK )         as FLAG_TYPE_PTN_NTK         ,
   Coalesce(CHANNEL.FLAG_AD_SC,Placement.FLAG_AD_SC )                        as FLAG_AD_SC                ,
   Coalesce(CHANNEL.ORG_CHANNEL_CD,Placement.ORG_CHANNEL_CD )                as ORG_CHANNEL_CD            ,
   Coalesce(CHANNEL.ORG_SUB_CHANNEL_CD,Placement.ORG_SUB_CHANNEL_CD )        as ORG_SUB_CHANNEL_CD        ,
   Coalesce(CHANNEL.ORG_SUB_SUB_CHANNEL_CD, Placement.ORG_SUB_SUB_CHANNEL_CD)  as ORG_SUB_SUB_CHANNEL_CD    ,
   Coalesce(CHANNEL.ORG_GT_ACTIVITY, Placement.ORG_GT_ACTIVITY )             as ORG_GT_ACTIVITY           ,
   Coalesce(CHANNEL.ORG_FIDELISATION,Placement.ORG_FIDELISATION)             as ORG_FIDELISATION          ,
   Coalesce(CHANNEL.ORG_WEB_ACTIVITY , Placement.ORG_WEB_ACTIVITY )          as ORG_WEB_ACTIVITY          ,
   Coalesce(CHANNEL.ORG_AUTO_ACTIVITY,Placement.ORG_AUTO_ACTIVITY )          as ORG_AUTO_ACTIVITY         ,
   Coalesce(CHANNEL.ORG_REM_CHANNEL_CD, Placement.ORG_REM_CHANNEL_CD)        as ORG_REM_CHANNEL_CD        ,
   Placement.ORG_TEAM_LEVEL_1_CD                                             as ORG_TEAM_LEVEL_1_CD       ,
   Placement.ORG_TEAM_LEVEL_1_DS                                             as ORG_TEAM_LEVEL_1_DS       ,
   Placement.ORG_TEAM_LEVEL_2_CD                                             as ORG_TEAM_LEVEL_2_CD       ,
   Placement.ORG_TEAM_LEVEL_2_DS                                             as ORG_TEAM_LEVEL_2_DS       ,
   Placement.ORG_TEAM_LEVEL_3_CD                                             as ORG_TEAM_LEVEL_3_CD       ,
   Placement.ORG_TEAM_LEVEL_3_DS                                             as ORG_TEAM_LEVEL_3_DS       ,
   Placement.ORG_TEAM_LEVEL_4_CD                                             as ORG_TEAM_LEVEL_4_CD       ,
   Placement.ORG_TEAM_LEVEL_4_DS                                             as ORG_TEAM_LEVEL_4_DS       ,
   Placement.WORK_TEAM_LEVEL_1_CD                                            as WORK_TEAM_LEVEL_1_CD      ,
   Placement.WORK_TEAM_LEVEL_1_DS                                            as WORK_TEAM_LEVEL_1_DS      ,
   Placement.WORK_TEAM_LEVEL_2_CD                                            as WORK_TEAM_LEVEL_2_CD      ,
   Placement.WORK_TEAM_LEVEL_2_DS                                            as WORK_TEAM_LEVEL_2_DS      ,
   Placement.WORK_TEAM_LEVEL_3_CD                                            as WORK_TEAM_LEVEL_3_CD      ,
   Placement.WORK_TEAM_LEVEL_3_DS                                            as WORK_TEAM_LEVEL_3_DS      ,
   Placement.WORK_TEAM_LEVEL_4_CD                                            as WORK_TEAM_LEVEL_4_CD      ,
   Placement.WORK_TEAM_LEVEL_4_DS                                            as WORK_TEAM_LEVEL_4_DS      ,
   Placement.CREATION_TS                                                     as CREATION_TS               ,
   Placement.DATE_REM_TS                                                     as DATE_REM_TS               ,
   Placement.CLOSURE_FONC_DT                                                 as CLOSURE_FONC_DT           ,
   Placement.CLOSURE_FONC_CD                                                 as CLOSURE_FONC_CD           

From                                                                     
  --On prend tout le contenu de la table miroir tmp                      
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_2     Placement                   
  --Enrichissement du CUID                                               
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_CUID RefCUID      
    On    Placement.ACTE_ID           = RefCUID.ACTE_ID                  
      And Placement.ORDER_DEPOSIT_DT  = RefCUID.ORDER_DEPOSIT_DT         
  --Enrichissement du canal                                              
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_CHANNEL Channel   
    On    Placement.ACTE_ID           = channel.ACTE_ID                  
      And Placement.ORDER_DEPOSIT_DT  = channel.ORDER_DEPOSIT_DT         
  --Enrichissement Client                                                
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_DMC Dmc           
    On    Placement.ACTE_ID           = Dmc.ACTE_ID                      
      And Placement.ORDER_DEPOSIT_DT  = Dmc.ORDER_DEPOSIT_DT             
 --Enrichissement IRIS2000                                               
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_IRIS Iris         
    On    Placement.ACTE_ID           = Iris.ACTE_ID                     
      And Placement.ORDER_DEPOSIT_DT  = Iris.ORDER_DEPOSIT_DT            
 --Enrichissement Fibre                                                  
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_FIBER Fiber       
    On    Placement.ACTE_ID           = Fiber.ACTE_ID                    
      And Placement.ORDER_DEPOSIT_DT  = Fiber.ORDER_DEPOSIT_DT           
                                                                    
;                                                                        
.if errorcode <> 0 then .quit 1                        
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PSV_PL    ;
.if errorcode <> 0 then .quit 1                            
.quit 0
