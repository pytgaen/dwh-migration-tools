-----------------------------------------------------------------------------------------
-- $HEADER: %HEADER%
-----------------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:  ATP_SRC_GetData_ODS_A_WITH_REJECT.sql $                   -
-- TYPE         : Script SQL                                                            -
-- DESCRIPTION  : Extraction de tables ODS avec Rejets                                  -
-----------------------------------------------------------------------------------------
--                 HISTORIQUE                                                           -
-- DATE            AUTEUR      CREATION/MODIFICATION                                    -
-- 00/00/00        XXX         Creation                                                 -
-- 10/01/14        AID         Modification mise ne norme DSM                           -
-----------------------------------------------------------------------------------------

.set width 250;

-- Delete preventif
DELETE FROM ${KNB_FILE_DBTG}.${KNB_FILE_TBTG} ALL;

.if errorcode <> 0 then .quit 1

-- Alimentation
INSERT INTO ${KNB_FILE_DBTG}.${KNB_FILE_TBTG}
(
  ${KNB_LST_COL_ODS},
  FRESH_TS,
  CREATION_TS,
  LAST_MODIF_TS,
  ${KNB_STR_INSERT_COL}
  FRESH_IN,
  COHERENCE_IN
)
SELECT
  ${KNB_LST_COL_ODS},
  M.FRESH_TS,
  CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0)) as CREATION_TS,
  CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0)) AS LAST_MODIF_TS,
  ${KNB_STR_SELECT_COL}
  1 AS FRESH_IN,
  0 AS COHERENCE_IN
FROM 
  ${KNB_ODS_SOURCE_TABLE} O
INNER JOIN
  ${KNB_PCO_TECH}.MET_W_COMPLETUDE_${KNB_SRCE_CD} M
ON
  M.FILE_NM = O.FILE_ID
WHERE
-- Restriction à la source 
  M.APPLI_SOURCE_CD = '${KNB_SRCE_CD}' AND
-- Restriction sur le type de fichier
  M.FILE_CD = '${KNB_FILE_CD}'
-- Condition dedoublonnage au sein de la fraîcheur
QUALIFY
  ROW_NUMBER() OVER(PARTITION BY ${KNB_FILE_PRKY}, FRESH_TS ORDER BY LINE_NU) = 1       
-- On purge la table des rejets pour le FILE_ID et la fraîcheur traitée
;DELETE
FROM ${KNB_FILE_RJTB} J
WHERE EXISTS (
SELECT 1
FROM
${KNB_PCO_TECH}.MET_W_COMPLETUDE_${KNB_SRCE_CD} M
WHERE
-- Filtre sur la source
J.APPLI_SOURCE_CD = M.APPLI_SOURCE_CD AND
-- Filtre sur le filename
J.FILE_ID = M.FILE_NM 
)
-- On alimente la table des rejets
;INSERT INTO ${KNB_FILE_RJTB}
(
  APPLI_SOURCE_CD,
  FRESH_TS,
  FILE_ID,
  LINE_NU,
  ${KNB_LST_COL_ODS},
  CREATION_TS,
  LAST_MODIF_TS,
  FRESH_IN,
  COHERENCE_IN
)
SELECT
  '${KNB_SRCE_CD}' AS APPLI_SOURCE_CD,
  M.FRESH_TS,
  O.FILE_ID,
  O.LINE_NU,
  ${KNB_LST_COL_ODS},
  CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0)) as CREATION_TS,
  CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0)) AS LAST_MODIF_TS,
  1 AS FRESH_IN,
  1 AS COHERENCE_IN
FROM 
  ${KNB_ODS_SOURCE_TABLE} O
INNER JOIN
  ${KNB_PCO_TECH}.MET_W_COMPLETUDE_${KNB_SRCE_CD} M
ON
  M.FILE_NM = O.FILE_ID
WHERE
-- Restriction à la source 
  M.APPLI_SOURCE_CD = '${KNB_SRCE_CD}' AND
-- Restriction sur le type de fichier
  M.FILE_CD = '${KNB_FILE_CD}'
-- On compte pour une même séquence/fraicheur combien on a de doublons
-- reçu dans les fichiers (on ne "trappe" pas les doublons parfaits car
-- ils sont éliminés au chargement)
QUALIFY
  COUNT(*) OVER(PARTITION BY ${KNB_FILE_PRKY},FRESH_TS) > 1 
-- On vide l'ODS si la purge est activée
;DELETE 
FROM 
  ${KNB_ODS_SOURCE_TABLE} O
WHERE EXISTS
(
  SELECT 1
  FROM
  ${KNB_PCO_TECH}.MET_W_COMPLETUDE_${KNB_SRCE_CD} M
  WHERE
-- Restriction sur le filename
  M.FILE_NM = O.FILE_ID AND
-- Restriction à la source 
  M.APPLI_SOURCE_CD = '${KNB_SRCE_CD}' AND
-- Restriction sur le type de fichier
  M.FILE_CD = '${KNB_FILE_CD}' AND
-- Purge active
  'O' = '${KNB_FILE_PURG}'
)
; 

.if errorcode <> 0 then .quit 1




