-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Hot_Alimentation_MOB_Step3_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de calcul  acte full SOFT mobile à Chaud
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 28/07/2014      YZH         Modification (ajouts des flags canaux)
-- 26/03/2015      MDE         Modif : Ajout enrichissement du CC/Ve  QC446
-- 23/04/2015      AOU         PDV Point Orange à exclure du Canal AD  QC884
-- 06/01/2016      MDE         Modification (Evol CA)
-- 13/05/2016      GMA         Modification Axe Canal Pilcom MultiCanal
-- 29/07/2016      ABO         Modification multi-canal: Ajout ATH
-- 27/11/2017      MEL         Ajout indicateur IOBSP
-- 21/09/2019      SSI         Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
-- 28/05/2020      JCR         modification champs adresse
-- 22/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
-- 14/01/2021      BCH         PILCOM-1086 : Decom ORG_WEB_PARTNER_IN
--------------------------------------------------------------------------------

.set width 2500;




Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_MOB All;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_MOB
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  OPERATOR_PROVIDER_ID              ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_EXTERNAL_ID                 ,
  INTRNL_SOURCE_ID                  ,
  ORDER_REF_EXTERNAL_ID             ,
  ORDER_OPER_ID                     ,
  ORDER_MOTV_ID                     ,
  ORDER_MOTIF_DS                    ,
  ORDER_STATUT_CD                   ,
  ORDER_STATUT_MODIF_TS             ,
  ORDER_LAST_STATUT_CD              ,
  ORDER_LAST_STATUT_MODIF_TS        ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_PRODUCT_DS_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  INB_PRESFACT_ACQ_ADV              ,
  INB_PRESFACT_ACQ_AGAP             ,
  SEG_PARC_DT_DEBUT                 ,
  INB_PARK_ID                       ,
  FLAG_HD                           ,
  ORG_CANAL_ID                      ,
  ORG_CHANEL_CD                     ,
  ORG_SUB_CHANEL_CD                 ,
  ORG_SUB_SUB_CHANEL_CD             ,
  ORG_REM_CHANEL_CD                 ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORIG_DEM                          ,
  CANALDEM_MTHD                     ,
  ORG_CANAL_ID_MACRO                ,
  ORG_CANAL_MACRO_LB                ,
  ORG_STORE_NAME                    ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_FLAG_TYPE_PTN_NTK             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  PAR_EXTERNAL_PARTY_FREG_ID        ,
  PAR_PARTY_KNB_FREG_ID             ,
  PAR_CID_ID                        ,
  PAR_PID_ID                        ,
  PAR_FIRST_IN                      ,
  ORG_AGENT_IOBSP                   ,
  ORG_EDO_IOBSP                     ,
  PAR_AID                           ,
  PAR_PARTY_KNB_BSS_ID              ,
  PAR_ND                            ,
  PAR_ACCES_SERVICE                 ,
  PAR_ADV_CLIENT_NU                 ,
  PAR_ADV_DOSSIER_NU                ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  OTO_OSCAR_VALUE_NU                ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_SIRET                         ,
  PAR_MARKET_SEG                    ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_CD_POSTAL                ,
  PAR_DO                            ,
  PAR_BU_CD                         ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  PAR_MOB_IMEI                      ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  PAR_MOB_IMSI                      ,
  PAR_SCORE_NU_INT                  ,
  PAR_SCORE_IN_INT                  ,
  PAR_TRESHOLD_NU_INT               ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  CONTRCT_DT_SIGN_PREC_INT          ,
  CONTRCT_DT_FIN_PREC_INT           ,
  CONTRCT_DT_DEB_SIGN_POST_INT      ,
  CONTRCT_DT_FIN_SIGN_POST_INT      ,
  DUREE_ENGAGEMENT_INT              ,
  TYPE_DUR_ENGAGEMENT_INT           ,
  CONTRCT_DT_SIGN_PREC_MOB          ,
  CONTRCT_DT_FIN_PREC_MOB           ,
  CONTRCT_DT_SIGN_POST_MOB          ,
  CONTRCT_DUREE_ENG_MOB             ,
  CONTRCT_UNIT_ENG_MOB              ,
  CONFIRMATION_IN                   ,
  CONFIRMATION_DT                   ,
  CONFIRMATION_CALC_FIN_DT          ,
  DELIVERY_IN                       ,
  DELIVERY_DT                       ,
  DELIVERY_CALC_FIN_DT              ,
  PERENNITE_IN                      ,
  PERENNITE_FIN_DT                  ,
  PERENNITE_CALC_FIN_DT             ,
  SEG_PRES_PARC_COMMANDE            ,
  CONCURENCE_IN                     ,
  CONCURENCE_CONCLU_IN              ,
  CONCURENCE_ID                     ,
  DELIVERY_ONTIME_IN                ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                       
)
Select
  Placement.ACTE_ID                                         as ACTE_ID                            ,
  Placement.ACTE_ID                                         as ACTE_ID_GEN                        ,
  Placement.OPERATOR_PROVIDER_ID                            as OPERATOR_PROVIDER_ID               ,
  Placement.ORDER_DEPOSIT_DT                                as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                as ORDER_DEPOSIT_TS                   ,
  Placement.EXTERNAL_ORDER_ID                               as ORDER_EXTERNAL_ID                  ,
  Placement.INTRNL_SOURCE_ID                                as INTRNL_SOURCE_ID                   ,
  Placement.VAD_ORDER_ID                                    as ORDER_REF_EXTERNAL_ID              ,
  Placement.ACTE_OPERTR_ID_OT                               as ORDER_OPER_ID                      ,
  Placement.MOTV_ORDR_ID                                    as ORDER_MOTV_ID                      ,
  Case  When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_310}'
          Then  '${P_PIL_311}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_312}'
          Then  '${P_PIL_313}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_314}'
          Then  '${P_PIL_315}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_316}'
          Then  '${P_PIL_317}'
        When  Placement.ACTE_OPERTR_ID_OT = '${P_PIL_318}'
          Then  '${P_PIL_319}'
        Else    '${P_PIL_321}'
  End                                                       as ORDER_MOTIF_DS                     ,
  Placement.ORDER_STATUS_CD                                 as ORDER_STATUT_CD                    ,
  Placement.STATUS_MODIF_TS                                 as ORDER_STATUT_MODIF_TS              ,
  Placement.ORDER_LAST_STATUT_CD                            as ORDER_LAST_STATUT_CD               ,
  Placement.ORDER_LAST_STATUT_MODIF_TS                      as ORDER_LAST_STATUT_MODIF_TS         ,
  ActeSoft.PRODUCT_ID_PRE                                   as ACT_PRODUCT_ID_PRE                 ,
  ActeSoft.PRODUCT_DS_PRE                                   as ACT_PRODUCT_DS_PRE                 ,
  ActeSoft.SEG_COM_ID_PRE                                   as ACT_SEG_COM_ID_PRE                 ,
  ActeSoft.SEG_COM_AGG_ID_PRE                               as ACT_SEG_COM_AGG_ID_PRE             ,
  ActeSoft.CODE_MIGR_PRE                                    as ACT_CODE_MIGR_PRE                  ,
  ActeSoft.TYPE_MVT_PRE                                     as ACT_OPER_ID_PRE                    ,
  ActeSoft.PRODUCT_ID_FINAL                                 as ACT_PRODUCT_ID_FINAL               ,
  Placement.PRESFACT_CO_OFFRE_OPT_DS                        as ACT_PRODUCT_DS_FINAL               ,
  ActeSoft.SEG_COM_ID_FINAL                                 as ACT_SEG_COM_ID_FINAL               ,
  ActeSoft.SEG_COM_AGG_ID_FINAL                             as ACT_SEG_COM_AGG_ID_FINAL           ,
  ActeSoft.CODE_MIGR_FINAL                                  as ACT_CODE_MIGR_FINAL                ,
  ActeSoft.TYPE_MVT_FINAL                                   as ACT_OPER_ID_FINAL                  ,
  ActeSoft.TYPE_SERVICE_FINAL                               as ACT_TYPE_SERVICE_FINAL             ,
  Coalesce(Mat.TYPE_COMMANDE_ID, ActeSoft.TYPE_COMMANDE_ID) as ACT_TYPE_COMMANDE_ID               ,
--Unité = NB
  Case When Mat.UNITE_CD ='${P_PIL_620}'
         Then ActeSoft.DELTA_TARIF 
    --Unité  CA_MARKET 
      When Mat.UNITE_CD ='${P_PIL_623}'
           then Mat.CA_MARKETING 
       Else Coalesce(ActeSoft.DELTA_TARIF,0)
  End                                                       as ACT_DELTA_TARIF                    ,
  Mat.UNITE_CD                                              as ACT_UNITE_CD                       ,
  Case  When Mat.ACTE_ID Is Not Null
          Then  Mat.ACTE_ID
        When ActeSoft.PERIODE_ID  = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit Placé est un produit inconnu de RefCom
        When  ActeSoft.PRODUCT_ID_FINAL  = '${P_PIL_223}'
          Then  '${P_PIL_224}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        When ActeSoft.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        Else '${P_PIL_220}'
  End                                                       as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID,'${P_PIL_067}')                  as ACT_REM_ID                         ,
  Coalesce(Mat.FLAG_ACT_REM,'N')                            as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC,'N')                         as ACT_FLAG_PEC_PERPVC                ,
     --Unité = NB
  Case When Mat.UNITE_CD ='${P_PIL_620}'
         Then Mat.ACTE_VALO
  --Unité = CA_MARKET 
       When Mat.UNITE_CD  ='${P_PIL_623}' 
         Then cast(( ACT_DELTA_TARIF * Mat.TAUX_MARGE ) as Format '-----------9,99')
       Else   Coalesce(Mat.ACTE_VALO,0)
  End                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Mat.ACTE_FAMILLE_KPI,'NON PARAM')                as ACT_ACTE_FAMILLE_KPI               ,
  ActeSoft.PERIODE_ID                                       as ACT_PERIODE_ID                     ,
  Null                                                      as INB_PRESFACT_ACQ_ADV               ,
  Null                                                      as INB_PRESFACT_ACQ_AGAP              ,
  Null                                                      as SEG_PARC_DT_DEBUT                  ,
  Null                                                      as INB_PARK_ID                        ,
  Mat.HUMAINDIGITAL                                         as FLAG_HD                            ,
  Placement.DISTRBTN_CHANNL_ID                              as ORG_CANAL_ID                       ,
  --Calcul du canal de vente Macro
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_CHANNEL_CD
        When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
         Then  'Exclus'
         When Orga.ORG_CHANEL_CD Is Not Null
         Then  Orga.ORG_CHANEL_CD
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
         Then  OrgaWeb.ORG_CHANEL_CD
        When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
         Then 'Online'
        Else 'NONPARAM' 
  End                                                       as ORG_CHANEL_CD_AGR                    ,
  --Sous Canal
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_SUB_CHANNEL_CD
        When Orga.ORG_CHANEL_CD Is Not Null
        Then Case When (Placement.FLAG_TYPE_CPT_NTK = 'AUTRC' AND ORG_CHANEL_CD_AGR ='Dist')
                    Then 'RC'
                  When FLAG_TYPE_PTN_NTK ='DCE'
                    Then 'Exclus'
                  Else Orga.ORG_SUB_CHANEL_CD
               End
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
         Then Orgaweb.ORG_SUB_CHANEL_CD
        Else 'NONPARAM'
  End                                                       as ORG_SUB_CHANEL_CD_AGR                  ,
  --Sous-Sous-Canal
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_SUB_SUB_CHANNEL_CD
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
          Then Case When FLAG_TYPE_PTN_NTK ='DCE'
                     Then 'Exclus'
                    Else Orga.ORG_SUB_SUB_CHANEL_CD
               End
        When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR='RC')
          Then Case  When FLAG_TYPE_CPT_NTK ='AUT'
                        Then 'AUTRC'
                      When FLAG_TYPE_CPT_NTK ='GRO'
                        Then 'GROSS'
                      Else FLAG_TYPE_CPT_NTK
                End
        When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP' And Placement.TYPE_EDO='INT')
          Then 'PAP Int'
        When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP' And Placement.TYPE_EDO='EXT')
          Then 'PAP Ext'
        When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR<>'RC')
          Then 
            Case When FLAG_TYPE_GEO Is Not Null
             Then 'DOM'
            Else 'Metropole'
            End
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_SUB_SUB_CHANEL_CD
        Else 'NONPARAM'
  End                                                       as ORG_SUB_SUB_CHANEL_CD_AGR            ,
  --Canal de Rem
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_REM_CHANNEL_CD
        When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
          Then  'Exclus'
        When ORG_SUB_SUB_CHANEL_CD_AGR = 'PAP Int'
          Then 'PAP'
        When ORG_SUB_SUB_CHANEL_CD_AGR = 'PAP Ext'
          Then 'Exclus'
        When Orga.ORG_CHANEL_CD Is Not Null  
          Then Orga.ORG_REM_CHANEL_CD
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_REM_CHANEL_CD
        When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
         Then 'Online'
        Else 'NONPARAM'
  End                                                       as ORG_REM_CHANEL_CD                  ,
  --ActivitÃ©
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_GT_ACTIVITY
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
          Then  'Exclus'
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
          Then Orga.ORG_GT_ACTIVITY
        When ORG_CHANEL_CD_AGR = 'Dist'
          Then
            Case  When ORG_SUB_CHANEL_CD_AGR =  'PAP'
                    Then 'Porte a Porte'
                  When FLAG_TYPE_PTN_NTK = 'MOB'
                    Then 'Mobistore'
                  When FLAG_TYPE_PTN_NTK = 'FC'
                    Then 'CARAIBES'
                  When FLAG_TYPE_PTN_NTK Is Not Null
                   Then FLAG_TYPE_PTN_NTK
                  When ORG_SUB_CHANEL_CD_AGR='AD'
                   Then 'Boutique FT'
                  When ORG_SUB_CHANEL_CD_AGR='RC'
                   Then 'Reseau Concurrent'
            End
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_GT_ACTIVITY            
        Else 'NONPARAM'
  End                                                       as ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_FIDELISATION
        When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
          Then  'Exclus'
        When Orga.ORG_CHANEL_CD Is Not Null  
          Then Orga.ORG_FIDELISATION
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_FIDELISATION
        Else 'NONPARAM'
  End                                                       as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_WEB_ACTIVITY
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
          Then  'Exclus'
        When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist'  )
          Then Orga.ORG_WEB_ACTIVITY
        When ORG_CHANEL_CD_AGR = 'Dist'
          Then 'NON'
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_WEB_ACTIVITY
        When OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
          Then 'OUI'
        Else 'E'
  End                                                       as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique
  Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
          Then OrgaPDV.ORG_AUTO_ACTIVITY
        When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
          Then 'Exclus'
        When ORG_CHANEL_CD_AGR = 'Dist'
          Then 'NON'
        When Orga.ORG_CHANEL_CD Is Not Null  
          Then Orga.ORG_AUTO_ACTIVITY
        When OrgaWeb.ORG_CHANEL_CD Is Not Null
          Then OrgaWeb.ORG_AUTO_ACTIVITY
        When OrgaWeb.ORG_CHANEL_CD Is Null And  Placement.DISTRBTN_CHANNL_ID ='SCC'
          Then 'OUI'
        Else 'E'
  End                                                       as ORG_AUTO_ACTIVITY                  ,
  Null                                                      as ORIG_DEM                           ,
  Null                                                      as CANALDEM_MTHD                      ,
  Null                                                      as ORG_CANAL_ID_MACRO                 ,
  Null                                                      as ORG_CANAL_MACRO_LB                 ,
  Placement.STORE_NAME                                      as ORG_STORE_NAME                     ,
  Placement.EDO_ID                                          as ORG_EDO_ID                         ,
  Placement.TYPE_EDO                                        as ORG_TYPE_EDO                       ,
  Placement.NETWRK_TYP_EDO_ID                               as ORG_NETWRK_TYP_EDO_ID              ,
  Placement.FLAG_TYPE_GEO                                   as ORG_FLAG_TYPE_GEO                  ,
  Placement.FLAG_TYPE_CPT_NTK                               as ORG_FLAG_TYPE_CPT_NTK              ,
  Placement.FLAG_TYPE_PTN_NTK                               as ORG_FLAG_TYPE_PTN_NTK              ,
  Placement.FLAG_PLT_CONV                                   as ORG_FLAG_PLT_CONV                  ,
  Placement.FLAG_TEAM_MKT                                   as ORG_FLAG_TEAM_MKT                  ,
  Placement.FLAG_TYPE_CMP                                   as ORG_FLAG_TYPE_CMP                  ,
  Null                                                      as ORG_REF_TRAV                       ,
  Placement.AGENT_ID                                        as ORG_AGENT_ID                       ,
  Null                                                      as ORG_POC_XI                         ,
  Placement.AGENT_ID                                        as ORG_AGENT_ID_UPD                   ,
  Null                                                      as ORG_AGENT_ID_UPD_DT                ,
  Placement.ORG_NOM                                         as ORG_NOM                            ,
  Placement.ORG_PRENOM                                      as ORG_PRENOM                         ,
  Null                                                      as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitée
  Null                                                      as ORG_ACTVT_REEL                     ,
  Null                                                      as ORG_RESP_REF_TRAV                  ,
  Null                                                      as ORG_RESP_AGENT_ID                  ,
  Null                                                      as ORG_RESP_XI                        ,
  Placement.CUSTOMER_FGT_ID                                 as PAR_EXTERNAL_PARTY_FREG_ID         ,
  Null                                                      as PAR_PARTY_KNB_FREG_ID              ,
  Null                                                      as PAR_CID_ID                         ,
  Null                                                      as PAR_PID_ID                         ,
  Null                                                      as PAR_FIRST_IN                       ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                    ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                      ,
  Placement.CUSTOMER_BSS_ID                                 as PAR_AID                            ,
  Null                                                      as PAR_PARTY_KNB_BSS_ID               ,
  Placement.CUSTOMER_ND_AR                                  as PAR_ND                             ,
  Null                                                      as PAR_ACCES_SERVICE                  ,
  Null                                                      as PAR_ADV_CLIENT_NU                  ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                         as PAR_ADV_DOSSIER_NU                 ,
  Null                                                      as DMC_LINE_ID                        ,
  Null                                                      as DMC_MASTER_LINE_ID                 ,
  Null                                                      as PAR_GEO_MACROZONE                  ,
  Null                                                      as PAR_UNIFIED_PARTY_ID               ,
  Null                                                      as PAR_PARTY_REGRPMNT_ID              ,
  Placement.OSCAR_VALUE_NU                                  as OTO_OSCAR_VALUE_NU                 ,
  Placement.CUSTOMER_LAST_NAME                              as PAR_LASTNAME                       ,
  Placement.CUSTOMER_FIRST_NAME                             as PAR_FIRSTNAME                      ,
  Placement.CUSTOMER_SIRET                                  as PAR_SIRET                          ,
  Placement.CUSTOMER_MARKET_SEG                             as PAR_MARKET_SEG                     ,
  Null                                                      as PAR_TYPE                           ,
  Null                                                      as PAR_EMAIL                          ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_STREET 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_STREET
  End                                                       as PAR_BILL_ADRESS_1                  ,
  Null                                                      as PAR_BILL_ADRESS_2                  ,
  Null                                                      as PAR_BILL_ADRESS_3                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_CITY 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_CITY
  End                                                       as PAR_BILL_ADRESS_4                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_ZIPCODE 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_ZIPCODE
  End                                                       as PAR_BILL_CD_POSTAL                 ,  
--Pour les  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3) In (${L_PIL_034})
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3)
        When    Placement.INSTALL_ADDRESS_ZIPCODE Is not Null
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 2)
        Else    Null
  End                                                       as PAR_DO                             ,
  Placement.INSTALL_REGIONAL_DIRCTN_ID                      as PAR_BU_CD                          ,
  Null                                                      as PAR_USCM                           ,
  Null                                                      as PAR_USCM_DS                        ,
  Null                                                      as PAR_USCM_USCM_DS                   ,
  Null                                                      as PAR_USCM_REGUSCM                   ,
  Null                                                      as PAR_USCM_REGUSCM_DS                ,
  Null                                                      as PAR_MOB_IMEI                       ,
  Null                                                      as PAR_MOB_TAC                        ,
  Null                                                      as PAR_MOB_SIM                        ,
  Null                                                      as PAR_MOB_IMSI                       ,
  Null                                                      as PAR_SCORE_NU_INT                   ,
  Null                                                      as PAR_SCORE_IN_INT                   ,
  Null                                                      as PAR_TRESHOLD_NU_INT                ,
  Null                                                      as PAR_SCORE_NU_MOB                   ,
  Null                                                      as PAR_SCORE_IN_MOB                   ,
  Null                                                      as PAR_TRESHOLD_NU_MOB                ,
  Null                                                      as CONTRCT_DT_SIGN_PREC_INT           ,
  Null                                                      as CONTRCT_DT_FIN_PREC_INT            ,
  Null                                                      as CONTRCT_DT_DEB_SIGN_POST_INT       ,
  Null                                                      as CONTRCT_DT_FIN_SIGN_POST_INT       ,
  Null                                                      as DUREE_ENGAGEMENT_INT               ,
  Null                                                      as TYPE_DUR_ENGAGEMENT_INT            ,
  Null                                                      as CONTRCT_DT_SIGN_PREC_MOB           ,
  Null                                                      as CONTRCT_DT_FIN_PREC_MOB            ,
  Null                                                      as CONTRCT_DT_SIGN_POST_MOB           ,
  Null                                                      as CONTRCT_DUREE_ENG_MOB              ,
  Null                                                      as CONTRCT_UNIT_ENG_MOB               ,
  Null                                                      as CONFIRMATION_IN                    ,
  Null                                                      as CONFIRMATION_DT                    ,
  Null                                                      as CONFIRMATION_CALC_FIN_DT           ,
  Null                                                      as DELIVERY_IN                        ,
  Null                                                      as DELIVERY_DT                        ,
  Null                                                      as DELIVERY_CALC_FIN_DT               ,
  Null                                                      as PERENNITE_IN                       ,
  Null                                                      as PERENNITE_FIN_DT                   ,
  Null                                                      as PERENNITE_CALC_FIN_DT              ,
  Null                                                      as SEG_PRES_PARC_COMMANDE             ,
  Null                                                      as CONCURENCE_IN                      ,
  Null                                                      as CONCURENCE_CONCLU_IN               ,
  Null                                                      as CONCURENCE_ID                      ,
  Null                                                      as DELIVERY_ONTIME_IN                 ,
  Null                                                      as CHECK_INITIAL_STATUS_CD            ,
  Null                                                      as CHECK_NAT_STATUS_CD                ,
  Null                                                      as CHECK_NAT_COMMENT                  ,
  Null                                                      as CHECK_NAT_STATUS_LN                ,
  Null                                                      as CHECK_LOC_STATUS_CD                ,
  Null                                                      as CHECK_LOC_COMMENT                  ,
  Null                                                      as CHECK_LOC_STATUS_LN                ,
  Null                                                      as CHECK_VALIDT_DT                    ,
  Null                                                      as CLOSURE_DT                         ,
  Placement.QUEUE_TS                                        as QUEUE_TS                           ,
  Placement.RUN_ID                                          as RUN_ID                             ,
  Placement.STREAMING_TS                                    as STREAMING_TS                       ,
  '${KNB_DATE_VACATION}'                                    as CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                    as LAST_MODIF_TS                      ,
  1                                                         as HOT_IN                             ,
  1                                                         as FRESH_IN                           ,
  0                                                         as COHERENCE_IN                       
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_MOB Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_CAL ActeSoft
    On    Placement.ACTE_ID           = ActeSoft.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = ActeSoft.ORDER_DEPOSIT_DT
    --Jointure récupérer les infos de la table des matrices
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On  Case  When Placement.EXT_OPER_ID = '${P_PIL_099}' And ActeSoft.TYPE_COMMANDE_ID = '${P_PIL_026}'
                Then '${P_PIL_018}'
              -- Sinon on remet le type commande de sortie
              Else  ActeSoft.TYPE_COMMANDE_ID
        End                                                 = Mat.TYPE_COMMANDE_ID
      And ActeSoft.SEG_COM_ID_FINAL                         = Mat.SEG_COM_ID_FINAL
      And ActeSoft.PERIODE_ID                               = Mat.PERIODE_ID
      And Coalesce(ActeSoft.SEG_COM_ID_PRE,'${P_PIL_211}')  = Mat.SEG_COM_ID_INI
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_SOFT Orga
    On    Placement.DISTRBTN_CHANNL_ID                        = Orga.DISTRBTN_CHANNL_ID
      And Placement.FLAG_PLT_CONV                             = Orga.FLAG_PLT_CONV
      And Placement.FLAG_TEAM_MKT                             = Orga.FLAG_TEAM_MKT
      And Placement.FLAG_TYPE_CMP                             = Orga.FLAG_TYPE_CMP
      And Orga.FRESH_IN                                       = 1
      And Orga.CURRENT_IN                                     = 1
      And Orga.CLOSURE_DT                                     is Null
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_WEB Orgaweb
    On    Placement.DISTRBTN_CHANNL_ID                        = Orgaweb.ORG_CHANNL_ID
      And Placement.STORE_NAME                                = Orgaweb.ORG_PDV_CD
      And Orgaweb.FRESH_IN                                    = 1
      And Orgaweb.CURRENT_IN                                  = 1
      And Orgaweb.CLOSURE_DT                                  is Null
   Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_PDV OrgaPDV
    On    Placement.DISTRBTN_CHANNL_ID                        = OrgaPDV.DISTRBTN_CHANNL_ID
      And Placement.STORE_NAME                                = OrgaPDV.PDV
      And OrgaPDV.FRESH_IN                                    = 1
      And OrgaPDV.CURRENT_IN                                  = 1
      And OrgaPDV.CLOSURE_DT                                  is Null
Where
  (1=1)
  --Tous les RMP sont Purgés des actes car on fait porter le maintient sans la suppression
  And Placement.EXT_OPER_ID not in ('${P_PIL_098}')
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_MOB;
.if errorcode <> 0 then .quit 1


