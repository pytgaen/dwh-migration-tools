-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step1_PreniteVerificationValidEFB.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des actes les lignes élibles dont on a déjà calculer la pérénité
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_VAL_CHECKED all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_VAL_CHECKED
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  VALDTN_DT                
)
Select
  Acte.ACTE_ID                    as ACTE_ID              ,
  Acte.ORDER_DEPOSIT_DT           as ORDER_DEPOSIT_DT     ,
  Acte.INB_VALDTN_DT              as VALDTN_DT            
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_INT Acte
Where
  (1=1)
  And Acte.ACT_SEG_COM_ID_FINAL   Not In ('${P_PIL_022}','NS')
  And Acte.INB_VALDTN_DT          Is Not Null
  And Acte.ORDER_DEPOSIT_DT       >=  Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_VAL_CHECKED;
.if errorcode <> 0 then .quit 1


.quit 0
