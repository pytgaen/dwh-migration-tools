-- $HEADER: mm2pco/current/sql/ATP_EXF_Placement_C_Alimentation_Step2_Placement_CREA.sql 13_05#3 09-NOV-2018 17:20:32 LXQG9925
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_EXF_Placement_C_Alimentation_Step2_Placement_CREA.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de placement à partir la table IHM de création d'acte
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/06/2014      OCH         Creation
-- 06/11/2018      LMU         Modification : REINJection
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL 
Where TYPE_MOVEMENT_CD In ('CREA', 'REINJ') ;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL
(
  ACTE_ID                 ,
  TYPE_MOVEMENT_CD        ,
  EXTERNAL_ACTE_ID        ,
  INTRNL_SOURCE_ID        ,
  ORDER_DEPOSIT_DT        ,
  ORDER_DEPOSIT_TS        ,
  NUM_ORDER_NU            ,
  COMMENT_DS              ,
  LAST_NAME_CUSTOMER_NM   ,
  FIRST_NAME_CUSTOMER_NM  ,
  MISISDN_ID              ,
  ND_ID                   ,
  NDIP_ID                 ,
  TYPE_CUSTOMER_CD        ,
  AGENT_ID                ,
  ACT_REM_ID              ,
  EDO_ID                  ,
  QUANTT_QT               ,
  CA_AM                   ,
  CA_LINE_AM              ,
  TYPE_SOURCE_CD          ,
  NATURE_CD               ,
  OSCAR_VALUE_CD          ,
  ENGAGMNT_NB             ,
  INJECTION_TS            ,
  CREATION_TS             ,
  LAST_MODIF_TS           ,
  FRESH_IN                ,
  COHERENCE_IN             
)
Select
  ActeId.ACTE_ID                                                As ACTE_ID                  ,
  Placement.TYPE_MOVEMENT_CD                                    As TYPE_MOVEMENT_CD         ,
  Placement.EXTERNAL_ACTE_ID                                    As EXTERNAL_ACTE_ID         ,
  Placement.INTRNL_SOURCE_ID                                    As INTRNL_SOURCE_ID         ,
  Placement.ORDER_DEPOSIT_DT                                    As ORDER_DEPOSIT_DT         ,
  Placement.ORDER_DEPOSIT_TS                                    As ORDER_DEPOSIT_TS         ,
  Placement.NUM_ORDER_NU                                        As NUM_ORDER_NU             ,
  Placement.COMMENT_DS                                          As COMMENT_DS               ,
  Placement.LAST_NAME_CUSTOMER_NM                               As LAST_NAME_CUSTOMER_NM    ,
  Placement.FIRST_NAME_CUSTOMER_NM                              As FIRST_NAME_CUSTOMER_NM   ,
  Placement.MISISDN_ID                                          As MISISDN_ID               ,
  Placement.ND_ID                                               As ND_ID                    ,
  Placement.NDIP_ID                                             As NDIP_ID                  ,
  Placement.TYPE_CUSTOMER_CD                                    As TYPE_CUSTOMER_CD         ,
  Placement.AGENT_ID                                            As AGENT_ID                 ,
  Placement.ACT_REM_ID                                          As ACT_REM_ID               ,
  Placement.EDO_ID                                              As EDO_ID                   ,
  Placement.QUANTT_QT                                           As QUANTT_QT                ,
  Placement.CA_AM                                               As CA_AM                    ,
  Placement.CA_AM/Placement.QUANTT_QT                           As CA_LINE_AM               ,
  Placement.TYPE_SOURCE_CD                                      As TYPE_SOURCE_CD           ,
  Placement.NATURE_CD                                           As NATURE_CD                ,
  Placement.OSCAR_VALUE_CD                                      As OSCAR_VALUE_CD           ,
  Placement.ENGAGMNT_NB                                         As ENGAGMNT_NB              ,
  Placement.INJECTION_TS                                        As INJECTION_TS             ,
  Current_Timestamp(0)                                          As CREATION_TS              ,
  Current_Timestamp(0)                                          As LAST_MODIF_TS            ,
  1                                                             As FRESH_IN                 ,
  0                                                             As COHERENCE_IN
From
  --On prend tout le contenu de la table miroir tmp
  ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_EXT Placement
  --On jointe avec la table referentiel pour générer le bon nombre de ligne
  Inner Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN ActeId
    On    Placement.EXTERNAL_ACTE_ID          = ActeId.EXTERNAL_ACTE_ID
    And   Placement.TYPE_SOURCE_ID            = ActeId.TYPE_SOURCE_ID
;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL;
.if errorcode <> 0 then .quit 1

.quit 0
