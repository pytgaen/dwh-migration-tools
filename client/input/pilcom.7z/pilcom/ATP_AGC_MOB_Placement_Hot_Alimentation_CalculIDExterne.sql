-- $HEADER: mm2pco/current/sql/ATP_AGC_MOB_Placement_Hot_Alimentation_CalculIDExterne.sql 13_05#2 13-MAI-2019 10:12:32 LXQG9925
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_MOB_Placement_Hot_Alimentation_CalculIDExterne.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul des ID externes pour les actes AGC OT/SO
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 26/03/2014      YZH         Creation
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H_EXT All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H_EXT
(
    EXTERNAL_ACTE_ID                      ,
    INTRNL_SOURCE_ID                      ,
    TYPE_SOURCE_ID                        ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    ORDER_TYPE_CD                         ,
    PRODUCT_TYPE                          ,
    EXTERNAL_PRODUCT_ID                   ,
    MOUVEMENT                             ,
    --Autres attributs à récupérer
    MOBILE_MSISDN_ID                      ,
    MSISDN_PORTED                         ,
    IMEI_CD                               ,
    SIM_CD                                ,
    SIM_EAN_CD                            ,
    INVOICE_ADDRESS_MAIL_NM
)
Select 
      trim(Req.CONTEXT_ID)||'|'||trim(Req.EXTERNAL_ORDER_ID)||'|'
      ||trim(Req.ORDER_TYPE_CD)||'|'||trim(Req.PRODUCT_TYPE)||'|'
      ||trim(Req.EXTERNAL_PRODUCT_ID)||'|'||trim(Req.MOUVEMENT)||'|'
      ||trim(cast (Req.QUEUE_TS as varchar(22)))                                                             AS EXTERNAL_ACTE_ID         ,
      ${IdSourceInterne}                                                                                     AS INTRNL_SOURCE_ID         ,
      ${IdentifiantTechniqueSource}                                                                          AS TYPE_SOURCE_ID           ,
      Req.CONTEXT_ID                                                                                         AS CONTEXT_ID               ,
      Req.EXTERNAL_ORDER_ID                                                                                  AS EXTERNAL_ORDER_ID        ,
      Req.ORDER_DEPOSIT_TS                                                                                   AS ORDER_DEPOSIT_TS         ,
      Req.ORDER_DEPOSIT_DT                                                                                   AS ORDER_DEPOSIT_DT         ,
      Req.ORDER_TYPE_CD                                                                                      AS ORDER_TYPE_CD            ,
      Req.PRODUCT_TYPE                                                                                       AS PRODUCT_TYPE             ,
      Req.EXTERNAL_PRODUCT_ID                                                                                AS EXTERNAL_PRODUCT_ID      ,
      Req.MOUVEMENT                                                                                          AS MOUVEMENT                ,
      Case when MOUVEMENT <> 'RMV' then Req.TERMINAL_MSISDN_ID  else null end                                AS MOBILE_MSISDN_ID         ,
      Case when MOUVEMENT <> 'RMV' then Req.MSISDN_PORTED       else null end                                AS MSISDN_PORTED            ,
      Case when MOUVEMENT <> 'RMV' then Req.IMEI_CD             else null end                                AS IMEI_CD                  ,
      Case when MOUVEMENT <> 'RMV' then Req.SIM_CD              else null end                                AS SIM_CD                   ,
      Case when MOUVEMENT <> 'RMV' then Req.SIM_EAN_CD          else null end                                AS SIM_EAN_CD               ,
      Req.INVOICE_ADDRESS_MAIL_NM                                                                            AS INVOICE_ADDRESS_MAIL_NM
from
(
  -- New offer
  Select
      LigneCom.CONTEXT_ID                                           AS CONTEXT_ID                ,
      LigneCom.EXTERNAL_ORDER_ID                                    AS EXTERNAL_ORDER_ID         ,
      LigneCom.ORDER_DEPOSIT_TS                                     AS ORDER_DEPOSIT_TS          ,
      LigneCom.ORDER_DEPOSIT_DT                                     AS ORDER_DEPOSIT_DT          ,
      LigneCom.ORDER_TYPE_CD                                        AS ORDER_TYPE_CD             ,
      'OT'                                                          AS PRODUCT_TYPE              ,
      LigneCom.NEW_OFFER_CD                                         AS EXTERNAL_PRODUCT_ID       ,
      Case When (
                  (LigneCom.NEW_OFFER_CD <> LigneCom.ORIGINAL_OFFER_CD Or LigneCom.ORIGINAL_OFFER_CD is null) 
                  And 
                  LigneCom.NEW_OFFER_CD is not null
                )                                
           Then '${P_PIL_005}'                          --Creation
           When (LigneCom.NEW_OFFER_CD=LigneCom.ORIGINAL_OFFER_CD Or LigneCom.NEW_OFFER_CD is null)
           Then  '${P_PIL_007}'                         --Maintient
      End                                                           AS MOUVEMENT                 ,
      LigneCom.TERMINAL_MSISDN_ID                                   AS TERMINAL_MSISDN_ID        ,
      LigneCom.MSISDN_PORTED                                        AS MSISDN_PORTED             ,
      LigneCom.IMEI_CD                                              AS IMEI_CD                   ,
      LigneCom.NEW_SIM_CD                                           AS SIM_CD                    ,
      LigneCom.NEW_EAN_CD                                           AS SIM_EAN_CD                ,
      LigneCom.INVOICE_ADDRESS_MAIL_NM                              AS INVOICE_ADDRESS_MAIL_NM   ,
      LigneCom.QUEUE_TS                                             AS QUEUE_TS 
  From ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM LigneCom
  Where ORDER_TYPE_CD <> '6'  
  -- Dedoublonnage à l'intérieur du Run.
  -- On ne prend que le dernier new_offer saisi
  Qualify row_number() over (partition by CONTEXT_ID, EXTERNAL_ORDER_ID, ORDER_TYPE_CD  
                             order by Queue_ts desc)=1
  Union
  -- Old offer
  Select    
      LigneCom.CONTEXT_ID                                           AS CONTEXT_ID               ,
      LigneCom.EXTERNAL_ORDER_ID                                    AS EXTERNAL_ORDER_ID        ,
      LigneCom.ORDER_DEPOSIT_TS                                     AS ORDER_DEPOSIT_TS         ,
      LigneCom.ORDER_DEPOSIT_DT                                     AS ORDER_DEPOSIT_DT         ,
      LigneCom.ORDER_TYPE_CD                                        AS ORDER_TYPE_CD            ,
      'OT'                                                          AS PRODUCT_TYPE             ,
      LigneCom.ORIGINAL_OFFER_CD                                    AS EXTERNAL_PRODUCT_ID      ,
      Case When (LigneCom.NEW_OFFER_CD <> LigneCom.ORIGINAL_OFFER_CD And LigneCom.NEW_OFFER_CD is not null)
           Then '${P_PIL_008}'                          --Suppression
           When (LigneCom.NEW_OFFER_CD=LigneCom.ORIGINAL_OFFER_CD Or LigneCom.NEW_OFFER_CD is null)
           Then  '${P_PIL_007}'                         --Maintient
      End                                                           AS MOUVEMENT                ,
      LigneCom.TERMINAL_MSISDN_ID                                   AS TERMINAL_MSISDN_ID       ,
      LigneCom.MSISDN_PORTED                                        AS MSISDN_PORTED            ,
      LigneCom.IMEI_CD                                              AS IMEI_CD                  ,
      LigneCom.NEW_SIM_CD                                           AS SIM_CD                   ,
      LigneCom.NEW_EAN_CD                                           AS SIM_EAN_CD               ,
      LigneCom.INVOICE_ADDRESS_MAIL_NM                              AS INVOICE_ADDRESS_MAIL_NM  ,
      LigneCom.QUEUE_TS                                             AS QUEUE_TS 
  From ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM LigneCom
  Where ORDER_TYPE_CD <> '6' And LigneCom.ORIGINAL_OFFER_CD Is Not Null
  -- On ne prend que le dernier original_offer saisi
  Qualify row_number() over (partition by CONTEXT_ID, EXTERNAL_ORDER_ID, ORDER_TYPE_CD  
                             order by Queue_ts desc)=1 
  Union
  -- Options
  Select    
      LigneCom.CONTEXT_ID                                           AS CONTEXT_ID               ,
      LigneCom.EXTERNAL_ORDER_ID                                    AS EXTERNAL_ORDER_ID        ,
      LigneCom.ORDER_DEPOSIT_TS                                     AS ORDER_DEPOSIT_TS         ,
      LigneCom.ORDER_DEPOSIT_DT                                     AS ORDER_DEPOSIT_DT         ,
      LigneCom.ORDER_TYPE_CD                                        AS ORDER_TYPE_CD            ,
      'SO'                                                          AS PRODUCT_TYPE             ,
      LigneCom.OPTION_IODA                                          AS EXTERNAL_PRODUCT_ID      ,
      Case When LigneCom.OPTION_ACTION in ('C', 'P')
           Then  '${P_PIL_005}'             -- Creation
           When LigneCom.OPTION_ACTION in ('S')
           Then  '${P_PIL_008}'             -- Suppression
           When LigneCom.OPTION_ACTION in ('R')
           Then  '${P_PIL_007}'             -- Maintient     
      End                                                           AS MOUVEMENT                ,
      LigneCom.TERMINAL_MSISDN_ID                                   AS TERMINAL_MSISDN_ID       ,
      LigneCom.MSISDN_PORTED                                        AS MSISDN_PORTED            ,
      LigneCom.IMEI_CD                                              AS IMEI_CD                  ,
      LigneCom.NEW_SIM_CD                                           AS SIM_CD                   ,
      LigneCom.NEW_EAN_CD                                           AS SIM_EAN_CD               ,
      LigneCom.INVOICE_ADDRESS_MAIL_NM                              AS INVOICE_ADDRESS_MAIL_NM  ,
      LigneCom.QUEUE_TS                                             AS QUEUE_TS 
  From ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM LigneCom
  Where ORDER_TYPE_CD <> '6' And LigneCom.OPTION_IODA Is Not Null
  -- On ne prend que la dernière action saisie pour chaque option 
  Qualify row_number() over (partition by CONTEXT_ID, EXTERNAL_ORDER_ID, ORDER_TYPE_CD,OPTION_IODA
                             order by Queue_ts desc)=1
) Req
Where Req.EXTERNAL_PRODUCT_ID is not null 

;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H_EXT;
.if errorcode <> 0 then .quit 1

.quit 0
