-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_PRP_Placement_Hot_Alimentation_CalculIDExterne.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de calcul des ID externes pour les actes AGC prépayées
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/05/2014      YZH         Creation
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_H_EXT All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_H_EXT
(
    EXTERNAL_ACTE_ID                      ,
    INTRNL_SOURCE_ID                      ,
    TYPE_SOURCE_ID                        ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    ORDER_TYPE_CD                         ,                            
    PRODUCT_TYPE                          ,
    EXTERNAL_PRODUCT_ID                   ,
    EXTERNAL_PRODUCT_ID_SEC               ,
    MOUVEMENT                             ,                             
    --Autres attributs à récupérer
    MOBILE_MSISDN_ID                      ,
    MSISDN_PORTED                         ,
    IMEI_CD                               ,
    SIM_CD                                ,
    SIM_EAN_CD                                          
)
Select 
      trim(Req.CONTEXT_ID)||'|'||trim(Req.EXTERNAL_ORDER_ID)||'|'
      ||trim(Req.ORDER_TYPE_CD)||'|'||trim(Req.PRODUCT_TYPE)||'|'
      ||trim(Req.EXTERNAL_PRODUCT_ID)||'|'||trim(Req.MOUVEMENT)||'|'
      ||trim(cast (Req.QUEUE_TS as varchar(22)))                                                             AS EXTERNAL_ACTE_ID    ,
      ${IdSourceInterne}                                                                                     AS INTRNL_SOURCE_ID    ,
      ${IdentifiantTechniqueSource}                                                                          AS TYPE_SOURCE_ID      ,
      Req.CONTEXT_ID                                                                                         AS CONTEXT_ID          ,
      Req.EXTERNAL_ORDER_ID                                                                                  AS EXTERNAL_ORDER_ID   ,
      Req.ORDER_DEPOSIT_TS                                                                                   AS ORDER_DEPOSIT_TS    ,
      Req.ORDER_DEPOSIT_DT                                                                                   AS ORDER_DEPOSIT_DT    ,
      Req.ORDER_TYPE_CD                                                                                      AS ORDER_TYPE_CD       ,
      Req.PRODUCT_TYPE                                                                                       AS PRODUCT_TYPE        ,
      Req.EXTERNAL_PRODUCT_ID                                                                                AS EXTERNAL_PRODUCT_ID ,
      Req.EXTERNAL_PRODUCT_ID_SEC                                                                            AS EXTERNAL_PRODUCT_ID_SEC,
      Req.MOUVEMENT                                                                                          AS MOUVEMENT           ,
      Req.TERMINAL_MSISDN_ID                                                                                 AS MOBILE_MSISDN_ID    ,
      Req.MSISDN_PORTED                                                                                      AS MSISDN_PORTED       ,
      Req.IMEI_CD                                                                                            AS IMEI_CD             ,
      Req.SIM_CD                                                                                             AS SIM_CD              ,
      Req.SIM_EAN_CD                                                                                         AS SIM_EAN_CD           
from  
(
  -- Plan tarifaire & déclinaisons
  Select
      LigneCom.CONTEXT_ID                                           AS CONTEXT_ID             ,
      LigneCom.EXTERNAL_ORDER_ID                                    AS EXTERNAL_ORDER_ID      ,
      LigneCom.ORDER_DEPOSIT_TS                                     AS ORDER_DEPOSIT_TS       ,
      LigneCom.ORDER_DEPOSIT_DT                                     AS ORDER_DEPOSIT_DT       ,
      LigneCom.ORDER_TYPE_CD                                        AS ORDER_TYPE_CD          ,
      'OT'                                                          AS PRODUCT_TYPE           ,
      LigneCom.NEW_OFFER_CD                                         AS EXTERNAL_PRODUCT_ID    , -- Déclinaisons 
      Case When LigneCom.ORIGINAL_OFFER_CD is Null
        Then 'ND'
      Else LigneCom.ORIGINAL_OFFER_CD       
      End                                                           AS EXTERNAL_PRODUCT_ID_SEC, -- Plans tarifaires     
      '${P_PIL_005}'                                                AS MOUVEMENT              ,
      LigneCom.TERMINAL_MSISDN_ID                                   AS TERMINAL_MSISDN_ID     ,
      LigneCom.MSISDN_PORTED                                        AS MSISDN_PORTED          ,
      LigneCom.IMEI_CD                                              AS IMEI_CD                ,
      LigneCom.NEW_SIM_CD                                           AS SIM_CD                 ,
      LigneCom.NEW_EAN_CD                                           AS SIM_EAN_CD             ,
      LigneCom.QUEUE_TS                                             AS QUEUE_TS 
  From ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM LigneCom
  Where ORDER_TYPE_CD = '6'  
  -- Dedoublonnage à l'intérieur du Run.
  -- On ne prend que le dernier new_offer saisi
  Qualify row_number() over (partition by CONTEXT_ID, EXTERNAL_ORDER_ID, ORDER_TYPE_CD  
                             order by Queue_ts desc)=1
  Union
  -- Options
  Select    
      LigneCom.CONTEXT_ID                                           AS CONTEXT_ID             ,
      LigneCom.EXTERNAL_ORDER_ID                                    AS EXTERNAL_ORDER_ID      ,
      LigneCom.ORDER_DEPOSIT_TS                                     AS ORDER_DEPOSIT_TS       ,
      LigneCom.ORDER_DEPOSIT_DT                                     AS ORDER_DEPOSIT_DT       ,
      LigneCom.ORDER_TYPE_CD                                        AS ORDER_TYPE_CD          ,
      'SO'                                                          AS PRODUCT_TYPE           ,
      LigneCom.NEW_OFFER_CD                                         AS EXTERNAL_PRODUCT_ID    ,
      LigneCom.OPTION_IODA                                          AS EXTERNAL_PRODUCT_ID_SEC,
      '${P_PIL_005}'                                                AS MOUVEMENT              ,
      LigneCom.TERMINAL_MSISDN_ID                                   AS TERMINAL_MSISDN_ID     ,
      LigneCom.MSISDN_PORTED                                        AS MSISDN_PORTED          ,
      LigneCom.IMEI_CD                                              AS IMEI_CD                ,
      LigneCom.NEW_SIM_CD                                           AS SIM_CD                 ,
      LigneCom.NEW_EAN_CD                                           AS SIM_EAN_CD             ,
      LigneCom.QUEUE_TS                                             AS QUEUE_TS 
  From ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM LigneCom
  Where ORDER_TYPE_CD = '6'And LigneCom.OPTION_IODA Is Not Null
  -- On ne prend que la dernière action saisie pour chaque option 
  Qualify row_number() over (partition by CONTEXT_ID, EXTERNAL_ORDER_ID, ORDER_TYPE_CD,OPTION_IODA  
                             order by Queue_ts desc)=1    
) Req
Where
  (1=1)
  And Req.EXTERNAL_PRODUCT_ID Is Not Null 
;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_PRP_H_EXT;
.if errorcode <> 0 then .quit 1

.quit 0
