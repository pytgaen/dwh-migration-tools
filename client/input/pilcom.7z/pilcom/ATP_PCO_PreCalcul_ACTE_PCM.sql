-- $HEADER: mm2pco/current/sql/ATP_PCO_PreCalcul_ACTE_PCM.sql 13_05#8 25-JUN-2018 18:31:17 LXQG9925
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_PreCalcul_ACTE_PCM.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_KC
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     CDR         Création
-- 19/03/2013     XKN         Modification : Modification de la jointure avec PERIODE (inner --> Left) afin de tracer les erreurs PERIODE_ID inocnnues
-- 06/02/2014     AID         Indus
-- 12/04/2015     MDE         Evol  : profondeur calcul 100 jrs
-- 02/05/2018     LMU         Modification dans le cadre des développements des RCS
---------------------------------------------------------------------------------

.set width 2000;

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
-- Partie PCM
-- **************************************************************

Delete from ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
( 
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  SEGMENTVALEURCLIENT       ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE
)
Select
  CalculTypePCM.ACTE_ID             as ACTE_ID                    ,
  CalculTypePCM.DATESAISIEBCR       as DATESAISIEBCR              ,
  CalculTypePCM.SEGMENTVALEURCLIENT as SEGMENTVALEURCLIENT        ,
  'ACQ'                             as EXT_PRODUCT_ID             ,
  CalculTypePCM.PERIODE_ID          as PERIODE_ID                 ,
  Coalesce(RefProduit.PRODUCT_ID,'${P_PIL_223}')             as PRODUCT_ID                 ,
  RefSegCom.SEG_COM_ID              as SEG_COM_ID                 ,
  RefSegCom.TYPE_SERVICE            as TYPE_SERVICE               ,
  RefSeg.SEG_COM_AGG_ID             as SEG_COM_AGG_ID             ,
  RefCat.CODE_MIGRATION             as CODE_MIGRATION             ,
  RefCat.MIGRATION_REGROUPEMENT_ID  as MIGRATION_REGROUPEMENT_ID  ,
  RegMigPossible.MIGRATION_POSSIBLE as MIGRATION_POSSIBLE
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATESAISIEBCR                                           as DATESAISIEBCR        ,
  --On Privilégie s'il y a un cashBack
      Coalesce(TypePcm1.FICTIF_PRODUCT_ID,TypePcm2.FICTIF_PRODUCT_ID) as EXT_PRODUCT_ID       ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                   ,
          Placement.DATESAISIEBCR                   as DATESAISIEBCR             ,
          Case  When    Placement.ID_PROGRAMMEFID='${P_PIL_089}' --Cas d'un PCM ORM
                  Then  '${P_PIL_087}'
                Else    '${P_PIL_088}'
          End                                       as TYPE_PCM                   ,
          Placement.SEGMENTVALEURCLIENT             as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          Placement.REFARTICLE                      as REFARTICLE
        From ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM Placement
        Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
          On    Placement.DATESAISIEBCR >= Period.PERIODE_DATE_DEB
         And Placement.DATESAISIEBCR <= Period.PERIODE_DATE_FIN
                     And Period.FRESH_IN = 1
         And Period.CURRENT_IN = 1
         And Period.CLOSURE_DT Is Null
        Where (1=1)
          And Placement.CLOSURE_DT Is null
          And Placement.DATESAISIEBCR   >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR   >= (Current_date - ${P_PIL_533})
          And Placement.TYPE_COMMANDE = 'PCM'
      )TmpCalc
      --Jointure pour récupérer les code EAN
      Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PRODUCT_FICTIF TypePcm1
       On   TmpCalc.REFARTICLE          = TypePcm1.ID_EXT
        And TmpCalc.TYPE_PCM            = TypePcm1.PRODUCT_TYPE
        And TypePcm1.FRESH_IN           = 1
        And TypePcm1.CURRENT_IN         = 1
        And TypePcm1.CLOSURE_DT         Is Null
      --Jointure pour les cas générique (Code EAN Null)
      Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_PRODUCT_FICTIF TypePcm2
       On   TmpCalc.TYPE_PCM            = TypePcm2.PRODUCT_TYPE
        And TypePcm2.ID_EXT             = '#'
        And TypePcm2.FRESH_IN           = 1
        And TypePcm2.CURRENT_IN         = 1
        And TypePcm2.CLOSURE_DT         Is Null
  )CalculTypePCM
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefProduit
    On    CalculTypePCM.EXT_PRODUCT_ID=RefProduit.EXT_PRODUCT_ID1
      And CalculTypePCM.PERIODE_ID = RefProduit.PERIODE_ID
      And RefProduit.FRESH_IN=1
      And RefProduit.CURRENT_IN=1
      And RefProduit.CLOSURE_DT is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
    On    RefProduit.PRODUCT_ID=RefSegCom.PRODUCT_ID
    --Filtre
      And RefSegCom.FRESH_IN=1
      And RefSegCom.CURRENT_IN=1
      And RefSegCom.CLOSURE_DT is null
      And RefSegCom.PERIODE_ID=CalculTypePCM.PERIODE_ID
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSeg
    On    RefSegCom.SEG_COM_ID=RefSeg.SEG_COM_ID
    --Filtre
      And RefSeg.FRESH_IN=1
      And RefSeg.CURRENT_IN=1
      And RefSeg.CLOSURE_DT is null
      And RefSeg.PERIODE_ID=RefSegCom.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCat
    On    RefSegCom.SEG_COM_ID=RefCat.SEG_COM_ID
    --Filtre
      And RefCat.FRESH_IN=1
      And RefCat.CURRENT_IN=1
      And RefCat.CLOSURE_DT is null
      And RefCat.PERIODE_ID=RefSegCom.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REGR_MIGR_PILCOM RegMigPossible
    On    RefCat.MIGRATION_REGROUPEMENT_ID=RegMigPossible.MIGRATION_REGROUPEMENT_ID
    --Filtre
      And RegMigPossible.FRESH_IN=1
      And RegMigPossible.CURRENT_IN=1
      And RegMigPossible.CLOSURE_DT is null
      And RegMigPossible.PERIODE_ID=RefCat.PERIODE_ID

Where
  (1=1)
  And CalculTypePCM.DATESAISIEBCR < Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
( 
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  SEGMENTVALEURCLIENT       ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE
)
Select
  CalculTypePCM.ACTE_ID                    as ACTE_ID                    ,
  CalculTypePCM.DATESAISIEBCR              as DATESAISIEBCR              ,
  CalculTypePCM.SEGMENTVALEURCLIENT        as SEGMENTVALEURCLIENT        ,
  CalculTypePCM.EXT_PRODUCT_ID             as EXT_PRODUCT_ID             ,
  CalculTypePCM.PERIODE_ID                 as PERIODE_ID                 ,
  Coalesce(CalculTypePCM.PRODUCT_ID,'${P_PIL_223}')             as PRODUCT_ID                 ,
  CalculTypePCM.SEG_COM_ID                 as SEG_COM_ID                 ,
  CalculTypePCM.TYPE_SERVICE               as TYPE_SERVICE               ,
  CalculTypePCM.SEG_COM_AGG_ID_FINAL       as SEG_COM_AGG_ID             ,
  CalculTypePCM.CODE_MIGR_FINAL            as CODE_MIGRATION             ,
  CalculTypePCM.MIGRATION_REGROUPEMENT_ID  as MIGRATION_REGROUPEMENT_ID  ,
  CalculTypePCM.MIGRATION_POSSIBLE         as MIGRATION_POSSIBLE
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATESAISIEBCR                                           as DATESAISIEBCR        ,
  --On Privilégie s'il y a un cashBack
      TmpCalc.TYPE_PCM                                                as EXT_PRODUCT_ID       ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      TypeEAN.PRODUCT_ID                                              as PRODUCT_ID           ,
      TypeEAN.SEG_COM_ID                                              as SEG_COM_ID           ,
      TypeEAN.TYPE_SERVICE                                            as TYPE_SERVICE         ,
      TypeEAN.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID_FINAL ,
      TypeEAN.CODE_MIGRATION                                          as CODE_MIGR_FINAL      ,
      TypeEAN.MIGRATION_REGROUPEMENT_ID                               as MIGRATION_REGROUPEMENT_ID ,
      TypeEAN.MIGRATION_POSSIBLE                                      as MIGRATION_POSSIBLE      
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                   ,
          Placement.DATESAISIEBCR                   as DATESAISIEBCR             ,
          Case  When    Placement.ID_PROGRAMMEFID='${P_PIL_089}' --Cas d'un PCM ORM
                    Then  'ORM'
                Else    'PCM'
          End                                       as TYPE_PCM                   ,
          Placement.SEGMENTVALEURCLIENT             as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          cast(trim(Placement.REFARTICLE )  as varchar(13))                    as REFARTICLE
        From
            ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM Placement
            Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
                On      Placement.DATESAISIEBCR >= Period.PERIODE_DATE_DEB
                    And Placement.DATESAISIEBCR <= Period.PERIODE_DATE_FIN
                    And Period.FRESH_IN         = 1
                    And Period.CURRENT_IN       = 1
                    And Period.CLOSURE_DT       Is Null
        Where (1=1)
          And Placement.CLOSURE_DT Is null
          And Placement.DATESAISIEBCR >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR   >= (Current_date - ${P_PIL_533})
          And Placement.TYPE_COMMANDE = 'PCM'
      )TmpCalc
      --Jointure pour récupérer les code EAN
      Inner Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN TypeEAN
        On      TmpCalc.REFARTICLE                  = TypeEAN.CODE_EAN
            And TmpCalc.PERIODE_ID                  = TypeEAN.PERIODE_ID
      Where
      (1=1)
  )CalculTypePCM
 ;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1 

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
( 
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  SEGMENTVALEURCLIENT       ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE
)
Select
  CalculTypePCM.ACTE_ID                    as ACTE_ID                    ,
  CalculTypePCM.DATESAISIEBCR              as DATESAISIEBCR              ,
  CalculTypePCM.SEGMENTVALEURCLIENT        as SEGMENTVALEURCLIENT        ,
  CalculTypePCM.EXT_PRODUCT_ID             as EXT_PRODUCT_ID             ,
  CalculTypePCM.PERIODE_ID                 as PERIODE_ID                 ,
  Coalesce(CalculTypePCM.PRODUCT_ID,'${P_PIL_223}')             as PRODUCT_ID                 ,
  CalculTypePCM.SEG_COM_ID                 as SEG_COM_ID                 ,
  CalculTypePCM.TYPE_SERVICE               as TYPE_SERVICE               ,
  CalculTypePCM.SEG_COM_AGG_ID_FINAL       as SEG_COM_AGG_ID             ,
  CalculTypePCM.CODE_MIGR_FINAL            as CODE_MIGRATION             ,
  CalculTypePCM.MIGRATION_REGROUPEMENT_ID  as MIGRATION_REGROUPEMENT_ID  ,
  CalculTypePCM.MIGRATION_POSSIBLE         as MIGRATION_POSSIBLE
From
  (
    Select
      TmpCalc.ACTE_ID                                                 as ACTE_ID              ,
      TmpCalc.DATESAISIEBCR                                           as DATESAISIEBCR        ,
  --On Privilégie s'il y a un cashBack
      TmpCalc.TYPE_PCM                                                as EXT_PRODUCT_ID       ,
      TmpCalc.SEGMENTVALEURCLIENT                                     as SEGMENTVALEURCLIENT  ,
      TmpCalc.PERIODE_ID                                              as PERIODE_ID           ,
      TypeEAN.PRODUCT_ID                                              as PRODUCT_ID           ,
      TypeEAN.SEG_COM_ID                                              as SEG_COM_ID           ,
      TypeEAN.TYPE_SERVICE                                            as TYPE_SERVICE         ,
      TypeEAN.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID_FINAL ,
      TypeEAN.CODE_MIGRATION                                          as CODE_MIGR_FINAL      ,
      TypeEAN.MIGRATION_REGROUPEMENT_ID                               as MIGRATION_REGROUPEMENT_ID ,
      TypeEAN.MIGRATION_POSSIBLE                                      as MIGRATION_POSSIBLE      
    From
      (
        Select
          Placement.ACTE_ID                         as ACTE_ID                   ,
          Placement.DATESAISIEBCR                   as DATESAISIEBCR             ,
          Case  When    Placement.ID_PROGRAMMEFID='${P_PIL_089}' --Cas d'un PCM ORM
                   Then  'ORM'
                Else    'PCM'
          End                                       as TYPE_PCM                   ,
          Placement.SEGMENTVALEURCLIENT             as SEGMENTVALEURCLIENT        ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049}) as PERIODE_ID                 ,
          cast(trim(Placement.REFARTICLE )  as varchar(13))                      as REFARTICLE
        From
            ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM Placement
            Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
                On      Placement.DATESAISIEBCR >= Period.PERIODE_DATE_DEB
                    And Placement.DATESAISIEBCR <= Period.PERIODE_DATE_FIN
                    And Period.FRESH_IN         = 1
                    And Period.CURRENT_IN       = 1
                    And Period.CLOSURE_DT       Is Null
        Where (1=1)
          And Placement.CLOSURE_DT Is null
          And Placement.DATESAISIEBCR   >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR   >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR   >= (Current_date - ${P_PIL_533})
          And Placement.TYPE_COMMANDE = 'PCM'
      )TmpCalc
      --Jointure pour récupérer EAN
        Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB TypeEAN
            On  Case  When TmpCalc.TYPE_PCM = 'ORM'
                        Then 'PP_0000003'
                        Else 'PP_0000004'
                End                                = TypeEAN.PRODUCT_ID
            And TmpCalc.PERIODE_ID                 = TypeEAN.PERIODE_ID
            Where 
                (1=1)
                And Not Exists
                    (
                        Select
                         1
                        From
                          ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM RefId
                        Where
                         (1=1)
                         And TmpCalc.ACTE_ID           = RefId.ACTE_ID
                         And TmpCalc.DATESAISIEBCR     = RefId.DATESAISIEBCR
                    )
  )CalculTypePCM
  ;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1









-- *************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
-- Partie RCS
-- **************************************************************

Insert Into ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM
( 
  ACTE_ID                   ,
  DATESAISIEBCR             ,
  SEGMENTVALEURCLIENT       ,
  EXT_PRODUCT_ID            ,
  PERIODE_ID                ,
  PRODUCT_ID                ,
  SEG_COM_ID                ,
  TYPE_SERVICE              ,
  SEG_COM_AGG_ID            ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE
)
Select
  CalculTypePCM.ACTE_ID                    as ACTE_ID                    ,
  CalculTypePCM.DATESAISIEBCR              as DATESAISIEBCR              ,
  CalculTypePCM.SEGMENTVALEURCLIENT        as SEGMENTVALEURCLIENT        ,
  CalculTypePCM.EXT_PRODUCT_ID             as EXT_PRODUCT_ID             ,
  CalculTypePCM.PERIODE_ID                 as PERIODE_ID                 ,
  Coalesce(CalculTypePCM.PRODUCT_ID,'${P_PIL_223}')             as PRODUCT_ID                 ,
  CalculTypePCM.SEG_COM_ID                 as SEG_COM_ID                 ,
  CalculTypePCM.TYPE_SERVICE               as TYPE_SERVICE               ,
  CalculTypePCM.SEG_COM_AGG_ID_FINAL       as SEG_COM_AGG_ID             ,
  CalculTypePCM.CODE_MIGR_FINAL            as CODE_MIGRATION             ,
  CalculTypePCM.MIGRATION_REGROUPEMENT_ID  as MIGRATION_REGROUPEMENT_ID  ,
  CalculTypePCM.MIGRATION_POSSIBLE         as MIGRATION_POSSIBLE
From
  (
    Select
      TmpCalc.ACTE_ID                                                    as ACTE_ID                   ,
      TmpCalc.DATESAISIEBCR                                              as DATESAISIEBCR             ,
      'INIT'                                                              as EXT_PRODUCT_ID            ,
      TmpCalc.SEGMENTVALEURCLIENT                                        as SEGMENTVALEURCLIENT       ,
      TmpCalc.PERIODE_ID                                                 as PERIODE_ID                ,
      RCS_Refcom.PRODUCT_ID                                              as PRODUCT_ID                ,
      RCS_Refcom.SEG_COM_ID                                              as SEG_COM_ID                ,
      RCS_Refcom.TYPE_SERVICE                                            as TYPE_SERVICE              ,
      RCS_Refcom.SEG_COM_AGG_ID                                          as SEG_COM_AGG_ID_FINAL      ,
      'NON'                                                              as CODE_MIGR_FINAL           ,
      Null                                                               as MIGRATION_REGROUPEMENT_ID ,
      0                                                                  as MIGRATION_POSSIBLE      
    From
      (
        Select
          Placement.ACTE_ID                                                      as ACTE_ID                   ,
          Placement.DATESAISIEBCR                                                as DATESAISIEBCR             ,
          Placement.SEGMENTVALEURCLIENT                                          as SEGMENTVALEURCLIENT       ,
          Coalesce(Period.PERIODE_ID, ${P_PIL_049})                              as PERIODE_ID                ,
          cast(trim(Placement.REFARTICLE )  as varchar(13))                      as REFARTICLE
        From
            ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM Placement
            Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
                On      Placement.DATESAISIEBCR >= Period.PERIODE_DATE_DEB
                    And Placement.DATESAISIEBCR <= Period.PERIODE_DATE_FIN
                    And Period.FRESH_IN         = 1
                    And Period.CURRENT_IN       = 1
                    And Period.CLOSURE_DT       Is Null
        Where (1=1)
          And Placement.CLOSURE_DT Is null
          And Placement.DATESAISIEBCR   >= Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR   >= Cast('${P_PIL_483}' As Date Format 'YYYYMMDD')
          And Placement.DATESAISIEBCR   >= (Current_date - ${P_PIL_533})
          And Placement.TYPE_COMMANDE = 'RCS'
      )TmpCalc
      Inner Join ${KNB_PCO_TMP}.CAT_W_RCS_REFCOM_JOUR RCS_Refcom
      On               TmpCalc.PERIODE_ID = RCS_Refcom.PERIODE_ID
      And              RCS_Refcom.EXT_PRODUCT_ID_1 = 'PCM_RCS_INC_00001'
  )CalculTypePCM
  ;

.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_PCM;
.if errorcode <> 0 then .quit 1