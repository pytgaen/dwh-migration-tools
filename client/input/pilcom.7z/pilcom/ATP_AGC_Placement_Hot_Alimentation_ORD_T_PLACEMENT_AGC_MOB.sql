-- $HEADER: mm2pco/current/sql/ATP_AGC_Placement_Hot_Alimentation_ORD_T_PLACEMENT_AGC_MOB.sql 13_05#11 26-JUN-2019 11:38:50 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_AGC_Placement_Hot_Alimentation_ORD_T_PLACEMENT_AGC_MOB.sql
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table T placement pour AGC MOB
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/03/2014      YZH         Creation
-- 25/04/2016      MDE         Evol : Axe Canal sur AGC 
-- 18/07/2016      MDE         Evol : Modif joiture avec CAT_W_NSH_REFO3_JOUR 
-- 18/12/2017      HOB         IOBSP
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
-- 31/05/2021      EVI         PILCOM-802 : Remplacement CAT_W_NSH_REFO3_JOUR par CAT_W_PILCOM_REFO3_JOUR
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_MOB_H All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_MOB_H
(
    ACTE_ID                               ,
    EXTERNAL_ACTE_ID                      ,
    INTRNL_SOURCE_ID                      ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    ORDER_TYPE_CD                         ,
    PRODUCT_TYPE                          ,
    EXTERNAL_PRODUCT_ID                   ,
    MOUVEMENT                             ,
    MSISDN_PORTED                         ,
    PAR_IMEI_CD                           ,
    PAR_SIM_CD                            ,
    SIM_EAN_CD                            ,
    -- Champs de la table commande
    MAIN_MSISDN_ID                        ,
    SECOND_MSISDN_ID                      ,
    HOLDER_CIVILITY                       ,
    HOLDER_LAST_NAME                      ,
    HOLDER_FIRST_NAME                     ,
    HOLDER_SIRET                          ,
    HOLDER_ADDRESS_NM_1                   ,
    HOLDER_ADDRESS_NM_2                   ,
    HOLDER_ADDRESS_NM_3                   ,
    HOLDER_ADDRRESS_NM_4                  ,
    HOLDER_ADDRESS_POSTAL_CD              ,
    HOLDER_CITY                           ,
    HOLDER_BANK_CD                        ,
    HOLDER_OFFICE_CD                      ,
    HOLRDER_ACCOUNT_CD                    ,
    HOLDER_RIB_KEY_CD                     ,
    HOLDER_MAIL                           ,
    CUSTOMER_CLIENT_NU_ADV                ,
    CUSTOMER_DOSSIER_NU_ADV               ,
    CUSTOMER_MARKET_SEG                   ,
    CUSTOMER_CIVILITY                     ,
    CUSTOMER_LAST_NAME_NM                 ,
    CUSTOMER_FIRST_NAME_NM                ,
    CUSTOMER_NAME_NM                      ,
    CUSTOMER_SIRET                        ,
    CUSTOMER_ADDRESS_1_NM                 ,
    CUSTOMER_ADDRESS_2_NM                 ,
    CUSTOMER_ADDRESS_3_NM                 ,
    CUSTOMER_ADDRESS_4_NM                 ,
    CUSTOMER_ADDRESS_POSTAL_CD            ,
    CUSTOMER_CITY                         ,
    CUSTOMER_CATEGORIE                    ,
    CUSTOMER_MAIL_CONTACT                 ,
    CUSTOMER_MSISDN_CONTACT               ,
    INVOICE_ADDRESS_MAIL_NM               ,
    STORE_CD                              ,
    ADV_STORE_CD                          ,
    FLAG_TYPE_PTN_NTK                     ,
    AGENT_ID                              ,
    AGENT_LAST_NAME_NM                    ,
    AGENT_FIRST_NAME_NM                   ,
    -- Enrichissement O3
    EDO_ID                                ,
    TYPE_EDO                              ,
    ORG_EDO_IOBSP                         ,
    ORG_AGENT_IOBSP                       ,
    NETWRK_TYP_EDO_ID                     ,
    FLAG_PLT_CONV                         ,
    FLAG_TEAM_MKT                         ,
    FLAG_TYPE_CMP                         ,
    FLAG_TYPE_GEO                         ,
    FLAG_TYPE_CPT_NTK                     ,
    CLOSURE_DT                            ,    
    -- Champs techniques
    QUEUE_TS                              ,
    RUN_ID                                ,
    STREAMING_TS                          ,
    CREATION_TS                           ,
    LAST_MODIF_TS                         ,
    HOT_IN                                ,
    FRESH_IN                              ,
    COHERENCE_IN                           
)
Select                                                                                                    
      Placement.ACTE_ID                                                       AS ACTE_ID                    , 
      Placement.EXTERNAL_ACTE_ID                                              AS EXTERNAL_ACTE_ID           , 
      Placement.INTRNL_SOURCE_ID                                              AS INTRNL_SOURCE_ID           ,
      Placement.CONTEXT_ID                                                    AS CONTEXT_ID                 , 
      Placement.EXTERNAL_ORDER_ID                                             AS EXTERNAL_ORDER_ID          , 
      Placement.ORDER_DEPOSIT_TS                                              AS ORDER_DEPOSIT_TS           ,
      Placement.ORDER_DEPOSIT_DT                                              AS ORDER_DEPOSIT_DT           ,
      Placement.ORDER_TYPE_CD                                                 AS ORDER_TYPE_CD              , 
      Placement.PRODUCT_TYPE                                                  AS PRODUCT_TYPE               , 
      Placement.EXTERNAL_PRODUCT_ID                                           AS EXTERNAL_PRODUCT_ID        , 
      Placement.MOUVEMENT                                                     AS MOUVEMENT                  ,
      Placement.MSISDN_PORTED                                                 AS MSISDN_PORTED              ,
      Placement.IMEI_CD                                                       AS PAR_IMEI_CD                ,
      Placement.SIM_CD                                                        AS PAR_SIM_CD                 ,
      Placement.SIM_EAN_CD                                                    AS SIM_EAN_CD                 ,
      Com.MAIN_MSISDN_ID                                                      AS MAIN_MSISDN_ID             ,
      Com.SECOND_MSISDN_ID                                                    AS SECOND_MSISDN_ID           ,
      Com.HOLDER_CIVILITY                                                     AS HOLDER_CIVILITY            ,
      Com.HOLDER_LAST_NAME                                                    AS HOLDER_LAST_NAME           ,
      Com.HOLDER_FIRST_NAME                                                   AS HOLDER_FIRST_NAME          ,
      Com.HOLDER_SIRET                                                        AS HOLDER_SIRET               ,
      Com.HOLDER_ADDRESS_NM_1                                                 AS HOLDER_ADDRESS_NM_1        ,
      Com.HOLDER_ADDRESS_NM_2                                                 AS HOLDER_ADDRESS_NM_2        ,
      Com.HOLDER_ADDRESS_NM_3                                                 AS HOLDER_ADDRESS_NM_3        ,
      Com.HOLDER_ADDRRESS_NM_4                                                AS HOLDER_ADDRRESS_NM_4       ,
      Com.HOLDER_ADDRESS_POSTAL_CD                                            AS HOLDER_ADDRESS_POSTAL_CD   ,
      Com.HOLDER_CITY                                                         AS HOLDER_CITY                ,
      Com.HOLDER_BANK_CD                                                      AS HOLDER_BANK_CD             ,
      Com.HOLDER_OFFICE_CD                                                    AS HOLDER_OFFICE_CD           ,
      Com.HOLRDER_ACCOUNT_CD                                                  AS HOLRDER_ACCOUNT_CD         ,
      Com.HOLDER_RIB_KEY_CD                                                   AS HOLDER_RIB_KEY_CD          ,
      Com.HOLDER_MAIL                                                         AS HOLDER_MAIL                ,
      Com.CUSTOMER_CLIENT_NU_ADV                                              AS CUSTOMER_CLIENT_NU_ADV     ,
      Placement.MOBILE_MSISDN_ID                                              AS CUSTOMER_DOSSIER_NU_ADV    ,
      Com.CUSTOMER_MARKET_SEG                                                 AS CUSTOMER_MARKET_SEG        ,
      Com.CUSTOMER_CIVILITY                                                   AS CUSTOMER_CIVILITY          ,
      Com.CUSTOMER_LAST_NAME_NM                                               AS CUSTOMER_LAST_NAME_NM      ,
      Com.CUSTOMER_FIRST_NAME_NM                                              AS CUSTOMER_FIRST_NAME_NM     ,
      Com.CUSTOMER_NAME_NM                                                    AS CUSTOMER_NAME_NM           ,
      Com.CUSTOMER_SIRET                                                      AS CUSTOMER_SIRET             ,
      Com.CUSTOMER_ADDRESS_1_NM                                               AS CUSTOMER_ADDRESS_1_NM      ,
      Com.CUSTOMER_ADDRESS_2_NM                                               AS CUSTOMER_ADDRESS_2_NM      ,
      Com.CUSTOMER_ADDRESS_3_NM                                               AS CUSTOMER_ADDRESS_3_NM      ,
      Com.CUSTOMER_ADDRESS_4_NM                                               AS CUSTOMER_ADDRESS_4_NM      ,
      Com.CUSTOMER_ADDRESS_POSTAL_CD                                          AS CUSTOMER_ADDRESS_POSTAL_CD ,
      Com.CUSTOMER_CITY                                                       AS CUSTOMER_CITY              ,
      Com.CUSTOMER_CATEGORIE                                                  AS CUSTOMER_CATEGORIE         ,
      Com.CUSTOMER_MAIL_CONTACT                                               AS CUSTOMER_MAIL_CONTACT      ,
      Com.CUSTOMER_MSISDN_CONTACT                                             AS CUSTOMER_MSISDN_CONTACT    ,
      Placement.INVOICE_ADDRESS_MAIL_NM                                       AS INVOICE_ADDRESS_MAIL_NM    ,
      Com.STORE_CD                                                            AS STORE_CD                   ,
      Com.ADV_STORE_CD                                                        AS ADV_STORE_CD               ,
      Coalesce(RefO3.FLAG_TYPE_PTN_NTK,RefO32.FLAG_TYPE_PTN_NTK)              AS FLAG_TYPE_PTN_NTK          , 
      Com.AGENT_ID                                                            AS AGENT_ID                   ,
      Com.AGENT_LAST_NAME_NM                                                  AS AGENT_LAST_NAME_NM         ,
      Com.AGENT_FIRST_NAME_NM                                                 AS AGENT_FIRST_NAME_NM        ,
      -- Enrichissement O3                              
      Coalesce(RefO3.EDO_ID,RefO32.EDO_ID)                                    AS EDO_ID                     ,
      Coalesce(RefO3.TYPE_EDO,RefO32.TYPE_EDO)                                AS TYPE_EDO                   ,
       Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
      End                                                                     AS ORG_EDO_IOBSP              ,
      Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
      End                                                                     AS ORG_AGENT_IOBSP            ,
      Coalesce(RefO3.NETWRK_TYP_EDO_ID,RefO32.NETWRK_TYP_EDO_ID)              AS NETWRK_TYP_EDO_ID          ,
      Coalesce(RefO3.FLAG_PLT_CONV,RefO32.FLAG_PLT_CONV)                      AS FLAG_PLT_CONV              ,
      Null                                                                    AS FLAG_TEAM_MKT              ,
      '#'                                                                     AS FLAG_TYPE_CMP              ,
      Coalesce(RefO3.FLAG_TYPE_GEO,RefO32.FLAG_TYPE_GEO)                      AS FLAG_TYPE_GEO              ,
      Coalesce(RefO3.FLAG_TYPE_CPT_NTK,RefO32.FLAG_TYPE_CPT_NTK)              AS FLAG_TYPE_CPT_NTK          ,
      Null                                                                    AS CLOSURE_DT                 ,
      -- Champs techniques                              
      Com.QUEUE_TS                                                            AS QUEUE_TS                   ,
      Com.RUN_ID                                                              AS RUN_ID                     ,
      Com.STREAMING_TS                                                        AS STREAMING_TS               ,
      Current_Timestamp(0)                                                    AS CREATION_TS                ,
      Current_Timestamp(0)                                                    AS LAST_MODIF_TS              ,
      1                                                                       AS HOT_IN                     ,
      1                                                                       AS FRESH_IN                   ,
      0                                                                       AS COHERENCE_IN                                                                                            
From  
    (
      Select *
      From ${KNB_COM_TMP}.ORD_T_ORDER_AGC_COM    
      Qualify Row_Number() Over(Partition by CONTEXT_ID Order by Queue_ts desc) = 1     
    )                                                         Com
Inner Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_AGC_MOB_H           Placement
  On  Com.CONTEXT_ID=Placement.CONTEXT_ID
Left outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR           RefO3        -- On reprend le catalogue O3 de New Shop
  On    Com.ADV_STORE_CD = RefO3.EXTNL_VAL_COD_CD
  And Placement.ORDER_DEPOSIT_DT Between RefO3.START_EXTNL_VAL_DT
    And Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
Left outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR           RefO32        -- On reprend le catalogue O3 de New Shop
  On    Com.STORE_CD = RefO32.EXTNL_VAL_COD_CD
  And Placement.ORDER_DEPOSIT_DT Between RefO32.START_EXTNL_VAL_DT
    And Coalesce(RefO32.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
   On    Coalesce(RefO3.EDO_ID,RefO32.EDO_ID)    = EdoOBK.EDO_ID
     And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
     And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN        = 1
Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
   On   Com.AGENT_ID=CuidOBK.AGENT_ID
   And  Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
  And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
-- On ne prend que le dernier contexte dans la table de commandes.
Qualify Row_Number() Over(Partition by  Placement.ACTE_ID
                          Order by      RefO3.START_EXTNL_VAL_DT Desc    ,
                                        Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD')) Desc  ,
                                        RefO32.START_EXTNL_VAL_DT Desc   ,
                                        Coalesce(RefO32.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD')) Desc
                         )=1
;                          
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_MOB_H;
.if errorcode <> 0 then .quit 1

.quit 0
