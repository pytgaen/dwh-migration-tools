-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCM_Anticip_Placement_Alim_Step1_TFBCR.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_TFINDICOM_CHO
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     GMA         Création
-- 09/04/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;

--Paramètre attendu : Les bornes de dates

--Delete des lignes
Delete From ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC
(
  ID_BCR                            ,
  DATESAISIEBCR                     ,
  DOSSIER_NU                        ,
  CLIENT_NU                         ,
  PRESFACT_CO                       ,
  USCM_CO_ADV                       ,
  USCM_CO_PCM                       ,
  NUMCATALMAIL                      ,
  CD_CANALDIST                      ,
  ADV_CO_BCR                        ,
  PDV_XI_BCR                        ,
  STATUTBCR_CO                      ,
  DUREEREENG                        ,
  TB_TYPEBCR                        ,
  NBPOINTSUTIL                      ,
  COMPLEMENT                        ,
  DATEVALIDATION                    ,
  NUMEROIMEI                        ,
  PV_POINTVENTE                     ,
  CODEVENDEUR                       ,
  ID_PROGRAMMEFID                   ,
  SEGMENTVALEURCLIENT               
)
Select 
  Brc.BCR_ID_BCR                                                                                    as ID_BCR                     ,
  Brc.BCR_DATESAISIEBCR                                                                             as DATESAISIEBCR              ,
  Coalesce(ComptPointODS.COMPTEPOINT_DOSSIER_NU,ComptPointSOC.COMPTEPOINT_DOSSIER_NU)               as DOSSIER_NU                 ,
  Coalesce(ComptPointODS.COMPTEPOINT_CLIENT_NU,ComptPointSOC.COMPTEPOINT_CLIENT_NU)                 as CLIENT_NU                  ,
  Brc.BCR_PRESFACT_CO                                                                               as PRESFACT_CO                ,
  Brc.BCR_USCM_CO_ADV                                                                               as USCM_CO_ADV                ,
  Brc.BCR_USCM_CO_PCM                                                                               as USCM_CO_PCM                ,
  Brc.BCR_NUMCATALMAIL                                                                              as NUMCATALMAIL               ,
  Brc.BCR_CD_CANALDIST                                                                              as CD_CANALDIST               ,
  Brc.BCR_ADV_CO_BCR                                                                                as ADV_CO_BCR                 ,
  Brc.BCR_PDV_XI_BCR                                                                                as PDV_XI_BCR                 ,
  Brc.BCR_STATUTBCR_CO                                                                              as STATUTBCR_CO               ,
  Brc.BCR_DUREEREENG                                                                                as DUREEREENG                 ,
  Brc.BCR_TB_TYPEBCR                                                                                as TB_TYPEBCR                 ,
  Brc.BCR_NBPOINTSUTIL                                                                              as NBPOINTSUTIL               ,
  Brc.BCR_COMPLEMENT                                                                                as COMPLEMENT                 ,
  Brc.BCR_DATEVALIDATION                                                                            as DATEVALIDATION             ,
  Brc.BCR_NUMEROIMEI                                                                                as NUMEROIMEI                 ,
  Brc.BCR_PV_POINTVENTE                                                                             as PV_POINTVENTE              ,
  Brc.BCR_CODEVENDEUR                                                                               as CODEVENDEUR                ,
  Brc.BCR_ID_PROGRAMMEFID                                                                           as ID_PROGRAMMEFID            ,
  Coalesce(Brc.BCR_SEGMENTVALEURCLIENT,'SC')                                                        as SEGMENTVALEURCLIENT        
From
  ${KNB_IBU_ODS}.V_ATP_F_BCR_PCM Brc
  Left Outer Join  ${KNB_IBU_ODS}.V_ATP_F_TFCOMPTEPOINT_PCM ComptPointODS
    On Brc.BCR_ID_DOSSIER   = ComptPointODS.COMPTEPOINT_ID_DOSSIER
  Left Outer Join  ${KNB_IBU_SOC}.V_TFCOMPTEPOINT ComptPointSOC
    On Brc.BCR_ID_DOSSIER   = ComptPointSOC.COMPTEPOINT_ID_DOSSIER
Where
  (1=1)
Qualify Row_Number() Over (Partition by Brc.BCR_ID_BCR Order by Brc.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC;
.if errorcode <> 0 then .quit 1


