-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Acte_Consolidation_Step2_CalculPerenniteVerifResiliation.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 12/08/2014      HZO         Creation
--------------------------------------------------------------------------------

.set width 2500;


Delete From ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_RESIL_PER All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindre dans le référentiel fusionné
-------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_RESIL_PER
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PAR_IMSI                    ,
  DOSSIER_TYPE_RESIL          ,
  PERNNT_IN                   ,
  PERNNT_END_DT               ,
  PERNNT_MOTIF                ,
  SEG_COM_ID_FINAL_ORDER      
)
Select 
  Acte.ACTE_ID                                                    as ACTE_ID                        ,
  Acte.INT_DEPOSIT_DT                                             as INT_DEPOSIT_DT                 ,
  Acte.PAR_IMSI                                                   as PAR_IMSI                       ,
  Placement.DOSSIER_TYPE_RESIL                                    as DOSSIER_TYPE_RESIL             ,
  'N'                                                             as PERNNT_IN                      ,
  Placement.DOSSIER_DATE_RESIL                                    as PERNNT_END_DT                  ,
  Placement.DOSSIER_MOTIF_RESIL                                   as PERNNT_MOTIF                   ,
  Acte.SEG_COM_ID_LP                                              as SEG_COM_ID_FINAL_ORDER         
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.INT_W_ACTE_CHO_EXRACT Acte
  Inner Join  ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_CHO Placement
    On    Acte.ACTE_ID                    =   Placement.ACTE_ID
      And Acte.INT_DEPOSIT_DT             =   Placement.INT_DEPOSIT_DT
  Inner Join ${KNB_PCO_SOC}.V_CAT_R_PARAM_RESIL_PER Per
    On    Placement.DOSSIER_TYPE_RESIL    =   Per.RESIL_INT_MOTIF
      And Per.PERENNITE_LOSS_FLAG         =   'Oui'
      And Per.CURRENT_IN                  =   1
      And Per.CLOSURE_DT                  Is Null
Where (1 = 1)
  And Placement.DOSSIER_DATE_RESIL <= Acte.INT_DEPOSIT_DT + 60
  And Placement.DOSSIER_DATE_RESIL >= Acte.INT_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_RESIL_PER;
.if errorcode <> 0 then .quit 1

.quit 0
