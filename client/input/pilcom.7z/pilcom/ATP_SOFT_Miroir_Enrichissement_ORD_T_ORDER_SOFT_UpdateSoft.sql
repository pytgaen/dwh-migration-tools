-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Miroir_Enrichissement_ORD_T_ORDER_SOFT_UpdateSoft.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  qui réalise la mise à jour des commandes SOFT à partir des informations calculées
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------


--Update de la table Commande Pour les attributs d'ordre:

Update RefCommande
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_COM RefCommande         ,
  ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_RECEP EnriRcp  
Set
  FLAG_FIRST_RECEPTION_COM      = EnriRcp.FLAG_FIRST_RECEPTION_COM        ,
  FLAG_FIRST_RECEPTION_COM_STAT = EnriRcp.FLAG_FIRST_RECEPTION_COM_STAT   
Where
  (1=1)
  And RefCommande.EXTERNAL_ORDER_ID = EnriRcp.EXTERNAL_ORDER_ID             
  And RefCommande.ORDER_STATUS_CD   = EnriRcp.ORDER_STATUS_CD               
  And RefCommande.STATUS_MODIF_TS   = EnriRcp.STATUS_MODIF_TS               
  And RefCommande.ORDER_DEPOSIT_DT  = EnriRcp.ORDER_DEPOSIT_DT              

--Update de l'opérateur de com pour les commande
;Update RefCommande
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_COM RefCommande         ,
  ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_OPCOM EnriOpt  
Set
  OPERATOR_PROVIDER_ID              = EnriOpt.OPERATOR_PROVIDER_ID        
Where
  (1=1)
  And RefCommande.EXTERNAL_ORDER_ID = EnriOpt.EXTERNAL_ORDER_ID           
  And RefCommande.ORDER_STATUS_CD   = EnriOpt.ORDER_STATUS_CD             
  And RefCommande.STATUS_MODIF_TS   = EnriOpt.STATUS_MODIF_TS             
  And RefCommande.ORDER_DEPOSIT_DT  = EnriOpt.ORDER_DEPOSIT_DT            

--Update de l'opérateur de com pour les commandes Mobiles
;Update RefCommandeMob
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_MOB RefCommandeMob         ,
  ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_OPCOM EnriOpt              
Set
  OPERATOR_PROVIDER_ID              = EnriOpt.OPERATOR_PROVIDER_ID        
Where
  (1=1)
  And RefCommandeMob.EXTERNAL_ORDER_ID  = EnriOpt.EXTERNAL_ORDER_ID           
  And RefCommandeMob.ORDER_STATUS_CD    = EnriOpt.ORDER_STATUS_CD             
  And RefCommandeMob.STATUS_MODIF_TS    = EnriOpt.STATUS_MODIF_TS             
  And RefCommandeMob.ORDER_DEPOSIT_DT   = EnriOpt.ORDER_DEPOSIT_DT            

--Update de l'opérateur de com pour les commandes Internet
;Update RefCommandeInt
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT RefCommandeInt      ,
  ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_OPCOM EnriOpt           
Set
  OPERATOR_PROVIDER_ID              = EnriOpt.OPERATOR_PROVIDER_ID        
Where
  (1=1)
  And RefCommandeInt.EXTERNAL_ORDER_ID  = EnriOpt.EXTERNAL_ORDER_ID           
  And RefCommandeInt.ORDER_STATUS_CD    = EnriOpt.ORDER_STATUS_CD             
  And RefCommandeInt.STATUS_MODIF_TS    = EnriOpt.STATUS_MODIF_TS             
  And RefCommandeInt.ORDER_DEPOSIT_DT   = EnriOpt.ORDER_DEPOSIT_DT            

--Update de l'opérateur de com pour les commandes PCM
;Update RefCommandePCM
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_PCM RefCommandePCM      ,
  ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_OPCOM EnriOpt           
Set
  OPERATOR_PROVIDER_ID              = EnriOpt.OPERATOR_PROVIDER_ID        
Where
  (1=1)
  And RefCommandePCM.EXTERNAL_ORDER_ID  = EnriOpt.EXTERNAL_ORDER_ID           
  And RefCommandePCM.ORDER_STATUS_CD    = EnriOpt.ORDER_STATUS_CD             
  And RefCommandePCM.STATUS_MODIF_TS    = EnriOpt.STATUS_MODIF_TS             
  And RefCommandePCM.ORDER_DEPOSIT_DT   = EnriOpt.ORDER_DEPOSIT_DT            
;
.if errorcode <> 0 then .quit 1


