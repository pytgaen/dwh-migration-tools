-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_VAD_Acte_Alimentation_Rapprochement_NewShop.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de raprochement
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 16/05/2014      MCA         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_TRC_VAD All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : recherche le traçage des actes NewShop
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_TRC_VAD
(
  ACTE_ID                            ,
  ORDER_DEPOSIT_DT                   ,
  CPLT_ACTE_ID                       ,
  CPLT_INTRL_SOURCE_ID               ,
  CPLT_EXT_INT_ID                    ,
  CPLT_ORG_AGENT_ID                  ,
  CPLT_ORG_NOM                       ,
  CPLT_ORG_PRENOM                    ,
  CPLT_ORG_STORE_NAME                ,
  CPLT_ORG_CHANNEL_CD                ,
  CPLT_ORG_SUB_CHANNEL_CD            ,
  CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
  CPLT_ORG_REM_CHANNEL_CD            ,
  CPLT_ORG_GT_ACTIVITY               ,
  CPLT_ORG_FIDELISATION              ,
  CPLT_ORG_AUTO_ACTIVITY             ,
  CPLT_ORG_WEB_ACTIVITY              ,
  CPLT_ORG_EDO_ID                    ,
  CPLT_ORG_TYPE_EDO                  ,
  CPLT_ORG_NETWRK_TYP_EDO_ID         ,
  CPLT_ORG_FLAG_PLT_CONV             ,
  CPLT_ORG_FLAG_TEAM_MKT             ,
  CPLT_ORG_FLAG_TYPE_CMP             ,
  CPLT_ORG_RESP_EDO_ID               ,
  CPLT_ORG_RESP_TYPE_EDO             ,
  CPLT_ORG_RESP_FLAG_PLT_CONV        ,
  CPLT_ORG_TEAM_LEVEL_1_CD           ,
  CPLT_ORG_TEAM_LEVEL_1_DS           ,
  CPLT_ORG_TEAM_LEVEL_2_CD           ,
  CPLT_ORG_TEAM_LEVEL_2_DS           ,
  CPLT_ORG_TEAM_LEVEL_3_CD           ,
  CPLT_ORG_TEAM_LEVEL_3_DS           ,
  CPLT_ORG_TEAM_LEVEL_4_CD           ,
  CPLT_ORG_TEAM_LEVEL_4_DS           ,
  CPLT_WORK_TEAM_LEVEL_1_CD          ,
  CPLT_WORK_TEAM_LEVEL_1_DS          ,
  CPLT_WORK_TEAM_LEVEL_2_CD          ,
  CPLT_WORK_TEAM_LEVEL_2_DS          ,
  CPLT_WORK_TEAM_LEVEL_3_CD          ,
  CPLT_WORK_TEAM_LEVEL_3_DS          ,
  CPLT_WORK_TEAM_LEVEL_4_CD          ,
  CPLT_WORK_TEAM_LEVEL_4_DS
)
Select
  ActeVAD.ACTE_ID                                           as ACTE_ID                            ,
  ActeVAD.ORDER_DEPOSIT_DT                                  as ORDER_DEPOSIT_DT                   ,
  --Identifiant de l'acte complémentaire
  ActeNewShop.ACTE_ID                                       as CPLT_ACTE_ID                       ,
  ActeNewShop.INTRNL_SOURCE_ID                              as CPLT_INTRL_SOURCE_ID               ,
  Coalesce (ActeNewShop.EXTERNAL_ORDER_ID, 1)               as CPLT_EXT_INT_ID                    ,
  ActeNewShop.ORG_AGENT_ID                                  as CPLT_ORG_AGENT_ID                  ,
  ActeNewShop.ORG_NOM                                       as CPLT_ORG_NOM                       ,
  ActeNewShop.ORG_PRENOM                                    as CPLT_ORG_PRENOM                    ,
  ActeNewShop.SHOP_COD_DS                                   as CPLT_ORG_STORE_NAME                ,
  ActeNewShop.ORG_CHANNEL_CD                                as CPLT_ORG_CHANNEL_CD                ,
  ActeNewShop.ORG_SUB_CHANNEL_CD                            as CPLT_ORG_SUB_CHANNEL_CD            ,
  ActeNewShop.ORG_SUB_SUB_CHANNEL_CD                        as CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
  ActeNewShop.ORG_REM_CHANNEL_CD                            as CPLT_ORG_REM_CHANNEL_CD            ,
  ActeNewShop.ORG_GT_ACTIVITY                               as CPLT_ORG_GT_ACTIVITY               ,
  ActeNewShop.ORG_FIDELISATION                              as CPLT_ORG_FIDELISATION              ,
  ActeNewShop.ORG_AUTO_ACTIVITY                             as CPLT_ORG_AUTO_ACTIVITY             ,
  ActeNewShop.ORG_WEB_ACTIVITY                              as CPLT_ORG_WEB_ACTIVITY              ,
  ActeNewShop.ORG_EDO_ID                                    as CPLT_ORG_EDO_ID                    ,
  ActeNewShop.ORG_TYPE_EDO                                  as CPLT_ORG_TYPE_EDO                  ,
  ActeNewShop.ORG_NETWRK_TYP_EDO_ID                         as CPLT_ORG_NETWRK_TYP_EDO_ID         ,
  ActeNewShop.ORG_FLAG_PLT_CONV                             as CPLT_ORG_FLAG_PLT_CONV             ,
  ActeNewShop.ORG_FLAG_TEAM_MKT                             as CPLT_ORG_FLAG_TEAM_MKT             ,
  ActeNewShop.ORG_FLAG_TYPE_CMP                             as CPLT_ORG_FLAG_TYPE_CMP             ,
  Null                                                      as CPLT_ORG_RESP_EDO_ID               ,
  Null                                                      as CPLT_ORG_RESP_TYPE_EDO             ,
  Null                                                      as CPLT_ORG_RESP_FLAG_PLT_CONV        ,
  Cast(ActeNewShop.ORG_TEAM_LEVEL_1_CD as Varchar(18))      as CPLT_ORG_TEAM_LEVEL_1_CD           ,
  ActeNewShop.ORG_TEAM_LEVEL_1_DS                           as CPLT_ORG_TEAM_LEVEL_1_DS           ,
  Cast(ActeNewShop.ORG_TEAM_LEVEL_2_CD as Varchar(18))      as CPLT_ORG_TEAM_LEVEL_2_CD           ,
  ActeNewShop.ORG_TEAM_LEVEL_2_DS                           as CPLT_ORG_TEAM_LEVEL_2_DS           ,
  Cast(ActeNewShop.ORG_TEAM_LEVEL_3_CD as Varchar(18))      as CPLT_ORG_TEAM_LEVEL_3_CD           ,
  ActeNewShop.ORG_TEAM_LEVEL_3_DS                           as CPLT_ORG_TEAM_LEVEL_3_DS           ,
  Cast(ActeNewShop.ORG_TEAM_LEVEL_4_CD as Varchar(18))      as CPLT_ORG_TEAM_LEVEL_4_CD           ,
  ActeNewShop.ORG_TEAM_LEVEL_4_DS                           as CPLT_ORG_TEAM_LEVEL_4_DS           ,
  Cast(ActeNewShop.WORK_TEAM_LEVEL_1_CD as Varchar(18))     as CPLT_WORK_TEAM_LEVEL_1_CD          ,
  ActeNewShop.WORK_TEAM_LEVEL_1_DS                          as CPLT_WORK_TEAM_LEVEL_1_DS          ,
  Cast(ActeNewShop.WORK_TEAM_LEVEL_2_CD as Varchar(18))     as CPLT_WORK_TEAM_LEVEL_2_CD          ,
  ActeNewShop.WORK_TEAM_LEVEL_2_DS                          as CPLT_WORK_TEAM_LEVEL_2_DS          ,
  Cast(ActeNewShop.WORK_TEAM_LEVEL_3_CD as Varchar(18))     as CPLT_WORK_TEAM_LEVEL_3_CD          ,
  ActeNewShop.WORK_TEAM_LEVEL_3_DS                          as CPLT_WORK_TEAM_LEVEL_3_DS          ,
  Cast(ActeNewShop.WORK_TEAM_LEVEL_4_CD as Varchar(18))     as CPLT_WORK_TEAM_LEVEL_4_CD          ,
  ActeNewShop.WORK_TEAM_LEVEL_4_DS                          as CPLT_WORK_TEAM_LEVEL_4_DS
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_VM}.V_ORD_F_ACTE_VAD ActeVAD
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_NEWSHOP ActeNewShop
    On  ActeVAD.ORDER_EXTERNAL_ID    = ActeNewShop.VAD_ID
    And ActeVAD.ACT_SEG_COM_ID_FINAL = ActeNewShop.ACT_SEG_COM_ID_FINAL
     -- On ne prend que ceux qui sont dans le périmètre de + ou - 3
    And ActeVAD.ORDER_DEPOSIT_DT    >= (ActeNewShop.ORDER_DEPOSIT_DT -3) 
    And ActeVAD.ORDER_DEPOSIT_DT    <= (ActeNewShop.ORDER_DEPOSIT_DT +3)
Where
  (1=1)
Qualify Row_Number() Over (Partition By ActeVAD.ACTE_ID  Order By ActeNewShop.LAST_MODIF_TS Desc) = 1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_NSH_TRC_VAD
;
.if errorcode <> 0 then .quit 1


.quit 0
