-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_DPVC_Placement_Extraction.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 07/07/2014      HZO         Creation
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_DECLAR_PVC_EXT All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ACT_W_DECLAR_PVC_EXT
(
  EXTERNAL_ACTE_ID                  ,
  TYPE_SOURCE_ID                    ,
  INTRNL_SOURCE_ID                  ,
  ACTE_ID                           ,
  ACTE_ID_EXTERNE                   ,
  ACTE_ID_CONTACTE                  ,
  ACTE_ID_DETAIL_CONTACTE           ,
  ACTE_ID_COMMANDE_REFERENCE        ,
  SOURCE_ID                         ,
  ACTE_STATUT                       ,
  ACTION_ACTE                       ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_RECEIVED_PIL_TS             ,
  ORDER_MAJ_PIL_TS                  ,
  CUID                              ,
  ORDER_STATUT                      ,
  ORDER_STATUT_TS                   ,
  SELLER_LAST_NAME                  ,
  SELLER_FIRST_NAME                 ,
  SALE_CHANNEL_DLC                  ,
  SALE_CHANNEL_ORDER                ,
  CODE_PARC_CLI                     ,
  ORIGINE_DLC_DS                    ,
  CUSTOMER_TYPE                     ,
  CUSTOMER_SEG                      ,
  CUSTOMER_LAST_NAME                ,
  CUSTOMER_FIRST_NAME               ,
  CUSTOMER_SIRET                    ,
  MISISDN                           ,
  ND                                ,
  NDIP                              ,
  CUSTOMER_CAT                      ,
  CUSTOMER_AGENCE                   ,
  CUSTOMER_ZIPCODE                  ,
  VOLUME                            ,
  VALEUR                            ,
  CA                                ,
  STATUT_CSO                        ,
  STATUT_CSO_DS                     ,
  COMMENTAIRE_DS                    ,
  TEAM_DLC_DES                      ,
  TEAM_ORDER_DES                    ,
  ACT_CD                            ,
  ACT_TYPE_COMMANDE_ID              ,
  TYPE_COMMANDE_INI                 ,
  CODE_COMMANDE_FIN                 ,
  TYPE_COMMANDE_FIN                 ,
  CODE_PRODUCT_FIN                  ,
  PRODUCT_DSC_FIN                   ,
  SEGMENT_COM_FIN                   ,
  CODE_PRODUCT_INI                  ,
  PRODUCT_DSC_INI                   ,
  SEGMENT_COM_INI                   ,
  CODE_MIGR_INI                     ,
  DSC_MIGR_INI                      ,
  CODE_MIGR_FIN                     ,
  DSC_MIGR_FIN                      ,
  ID_FREGATE                        ,
  DT_CHECK_PARC                     ,
  DT_END_PARC                       ,
  END_PARC_DSC                      ,
  TAUX_PERENNITE                    ,
  DELAIS_PERENNITE                  ,
  OSCAR_VALUE                       ,
  DUREE_ENG                         ,
  IMEI                              ,
  EAN                               ,
  SIM                               ,
  ID_PARSIFAL                       ,
  MOTIF_DLC_DS                      ,
  FILE_ID                           ,
  FRESH_TS                          ,
  FRESH_IN                          ,
  COHERENCE_IN                      ,
  RUN_ID                            
)
Select
  Trim(ID_PARSIFAL)                 As EXTERNAL_ACTE_ID                  ,
  ${IdentifiantTechniqueSource}     As TYPE_SOURCE_ID                     ,
  ${IdSourceInterne}                As INTRNL_SOURCE_ID                   ,
  ACTE_ID                           As ACTE_ID                            ,
  ACTE_ID_EXTERNE                   As ACTE_ID_EXTERNE                    ,
  ACTE_ID_CONTACTE                  As ACTE_ID_CONTACTE                   ,
  ACTE_ID_DETAIL_CONTACTE           As ACTE_ID_DETAIL_CONTACTE            ,
  ACTE_ID_COMMANDE_REFERENCE        As ACTE_ID_COMMANDE_REFERENCE         ,
  SOURCE_ID                         As SOURCE_ID                          ,
  ACTE_STATUT                       As ACTE_STATUT                        ,
  ACTION_ACTE                       As ACTION_ACTE                        ,
  CAST(CAST(CAST(CAST(CAST((CAST('1970-01-01' AS DATE) + ( CAST(ORDER_DEPOSIT_TS AS INTEGER) / 86400) (FORMAT 'YYYYMMDD' )) AS CHAR(8)) ||
      CAST (( ((  CAST(ORDER_DEPOSIT_TS AS INTEGER) MOD 86400) / 3600) (FORMAT '99')) AS CHAR(2)) || 
      CAST (( ((( CAST(ORDER_DEPOSIT_TS AS INTEGER) MOD 86400) MOD 3600) / 60) (FORMAT '99')) AS CHAR(2)) ||
      CAST (( ((( CAST(ORDER_DEPOSIT_TS AS INTEGER) MOD 86400) MOD 3600) MOD 60) (FORMAT '99')) AS CHAR(2)) AS VARCHAR(20)) AS TIMESTAMP(0) FORMAT 'YYYYMMDDHHMISS' ) At Time Zone 'Europe Central' AS VARCHAR(19)) AS TIMESTAMP(0))
                                    As ORDER_DEPOSIT_TS                   ,
  CAST(CAST(CAST(CAST(CAST((CAST('1970-01-01' AS DATE) + ( CAST(ORDER_RECEIVED_PIL_TS AS INTEGER) / 86400) (FORMAT 'YYYYMMDD' )) AS CHAR(8)) ||
      CAST (( ((  CAST(ORDER_RECEIVED_PIL_TS AS INTEGER) MOD 86400) / 3600) (FORMAT '99')) AS CHAR(2)) || 
      CAST (( ((( CAST(ORDER_RECEIVED_PIL_TS AS INTEGER) MOD 86400) MOD 3600) / 60) (FORMAT '99')) AS CHAR(2)) ||
      CAST (( ((( CAST(ORDER_RECEIVED_PIL_TS AS INTEGER) MOD 86400) MOD 3600) MOD 60) (FORMAT '99')) AS CHAR(2)) AS VARCHAR(20)) AS TIMESTAMP(0) FORMAT 'YYYYMMDDHHMISS' ) At Time Zone 'Europe Central' AS VARCHAR(19)) AS TIMESTAMP(0))
                                    As ORDER_RECEIVED_PIL_TS              ,
  CAST(CAST(CAST(CAST(CAST((CAST('1970-01-01' AS DATE) + ( CAST(ORDER_MAJ_PIL_TS AS INTEGER) / 86400) (FORMAT 'YYYYMMDD' )) AS CHAR(8)) ||
      CAST (( ((  CAST(ORDER_MAJ_PIL_TS AS INTEGER) MOD 86400) / 3600) (FORMAT '99')) AS CHAR(2)) || 
      CAST (( ((( CAST(ORDER_MAJ_PIL_TS AS INTEGER) MOD 86400) MOD 3600) / 60) (FORMAT '99')) AS CHAR(2)) ||
      CAST (( ((( CAST(ORDER_MAJ_PIL_TS AS INTEGER) MOD 86400) MOD 3600) MOD 60) (FORMAT '99')) AS CHAR(2)) AS VARCHAR(20)) AS TIMESTAMP(0) FORMAT 'YYYYMMDDHHMISS' ) At Time Zone 'Europe Central' AS VARCHAR(19)) AS TIMESTAMP(0))
                                    As ORDER_MAJ_PIL_TS                   ,
  CUID                              As CUID                               ,
  ORDER_STATUT                      As ORDER_STATUT                       ,
  Case When ORDER_STATUT_TS = 0 
          Then 
            Null
          Else 
            Cast(ORDER_STATUT_TS As TimeStamp(0) Format 'YYYYMMDDHHMISS')
  End                               As ORDER_STATUT_TS                    ,
  SELLER_LAST_NAME                  As SELLER_LAST_NAME                   ,
  SELLER_FIRST_NAME                 As SELLER_FIRST_NAME                  ,
  SALE_CHANNEL_DLC                  As SALE_CHANNEL_DLC                   ,
  SALE_CHANNEL_ORDER                As SALE_CHANNEL_ORDER                 ,
  CODE_PARC_CLI                     As CODE_PARC_CLI                      ,
  ORIGINE_DLC_DS                    As ORIGINE_DLC_DS                     ,
  CUSTOMER_TYPE                     As CUSTOMER_TYPE                      ,
  CUSTOMER_SEG                      As CUSTOMER_SEG                       ,
  CUSTOMER_LAST_NAME                As CUSTOMER_LAST_NAME                 ,
  CUSTOMER_FIRST_NAME               As CUSTOMER_FIRST_NAME                ,
  CUSTOMER_SIRET                    As CUSTOMER_SIRET                     ,
  MISISDN                           As MISISDN                            ,
  ND                                As ND                                 ,
  NDIP                              As NDIP                               ,
  CUSTOMER_CAT                      As CUSTOMER_CAT                       ,
  CUSTOMER_AGENCE                   As CUSTOMER_AGENCE                    ,
  CUSTOMER_ZIPCODE                  As CUSTOMER_ZIPCODE                   ,
  VOLUME                            As VOLUME                             ,
  VALEUR                            As VALEUR                             ,
  CA                                As CA                                 ,
  STATUT_CSO                        As STATUT_CSO                         ,
  STATUT_CSO_DS                     As STATUT_CSO_DS                      ,
  COMMENTAIRE_DS                    As COMMENTAIRE_DS                     ,
  TEAM_DLC_DES                      As TEAM_DLC_DES                       ,
  TEAM_ORDER_DES                    As TEAM_ORDER_DES                     ,
  ACT_CD                            As ACT_CD                             ,
  ACT_TYPE_COMMANDE_ID              As ACT_TYPE_COMMANDE_ID               ,
  TYPE_COMMANDE_INI                 As TYPE_COMMANDE_INI                  ,
  CODE_COMMANDE_FIN                 As CODE_COMMANDE_FIN                  ,
  TYPE_COMMANDE_FIN                 As TYPE_COMMANDE_FIN                  ,
  CODE_PRODUCT_FIN                  As CODE_PRODUCT_FIN                   ,
  PRODUCT_DSC_FIN                   As PRODUCT_DSC_FIN                    ,
  SEGMENT_COM_FIN                   As SEGMENT_COM_FIN                    ,
  CODE_PRODUCT_INI                  As CODE_PRODUCT_INI                   ,
  PRODUCT_DSC_INI                   As PRODUCT_DSC_INI                    ,
  SEGMENT_COM_INI                   As SEGMENT_COM_INI                    ,
  CODE_MIGR_INI                     As CODE_MIGR_INI                      ,
  DSC_MIGR_INI                      As DSC_MIGR_INI                       ,
  CODE_MIGR_FIN                     As CODE_MIGR_FIN                      ,
  DSC_MIGR_FIN                      As DSC_MIGR_FIN                       ,
  ID_FREGATE                        As ID_FREGATE                         ,
  DT_CHECK_PARC                     As DT_CHECK_PARC                      ,
  DT_END_PARC                       As DT_END_PARC                        ,
  END_PARC_DSC                      As END_PARC_DSC                       ,
  TAUX_PERENNITE                    As TAUX_PERENNITE                     ,
  DELAIS_PERENNITE                  As DELAIS_PERENNITE                   ,
  OSCAR_VALUE                       As OSCAR_VALUE                        ,
  DUREE_ENG                         As DUREE_ENG                          ,
  IMEI                              As IMEI                               ,
  EAN                               As EAN                                ,
  SIM                               As SIM                                ,
  ID_PARSIFAL                       As ID_PARSIFAL                        ,
  MOTIF_DLC_DS                      As MOTIF_DLC_DS                       ,
  FILE_ID                           As FILE_ID                            ,
  Cast(FRESH_TS As Timestamp(0))    As FRESH_TS                           ,
  1                                 As FRESH_IN                           ,
  1                                 As COHERENCE_IN                       ,
  Null                              As RUN_ID                             
From
  ${KNB_PCO_TMP}.ACT_W_DECLAR_PVC OdsConsom
  
Where
  (1 = 1)
;  
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_W_DECLAR_PVC_EXT;
.if errorcode <> 0 then .quit 1

.quit 0
