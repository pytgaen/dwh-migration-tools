 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ProduitOpenCat.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des produits OpenCat
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000


------------------------------------------------------------------------------------------------------
------------------ Traitement des OC 
------------------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  'Produit Externe manquant ; ( OC ) ; ( '
        ||Trim(Placement.COMPST_OFFR_ID)
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.COMPST_OFFR_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Cast(Coalesce(Placement.COMPST_OFFR_DS,'') as Varchar(250)))
  End                                                         As INFO_CD                ,
  Count(*)                                                    As VOLUME_NB              ,
  Min(Placement.ORDER_DEPOSIT_DT)                             As MIN_RECEIVED_DT        ,
  Max(Placement.ORDER_DEPOSIT_DT)                             As MAX_RECEIVED_DT        
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_INT Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OPENCAT Catalogue
    On  Placement.COMPST_OFFR_ID        = Catalogue.COMPST_OFFR_ID
    And Catalogue.ATOMIC_OFFR_ID        Is Null
    And Catalogue.FUNCTN_ID             Is Null
    And Catalogue.FUNCTN_VALUE_ID       Is Null
    And Catalogue.CURRENT_IN            = 1
    And Catalogue.CLOSURE_DT            Is Null
    And Catalogue.PERIODE_ID            =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Placement.TYPE_PRODUCT            = 'OC'
  And Catalogue.COMPST_OFFR_ID          Is Null
  And Placement.ORDER_DEPOSIT_DT        >= Current_date -30
Group by 
  ERROR_CD              ,
  INFO_CD
;
.if errorcode <> 0 Then .quit 1


------------------------------------------------------------------------------------------------------
------------------ Traitement des OA 
------------------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  'Produit Externe manquant ; ( OC , OA ) ; ( '
        ||Trim(Placement.COMPST_OFFR_ID)
        ||' , '
        ||Trim(Placement.ATOMIC_OFFR_ID)
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.COMPST_OFFR_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.COMPST_OFFR_DS,''))
          ||' - '
          ||Trim(Coalesce(Placement.ATOMIC_OFFR_DS,''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  (
    Select
      Placement.COMPST_OFFR_ID                  As COMPST_OFFR_ID     ,
      Placement.COMPST_OFFR_DS                  As COMPST_OFFR_DS     ,
      Placement.ATOMIC_OFFR_ID                  As ATOMIC_OFFR_ID     ,
      Placement.ATOMIC_OFFR_DS                  As ATOMIC_OFFR_DS     ,
      Count(*)                                  As VolumeCas          ,
      Min(Placement.ORDER_DEPOSIT_DT)           As DateMinRecue       ,
      Max(Placement.ORDER_DEPOSIT_DT)           As DateMaxRecue       
    From
      ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_INT Placement
    Where
      (1=1)
      And Placement.TYPE_PRODUCT            = 'OA'
      And Placement.ORDER_DEPOSIT_DT        >= Current_date -30
    Group by
      Placement.COMPST_OFFR_ID        ,
      Placement.COMPST_OFFR_DS        ,
      Placement.ATOMIC_OFFR_ID        ,
      Placement.ATOMIC_OFFR_DS        
  ) Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OPENCAT Catalogue
    On  Placement.COMPST_OFFR_ID        = Catalogue.COMPST_OFFR_ID
    And Placement.ATOMIC_OFFR_ID        = Catalogue.ATOMIC_OFFR_ID
    And Catalogue.FUNCTN_ID             Is Null
    And Catalogue.FUNCTN_VALUE_ID       Is Null
    And Catalogue.CURRENT_IN            = 1
    And Catalogue.CLOSURE_DT            Is Null
    And Catalogue.PERIODE_ID            =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Catalogue.COMPST_OFFR_ID          Is Null
;
.if errorcode <> 0 Then .quit 1


------------------------------------------------------------------------------------------------------
------------------ Traitement des F/VF
------------------------------------------------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_REFCOM_OPENCAT_VF (
  COMPST_OFFR_ID              Varchar(20)         Not Null  ,
  ATOMIC_OFFR_ID              Varchar(20)         Not Null  ,
  FUNCTN_ID                   Varchar(20)         Not Null  ,
  FUNCTN_VALUE_ID             Varchar(100)        Not Null  
)
Primary Index (
  COMPST_OFFR_ID    ,
  ATOMIC_OFFR_ID    ,
  FUNCTN_ID         ,
  FUNCTN_VALUE_ID   
)
On Commit Preserve Rows
;

Insert Into ${KNB_TERADATA_USER}.ORD_V_REFCOM_OPENCAT_VF
(
  COMPST_OFFR_ID    ,
  ATOMIC_OFFR_ID    ,
  FUNCTN_ID         ,
  FUNCTN_VALUE_ID   
)
Select
  COMPST_OFFR_ID                  As COMPST_OFFR_ID     ,
  ATOMIC_OFFR_ID                  As ATOMIC_OFFR_ID     ,
  FUNCTN_ID                       As FUNCTN_ID          ,
  Coalesce(FUNCTN_VALUE_ID,'-1')  As FUNCTN_VALUE_ID    
From
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_OPENCAT
Where
  (1=1)
  And FUNCTN_ID       Is Not Null
  And CURRENT_IN      = 1
  And CLOSURE_DT      Is Null
  And PERIODE_ID      =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
;
.if errorcode <> 0 Then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.ORD_V_REFCOM_OPENCAT_VF Column(COMPST_OFFR_ID,ATOMIC_OFFR_ID,FUNCTN_ID,FUNCTN_VALUE_ID);
.if errorcode <> 0 Then .quit 1







Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_SOFT_VF(
  COMPST_OFFR_ID              Varchar(20)         Not Null  ,
  COMPST_OFFR_DS              Varchar(100)                  ,
  ATOMIC_OFFR_ID              Varchar(20)         Not Null  ,
  ATOMIC_OFFR_DS              Varchar(100)                  ,
  FUNCTN_ID                   Varchar(20)         Not Null  ,
  FUNCTN_DS                   Varchar(100)                  ,
  FUNCTN_VALUE_ID             Varchar(100)        Not Null  ,
  FUNCTN_VALUE_DS             Varchar(100)                  ,
  VOLUMECAS                   Integer                       ,
  DATEMINRECUE                Date Format 'YYYYMMDD'        ,
  DATEMAXRECUE                Date Format 'YYYYMMDD'        
)
Primary Index (
  COMPST_OFFR_ID    ,
  ATOMIC_OFFR_ID    ,
  FUNCTN_ID         ,
  FUNCTN_VALUE_ID   
)
On Commit Preserve Rows
;
.if errorcode <> 0 Then .quit 1



Insert Into ${KNB_TERADATA_USER}.ORD_V_SOFT_VF
(
  COMPST_OFFR_ID              ,
  COMPST_OFFR_DS              ,
  ATOMIC_OFFR_ID              ,
  ATOMIC_OFFR_DS              ,
  FUNCTN_ID                   ,
  FUNCTN_DS                   ,
  FUNCTN_VALUE_ID             ,
  FUNCTN_VALUE_DS             ,
  VOLUMECAS                   ,
  DATEMINRECUE                ,
  DATEMAXRECUE                
)
Select
  Placement.COMPST_OFFR_ID                  As COMPST_OFFR_ID     ,
  Placement.COMPST_OFFR_DS                  As COMPST_OFFR_DS     ,
  Placement.ATOMIC_OFFR_ID                  As ATOMIC_OFFR_ID     ,
  Placement.ATOMIC_OFFR_DS                  As ATOMIC_OFFR_DS     ,
  Placement.FUNCTN_ID                       As FUNCTN_ID          ,
  Placement.FUNCTN_DS                       As FUNCTN_DS          ,
  Coalesce(Placement.FUNCTN_VALUE_ID,'-1')  As FUNCTN_VALUE_ID    ,
  Placement.FUNCTN_VALUE_DS                 As FUNCTN_VALUE_DS    ,
  Count(*)                                  As VolumeCas          ,
  Min(Placement.ORDER_DEPOSIT_DT)           As DateMinRecue       ,
  Max(Placement.ORDER_DEPOSIT_DT)           As DateMaxRecue       
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_INT Placement
Where
  (1=1)
  And Placement.TYPE_PRODUCT            = 'FVF'
  And Placement.ORDER_DEPOSIT_DT        >= Current_date -30
  -- On exclu des cas d'erreur de saisie :
  And Not ( Placement.FUNCTN_ID in ('FONC50000000014','FONC50000000012','Fonc00000000334','FONC50000000015','Fonc00000000336') And SubStr(Placement.FUNCTN_VALUE_ID,1,2)='vf')
Group by
  Placement.COMPST_OFFR_ID                    ,
  Placement.COMPST_OFFR_DS                    ,
  Placement.ATOMIC_OFFR_ID                    ,
  Placement.ATOMIC_OFFR_DS                    ,
  Placement.FUNCTN_ID                         ,
  Placement.FUNCTN_DS                         ,
  Coalesce(Placement.FUNCTN_VALUE_ID,'-1')    ,
  Placement.FUNCTN_VALUE_DS                   
;
.if errorcode <> 0 Then .quit 1


Collect Stat On ${KNB_TERADATA_USER}.ORD_V_SOFT_VF Column(COMPST_OFFR_ID,ATOMIC_OFFR_ID,FUNCTN_ID,FUNCTN_VALUE_ID);
.if errorcode <> 0 Then .quit 1

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'OPENCAT'                                                     As CATALOG_ID             ,
  'Produit Externe manquant ; ( OC , OA , F '
        ||Case  When Placement.FUNCTN_VALUE_ID Is Null
                  Then  ') ; ( '
                Else    ' , VF ) ; ( '
          End
        ||Trim(Placement.COMPST_OFFR_ID)
        ||' , '
        ||Trim(Placement.ATOMIC_OFFR_ID)
        ||' , '
        ||Trim(Placement.FUNCTN_ID)
        ||Case  When Placement.FUNCTN_VALUE_ID Is Null
                  Then ''
                Else ' , '||Trim(Placement.FUNCTN_VALUE_ID)
          End
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.COMPST_OFFR_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.COMPST_OFFR_DS,''))
          ||' - '
          ||Trim(Coalesce(Placement.ATOMIC_OFFR_DS,''))
          ||' - '
          ||Trim(Coalesce(Placement.FUNCTN_DS,''))
          ||Trim(Coalesce(' - '||Trim(Placement.FUNCTN_VALUE_DS),''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  ${KNB_TERADATA_USER}.ORD_V_SOFT_VF Placement
  Left Outer Join ${KNB_TERADATA_USER}.ORD_V_REFCOM_OPENCAT_VF Catalogue
    On    Placement.COMPST_OFFR_ID                        = Catalogue.COMPST_OFFR_ID
      And Placement.ATOMIC_OFFR_ID                        = Catalogue.ATOMIC_OFFR_ID
      And Placement.FUNCTN_ID                             = Catalogue.FUNCTN_ID
      And Coalesce(Placement.FUNCTN_VALUE_ID,'-1')        = Coalesce(Catalogue.FUNCTN_VALUE_ID,'-1')
Where
  (1=1)
  And Catalogue.COMPST_OFFR_ID          Is Null
;
.if errorcode <> 0 Then .quit 1

-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1


.quit 0
