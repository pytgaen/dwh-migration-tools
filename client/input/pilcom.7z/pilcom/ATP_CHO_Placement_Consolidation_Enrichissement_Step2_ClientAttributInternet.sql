-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_Enrichissement_Step2_ClientAttributInternet.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;




Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_AT_INT All;
.if errorcode <> 0 then .quit 1

-----------------------------------------------------------
-- Calcul des Attributs Internet du client
-----------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_AT_INT
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  PAR_AID                   ,
  PAR_ND                    
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT         ,
  --Récupération de l'AID (id Bss du client) :
  Max (
        Case  When TfServTech.SRVTECH_CO_SERVBASE='${P_PIL_060}'
                Then Substr(Trim(TfServTech.SRVTECH_NU_TEL),2,Character_Length(TfServTech.SRVTECH_NU_TEL)-1)
              Else Null
        End
      )                                     as PAR_AID                ,
  --Récupération du ND :
  Max (
        Case  When  TfServTech.SRVTECH_CO_SERVBASE='${P_PIL_061}'
                Then Trim(TfServTech.SRVTECH_NU_TEL)
              Else Null
        End
      )                                     as PAR_ND                
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 RefId
  Inner Join ${KNB_IBU_SOC}.V_TFSRVTECH TfServTech
    On    RefId.CLIENT_NU                             =   TfServTech.SRVTECH_CLIENT_NU
      And RefId.DOSSIER_NU                            =   TfServTech.SRVTECH_DOSSIER_NU
Where
  (1=1)
  And ( RefId.PAR_AID Is Null Or RefId.PAR_ND Is null)
  And TfServTech.SRVTECH_CO_SERVBASE  In ('${P_PIL_060}','${P_PIL_061}')
  And TfServTech.SRVTECH_PLTF_CO      Not In ('${P_PIL_062}','${P_PIL_063}')
  And TfServTech.SRVTECH_IN_SRV_ACTIF = '${P_PIL_064}'
Group By
  RefId.ACTE_ID           ,
  RefId.INT_DEPOSIT_DT    
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_AT_INT;
.if errorcode <> 0 then .quit 1




.quit 0



