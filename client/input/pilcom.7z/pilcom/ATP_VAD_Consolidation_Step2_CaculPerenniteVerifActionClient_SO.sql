-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_VAD_Consolidation_Step2_CaculPerenniteVerifActionClient_SO.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 04/07/2014      HFO         Creation
-- 22/08/2014       GMA         Modification affectation date effet en cas actionclient=datesaisie
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.INT_W_ACTE_VAD_CHECK_ACTCLI_SO All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.INT_W_ACTE_VAD_CHECK_ACTCLI_SO
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PERNNT_IN                   ,
  PERNNT_END_DT               ,
  PERNNT_MOTIF                ,
  ORDAGD_DT_CANCEL            ,
  SEG_COM_ID_FINAL_ORDER      ,
  SEG_FINAL_ORDER_DT          ,
  SEG_FINAL_ORDER_CANCEL_DT   
)
Select
  Acte.ACTE_ID                                                    as ACTE_ID                        ,
  Acte.DATE_SAISIE                                             as INT_DEPOSIT_DT                 ,
  --On applique la règle : s'il résilie avec une date de résiliation programmée inférieur à la date de commande plus 60 jours
  Case  When  (Acte.DATE_SAISIE = RefAgend.ORDAGD_DEMANDE_DT  And RefAgend.ORDAGD_DT_EFFET <= Acte.DATE_SAISIE + 60)
          Then  'N'
        -- si la date de résiliation programmée est supérieur date de commande plus 60 jours alors on reste pérenne
        When Acte.DATE_SAISIE = RefAgend.ORDAGD_DEMANDE_DT
          Then  'O'
        Else    'N'
  End                                                             as PERNNT_IN                      ,
  Case  When  (Acte.DATE_SAISIE = RefAgend.ORDAGD_DEMANDE_DT  And RefAgend.ORDAGD_DT_EFFET <= Acte.DATE_SAISIE + 60)
          Then  RefAgend.ORDAGD_DT_EFFET
        -- si la date de résiliation programmée est supérieur date de commande plus 60 jours alors on reste pérenne
        When Acte.DATE_SAISIE = RefAgend.ORDAGD_DEMANDE_DT
          Then  Null
        Else    RefAgend.ORDAGD_DEMANDE_DT
  End                                                             as PERNNT_END_DT                  ,
  Case  When  (Acte.DATE_SAISIE = RefAgend.ORDAGD_DEMANDE_DT  And RefAgend.ORDAGD_DT_EFFET <= Acte.DATE_SAISIE + 60)
          Then  'Résiliation'
        -- si la date de résiliation programmée est supérieur date de commande plus 60 jours alors on reste pérenne
        When Acte.DATE_SAISIE = RefAgend.ORDAGD_DEMANDE_DT
          Then  Null
        Else    'Résiliation'
  End                                                             As PERNNT_MOTIF                  ,
  Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET)     as ORDAGD_DT_CANCEL               ,
  Null                                                            as SEG_COM_ID_FINAL_ORDER         ,
  RefAgend.ORDAGD_DEMANDE_DT                                      as SEG_FINAL_ORDER_DT             ,
  Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET)     as SEG_FINAL_ORDER_CANCEL_DT      
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.COM_T_PRENRI_ACTE_VAD Acte
  Inner Join  ${KNB_PCO_TMP}.ORD_W_AGENDE_SEG_REFCOM_DB RefAgend
    On    Acte.PAR_IMSI                 =   RefAgend.DOSSIER_NU_IMSI
      And Acte.SEG_COM_ID               =   RefAgend.SEG_COM_ID
      And Acte.DATE_SAISIE              <=  RefAgend.ORDAGD_DEMANDE_DT
      And RefAgend.ORDAGD_DEMANDE_DT    <=  (Acte.DATE_SAISIE + 60)
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  --And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID          Not In ('NS','OPTTECH','OPT_INC')
  And Acte.TYPE_PRODUIT             in ('SO')
  And Acte.PAR_IMSI               Is Not Null
  -- On filtre les ordres annulé
  And RefAgend.ORDAGD_ETAT        Not In ('K')
  --On recherche les annulation :
  And RefAgend.ORDAGD_OPE         In ('S')
  And Acte.DATE_SAISIE < current_date -90
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order by Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET) Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_VAD_CHECK_ACTCLI_SO;
.if errorcode <> 0 then .quit 1




.quit 0


