-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_Referentiel_Alimentation_PSF_REFCOM_FVF_Step3_CalculPerennite.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/04/2014      HFO         Creation
-- 23/01/2015      HFO         Mise en norme suite Patch  G13R00C22P01 correction Post MEP S052015
-- 02/07/2015       GMA         Modification Pour ajouter le Delete Insert En MS
--------------------------------------------------------------------------------

.set width 2500;


CREATE VOLATILE TABLE ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF
(
  ORDR_ID                           BIGINT                                   NOT NULL      ,
  TYPE_ORDR_CD                      VARCHAR(4)                                             ,
  STAT_MVT                          VARCHAR(2)                                             ,
  COMPST_OFFR_ID                    VARCHAR(13)                                            ,
  ATOMIC_OFFR_ID                    VARCHAR(60)                                            ,
  FUNCTN_ID                         VARCHAR(15)                                            ,
  FUNCTN_VALUE_ID                   VARCHAR(18)                                            ,
  ORDR_DT                           DATE FORMAT 'YYYY/MM/DD'                               ,
  ACCES_SERVICE_ID                  BIGINT                                                 ,
  PRODUCT_TYPE                      VARCHAR(4)                                             ,
  INST_PROD_DT                      DATE FORMAT 'YYYY/MM/DD'                               ,
  START_DT                          DATE FORMAT 'YYYY/MM/DD'                               ,
  END_DT                            DATE FORMAT 'YYYY/MM/DD'                                
)
PRIMARY INDEX ( ORDR_ID,COMPST_OFFR_ID, ATOMIC_OFFR_ID,FUNCTN_ID,FUNCTN_VALUE_ID ) 
ON COMMIT PRESERVE ROWS
;
.if errorcode <> 0 then .quit 1

--Cas 1 : Cas des 'CHG','ADD','RMV','INI' 
Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF
(
  ORDR_ID                 ,
  TYPE_ORDR_CD            ,
  STAT_MVT                ,
  COMPST_OFFR_ID          ,
  ATOMIC_OFFR_ID          ,
  FUNCTN_ID               ,
  FUNCTN_VALUE_ID         ,
  ORDR_DT                 ,
  ACCES_SERVICE_ID        ,
  PRODUCT_TYPE            ,
  INST_PROD_DT            ,
  START_DT                ,
  END_DT                   
)

Select
  Cmd.ORDR_ID                                                                   As ORDR_ID                ,
  --On Traite les Cas particuliers des CHG et INI, Les autres cas ne changent pas
  Case  When CmdLc.ORDR_LINE_ACT_CD ='CHG'
          Then 
            Case  When CmdLc.ATTR_ITEM_RPS_PREV_ID Is Not Null And (CmdLc.ATTR_ITEM_RPS_PREV_ID<>CmdLc.ATTR_ITEM_RPS_ID)
                    Then 'A'
                  When Cmd.OLD_COMPST_OFFR_RPS_ID Is not Null
                    Then 'A'
                  Else 'M'
            End
        When CmdLc.ORDR_LINE_ACT_CD ='INI' 
          Then 
            Case  When Cmd.OLD_COMPST_OFFR_RPS_ID Is not Null Or (CmdLc.ATTR_ITEM_RPS_PREV_ID Is Not Null And (CmdLc.ATTR_ITEM_RPS_PREV_ID<>CmdLc.ATTR_ITEM_RPS_ID))
                    Then 'A'
                  Else 'M'
            End
        When CmdLc.ORDR_LINE_ACT_CD ='ADD'
          Then 'A'
        When CmdLc.ORDR_LINE_ACT_CD ='RMV'
          Then 'S'
        Else CmdLc.ORDR_LINE_ACT_CD
  End                                                                           As TYPE_ORDR_CD           ,
  --Calcul du mouvement
  Cmd.STATT_CD                                                                  As STAT_MVT               ,
  Case  When CmdLc.ORDR_LINE_ACT_CD = 'RMV' And Cmd.OLD_COMPST_OFFR_RPS_ID Is Not Null
          Then Cmd.OLD_COMPST_OFFR_RPS_ID
        Else Cmd.COMPST_OFFR_RPS_ID
  End                                                                           As COMPST_OFFR_ID         ,
  CmdLc.PRODUCT_ID_RPS                                                          As ATOMIC_OFFR_ID         ,
  CmdLc.ATTRIBUTE_RPS_ID                                                        As FUNCTN_ID              ,
  CmdLc.ATTR_ITEM_RPS_ID                                                        As FUNCTN_VALUE_ID        ,
  Cmd.ORDR_DT                                                                   As ORDR_DT                ,
  Cmd.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID       ,
  'FVF'                                                                         As PRODUCT_TYPE           ,
  CmdLc.INST_PROD_DT                                                            As INST_PROD_DT           ,
  CmdLc.START_DT                                                                As START_DT               ,
  CmdLc.END_DT                                                                  As END_DT                  
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD  Cmd 
    Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD  CmdLc 
    On Cmd.Ordr_id=CmdLc.Ordr_id
  Where
    (1=1)
    And CmdLc.ORDR_LINE_ACT_CD in ('CHG','ADD','RMV','INI')

  -- Cas 2 : Gestion des cas changement et maintien avec une ancienne valeur de fonction non null
;Insert into ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF
(
  ORDR_ID                 ,
  TYPE_ORDR_CD            ,
  STAT_MVT                ,
  COMPST_OFFR_ID          ,
  ATOMIC_OFFR_ID          ,
  FUNCTN_ID               ,
  FUNCTN_VALUE_ID         ,
  ORDR_DT                 ,
  ACCES_SERVICE_ID        ,
  PRODUCT_TYPE            ,
  INST_PROD_DT            ,
  START_DT                ,
  END_DT                  
)

Select
  Cmd.ORDR_ID                                                                   As ORDR_ID                ,
  --Si ancienne OC non null et commande de type MIG alors on a un Ajout
  --ATTR_ITEM_PREV_ID
  'S'                                                                           As TYPE_ORDR_CD           ,
  --Calcul du mouvement
  Cmd.STATT_CD                                                                  As STAT_MVT               ,
  Case  When Cmd.OLD_COMPST_OFFR_RPS_ID Is Not Null
          Then Cmd.OLD_COMPST_OFFR_RPS_ID
        Else Cmd.COMPST_OFFR_RPS_ID
  End                                                                           As COMPST_OFFR_ID         ,
  CmdLc.PRODUCT_ID_RPS                                                          As ATOMIC_OFFR_ID,
  CmdLc.ATTRIBUTE_RPS_ID                                                        As FUNCTN_ID,
  CmdLc.ATTR_ITEM_RPS_PREV_ID                                                   As FUNCTN_VALUE_ID,
  Cmd.ORDR_DT                                                                   As ORDR_DT                ,
  Cmd.ACCES_SERVICE_ID                                                          As ACCES_SERVICE_ID       ,
  'FVF'                                                                         As PRODUCT_TYPE           ,
  CmdLc.INST_PROD_DT                                                            As INST_PROD_DT           ,
  CmdLc.START_DT                                                                As START_DT               ,
  CmdLc.END_DT                                                                  As END_DT
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD  Cmd 
    Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD CmdLc 
    On Cmd.Ordr_id=CmdLc.Ordr_id
  Where
    (1=1)
    And CmdLc.ORDR_LINE_ACT_CD in ('CHG','INI')
    And CmdLc.ATTR_ITEM_RPS_PREV_ID Is Not Null
;
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF column (FUNCTN_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF column (FUNCTN_VALUE_ID) ;
.if errorcode <> 0 then .quit 1


CREATE Volatile TABLE ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF
(
  ACCES_SERVICE_ID                                      BIGINT                    ,
  ORDR_ID                                NOT NULL       BIGINT                    ,
  COMPST_OFFR_ID                         NOT NULL       VARCHAR(13)               ,
  ATOMIC_OFFR_ID                         NOT NULL      VARCHAR(60)                ,
  FUNCTN_ID                                             VARCHAR(15)               ,
  FUNCTN_VALUE_ID                                       VARCHAR(18)               ,
  SEG_COM_ID                                            VARCHAR(64)               ,
  TYPE_SERVICE                                          VARCHAR(20)               ,
  TYPE_ORDR_CD                                          VARCHAR(4)                ,
  STAT_MVT                                              VARCHAR(2)                ,
  PRODUCT_TYPE                                          VARCHAR(4)                ,
  START_COMM_DT                                         DATE FORMAT 'YYYY/MM/DD'  ,
  END_COMM_DT                                           DATE FORMAT 'YYYY/MM/DD'  ,
  INST_PROD_DT                                          DATE FORMAT 'YYYY/MM/DD'  ,
  START_DT                                              DATE FORMAT 'YYYY/MM/DD'  ,
  END_DT                                                DATE FORMAT 'YYYY/MM/DD'  ,
  ORDR_DT                                               DATE FORMAT 'YYYY/MM/DD'   
)
PRIMARY INDEX ( ORDR_ID, COMPST_OFFR_ID , ATOMIC_OFFR_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


Insert Into  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF
( 
  ACCES_SERVICE_ID                     ,
  ORDR_ID                              ,
  COMPST_OFFR_ID                       ,
  ATOMIC_OFFR_ID                       ,
  FUNCTN_ID                            ,
  FUNCTN_VALUE_ID                      ,
  SEG_COM_ID                           ,
  TYPE_SERVICE                         ,
  TYPE_ORDR_CD                         ,
  STAT_MVT                             ,
  PRODUCT_TYPE                         ,
  START_COMM_DT                        ,
  END_COMM_DT                          ,
  INST_PROD_DT                         ,
  START_DT                             ,
  END_DT                               ,
  ORDR_DT                               
)
  
  Select
  CmdFVF.ACCES_SERVICE_ID                                                               As ACCES_SERVICE_ID  ,
  CmdFVF.ORDR_ID                                                                        As ORDR_ID           ,
  RefCatalogue.COMPST_OFFR_ID                                                           As COMPST_OFFR_ID     ,
  RefCatalogue.ATOMIC_OFFR_ID                                                           As ATOMIC_OFFR_ID     ,
  RefCatalogue.FUNCTN_ID                                                                As FUNCTN_ID          ,
  RefCatalogue.FUNCTN_VALUE_ID                                                          As FUNCTN_VALUE_ID    ,
  RefCatalogue.SEG_COM_ID                                                               As SEG_COM_ID         ,
  RefCatalogue.TYPE_SERVICE                                                             As TYPE_SERVICE       ,
  CmdFVF.TYPE_ORDR_CD                                                                   As TYPE_ORDR_CD       ,
  CmdFVF.STAT_MVT                                                                       As STAT_MVT           ,
  CmdFVF.PRODUCT_TYPE                                                                   As PRODUCT_TYPE       ,
  RefCatalogue.START_COMM_DT                                                            As START_COMM_DT      ,
  RefCatalogue.END_COMM_DT                                                              As END_COMM_DT        ,
  CmdFVF.INST_PROD_DT                                                                   As INST_PROD_DT       ,
  CmdFVF.START_DT                                                                       As START_DT           ,
  CmdFVF.END_DT                                                                         As END_DT             ,
  CmdFVF.ORDR_DT                                                                        As ORDR_DT              
From
  ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF CmdFVF
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_GEN_INT_CAT_RPS RefCatalogue
      On    CmdFVF.COMPST_OFFR_ID = RefCatalogue.COMPST_OFFR_ID
      And  CmdFVF.ATOMIC_OFFR_ID = RefCatalogue.ATOMIC_OFFR_ID
      --And RefCatalogue.ATOMIC_OFFR_ID= '-1'
       And RefCatalogue.FUNCTN_ID= CmdFVF.FUNCTN_ID
       And RefCatalogue.FUNCTN_VALUE_ID= CmdFVF.FUNCTN_VALUE_ID
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1

 Delete from  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Where TYPE_ORDR_CD = 'M';
.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Column(COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1

CREATE Volatile TABLE ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS
(
  ORDR_ID                                NOT NULL       BIGINT            ,
  COMPST_OFFR_ID                         NOT NULL       VARCHAR(13)       ,
  ATOMIC_OFFR_ID                         NOT NULL       VARCHAR(60)       ,
  FUNCTN_ID                                             VARCHAR(15)       ,
  FUNCTN_VALUE_ID                                       VARCHAR(15)       ,
  SEG_COM_ID                                            VARCHAR(64)        
)
PRIMARY INDEX ( ORDR_ID, COMPST_OFFR_ID, ATOMIC_OFFR_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS
(
  ORDR_ID                 ,
  COMPST_OFFR_ID          ,
  ATOMIC_OFFR_ID          ,
  FUNCTN_ID               ,
  FUNCTN_VALUE_ID         ,
  SEG_COM_ID              
)
Select
  Distinct
  ORDR_ID               ,
  COMPST_OFFR_ID        ,
  ATOMIC_OFFR_ID        ,
  FUNCTN_ID             ,
  FUNCTN_VALUE_ID       ,
  SEG_COM_ID             
From
   ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF CmdFVF
Where 
  CmdFVF.TYPE_ORDR_CD In ('A','S')
Qualify count(*) over (partition by   CmdFVF.ORDR_ID, CmdFVF.SEG_COM_ID  )>1
;

.if errorcode <> 0 then .quit 1

Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS column (COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1


Delete
From
  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF  Tab1
Where
  exists
  (
    Select
    1
    From
      ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS  Tab2
    Where
      (1=1)
      And Tab1.ORDR_ID=Tab2.ORDR_ID
      And Tab1.SEG_COM_ID=Tab2.SEG_COM_ID
  )
;
.if errorcode <> 0 then .quit 1



Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF column (ORDR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Column(COMPST_OFFR_ID) ;
.if errorcode <> 0 then .quit 1
Collect stat ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF Column (ATOMIC_OFFR_ID) ;
.if errorcode <> 0 then .quit 1





Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM;
.if errorcode <> 0 then .quit 1
Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE;
.if errorcode <> 0 then .quit 1

--Insertion dans le référentiel
Delete From ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE Where PRODUCT_TYPE='FVF';
;Insert Into ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE
(
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
)
Select
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
From ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF RefeFVF
Where
  (1=1)
  And RefeFVF.TYPE_SERVICE in (${L_PIL_018})
  --And RefeFVF.TYPE_SERVICE in ('OFFCONV', 'OFFINT', 'ACCRTC')
  --A Supp
  And RefeFVF.SEG_COM_ID   Not Like 'RTC%'
;
.if errorcode <> 0 then .quit 1

Delete From  ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM Where PRODUCT_TYPE='FVF'
;Insert Into ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM
(
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
)
Select
  ACCES_SERVICE_ID                       ,
  ORDR_ID                                ,
  SEG_COM_ID                             ,
  TYPE_SERVICE                           ,
  TYPE_ORDR_CD                           ,
  STAT_MVT                               ,
  PRODUCT_TYPE                           ,
  START_COMM_DT                          ,
  END_COMM_DT                            ,
  INST_PROD_DT                           ,
  START_DT                               ,
  END_DT                                 ,
  ORDR_DT                                
From
  ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF
;
.if errorcode <> 0 then .quit 1



Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM;
.if errorcode <> 0 then .quit 1
Collect Stats On ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE;
.if errorcode <> 0 then .quit 1
-- Vidage les tables 

Delete From ${KNB_TERADATA_USER}.ORD_V_PLACEMENT_ORDR_PCA_FVF All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_TERADATA_USER}.ORD_V_ORDRE_PSF_REFCOM_FVF All;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_TERADATA_USER}.ORD_V_ACTE_SOFT_INT_COM_FVF_AS All;
.if errorcode <> 0 then .quit 1
