-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_MD2_Acte_Hot_CalculDelta_Jour.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de ²
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 01/09/2014      MDE         Creation
-- 12/01/2016      MDE         Modif : Ecol Calcul CA
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.INT_W_ACTE_CHOH_EXRACT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_CHOH_EXRACT
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  TYPE_COMMANDE             ,
  TYPE_OT_SO                ,
  PRODUCT_ID_PRE            ,
  TARIF_HT_PRE              ,
  SEG_COM_ID_PRE            ,
  SEG_COM_AGG_ID_PRE        ,
  CODE_MIGRATION_PRE        ,
  PRESFACT_CO_OFFRE_OPT_ACQ ,
  PRODUCT_ID                ,
  TARIF_HT                  ,
  SEG_COM_ID                ,
  SEG_COM_AGG_ID            ,
  TYPE_SERVICE              ,
  CODE_MIGRATION            ,
  MIGRATION_REGROUPEMENT_ID ,
  MIGRATION_POSSIBLE        ,
  PERIODE_ID                ,
  CLIENT_NU                 ,
  CLIENT_NU_NEW_PORTE       ,
  DOSSIER_NU                ,
  DOSSIER_NU_NEW_PORTE      ,
  PAR_IMSI                  ,
  DOSSIER_DATE_RESIL        ,
  DMC_LINE_ID               ,
  INB_PRESFACT_ACQ_ADV      ,
  INB_PRESFACT_ACQ_AGAP     ,
  PARC_DT_DEBUT             ,
  PARC_DT_FIN               ,
  ORDAGD_DT_CONF            ,
  IN_CLIDOS                 ,
  SEG_COM_ID_LP             ,
  TYPE_SERVICE_LP           
)
Select
  --Récupération de la clé
  Placement.ACTE_ID                                           as ACTE_ID                  ,
  Placement.INT_DEPOSIT_DT                                    as INT_DEPOSIT_DT           ,
  --Attribut De la commande
  Placement.TYPE_COMMANDE                                     as TYPE_COMMANDE            ,
  Placement.TYPE_OT_SO                                        as TYPE_OT_SO               ,
  --Information Produit Précédant
  --Dans le Cas où la prestation facturable n'est pas retrouvée => Problème Calcul Pilcom => PRESTA_PRE_CAL_INCO
  Case  When Placement.PRESFACT_CO_PRECED Is Null
          Then '${P_PIL_215}'
  --Dans le Cas où la prestation facturable est retrouvée  Mais pas dans RefCom => Problème Refcom => PRESTA_PRE_RFC_INCO
        When Placement.PRESFACT_CO_PRECED Is Not Null And RefcomPre.PRODUCT_ID Is Null
          Then '${P_PIL_216}'
        Else RefcomPre.PRODUCT_ID
  End                                                     as PRODUCT_ID_PRE           ,
  Coalesce(RefcomPre.TARIF_HT,0)                          as TARIF_HT_PRE             ,
  RefcomPre.SEG_COM_ID                                    as SEG_COM_ID_PRE           ,
  RefcomPre.SEG_COM_AGG_ID                                as SEG_COM_AGG_ID_PRE       ,
  RefcomPre.CODE_MIGRATION                                as CODE_MIGRATION_PRE       ,
  --Information Produit Acqui
  Placement.PRESFACT_CO_OFFRE_OPT_ACQ                     as PRESFACT_CO_OFFRE_OPT_ACQ,
  Coalesce(Refcom.PRODUCT_ID            ,'${P_PIL_223}')  as PRODUCT_ID               ,
  Coalesce(Refcom.TARIF_HT,0)                             as TARIF_HT                 ,
  Coalesce(Refcom.SEG_COM_ID             ,'${P_PIL_022}') as SEG_COM_ID               ,
  Coalesce(Refcom.SEG_COM_AGG_ID        ,'${P_PIL_022}')  as SEG_COM_AGG_ID           ,
  Refcom.TYPE_SERVICE                                     as TYPE_SERVICE             ,
  Coalesce(Refcom.CODE_MIGRATION            ,'${P_PIL_024}')  as CODE_MIGRATION           ,
  Coalesce(Refcom.MIGRATION_REGROUPEMENT_ID ,'${P_PIL_023}')  as MIGRATION_REGROUPEMENT_ID,
  --Si c'est une OT alors on laisse la migration param 
  Case  When Placement.TYPE_OT_SO = '${P_PIL_040}'
          Then Coalesce(Refcom.MIGRATION_POSSIBLE,'${P_PIL_020}')
        --Si c'est un SO alors non Migrable :
        When Placement.TYPE_OT_SO = '${P_PIL_041}'
          Then '${P_PIL_020}'
        Else   '${P_PIL_020}'
  End                                                         as MIGRATION_POSSIBLE       ,
  --Période Considérée :
  Coalesce(Periode.PERIODE_ID                ,${P_PIL_049}  )  as PERIODE_ID               ,
  Placement.CLIENT_NU                                         as CLIENT_NU                ,
  Placement.CLIENT_NU_NEW_PORTE                               as CLIENT_NU_NEW_PORTE      ,
  Placement.DOSSIER_NU                                        as DOSSIER_NU               ,
  Placement.DOSSIER_NU_NEW_PORTE                              as DOSSIER_NU_NEW_PORTE     ,
  Placement.PAR_IMSI                                          as PAR_IMSI                 ,
  Placement.DOSSIER_DATE_RESIL                                as DOSSIER_DATE_RESIL       ,
  Placement.DMC_LINE_ID                                       as DMC_LINE_ID              ,
  Placement.INB_PRESFACT_ACQ_ADV                              as INB_PRESFACT_ACQ_ADV     ,
  Placement.INB_PRESFACT_ACQ_AGAP                             as INB_PRESFACT_ACQ_AGAP    ,
  Placement.PARC_DT_DEBUT                                     as PARC_DT_DEBUT            ,
  Placement.PARC_DT_FIN                                       as PARC_DT_FIN              ,
  Placement.ORDAGD_DT_CONF                                    as ORDAGD_DT_CONF           ,
  Placement.IN_CLIDOS                                         as IN_CLIDOS                ,
  RefProduitLastPer.SEG_COM_ID                                as SEG_COM_ID_LP            ,
  RefProduitLastPer.TYPE_SERVICE                              as TYPE_SERVICE_LP          
From
  ${KNB_PCO_TMP}.INT_T_PLACEMENT_CHOH Placement 
  --On Jointe pour Trouver la période Commmercial qui va bien
   Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.INT_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.INT_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                       = 1
      And Periode.CURRENT_IN                     = 1
      And Periode.CLOSURE_DT                     is null
    -- Attention Ici on met un restriction :
  -- Il faut que les Produits soit dans REFCOM !
  Left Outer Join  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB Refcom
    On    Placement.PRESFACT_CO_OFFRE_OPT_ACQ   =  Refcom.EXT_PRODUCT_ID
      And Placement.TYPE_OT_SO                  =  Case  When Refcom.TYPE_PRODUIT in ('OA','OC','NS')
                                                          Then 'SO'
                                                        Else Refcom.TYPE_PRODUIT
                                                   End
      And Periode.PERIODE_ID                    =  Refcom.PERIODE_ID
  Left Outer Join  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB RefcomPre
    On   Placement.PRESFACT_CO_PRECED        = RefcomPre.EXT_PRODUCT_ID
      And 'OT'                               = RefcomPre.TYPE_PRODUIT
      And Periode.PERIODE_ID                 = RefcomPre.PERIODE_ID
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB RefProduitLastPer
    On    Placement.PRESFACT_CO_OFFRE_OPT_ACQ   = RefProduitLastPer.EXT_PRODUCT_ID
      --On ajoute pour le cas particulier des OA dans le référentiel un surdéfinition en SO
      And Placement.TYPE_OT_SO                  = RefProduitLastPer.TYPE_PRODUIT
      And RefProduitLastPer.PERIODE_ID          = (
                                                      Select
                                                        Max(PERIODE_ID)
                                                      From
                                                        ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM
                                                      Where
                                                        (1=1)
                                                        And CURRENT_IN=1
                                                        And CLOSURE_DT Is Null
                                                  )
  /*
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Period
     On    Placement.INT_DEPOSIT_DT             >= Period.PERIODE_DATE_DEB
      And Placement.INT_DEPOSIT_DT              <= Period.PERIODE_DATE_FIN
      And Period.FRESH_IN                       = 1
      And Period.CURRENT_IN                     = 1
      And Period.CLOSURE_DT                     is null
  -- Attention Ici on met un restriction :
  -- Il faut que les Produits soit dans REFCOM !
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefProduit
    On    Placement.PRESFACT_CO_OFFRE_OPT_ACQ   =   RefProduit.EXT_PRODUCT_ID1
      --On ajoute pour le cas particulier des OA dans le référentiel un surdéfinition en SO
      And Placement.TYPE_OT_SO                  = Case  When RefProduit.TYPE_PRODUIT in ('OA','OC','NS')
                                                          Then 'SO'
                                                        Else RefProduit.TYPE_PRODUIT
                                                  End
      And RefProduit.PERIODE_ID                 = Period.PERIODE_ID
      And RefProduit.FRESH_IN                   = 1
      And RefProduit.CURRENT_IN                 = 1
      And RefProduit.CLOSURE_DT                 is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegCom
    On    RefProduit.PRODUCT_ID                 = RefSegCom.PRODUCT_ID
      And RefSegCom.PERIODE_ID                  = Period.PERIODE_ID
      And RefSegCom.FRESH_IN                    = 1
      And RefSegCom.CURRENT_IN                  = 1
      And RefSegCom.CLOSURE_DT                  is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCat
    On    RefSegCom.SEG_COM_ID                  = RefCat.SEG_COM_ID
      And RefCat.PERIODE_ID                     = RefSegCom.PERIODE_ID
      And RefCat.FRESH_IN                       = 1
      And RefCat.CURRENT_IN                     = 1
      And RefCat.CLOSURE_DT                     is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSegType
    On    RefSegCom.SEG_COM_ID                  = RefSegType.SEG_COM_ID
      And RefSegCom.PERIODE_ID                  = RefSegType.PERIODE_ID
      And RefSegType.FRESH_IN                   = 1
      And RefSegType.CURRENT_IN                 = 1
      And RefSegType.CLOSURE_DT                 is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REGR_MIGR_PILCOM RegMigPossible
    On    RefCat.MIGRATION_REGROUPEMENT_ID      = RegMigPossible.MIGRATION_REGROUPEMENT_ID
      And RegMigPossible.PERIODE_ID             = RefCat.PERIODE_ID
      And RegMigPossible.FRESH_IN               = 1
      And RegMigPossible.CURRENT_IN             = 1
      And RegMigPossible.CLOSURE_DT             is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefProduitPre
    On    Placement.PRESFACT_CO_PRECED          = RefProduitPre.EXT_PRODUCT_ID1
      --On filtre sur les OT pour les produits précédents
      And RefProduitPre.TYPE_PRODUIT            = 'OT'
      AND RefProduitPre.PERIODE_ID              = Period.PERIODE_ID
      And RefProduitPre.FRESH_IN                = 1
      And RefProduitPre.CURRENT_IN              = 1
      And RefProduitPre.CLOSURE_DT              is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_PRD_SGMCM_PILCOM RefSegComPre
    On  RefProduitPre.PRODUCT_ID                = RefSegComPre.PRODUCT_ID
    And RefSegComPre.PERIODE_ID                 = Period.PERIODE_ID
    And RefSegComPre.FRESH_IN                   = 1
    And RefSegComPre.CURRENT_IN                 = 1
    And RefSegComPre.CLOSURE_DT                 is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_SEG_COMMERCE_PILCOM RefSegTypePre
    On    RefSegComPre.SEG_COM_ID               = RefSegTypePre.SEG_COM_ID
      And RefSegComPre.PERIODE_ID               = RefSegTypePre.PERIODE_ID
      And RefSegTypePre.FRESH_IN                = 1
      And RefSegTypePre.CURRENT_IN              = 1
      And RefSegTypePre.CLOSURE_DT              is null
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_LIEN_SEGCOM_PILCOM RefCatPre
    On    RefSegComPre.SEG_COM_ID               = RefCatPre.SEG_COM_ID
      And RefCatPre.PERIODE_ID                  = RefSegComPre.PERIODE_ID
      And RefCatPre.FRESH_IN                    = 1
      And RefCatPre.CURRENT_IN                  = 1
      And RefCatPre.CLOSURE_DT                  is null
  --Calcul du segment sur le dernier référentiel 
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB RefProduitLastPer
    On    Placement.PRESFACT_CO_OFFRE_OPT_ACQ   = RefProduitLastPer.EXT_PRODUCT_ID
      --On ajoute pour le cas particulier des OA dans le référentiel un surdéfinition en SO
      And Placement.TYPE_OT_SO                  = RefProduitLastPer.TYPE_PRODUIT
      And RefProduitLastPer.PERIODE_ID          = (
                                                      Select
                                                        Max(PERIODE_ID)
                                                      From
                                                        ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM
                                                      Where
                                                        (1=1)
                                                        And CURRENT_IN=1
                                                        And CLOSURE_DT Is Null
                                                  )       */
--Filtre
Where
  (1=1)
  --Filtre pour le calcul de profondeur
  --And Placement.CLOSURE_DT is null
  --Filtre pour ne prendre que le commande à AGAP
  And Placement.TYPE_OT_SO in ('${P_PIL_040}','${P_PIL_041}')
  And Placement.HOT_IN = 1
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_CHOH_EXRACT;
.if errorcode <> 0 then .quit 1

.quit 0
