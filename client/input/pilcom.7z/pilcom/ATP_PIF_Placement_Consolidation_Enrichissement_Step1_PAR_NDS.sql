--$HEADER:   mm2pco/current/sql/ATP_PIF_Placement_Consolidation_Enrichissement_Step1_PAR_NDS.sql 13_05#5 08-JUN-2017 08:54:10 KRQJ9961 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step1_PAR_NDS.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 01/08/2016      HLA         Creation
-- 06/04/2017      HLA         Modification
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------
-- Etape 1: Enrichissement DMC 1
----------------------------------------------------------------
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC (
      ACTE_ID BIGINT  NOT NULL,
      ORDER_DEPOSIT_DT DATE FORMAT 'YYYYMMDD'  NOT NULL,
      ORDER_DEPOSIT_TS               Timestamp(0)  ,
      DMC_LINE_ID INTEGER ,
      DMC_MASTER_LINE_ID INTEGER ,
      DMC_LINE_TYPE CHAR(1) ,
      DMC_ACTIVATION_DT DATE FORMAT 'YYYYMMDD'  ,
      PAR_DEPRTMNT_ID CHAR(5) ,
      PAR_AID VARCHAR(31),
      PAR_REGRPMNT_ID VARCHAR(15) ,
      PAR_UNIFIED_PARTY_ID VARCHAR(15)  ,
      MAIL_ADRESS VARCHAR(100) ,
      FIRST_NAME_NM VARCHAR(64) ,
      LAST_NAME_NM VARCHAR(64) ,
      POSTAL_CD CHAR(5) ,
      SERVICE_ACCESS_ID BIGINT ,
      PAR_INSEE_NB CHAR(5) ,
      PAR_BU_CD BYTEINT 
)
    Primary Index (
     Acte_ID
  )
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC Column( Acte_ID);
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC
(
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  ORDER_DEPOSIT_TS     ,
  DMC_LINE_ID          ,
  DMC_MASTER_LINE_ID   ,
  DMC_LINE_TYPE        ,
  DMC_ACTIVATION_DT    ,
  PAR_DEPRTMNT_ID      ,
  PAR_AID              ,
  PAR_REGRPMNT_ID      ,
  PAR_UNIFIED_PARTY_ID ,
  MAIL_ADRESS          ,
  FIRST_NAME_NM        ,
  LAST_NAME_NM         ,
  POSTAL_CD            ,
  SERVICE_ACCESS_ID    ,
  PAR_INSEE_NB         ,
  PAR_BU_CD             
  
)
Select
  RefId.ACTE_ID                             AS  ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    AS  ORDER_DEPOSIT_DT       ,
  RefId.ORDER_DEPOSIT_TS                    As  ORDER_DEPOSIT_TS       ,
  LineDmc.LINE_ID                           as  DMC_LINE_ID            ,
  LineDmc.MASTER_LINE_ID                    as  DMC_MASTER_LINE_ID     ,
  LineDmc.LINE_TYPE                         as  DMC_LINE_TYPE          ,
  LineDmc.ACTIVATION_DT                     as  DMC_ACTIVATION_DT      ,
  LineDmc.DEPRTMNT_ID                       as  PAR_DEPRTMNT_ID        ,
  LineDmc.BSS_PARTY_EXTERNL_ID              AS  PAR_AID                ,
  LineDmc.PARTY_REGRPMNT_ID                 AS  PAR_REGRPMNT_ID        ,
  LineDmc.UNIFIED_PARTY_ID                  AS  PAR_UNIFIED_PARTY_ID   ,
  LineDmc.MAIL_ADRESS                       AS  MAIL_ADRESS            ,
  LineDmc.LAST_NAME_NM                      AS  FIRST_NAME_NM          ,
  LineDmc.FIRST_NAME_NM                     AS  LAST_NAME_NM           ,
  LineDmc.POSTAL_CD                         AS  POSTAL_CD              ,
  LineDmc.SERVICE_ACCESS_ID                 AS  SERVICE_ACCESS_ID      ,
  LineDmc.INSEE_NB                          as  PAR_INSEE_NB           ,
  Geo.BU_CD                                 as  PAR_BU_CD               
  
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 RefId

     Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
        On RefId.PAR_FIXE_DS = LineDmc.ND_VOIP_VALUE_DS
         And LineDmc.START_DT <= RefID.DATE_CREATE_TS 
         And LineDmc.END_DT   > RefID.DATE_CREATE_TS
         And LineDmc.LINE_TYPE = 'I'
         And RefId.DMC_LINE_ID is  null
         
    Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT Geo
        On Geo.DEPT_CD = LineDmc.DEPRTMNT_ID
Where 
  (1=1)
  
   Qualify row_number() over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT order by LineDmc.START_DT desc)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------
-- Etape 2: Enrichissement DMC 2
----------------------------------------------------------------
Insert Into ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC
(
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  ORDER_DEPOSIT_TS     ,
  DMC_LINE_ID          ,
  DMC_MASTER_LINE_ID   ,
  DMC_LINE_TYPE        ,
  DMC_ACTIVATION_DT    ,
  PAR_DEPRTMNT_ID      ,
  PAR_AID              ,
  PAR_REGRPMNT_ID      ,
  PAR_UNIFIED_PARTY_ID ,
  MAIL_ADRESS          ,
  FIRST_NAME_NM        ,
  LAST_NAME_NM         ,
  POSTAL_CD            ,
  SERVICE_ACCESS_ID    ,
  PAR_INSEE_NB         ,
  PAR_BU_CD             
  
)
Select
  RefId.ACTE_ID                             AS  ACTE_ID                ,
  RefId.ORDER_DEPOSIT_DT                    AS  ORDER_DEPOSIT_DT       ,
  RefId.ORDER_DEPOSIT_TS                    As  ORDER_DEPOSIT_TS       ,
  LineDmc.LINE_ID                           as  DMC_LINE_ID            ,
  LineDmc.MASTER_LINE_ID                    as  DMC_MASTER_LINE_ID     ,
  LineDmc.LINE_TYPE                         as  DMC_LINE_TYPE          ,
  LineDmc.ACTIVATION_DT                     as  DMC_ACTIVATION_DT      ,
  LineDmc.DEPRTMNT_ID                       as  PAR_DEPRTMNT_ID        ,
  LineDmc.BSS_PARTY_EXTERNL_ID              AS  PAR_AID                ,
  LineDmc.PARTY_REGRPMNT_ID                 AS  PAR_REGRPMNT_ID        ,
  LineDmc.UNIFIED_PARTY_ID                  AS  PAR_UNIFIED_PARTY_ID   ,
  LineDmc.MAIL_ADRESS                       AS  MAIL_ADRESS            ,
  LineDmc.LAST_NAME_NM                      AS  FIRST_NAME_NM          ,
  LineDmc.FIRST_NAME_NM                     AS  LAST_NAME_NM           ,
  LineDmc.POSTAL_CD                         AS  POSTAL_CD              ,
  LineDmc.SERVICE_ACCESS_ID                 AS  SERVICE_ACCESS_ID      ,
  LineDmc.INSEE_NB                          as  PAR_INSEE_NB           ,
  Geo.BU_CD                                 as  PAR_BU_CD               
  
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 RefId

     Inner Join  ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
        On RefId.PAR_FIXE_DS = LineDmc.NDS_VALUE_DS
         And LineDmc.START_DT <= RefID.DATE_CREATE_TS 
         And LineDmc.END_DT   > RefID.DATE_CREATE_TS
         And LineDmc.LINE_TYPE = 'I'
         And RefId.DMC_LINE_ID is  null
        
    Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT Geo
        On Geo.DEPT_CD = LineDmc.DEPRTMNT_ID
Where 
  (1=1)
  
   And Not Exists 
  (
    Select
       1
    From 
     ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC RefIdExclu
    Where(1=1)
      And   RefIdExclu.ACTE_ID             = RefId.ACTE_ID
      And   RefIdExclu.ORDER_DEPOSIT_DT    = RefId.ORDER_DEPOSIT_DT
      And   RefIdExclu.DMC_LINE_ID  Is Not Null
  )
  Qualify row_number() over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT order by LineDmc.START_DT desc)=1

;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC;
.if errorcode <> 0 then .quit 1
-----------------------------------------------------------
-- Etape 3: Insertion dan table tmp (DMC + Client NU)
-----------------------------------------------------------
 
Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  SERVICE_ACCESS_ID             ,
  DMC_LINE_ID                   ,
  DMC_MASTER_LINE_ID            ,
  DMC_LINE_TYPE                 ,
  DMC_ACTIVATION_DT             ,
  PAR_DEPRTMNT_ID               ,
  PAR_AID                       ,
  PAR_REGRPMNT_ID               ,
  PAR_UNIFIED_PARTY_ID          ,
  MAIL_ADRESS                   ,
  FIRST_NAME_NM                 ,
  LAST_NAME_NM                  ,
  POSTAL_CD                     ,
  PAR_INSEE_NB                  ,
  PAR_BU_CD                     ,
  CLIENT_NU                     ,
  CLIENT_NU_NEW_PORTE           ,
  DOSSIER_NU                    ,
  DOSSIER_NU_NEW_PORTE          ,
  DOSSIER_DATE_ACTIV            ,
  DOSSIER_DATE_RESIL            ,
  DOSSIER_TYPE_RESIL            ,
  DOSSIER_MOTIF_RESIL           ,
  DOSSIER_NU_IMSI                
)
Select 
  RefId.ACTE_ID                           AS  ACTE_ID                       ,
  RefId.ORDER_DEPOSIT_DT                  AS  ORDER_DEPOSIT_DT              ,
  RefId.SERVICE_ACCESS_ID                 AS  SERVICE_ACCESS_ID             ,
  RefId.DMC_LINE_ID                       as  DMC_LINE_ID                   ,
  RefId.DMC_MASTER_LINE_ID                as  DMC_MASTER_LINE_ID            ,
  RefId.DMC_LINE_TYPE                     as  DMC_LINE_TYPE                 ,
  RefId.DMC_ACTIVATION_DT                 as  DMC_ACTIVATION_DT             ,
  RefId.PAR_DEPRTMNT_ID                   as  PAR_DEPRTMNT_ID               ,
  RefId.PAR_AID                           AS  PAR_AID                       ,
  RefId.PAR_REGRPMNT_ID                   AS  PAR_REGRPMNT_ID               ,
  RefId.PAR_UNIFIED_PARTY_ID              AS  PAR_UNIFIED_PARTY_ID          ,
  RefId.MAIL_ADRESS                       AS  MAIL_ADRESS                   ,
  RefId.LAST_NAME_NM                      AS  FIRST_NAME_NM                 ,
  RefId.FIRST_NAME_NM                     AS  LAST_NAME_NM                  ,
  RefId.POSTAL_CD                         AS  POSTAL_CD                     ,
  RefId.PAR_INSEE_NB                      as  PAR_INSEE_NB                  ,
  RefId.PAR_BU_CD                         as  PAR_BU_CD                     ,
  Dossier.DOSSIER_CLIENT_NU               as  CLIENT_NU                     ,
  NULL                                    as  CLIENT_NU_NEW_PORTE           ,
  Dossier.DOSSIER_NU                      as  DOSSIER_NU                    ,
  NULL                                    as  DOSSIER_NU_NEW_PORTE          ,
  NULL                                    as  DOSSIER_DATE_ACTIV            ,
  Dossier.DOSSIER_DT_RESIL                as  DOSSIER_DATE_RESIL            ,
  NULL                                    as  DOSSIER_TYPE_RESIL            ,
  Dossier.DOSSIER_CO_MOTRESIL             as  DOSSIER_MOTIF_RESIL           ,
  Dossier.DOSSIER_NU_IMSI                 as  DOSSIER_NU_IMSI                
  
From ${KNB_TERADATA_USER}.ORD_V_REF_PIF_DMC RefId

    Left outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
        On   RefId.DMC_MASTER_LINE_ID = LineDmc.MASTER_LINE_ID
         and LineDmc.LINE_TYPE = 'M'
    --Jointure Client/Dossier
    Left outer Join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
        On     LineDmc.RES_VALUE_DS = Dossier.DOSSIER_NU
         and Dossier.DOSSIER_DT_CREAT <= RefId.ORDER_DEPOSIT_TS
         and RefId.ORDER_DEPOSIT_TS < Coalesce(Dossier.DOSSIER_DT_RESIL,cast('2999-12-31 00:00:00'as timestamp(0)))

Where (1=1) 
   Qualify row_number() over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT order by LineDmc.START_DT desc)=1
       ;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_IDLINEDMC;
.if errorcode <> 0 then .quit 1

