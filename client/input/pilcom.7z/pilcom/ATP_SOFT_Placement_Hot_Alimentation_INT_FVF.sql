-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Hot_Alimentation_INT_FVF.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de génération à chaud SOFT Internet des lignes De fonction / Valeur de fonction
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--24/02/2015       MDE         Modification :evol CUSTOMER_MARKET_SEG QC796
--------------------------------------------------------------------------------



.set width 2000;


-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.PLACEMENT_SOFT en FVF
-- **************************************************************

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_FVF All;
.if errorcode <> 0 then .quit 1
--------------------------------------------------------------------
-- Cas 1 : Pour les FVF  le cas nominal
--------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_FVF
(
  EXTERNAL_ACTE_ID              ,
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  TYPE_PRODUCT                  ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_DEPOSIT_DT              ,
  PARSIFAL_ORDER_ID             ,
  ORDER_DEPOSIT_TS              ,
  ORDER_VALIDATION_TS           ,
  ORDER_DELIVERY_TS             ,
  AGENT_ID                      ,
  DISTRBTN_CHANNL_ID            ,
  STORE_NAME                    ,
  MOTV_ORDR_ID                  ,
  ORDER_TYPE_CD                 ,
  ORDER_TYPE_ID                 ,
  CANCEL_MOTV_DS                ,
  ACTE_OPERTR_ID_COMPST_OFFR    ,
  COMPST_OFFR_ID                ,
  COMPST_OFFR_DS                ,
  CUSTOMER_CIVILITY             ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_MARKET_SEG           ,
  CUSTOMER_SIRET                ,
  CUSTOMER_BSS_ID               ,
  CUSTOMER_FGT_ID               ,
  CUSTOMER_ND                   ,
  CUSTOMER_CPT_FAC_FGT          ,
  CUSTOMER_CLIENT_NU_ADV        ,
  CUSTOMER_DOSSIER_NU_ADV       ,
  CUSTOMER_BO_ID                ,
  CUSTOMER_ND_AR                ,
  INSTALL_ADDRESS_STREET        ,
  INSTALL_ADDRESS_ZIPCODE       ,
  INSTALL_ADDRESS_CITY          ,
  INSTALL_ADDRESS_COUNTRY       ,
  INSTALL_REGIONAL_DIRCTN_ID    ,
  CONTACT_CIVILITY              ,
  CONTACT_LAST_NAME             ,
  CONTACT_FIRST_NAME            ,
  CONTACT_MOBILE_NUMBER         ,
  CONTACT_MAIL_ADDRESS          ,
  CONTACT_ADDRESS_STREET        ,
  CONTACT_ADDRESS_ZIPCODE       ,
  CONTACT_ADDRESS_CITY          ,
  CONTACT_ADDRESS_COUNTRY       ,
  SHIPMENT_ADDRESS_RELAY_ID     ,
  SHIPMENT_ADDRESS_STREET       ,
  SHIPMENT_ADDRESS_ZIPCODE      ,
  SHIPMENT_ADDRESS_CITY         ,
  SHIPMENT_ADDRESS_COUNTRY      ,
  BO_AGENT_ID                   ,
  ORDER_LINE_EXTERNAL_ID        ,
  EXT_OPER_ID                   ,
  ATOMIC_OFFR_ID                ,
  ATOMIC_OFFR_DS                ,
  FUNCTN_ID                     ,
  FUNCTN_DS                     ,
  FUNCTN_VALUE_ID               ,
  SMPL_FNCTN_VALUE_NM           ,
  FUNCTN_VALUE_DS               ,
  OSCAR_VALUE_NU                ,
  ORDER_COMPLETED               ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT ,
  QUEUE_TS                      ,
  RUN_ID                        ,
  STREAMING_TS                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  HOT_IN                        ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  Case When LigneCommande.FUNCTN_VALUE_ID   Is null
            Then
              --Cas D'une suppression on prend l'OC précédante si elle existe
              Case  When (LigneCommande.EXT_OPER_ID = '${P_PIL_008}' And Commande.PREVIOUS_COMPST_OFFR_ID Is not Null)
                      Then Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.PREVIOUS_COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||'|'||trim(LigneCommande.FUNCTN_ID)
                    --Sinon on prend l'oc courrante.
                    Else Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||'|'||trim(LigneCommande.FUNCTN_ID)
              End
  Else --Cas D'une suppression on prend l'OC précédante si elle existe
      Case  When (LigneCommande.EXT_OPER_ID = '${P_PIL_008}' And Commande.PREVIOUS_COMPST_OFFR_ID Is not Null)
              Then Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.PREVIOUS_COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||'|'||trim(LigneCommande.FUNCTN_ID)||'|'||trim(LigneCommande.FUNCTN_VALUE_ID  )
              --Sinon on prend l'oc courrante.
              Else Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||'|'||trim(LigneCommande.FUNCTN_ID)||'|'||trim(LigneCommande.FUNCTN_VALUE_ID  )
      End
  End                                                                                                           as EXTERNAL_ACTE_ID               ,
  Commande.EXTERNAL_ORDER_ID                                                                                    as EXTERNAL_ORDER_ID              ,
  Commande.ORDER_STATUS_CD                                                                                      as ORDER_STATUS_CD                ,
  Commande.STATUS_MODIF_TS                                                                                      as STATUS_MODIF_TS                ,
  '${IdSourceInterne}'                                                                                          as INTRNL_SOURCE_ID               ,
  '${SousSource}'                                                                                               as TYPE_SOURCE_ID                 ,
  '${P_PIL_004}'                                                                                                as TYPE_PRODUCT                   ,
  Commande.OPERATOR_PROVIDER_ID                                                                                 as OPERATOR_PROVIDER_ID           ,
  Commande.ORDER_DEPOSIT_DT                                                                                     as ORDER_DEPOSIT_DT               ,
  Commande.PARSIFAL_ORDER_ID                                                                                    as PARSIFAL_ORDER_ID              ,
  Commande.ORDER_DEPOSIT_TS                                                                                     as ORDER_DEPOSIT_TS               ,
  Commande.ORDER_VALIDATION_TS                                                                                  as ORDER_VALIDATION_TS            ,
  Commande.ORDER_DELIVERY_TS                                                                                    as ORDER_DELIVERY_TS              ,
  Commande.AGENT_ID                                                                                             as AGENT_ID                       ,
  Commande.DISTRBTN_CHANNL_ID                                                                                   as DISTRBTN_CHANNL_ID             ,
  Commande.STORE_NAME                                                                                           as STORE_NAME                     ,
  Commande.MOTV_ORDR_ID                                                                                         as MOTV_ORDR_ID                   ,
  Commande.ORDER_TYPE_CD                                                                                        as ORDER_TYPE_CD                  ,
  Commande.ORDER_TYPE_ID                                                                                        as ORDER_TYPE_ID                  ,
  Commande.CANCEL_MOTV_DS                                                                                       as CANCEL_MOTV_DS                 ,
  Commande.ACTE_OPERTR_ID_COMPST_OFFR                                                                           as ACTE_OPERTR_ID_COMPST_OFFR     ,
  Case  When LigneCommande.EXT_OPER_ID = '${P_PIL_008}'And Commande.PREVIOUS_COMPST_OFFR_ID Is Not Null
          Then Commande.PREVIOUS_COMPST_OFFR_ID
        Else  Commande.COMPST_OFFR_ID 
  End                                                                                                           as COMPST_OFFR_ID                 ,
  Case  When LigneCommande.EXT_OPER_ID = '${P_PIL_008}'And Commande.PREVIOUS_COMPST_OFFR_ID Is Not Null
          Then Commande.PREVIOUS_COMPST_OFFR_DS
        Else  Commande.COMPST_OFFR_DS 
  End                                                                                                           as COMPST_OFFR_DS                 ,
  Commande.CUSTOMER_CIVILITY                                                                                    as CUSTOMER_CIVILITY              ,
  Commande.CUSTOMER_LAST_NAME                                                                                   as CUSTOMER_LAST_NAME             ,
  Commande.CUSTOMER_FIRST_NAME                                                                                  as CUSTOMER_FIRST_NAME            ,
  case when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='R'
        Then 'R'
     when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='P'
        Then 'P'
     when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='I'
        Then 'X'
    when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='C'  
       Then 'M'
  End                                                                                                           as CUSTOMER_MARKET_SEG            ,
  Commande.CUSTOMER_SIRET                                                                                       as CUSTOMER_SIRET                 ,
  Commande.CUSTOMER_BSS_ID                                                                                      as CUSTOMER_BSS_ID                ,
  Commande.CUSTOMER_FGT_ID                                                                                      as CUSTOMER_FGT_ID                ,
  Commande.CUSTOMER_ND                                                                                          as CUSTOMER_ND                    ,
  Commande.CUSTOMER_CPT_FAC_FGT                                                                                 as CUSTOMER_CPT_FAC_FGT           ,
  Commande.CUSTOMER_CLIENT_NU_ADV                                                                               as CUSTOMER_CLIENT_NU_ADV         ,
  Commande.CUSTOMER_DOSSIER_NU_ADV                                                                              as CUSTOMER_DOSSIER_NU_ADV        ,
  Commande.CUSTOMER_BO_ID                                                                                       as CUSTOMER_BO_ID                 ,
  Commande.CUSTOMER_ND_AR                                                                                       as CUSTOMER_ND_AR                 ,
  Commande.INSTALL_ADDRESS_STREET                                                                               as INSTALL_ADDRESS_STREET         ,
  Commande.INSTALL_ADDRESS_ZIPCODE                                                                              as INSTALL_ADDRESS_ZIPCODE        ,
  Commande.INSTALL_ADDRESS_CITY                                                                                 as INSTALL_ADDRESS_CITY           ,
  Commande.INSTALL_ADDRESS_COUNTRY                                                                              as INSTALL_ADDRESS_COUNTRY        ,
  Commande.INSTALL_REGIONAL_DIRCTN_ID                                                                           as INSTALL_REGIONAL_DIRCTN_ID     ,
  Commande.CONTACT_CIVILITY                                                                                     as CONTACT_CIVILITY               ,
  Commande.CONTACT_LAST_NAME                                                                                    as CONTACT_LAST_NAME              ,
  Commande.CONTACT_FIRST_NAME                                                                                   as CONTACT_FIRST_NAME             ,
  Commande.CONTACT_MOBILE_NUMBER                                                                                as CONTACT_MOBILE_NUMBER          ,
  Commande.CONTACT_MAIL_ADDRESS                                                                                 as CONTACT_MAIL_ADDRESS           ,
  Commande.CONTACT_ADDRESS_STREET                                                                               as CONTACT_ADDRESS_STREET         ,
  Commande.CONTACT_ADDRESS_ZIPCODE                                                                              as CONTACT_ADDRESS_ZIPCODE        ,
  Commande.CONTACT_ADDRESS_CITY                                                                                 as CONTACT_ADDRESS_CITY           ,
  Commande.CONTACT_ADDRESS_COUNTRY                                                                              as CONTACT_ADDRESS_COUNTRY        ,
  Commande.SHIPMENT_ADDRESS_RELAY_ID                                                                            as SHIPMENT_ADDRESS_RELAY_ID      ,
  Commande.SHIPMENT_ADDRESS_STREET                                                                              as SHIPMENT_ADDRESS_STREET        ,
  Commande.SHIPMENT_ADDRESS_ZIPCODE                                                                             as SHIPMENT_ADDRESS_ZIPCODE       ,
  Commande.SHIPMENT_ADDRESS_CITY                                                                                as SHIPMENT_ADDRESS_CITY          ,
  Commande.SHIPMENT_ADDRESS_COUNTRY                                                                             as SHIPMENT_ADDRESS_COUNTRY       ,
  Commande.BO_AGENT_ID                                                                                          as BO_AGENT_ID                    ,
  LigneCommande.ORDER_LINE_EXTERNAL_ID                                                                          as ORDER_LINE_EXTERNAL_ID         ,
  Case  --Si la commande est en CHG
        When LigneCommande.EXT_OPER_ID = '${P_PIL_006}'
          Then
            Case  When (LigneCommande.PREVIOUS_FUNCTN_VALUE_ID Is Not Null)
                    Then '${P_PIL_091}' -- Dans le cas où la VF est modifiée alors c'est un ADD migratoire => ADM
                  --Dans le cas où c'est une migration d'OC avec maintient
                  When Commande.PREVIOUS_COMPST_OFFR_ID Is Not Null
                    Then '${P_PIL_099}' --On créer le mouvement fictif d'ajout de produit qui sera réinterprété par la suite
                  --Sinon on le laisse en maintient
                  Else '${P_PIL_007}'
            End
        --Si la commande est en INI et que l'OC précédante est renseigné alors on interpréte en Ajout de produit qui sera réinterprété par la suite
        When (LigneCommande.EXT_OPER_ID = '${P_PIL_007}' And Commande.PREVIOUS_COMPST_OFFR_ID Is Not Null)
          --On met un ADP
          Then  '${P_PIL_099}'
        --Sinon on laisse l'opérateur de la ligne
        Else LigneCommande.EXT_OPER_ID
  End                                                                                                           as EXT_OPER_ID                    ,
  LigneCommande.ATOMIC_OFFR_ID                                                                                  as ATOMIC_OFFR_ID                 ,
  LigneCommande.ATOMIC_OFFR_DS                                                                                  as ATOMIC_OFFR_DS                 ,
  LigneCommande.FUNCTN_ID                                                                                       as FUNCTN_ID                      ,
  LigneCommande.FUNCTN_DS                                                                                       as FUNCTN_DS                      ,
  LigneCommande.FUNCTN_VALUE_ID                                                                                 as FUNCTN_VALUE_ID                ,
  LigneCommande.SMPL_FNCTN_VALUE_NM                                                                             as SMPL_FNCTN_VALUE_NM            ,
  LigneCommande.FUNCTN_VALUE_DS                                                                                 as FUNCTN_VALUE_DS                ,
  'SC'                                                                                                          as OSCAR_VALUE_NU                 ,
  Commande.ORDER_COMPLETED                                                                                      as ORDER_COMPLETED                ,
  Commande.FLAG_FIRST_RECEPTION_COM                                                                             as FLAG_FIRST_RECEPTION_COM       ,
  Commande.FLAG_FIRST_RECEPTION_COM_STAT                                                                        as FLAG_FIRST_RECEPTION_COM_STAT  ,
  LigneCommande.QUEUE_TS                                                                                        as QUEUE_TS                       ,
  Commande.RUN_ID                                                                                               as RUN_ID                         ,
  LigneCommande.STREAMING_TS                                                                                    as STREAMING_TS                   ,
  Commande.CREATION_TS                                                                                          as CREATION_TS                    ,
  Commande.LAST_MODIF_TS                                                                                        as LAST_MODIF_TS                  ,
  Commande.HOT_IN                                                                                               as HOT_IN                         ,
  Commande.FRESH_IN                                                                                             as FRESH_IN                       ,
  Commande.COHERENCE_IN                                                                                         as COHERENCE_IN                   
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_COM Commande
  Inner Join ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT LigneCommande
    On    Commande.EXTERNAL_ORDER_ID  = LigneCommande.EXTERNAL_ORDER_ID     
      And Commande.ORDER_STATUS_CD    = LigneCommande.ORDER_STATUS_CD       
      And Commande.STATUS_MODIF_TS    = LigneCommande.STATUS_MODIF_TS       
      And Commande.ORDER_DEPOSIT_DT   = LigneCommande.ORDER_DEPOSIT_DT      
Where
  (1=1)
  --On ne tient compte que des 1er statut de chaque commande:
  And Commande.FLAG_FIRST_RECEPTION_COM_STAT = 1
  And FUNCTN_ID<>'${P_PIL_009}'
  And LigneCommande.EXT_OPER_ID In ('${P_PIL_006}','${P_PIL_005}','${P_PIL_008}','${P_PIL_007}')


--------------------------------------------------------------------
-- Cas 2 : Ajout des lignes en sup avec un produit initiale => Finale on insert le produit de départ
--------------------------------------------------------------------

;Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_FVF
(
  EXTERNAL_ACTE_ID              ,
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  TYPE_PRODUCT                  ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_DEPOSIT_DT              ,
  PARSIFAL_ORDER_ID             ,
  ORDER_DEPOSIT_TS              ,
  ORDER_VALIDATION_TS           ,
  ORDER_DELIVERY_TS             ,
  AGENT_ID                      ,
  DISTRBTN_CHANNL_ID            ,
  STORE_NAME                    ,
  MOTV_ORDR_ID                  ,
  ORDER_TYPE_CD                 ,
  ORDER_TYPE_ID                 ,
  CANCEL_MOTV_DS                ,
  ACTE_OPERTR_ID_COMPST_OFFR    ,
  COMPST_OFFR_ID                ,
  COMPST_OFFR_DS                ,
  CUSTOMER_CIVILITY             ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_MARKET_SEG           ,
  CUSTOMER_SIRET                ,
  CUSTOMER_BSS_ID               ,
  CUSTOMER_FGT_ID               ,
  CUSTOMER_ND                   ,
  CUSTOMER_CPT_FAC_FGT          ,
  CUSTOMER_CLIENT_NU_ADV        ,
  CUSTOMER_DOSSIER_NU_ADV       ,
  CUSTOMER_BO_ID                ,
  CUSTOMER_ND_AR                ,
  INSTALL_ADDRESS_STREET        ,
  INSTALL_ADDRESS_ZIPCODE       ,
  INSTALL_ADDRESS_CITY          ,
  INSTALL_ADDRESS_COUNTRY       ,
  INSTALL_REGIONAL_DIRCTN_ID    ,
  CONTACT_CIVILITY              ,
  CONTACT_LAST_NAME             ,
  CONTACT_FIRST_NAME            ,
  CONTACT_MOBILE_NUMBER         ,
  CONTACT_MAIL_ADDRESS          ,
  CONTACT_ADDRESS_STREET        ,
  CONTACT_ADDRESS_ZIPCODE       ,
  CONTACT_ADDRESS_CITY          ,
  CONTACT_ADDRESS_COUNTRY       ,
  SHIPMENT_ADDRESS_RELAY_ID     ,
  SHIPMENT_ADDRESS_STREET       ,
  SHIPMENT_ADDRESS_ZIPCODE      ,
  SHIPMENT_ADDRESS_CITY         ,
  SHIPMENT_ADDRESS_COUNTRY      ,
  BO_AGENT_ID                   ,
  ORDER_LINE_EXTERNAL_ID        ,
  EXT_OPER_ID                   ,
  ATOMIC_OFFR_ID                ,
  ATOMIC_OFFR_DS                ,
  FUNCTN_ID                     ,
  FUNCTN_DS                     ,
  FUNCTN_VALUE_ID               ,
  SMPL_FNCTN_VALUE_NM           ,
  FUNCTN_VALUE_DS               ,
  OSCAR_VALUE_NU                ,
  ORDER_COMPLETED               ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT ,
  QUEUE_TS                      ,
  RUN_ID                        ,
  STREAMING_TS                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  HOT_IN                        ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  Case When (Commande.PREVIOUS_COMPST_OFFR_ID Is not null)
          Then Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.PREVIOUS_COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||'|'||trim(LigneCommande.FUNCTN_ID)||'|'||trim(LigneCommande.PREVIOUS_FUNCTN_VALUE_ID) 
        Else Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||'|'||trim(LigneCommande.FUNCTN_ID)||'|'||trim(LigneCommande.PREVIOUS_FUNCTN_VALUE_ID) 
  End                                                                                                           as EXTERNAL_ACTE_ID               ,
  Commande.EXTERNAL_ORDER_ID                                                                                    as EXTERNAL_ORDER_ID              ,
  Commande.ORDER_STATUS_CD                                                                                      as ORDER_STATUS_CD                ,
  Commande.STATUS_MODIF_TS                                                                                      as STATUS_MODIF_TS                ,
  '${IdSourceInterne}'                                                                                          as INTRNL_SOURCE_ID               ,
  '${SousSource}'                                                                                               as TYPE_SOURCE_ID                 ,
  '${P_PIL_004}'                                                                                                as TYPE_PRODUCT                   ,
  Commande.OPERATOR_PROVIDER_ID                                                                                 as OPERATOR_PROVIDER_ID           ,
  Commande.ORDER_DEPOSIT_DT                                                                                     as ORDER_DEPOSIT_DT               ,
  Commande.PARSIFAL_ORDER_ID                                                                                    as PARSIFAL_ORDER_ID              ,
  Commande.ORDER_DEPOSIT_TS                                                                                     as ORDER_DEPOSIT_TS               ,
  Commande.ORDER_VALIDATION_TS                                                                                  as ORDER_VALIDATION_TS            ,
  Commande.ORDER_DELIVERY_TS                                                                                    as ORDER_DELIVERY_TS              ,
  Commande.AGENT_ID                                                                                             as AGENT_ID                       ,
  Commande.DISTRBTN_CHANNL_ID                                                                                   as DISTRBTN_CHANNL_ID             ,
  Commande.STORE_NAME                                                                                           as STORE_NAME                     ,
  Commande.MOTV_ORDR_ID                                                                                         as MOTV_ORDR_ID                   ,
  Commande.ORDER_TYPE_CD                                                                                        as ORDER_TYPE_CD                  ,
  Commande.ORDER_TYPE_ID                                                                                        as ORDER_TYPE_ID                  ,
  Commande.CANCEL_MOTV_DS                                                                                       as CANCEL_MOTV_DS                 ,
  Commande.ACTE_OPERTR_ID_COMPST_OFFR                                                                           as ACTE_OPERTR_ID_COMPST_OFFR     ,
  --Si l'on a un changement d'oc alors on met l'oc précédante
  Case  When Commande.PREVIOUS_COMPST_OFFR_ID Is Not Null
          Then Commande.PREVIOUS_COMPST_OFFR_ID
        Else Commande.COMPST_OFFR_ID
  End                                                                                                           as COMPST_OFFR_ID                 ,
  Case  When Commande.PREVIOUS_COMPST_OFFR_ID Is Not Null
          Then Commande.PREVIOUS_COMPST_OFFR_DS
        Else Commande.COMPST_OFFR_DS
  End                                                                                                           as COMPST_OFFR_DS                 ,
  Commande.CUSTOMER_CIVILITY                                                                                    as CUSTOMER_CIVILITY              ,
  Commande.CUSTOMER_LAST_NAME                                                                                   as CUSTOMER_LAST_NAME             ,
  Commande.CUSTOMER_FIRST_NAME                                                                                  as CUSTOMER_FIRST_NAME            ,
  case when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='R'
        Then 'R'
     when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='P'
        Then 'P'
     when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='I'
        Then 'X'
    when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='C'  
       Then 'M'
  End                                                                                                           as CUSTOMER_MARKET_SEG            ,
  Commande.CUSTOMER_SIRET                                                                                       as CUSTOMER_SIRET                 ,
  Commande.CUSTOMER_BSS_ID                                                                                      as CUSTOMER_BSS_ID                ,
  Commande.CUSTOMER_FGT_ID                                                                                      as CUSTOMER_FGT_ID                ,
  Commande.CUSTOMER_ND                                                                                          as CUSTOMER_ND                    ,
  Commande.CUSTOMER_CPT_FAC_FGT                                                                                 as CUSTOMER_CPT_FAC_FGT           ,
  Commande.CUSTOMER_CLIENT_NU_ADV                                                                               as CUSTOMER_CLIENT_NU_ADV         ,
  Commande.CUSTOMER_DOSSIER_NU_ADV                                                                              as CUSTOMER_DOSSIER_NU_ADV        ,
  Commande.CUSTOMER_BO_ID                                                                                       as CUSTOMER_BO_ID                 ,
  Commande.CUSTOMER_ND_AR                                                                                       as CUSTOMER_ND_AR                 ,
  Commande.INSTALL_ADDRESS_STREET                                                                               as INSTALL_ADDRESS_STREET         ,
  Commande.INSTALL_ADDRESS_ZIPCODE                                                                              as INSTALL_ADDRESS_ZIPCODE        ,
  Commande.INSTALL_ADDRESS_CITY                                                                                 as INSTALL_ADDRESS_CITY           ,
  Commande.INSTALL_ADDRESS_COUNTRY                                                                              as INSTALL_ADDRESS_COUNTRY        ,
  Commande.INSTALL_REGIONAL_DIRCTN_ID                                                                           as INSTALL_REGIONAL_DIRCTN_ID     ,
  Commande.CONTACT_CIVILITY                                                                                     as CONTACT_CIVILITY               ,
  Commande.CONTACT_LAST_NAME                                                                                    as CONTACT_LAST_NAME              ,
  Commande.CONTACT_FIRST_NAME                                                                                   as CONTACT_FIRST_NAME             ,
  Commande.CONTACT_MOBILE_NUMBER                                                                                as CONTACT_MOBILE_NUMBER          ,
  Commande.CONTACT_MAIL_ADDRESS                                                                                 as CONTACT_MAIL_ADDRESS           ,
  Commande.CONTACT_ADDRESS_STREET                                                                               as CONTACT_ADDRESS_STREET         ,
  Commande.CONTACT_ADDRESS_ZIPCODE                                                                              as CONTACT_ADDRESS_ZIPCODE        ,
  Commande.CONTACT_ADDRESS_CITY                                                                                 as CONTACT_ADDRESS_CITY           ,
  Commande.CONTACT_ADDRESS_COUNTRY                                                                              as CONTACT_ADDRESS_COUNTRY        ,
  Commande.SHIPMENT_ADDRESS_RELAY_ID                                                                            as SHIPMENT_ADDRESS_RELAY_ID      ,
  Commande.SHIPMENT_ADDRESS_STREET                                                                              as SHIPMENT_ADDRESS_STREET        ,
  Commande.SHIPMENT_ADDRESS_ZIPCODE                                                                             as SHIPMENT_ADDRESS_ZIPCODE       ,
  Commande.SHIPMENT_ADDRESS_CITY                                                                                as SHIPMENT_ADDRESS_CITY          ,
  Commande.SHIPMENT_ADDRESS_COUNTRY                                                                             as SHIPMENT_ADDRESS_COUNTRY       ,
  Commande.BO_AGENT_ID                                                                                          as BO_AGENT_ID                    ,
  LigneCommande.ORDER_LINE_EXTERNAL_ID                                                                          as ORDER_LINE_EXTERNAL_ID         ,
  '${P_PIL_015}'                                                                                                as EXT_OPER_ID                    ,
  LigneCommande.ATOMIC_OFFR_ID                                                                                  as ATOMIC_OFFR_ID                 ,
  LigneCommande.ATOMIC_OFFR_DS                                                                                  as ATOMIC_OFFR_DS                 ,
  LigneCommande.FUNCTN_ID                                                                                       as FUNCTN_ID                      ,
  LigneCommande.FUNCTN_DS                                                                                       as FUNCTN_DS                      ,
  LigneCommande.PREVIOUS_FUNCTN_VALUE_ID                                                                        as FUNCTN_VALUE_ID                ,
  LigneCommande.PREVIOUS_SMPL_FNCTN_VALUE_NM                                                                    as SMPL_FNCTN_VALUE_NM            ,
  LigneCommande.PREVIOUS_FUNCTN_VALUE_DS                                                                        as FUNCTN_VALUE_DS                ,
  'SC'                                                                                                          as OSCAR_VALUE_NU                 ,
  Commande.ORDER_COMPLETED                                                                                      as ORDER_COMPLETED                ,
  Commande.FLAG_FIRST_RECEPTION_COM                                                                             as FLAG_FIRST_RECEPTION_COM       ,
  Commande.FLAG_FIRST_RECEPTION_COM_STAT                                                                        as FLAG_FIRST_RECEPTION_COM_STAT  ,
  LigneCommande.QUEUE_TS                                                                                        as QUEUE_TS                       ,
  Commande.RUN_ID                                                                                               as RUN_ID                         ,
  LigneCommande.STREAMING_TS                                                                                    as STREAMING_TS                   ,
  Commande.CREATION_TS                                                                                          as CREATION_TS                    ,
  Commande.LAST_MODIF_TS                                                                                        as LAST_MODIF_TS                  ,
  Commande.HOT_IN                                                                                               as HOT_IN                         ,
  Commande.FRESH_IN                                                                                             as FRESH_IN                       ,
  Commande.COHERENCE_IN                                                                                         as COHERENCE_IN                   
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_COM Commande
  Inner Join ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT LigneCommande
    On    Commande.EXTERNAL_ORDER_ID  = LigneCommande.EXTERNAL_ORDER_ID     
      And Commande.ORDER_STATUS_CD    = LigneCommande.ORDER_STATUS_CD       
      And Commande.STATUS_MODIF_TS    = LigneCommande.STATUS_MODIF_TS       
      And Commande.ORDER_DEPOSIT_DT   = LigneCommande.ORDER_DEPOSIT_DT      
Where
  (1=1)
  --On ne tient compte que des 1er statut de chaque commande:
  And Commande.FLAG_FIRST_RECEPTION_COM_STAT = 1
  And FUNCTN_ID<>'${P_PIL_009}'
  And LigneCommande.EXT_OPER_ID in ('${P_PIL_006}')
  And LigneCommande.PREVIOUS_FUNCTN_VALUE_ID Is not null

--Insertion des lignes fictives de suppresions pour les commandes changement d'OC on met le produit initiale
;Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_FVF
(
  EXTERNAL_ACTE_ID              ,
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  TYPE_PRODUCT                  ,
  OPERATOR_PROVIDER_ID          ,
  ORDER_DEPOSIT_DT              ,
  PARSIFAL_ORDER_ID             ,
  ORDER_DEPOSIT_TS              ,
  ORDER_VALIDATION_TS           ,
  ORDER_DELIVERY_TS             ,
  AGENT_ID                      ,
  DISTRBTN_CHANNL_ID            ,
  STORE_NAME                    ,
  MOTV_ORDR_ID                  ,
  ORDER_TYPE_CD                 ,
  ORDER_TYPE_ID                 ,
  CANCEL_MOTV_DS                ,
  ACTE_OPERTR_ID_COMPST_OFFR    ,
  COMPST_OFFR_ID                ,
  COMPST_OFFR_DS                ,
  CUSTOMER_CIVILITY             ,
  CUSTOMER_LAST_NAME            ,
  CUSTOMER_FIRST_NAME           ,
  CUSTOMER_MARKET_SEG           ,
  CUSTOMER_SIRET                ,
  CUSTOMER_BSS_ID               ,
  CUSTOMER_FGT_ID               ,
  CUSTOMER_ND                   ,
  CUSTOMER_CPT_FAC_FGT          ,
  CUSTOMER_CLIENT_NU_ADV        ,
  CUSTOMER_DOSSIER_NU_ADV       ,
  CUSTOMER_BO_ID                ,
  CUSTOMER_ND_AR                ,
  INSTALL_ADDRESS_STREET        ,
  INSTALL_ADDRESS_ZIPCODE       ,
  INSTALL_ADDRESS_CITY          ,
  INSTALL_ADDRESS_COUNTRY       ,
  INSTALL_REGIONAL_DIRCTN_ID    ,
  CONTACT_CIVILITY              ,
  CONTACT_LAST_NAME             ,
  CONTACT_FIRST_NAME            ,
  CONTACT_MOBILE_NUMBER         ,
  CONTACT_MAIL_ADDRESS          ,
  CONTACT_ADDRESS_STREET        ,
  CONTACT_ADDRESS_ZIPCODE       ,
  CONTACT_ADDRESS_CITY          ,
  CONTACT_ADDRESS_COUNTRY       ,
  SHIPMENT_ADDRESS_RELAY_ID     ,
  SHIPMENT_ADDRESS_STREET       ,
  SHIPMENT_ADDRESS_ZIPCODE      ,
  SHIPMENT_ADDRESS_CITY         ,
  SHIPMENT_ADDRESS_COUNTRY      ,
  BO_AGENT_ID                   ,
  ORDER_LINE_EXTERNAL_ID        ,
  EXT_OPER_ID                   ,
  ATOMIC_OFFR_ID                ,
  ATOMIC_OFFR_DS                ,
  FUNCTN_ID                     ,
  FUNCTN_DS                     ,
  FUNCTN_VALUE_ID               ,
  SMPL_FNCTN_VALUE_NM           ,
  FUNCTN_VALUE_DS               ,
  OSCAR_VALUE_NU                ,
  ORDER_COMPLETED               ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT ,
  QUEUE_TS                      ,
  RUN_ID                        ,
  STREAMING_TS                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  HOT_IN                        ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  Case When (LigneCommande.FUNCTN_VALUE_ID   Is not null)
          Then  Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.PREVIOUS_COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||trim(LigneCommande.FUNCTN_ID)||'|'||trim(LigneCommande.FUNCTN_VALUE_ID  )
        Else    Commande.EXTERNAL_ORDER_ID||'|'||Commande.ORDER_STATUS_CD||'|'||trim(Commande.PREVIOUS_COMPST_OFFR_ID)||'|'||trim(LigneCommande.ATOMIC_OFFR_ID)||trim(LigneCommande.FUNCTN_ID)
  End                                                                                                           as EXTERNAL_ACTE_ID               ,
  Commande.EXTERNAL_ORDER_ID                                                                                    as EXTERNAL_ORDER_ID              ,
  Commande.ORDER_STATUS_CD                                                                                      as ORDER_STATUS_CD                ,
  Commande.STATUS_MODIF_TS                                                                                      as STATUS_MODIF_TS                ,
  '${IdSourceInterne}'                                                                                          as INTRNL_SOURCE_ID               ,
  '${SousSource}'                                                                                               as TYPE_SOURCE_ID                 ,
  '${P_PIL_004}'                                                                                                as TYPE_PRODUCT                   ,
  Commande.OPERATOR_PROVIDER_ID                                                                                 as OPERATOR_PROVIDER_ID           ,
  Commande.ORDER_DEPOSIT_DT                                                                                     as ORDER_DEPOSIT_DT               ,
  Commande.PARSIFAL_ORDER_ID                                                                                    as PARSIFAL_ORDER_ID              ,
  Commande.ORDER_DEPOSIT_TS                                                                                     as ORDER_DEPOSIT_TS               ,
  Commande.ORDER_VALIDATION_TS                                                                                  as ORDER_VALIDATION_TS            ,
  Commande.ORDER_DELIVERY_TS                                                                                    as ORDER_DELIVERY_TS              ,
  Commande.AGENT_ID                                                                                             as AGENT_ID                       ,
  Commande.DISTRBTN_CHANNL_ID                                                                                   as DISTRBTN_CHANNL_ID             ,
  Commande.STORE_NAME                                                                                           as STORE_NAME                     ,
  Commande.MOTV_ORDR_ID                                                                                         as MOTV_ORDR_ID                   ,
  Commande.ORDER_TYPE_CD                                                                                        as ORDER_TYPE_CD                  ,
  Commande.ORDER_TYPE_ID                                                                                        as ORDER_TYPE_ID                  ,
  Commande.CANCEL_MOTV_DS                                                                                       as CANCEL_MOTV_DS                 ,
  Commande.ACTE_OPERTR_ID_COMPST_OFFR                                                                           as ACTE_OPERTR_ID_COMPST_OFFR     ,
  Commande.PREVIOUS_COMPST_OFFR_ID                                                                              as COMPST_OFFR_ID                 ,
  Commande.PREVIOUS_COMPST_OFFR_DS                                                                              as COMPST_OFFR_DS                 ,
  Commande.CUSTOMER_CIVILITY                                                                                    as CUSTOMER_CIVILITY              ,
  Commande.CUSTOMER_LAST_NAME                                                                                   as CUSTOMER_LAST_NAME             ,
  Commande.CUSTOMER_FIRST_NAME                                                                                  as CUSTOMER_FIRST_NAME            ,
  case when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='R'
        Then 'R'
     when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='P'
        Then 'P'
     when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='I'
        Then 'X'
    when  Substring(trim(Commande.CUSTOMER_MARKET_SEG) from 1 for 1 )='C'  
       Then 'M'
  End                                                                                                           as CUSTOMER_MARKET_SEG            ,
  Commande.CUSTOMER_SIRET                                                                                       as CUSTOMER_SIRET                 ,
  Commande.CUSTOMER_BSS_ID                                                                                      as CUSTOMER_BSS_ID                ,
  Commande.CUSTOMER_FGT_ID                                                                                      as CUSTOMER_FGT_ID                ,
  Commande.CUSTOMER_ND                                                                                          as CUSTOMER_ND                    ,
  Commande.CUSTOMER_CPT_FAC_FGT                                                                                 as CUSTOMER_CPT_FAC_FGT           ,
  Commande.CUSTOMER_CLIENT_NU_ADV                                                                               as CUSTOMER_CLIENT_NU_ADV         ,
  Commande.CUSTOMER_DOSSIER_NU_ADV                                                                              as CUSTOMER_DOSSIER_NU_ADV        ,
  Commande.CUSTOMER_BO_ID                                                                                       as CUSTOMER_BO_ID                 ,
  Commande.CUSTOMER_ND_AR                                                                                       as CUSTOMER_ND_AR                 ,
  Commande.INSTALL_ADDRESS_STREET                                                                               as INSTALL_ADDRESS_STREET         ,
  Commande.INSTALL_ADDRESS_ZIPCODE                                                                              as INSTALL_ADDRESS_ZIPCODE        ,
  Commande.INSTALL_ADDRESS_CITY                                                                                 as INSTALL_ADDRESS_CITY           ,
  Commande.INSTALL_ADDRESS_COUNTRY                                                                              as INSTALL_ADDRESS_COUNTRY        ,
  Commande.INSTALL_REGIONAL_DIRCTN_ID                                                                           as INSTALL_REGIONAL_DIRCTN_ID     ,
  Commande.CONTACT_CIVILITY                                                                                     as CONTACT_CIVILITY               ,
  Commande.CONTACT_LAST_NAME                                                                                    as CONTACT_LAST_NAME              ,
  Commande.CONTACT_FIRST_NAME                                                                                   as CONTACT_FIRST_NAME             ,
  Commande.CONTACT_MOBILE_NUMBER                                                                                as CONTACT_MOBILE_NUMBER          ,
  Commande.CONTACT_MAIL_ADDRESS                                                                                 as CONTACT_MAIL_ADDRESS           ,
  Commande.CONTACT_ADDRESS_STREET                                                                               as CONTACT_ADDRESS_STREET         ,
  Commande.CONTACT_ADDRESS_ZIPCODE                                                                              as CONTACT_ADDRESS_ZIPCODE        ,
  Commande.CONTACT_ADDRESS_CITY                                                                                 as CONTACT_ADDRESS_CITY           ,
  Commande.CONTACT_ADDRESS_COUNTRY                                                                              as CONTACT_ADDRESS_COUNTRY        ,
  Commande.SHIPMENT_ADDRESS_RELAY_ID                                                                            as SHIPMENT_ADDRESS_RELAY_ID      ,
  Commande.SHIPMENT_ADDRESS_STREET                                                                              as SHIPMENT_ADDRESS_STREET        ,
  Commande.SHIPMENT_ADDRESS_ZIPCODE                                                                             as SHIPMENT_ADDRESS_ZIPCODE       ,
  Commande.SHIPMENT_ADDRESS_CITY                                                                                as SHIPMENT_ADDRESS_CITY          ,
  Commande.SHIPMENT_ADDRESS_COUNTRY                                                                             as SHIPMENT_ADDRESS_COUNTRY       ,
  Commande.BO_AGENT_ID                                                                                          as BO_AGENT_ID                    ,
  LigneCommande.ORDER_LINE_EXTERNAL_ID                                                                          as ORDER_LINE_EXTERNAL_ID         ,
  --Dans le cas d'un INI : On type un suppression fictive de produit (Purgé au niveau ACTE)
  '${P_PIL_098}'                                                                                                as EXT_OPER_ID                    ,
  LigneCommande.ATOMIC_OFFR_ID                                                                                  as ATOMIC_OFFR_ID                 ,
  LigneCommande.ATOMIC_OFFR_DS                                                                                  as ATOMIC_OFFR_DS                 ,
  LigneCommande.FUNCTN_ID                                                                                       as FUNCTN_ID                      ,
  LigneCommande.FUNCTN_DS                                                                                       as FUNCTN_DS                      ,
  LigneCommande.FUNCTN_VALUE_ID                                                                                 as FUNCTN_VALUE_ID                ,
  LigneCommande.SMPL_FNCTN_VALUE_NM                                                                             as SMPL_FNCTN_VALUE_NM            ,
  LigneCommande.FUNCTN_VALUE_DS                                                                                 as FUNCTN_VALUE_DS                ,
  'SC'                                                                                                          as OSCAR_VALUE_NU                 ,
  Commande.ORDER_COMPLETED                                                                                      as ORDER_COMPLETED                ,
  Commande.FLAG_FIRST_RECEPTION_COM                                                                             as FLAG_FIRST_RECEPTION_COM       ,
  Commande.FLAG_FIRST_RECEPTION_COM_STAT                                                                        as FLAG_FIRST_RECEPTION_COM_STAT  ,
  LigneCommande.QUEUE_TS                                                                                        as QUEUE_TS                       ,
  Commande.RUN_ID                                                                                               as RUN_ID                         ,
  LigneCommande.STREAMING_TS                                                                                    as STREAMING_TS                   ,
  Commande.CREATION_TS                                                                                          as CREATION_TS                    ,
  Commande.LAST_MODIF_TS                                                                                        as LAST_MODIF_TS                  ,
  Commande.HOT_IN                                                                                               as HOT_IN                         ,
  Commande.FRESH_IN                                                                                             as FRESH_IN                       ,
  Commande.COHERENCE_IN                                                                                         as COHERENCE_IN                   
From
  ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_COM Commande
  Inner Join ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT LigneCommande
    On    Commande.EXTERNAL_ORDER_ID  = LigneCommande.EXTERNAL_ORDER_ID     
      And Commande.ORDER_STATUS_CD    = LigneCommande.ORDER_STATUS_CD       
      And Commande.STATUS_MODIF_TS    = LigneCommande.STATUS_MODIF_TS       
      And Commande.ORDER_DEPOSIT_DT   = LigneCommande.ORDER_DEPOSIT_DT      
Where
  (1=1)
  --On ne tient compte que des 1er statut de chaque commande:
  And Commande.FLAG_FIRST_RECEPTION_COM_STAT = 1
  And FUNCTN_ID<>'${P_PIL_009}'
  --On ne récupère que les ini et CHG
  And LigneCommande.EXT_OPER_ID in ('${P_PIL_006}','${P_PIL_007}')
  --On récupère uniquement les Cas de non modif de Valeur de fonction sinon c'est géré par le cas 2
  And LigneCommande.PREVIOUS_FUNCTN_VALUE_ID Is null
  --On récupère uniquement les changements d'OC
  And Commande.PREVIOUS_COMPST_OFFR_ID Is not null
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_FVF;
.if errorcode <> 0 then .quit 1


.quit 0 


