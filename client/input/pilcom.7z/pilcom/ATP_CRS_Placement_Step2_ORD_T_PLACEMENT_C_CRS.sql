-- $HEADER: mm2pco/current/sql/ATP_CRS_Placement_Step2_ORD_T_PLACEMENT_C_CRS.sql 13_05#14 26-JUN-2019 11:39:36 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CRS_Placement_Step2_ORD_T_PLACEMENT_C_CRS.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table T placement pour CRS
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 30/12/2014      OCH         Creation
-- 12/04/2016      MDE         Evol  : profondeur calcul 100 jrs
-- 09/12/2016      HOB         Modif VA Ajout Champ
-- 23/11/2017      MEL         Ajout indicateur IOBSP
-- 13/07/2017      LMU         Modification des IOBSP
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 10/03/2020      JCR         Modif KPI2020
-- 18/01/2020      ITA         PILCOM_793 : Amelioration du rejet des placements CRS
-- 17/06/2021      BCH         PILCOM_936 : Optimisation O3
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_CRS All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_CRS
(
 ACTE_ID                              ,
 EXTERNAL_ACTE_ID                     ,
 TYPE_SOURCE_ID                       ,
 INTRNL_SOURCE_ID                     ,
 ORDER_DEPOSIT_DT                     ,
 ORDER_DEPOSIT_TS                     ,
 ORDER_ID                             ,
 CUSTOMER_LAST_NAME_NM                ,
 CUSTOMER_FIRST_NAME_NM               ,
 CUSTOMER_MSISDN_ID                   ,
 CUSTOMER_DN_ID                       ,
 CUSTOMER_MARKET_SEG_CD               ,
 ACT_REM_ID                           ,
 CA_HT                                ,
 CODE_EAN                             ,
 IMEI_CD                              ,
 DOM_TYPE                             ,
 REJECT_CD                            ,
 SERVICE_ACCESS_ID                    ,
 LINE_ID                              ,
 MASTER_LINE_ID                       ,
 PAR_GEO_MACROZONE                    ,
 PAR_UNIFIED_PARTY_ID                 ,
 PAR_PARTY_REGRPMNT_ID                ,
 CONVERGENT_IN                        ,
 BSS_PARTY_KNB_ID                     ,
 BSS_PARTY_EXTERNL_ID                 ,
 FREG_PARTY_KNB_ID                    ,
 FREG_PARTY_EXTERNL_ID                ,
 RESIL_MOB_DT                         ,
 RESIL_MOB_MOTIF                      ,
 RESIL_MOB_MOTIF_DS                   ,
 STORE_CD                             ,
 ADV_STORE_CD                         ,
 FLAG_TYPE_PTN_NTK_IN                 ,
 AGENT_ID                             ,
 AGENT_LAST_NAME_NM                   ,
 AGENT_FIRST_NAME_NM                  ,
 PAR_CID_ID                           ,
 PAR_PID_ID                           ,
 PAR_FIRST_IN                         ,
 ORG_AGENT_IOBSP                      ,
 ORG_EDO_IOBSP                        ,
 EDO_ID                               ,
 TYPE_EDO_ID                          ,
 NETWRK_TYP_EDO_ID                    ,
 FLAG_PLT_AD_IN                       ,
 FLAG_PLT_CONV_IN                     ,
 FLAG_PLT_SCH_IN                      ,
 FLAG_TEAM_MKT_IN                     ,
 FLAG_TYPE_CMP_IN                     ,
 FLAG_TYPE_GEO_IN                     ,
 FLAG_TYPE_CPT_NTK_IN                 ,
 CLOSURE_DT                           ,
 RUN_ID                               ,
 CREATION_TS                          ,
 LAST_MODIF_TS                        ,
 HOT_IN                               ,
 FRESH_IN                             ,
 COHERENCE_IN                         
 )
Select                                                                                                    
 Placement.ACTE_ID                                                                                     As ACTE_ID                              ,
 Placement.EXTERNAL_ACTE_ID                                                                            As EXTERNAL_ACTE_ID                     ,
 Placement.TYPE_SOURCE_ID                                                                              As TYPE_SOURCE_ID                       ,
 Placement.INTRNL_SOURCE_ID                                                                            As INTRNL_SOURCE_ID                     ,
 Placement.ORDER_DEPOSIT_DT                                                                            As ORDER_DEPOSIT_DT                     ,
 Placement.ORDER_DEPOSIT_TS                                                                            As ORDER_DEPOSIT_TS                     ,
 Placement.ORDER_ID                                                                                    As ORDER_ID                             ,
 Placement.CUSTOMER_LAST_NAME_NM                                                                       As CUSTOMER_LAST_NAME_NM                ,
 Placement.CUSTOMER_FIRST_NAME_NM                                                                      As CUSTOMER_FIRST_NAME_NM               ,
 Placement.CUSTOMER_MSISDN_ID                                                                          As CUSTOMER_MSISDN_ID                   ,
 Placement.CUSTOMER_DN_ID                                                                              As CUSTOMER_DN_ID                       ,
 Placement.CUSTOMER_MARKET_SEG_CD                                                                      As CUSTOMER_MARKET_SEG_CD               ,
 Placement.ACT_REM_ID                                                                                  As ACT_REM_ID                           ,
 Placement.CA_HT                                                                                       As CA_HT                                ,
 Placement.CODE_EAN                                                                                    As EAN_CD                               ,
 Placement.IMEI_CD                                                                                     As IMEI_CD                              ,
 Placement.DOM_TYPE                                                                                    As DOM_TYPE                             ,
 Placement.REJECT_CD                                                                                   As REJECT_CD                            ,
 Null                                                                                                  As SERVICE_ACCESS_ID                    ,
 Null                                                                                                  AS LINE_ID                              ,
 Null                                                                                                  AS MASTER_LINE_ID                       ,
 Null                                                                                                  As PAR_GEO_MACROZONE                    ,
 Null                                                                                                  As PAR_UNIFIED_PARTY_ID                 ,
 Null                                                                                                  As PAR_PARTY_REGRPMNT_ID                ,
 Null                                                                                                  AS CONVERGENT_IN                        ,
 Null                                                                                                  AS BSS_PARTY_KNB_ID                     ,
 Null                                                                                                  AS BSS_PARTY_EXTERNL_ID                 ,
 Null                                                                                                  AS FREG_PARTY_KNB_ID                    ,
 Null                                                                                                  AS FREG_PARTY_EXTERNL_ID                ,
 Null                                                                                                  AS RESIL_MOB_DT                         ,
 Null                                                                                                  AS RESIL_MOB_MOTIF                      ,
 Null                                                                                                  AS RESIL_MOB_MOTIF_DS                   ,
 Null                                                                                                  AS STORE_CD                             ,
 Placement.ADV_STORE_CD                                                                                AS ADV_STORE_CD                         ,
 RefO3.FLAG_TYPE_PTN_NTK                                                                               AS FLAG_TYPE_PTN_NTK_IN                 ,
 Placement.AGENT_ID                                                                                    AS AGENT_ID                             ,
 RefAGENT_ID.LAST_NAME_NM                                                                              AS AGENT_LAST_NAME_NM                   ,
 RefAGENT_ID.FIRST_NAME_NM                                                                             AS AGENT_FIRST_NAME_NM                  ,
 Null                                                                                                  AS PAR_CID_ID                           ,
 Null                                                                                                  AS PAR_PID_ID                           ,
 Null                                                                                                  AS PAR_FIRST_IN                         ,
 Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
 End                                                                                                   as ORG_AGENT_IOBSP       ,
 case when  EdoOBK.EDO_ID is null
        Then 'N'
        Else 'O'
 End                                                                                                   As ORG_EDO_IOBSP                        ,
 RefO3.EDO_ID                                                                                          AS EDO_ID                               ,
 RefO3.TYPE_EDO                                                                                        AS TYPE_EDO_ID                          ,
 RefO3.NETWRK_TYP_EDO_ID                                                                               AS NETWRK_TYP_EDO_ID                    ,
 RefO3.FLAG_PLT_AD                                                                                     AS FLAG_PLT_AD_IN                       ,
 RefO3.FLAG_PLT_CONV                                                                                   AS FLAG_PLT_CONV_IN                     ,
 RefO3.FLAG_PLT_SCH                                                                                    AS FLAG_PLT_SCH_IN                      ,
 Null                                                                                                  AS FLAG_TEAM_MKT_IN                     ,
 Null                                                                                                  AS FLAG_TYPE_CMP_IN                     ,
 RefO3.FLAG_TYPE_GEO                                                                                   AS FLAG_TYPE_GEO_IN                     ,
 RefO3.FLAG_TYPE_CPT_NTK                                                                               AS FLAG_TYPE_CPT_NTK_IN                 ,
 Null                                                                                                  AS CLOSURE_DT                           ,
 Placement.RUN_ID                                                                                      AS RUN_ID                               ,
 Current_Timestamp(0)                                                                                  AS CREATION_TS                          ,
 Current_Timestamp(0)                                                                                  AS LAST_MODIF_TS                        ,
 0                                                                                                     AS HOT_IN                               ,
 1                                                                                                     AS FRESH_IN                             ,
 0                                                                                                     AS COHERENCE_IN                         
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_CRS           Placement
Left outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR    RefO3
 On  Placement.ADV_STORE_CD = RefO3.EXTNL_VAL_COD_CD
 And Placement.ORDER_DEPOSIT_DT Between RefO3.START_EXTNL_VAL_DT
 And Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
Left outer Join  ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefAGENT_ID
 On  Placement.AGENT_ID      = RefAGENT_ID.AGENT_CUID
 And RefAGENT_ID.CURRENT_IN  = 1
 And RefAGENT_ID.CLOSURE_DT  is Null
   --- Indicateur IOBSP
Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
 On  RefO3.EDO_ID   = EdoOBK.EDO_ID
 And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
 And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN = 1 --('ORANGEBANK')
Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
 On Placement.AGENT_ID=CuidOBK.AGENT_ID 
 AND Placement.ORDER_DEPOSIT_DT >= CuidOBK.HABILL_BEGIN_DT 
 AND Placement.ORDER_DEPOSIT_DT < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
 
Qualify Row_Number() Over(Partition by  Placement.ACTE_ID
        Order by     RefO3.START_EXTNL_VAL_DT Desc,
                     Coalesce(RefO3.END_EXTNL_VAL_DT , Cast('99991231' AS Date Format 'YYYYMMDD')) Desc
                          )=1
;                                                  
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_CRS;
.if errorcode <> 0 then .quit 1

-----------------------------------------------------------------
--La consolidation
-----------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_CRS
(
 ACTE_ID                              ,
 EXTERNAL_ACTE_ID                     ,
 TYPE_SOURCE_ID                       ,
 INTRNL_SOURCE_ID                     ,
 ORDER_DEPOSIT_DT                     ,
 ORDER_DEPOSIT_TS                     ,
 ORDER_ID                             ,
 CUSTOMER_LAST_NAME_NM                ,
 CUSTOMER_FIRST_NAME_NM               ,
 CUSTOMER_MSISDN_ID                   ,
 CUSTOMER_DN_ID                       ,
 CUSTOMER_MARKET_SEG_CD               ,
 ACT_REM_ID                           ,
 CA_HT                                ,
 CODE_EAN                             ,
 IMEI_CD                              ,
 DOM_TYPE                             ,
 REJECT_CD                            ,
 SERVICE_ACCESS_ID                    ,
 LINE_ID                              ,
 MASTER_LINE_ID                       ,
 PAR_GEO_MACROZONE                    ,
 PAR_UNIFIED_PARTY_ID                 ,
 PAR_PARTY_REGRPMNT_ID                ,
 CONVERGENT_IN                        ,
 BSS_PARTY_KNB_ID                     ,
 BSS_PARTY_EXTERNL_ID                 ,
 FREG_PARTY_KNB_ID                    ,
 FREG_PARTY_EXTERNL_ID                ,
 RESIL_MOB_DT                         ,
 RESIL_MOB_MOTIF                      ,
 RESIL_MOB_MOTIF_DS                   ,
 STORE_CD                             ,
 ADV_STORE_CD                         ,
 FLAG_TYPE_PTN_NTK_IN                 ,
 AGENT_ID                             ,
 AGENT_LAST_NAME_NM                   ,
 AGENT_FIRST_NAME_NM                  ,
 PAR_CID_ID                           ,
 PAR_PID_ID                           ,
 PAR_FIRST_IN                         ,
 ORG_AGENT_IOBSP                      ,
 ORG_EDO_IOBSP                        ,
 EDO_ID                               ,
 TYPE_EDO_ID                          ,
 NETWRK_TYP_EDO_ID                    ,
 FLAG_PLT_AD_IN                       ,
 FLAG_PLT_CONV_IN                     ,
 FLAG_PLT_SCH_IN                      ,
 FLAG_TEAM_MKT_IN                     ,
 FLAG_TYPE_CMP_IN                     ,
 FLAG_TYPE_GEO_IN                     ,
 FLAG_TYPE_CPT_NTK_IN                 ,
 CLOSURE_DT                           ,
 RUN_ID                               ,
 CREATION_TS                          ,
 LAST_MODIF_TS                        ,
 HOT_IN                               ,
 FRESH_IN                             ,
 COHERENCE_IN                         
 )
Select                                                                                                    
 Placement.ACTE_ID                                                                                     As ACTE_ID                              ,
 Placement.EXTERNAL_ACTE_ID                                                                            As EXTERNAL_ACTE_ID                     ,
 Placement.TYPE_SOURCE_ID                                                                              As TYPE_SOURCE_ID                       ,
 Placement.INTRNL_SOURCE_ID                                                                            As INTRNL_SOURCE_ID                     ,
 Placement.ORDER_DEPOSIT_DT                                                                            As ORDER_DEPOSIT_DT                     ,
 Placement.ORDER_DEPOSIT_TS                                                                            As ORDER_DEPOSIT_TS                     ,
 Placement.ORDER_ID                                                                                    As ORDER_ID                             ,
 Placement.CUSTOMER_LAST_NAME_NM                                                                       As CUSTOMER_LAST_NAME_NM                ,
 Placement.CUSTOMER_FIRST_NAME_NM                                                                      As CUSTOMER_FIRST_NAME_NM               ,
 Placement.CUSTOMER_MSISDN_ID                                                                          As CUSTOMER_MSISDN_ID                   ,
 Placement.CUSTOMER_DN_ID                                                                              As CUSTOMER_DN_ID                       ,
 Placement.CUSTOMER_MARKET_SEG_CD                                                                      As CUSTOMER_MARKET_SEG_CD               ,
 Placement.ACT_REM_ID                                                                                  As ACT_REM_ID                           ,
 Placement.CA_HT                                                                                       As CA_HT                                ,
 Placement.CODE_EAN                                                                                    As CODE_EAN                             ,
 Placement.IMEI_CD                                                                                     As IMEI_CD                              ,
 Placement.DOM_TYPE                                                                                    As DOM_TYPE                             ,
 Placement.REJECT_CD                                                                                   As REJECT_CD                            ,
 Null                                                                                                  AS SERVICE_ACCESS_ID                    ,
 Null                                                                                                  AS LINE_ID                              ,
 Null                                                                                                  AS MASTER_LINE_ID                       ,
 Null                                                                                                  As PAR_GEO_MACROZONE                    ,
 Null                                                                                                  As PAR_UNIFIED_PARTY_ID                 ,
 Null                                                                                                  As PAR_PARTY_REGRPMNT_ID                ,
 Null                                                                                                  AS CONVERGENT_IN                        ,
 Null                                                                                                  AS BSS_PARTY_KNB_ID                     ,
 Null                                                                                                  AS BSS_PARTY_EXTERNL_ID                 ,
 Null                                                                                                  AS FREG_PARTY_KNB_ID                    ,
 Null                                                                                                  AS FREG_PARTY_EXTERNL_ID                ,
 Null                                                                                                  AS RESIL_MOB_DT                         ,
 Null                                                                                                  AS RESIL_MOB_MOTIF                      ,
 Null                                                                                                  AS RESIL_MOB_MOTIF_DS                   ,
 Null                                                                                                  AS STORE_CD                             ,
 Placement.ADV_STORE_CD                                                                                AS ADV_STORE_CD                         ,
 RefO3.FLAG_TYPE_PTN_NTK                                                                               AS FLAG_TYPE_PTN_NTK_IN                 ,
 Placement.AGENT_ID                                                                                    AS AGENT_ID                             ,
 RefAGENT_ID.LAST_NAME_NM                                                                              AS AGENT_LAST_NAME_NM                   ,
 RefAGENT_ID.FIRST_NAME_NM                                                                             AS AGENT_FIRST_NAME_NM                  ,
 Placement.PAR_CID_ID                                                                                  AS PAR_CID_ID                           ,
 Placement.PAR_PID_ID                                                                                  AS PAR_PID_ID                           ,
 Placement.PAR_FIRST_IN                                                                                AS PAR_FIRST_IN                         ,
 Placement.ORG_AGENT_IOBSP                                                                             AS ORG_AGENT_IOBSP                      ,
 Placement.ORG_EDO_IOBSP                                                                               AS ORG_EDO_IOBSP                        ,
 RefO3.EDO_ID                                                                                          AS EDO_ID                               ,
 RefO3.TYPE_EDO                                                                                        AS TYPE_EDO_ID                          ,
 RefO3.NETWRK_TYP_EDO_ID                                                                               AS NETWRK_TYP_EDO_ID                    ,
 RefO3.FLAG_PLT_AD                                                                                     AS FLAG_PLT_AD_IN                       ,
 RefO3.FLAG_PLT_CONV                                                                                   AS FLAG_PLT_CONV_IN                     ,
 RefO3.FLAG_PLT_SCH                                                                                    AS FLAG_PLT_SCH_IN                      ,
 Null                                                                                                  AS FLAG_TEAM_MKT_IN                     ,
 Null                                                                                                  AS FLAG_TYPE_CMP_IN                     ,
 RefO3.FLAG_TYPE_GEO                                                                                   AS FLAG_TYPE_GEO_IN                     ,
 RefO3.FLAG_TYPE_CPT_NTK                                                                               AS FLAG_TYPE_CPT_NTK_IN                 ,
 Null                                                                                                  AS CLOSURE_DT                           ,
 Placement.RUN_ID                                                                                      AS RUN_ID                               ,
 Current_Timestamp(0)                                                                                  AS CREATION_TS                          ,
 Current_Timestamp(0)                                                                                  AS LAST_MODIF_TS                        ,
 0                                                                                                     AS HOT_IN                               ,
 1                                                                                                     AS FRESH_IN                             ,
 0                                                                                                     AS COHERENCE_IN                         
 From
  --On prend tout le contenu de la table mirroire tmp
 ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_CRS  Placement
 Left outer Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR    RefO3
 On  Placement.ADV_STORE_CD = RefO3.EXTNL_VAL_COD_CD
 And Placement.ORDER_DEPOSIT_DT Between RefO3.START_EXTNL_VAL_DT
 And Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
 Left outer Join  ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefAGENT_ID
 On  Placement.AGENT_ID      = RefAGENT_ID.AGENT_CUID
 And RefAGENT_ID.CURRENT_IN  = 1
 And RefAGENT_ID.CLOSURE_DT  is Null
 Where  Not Exists (
                     Select 1
                     From  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_CRS     WorkPL
                     Where   WorkPL.ACTE_ID = Placement.ACTE_ID
                             And WorkPL.ORDER_ID = Placement.ORDER_ID
                   )
   And   Placement.ORDER_DEPOSIT_DT > Cast(Cast(${KNB_PILCOM_ACTE_BORNE_INF} As Char(8)) as Date Format 'YYYYMMDD')
   And   Placement.ORDER_DEPOSIT_DT < Cast(Cast(${KNB_PILCOM_ACTE_BORNE_MAX} As Char(8)) as Date Format 'YYYYMMDD')
   And   cast ( Cast( Placement.ORDER_DEPOSIT_TS as TIMESTAMP(0)) as Date )  >= (Current_date - ${P_PIL_536}) 
 Qualify Row_Number() Over(Partition by  Placement.ACTE_ID
        Order by     RefO3.START_EXTNL_VAL_DT Desc,
                     Coalesce(RefO3.END_EXTNL_VAL_DT , Cast('99991231' AS Date Format 'YYYYMMDD')) Desc
                          )=1
;                                                  
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_C_CRS;
.if errorcode <> 0 then .quit 1

.quit 0
