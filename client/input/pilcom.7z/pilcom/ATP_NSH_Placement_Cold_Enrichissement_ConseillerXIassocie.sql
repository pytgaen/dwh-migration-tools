-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_Enrichissement_ConseillerXIassocie.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement des conseillers
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/03/2014      MCA         Creation
-- 31/07/2014      MCA         Indus
-- 24/09/2014      HZO         Modification : Filtres RefAgent : CURRENT_IN et CLOSURE_DT
--------------------------------------------------------------------------------

.set width 2500;


--Delete des lignes
--------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_VENDEUR All;
.if errorcode <> 0 then .quit 1

--------------------------------------------------------------------------------
-------------------------------------------------------------------
-- Implémentation des RGs sur la recherche du XI associé au code vendeur
-- On recherche Ici le conseiller ayant réaliser la vente
-------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_VENDEUR
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  ORG_REF_TRAV              ,
  ORG_AGENT_ID              ,
  ORG_POC_XI                ,
  ORG_NOM                   ,
  ORG_PRENOM                ,
  ORG_GROUPE_ID             
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT            as ORDER_DEPOSIT_DT     ,
  --Lorsqu'on trouve l'orga POC
  RefAgent.SOURCE_CD                as ORG_REF_TRAV         ,
  --Code Aliance du vendeur :
  RefId.ORG_AGENT_ID                as ORG_AGENT_ID         ,
  --Code Xi du Vendeur :CLIENT_CO_TYPCLI
  Null                              as ORG_POC_XI           ,
  --Nom du Vendeur :
  RefAgent.LAST_NAME_NM             as ORG_NOM              ,
  --Prénom du vendeur :
  RefAgent.FIRST_NAME_NM            as ORG_PRENOM           ,
  --Groupe de travail
  Null                              as ORG_GROUPE_ID
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP RefId
  Inner Join ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT RefAgent
    On    RefId.ORG_AGENT_ID      =   RefAgent.AGENT_CUID
      And RefAgent.CURRENT_IN      = 1
      And RefAgent.CLOSURE_DT      is null
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by RefAgent.LAST_NAME_NM  Asc)=1

;
.if errorcode <> 0 then .quit 1
--Collecte des stats
Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_VENDEUR;
.if errorcode <> 0 then .quit 1

.quit 0

