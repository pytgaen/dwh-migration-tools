-- $HEADER: mm2pco/current/sql/ATP_EXF_Placement_C_Alimentation_Step4_Placement_Final.sql 13_05#9 26-JUN-2019 11:40:14 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EXF_Placement_C_Alimentation_Step5_Placement_Final.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de creation de placement final
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 10/06/2013      OCH         Creation
-- 12/04/2015      MDE         Evol  : profondeur calcul 100 jrs
-- 21/11/2017      HOB         Alimentation Champs IOBSP  
-- 01/03/2019      SSI        Evol : Hierachisation IOBSP
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID

--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_T_PLACEMENT_EXF_C All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ACT_T_PLACEMENT_EXF_C
(
    ACTE_ID                      ,
    EXTERNAL_ACTE_ID             ,
    TYPE_MOVEMENT_CD             ,
    INTRNL_SOURCE_ID             ,
    ORDER_DEPOSIT_DT             ,
    ORDER_DEPOSIT_TS             ,
    NUM_ORDER_NU                 ,
    COMMENT_DS                   ,
    LAST_NAME_CUSTOMER_NM        ,
    FIRST_NAME_CUSTOMER_NM       ,
    MISISDN_ID                   ,
    ND_ID                        ,
    NDIP_ID                      ,
    TYPE_CUSTOMER_CD             ,
    TYPE_SOURCE_CD               ,
    ENGAGMNT_NB                  ,
    AGENT_ID                     ,
    NATURE_CD                    ,
    OSCAR_VALUE_CD               ,
    INJECTION_TS                 ,
    CLOSURE_DT                   ,
    ORG_REF_TRAV_ID              ,
    ORG_AGENT_ID                 ,
    ORG_AGENT_IOBSP              ,
    ORG_POC_XI                   ,
    ORG_LAST_NAME_NM             ,
    ORG_FIRST_NAME_NM            ,
    WORK_GROUPE_ID               ,
    ORG_GROUPE_ID                ,
    ORG_ACTVT_REAL_ID            ,
    ORG_RESP_REF_TRAV_ID         ,
    ORG_RESP_AGENT_ID            ,
    ORG_RESP_XI_ID               ,
    ORG_RESP_REAL_ACTIVITY_CD    ,
    ACT_REM_ID                   ,
    CDR_ID                       ,
    EDO_ID                       ,
    ORG_EDO_IOBSP                ,
    PLT_CONV_IN                  ,
    PLT_SCH_IN                   ,
    TEAM_MKT_IN                  ,
    TYPE_CMP_IN                  ,
    TYPE_GEO_IN                  ,
    TYPE_CPT_NTK_IN              ,
    TYPE_EDO_IN                  ,
    NETWRK_TYP_EDO_ID            ,
    QUANTT_QT                    ,
    CA_AM                        ,
    CA_LINE_AM                   ,
    HOT_IN                       ,
    CREATION_TS                  ,
    LAST_MODIF_TS                ,
    FRESH_IN                     ,
    COHERENCE_IN         
)
Select
  Placement.ACTE_ID                                             As ACTE_ID                   ,
  Placement.EXTERNAL_ACTE_ID                                    As EXTERNAL_ACTE_ID          ,
  Placement.TYPE_MOVEMENT_CD                                    As TYPE_MOVEMENT_CD          ,
  Placement.INTRNL_SOURCE_ID                                    As INTRNL_SOURCE_ID          ,
  Placement.ORDER_DEPOSIT_DT                                    As ORDER_DEPOSIT_DT          ,
  Placement.ORDER_DEPOSIT_TS                                    As ORDER_DEPOSIT_TS          ,
  Placement.NUM_ORDER_NU                                        As NUM_ORDER_NU              ,
  Placement.COMMENT_DS                                          As COMMENT_DS                ,
  Placement.LAST_NAME_CUSTOMER_NM                               As LAST_NAME_CUSTOMER_NM     ,
  Placement.FIRST_NAME_CUSTOMER_NM                              As FIRST_NAME_CUSTOMER_NM    ,
  Placement.MISISDN_ID                                          As MISISDN_ID                ,
  Placement.ND_ID                                               As ND_ID                     ,
  Placement.NDIP_ID                                             As NDIP_ID                   ,
  Placement.TYPE_CUSTOMER_CD                                    As TYPE_CUSTOMER_CD          ,
  Placement.TYPE_SOURCE_CD                                      As TYPE_SOURCE_CD            ,
  Placement.ENGAGMNT_NB                                         As ENGAGMNT_NB               ,
  Placement.AGENT_ID                                            As AGENT_ID                  ,
  Placement.NATURE_CD                                           As NATURE_CD                 ,
  Placement.OSCAR_VALUE_CD                                      As OSCAR_VALUE_CD            ,
  Placement.INJECTION_TS                                        As INJECTION_TS              ,
  Case When Placement.TYPE_MOVEMENT_CD IN ('SUPP') then  Current_Timestamp(0)
       When Placement.TYPE_MOVEMENT_CD IN ('CREA','MODIF') then Null 
  END                                                           As CLOSURE_DT                ,
  Null                                                          As ORG_REF_TRAV_ID           ,
  Ref_AGENT_ID.ORG_AGENT_ID                                     As ORG_AGENT_ID              ,
  Null                                                          As ORG_AGENT_IOBSP           ,
  Null                                                          As ORG_POC_XI                ,
  Ref_AGENT_ID.ORG_LAST_NAME_NM                                 As ORG_LAST_NAME_NM          ,
  Ref_AGENT_ID.ORG_FIRST_NAME_NM                                As ORG_FIRST_NAME_NM         ,
  Null                                                          As WORK_GROUPE_ID            ,
  Null                                                          As ORG_GROUPE_ID             ,
  Null                                                          As ORG_ACTVT_REAL_ID         ,
  Null                                                          As ORG_RESP_REF_TRAV_ID      ,
  Null                                                          As ORG_RESP_AGENT_ID         ,
  Null                                                          As ORG_RESP_XI_ID            ,
  Null                                                          As ORG_RESP_REAL_ACTIVITY_CD ,
  Placement.ACT_REM_ID                                          As ACT_REM_ID                ,
  Null                                                          As CDR_ID                    ,
  Placement.EDO_ID                                              As EDO_ID                    ,
  Null                                                          As ORG_EDO_IOBSP             ,
  RefO3.FLAG_PLT_CONV_IN                                        As PLT_CONV_IN               ,
  RefO3.FLAG_PLT_SCH_IN                                         As PLT_SCH_IN                ,
  Null                                                          As TEAM_MKT_IN               ,
  Null                                                          As TYPE_CMP_IN               ,
  RefO3.FLAG_TYPE_GEO_IN                                        As TYPE_GEO_IN               ,
  RefO3.FLAG_TYPE_CPT_NTK_IN                                    As TYPE_CPT_NTK_IN           ,
  RefO3.TYPE_EDO_IN                                             As TYPE_EDO_IN               ,
  RefO3.NETWRK_TYP_EDO_ID                                       As NETWRK_TYP_EDO_ID         ,
  Placement.QUANTT_QT                                           As QUANTT_QT                 ,
  Placement.CA_AM                                               As CA_AM                     ,
  Placement.CA_LINE_AM                                          As CA_LINE_AM                ,
  0                                                             As HOT_IN                    ,
  Current_Timestamp(0)                                          As CREATION_TS               ,
  Current_Timestamp(0)                                          As LAST_MODIF_TS             ,
  1                                                             As FRESH_IN                  ,
  0                                                             As COHERENCE_IN              
From
  --On prend tout le contenu de la table mirroire tmp
  ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_PL Placement
  --Enrichissement du NUM_ORDER_NU
  Left Outer Join ${KNB_PCO_TMP}.ACT_W_PL_EXF_C_AGENT_ID Ref_AGENT_ID
    On    Placement.ACTE_ID           = Ref_AGENT_ID.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = Ref_AGENT_ID.ORDER_DEPOSIT_DT
  --Enrichissement d'O3
  Left Outer Join ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3 RefO3
    On    Placement.ACTE_ID           = RefO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RefO3.ORDER_DEPOSIT_DT
   Qualify Row_Number() Over(Partition by placement.ACTE_ID order by 1)=1
;

.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_T_PLACEMENT_EXF_C;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------------------------------------
---     La consolidation
-------------------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ACT_T_PLACEMENT_EXF_C
(
    ACTE_ID                      ,
    EXTERNAL_ACTE_ID             ,
    TYPE_MOVEMENT_CD             ,
    INTRNL_SOURCE_ID             ,
    ORDER_DEPOSIT_DT             ,
    ORDER_DEPOSIT_TS             ,
    NUM_ORDER_NU                 ,
    COMMENT_DS                   ,
    LAST_NAME_CUSTOMER_NM        ,
    FIRST_NAME_CUSTOMER_NM       ,
    MISISDN_ID                   ,
    ND_ID                        ,
    NDIP_ID                      ,
    TYPE_CUSTOMER_CD             ,
    TYPE_SOURCE_CD               ,
    ENGAGMNT_NB                  ,
    AGENT_ID                     ,
    NATURE_CD                    ,
    OSCAR_VALUE_CD               ,
    INJECTION_TS                 ,
    CLOSURE_DT                   ,
    ORG_REF_TRAV_ID              ,
    ORG_AGENT_ID                 ,
    ORG_AGENT_IOBSP              ,
    ORG_POC_XI                   ,
    ORG_LAST_NAME_NM             ,
    ORG_FIRST_NAME_NM            ,
    WORK_GROUPE_ID               ,
    ORG_GROUPE_ID                ,
    ORG_ACTVT_REAL_ID            ,
    ORG_RESP_REF_TRAV_ID         ,
    ORG_RESP_AGENT_ID            ,
    ORG_RESP_XI_ID               ,
    ORG_RESP_REAL_ACTIVITY_CD    ,
    ACT_REM_ID                   ,
    CDR_ID                       ,
    EDO_ID                       ,
    ORG_EDO_IOBSP                ,
    PLT_CONV_IN                  ,
    PLT_SCH_IN                   ,
    TEAM_MKT_IN                  ,
    TYPE_CMP_IN                  ,
    TYPE_GEO_IN                  ,
    TYPE_CPT_NTK_IN              ,
    TYPE_EDO_IN                  ,
    NETWRK_TYP_EDO_ID            ,
    QUANTT_QT                    ,
    CA_AM                        ,
    CA_LINE_AM                   ,
    HOT_IN                       ,
    CREATION_TS                  ,
    LAST_MODIF_TS                ,
    FRESH_IN                     ,
    COHERENCE_IN         
)
Select
  Placement.ACTE_ID                                             As ACTE_ID                   ,
  Placement.EXTERNAL_ACTE_ID                                    As EXTERNAL_ACTE_ID          ,
  Placement.TYPE_MOVEMENT_CD                                    As TYPE_MOVEMENT_CD          ,
  Placement.INTRNL_SOURCE_ID                                    As INTRNL_SOURCE_ID          ,
  Placement.ORDER_DEPOSIT_DT                                    As ORDER_DEPOSIT_DT          ,
  Placement.ORDER_DEPOSIT_TS                                    As ORDER_DEPOSIT_TS          ,
  Placement.NUM_ORDER_NU                                        As NUM_ORDER_NU              ,
  Placement.COMMENT_DS                                          As COMMENT_DS                ,
  Placement.LAST_NAME_CUSTOMER_NM                               As LAST_NAME_CUSTOMER_NM     ,
  Placement.FIRST_NAME_CUSTOMER_NM                              As FIRST_NAME_CUSTOMER_NM    ,
  Placement.MISISDN_ID                                          As MISISDN_ID                ,
  Placement.ND_ID                                               As ND_ID                     ,
  Placement.NDIP_ID                                             As NDIP_ID                   ,
  Placement.TYPE_CUSTOMER_CD                                    As TYPE_CUSTOMER_CD          ,
  Placement.TYPE_SOURCE_CD                                      As TYPE_SOURCE_CD            ,
  Placement.ENGAGMNT_NB                                         As ENGAGMNT_NB               ,
  Placement.AGENT_ID                                            As AGENT_ID                  ,
  Placement.NATURE_CD                                           As NATURE_CD                 ,
  Placement.OSCAR_VALUE_CD                                      As OSCAR_VALUE_CD            ,
  Placement.INJECTION_TS                                        As INJECTION_TS              ,
  Case When Placement.TYPE_MOVEMENT_CD IN ('SUPP') then  Current_Timestamp(0)
       When Placement.TYPE_MOVEMENT_CD IN ('CREA','MODIF') then Null 
  END                                                           As CLOSURE_DT                ,
  Null                                                          As ORG_REF_TRAV_ID           ,
  Placement.AGENT_ID                                            As ORG_AGENT_ID              ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                         as  ORG_AGENT_IOBSP          ,
  Null                                                          As ORG_POC_XI                ,
  Ref_AGENT_ID.LAST_NAME_NM                                     As ORG_LAST_NAME_NM          ,
  Ref_AGENT_ID.FIRST_NAME_NM                                    As ORG_FIRST_NAME_NM         ,
  Null                                                          As WORK_GROUPE_ID            ,
  Null                                                          As ORG_GROUPE_ID             ,
  Null                                                          As ORG_ACTVT_REAL_ID         ,
  Null                                                          As ORG_RESP_REF_TRAV_ID      ,
  Null                                                          As ORG_RESP_AGENT_ID         ,
  Null                                                          As ORG_RESP_XI_ID            ,
  Null                                                          As ORG_RESP_REAL_ACTIVITY_CD ,
  Placement.ACT_REM_ID                                          As ACT_REM_ID                ,
  Null                                                          As CDR_ID                    ,
  Placement.EDO_ID                                              As EDO_ID                    ,
  Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
  End                                                           as ORG_EDO_IOBSP              ,
  RefO3.FLAG_PLT_CONV_IN                                        As PLT_CONV_IN               ,
  RefO3.FLAG_PLT_SCH_IN                                         As PLT_SCH_IN                ,
  Null                                                          As TEAM_MKT_IN               ,
  Null                                                          As TYPE_CMP_IN               ,
  RefO3.FLAG_TYPE_GEO_IN                                        As TYPE_GEO_IN               ,
  RefO3.FLAG_TYPE_CPT_NTK_IN                                    As TYPE_CPT_NTK_IN           ,
  RefO3.TYPE_EDO_IN                                             As TYPE_EDO_IN               ,
  RefO3.NETWRK_TYP_EDO_ID                                       As NETWRK_TYP_EDO_ID         ,
  Placement.QUANTT_QT                                           As QUANTT_QT                 ,
  Placement.CA_AM                                               As CA_AM                     ,
  Placement.CA_LINE_AM                                          As CA_LINE_AM                ,
  0                                                             As HOT_IN                    ,
  Current_Timestamp(0)                                          As CREATION_TS               ,
  Current_Timestamp(0)                                          As LAST_MODIF_TS             ,
  1                                                             As FRESH_IN                  ,
  0                                                             As COHERENCE_IN              
From
  --On prend tout le contenu de la table mirroire tmp
  ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF  Placement
  --Enrichissement du NUM_ORDER_NU
  Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_GLOBAL_AGENT Ref_AGENT_ID
    On    Placement.AGENT_ID      = Ref_AGENT_ID.AGENT_CUID
    And Ref_AGENT_ID.CURRENT_IN  = 1
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    Placement.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')     And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Placement.AGENT_ID=CuidOBK.AGENT_ID
        And  Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
        And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))  
      
  --Enrichissement d'O3
  Left Outer Join ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_O3 RefO3
    On    Placement.ACTE_ID           = RefO3.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RefO3.ORDER_DEPOSIT_DT
   Where Placement.ORDER_DEPOSIT_DT   > Cast(Cast(${KNB_PILCOM_ACTE_BORNE_INF} As Char(8)) as Date Format 'YYYYMMDD')
   And   Placement.ORDER_DEPOSIT_DT   < Cast(Cast(${KNB_PILCOM_ACTE_BORNE_MAX} As Char(8)) as Date Format 'YYYYMMDD')
   And   Placement.ORDER_DEPOSIT_DT   >= (Current_date - ${P_PIL_532}) 
   And Ref_AGENT_ID.CURRENT_IN  = 1
   And Ref_AGENT_ID.CLOSURE_DT  is Null
  And Not Exists 
   (  Select 1 
        From  ${KNB_PCO_TMP}.ACT_T_PLACEMENT_EXF_C EXF
         Where EXF.ACTE_ID = Placement.ACTE_ID
    )
 
   Qualify Row_Number() Over(Partition by placement.ACTE_ID order by 1)=1
;

.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_T_PLACEMENT_EXF_C;
.if errorcode <> 0 then .quit 1
----------------------Vider les tables de IHM ----------------------

Delete From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA All  ;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP All  ;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF All ;
.if errorcode <> 0 then .quit 1

.quit 0
