--$HEADER:   %HEADER%
---------------------------------------------------------------------------------------
--
-- NOM FICHIER  : AVM_BPM_ALIM_HOT_ORD_T_ACTE_UNIFIED_H_BPM.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données Oslo dans la table ORD_T_ACTE_UNIFIED_H_BPM 
---------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      creation/MODIFICATION
-- 26/09/2016     ABO         Creation
-- 06/03/2017     MDE         Modif filre (MAJ alimentation à chaud)
-- 13/03/2017     HOB         Modif 
-- 19/04/2017     JCR         Ajout CID/PID/First
-- 31/08/2017     JCR         Propagation nom/prenom de l'agent
-- 01/07/2020     JCR         Ajout colonne SIM_EAN_CD et SIM_CD
---------------------------------------------------------------------------------------
.set width 2000

/*==============================================================*/
/* Delete de la table ORD_T_ACTE_UNIFIED_H_BPM                  */
/*==============================================================*/
Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_BPM;
.if errorcode <> 0 then .quit 1;

/*==============================================================*/
/* Insertion dans la table ORD_T_ACTE_UNIFIED_H_BPM             */
/*==============================================================*/

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_BPM 
(
  ACTE_ID                             ,
  OPERATOR_PROVIDER_ID                ,
  INTRNL_SOURCE_ID                    ,
  TYPE_SOURCE_ID                      ,
  MASTER_ACTE_ID                      ,
  MASTER_INTRNL_SOURCE_ID             ,
  MASTER_FLAG                         ,
  MASTER_NB_FOUND                     ,
  CPLT_ACTE_ID                        ,
  CPLT_INTRNL_SOURCE_ID               ,
  CPLT_IN                             ,
  RULE_ID                             ,
  OFFSET_NB                           ,
  ACT_TYPE                            ,
  ORDER_EXTERNAL_ID                   ,
  STATUS_CD                           ,
  ACT_UNIFIED_STATUS_CD               ,
  ACT_TS                              ,
  ACT_DT                              ,
  ACT_HH                              ,
  ACT_LAST_UPD_TS                     ,
  ACT_PRODUCT_ID_PRE                  ,
  ACT_SEG_COM_ID_PRE                  ,
  ACT_SEG_COM_AGG_ID_PRE              ,
  ACT_CODE_MIGR_PRE                   ,
  ACT_OPER_ID_PRE                     ,
  ACT_PRODUCT_ID_FINAL                ,
  ACT_SEG_COM_ID_FINAL                ,
  ACT_SEG_COM_AGG_ID_FINAL            ,
  ACT_CODE_MIGR_FINAL                 ,
  ACT_OPER_ID_FINAL                   ,
  ACT_TYPE_SERVICE_FINAL              ,
  ACT_TYPE_COMMANDE_ID                ,
  ACT_DELTA_TARIF                     ,
  ACT_CD                              ,
  ACT_REM_ID                          ,
  ACT_FLAG_ACT_REM                    ,
  ACT_FLAG_PEC_PERPVC                 ,
  ACT_FLAG_PVC_REM                    ,
  ACT_ACTE_VALO                       ,
  ACT_ACTE_FAMILLE_KPI                ,
  ACT_PERIODE_ID                      ,
  ACT_PERIODE_STATUS                  ,
  ACT_PERIODE_CLOSURE_DT              ,
  ORIGIN_CD                           ,
  REASON_CD                           ,
  RESULT_CD                           ,
  AGENT_ID                            ,
  AGENT_ID_UPD                        ,
  AGENT_ID_UPD_DT                     ,
  AGENT_FIRST_NAME                    ,
  AGENT_LAST_NAME                     ,
  UNIFIED_SHOP_CD                     ,
  ORG_SPE_CANAL_ID_MACRO              ,
  ORG_SPE_CANAL_ID                    ,
  ORG_REM_CHANNEL_CD                  ,
  ORG_CHANNEL_CD                      ,
  ORG_SUB_CHANNEL_CD                  ,
  ORG_SUB_SUB_CHANNEL_CD              ,
  ORG_GT_ACTIVITY                     ,
  ORG_FIDELISATION                    ,
  ORG_WEB_ACTIVITY                    ,
  ORG_AUTO_ACTIVITY                   ,
  ORG_EDO_ID                          ,
  ORG_TYPE_EDO                        ,
  ORG_FLAG_PLT_CONV                   ,
  ORG_FLAG_TEAM_MKT                   ,
  ORG_FLAG_TYPE_CMP                   ,
  ORG_RESP_EDO_ID                     ,
  ORG_RESP_TYPE_EDO                   ,
  ORG_RESP_FLAG_PLT_CONV              ,
  ACTIVITY_CD                         ,
  ACTIVITY_GROUPNG_CD                 ,
  REAL_ACTIVITY_CD                    ,
  AUTO_ACTIVITY_IN                    ,
  ORG_TYPE_CD                         ,
  ORG_TEAM_TYPE_ID                    ,
  ORG_TEAM_LEVEL_1_CD                 ,
  ORG_TEAM_LEVEL_1_DS                 ,
  ORG_TEAM_LEVEL_2_CD                 ,
  ORG_TEAM_LEVEL_2_DS                 ,
  ORG_TEAM_LEVEL_3_CD                 ,
  ORG_TEAM_LEVEL_3_DS                 ,
  ORG_TEAM_LEVEL_4_CD                 ,
  ORG_TEAM_LEVEL_4_DS                 ,
  WORK_TEAM_LEVEL_1_CD                ,
  WORK_TEAM_LEVEL_1_DS                ,
  WORK_TEAM_LEVEL_2_CD                ,
  WORK_TEAM_LEVEL_2_DS                ,
  WORK_TEAM_LEVEL_3_CD                ,
  WORK_TEAM_LEVEL_3_DS                ,
  WORK_TEAM_LEVEL_4_CD                ,
  WORK_TEAM_LEVEL_4_DS                ,
  CONFIRMATION_IN                     ,
  UNCONFIRM_REASON_LL                 ,
  CONFIRMATION_DT                     ,
  CONFIRMATION_CALC_FIN_DT            ,
  DELIVERY_IN                         ,
  DELIVERY_DT                         ,
  DELIVERY_CALC_FIN_DT                ,
  PERENNITE_IN                        ,
  PERENNITE_FIN_DT                    ,
  PERENNITE_CALC_FIN_DT               ,
  CONCURENCE_IN                       ,
  CONCURENCE_CONCLU_IN                ,
  CONCURENCE_ID                       ,
  CONCLU_PVC_IN                       ,
  PERENNITE_PVC_IN                    ,
  PERENNITE_PVC_FIN_DT                ,
  PERENNITE_PVC_CALC_FIN_DT           ,
  CONCLDD_IN                          ,
  COMPTTN_IN                          ,
  COMPTTN_ID                          ,
  PERNNT_IN                           ,
  PERNNT_END_DT                       ,
  PERNNT_MOTIF                        ,
  PERNNT_CALC_END_DT                  ,
  CONTRCT_NB_MONTH                    ,
  CONTRCT_NB_MONTH_REMAINING          ,
  CONTRCT_DT_SIGN_POST                ,
  MIGRA_DT                            ,
  MIGRA_NEXT_OFFRE                    ,
  RESIL_INT_DT                        ,
  RESIL_INT_MOTIF                     ,
  RESIL_INT_MOTIF_DS                  ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN      ,
  SEGMENT_DELIVERY_IN_PARK_DT         ,
  DELIVERY_ONTIME_IN                  ,
  DELIVERY_DEAD_LINE_NU               ,
  ORDER_CANCELING_DT                  ,
  LINE_ID                             ,
  MASTER_LINE_ID                      ,
  CUST_TYPE_CD                        ,
  MSISDN_ID                           ,
  NDS_VALUE_DS                        ,
  EXTERNAL_PARTY_ID                   ,
  RES_VALUE_DS                        ,
  PAR_ACCES_SERVICE                   ,
  TAC_CD                              ,
  IMEI_CD                             ,
  IMSI_CD                             ,
  HOM_START_DT                        ,
  MOB_START_DT                        ,
  I_SCORE_VALUE                       ,
  I_SCORE_TRESHOLD                    ,
  I_SCORE_IN                          ,
  M_SCORE_VALUE                       ,
  M_SCORE_TRESHOLD                    ,
  M_SCORE_IN                          ,
  OSCAR_VALUE                         ,
  CUST_BU_TYPE_CD                     ,
  CUST_BU_CD                          ,
  ADDRESS_TYPE                        ,
  ADDRESS_CONCAT_NM                   ,
  POSTAL_CD                           ,
  INSEE_CD                            ,
  BU_CD                               ,
  DEPARTMNT_ID                        ,
  PAR_IRIS2000_CD                     ,
  PAR_GEO_MACROZONE                   ,
  PAR_UNIFIED_PARTY_ID                ,
  PAR_PARTY_REGRPMNT_ID               ,
  PAR_CID_ID                          ,
  PAR_PID_ID                          ,
  PAR_FIRST_IN                        ,
  COMMARTICLE_RP_REFPRIX_CD           ,
  ACT_CA_LINE_AM                      ,
  ACT_CA_TTC_AM                       ,
  EAN_CD                              ,
  SIM_CD                              ,
  SIM_EAN_CD                          ,
  ORG_RESP_ID                         ,
  EAN_PREVIOUS_CD                     ,
  TAC_PREVIOUS_CD                     ,
  IMEI_PREVIOUS_CD                    ,
  PCM_PREVIOUS_OFFRE_CD               ,
  PCM_COMMTMNT_PERIOD_NU              ,
  PCM_LEVEL_POINT_NU                  ,
  PCM_OFFRE_CD                        ,
  PCM_EFFCTV_NEXT_OFFRE_DT            ,
  PCM_TYPE_OFFRE_MOBILE_CD            ,
  PCM_POINT_UTIL_NU                   ,
  PCM_BALANCE_POINT_NU                ,
  PCM_STATUT_POINT_CD                 ,
  PCM_POINT_DUE_NU                    ,
  PAR_ELIGIBLE_FIBER_IN               ,
  CHECK_INITIAL_STATUS_CD             ,
  CHECK_NAT_STATUS_CD                 ,
  CHECK_NAT_COMMENT                   ,
  CHECK_NAT_STATUS_LN                 ,
  CHECK_LOC_STATUS_CD                 ,
  CHECK_LOC_COMMENT                   ,
  CHECK_LOC_STATUS_LN                 ,
  CHECK_VALIDT_DT                     ,
  ACT_END_UNIFIED_DT                  ,
  ACT_END_UNIFIED_DS                  ,
  ACT_CLOSURE_DT                      ,
  ACT_CLOSURE_DS                      ,
  HOT_IN                              ,
  RUN_ID                              ,
  QUEUE_TS                            ,
  STREAMING_TS                        ,
  ACT_CREATION_TS                     ,
  EXT_CREATION_TS                     ,
  CREATION_TS                         ,
  LAST_MODIF_TS                       ,
  FRESH_IN                            ,
  COHERENCE_IN                         
)
Select
  ActeRefID.ACTE_ID                                                               As  ACTE_ID                             ,
  NULL                                                                            As  OPERATOR_PROVIDER_ID                ,
  ActeRefID.INTRNL_SOURCE_ID                                                      As  INTRNL_SOURCE_ID                    ,
  'OBK'                                                                           As  TYPE_SOURCE_ID                      ,
  ActeRefID.ACTE_ID                                                               As  MASTER_ACTE_ID                      ,
  ActeRefID.INTRNL_SOURCE_ID                                                      As  MASTER_INTRNL_SOURCE_ID             ,
  ${P_PIL_354}                                                                    As  MASTER_FLAG                         ,
  ${P_PIL_375}                                                                    As  MASTER_NB_FOUND                     ,
  NULL                                                                            As  CPLT_ACTE_ID                        ,
  NULL                                                                            As  CPLT_INTRNL_SOURCE_ID               ,
  '${P_PIL_388}'                                                                  As  CPLT_IN                             ,
  '${P_PIL_362}'                                                                  As  RULE_ID                             ,
  NULL                                                                            As  OFFSET_NB                           ,
 '${P_PIL_325}'                                                                   As  ACT_TYPE                            ,
  Case when ActeRefID.TYPE_LINE = 'I'  
        Then ActeRefID.EXTERNAL_INDCTN_ID
       Else ActeRefID.EXTERNAL_SUBSCRPTN_ID
  End                                                                             As  ORDER_EXTERNAL_ID                   ,
  Case when ActeRefID.STATUS_CD is not null 
         Then ActeRefID.STATUS_CD
       Else ActeRefID.LAST_STATUS_CD
  End                                                                             As  STATUS_CD                           ,
  --'${P_PIL_397}'                                                                As  STATUS_CD                           ,
 '${P_PIL_381}'                                                                   As  ACT_UNIFIED_STATUS_CD               ,
  ActeRefID.ORDER_DEPOSIT_TS                                                      As  ACT_TS                              ,
  ActeRefID.ORDER_DEPOSIT_DT                                                      As  ACT_DT                              ,
  Extract(HOUR From ActeRefID.ORDER_DEPOSIT_TS)                                   As  ACT_HH                              ,
  ActeRefID.LAST_MODIF_TS                                                         As  ACT_LAST_UPD_TS                     ,
  Null                                                                            As  ACT_PRODUCT_ID_PRE                  ,
  Null                                                                            As  ACT_SEG_COM_ID_PRE                  ,
  NULL                                                                            As  ACT_SEG_COM_AGG_ID_PRE              ,
  NULL                                                                            As  ACT_CODE_MIGR_PRE                   ,
  NULL                                                                            As  ACT_OPER_ID_PRE                     ,
 --REFCOM                                                                                                                  
  ActeRefID.ACT_PRODUCT_ID_FINAL                                                  As  ACT_PRODUCT_ID_FINAL                ,
  ActeRefID.ACT_SEG_COM_ID_FINAL                                                  As  ACT_SEG_COM_ID_FINAL                ,
  ActeRefID.ACT_SEG_COM_AGG_ID_FINAL                                              As  ACT_SEG_COM_AGG_ID_FINAL            ,
  NULL                                                                            As  ACT_CODE_MIGR_FINAL                 ,
  'ADD'                                                                           As  ACT_OPER_ID_FINAL                   ,
  ActeRefID.ACT_TYPE_SERVICE_FINAL                                                As  ACT_TYPE_SERVICE_FINAL              ,
  ActeRefID.ACT_TYPE_COMMANDE_ID                                                  As  ACT_TYPE_COMMANDE_ID                ,
  Null                                                                            As  ACT_DELTA_TARIF                     ,
  ActeRefID.ACT_CD                                                                As  ACT_CD                              ,
  ActeRefID.ACTE_REM_ID                                                           As  ACT_REM_ID                          ,
  ActeRefID.FLAG_ACT_REM                                                          As  ACT_FLAG_ACT_REM                    ,
  ActeRefID.FLAG_PEC_PERPVC                                                       As  ACT_FLAG_PEC_PERPVC                 ,
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And ActeRefID.FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And ActeRefID.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And ActeRefID.ORG_REM_CHANNEL_CD IN (${L_PIL_043})
                    --L'acte ne doit pas être annulé
                    And ActeRefID.CLOSURE_FONC_DT         Is Null
                    --Le Flag vente conclue doit être à Oui
                    And CONCLDD_IN = 'O' 
                )
        Then 'O'
        Else 'N'
  End                                                                             As  ACT_FLAG_PVC_REM                    ,
  Coalesce(ActeRefID.ACTE_VALO,0)                                                 As  ACT_ACTE_VALO                       ,
  ActeRefID.ACTE_FAMILLE_KPI                                                      As  ACT_ACTE_FAMILLE_KPI                ,
  ActeRefID.ACT_PERIODE_ID                                                        As  ACT_PERIODE_ID                      ,
  ActeRefID.ACT_PERIODE_STATUS                                                    As  ACT_PERIODE_STATUS                  ,
  ActeRefID.ACT_PERIODE_CLOSURE_DT                                                As  ACT_PERIODE_CLOSURE_DT              ,
  Null                                                                            As  ORIGIN_CD                           ,
  Null                                                                            As  REASON_CD                           ,
  Null                                                                            As  RESULT_CD                           ,
  ActeRefID.ORG_AGENT_ID                                                          As  AGENT_ID                            ,
  ActeRefID.ORG_AGENT_ID_UPD                                                      As  AGENT_ID_UPD                        ,
  ActeRefID.ORG_AGENT_ID_UPD_DT                                                   As  AGENT_ID_UPD_DT                     ,
  ActeRefID.ORG_PRENOM                                                            As  AGENT_FIRST_NAME                    ,
  ActeRefID.ORG_NOM                                                               As  AGENT_LAST_NAME                     ,
  ActeRefID.UNIFIED_SHOP_CD                                                       As  UNIFIED_SHOP_CD                     ,
  Null                                                                            As  ORG_SPE_CANAL_ID_MACRO              ,
  Null                                                                            As  ORG_SPE_CANAL_ID                    ,
  ActeRefID.ORG_REM_CHANNEL_CD                                                    As  ORG_REM_CHANNEL_CD                  ,
  ActeRefID.ORG_CHANNEL_CD                                                        As  ORG_CHANNEL_CD                      ,
  ActeRefID.ORG_SUB_CHANNEL_CD                                                    As  ORG_SUB_CHANNEL_CD                  ,
  ActeRefID.ORG_SUB_SUB_CHANNEL_CD                                                As  ORG_SUB_SUB_CHANNEL_CD              ,
  ActeRefID.ORG_GT_ACTIVITY                                                       As  ORG_GT_ACTIVITY                     ,
  ActeRefID.ORG_FIDELISATION                                                      As  ORG_FIDELISATION                    ,
  ActeRefID.ORG_WEB_ACTIVITY                                                      As  ORG_WEB_ACTIVITY                    ,
  ActeRefID.ORG_AUTO_ACTIVITY                                                     As  ORG_AUTO_ACTIVITY                   ,
  ActeRefID.EDO_ID                                                                As  ORG_EDO_ID                          ,
  ActeRefID.TYPE_EDO_ID                                                           As  ORG_TYPE_EDO                        ,
  ActeRefID.FLAG_PLT_CONV_NB                                                      As  ORG_FLAG_PLT_CONV                   ,
  Null                                                                            As  ORG_FLAG_TEAM_MKT                   ,
  Null                                                                            As  ORG_FLAG_TYPE_CMP                   ,
  Null                                                                            As  ORG_RESP_EDO_ID                     ,
  NULL                                                                            As  ORG_RESP_TYPE_EDO                   ,
  NULL                                                                            As  ORG_RESP_FLAG_PLT_CONV              ,
  Null                                                                            As  ACTIVITY_CD                         ,
  NULL                                                                            As  ACTIVITY_GROUPNG_CD                 ,
  NULL                                                                            As  REAL_ACTIVITY_CD                    ,
  ActeRefID.ORG_AUTO_ACTIVITY                                                     As  AUTO_ACTIVITY_IN                    ,
  Case  When ActeRefID.EDO_ID Is Not Null                                      
          Then 'O3'                                                            
        Else Null                                                              
  End                                                                             As  ORG_TYPE_CD                         ,
  NULL                                                                            As  ORG_TEAM_TYPE_ID                    ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_1_CD)                                             As  ORG_TEAM_LEVEL_1_CD                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_1_DS)                                             As  ORG_TEAM_LEVEL_1_DS                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_2_CD)                                             As  ORG_TEAM_LEVEL_2_CD                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_2_DS)                                             As  ORG_TEAM_LEVEL_2_DS                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_3_CD)                                             As  ORG_TEAM_LEVEL_3_CD                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_3_DS)                                             As  ORG_TEAM_LEVEL_3_DS                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_4_CD)                                             As  ORG_TEAM_LEVEL_4_CD                 ,
  Trim(ActeRefID.ORG_TEAM_LEVEL_4_DS)                                             As  ORG_TEAM_LEVEL_4_DS                 ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_1_CD)                                            As  WORK_TEAM_LEVEL_1_CD                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_1_DS)                                            As  WORK_TEAM_LEVEL_1_DS                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_2_CD)                                            As  WORK_TEAM_LEVEL_2_CD                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_2_DS)                                            As  WORK_TEAM_LEVEL_2_DS                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_3_CD)                                            As  WORK_TEAM_LEVEL_3_CD                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_3_DS)                                            As  WORK_TEAM_LEVEL_3_DS                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_4_CD)                                            As  WORK_TEAM_LEVEL_4_CD                ,
  Trim(ActeRefID.WORK_TEAM_LEVEL_4_DS)                                            As  WORK_TEAM_LEVEL_4_DS                ,
  Null                                                                            As  CONFIRMATION_IN                     ,
  Null                                                                            As  UNCONFIRM_REASON_LL                 ,
  Null                                                                            As  CONFIRMATION_DT                     ,
  Null                                                                            As  CONFIRMATION_CALC_FIN_DT            ,
  Null                                                                            As  DELIVERY_IN                         ,
  Null                                                                            As  DELIVERY_DT                         ,
  Null                                                                            As  DELIVERY_CALC_FIN_DT                ,
  Null                                                                            As  PERENNITE_IN                        ,
  Null                                                                            As  PERENNITE_FIN_DT                    ,
  Null                                                                            As  PERENNITE_CALC_FIN_DT               ,
  Null                                                                            As  CONCURENCE_IN                       ,
  Null                                                                            As  CONCURENCE_CONCLU_IN                ,
  Null                                                                            As  CONCURENCE_ID                       ,
  Null                                                                            As  CONCLU_PVC_IN                       ,
  --Pas de calcul de perenité pour Oslo                                                                                    
  Null                                                                            As  PERENNITE_PVC_IN                    ,
  Null                                                                            As  PERENNITE_PVC_FIN_DT                ,
  Null                                                                            As  PERENNITE_PVC_CALC_FIN_DT           ,
  --Flag Si la vente en conclue                                                                                            
  Case 
      When ActeRefID.CLOSURE_FONC_CD is null    Then 'O'
     
      Else 'N'
  End                                                                             As  CONCLDD_IN                          ,
  --Flag de concurrence                                                                                                    
  ActeRefID.COMPTTN_IN                                                            As  COMPTTN_IN                          ,
  ActeRefID.COMPTTN_ID                                                            As  COMPTTN_ID                          ,
  Null                                                                            As  PERNNT_IN                           ,
  Null                                                                            As  PERNNT_END_DT                       ,
  Null                                                                            As  PERNNT_MOTIF                        ,
  Null                                                                            As  PERNNT_CALC_END_DT                  ,
  Null                                                                            As  CONTRCT_NB_MONTH                    ,
  Null                                                                            As  CONTRCT_NB_MONTH_REMAINING          ,
  Null                                                                            As  CONTRCT_DT_SIGN_POST                ,
  Null                                                                            As  MIGRA_DT                            ,
  Null                                                                            As  MIGRA_NEXT_OFFRE                    ,
  Null                                                                            As  RESIL_INT_DT                        ,
  Null                                                                            As  RESIL_INT_MOTIF                     ,
  Null                                                                            As  RESIL_INT_MOTIF_DS                  ,
  0                                                                               As  PRES_SEGMENT_IN_PARK_BEFORE_IN      ,
  Null                                                                            As  SEGMENT_DELIVERY_IN_PARK_DT         ,
  Null                                                                            As  DELIVERY_ONTIME_IN                  ,
  Null                                                                            As  DELIVERY_DEAD_LINE_NU               ,
  --Date d'annulation d'une ind/souc suite à annulation,retract...                                                         
  ActeRefID.CLOSURE_FONC_DT                                                       As  ORDER_CANCELING_DT                  ,
  ActeRefID.DMC_LINE_ID                                                           As  LINE_ID                             ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.MASTER_LINE_ID
       Else Null
  End                                                                             As  MASTER_LINE_ID                      ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.CUST_BK_ID
       Else Null
  End                                                                             As  CUST_TYPE_CD                        ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.MSISDN_ID
       Else '0000000000'
  End                                                                             As  MSISDN_ID                           ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_ND_DS
       Else '0000000000'
  End                                                                             As  NDS_VALUE_DS                        ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.CLIENT_NU
       Else '0000000000'
  End                                                                             As  EXTERNAL_PARTY_ID                   ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_AID
       Else Null
  End                                                                             As  RES_VALUE_DS                        ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.SERVICE_ACCESS_ID
       Else Null
  End                                                                             As  PAR_ACCES_SERVICE                   ,
  Null                                                                            As  TAC_CD                              ,
  Null                                                                            As  IMEI_CD                             ,
  Null                                                                            As  IMSI_CD                             ,
  Null                                                                            As  HOM_START_DT                        ,
  Null                                                                            As  MOB_START_DT                        ,
  Null                                                                            As  I_SCORE_VALUE                       ,
  Null                                                                            As  I_SCORE_TRESHOLD                    ,
  Null                                                                            As  I_SCORE_IN                          ,
  Null                                                                            As  M_SCORE_VALUE                       ,
  Null                                                                            As  M_SCORE_TRESHOLD                    ,
  Null                                                                            As  M_SCORE_IN                          ,
  Null                                                                            As  OSCAR_VALUE                         ,
  Null                                                                            As  CUST_BU_TYPE_CD                     ,
  Null                                                                            As  CUST_BU_CD                          ,
  '${P_PIL_373}'                                                                  As  ADDRESS_TYPE                        ,
  ActeRefID.BK_SUB_ADRESS_NM                                                      As  ADDRESS_CONCAT_NM                   ,
  ActeRefID.PAR_POSTAL_CD                                                         As  POSTAL_CD                           ,
  --Si client Telco alors on renseigne les informations geographiques                                                      
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_INSEE_NB
       Else Null
  End                                                                             As  INSEE_CD                            ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_BU_CD
       Else Null
  End                                                                             As  BU_CD                               ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_DEPRTMNT_ID
       Else Null
  End                                                                             As  DEPARTMNT_ID                        ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_IRIS2000_CD
       Else Null
  End                                                                             As  PAR_IRIS2000_CD                     ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_GEO_MACROZONE
       Else Null
  End                                                                             As  PAR_GEO_MACROZONE                   ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_UNIFIED_PARTY_ID
       Else Null
  End                                                                             As  PAR_UNIFIED_PARTY_ID                ,
  Case When ActeRefID.DMC_LINE_ID is not null
        Then ActeRefID.PAR_REGRPMNT_ID
       Else Null
  End                                                                             As  PAR_PARTY_REGRPMNT_ID               ,
  Null                                                                            As  PAR_CID_ID                          ,
  Null                                                                            As  PAR_PID_ID                          ,
  Null                                                                            As  PAR_FIRST_IN                        ,
  Null                                                                            As  COMMARTICLE_RP_REFPRIX_CD           ,
  Null                                                                            As  ACT_CA_LINE_AM                      ,
  Null                                                                            As  ACT_CA_TTC_AM                       ,
  ActeRefID.EXTERNAL_PRODUCT_ID                                                   As  EAN_CD                              ,
  Null                                                                            As  SIM_CD                              ,
  Null                                                                            As  SIM_EAN_CD                          ,
  NULL                                                                            As  ORG_RESP_ID                         ,
  NULL                                                                            As  EAN_PREVIOUS_CD                     ,
  NULL                                                                            As  TAC_PREVIOUS_CD                     ,
  NULL                                                                            As  IMEI_PREVIOUS_CD                    ,
  NULL                                                                            As  PCM_PREVIOUS_OFFRE_CD               ,
  NULL                                                                            As  PCM_COMMTMNT_PERIOD_NU              ,
  NULL                                                                            As  PCM_LEVEL_POINT_NU                  ,
  NULL                                                                            As  PCM_OFFRE_CD                        ,
  NULL                                                                            As  PCM_EFFCTV_NEXT_OFFRE_DT            ,
  NULL                                                                            As  PCM_TYPE_OFFRE_MOBILE_CD            ,
  NULL                                                                            As  PCM_POINT_UTIL_NU                   ,
  NULL                                                                            As  PCM_BALANCE_POINT_NU                ,
  NULL                                                                            As  PCM_STATUT_POINT_CD                 ,
  NULL                                                                            As  PCM_POINT_DUE_NU                    ,
  NULL                                                                            As  PAR_ELIGIBLE_FIBER_IN               ,
  Null                                                                            As  CHECK_INITIAL_STATUS_CD             ,
  Null                                                                            As  CHECK_NAT_STATUS_CD                 ,
  Null                                                                            As  CHECK_NAT_COMMENT                   ,
  Null                                                                            As  CHECK_NAT_STATUS_LN                 ,
  Null                                                                            As  CHECK_LOC_STATUS_CD                 ,
  Null                                                                            As  CHECK_LOC_COMMENT                   ,
  Null                                                                            As  CHECK_LOC_STATUS_LN                 ,
  Null                                                                            As  CHECK_VALIDT_DT                     ,
  Null                                                                            As  ACT_END_UNIFIED_DT                  ,
  Null                                                                            As  ACT_END_UNIFIED_DS                  ,
  ActeRefID.CLOSURE_FONC_DT                                                       As  ACT_CLOSURE_DT                      ,
  Case When ActeRefID.CLOSURE_FONC_CD Is Not Null 
        Then 'Acte Clos'                          
  End                                                                             As  ACT_CLOSURE_DS                      ,
  1                                                                               As  HOT_IN                              ,
  ActeRefID.RUN_ID                                                                As  RUN_ID                              ,
  NULL                                                                            As  QUEUE_TS                            ,
  NULL                                                                            As  STREAMING_TS                        ,
  ActeRefID.CREATION_TS                                                           As  ACT_CREATION_TS                     ,
  Current_Timestamp(0)                                                            As  EXT_CREATION_TS                     ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                       As  CREATION_TS                         ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                       As  LAST_MODIF_TS                       ,
  1                                                                               As  FRESH_IN                            ,
  0                                                                               As  COHERENCE_IN                         

From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_BPM  ActeRefID   
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
      On  ActeRefID.ACT_PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                           = 1
      And EtatPeriode.FRESH_IN                             = 1
      And EtatPeriode.CLOSURE_DT                           Is Null

  Where
(1=1)
  And Substr(ActeRefID.ACT_CD,1,3)      Not In (${L_PIL_036})
  And ActeRefID.ACT_SEG_COM_ID_FINAL    <>     '${P_PIL_295}'
  And ActeRefID.ACT_CD                  <>     '${P_PIL_067}'
  And ActeRefID.ORDER_DEPOSIT_DT        >=     Current_date -20
  And ActeRefID.CLOSURE_FONC_DT           Is Null
  And ( EtatPeriode.PERIODE_STATUS is Null Or EtatPeriode.PERIODE_STATUS = 'O' )
  And ActeRefID.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
  And Exists
(
  Select 1
  From ${KNB_PCO_TMP}.ACT_E_ACTE_UNIFIED_BPM RUN
  Where ActeRefID.RUN_ID  = RUN.RUN_ID
);

;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_BPM;
.if errorcode <> 0 then .quit 1;

.quit 0
