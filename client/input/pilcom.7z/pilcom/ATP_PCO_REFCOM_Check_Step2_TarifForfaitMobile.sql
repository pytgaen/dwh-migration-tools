 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_MigrationInternet.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des migrations Internet
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000


Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  5                                                             As REJECT_TYPE_ID         ,
  'AGAP'                                                        As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  'Différence de Tarification de forfait entre REFCOM et ADV ; ( Offre - Libellée - Plateforme ADV - Tarif ADV - Tarif REFCOM ) ; ( '
        ||Coalesce(Trim(RefCom.EXT_PRODUCT_ID1),'')
        ||' - '
        ||OREPLACE(Coalesce(Trim(Rci.PRESFACT_LL_PREST),''),'-','')
        ||' - '
        ||Coalesce(Trim(Rci.PRESFACT_PLTF_CO),'')
        ||' - '
        ||Coalesce(Trim(Rci.PRESFACT_MT_TARIF),'')
        ||' - '
        ||Coalesce(Trim(RefCom.TARIF_HT),'')
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Null                                                          As VolumeCas              ,
  Null                                                          As DateMinRecue           ,
  Null                                                          As DateMaxRecue           
From
  ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_AGAP RefCom
  Inner Join
    (
      Select
        Rci.PRESFACT_CO_FORM      As PRESFACT_CO_FORM     ,
        Rci.PRESFACT_MT_TARIF     As PRESFACT_MT_TARIF    ,
        Rci.PRESFACT_LL_PREST     As PRESFACT_LL_PREST    ,
        Rci.PRESFACT_PLTF_CO      As PRESFACT_PLTF_CO     
      From
        ${KNB_IBU_SOC}.V_TDPRESFACT Rci
      Where
        (1=1)
        And Rci.CURRENT_IN        = 1
      Qualify Row_Number() Over (Partition By Rci.PRESFACT_CO_FORM Order By Rci.PRESFACT_PLTF_CO Asc)=1
     ) Rci
    On    RefCom.EXT_PRODUCT_ID1    = Rci.PRESFACT_CO_FORM
     
Where
  (1=1)
  And RefCom.TYPE_PRODUIT                       = 'OT'
  And RefCom.CURRENT_IN                         = 1
  And RefCom.FRESH_IN                           = 1
  And RefCom.CLOSURE_DT                         Is Null
  And RefCom.PERIODE_ID                         = (Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
  And RefCom.TARIF_HT                           <>  Rci.PRESFACT_MT_TARIF
  And (RefCom.TARIF_HT+Rci.PRESFACT_MT_TARIF    Not In (0.01))
  And Rci.PRESFACT_MT_TARIF                     Not In (0.00)
;
.if errorcode <> 0 Then .quit 1


-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
