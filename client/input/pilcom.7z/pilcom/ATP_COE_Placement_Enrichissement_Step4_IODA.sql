--$HEADER:   mm2pco/current/sql/ATP_COE_Placement_Enrichissement_Step4_IODA.sql 13_05#3 13-NOV-2018 11:14:48 LXQG9925
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_COE_Placement_Enrichissement_IODA.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'Enrichissement CUID 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/10/2018       HOB          Creation
----------------------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_IODA All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Rapprochement IODA/OEE                    ----
----------------------------------------------------------------------------------------------
  Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_IODA
  (  
    ACTE_ID                     ,
    ORDER_DEPOSIT_DT            ,
    OPERATOR_PROVIDER_ID        ,
    EXTRNL_APPLI_SOURCE_ID      ,
    EXTERNAL_ORDER_ID           ,
    ORDR_TYP_CD                 ,
    EXTRNL_CONCLSN_ID           ,
    EXTRNL_DOSSIER_NU           ,
    EXTRNL_CLIENT_NU            ,
    IODA_AGENT_ID               ,
    IODA_SHOP_CD                ,
    IODA_CONTEXT_ORDER  

    )
  Select
    Placement.ACTE_ID                                             as  ACTE_ID                      ,
    Placement.ORDER_DEPOSIT_DT                                    as  ORDER_DEPOSIT_DT             ,
    Placement.OPERATOR_PROVIDER_ID                                as  OPERATOR_PROVIDER_ID         ,
    Placement.EXTRNL_APPLI_SOURCE_ID                              as  EXTRNL_APPLI_SOURCE_ID       ,
    Placement.EXTERNAL_ORDER_ID                                   as  EXTERNAL_ORDER_ID            ,
    Placement.ORDR_TYP_CD                                         as  ORDR_TYP_CD                  ,
    Placement.EXTRNL_CONCLSN_ID                                   as  EXTRNL_CONCLSN_ID            ,
    Placement.EXTRNL_DOSSIER_NU                                   as  EXTRNL_DOSSIER_NU            ,
    Placement.EXTRNL_CLIENT_NU                                    as  EXTRNL_CLIENT_NU             ,
    Context.AGENT_ID                                              as  IODA_AGENT_ID                ,
    Context.ADV_STORE_CD                                          as  IODA_SHOP_CD                 ,
    AGC.ORDER_TYPE_CD                                             as  IODA_CONTEXT_ORDER          
  From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_1  Placement 
       Inner Join ${KNB_COM_SOC}.V_ORD_F_ORDER_AGC_LINE_COM AGC
          On  Placement.EXTRNL_DOSSIER_NU         = AGC.TERMINAL_MSISDN_ID
          And  Placement.ORDER_DEPOSIT_DT        = AGC.ORDER_DEPOSIT_DT
          And  AGC.ORDER_TYPE_CD in ('8','10','12','13')
       Inner Join ${KNB_COM_SOC}.V_ORD_F_ORDER_AGC_COM Context
          On   AGC.CONTEXT_ID         = Context.CONTEXT_ID
     
Where
  (1=1)
  And Placement.ORDR_TYP_CD     ='INITAD'
  And Placement.IODA_AGENT_ID is  null
   Qualify Row_Number() Over (Partition By AGC.CONTEXT_ID ,AGC.ORDER_TYPE_CD Order By Context.QUEUE_TS )=1    ; 

.if errorcode <> 0 then .quit 1            
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_IODA  ; 
.if errorcode <> 0 then .quit 1  
