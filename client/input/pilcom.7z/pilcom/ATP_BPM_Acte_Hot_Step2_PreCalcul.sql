--$HEADER:   mm2pco/current/sql/ATP_BPM_Acte_Hot_Step2_PreCalcul.sql 13_05#8 20-MAR-2018 16:19:10 GXPZ7694
---------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_BPM_Acte_Hot_Step2_PreCalcul.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ORD_W_ACTE_BPM_H_EXT
--
---------------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 14/11/2016     ABO         Création
-- 13/04/2017     JCR         Modification type de commande
-- 03/08/2017     HLA         Modif
-- 23/01/2018     JCR         Modification filtre sur le compte bancaire
-- 09/03/2018     HOB         Conservation d'INIT 
-- 07/08/2020     EVI         PILCOM-638 : Gestion Bundle
---------------------------------------------------------------------------------------

.set width 2000;
-- **************************************************************
-- Alimentation de la table ORD_W_ACTE_BPM_H_EXT
-- **************************************************************

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_BPM_H_EXT;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_BPM_H_EXT
( 
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  EXTERNAL_PRODUCT_ID       ,
  PERIODE_ID                ,
  COMPTE_BK_ID              ,
  TYPE_COMMANDE_ID          ,
  SEG_COM_ID                ,
  CLOSURE_FONC_CD           ,
  EXTERNAL_INDCTN_ID        ,
  EXTERNAL_SUBSCRPTN_ID     ,
  PACKAGE_CD    
)
Select                          
  Sub.ACTE_ID                     ,
  Sub.ORDER_DEPOSIT_DT            ,
  Sub.EXTERNAL_PRODUCT_ID         ,
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )    As PERIODE_ID              ,
  Sub.COMPTE_BK_ID                ,
  Sub.TYPE_COMMANDE_ID            ,
  Sub.SEG_COM_ID                  ,
  Sub.CLOSURE_FONC_CD             ,
  Sub.EXTERNAL_INDCTN_ID          ,
  Sub.EXTERNAL_SUBSCRPTN_ID       ,
  Sub.PACKAGE_CD    

From 
  ( 
   Select
     Placement.ACTE_ID                                         As ACTE_ID                 ,
     cast(Placement.ORDER_DEPOSIT_TS  as date)                 As ORDER_DEPOSIT_DT        ,
     Placement.EXTERNAL_PRODUCT_ID                             As EXTERNAL_PRODUCT_ID     ,
     Placement.COMPTE_BK_ID                                    As COMPTE_BK_ID            ,
     Placement.TYPE_COMMANDE_ID                                As TYPE_COMMANDE_ID        ,
     'BPM'                                                     As SEG_COM_ID              ,
     Placement.CLOSURE_FONC_CD                                 As CLOSURE_FONC_CD         ,
     Placement.EXTERNAL_INDCTN_ID                              As EXTERNAL_INDCTN_ID      ,
     Placement.EXTERNAL_SUBSCRPTN_ID                           As EXTERNAL_SUBSCRPTN_ID   ,
     Placement.PACKAGE_CD                                      As PACKAGE_CD
   From                         
      ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BPM_H Placement
     
    )Sub
  Left outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Periode
        On      Sub.ORDER_DEPOSIT_DT >= Periode.PERIODE_DATE_DEB
            And Sub.ORDER_DEPOSIT_DT <= Periode.PERIODE_DATE_FIN
            And Periode.FRESH_IN         = 1
            And Periode.CURRENT_IN       = 1
            And Periode.CLOSURE_DT       Is Null
Where 
  (1=1)

;       
 .if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_BPM_H_EXT;
.if errorcode <> 0 then .quit 1 





