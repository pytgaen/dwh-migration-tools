--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_GEN_GetInfosCrossActes_ORD_T_ACTE_UNIFIED.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de configuration pour les croissements des actes de la table ORD_T_ACTE_UNIFIED 
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 30/05/2013     CBR         Création
-- 30/08/2018     HOB          Modif Omnicanalité 
---------------------------------------------------------------------------------

.set width 5000

Select 
  MASTER_SOURCE_NM || ' ' || 
  MASTER_INTRNL_SOURCE_ID || ' ' || 
  MASTER_TYPE_SOURCE_ID || ' ' ||
  SLAVE_SOURCE_NM || ' ' || 
  SLAVE_INTRNL_SOURCE_ID || ' ' || 
  SLAVE_TYPE_SOURCE_ID (Title '') 
From ${KNB_PCO_SOC}.V_ORD_R_ACTE_CROSS 
Where  (1=1)
And (MASTER_SOURCE_NM = '${Source}' Or SLAVE_SOURCE_NM = '${Source}')
Order by OMNICANAL ;
.if errorcode <> 0 then .quit 1;

