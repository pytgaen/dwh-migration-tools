-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_MOB_Acte_Cold_Extract_REFCOM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'extraction des actes à froid avec produit refcom pour AGC MOB
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/04/2014      YZH         Creation
-- 09/03/2015      HFO         MODIFICATION (ajout champs CHAPP perennité)
-- 21/03/2016      MDE         Evol : Correction Coalesce sur period_id
-- 07/04/2015      MDE         Evol  : profondeur calcul 100 jrs
-- 20/07/2021      BCH         PILCOM-970 : Migration Assurance Mobile 
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C
(
    ACTE_ID                               ,
    EXTERNAL_ACTE_ID                      ,
    CONTEXT_ID                            ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_DT                      ,
    PERIODE_ID                            ,
    CUSTOMER_CLIENT_NU_ADV                ,
    CUSTOMER_DOSSIER_NU_ADV               ,
    PRODUCT_TYPE                          ,
    PRODUCT_ID                            ,
    SEG_COM_ID                            ,
    SEG_COM_ID_LP                         ,
    SEG_COM_AGG_ID                        ,
    MOUVEMENT                             ,
    TYPE_SERVICE                          ,
    TYPE_SERVICE_LP                       ,
    MIGRATION_REGROUPEMENT_ID             ,
    MIGRATION_POSSIBLE                    ,
    CODE_MIGRATION                        ,
    TARIF_HT                              ,
    EDO_ID                                ,
    RESIL_MOB_DT                          ,
    RESIL_MOB_MOTIF                       ,
    RESIL_MOB_MOTIF_DS                    ,
    PAR_IMSI_CD          
)
Select                                                                                            
    Placement.ACTE_ID                                               as ACTE_ID                    ,
    Placement.EXTERNAL_ACTE_ID                                      as EXTERNAL_ACTE_ID           ,
    Placement.CONTEXT_ID                                            as CONTEXT_ID                 ,
    Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
    Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
    Coalesce(Periode.PERIODE_ID                  ,${P_PIL_049}  )   as PERIODE_ID                 ,
    Placement.CUSTOMER_CLIENT_NU_ADV                                as CUSTOMER_CLIENT_NU_ADV     ,
    Placement.CUSTOMER_DOSSIER_NU_ADV                               as CUSTOMER_DOSSIER_NU_ADV    ,
    Placement.PRODUCT_TYPE                                          as PRODUCT_TYPE               ,
    Coalesce(Refcom.PRODUCT_ID                  ,'${P_PIL_223}')    as PRODUCT_ID                 ,
    Coalesce(Refcom.SEG_COM_ID                  ,'${P_PIL_022}')    as SEG_COM_ID                 ,
    Coalesce(RefProduitLastPer.SEG_COM_ID       ,'${P_PIL_022}')    as SEG_COM_ID_LP              ,
    Coalesce(Refcom.SEG_COM_AGG_ID              ,'${P_PIL_022}')    as SEG_COM_AGG_ID             ,
    Placement.MOUVEMENT                                             as MOUVEMENT                  ,
    Refcom.TYPE_SERVICE                                             as TYPE_SERVICE               ,
    RefProduitLastPer.TYPE_SERVICE                                  as TYPE_SERVICE_LP            ,
    Coalesce(Refcom.MIGRATION_REGROUPEMENT_ID   ,'${P_PIL_023}')    as MIGRATION_REGROUPEMENT_ID  ,
    Coalesce(Refcom.MIGRATION_POSSIBLE          ,'${P_PIL_020}')    as MIGRATION_POSSIBLE         ,
    Coalesce(Refcom.CODE_MIGRATION              ,'${P_PIL_024}')    as CODE_MIGRATION             ,
    Coalesce(Refcom.TARIF_HT                    ,0)                 as TARIF_HT                   ,
    Placement.EDO_ID                                                as EDO_ID                     ,
    Placement.RESIL_MOB_DT                                          as RESIL_MOB_DT               ,
    Placement.RESIL_MOB_MOTIF                                       as RESIL_MOB_MOTIF            ,
    Placement.RESIL_MOB_MOTIF_DS                                    as RESIL_MOB_MOTIF_DS         ,
    Placement.PAR_IMSI_CD                                           as PAR_IMSI_CD                
From  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_AGC_MOB Placement
Left Outer Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Periode
      On  Placement.ORDER_DEPOSIT_DT     >=    Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT     <=    Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                =    1
      And Periode.CURRENT_IN              =    1
      And Periode.CLOSURE_DT             Is Null
Left Outer Join  ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB Refcom
      On  Placement.EXTERNAL_PRODUCT_ID   =    Refcom.EXT_PRODUCT_ID
      And Placement.PRODUCT_TYPE          =    Refcom.TYPE_PRODUIT
      And Periode.PERIODE_ID              =    Refcom.PERIODE_ID
-- Calcul du segment de la derniere periode, pour la perennité
Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB RefProduitLastPer
      On  Placement.EXTERNAL_PRODUCT_ID   =    RefProduitLastPer.EXT_PRODUCT_ID
      And Placement.PRODUCT_TYPE          =    RefProduitLastPer.TYPE_PRODUIT
      And RefProduitLastPer.PERIODE_ID    =   (
                                                Select
                                                  Max(PERIODE_ID)
                                                From
                                                  ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM
                                                Where
                                                  (1=1)
                                                And CURRENT_IN=1
                                                And CLOSURE_DT Is Null
                                               )
      
Where                                1    =    1
And       Placement.ORDER_TYPE_CD        <>    '6'                  -- On exclut les commandes prépayées
And       Placement.ORDER_DEPOSIT_DT              >= (Current_date - ${P_PIL_523}) 
--And       Placement.CLOSURE_DT          Is Null
;                          
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_MOB_REFCOM_C;
.if errorcode <> 0 then .quit 1

.quit 0
