-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_HRF_ACTE_ENRI_PRDT_PRCD.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Perimetre RF - ACTE - IDENTIFICATION DU PRODUIT PRECEDENT -
--
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 05/08/13        DARTIGUE    Creation
-- 03/09/2014      GMA          Evolution sur le VIO
-- 08/09/2014      GMA          Evol Stabilisation du produit précédant
---------------------------------------------------------------------------------

.SET WIDTH 2000;

-- MISE A JOUR DU PRODUIT PRECEDENT POUR LES INTERACTIONS DONT LE PRODUIT PLACE N'EST PAS UNE OFFRE D'ACCES RTC

UPDATE           ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
FROM              (
                    SELECT   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN                                                                                                                                  AS T_ACTE_ID_GEN
                           , INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                                                                                      AS T_ACTE_ID
                           , COALESCE(V_INB_F_PART_INB_HRF.CANCELLNG_DT, CAST('${KNB_PCO_DEFAULT_DT}' AS DATE FORMAT '${KNB_PCO_FORMAT_DT_TECH}'))                                        AS T_CANCELLNG_DT
                           , V_INB_F_PART_INB_HRF.PRODUCT_ID                                                                                                                              AS T_PRODUCT_ID
                           , ROW_NUMBER() OVER (
                                                 PARTITION BY  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN
                                                             , INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID
                                                 ORDER BY      T_CANCELLNG_DT ASC
                                                             , V_INB_F_PART_INB_HRF.REALZTN_DT Desc
                                                             , CAT_W_OPENCAT_REFCOM.SEG_COM_ID Asc
                                               )                                                                                                                                          AS T_TECH

                    FROM   ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM                                                                                                                                    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
                    JOIN   ${KNB_PCO_SOC}.V_INB_F_PART_INB_HRF                                                                                                                               V_INB_F_PART_INB_HRF
                    ON       1                                                                                                                                                     =         1
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.SERVICE_ACCESS_ID                                                                                                                     =         V_INB_F_PART_INB_HRF.SERVICE_ACCESS_ID
                    JOIN   ${KNB_PCO_TMP}.CAT_W_OPENCAT_REFCOM                                                                                                                               CAT_W_OPENCAT_REFCOM
                    ON       1                                                                                                                                                     =         1
                    AND      V_INB_F_PART_INB_HRF.PRODUCT_ID                                                                                                                       =         CAT_W_OPENCAT_REFCOM.PRODUCT_ID
                    WHERE    1                                                                                                                                                     =         1
                  -- SEULES LES OFFRES D'ACCES OPENCAT DONT LA PERIODE DE VALIDITE INCLUE LA DATE DE L'INTERACTION SONT CONSIDEREES
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                                                                    >          V_INB_F_PART_INB_HRF.REALZTN_DT
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT - 2                                                                                                                <=         T_CANCELLNG_DT
                  -- SEULE LA PERIODE COMMERCIALE CORRESPONDANTE A LA DATE DE L'INTERACTION EST CONSIDEREE
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                                                                     BETWEEN   CAT_W_OPENCAT_REFCOM.PERIODE_DATE_DEB
                                                                                                                                                                                   AND       CAT_W_OPENCAT_REFCOM.PERIODE_DATE_FIN
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT                                                                                                    NOT IN (${L_PIL_049})
                  -- SEULS LES EDP NON SUPPRIMES LOGIQUEMENT SONT CONSIDERES
                    AND      V_INB_F_PART_INB_HRF.CLOSRE_DT                                                                                                                        IS NULL
                  -- SELECTION EXCLUSIVE DES PRODUITS OPENCAT CORRESPONDANT A DES OFFRES D'ACCES NON RTC DANS LE REFERENTIEL OPENCAT REFCOM
                    AND      CAT_W_OPENCAT_REFCOM.TYPE_SERVICE                                                                                                                     IN     (${L_PIL_019})
                  -- SELECTION EXCLUSIVE DES INTERACTIONS DONT LE PRODUIT PLACE N'EST PAS UNE OFFRE D'ACCES RTC
                    AND      COALESCE(INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.TYPE_SERVICE, '${P_PIL_211}')                                                                                               <>      '${P_PIL_247}'
                  -- Ajout pour supprimer les données NS
                    AND      CAT_W_OPENCAT_REFCOM.SEG_COM_ID Not In ('NS','ND')
                  -- SEUL LE PRODUIT DONT LA DATE D'INSTALLATION EST LA PLUS RECENTE EST CONSERVE
                    QUALIFY  T_TECH                                                                                                                                                =         1
                  ) T (
                        T_ACTE_ID_GEN
                      , T_ACTE_ID
                      , T_CANCELLNG_DT
                      , T_PRODUCT_ID
                      , T_TECH
                      )               
SET                INTRNL_PRDCT_ID_OPENCAT_INI                       =         T.T_PRODUCT_ID
WHERE              1                                                 =         1
AND                ACTE_ID_GEN                                       =         T.T_ACTE_ID_GEN
AND                ACTE_ID                                           =         T.T_ACTE_ID
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- MISE A JOUR DU PRODUIT PRECEDENT POUR LES INTERACTIONS DONT LE PRODUIT PLACE EST UNE OFFRE D'ACCES RTC

UPDATE           ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
FROM              (
                    SELECT   INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN                                                                                                                                  AS T_ACTE_ID_GEN
                           , INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID                                                                                                                                      AS T_ACTE_ID
                           , COALESCE(V_INB_F_PART_INB_HRF.CANCELLNG_DT, CAST('${KNB_PCO_DEFAULT_DT}' AS DATE FORMAT '${KNB_PCO_FORMAT_DT_TECH}'))                                        AS T_CANCELLNG_DT
                           , V_INB_F_PART_INB_HRF.PRODUCT_ID                                                                                                                              AS T_PRODUCT_ID
                           , ROW_NUMBER() OVER (
                                                 PARTITION BY  INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID_GEN
                                                             , INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.ACTE_ID
                                                 ORDER BY      T_CANCELLNG_DT ASC
                                                             , V_INB_F_PART_INB_HRF.REALZTN_DT Desc
                                                             , CAT_W_OPENCAT_REFCOM.SEG_COM_ID Asc
                                               )                                                                                                                                          AS T_TECH

                    FROM   ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM                                                                                                                                    INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
                    JOIN   ${KNB_PCO_SOC}.V_INB_F_PART_INB_HRF                                                                                                                               V_INB_F_PART_INB_HRF
                    ON       1                                                                                                                                                     =         1
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.SERVICE_ACCESS_ID                                                                                                                     =         V_INB_F_PART_INB_HRF.SERVICE_ACCESS_ID
                    JOIN   ${KNB_PCO_TMP}.CAT_W_OPENCAT_REFCOM                                                                                                                               CAT_W_OPENCAT_REFCOM
                    ON       1                                                                                                                                                     =         1
                    AND      V_INB_F_PART_INB_HRF.PRODUCT_ID                                                                                                                       =         CAT_W_OPENCAT_REFCOM.PRODUCT_ID
                    WHERE    1                                                                                                                                                     =         1
                  -- SEULES LES OFFRES D'ACCES OPENCAT DONT LA PERIODE DE VALIDITE INCLUE LA DATE DE L'INTERACTION SONT CONSIDEREES
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                                                                    >          V_INB_F_PART_INB_HRF.REALZTN_DT
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT - 2                                                                                                                <=         T_CANCELLNG_DT
                  -- SEULE LA PERIODE COMMERCIALE CORRESPONDANTE A LA DATE DE L'INTERACTION EST CONSIDEREE
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_CREATED_BY_DT                                                                                                                     BETWEEN   CAT_W_OPENCAT_REFCOM.PERIODE_DATE_DEB
                                                                                                                                                                                   AND       CAT_W_OPENCAT_REFCOM.PERIODE_DATE_FIN
                  -- Pas de VIO
                    AND     INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.INT_RESULT                                                                                                     NOT IN (${L_PIL_049})
                  -- SEULS LES EDP NON SUPPRIMES LOGIQUEMENT SONT CONSIDERES
                    AND      V_INB_F_PART_INB_HRF.CLOSRE_DT                                                                                                                        IS NULL
                  -- SELECTION EXCLUSIVE DES PRODUITS OPENCAT CORRESPONDANT A DES OFFRES D'ACCES NON RTC DANS LE REFERENTIEL OPENCAT REFCOM
                    AND      CAT_W_OPENCAT_REFCOM.TYPE_SERVICE                                                                                                                     =      '${P_PIL_247}'
                  -- SELECTION EXCLUSIVE DES INTERACTIONS DONT LE PRODUIT PLACE N'EST PAS UNE OFFRE D'ACCES RTC
                    AND      INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM.TYPE_SERVICE                                                                                                                          =      '${P_PIL_247}'
                  -- Ajout pour supprimer les données NS
                    AND      CAT_W_OPENCAT_REFCOM.SEG_COM_ID Not In ('NS','ND')
                  -- SEUL LE PRODUIT DONT LA DATE D'INSTALLATION EST LA PLUS RECENTE EST CONSERVE
                    QUALIFY  T_TECH                                                                                                                                                =         1
                  ) T (
                        T_ACTE_ID_GEN
                      , T_ACTE_ID
                      , T_CANCELLNG_DT
                      , T_PRODUCT_ID
                      , T_TECH
                      )               
SET                INTRNL_PRDCT_ID_OPENCAT_INI                       =         T.T_PRODUCT_ID
WHERE              1                                                 =         1
AND                ACTE_ID_GEN                                       =         T.T_ACTE_ID_GEN
AND                ACTE_ID                                           =         T.T_ACTE_ID
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

Update RefId
From
  ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM RefId  ,
  (
    Select
      RefId.ACTE_ID         as ACTE_ID      ,
      RefId.ACTE_ID_GEN     as ACTE_ID_GEN  ,
      RefCom.PRODUCT_ID     as PRODUCT_ID
    From
      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM RefId
      Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_PCAFUS_O RefParcPCA
        On    RefId.SERVICE_ACCESS_ID     =   RefParcPCA.SERVICE_ACCESS_ID
          And RefId.INT_CREATED_BY_DT     >  RefParcPCA.REALZTN_DT
          And RefParcPCA.TYPE_SERVICE     =  '${P_PIL_443}'
      Inner Join ${KNB_PCO_TMP}.CAT_W_OPENCAT_REFCOM RefCom
        On    RefParcPCA.SEG_COM_ID       =   RefCom.SEG_COM_ID
          And RefId.INT_CREATED_BY_DT     Between RefCom.PERIODE_DATE_DEB And RefCom.PERIODE_DATE_FIN
          And RefCom.TYPE_SERVICE         =  '${P_PIL_443}'
          And RefCom.SEG_COM_ID           Not In ('NS','ND')
      Inner Join ${KNB_PCO_SOC}.V_INB_F_PART_INB_HRF Parc
        On    RefCom.PRODUCT_ID           =   Parc.PRODUCT_ID
          And RefId.SERVICE_ACCESS_ID     =   Parc.SERVICE_ACCESS_ID
    Where
      (1=1)
      And RefId.INT_RESULT IN (${L_PIL_049})
    Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ACTE_ID_GEN Order by RefParcPCA.REALZTN_DT desc, RefParcPCA.CANCELLNG_DT desc)=1
  )CalcTmp
Set
  INTRNL_PRDCT_ID_OPENCAT_INI = CalcTmp.PRODUCT_ID
Where
  (1=1)
  And RefId.ACTE_ID       = CalcTmp.ACTE_ID
  And RefId.ACTE_ID_GEN   = CalcTmp.ACTE_ID_GEN
;
.IF ERRORCODE <> 0 THEN .QUIT 1;

