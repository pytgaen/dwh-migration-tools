-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step3_CalculPerenniteVerifActionClient.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul de la date action client pour la partie internet de la commande
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/05/2014      HFO         Creation
-- 23/06/2014      HFO         Modification : Ajout du champ motif de perte de pérénnité
-- 15/12/2013      HFO         MODIFICATION (alim debut et fin de commercialisation)
-- 22/01/2015      HFO         MODIFICATION
-- 23/01/2015      HFO         Mise en norme suite Patch  G13R00C22P01 correction Post MEP S052015
--------------------------------------------------------------------------------

.set width 2500;

--On vide les table de dedoublonnage pour donner de l'espace

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_INT_CMD All ;
.if errorcode <> 0 then .quit 1
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_INT_LIN_CMD All ;
.if errorcode <> 0 then .quit 1

--On vide les table à charger
Delete From ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_OPT All ;
.if errorcode <> 0 then .quit 1

Delete From ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_FORF All ;
.if errorcode <> 0 then .quit 1

--Pour les options : les suppressions

Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_OPT
(
  ACTE_ID                               ,
  ORDER_DEPOSIT_DT                      ,
  ACCES_SERVICE_ID                      ,
  PERNNT_IN                             ,
  PERNNT_END_DT                         ,
  PERNNT_MOTIF                          ,
  SEG_COM_ID_FINAL_ORDER                 
)
Select
  Acte.ACTE_ID                                                    As ACTE_ID                        ,
  Acte.ORDER_DEPOSIT_DT                                           As ORDER_DEPOSIT_DT               ,
  RefCmd.ACCES_SERVICE_ID                                         As ACCES_SERVICE_ID               ,
  --On applique la règle : si suppression alors pas pérenne
  Case  When  (Acte.ORDER_DEPOSIT_DT = RefCmd.ORDR_DT  And RefCmd.START_DT <= Acte.ORDER_DEPOSIT_DT + 60)
          Then  'N'
        -- si la date de résiliation programmée est supérieur date de commande plus 60 jours alors on reste pérenne
        When Acte.ORDER_DEPOSIT_DT = RefCmd.ORDR_DT
          Then  'O'
        Else    'N'
  End                                                             As PERNNT_IN                      ,
  Case  When  (Acte.ORDER_DEPOSIT_DT = RefCmd.ORDR_DT  And RefCmd.START_DT <= Acte.ORDER_DEPOSIT_DT + 60)
          Then  RefCmd.ORDR_DT
        -- si la date de résiliation programmée est supérieur date de commande plus 60 jours alors on reste pérenne
        When Acte.ORDER_DEPOSIT_DT = RefCmd.ORDR_DT
          Then  Null
        Else    RefCmd.ORDR_DT
  End                                                             As PERNNT_END_DT                  ,
  Case  When  (Acte.ORDER_DEPOSIT_DT = RefCmd.ORDR_DT  And RefCmd.START_DT <= Acte.ORDER_DEPOSIT_DT + 60)
          Then  'Suppression Option'
        -- si la date de résiliation programmée est supérieur date de commande plus 60 jours alors on reste pérenne
        When Acte.ORDER_DEPOSIT_DT = RefCmd.ORDR_DT
          Then  Null
        Else    'Suppression Option'
  End                                                             As PERNNT_MOTIF                  ,
  Acte.SEG_COM_ID                                                 As SEG_COM_ID_FINAL_ORDER          
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI Acte
  Inner Join  ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM RefCmd
    On    Acte.SERVICE_ACCESS_ID          =   RefCmd.ACCES_SERVICE_ID 
      And Acte.SEG_COM_ID                 =   RefCmd.SEG_COM_ID
      And Acte.ORDER_DEPOSIT_DT           <=  RefCmd.ORDR_DT
      And RefCmd.ORDR_DT                  <=  (Acte.ORDER_DEPOSIT_DT + 60)
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  And Acte.EXT_OPER_ID          In ('ADD') 
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID           Not In ('NS','OPTTECH','OPT_INC')
  And Acte.SERVICE_ACCESS_ID    Is Not Null
  -- On filtre les commande pas KO
  And RefCmd.STAT_MVT           Not In ('K')
  --On recherche les Suppression :
  And RefCmd.TYPE_ORDR_CD       In ('S')
  --On ne gère que les options 
  And RefCmd.TYPE_SERVICE       Not In ('OFFCONV', 'OFFINT','OFFCONVINT','OFFQD','OFFFIX','OFFMOB')
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order By RefCmd.ORDR_DT Desc ) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stats On ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_OPT;
.if errorcode <> 0 then .quit 1

---------------------------------------------------------------------------------------------------------------
--Pour les offres
---------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_FORF All ;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_FORF
(
  ACTE_ID                               ,
  ORDER_DEPOSIT_DT                      ,
  ACCES_SERVICE_ID                      ,
  PERNNT_IN                             ,
  PERNNT_END_DT                         ,
  PERNNT_MOTIF                          ,
  SEG_COM_ID_FINAL_ORDER                
)
Select
  Acte.ACTE_ID                                                    As ACTE_ID                      ,
  Acte.ORDER_DEPOSIT_DT                                           As ORDER_DEPOSIT_DT             ,
  RefOffre.ACCES_SERVICE_ID                                       As ACCES_SERVICE_ID             ,
  --s'il a souscrit à une nouvelle offre. Si acte plus recent  et pas meme segment => Non perenne
  --Si il migre vers une offre com lancé après la cmd de l'acte 1 => Perenne
  Case  When RefOffre.START_DT >=  Acte.ORDER_DEPOSIT_DT
          Then  'O'
  --Si la date de debut du nouveau seg est > date de debut de l'ancien alors perenne
        When (RefOffre.START_DT <  Acte.ORDER_DEPOSIT_DT) And (RefOffre.START_COMM_DT > Acte.ORDER_DEPOSIT_DT)
          Then 'O'
        Else    'N'
  End                                                             As PERNNT_IN                     ,
  Case  When RefOffre.START_DT >=  Acte.ORDER_DEPOSIT_DT
          Then  Null
  --Si la date de debut du nouveau seg est > date de debut de l'ancien alors perenne
        When (RefOffre.START_DT <  Acte.ORDER_DEPOSIT_DT) And (RefOffre.START_COMM_DT > Acte.ORDER_DEPOSIT_DT)
          Then Null
        Else    RefOffre.ORDR_DT
  End                                                             As PERNNT_END_DT                 ,
  Case When RefOffre.START_DT >=  Acte.ORDER_DEPOSIT_DT
          Then Null
  --Si la date de debut du nouveau seg est > date de debut de l'ancien alors perenne
        When (RefOffre.START_DT <  Acte.ORDER_DEPOSIT_DT) And (RefOffre.START_COMM_DT > Acte.ORDER_DEPOSIT_DT)
          Then Null
       Else 'Migration'
  End                                                             As PERNNT_MOTIF                  ,
  RefOffre.SEG_COM_ID                                             As SEG_COM_ID_FINAL_ORDER        
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_ELI Acte
  Inner Join  ${KNB_PCO_TMP}.ORD_W_ORDRE_PSF_REFCOM_OFFRE RefOffre
    On    Acte.SERVICE_ACCESS_ID          =   RefOffre.ACCES_SERVICE_ID 
      And Acte.ORDER_DEPOSIT_DT           <=  RefOffre.ORDR_DT
      And RefOffre.ORDR_DT                <=  (Acte.ORDER_DEPOSIT_DT + 60)
      --Code produit sont différents
      And Acte.SEG_COM_ID                 <>  RefOffre.SEG_COM_ID
Where
  (1=1)
  --And Acte.ACTE_OPERTR_ID_COMPST_OFFR In ('MIGRA','CREAT')
  And Acte.EXT_OPER_ID                In ('ADD') 
  And Acte.SEG_COM_ID                 Not In ('NS','OPTTECH','OPT_INC')
  And Acte.SERVICE_ACCESS_ID          Is Not Null
  -- On filtre les ordres Pas KO
  And RefOffre.STAT_MVT               Not In ('K')
  --On recherche les annulation :
  And RefOffre.TYPE_ORDR_CD           In ('A')
  --On ne gère que les Forfait 
  And Acte.TYPE_SERVICE               In ('OFFCONV', 'OFFINT','OFFCONVINT','OFFQD','OFFFIX')
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order by RefOffre.ORDR_DT Desc)=1
;
.if errorcode <> 0 then .quit 1



Collect Stats On ${KNB_PCO_TMP}.INT_W_ACTE_SOFT_PERENITE_FORF;
.if errorcode <> 0 then .quit 1



.quit 0

