-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:ATP_PER_CalculPerenniteActe_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de génération des identifiants Internes
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     GMA         Création
-- 06/02/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;


Delete from ${KNB_PCO_TMP}.ORD_T_CALC_ACT_VAD_PER all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_CALC_ACT_VAD_PER
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  CONFIRMATION_IN           ,
  CONFIRMATION_DT           ,
  CONFIRMATION_CALC_FIN_DT  ,
  DELIVERY_IN               ,
  DELIVERY_DT               ,
  DELIVERY_CALC_FIN_DT      ,
  PERENNITE_IN              ,
  PERENNITE_FIN_DT          ,
  PERENNITE_CALC_FIN_DT     
)
Select
  CalculTmp.ACTE_ID                   as ACTE_ID                  ,
  CalculTmp.ORDER_DEPOSIT_DT          as ORDER_DEPOSIT_DT         ,
  --Calcul de la confirmation
  CalculTmp.CONFIRMATION_IN           as CONFIRMATION_IN          ,
  CalculTmp.CONFIRMATION_DT           as CONFIRMATION_DT          ,
  CalculTmp.CONFIRMATION_CALC_FIN_DT  as CONFIRMATION_CALC_FIN_DT ,
  --Calcul de la livraison
  CalculTmp.DELIVERY_IN               as DELIVERY_IN               ,
  CalculTmp.DELIVERY_DT               as DELIVERY_DT               ,
  CalculTmp.DELIVERY_CALC_FIN_DT      as DELIVERY_CALC_FIN_DT      ,
  --Calcul de Pérénité
  Case  When  CalculTmp.CONFIRMATION_IN='O'
          Then  CalculTmp.PERENNITE_IN
        Else  'NA'
  End                                 as PERENNITE_IN              ,
  Case  When  CalculTmp.CONFIRMATION_IN='O'
          Then  CalculTmp.PERENNITE_FIN_DT
        Else  Null
  End                                 as PERENNITE_FIN_DT          ,
  Case  When  CalculTmp.CONFIRMATION_IN='O'
          Then  CalculTmp.PERENNITE_CALC_FIN_DT
        Else  Null
  End                                 as PERENNITE_CALC_FIN_DT     
From
  (
    Select
      RefId.ACTE_ID                   as ACTE_ID                ,
      RefId.DATE_SAISIE               as ORDER_DEPOSIT_DT       ,
      -----------------------------------------------------------------------------------------------------
      --Flag de confirmation
      Case  When RefAct.CONFIRMATION_CALC_FIN_DT Is Not Null -- le calcul à déjà eu lieu pour cet ID
              Then  RefAct.CONFIRMATION_IN --Alors on remet la valeur précédement calculée
            Else  --Dans le cas où la commande n'est pas validée
              Case  When (RefId.DATE_CONFIRMATION is not null) --Si la commande est validée alors OK
                        Then 'O'
                    Else 'N'
              End
      End                             as CONFIRMATION_IN          ,
      --Date de confirmation
      Case  When RefAct.CONFIRMATION_CALC_FIN_DT Is Not Null -- le calcul à déjà eu lieu pour cet ID
                Then  RefAct.CONFIRMATION_DT --Alors on remet la valeur précédement calculée
            Else  --Dans le cas où la commande n'est pas validée
              Case  When (RefId.DATE_CONFIRMATION is not null) --Si la commande est validée alors OK
                        Then RefId.DATE_CONFIRMATION
                    Else Null
              End
      End                             as CONFIRMATION_DT          ,
      --Date de dernier calcul de la confirmation
      Case  When RefAct.CONFIRMATION_CALC_FIN_DT Is Not Null --Si la commande n'est pas validée mais que le
                --Dernier calcul est valorisé (Cas > 200 jours on ne calcul plus)
                Then RefAct.CONFIRMATION_CALC_FIN_DT
            When (RefId.DATE_CONFIRMATION is not null) --Si la commande est validée alors OK
                Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
            When ( RefId.DATE_SAISIE + ${P_PIL_055} ) <= Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
            Else Null
      End                             as CONFIRMATION_CALC_FIN_DT  ,
      -----------------------------------------------------------------------------------------------------
      --Flag de livraison
      Case  When RefAct.DELIVERY_CALC_FIN_DT Is Not Null -- le calcul à déjà eu lieu pour cet ID
              Then  RefAct.DELIVERY_IN --Alors on remet la valeur précédement calculée
            Else  --Dans le cas où la commande n'est pas validée
              Case  When RefId.DATE_LIVRAISON is not Null --Si la commande est validée alors OK
                        Then 'O'
                    Else 'N'
              End
      End                             as DELIVERY_IN            ,
      --Date de livraison
      Case  When RefAct.DELIVERY_CALC_FIN_DT Is Not Null -- le calcul à déjà eu lieu pour cet ID
              Then  RefAct.DELIVERY_DT --Alors on remet la valeur précédement calculée
            Else  --Dans le cas où la commande n'est pas validée
              Case  When RefId.DATE_LIVRAISON is not Null --Si la commande est validée alors OK
                        Then RefId.DATE_LIVRAISON
                    Else Null
              End
      End                             as DELIVERY_DT            ,
      --Date de dernier calcul de la confirmation
      Case  When RefAct.DELIVERY_CALC_FIN_DT Is Not Null --Si la commande n'est pas validée mais que le
                --Dernier calcul est valorisé (Cas > 200 jours on ne calcul plus)
                Then RefAct.DELIVERY_CALC_FIN_DT
            When (RefId.DATE_LIVRAISON is not Null) --Si la commande est validée alors OK
                Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
            When ( RefId.DATE_SAISIE + ${P_PIL_055} ) <= Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
            Else Null
      End                             as DELIVERY_CALC_FIN_DT   ,
      -----------------------------------------------------------------------------------------------------
      --Flag de Pérénnité :
      Case  When RefAct.PERENNITE_CALC_FIN_DT is not null  -- le calcul à déjà eu lieu pour cet ID
              Then RefAct.PERENNITE_IN  --Alors on remet la valeur précédement calculée
            Else  --Sinon on regarde si la parc n'est pas cloturé
              Case  When RefId.DATE_FIN_PERENNITE is not Null --Si le parc est cloturé alors 
                        Then 'N'
                    Else 'O'
              End
      End                             as PERENNITE_IN           ,
      --Dans de Fin de présence en parc
      Case  When RefAct.PERENNITE_CALC_FIN_DT is not null  -- le calcul à déjà eu lieu pour cet ID
              Then RefAct.PERENNITE_FIN_DT  --Alors on remet la valeur précédement calculée
            Else  --Sinon on regarde si la parc n'est pas cloturé
              Case  When RefId.DATE_FIN_PERENNITE is not Null --Si le parc est cloturé alors 
                        Then RefId.DATE_FIN_PERENNITE
                    Else Null
              End
      End                             as PERENNITE_FIN_DT       ,
      --Dans de Fin de calcul de présence en parc
      Case  When RefAct.PERENNITE_CALC_FIN_DT Is Not Null --Si la commande n'est pas validée mais que le
                --Dernier calcul est valorisé (Cas > 200 jours on ne calcul plus)
                Then RefAct.PERENNITE_CALC_FIN_DT
            When RefId.DATE_FIN_PERENNITE Is not Null
                --Dans le cas ou la commande n'est pas pérènne :
                Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
            When ( RefId.DATE_SAISIE + ${P_PIL_055} ) <= Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
                Then Cast('${KNB_VACATION_PDATE}' as Date Format 'YYYYMMDD')
            Else Null
      End                             as PERENNITE_CALC_FIN_DT  
    From
      ${KNB_PCO_TMP}.ORD_T_ENRI_ACT_VAD_PERFIN RefId
      Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_VAD  RefAct
        On    RefId.ACTE_ID           = RefAct.ACTE_ID
          And RefId.DATE_SAISIE       = RefAct.ORDER_DEPOSIT_DT
  )CalculTmp
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_CALC_ACT_VAD_PER;
.if errorcode <> 0 then .quit 1

