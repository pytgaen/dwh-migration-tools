-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_OEE_Placement_Consolidation_Enrichissement_Step1_ParcPrecedent.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Enrichissement Parc Precedent
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 27/03/2014      AID         Indus
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_PARCPRE all;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_PARCPRE
(
  ACTE_ID                 ,
  INT_DEPOSIT_DT          ,
  PRESFACT_CO_PRECED      
)
Select
  RefId.ACTE_ID                             as ACTE_ID                ,
  RefId.INT_DEPOSIT_DT                      as INT_DEPOSIT_DT         ,
  Prestation.PRESFACT_CO_FORM               as PRESFACT_CO_PRECED     
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TFSRVFCDOS ParcADV
    On    RefId.DOSSIER_NU                = ParcADV.SRVFCDOS_DOSSIER_NU
      And RefId.CLIENT_NU                 = ParcADV.SRVFCDOS_CLIENT_NU
      And RefId.INT_DEPOSIT_DT            >= ParcADV.SRVFCDOS_DT_DEBUT
      And RefId.INT_DEPOSIT_DT            <= coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('99991231' as date format 'YYYYMMDD'))
      -- Pour cet enrichissement on ne tient compte que des demandes de type Dossier
      -- En effet pour les demandes Client 'C'  ce n'est pas des migrations d'OT
      And RefId.IN_CLIDOS = 'D'
  Inner Join ${KNB_IBU_SOC}.V_TDPRESFACT Prestation
    On    ParcADV.SRVFCDOS_PRESFACT_CO    = Prestation.PRESFACT_CO
      And Prestation.PRESFACT_IN_OFT      = '${P_PIL_065}'
      And Prestation.CURRENT_IN           = 1
Qualify Row_Number() Over (Partition By RefId.ACTE_ID Order By Coalesce(ParcADV.SRVFCDOS_DT_FIN,Cast('99991231' as date format 'YYYYMMDD')) desc, ParcADV.SRVFCDOS_DT_DEBUT desc, ParcADV.CLOSURE_DT asc, ParcADV.SRVFCDOS_PRESFACT_CO asc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_OEE_PARCPRE;
.if errorcode <> 0 then .quit 1

.quit 0
