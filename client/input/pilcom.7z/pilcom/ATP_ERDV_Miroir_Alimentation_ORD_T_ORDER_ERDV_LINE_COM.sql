-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Miroir_Alimentation_ORD_T_ORDER_ERDV_LINE_COM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/12/2013      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;




--Insertion dans la table des lignes de commandes :

--TODO PAramétrage

Delete from ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_LINE_COM all ;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_LINE_COM
(
  EXTERNAL_ORDER_ID,
  ORDER_LINE_EXTERNAL_ID,
  ORDER_LINE_STATUS_CD,
  ORDER_LINE_CONTRACT_DATE_TS,
  ORDER_LINE_WANTED_DATE_TS,
  ORDER_LINE_PREST_CD,
  ORDER_LINE_QUANTITY_QT,
  ORDER_LINE_AMOUNT_AM,
  ORDER_LINE_TVA_RT,
  ORDER_LINE_OPER_CD,
  CUSTOMER_MARKET_SEG_CD,
  CUSTOMER_LAST_NAME_NM,
  CUSTOMER_ADDRESS_APPT_NM,
  CUSTOMER_ADDRESS_ESC_NM,
  CUSTOMER_ADDRESS_STAGE_NM,
  CUSTOMER_ADDRESS_BAT_NM,
  CUSTOMER_ADDRESS_RESIDENCE_NM,
  CUSTOMER_ADDRESS_ZIPCODE_CD,
  CUSTOMER_ADDRESS_NUMBER_NU,
  CUSTOMER_ADDRESS_STR_TYPE_CD,
  CUSTOMER_ADDRESS_STREET_NM,
  CUSTOMER_ADDRESS_CITY_NM,
  CUSTOMER_ADDRESS_INSEE_CD,
  REF_OFFRE_CIBLE_CD,
  CATALOGUE_CD,
  CUSTOMER_ND_NU,
  CUSTOMER_NDS_NU,
  QUEUE_TS,
  RUN_ID,
  STREAMING_TS,
  CREATION_TS,
  LAST_MODIF_TS,
  HOT_IN,
  FRESH_IN,
  COHERENCE_IN
)
Select
  LigneCom.EXTERNAL_ORDER_ID                                 as EXTERNAL_ORDER_ID                     ,
  LigneCom.ORDER_LINE_EXTERNAL_ID                            as ORDER_LINE_EXTERNAL_ID                ,
  LigneCom.ORDER_LINE_STATUS_CD                              as ORDER_LINE_STATUS_CD                  ,
  LigneCom.ORDER_LINE_CONTRACT_DATE_TS                       as ORDER_LINE_CONTRACT_DATE_TS           ,
  LigneCom.ORDER_LINE_WANTED_DATE_TS                         as ORDER_LINE_WANTED_DATE_TS             ,
  LigneCom.ORDER_LINE_PREST_CD                               as ORDER_LINE_PREST_CD                   ,
  LigneCom.ORDER_LINE_QUANTITY_QT                            as ORDER_LINE_QUANTITY_QT                ,
  LigneCom.ORDER_LINE_AMOUNT_AM                              as ORDER_LINE_AMOUNT_AM                  ,
  LigneCom.ORDER_LINE_TVA_RT                                 as ORDER_LINE_TVA_RT                     ,
  LigneCom.ORDER_LINE_OPER_CD                                as ORDER_LINE_OPER_CD                    ,
  LigneCom.CUSTOMER_MARKET_SEG_CD                            as CUSTOMER_MARKET_SEG_CD                ,
  LigneCom.CUSTOMER_LAST_NAME_NM                             as CUSTOMER_LAST_NAME_NM                 ,
  LigneCom.CUSTOMER_ADDRESS_APPT_NM                          as CUSTOMER_ADDRESS_APPT_NM              ,
  LigneCom.CUSTOMER_ADDRESS_ESC_NM                           as CUSTOMER_ADDRESS_ESC_NM               ,
  LigneCom.CUSTOMER_ADDRESS_STAGE_NM                         as CUSTOMER_ADDRESS_STAGE_NM             ,
  LigneCom.CUSTOMER_ADDRESS_BAT_NM                           as CUSTOMER_ADDRESS_BAT_NM               ,
  LigneCom.CUSTOMER_ADDRESS_RESIDENCE_NM                     as CUSTOMER_ADDRESS_RESIDENCE_NM         ,
  LigneCom.CUSTOMER_ADDRESS_ZIPCODE_CD                       as CUSTOMER_ADDRESS_ZIPCODE_CD           ,
  LigneCom.CUSTOMER_ADDRESS_NUMBER_NU                        as CUSTOMER_ADDRESS_NUMBER_NU            ,
  LigneCom.CUSTOMER_ADDRESS_STR_TYPE_CD                      as CUSTOMER_ADDRESS_STR_TYPE_CD          ,
  LigneCom.CUSTOMER_ADDRESS_STREET_NM                        as CUSTOMER_ADDRESS_STREET_NM            ,
  LigneCom.CUSTOMER_ADDRESS_CITY_NM                          as CUSTOMER_ADDRESS_CITY_NM              ,
  LigneCom.CUSTOMER_ADDRESS_INSEE_CD                         as CUSTOMER_ADDRESS_INSEE_CD             ,
  LigneCom.REF_OFFRE_CIBLE_CD                                as REF_OFFRE_CIBLE_CD                    ,
  LigneCom.CATALOGUE_CD                                      as CATALOGUE_CD                          ,
  LigneCom.CUSTOMER_ND_NU                                    as CUSTOMER_ND_NU                        ,
  LigneCom.CUSTOMER_NDS_NU                                   as CUSTOMER_NDS_NU                       ,
  LigneCom.QUEUE_TS                                          as QUEUE_TS                              ,
  '${RUN_ID}'                                                as RUN_ID                                ,
  LigneCom.STREAMING_TS                                      as STREAMING_TS                          ,
  Current_Timestamp(0)                                       as CREATION_TS                           ,
  Null                                                       as LAST_MODIF_TS                         ,
  1                                                          as HOT_IN                                ,
  1                                                          as FRESH_IN                              ,
  0                                                          as COHERENCE_IN
From
  ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_LINE_COM LigneCom
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_LINE_COM;
.if errorcode <> 0 then .quit 1


