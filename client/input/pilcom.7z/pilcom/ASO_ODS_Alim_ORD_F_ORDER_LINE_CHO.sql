--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ASO_ODS_Alim_ORD_F_ORDER_LINE_CHO.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'd'alimentation de la table ORD_F_ORDER_LINE_CHO
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 08/01/2014     XKN         Création
---------------------------------------------------------------------------------

.set width 5000

--------------------------
-- ORD_F_ORDER_LINE_CHO --
--------------------------

DELETE FROM ${KNB_IBU_ODS}.ORD_F_ORDER_LINE_CHO;
.if errorcode <> 0 then .quit 1

INSERT INTO ${KNB_IBU_ODS}.ORD_F_ORDER_LINE_CHO
(
      LEAD_ID,
      SEQNUM_NB,
      PRODUCT_ID,
      QTY_NB,
      ADDED_TS,
      ADDED_OPRID_CD,
      ADDED_XI_ID,
      LASTMANT_TS,
      LASTMANT_OPRID_CD,
      LASTMANT_XI_ID,
      LE_PRDLIN_TYPE_CD,
      PRODUCT_ALT_ID ,
      OTO_OFFER_TYPE_CD,
      OTO_OFFER_CD,
      OTO_OFFER_LN,
      OFFER_STATUS_CD,
      SOLDOFF_SRC_CD,
      OTO_SESSION_ID,
      OTO_APPETENCE_CD,
      SEQ_NUM_REL_OFF_NB,
      RSFCOMMENTAIRE_DS,
      OTO_OFF_IB_LN,
      ADDED_GRP_ID,
      ADDED_GRP_SN,
      LASTMANT_GRP_ID,
      LASTMANT_GRP_SN,
      NO_CMD_BNPP,
      CREATION_TS,
      LAST_MODIF_TS,
      ASC_DESC_VALUE_IN,
      FRESH_IN,
      COHERENCE_IN
)
SELECT 
      LEAD_ID,
      SEQNUM_NB,
      PRODUCT_ID,
      QTY_NB,
      ADDED_TS,
      ADDED_OPRID_CD,
      ADDED_XI_ID,
      LASTMANT_TS,
      LASTMANT_OPRID_CD,
      LASTMANT_XI_ID,
      LE_PRDLIN_TYPE_CD,
      PRODUCT_ALT_ID ,
      OTO_OFFER_TYPE_CD,
      OTO_OFFER_CD,
      OTO_OFFER_LN,
      OFFER_STATUS_CD,
      SOLDOFF_SRC_CD,
      OTO_SESSION_ID,
      OTO_APPETENCE_CD,
      SEQ_NUM_REL_OFF_NB,
      RSFCOMMENTAIRE_DS,
      OTO_OFF_IB_LN,
      ADDED_GRP_ID,
      ADDED_GRP_SN,
      LASTMANT_GRP_ID,
      LASTMANT_GRP_SN,
      NO_CMD_BNPP,
      CREATION_TS,
      LAST_MODIF_TS,
      ASC_DESC_VALUE_IN,
      FRESH_IN,
      COHERENCE_IN
FROM ${KNB_IBU_TMP}.ORD_T_ORDER_LINE_C;
.if errorcode <> 0 then .quit 1

COLLECT STATS ON ${KNB_IBU_ODS}.ORD_F_ORDER_LINE_CHO;
.if errorcode <> 0 then .quit 1

