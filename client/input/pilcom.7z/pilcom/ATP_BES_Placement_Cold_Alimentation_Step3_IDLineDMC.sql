-- $HEADER:   mm2pco/current/sql/ATP_BES_Placement_Cold_Alimentation_Step3_IDLineDMC.sql 13_05#13 14-JUN-2017 15:59:55 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Cold_Alimentation_Step3_IDLineDMC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/09/2015      MDE         Creation
-- 09/12/2016      HOB         MODIFICATION VA
-- 07/03/2017      HLA         MODIFICATION 
-- 13/06/2017      HLA         Evol DMC FIXE 
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC all;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  DEPARTMNT_ID              ,
  BU_CD                     ,
  POSTAL_CD                 ,
  INSEE_CD                  ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID     ,
  PAR_CID_ID                ,
  PAR_PID_ID                ,
  PAR_FIRST_IN               
)
 Select
  RefId.ACTE_ID                                   as ACTE_ID                   ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT          ,
  LineDmc.LINE_ID                                 as DMC_LINE_ID               ,
  LineDmc.LINE_ID                                 as DMC_MASTER_LINE_ID        ,
  Ldmc.DEPRTMNT_ID                                as DEPARTMNT_ID              ,
  Geo.BU_CD                                       as BU_CD                     ,
  Ldmc.POSTAL_CD                                  as POSTAL_CD                 ,
  Ldmc.INSEE_NB                                   as INSEE_CD                  ,
  Ldmc.UNIFIED_PARTY_ID                           as PAR_UNIFIED_PARTY_ID      ,
  Ldmc.PARTY_REGRPMNT_ID                          AS PAR_PARTY_REGRPMNT_ID     ,
  Ldmc.CID_ID                                     as PAR_CID_ID                ,
  Ldmc.PID_ID                                     as PAR_PID_ID                ,
  Fi.FIRST_IN                                     As PAR_FIRST_IN               
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_C_1 RefId
     Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_LNK_AR LineDmc
      --Jointure Client/Dossier
     On RefId.DOSSIER_NU = LineDmc.RES_VALUE_DS
    And RefId.CLIENT_NU = LineDmc.ADV_CLIENT_NU
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On LineDmc.LINE_ID = Ldmc.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_FIRST_VM Fi
   On LineDmc.LINE_ID = Fi.LINE_ID
    
Where
  (1=1)
  And RefId.DMC_LINE_ID   Is Null
  --And Ldmc.LINE_TYPE   In ('P','M')
  And Ldmc.CLOSURE_DT  Is Null
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 2 : On recherche l'identifiant ligne dans DMC Par FIXE
----------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  DEPARTMNT_ID              ,
  BU_CD                     ,
  POSTAL_CD                 ,
  INSEE_CD                  ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID     ,
  PAR_CID_ID                ,
  PAR_PID_ID                ,
  PAR_FIRST_IN               
)
 Select
  RefId.ACTE_ID                                   as ACTE_ID                   ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT          ,
  LineDmc.LINE_ID                                 as DMC_LINE_ID               ,
  LineDmc.LINE_ID                                 as DMC_MASTER_LINE_ID        ,
  LineDmc.DEPRTMNT_ID                             as DEPARTMNT_ID              ,
  Geo.BU_CD                                       as BU_CD                     ,
  LineDmc.POSTAL_CD                               as POSTAL_CD                 ,
  LineDmc.INSEE_NB                                as INSEE_CD                  ,
  LineDmc.UNIFIED_PARTY_ID                        as PAR_UNIFIED_PARTY_ID      ,
  LineDmc.PARTY_REGRPMNT_ID                       AS PAR_PARTY_REGRPMNT_ID     ,
  LineDmc.CID_ID                                  as PAR_CID_ID                ,
  LineDmc.PID_ID                                  as PAR_PID_ID                ,
  Fi.FIRST_IN                                     As PAR_FIRST_IN               
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_NDS RefId
   Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
      On  RefId.SERVICE_ACCESS_ID          = LineDmc.SERVICE_ACCESS_ID
      
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = LineDmc.DEPRTMNT_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_FIRST_VM Fi
   On LineDmc.LINE_ID = Fi.LINE_ID
    
Where
  (1=1)
  And Not Exists
  (
    Select
      1
    From
     ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC RefIdExclu
    Where
      (1=1)
      And   RefIdExclu.ACTE_ID           = RefId.ACTE_ID
      And   RefIdExclu.ORDER_DEPOSIT_DT  = RefId.ORDER_DEPOSIT_DT
      And   RefIdExclu.DMC_LINE_ID  Is Not Null
  )
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT  Order by LineDmc.START_DT , LineDmc.LINE_ID Desc)=1

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------
-- Etape 3 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IRIS
(
  ACTE_ID                       ,
  ORDER_DEPOSIT_DT              ,
  DMC_LINE_ID                   ,
  PAR_IRIS2000_CD               ,
  PAR_GEO_MACROZONE
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                        ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT               ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                    ,
  FIBER.IRIS2000_CD                               as PAR_IRIS2000_CD                ,
  FIBER.RESERV_4                                  AS PAR_GEO_MACROZONE 
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
  Where
  (1=1)
 Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.LAST_MODIF_TS Desc)=1

  ;

.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 4 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_FIBER All;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_FIBER
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  DMC_LINE_ID                 ,
  FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                      ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT             ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                  ,
  FIBER.FIBER_IN                                  as FIBER_IN
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
   Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
  ;

.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BES_C_FIBER;
.if errorcode <> 0 then .quit 1

.quit 0

