-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_PCM_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 25/03/2014      AID         Indus 
-- 30/07/2014      YZH         Evol QC 606
-- 04/09/2014      HZO         Evol, Prise en Compte de Perform
-- 17/10/2014      HZO         Ajout de la jointure OSCAR_VALUE_NU = SC / Prise en compte de Perform dans l'étape précédente
-- 12/03/2015      HFO         MODIFICATION QC 1002 et enlève tracage ETASK
-- 12/03/2015      MDE         Ajout Tracage ETASK
-- 23/04/2015      AOU         PDV Point Orange à exclure du Canal AD  QC884
-- 21/05/2015      YZH         Pilcom Digital - Nouveaux champs DMC + Hier O3 
-- 06/07/2014      HFO         MODIFICATION  ajout nouveaux champs OB1 QC 712
-- 29/10/2015      MDE         Modification: tracage Ref ETASK
-- 07/01/2016      MDE         Modification: Evol Calcul CA
-- 29/03/2016      MDE         Evol:ETASK ajout rule_id 30/31
-- 13/05/2016      GMA         Modification Axe Canal Pilcom MultiCanal
-- 03/06/2016      HLA         Evol:VAD annulation
-- 29/07/2016      ABO         Modification multi-canal: Ajout ATH
-- 03/08/2016      MDE         Modif RG alim  ORG_CANAL_ID / ETASK
-- 26/12/2016      JCR         Ajouts champs VA
-- 28/03/2017      MDE         Evol : ajout CID/PID/FIRST 
-- 17/07/2017      HLA         Modif Pilotage Terminaux
-- 13/12/2017      MEL         Evol IOBSP
-- 21/09/2019      SSI         Modification Evolution de l’alimentation de l’acte_valo et ACT_DELTA_TARIF
-- 14/04/2020      YAB         Modification de l'alimentation ACT_DELTA_TARIF KPI2020 
-- 28/05/2020      JCR         modification champs adresse
-- 31/07/2020      EVI         PILCOM-386 : Refonte Digital - Enrichissement SOFT via 6PO
-- 22/10/2020      EVI         PILCOM-57 : Decommissionnement WEBPARTNER
-- 10/03/2021      EVI         PILCOM-800 : REFONTE DIGITAL - Alimentation PAR_EXTERNAL_PARTY_ID
-- 14/01/2021      BCH         PILCOM-1086 : Decom ORG_WEB_PARTNER_IN
--------------------------------------------------------------------------------

.set width 2500;

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_PCM All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_C_PCM
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  ACTE_ID_CMD_RAPPROCHEE            ,
  OPERATOR_PROVIDER_ID              ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_EXTERNAL_ID                 ,
  INTRNL_SOURCE_ID                  ,
  ORDER_REF_EXTERNAL_ID             ,
  ORDER_MOTV_ID                     ,
  ORDER_MOTIF_DS                    ,
  ORDER_STATUT_CD                   ,
  ORDER_STATUT_MODIF_TS             ,
  ORDER_LAST_STATUT_CD              ,
  ORDER_LAST_STATUT_MODIF_TS        ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_PRODUCT_DS_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  INB_PRESFACT_ACQ_ADV              ,
  INB_PRESFACT_ACQ_AGAP             ,
  SEG_PARC_DT_DEBUT                 ,
  INB_PARK_ID                       ,
  FLAG_HD                           ,
  ORG_CANAL_ID                      ,
  ORG_CHANEL_CD                     ,
  ORG_SUB_CHANEL_CD                 ,
  ORG_SUB_SUB_CHANEL_CD             ,
  ORG_REM_CHANEL_CD                 ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORIG_DEM                          ,
  CANALDEM_MTHD                     ,
  ORG_CANAL_ID_MACRO                ,
  ORG_CANAL_MACRO_LB                ,
  ORG_STORE_NAME                    ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_FLAG_TYPE_PTN_NTK             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  ORG_TYPE_CD                       ,
  ORG_TEAM_LEVEL_1_CD               ,
  ORG_TEAM_LEVEL_1_DS               ,
  ORG_TEAM_LEVEL_2_CD               ,
  ORG_TEAM_LEVEL_2_DS               ,
  ORG_TEAM_LEVEL_3_CD               ,
  ORG_TEAM_LEVEL_3_DS               ,
  ORG_TEAM_LEVEL_4_CD               ,
  ORG_TEAM_LEVEL_4_DS               ,
  WORK_TEAM_LEVEL_1_CD              ,
  WORK_TEAM_LEVEL_1_DS              ,
  WORK_TEAM_LEVEL_2_CD              ,
  WORK_TEAM_LEVEL_2_DS              ,
  WORK_TEAM_LEVEL_3_CD              ,
  WORK_TEAM_LEVEL_3_DS              ,
  WORK_TEAM_LEVEL_4_CD              ,
  WORK_TEAM_LEVEL_4_DS              ,
  PAR_EXTERNAL_PARTY_FREG_ID        ,
  PAR_PARTY_KNB_FREG_ID             ,
  PAR_AID                           ,
  PAR_PARTY_KNB_BSS_ID              ,
  PAR_ND                            ,
  PAR_ACCES_SERVICE                 ,
  PAR_ADV_CLIENT_NU                 ,
  PAR_ADV_DOSSIER_NU                ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_DEPRTMNT_ID                   ,
   --
  PAR_CID_ID                        ,
  PAR_PID_ID                        ,
  PAR_FIRST_IN                      ,
  ORG_EDO_IOBSP                     ,
  ORG_AGENT_IOBSP                   ,
  --
  PAR_POSTAL_CD                     ,
  PAR_INSEE_CD                      ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  PAR_IRIS2000_CD                   ,
  PAR_FIBER_IN                      ,
  REDIRECTION_CD                    ,
  OTO_OSCAR_VALUE_NU                ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_SIRET                         ,
  PAR_MARKET_SEG                    ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_CD_POSTAL                ,
  PAR_DO                            ,
  PAR_BU_CD                         ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  PAR_MOB_IMEI                      ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  PAR_MOB_IMSI                      ,
  PAR_EXTERNAL_PARTY_ID             ,
  PAR_SCORE_NU_INT                  ,
  PAR_SCORE_IN_INT                  ,
  PAR_TRESHOLD_NU_INT               ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  CONTRCT_DT_SIGN_PREC_INT          ,
  CONTRCT_DT_FIN_PREC_INT           ,
  CONTRCT_DT_DEB_SIGN_POST_INT      ,
  CONTRCT_DT_FIN_SIGN_POST_INT      ,
  DUREE_ENGAGEMENT_INT              ,
  TYPE_DUR_ENGAGEMENT_INT           ,
  CONTRCT_DT_SIGN_PREC_MOB          ,
  CONTRCT_DT_FIN_PREC_MOB           ,
  CONTRCT_DT_SIGN_POST_MOB          ,
  CONTRCT_DUREE_ENG_MOB             ,
  CONTRCT_UNIT_ENG_MOB              ,
  CONFIRMATION_IN                   ,
  CONFIRMATION_DT                   ,
  CONFIRMATION_CALC_FIN_DT          ,
  DELIVERY_IN                       ,
  DELIVERY_DT                       ,
  DELIVERY_CALC_FIN_DT              ,
  PERENNITE_IN                      ,
  PERENNITE_FIN_DT                  ,
  PERENNITE_CALC_FIN_DT             ,
  SEG_PRES_PARC_COMMANDE            ,
  CONCURENCE_IN                     ,
  CONCURENCE_CONCLU_IN              ,
  CONCURENCE_ID                     ,
  ORDER_CANCELING_DT                ,
  SEG_COM_ID_ORDER_ID               ,
  SEG_ORDER_DT                      ,
  SEG_CANCEL_DT                     ,
  SEG_COM_ID_NEXT_ORDER             ,
  SEG_NEXT_ORDER_DT                 ,
  SEG_NEXT_CANCEL_DT                ,
  SEG_COM_ID_FINAL_ORDER            ,
  SEG_FINAL_ORDER_DT                ,
  SEG_FINAL_ORDER_CANCEL_DT         ,
  DELIVERY_ONTIME_IN                ,
  DELIVERY_DEAD_LINE_NU             ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CPLT_ACTE_ID                      ,
  CPLT_EXT_INT_ID                   ,
  CPLT_EXT_INT_DELT_ID              ,
  CPLT_ORG_EDO_ID                   ,
  CPLT_ORG_TYPE_EDO                 ,
  CPLT_ORG_FLAG_PLT_CONV            ,
  CPLT_ORG_FLAG_TEAM_MKT            ,
  CPLT_ORG_FLAG_TYPE_CMP            ,
  CPLT_ORG_REM_CHANNEL_CD           ,
  CPLT_ORG_CHANNEL_CD               ,
  CPLT_ORG_SUB_CHANNEL_CD           ,
  CPLT_ORG_SUB_SUB_CHANNEL_CD       ,
  CPLT_ORG_GT_ACTIVITY              ,
  CPLT_ORG_FIDELISATION             ,
  CPLT_ORG_WEB_ACTIVITY             ,
  CPLT_ORG_AUTO_ACTIVITY            ,
  CPLT_EXTERNAL_TEAM_CD             ,
  CPLT_O3_ACTIVE_TEAM_CD            ,
  CPLT_O3_RATTACHEMENT_TEAM_CD      ,
  CPLT_AGENT_ID_UPD                 ,
  CPLT_INT_SRC                      ,
  CPLT_INT_REASON                   ,
  CPLT_INT_RESULT                   ,
       --Ajout QC 712 : Ajout Code TAC,EAN,IMEI
  TAC_PREVIOUS_CD                   ,
  IMEI_PREVIOUS_CD                  ,
  EAN_PREVIOUS_CD                   ,
  PCM_PREVIOUS_OFFRE_CD             ,
  COMMARTICLE_RP_REFPRIX_CD         ,
  PCM_COMMTMNT_PERIOD_NU            ,
  PCM_LEVEL_POINT_NU                ,
  CO_OFFRE_TERM_CD                  ,
  PCM_EFFCTV_NEXT_OFFRE_DT          ,
  PCM_TYPE_OFFRE_MOBILE_CD          ,
  PCM_POINT_UTIL_NU                 ,
  PCM_BALANCE_POINT_NU              ,
  PCM_STATUT_POINT_CD               ,
  PCM_POINT_DUE_NU                  ,
  --Fin  QC 712
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                         as ACTE_ID                            ,
  Placement.ACTE_ID                                         as ACTE_ID_GEN                        ,
  ActeSoft.ACTE_ID_CMD_RAPPROCHEE                           as ACTE_ID_CMD_RAPPROCHEE             ,
  Placement.OPERATOR_PROVIDER_ID                            as OPERATOR_PROVIDER_ID               ,
  Placement.ORDER_DEPOSIT_DT                                as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                as ORDER_DEPOSIT_TS                   ,
  Placement.EXTERNAL_ORDER_ID                               as ORDER_EXTERNAL_ID                  ,
  Placement.INTRNL_SOURCE_ID                                as INTRNL_SOURCE_ID                   ,
  Case  --Si c'est un PCM alors
        When Placement.TYPE_PRODUCT = '${P_PIL_231}'
          Then Trim(Cast(Placement.BCR_ID As Varchar(20)))
        --Si c'es un VAD 
        When  Placement.TYPE_PRODUCT = '${P_PIL_232}'
          Then  Placement.VAD_ORDER_ID
        Else Trim(Cast(Placement.BCR_ID As Varchar(20)))
  End                                                       as ORDER_REF_EXTERNAL_ID              ,
  Placement.MOTV_ORDR_ID                                    as ORDER_MOTV_ID                      ,
  Case  --Si c'est un PCM alors
        When Placement.TYPE_PRODUCT = '${P_PIL_231}'
          Then  '${P_PIL_320}'
        --Si c'es un VAD 
        When  Placement.TYPE_PRODUCT = '${P_PIL_232}'
          Then  '${P_PIL_378}'
        Else    '${P_PIL_379}'
  End                                                       as ORDER_MOTIF_DS                     ,
  Placement.ORDER_STATUS_CD                                 as ORDER_STATUT_CD                    ,
  Placement.STATUS_MODIF_TS                                 as ORDER_STATUT_MODIF_TS              ,
  Placement.ORDER_LAST_STATUT_CD                            as ORDER_LAST_STATUT_CD               ,
  Placement.ORDER_LAST_STATUT_MODIF_TS                      as ORDER_LAST_STATUT_MODIF_TS         ,
  ActeSoft.PRODUCT_ID_PRE                                   as ACT_PRODUCT_ID_PRE                 ,
  Null                                                      as ACT_PRODUCT_DS_PRE                 ,
  ActeSoft.SEG_COM_ID_PRE                                   as ACT_SEG_COM_ID_PRE                 ,
  ActeSoft.CODE_MIGR_PRE                                    as ACT_CODE_MIGR_PRE                  ,
  ActeSoft.SEG_COM_AGG_ID_PRE                               as ACT_SEG_COM_AGG_ID_PRE             ,  
  ActeSoft.TYPE_MVT_PRE                                     as ACT_OPER_ID_PRE                    ,
  ActeSoft.PRODUCT_ID_FINAL                                 as ACT_PRODUCT_ID_FINAL               ,
  Placement.TERMINAL_DS                                     as ACT_PRODUCT_DS_FINAL               ,
  ActeSoft.SEG_COM_ID_FINAL                                 as ACT_SEG_COM_ID_FINAL               ,
  ActeSoft.SEG_COM_AGG_ID_FINAL                             as ACT_SEG_COM_AGG_ID_FINAL           ,
  ActeSoft.CODE_MIGR_FINAL                                  as ACT_CODE_MIGR_FINAL                ,
  ActeSoft.TYPE_MVT_FINAL                                   as ACT_OPER_ID_FINAL                  ,
  ActeSoft.TYPE_SERVICE_FINAL                               as ACT_TYPE_SERVICE_FINAL             ,
  Coalesce(Mat.TYPE_COMMANDE_ID, MatSC.TYPE_COMMANDE_ID, ActeSoft.TYPE_COMMANDE_ID) as ACT_TYPE_COMMANDE_ID               ,
--Unité = NB
  Case
   When Coalesce(Mat.UNITE_CD,MatSC.UNITE_CD) ='${P_PIL_620}'         
            then case When ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
                    Then Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)
                    Else  ActeSoft.DELTA_TARIF
                 End    
    --Unité  CA_MARKET )
      When Coalesce(Mat.UNITE_CD,MatSC.UNITE_CD) ='${P_PIL_623}'
           then Coalesce(Mat.CA_MARKETING,MatSC.CA_MARKETING,0)
      --Unité  CA_Calipco
      When Coalesce(Mat.UNITE_CD,MatSC.UNITE_CD) ='${P_PIL_622}'
          then Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT,0)
       Else Coalesce(ActeSoft.DELTA_TARIF,0)
  End                                                       as ACT_DELTA_TARIF                    ,
  Coalesce(Mat.UNITE_CD,MatSC.UNITE_CD)                     as ACT_UNITE_CD                       ,
  Case  When Coalesce(Mat.ACTE_ID, MatSC.ACTE_ID)   is not Null
          Then  Coalesce(Mat.ACTE_ID, MatSC.ACTE_ID)
        When Placement.OSCAR_VALUE_NU Is Null
          Then  '${P_PIL_225}'
        Else    '${P_PIL_067}'
  End                                                       as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID, MatSC.ACTE_REM_ID, '${P_PIL_067}') as ACT_REM_ID                      ,
  Coalesce(Mat.FLAG_ACT_REM,MatSC.FLAG_ACT_REM,'N')         as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC,MatSC.FLAG_PEC_PERPVC,'N')   as ACT_FLAG_PEC_PERPVC                ,
  --Unité = NB
  Case When Coalesce(Mat.UNITE_CD,MatSC.UNITE_CD) ='${P_PIL_620}'
         Then Coalesce(Mat.ACTE_VALO,MatSC.ACTE_VALO,0)
  --Unité  CA_MARKET et CA_Calipso
       When Coalesce(Mat.UNITE_CD,MatSC.UNITE_CD) in ('${P_PIL_623}','${P_PIL_622}')
         Then cast(( ACT_DELTA_TARIF * Coalesce(Mat.TAUX_MARGE,MatSC.TAUX_MARGE) ) as Format '-----------9,99')
       Else   Coalesce(Mat.ACTE_VALO,MatSC.ACTE_VALO,0)
  End                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Mat.ACTE_FAMILLE_KPI,MatSC.ACTE_FAMILLE_KPI,'NON PARAM') as ACT_ACTE_FAMILLE_KPI               ,
  ActeSoft.PERIODE_ID                                       as ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                  as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            as ACT_PERIODE_CLOSURE_DT             ,
  Null                                                      as INB_PRESFACT_ACQ_ADV               ,
  Null                                                      as INB_PRESFACT_ACQ_AGAP              ,
  Null                                                      as SEG_PARC_DT_DEBUT                  ,
  Null                                                      as INB_PARK_ID                        ,
  Mat.HUMAINDIGITAL                                         as FLAG_HD                            ,
   Case When (TraceAutoEtk.ACTE_ID is not null And Placement.DISTRBTN_CHANNL_ID in (${L_PIL_990}) And ORG_CHANEL_CD_AGR='Online'   )
        Then  'SCC'      
       Else  Placement.DISTRBTN_CHANNL_ID 
   End                                                      as ORG_CANAL_ID                       ,
  --Calcul du canal de vente Macro
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_CHANEL_CD   
       When  TraceAutoEtk.ACTE_ID Is  Null
        Then 
              Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                       Then OrgaPDV.ORG_CHANNEL_CD
                    When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                       Then  'Exclus'
                    When Orga.ORG_CHANEL_CD Is Not Null
                       Then  Orga.ORG_CHANEL_CD
                    When OrgaWeb.ORG_CHANEL_CD Is Not Null
                       Then  OrgaWeb.ORG_CHANEL_CD
                    When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
                       Then 'Online'
                    Else 'NONPARAM' 
                End
      Else  TraceAutoEtk.ORG_CHANEL_CD 
   End                                                    as ORG_CHANEL_CD_AGR                    ,
  --Sous Canal
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_SUB_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_SUB_CHANEL_CD  
	   When (NSW2.ORG_SUB_CHANEL_CD is not null or NSW3.ORG_SUB_CHANEL_CD is not null)
        Then Coalesce(NSW2.ORG_SUB_CHANEL_CD,NSW3.ORG_SUB_CHANEL_CD)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then
            Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                   Then OrgaPDV.ORG_SUB_CHANNEL_CD
                  When Orga.ORG_CHANEL_CD Is Not Null
                   Then Case When (Placement.FLAG_TYPE_CPT_NTK = 'AUTRC' AND ORG_CHANEL_CD_AGR ='Dist')
                              Then 'RC'
                            When FLAG_TYPE_PTN_NTK ='DCE'
                              Then 'Exclus'
                            Else Orga.ORG_SUB_CHANEL_CD
                         End
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                   Then Orgaweb.ORG_SUB_CHANEL_CD
                  Else 'NONPARAM'
            End
     Else  TraceAutoEtk.ORG_SUB_CHANEL_CD 
  End                                                     as ORG_SUB_CHANEL_CD_AGR                  ,
  --Sous-Sous-Canal
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_SUB_SUB_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_SUB_SUB_CHANEL_CD   
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then
            Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_SUB_SUB_CHANNEL_CD
                  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
                    Then Case When FLAG_TYPE_PTN_NTK ='DCE'
                               Then 'Exclus'
                              Else Orga.ORG_SUB_SUB_CHANEL_CD
                         End
                  When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR='RC')
                    Then  Case  When FLAG_TYPE_CPT_NTK ='AUT'
                                  Then 'AUTRC'
                                When FLAG_TYPE_CPT_NTK ='GRO'
                                  Then 'GROSS'
                                Else FLAG_TYPE_CPT_NTK
                          End
                  When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP' And Placement.TYPE_EDO='INT')
                    Then 'PAP Int'
                  When ( ORG_CHANEL_CD_AGR ='Dist' AND Placement.DISTRBTN_CHANNL_ID ='PAP' And Placement.TYPE_EDO='EXT')
                    Then 'PAP Ext'
                  When (ORG_CHANEL_CD_AGR = 'Dist' and ORG_SUB_CHANEL_CD_AGR<>'RC')
                    Then 
                      Case When FLAG_TYPE_GEO Is Not Null
                       Then 'DOM'
                      Else 'Metropole'
                      End
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                    Then OrgaWeb.ORG_SUB_SUB_CHANEL_CD
                  Else 'NONPARAM'
          End
     Else  TraceAutoEtk.ORG_SUB_SUB_CHANEL_CD 
  End                                                     as ORG_SUB_SUB_CHANEL_CD_AGR              ,
  --Canal de Rem
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_REM_CHANEL_CD
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_REM_CHANEL_CD    
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then 
          Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                  Then OrgaPDV.ORG_REM_CHANNEL_CD
                When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                  Then  'Exclus'
                When ORG_SUB_SUB_CHANEL_CD_AGR = 'PAP Int'
                  Then 'PAP'
                When ORG_SUB_SUB_CHANEL_CD_AGR = 'PAP Ext'
                  Then 'Exclus'
                When Orga.ORG_CHANEL_CD Is Not Null  
                  Then Orga.ORG_REM_CHANEL_CD
                When OrgaWeb.ORG_CHANEL_CD Is Not Null
                  Then OrgaWeb.ORG_REM_CHANEL_CD
                When  OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
                 Then 'Online'
                Else 'NONPARAM'
          End
     Else  TraceAutoEtk.ORG_REM_CHANEL_CD 
  End                                                     as ORG_REM_CHANEL_CD                  ,
  --ActivitÃ©
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_GT_ACTIVITY
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_GT_ACTIVITY      
       When (NSW2.ORG_GT_ACTIVITY is not null or NSW3.ORG_GT_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_GT_ACTIVITY,NSW3.ORG_GT_ACTIVITY) 
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then 
          Case  When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                  Then OrgaPDV.ORG_GT_ACTIVITY
                When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
                  Then  'Exclus'
                When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist')
                  Then Orga.ORG_GT_ACTIVITY
                When ORG_CHANEL_CD_AGR = 'Dist'
                  Then
                    Case  When ORG_SUB_CHANEL_CD_AGR =  'PAP'
                            Then 'Porte a Porte'
                          When FLAG_TYPE_PTN_NTK = 'MOB'
                            Then 'Mobistore'
                          When FLAG_TYPE_PTN_NTK = 'FC'
                            Then 'CARAIBES'
                          When FLAG_TYPE_PTN_NTK Is Not Null
                           Then FLAG_TYPE_PTN_NTK
                          When ORG_SUB_CHANEL_CD_AGR='AD'
                           Then 'Boutique FT'
                          When ORG_SUB_CHANEL_CD_AGR='RC'
                           Then 'Reseau Concurrent'
                    End
                When OrgaWeb.ORG_CHANEL_CD Is Not Null
                  Then OrgaWeb.ORG_GT_ACTIVITY            
                Else 'NONPARAM'
          End
     Else  TraceAutoEtk.ORG_GT_ACTIVITY 
  End                                                     as ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  Case When  TraceAutoEtk.ACTE_ID Is  Null 
        Then Case When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_FIDELISATION 
                  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                    Then  'Exclus'
                  When Orga.ORG_CHANEL_CD Is Not Null  
                   Then Orga.ORG_FIDELISATION
                When OrgaWeb.ORG_CHANEL_CD Is Not Null
                    Then OrgaWeb.ORG_FIDELISATION
               Else 'NONPARAM'
            End  
       Else  TraceAutoEtk.ORG_FIDELISATION 
  End                                                     as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_WEB_ACTIVITY
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_WEB_ACTIVITY    
       When (NSW2.ORG_WEB_ACTIVITY is not null or NSW3.ORG_WEB_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_WEB_ACTIVITY,NSW3.ORG_WEB_ACTIVITY)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then Case When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_WEB_ACTIVITY 
                  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist' And FLAG_TYPE_PTN_NTK ='DCE')
                    Then  'Exclus'
                  When (Orga.ORG_CHANEL_CD Is Not Null and ORG_CHANEL_CD_AGR <> 'Dist'  )
                    Then Orga.ORG_WEB_ACTIVITY
                  When ORG_CHANEL_CD_AGR = 'Dist'
                   Then 'NON'
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                   Then OrgaWeb.ORG_WEB_ACTIVITY
                  When OrgaWeb.ORG_CHANEL_CD Is Null And Placement.DISTRBTN_CHANNL_ID ='SCC'
                    Then 'OUI'
                Else 'E'
           End    
     Else  TraceAutoEtk.ORG_WEB_ACTIVITY 
  End                                                     as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique
  Case 
       When Orga.ORG_REM_CHANEL_CD = 'ProPme' then Orga.ORG_AUTO_ACTIVITY
	   When OrgaWeb.ORG_REM_CHANEL_CD = 'ProPme' then OrgaWeb.ORG_AUTO_ACTIVITY     
       When (NSW2.ORG_AUTO_ACTIVITY is not null or NSW3.ORG_AUTO_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_AUTO_ACTIVITY,NSW3.ORG_AUTO_ACTIVITY)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then Case When OrgaPDV.DISTRBTN_CHANNL_ID Is Not Null
                    Then OrgaPDV.ORG_AUTO_ACTIVITY 
                  When Orga.ORG_CHANEL_CD Is Not Null And FLAG_TYPE_PTN_NTK ='DCE'
                    Then 'Exclus'
                  When ORG_CHANEL_CD_AGR = 'Dist'
                    Then 'NON'
                  When Orga.ORG_CHANEL_CD Is Not Null  
                    Then Orga.ORG_AUTO_ACTIVITY
                  When OrgaWeb.ORG_CHANEL_CD Is Not Null
                    Then OrgaWeb.ORG_AUTO_ACTIVITY
                  When OrgaWeb.ORG_CHANEL_CD Is Null And  Placement.DISTRBTN_CHANNL_ID ='SCC'
                    Then 'OUI'
                 Else 'E'
             End  
        Else  TraceAutoEtk.ORG_AUTO_ACTIVITY 
  End                                                       as ORG_AUTO_ACTIVITY                  ,
  Null                                                      as ORIG_DEM                           ,
  Null                                                      as CANALDEM_MTHD                      ,
  Null                                                      as ORG_CANAL_ID_MACRO                 ,
  Null                                                      as ORG_CANAL_MACRO_LB                 ,
  Case When (TraceAutoEtk.ACTE_ID Is Not Null And Placement.DISTRBTN_CHANNL_ID in (${L_PIL_990}) And TraceAutoEtk.JOB_ID in (${L_PIL_991}))
        Then  '${P_PIL_491}'     
       When  (TraceAutoEtk.ACTE_ID Is Not Null And Placement.DISTRBTN_CHANNL_ID in (${L_PIL_990}) And TraceAutoEtk.JOB_ID in (${L_PIL_992}))
        Then  '${P_PIL_492}' 
       Else    Placement.STORE_NAME
   End                                                      as ORG_STORE_NAME                      ,
  Case When (NSW2.EDO_ID is not null or NSW3.EDO_ID is not null)
        Then Coalesce(NSW2.EDO_ID,NSW3.EDO_ID)
       When  TraceAutoEtk.ACTE_ID Is  Null 
        Then  Placement.EDO_ID       
       Else  TraceAutoEtk.EDO_ID 
   End                                                      as ORG_EDO_ID                         ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.TYPE_EDO       
       Else  TraceAutoEtk.TYPE_EDO_ID 
   End                                                      as ORG_TYPE_EDO                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.NETWRK_TYP_EDO_ID       
       Else  TraceAutoEtk.NETWRK_TYP_EDO_ID 
   End                                                      as ORG_NETWRK_TYP_EDO_ID              ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_GEO       
       Else  TraceAutoEtk.FLAG_TYPE_GEO_CD 
   End                                                      as ORG_FLAG_TYPE_GEO                  ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_CPT_NTK       
       Else  TraceAutoEtk.FLAG_TYPE_CPT_NTK_NU 
  End                                                       as ORG_FLAG_TYPE_CPT_NTK              ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_PTN_NTK       
       Else  TraceAutoEtk.FLAG_TYPE_PTN_NTK_NU 
   End                                                      as ORG_FLAG_TYPE_PTN_NTK              ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  Placement.FLAG_PLT_CONV       
       Else  TraceAutoEtk.FLAG_PLT_CONV_NB 
   End                                                      as ORG_FLAG_PLT_CONV                  ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TEAM_MKT       
       Else  TraceAutoEtk.FLAG_TEAM_MKT_NB 
   End                                                      as ORG_FLAG_TEAM_MKT                  ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.FLAG_TYPE_CMP       
       Else  TraceAutoEtk.FLAG_TYPE_CMP_NU 
  End                                                       as ORG_FLAG_TYPE_CMP                  ,
  Null                                                      as ORG_REF_TRAV                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Placement.AGENT_ID      
       Else  TraceAutoEtk.AGENT_ID 
   End                                                      as ORG_AGENT_ID                       ,
  Null                                                      as ORG_POC_XI                         ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Coalesce(RetourGRV.AGENT_ID_UPD,Placement.AGENT_ID)
       Else  Coalesce(RetourGRV.AGENT_ID_UPD,TraceAutoEtk.AGENT_ID)
   End                                                      as ORG_AGENT_ID_UPD                   ,
  Cast(RetourGRV.AGENT_ID_UPD_TS as date Format 'YYYYMMDD') as ORG_AGENT_ID_UPD_DT              ,
  Case When  TraceAutoEtk.ACTE_ID is  null 
        Then  Coalesce(RetourGRV.ORG_NOM,Placement.ORG_NOM)
       Else  Coalesce(RetourGRV.ORG_NOM,TraceAutoEtk.ORG_LAST_NAME_NM)
  End                                                      as ORG_NOM                            ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  Coalesce(RetourGRV.ORG_PRENOM,Placement.ORG_PRENOM )
       Else  Coalesce(RetourGRV.ORG_PRENOM,TraceAutoEtk.ORG_FIRST_NAME_NM)
   End                                                      as ORG_PRENOM                         ,
  Null                                                      as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitée
  Null                                                      as ORG_ACTVT_REEL                     ,
  Null                                                      as ORG_RESP_REF_TRAV                  ,
  Null                                                      as ORG_RESP_AGENT_ID                  ,
  Null                                                      as ORG_RESP_XI                        ,
  -- Calcul Hier O3
       Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then OrgO3Enri.ORG_TYPE_CD     
       Else  NULL 
   End                                                      as ORG_TYPE_CD                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.ORG_TEAM_LEVEL_1_CD  
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_1_CD 
   End                                                      as ORG_TEAM_LEVEL_1_CD                ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_1_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_1_DS 
   End                                                      as ORG_TEAM_LEVEL_1_DS                ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_2_CD      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_2_CD 
   End                                                      as ORG_TEAM_LEVEL_2_CD                ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_2_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_2_DS 
   End                                                      as ORG_TEAM_LEVEL_2_DS                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.ORG_TEAM_LEVEL_3_CD      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_3_CD 
   End                                                      as ORG_TEAM_LEVEL_3_CD                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.ORG_TEAM_LEVEL_3_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_3_DS 
   End                                                      as ORG_TEAM_LEVEL_3_DS                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_4_CD      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_4_CD 
   End                                                      as ORG_TEAM_LEVEL_4_CD                ,
      Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.ORG_TEAM_LEVEL_4_DS      
       Else  TraceAutoEtk.ORG_TEAM_LEVEL_4_DS 
   End                                                      as ORG_TEAM_LEVEL_4_DS                ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_1_CD     
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_1_CD 
   End                                                      as WORK_TEAM_LEVEL_1_CD               ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_1_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_1_DS 
   End                                                      as WORK_TEAM_LEVEL_1_DS               ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_2_CD      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_2_CD 
   End                                                      as WORK_TEAM_LEVEL_2_CD               ,
  Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_2_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_2_DS 
   End                                                      as WORK_TEAM_LEVEL_2_DS               , 
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_3_CD      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_3_CD 
   End                                                      as WORK_TEAM_LEVEL_3_CD               ,
   Case When  TraceAutoEtk.ACTE_ID Is Null
        Then  OrgO3Enri.WORK_TEAM_LEVEL_3_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_3_DS 
   End                                                      as WORK_TEAM_LEVEL_3_DS               ,
   Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_4_CD      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_4_CD 
   End                                                      as WORK_TEAM_LEVEL_4_CD               ,
      Case When  TraceAutoEtk.ACTE_ID Is Null 
        Then  OrgO3Enri.WORK_TEAM_LEVEL_4_DS      
       Else  TraceAutoEtk.WORK_TEAM_LEVEL_4_DS 
   End                                                      as WORK_TEAM_LEVEL_4_DS               ,     
  Placement.CUSTOMER_FGT_ID                                 as PAR_EXTERNAL_PARTY_FREG_ID         ,
  Null                                                      as PAR_PARTY_KNB_FREG_ID              ,    
  Placement.CUSTOMER_BSS_ID                                 as PAR_AID                            ,
  --  Placement.BSS_PARTY_KNB_ID                                as PAR_PARTY_KNB_BSS_ID               ,
  Null                                                      as PAR_PARTY_KNB_BSS_ID               ,
  Placement.CUSTOMER_ND_AR                                  as PAR_ND                             ,
  Placement.SERVICE_ACCESS_ID                               as PAR_ACCES_SERVICE                  ,
  Placement.CUSTOMER_CLIENT_NU_ADV                          as PAR_ADV_CLIENT_NU                  ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                         as PAR_ADV_DOSSIER_NU                 ,
  Placement.LINE_ID                                         as DMC_LINE_ID                        ,
  Placement.MASTER_LINE_ID                                  as DMC_MASTER_LINE_ID                 ,
  Case When (Placement.PAR_DEPRTMNT_ID Is Null
              Or
              Substring(Trim(Placement.PAR_DEPRTMNT_ID) From 1 For 3) In ('998', '999') -- respectivement departement etranger  ou inconnu
            ) 
            And PAR_BILL_CD_POSTAL_AGR  Is Not Null
        Then
           Case When Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 3) In ('971','972','973','974','975','976','980','986','987','988')
                        Then  Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 3) -- on renseigne les departement sur 3 caracteres
                        Else    Substring(Trim(PAR_BILL_CD_POSTAL_AGR) From 1 For 2)  -- on renseigne les departement sur 2 caracteres
            End
        Else    Trim(Placement.PAR_DEPRTMNT_ID)
  End                                                       as PAR_DEPRTMNT_ID                    ,
  Placement.PAR_CID_ID                                      as PAR_CID_ID                         ,
  Placement.PAR_PID_ID                                      as PAR_PID_ID                         ,
  Placement.PAR_FIRST_IN                                    as PAR_FIRST_IN                       ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                      ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                    ,
  Placement.PAR_POSTAL_CD                                   as PAR_POSTAL_CD                      ,
  Placement.PAR_INSEE_CD                                    as PAR_INSEE_CD                       ,
  Placement.PAR_GEO_MACROZONE                               as PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                            as PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                           as PAR_PARTY_REGRPMNT_ID              ,
  Placement.PAR_IRIS2000_CD                                 as PAR_IRIS2000_CD                    ,
  Placement.PAR_FIBER_IN                                    as PAR_FIBER_IN                       ,
  Case When  TraceAutoEtk.ACTE_ID Is Null 
          Then  Placement.REDIRECTION_CD      
       Else  TraceAutoEtk.ORDR_ORGN_DS 
   End                                                      as REDIRECTION_CD                     ,
  Placement.OSCAR_VALUE_NU                                  as OTO_OSCAR_VALUE_NU                 ,
  Placement.CUSTOMER_LAST_NAME                              as PAR_LASTNAME                       ,
  Placement.CUSTOMER_FIRST_NAME                             as PAR_FIRSTNAME                      ,
  Placement.CUSTOMER_SIRET                                  as PAR_SIRET                          ,
  Placement.CUSTOMER_MARKET_SEG                             as PAR_MARKET_SEG                     ,
  Null                                                      as PAR_TYPE                           ,
  Null                                                      as PAR_EMAIL                          ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_STREET 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_STREET
  End                                                       as PAR_BILL_ADRESS_1                  ,
  Null                                                      as PAR_BILL_ADRESS_2                  ,
  Null                                                      as PAR_BILL_ADRESS_3                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_CITY 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_CITY
  End                                                       as PAR_BILL_ADRESS_4                  ,
  Case When Placement.INSTALL_ADDRESS_ZIPCODE Is Not NULL
    Then Placement.INSTALL_ADDRESS_ZIPCODE 
       When Placement.SHIPMENT_ADDRESS_ZIPCODE Is Not Null 
    Then Placement.SHIPMENT_ADDRESS_ZIPCODE
  End                                                       as PAR_BILL_CD_POSTAL_AGR             ,
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3) In (${L_PIL_034})
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 3)
        When    Placement.INSTALL_ADDRESS_ZIPCODE  Is Not Null
          Then  Substring(Trim(Placement.INSTALL_ADDRESS_ZIPCODE) From 1 For 2)
        Else    Null
  End                                                       as PAR_DO                             ,
  Placement.PAR_BU_CD                                       as PAR_BU_CD                          ,
  Null                                                      as PAR_USCM                           ,
  Null                                                      as PAR_USCM_DS                        ,
  Null                                                      as PAR_USCM_USCM_DS                   ,
  Null                                                      as PAR_USCM_REGUSCM                   ,
  Null                                                      as PAR_USCM_REGUSCM_DS                ,
  Placement.PAR_IMEI_CD                                     as PAR_MOB_IMEI                       ,
  Placement.PAR_TAC_CD                                      as PAR_MOB_TAC                        ,
  Null                                                      as PAR_MOB_SIM                        ,
  Placement.PAR_IMSI_CD                                     as PAR_MOB_IMSI                       ,
  Placement.PAR_EXTERNAL_PARTY_ID                           as PAR_EXTERNAL_PARTY_ID              ,
  Placement.PAR_SCORE_NU_INT                                as PAR_SCORE_NU_INT                   ,
  Placement.PAR_SCORE_IN_INT                                as PAR_SCORE_IN_INT                   ,
  Placement.PAR_TRESHOLD_NU_INT                             as PAR_TRESHOLD_NU_INT                ,
  Placement.PAR_SCORE_NU_MOB                                as PAR_SCORE_NU_MOB                   ,
  Placement.PAR_SCORE_IN_MOB                                as PAR_SCORE_IN_MOB                   ,
  Placement.PAR_TRESHOLD_NU_MOB                             as PAR_TRESHOLD_NU_MOB                ,
  Placement.CONTRCT_DT_SIGN_PREC_INT                        as CONTRCT_DT_SIGN_PREC_INT           ,
  Placement.CONTRCT_DT_FIN_PREC_INT                         as CONTRCT_DT_FIN_PREC_INT            ,
  Placement.CONTRCT_DT_DEB_SIGN_POST_INT                    as CONTRCT_DT_DEB_SIGN_POST_INT       ,
  Placement.CONTRCT_DT_FIN_SIGN_POST_INT                    as CONTRCT_DT_FIN_SIGN_POST_INT       ,
  Placement.DUREE_ENGAGEMENT_INT                            as DUREE_ENGAGEMENT_INT               ,
  Placement.TYPE_DUR_ENGAGEMENT_INT                         as TYPE_DUR_ENGAGEMENT_INT            ,
  Placement.CONTRCT_DT_SIGN_PREC_MOB                        as CONTRCT_DT_SIGN_PREC_MOB           ,
  Placement.CONTRCT_DT_FIN_PREC_MOB                         as CONTRCT_DT_FIN_PREC_MOB            ,
  Placement.CONTRCT_DT_SIGN_POST_MOB                        as CONTRCT_DT_SIGN_POST_MOB           ,
  Placement.CONTRCT_DUREE_ENG_MOB                           as CONTRCT_DUREE_ENG_MOB              ,
  Placement.CONTRCT_UNIT_ENG_MOB                            as CONTRCT_UNIT_ENG_MOB               ,
  Null                                                      as CONFIRMATION_IN                    ,
  Null                                                      as CONFIRMATION_DT                    ,
  Null                                                      as CONFIRMATION_CALC_FIN_DT           ,
  Null                                                      as DELIVERY_IN                        ,
  Null                                                      as DELIVERY_DT                        ,
  Null                                                      as DELIVERY_CALC_FIN_DT               ,
  Null                                                      as PERENNITE_IN                       ,
  Null                                                      as PERENNITE_FIN_DT                   ,
  Null                                                      as PERENNITE_CALC_FIN_DT              ,
  --Indicateur Si déjà en parc lors de la commande
  ----------------------------------------------------------------------------
  Null                                                      as SEG_PRES_PARC_COMMANDE             ,
  ----------------------------------------------------------------------------
  Null                                                      as CONCURENCE_IN                      ,
  Null                                                      as CONCURENCE_CONCLU_IN               ,
  Null                                                      as CONCURENCE_ID                      ,
  -- Indicateur d'annulation
  VADCancel.ORDER_CANCELING_DT                              as ORDER_CANCELING_DT                 ,
  -- Indicateur Sur la commande
  ---------------------------------------------------------------------------
  Null                                                      as SEG_COM_ID_ORDER_ID          ,
  Null                                                      as SEG_ORDER_DT                 ,
  Null                                                      as SEG_CANCEL_DT                ,
  Null                                                      as SEG_COM_ID_NEXT_ORDER        ,
  Null                                                      as SEG_NEXT_ORDER_DT            ,
  Null                                                      as SEG_NEXT_CANCEL_DT           ,
  Null                                                      as SEG_COM_ID_FINAL_ORDER       ,
  Null                                                      as SEG_FINAL_ORDER_DT           ,
  Null                                                      as SEG_FINAL_ORDER_CANCEL_DT    ,
  ----------------------------------------------------------------------------
  --Calcul si la livraison à eu lieu dans les temps :
  Null                                                      as DELIVERY_ONTIME_IN                 ,
  Null                                                      as DELIVERY_DEAD_LINE_NU              ,
  ----------------------------------------------------------------------------
  Null                                                      as CHECK_INITIAL_STATUS_CD            ,
  RetournCSO.CHECK_NAT_STATUS_CD                            as CHECK_NAT_STATUS_CD                ,
  RetournCSO.CHECK_NAT_COMMENT                              as CHECK_NAT_COMMENT                  ,
  RetournCSO.CHECK_NAT_STATUS_LN                            as CHECK_NAT_STATUS_LN                ,
  RetournCSO.CHECK_LOC_STATUS_CD                            as CHECK_LOC_STATUS_CD                ,
  RetournCSO.CHECK_LOC_COMMENT                              as CHECK_LOC_COMMENT                  ,
  RetournCSO.CHECK_LOC_STATUS_LN                            as CHECK_LOC_STATUS_LN                ,
  RetournCSO.CHECK_VALIDT_DT                                as CHECK_VALIDT_DT                    ,
  --Indicateur Acte Complémentaire (tracage Automatique):
  ----------------------------------------------------------------------------
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID Is Not Null and TraceAutoEtk.EXT_APPLI_ID Is Not Null )
          Then '${P_INT_031}'
        When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID Is Not Null and TraceAutoEtk.EXT_APPLI_ID Is  Null )
          Then  '${P_PIL_520}'
       Else TraceAuto.CPLT_ACTE_ID
  End                                                     as CPLT_ACTE_ID                       ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then TraceAutoEtk.ORDR_ID
       Else  TraceAuto.CPLT_EXT_INT_ID
   End                                                    as CPLT_EXT_INT_ID                    ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_EXT_INT_DELT_ID
   End                                                    as CPLT_EXT_INT_DELT_ID               ,
  Case When (NSW2.EDO_ID is not null or NSW3.EDO_ID is not null)
        Then Coalesce(NSW2.EDO_ID,NSW3.EDO_ID)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_EDO_ID
   End                                                    as CPLT_ORG_EDO_ID                    ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_TYPE_EDO
   End                                                    as CPLT_ORG_TYPE_EDO                  ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_FLAG_PLT_CONV
   End                                                     as CPLT_ORG_FLAG_PLT_CONV            ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_FLAG_TEAM_MKT
   End                                                     as CPLT_ORG_FLAG_TEAM_MKT            ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_FLAG_TYPE_CMP
   End                                                     as CPLT_ORG_FLAG_TYPE_CMP            ,
    Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_REM_CHANNEL_CD
   End                                                    as CPLT_ORG_REM_CHANNEL_CD            ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_CHANNEL_CD
   End                                                    as CPLT_ORG_CHANNEL_CD                ,
  Case 
        When (NSW2.ORG_SUB_CHANEL_CD is not null or NSW3.ORG_SUB_CHANEL_CD is not null)
        Then Coalesce(NSW2.ORG_SUB_CHANEL_CD,NSW3.ORG_SUB_CHANEL_CD)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_SUB_CHANNEL_CD
   End                                                    as CPLT_ORG_SUB_CHANNEL_CD            ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_SUB_SUB_CHANNEL_CD
   End                                                    as CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
     Case 
       When (NSW2.ORG_GT_ACTIVITY is not null or NSW3.ORG_GT_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_GT_ACTIVITY,NSW3.ORG_GT_ACTIVITY) 
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_GT_ACTIVITY
   End                                                    as CPLT_ORG_GT_ACTIVITY                ,
   Case When(TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null
       Else  TraceAuto.CPLT_ORG_FIDELISATION
   End                                                    as CPLT_ORG_FIDELISATION               ,
    Case 
        When (NSW2.ORG_WEB_ACTIVITY is not null or NSW3.ORG_WEB_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_WEB_ACTIVITY,NSW3.ORG_WEB_ACTIVITY)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_WEB_ACTIVITY
   End                                                    as CPLT_ORG_WEB_ACTIVITY               ,
    Case
        When (NSW2.ORG_AUTO_ACTIVITY is not null or NSW3.ORG_AUTO_ACTIVITY is not null)
        Then Coalesce(NSW2.ORG_AUTO_ACTIVITY,NSW3.ORG_AUTO_ACTIVITY)
       When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_ORG_AUTO_ACTIVITY
   End                                                    as CPLT_ORG_AUTO_ACTIVITY              ,
   Case When(TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then NULL 
       Else  TraceAuto.CPLT_EXTERNAL_TEAM_CD
   End                                                    as CPLT_EXTERNAL_TEAM_CD               ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then NULL 
       Else  TraceAuto.CPLT_O3_ACTIVE_TEAM_CD
   End                                                    as CPLT_O3_ACTIVE_TEAM_CD              ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then NULL 
       Else  TraceAuto.CPLT_O3_RATTACHEMENT_TEAM_CD
   End                                                    as CPLT_O3_RATTACHEMENT_TEAM_CD        ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_AGENT_ID_UPD
   End                                                    as CPLT_AGENT_ID_UPD                  ,
    Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_INT_SRC
   End                                                    as CPLT_INT_SRC                       ,
   Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_INT_REASON
   End                                                    as CPLT_INT_REASON                    ,
  Case When (TraceAuto.CPLT_ACTE_ID Is Null and TraceAutoEtk.ACTE_ID is not null )
        Then Null 
       Else  TraceAuto.CPLT_INT_RESULT
   End                                                    as CPLT_INT_RESULT                   ,
        --Ajout QC 712 : Ajout Code TAC,EAN,IMEI
  Placement.TAC_PREVIOUS_CD                               as TAC_PREVIOUS_CD                   ,
  Placement.IMEI_PREVIOUS_CD                              as IMEI_PREVIOUS_CD                  ,
  Placement.EAN_PREVIOUS_CD                               as EAN_PREVIOUS_CD                   ,
  Placement.PRESFACT_CO_PRE_ADV                           as PCM_PREVIOUS_OFFRE_CD             ,
  Placement.COMMARTICLE_RP_REFPRIX_CD                     as COMMARTICLE_RP_REFPRIX_CD         ,
  Placement.PCM_COMMTMNT_PERIOD_NU                        as PCM_COMMTMNT_PERIOD_NU            ,
  Placement.PCM_LEVEL_POINT_NU                            as PCM_LEVEL_POINT_NU                ,
  Placement.CO_OFFRE_TERM_CD                              as CO_OFFRE_TERM_CD                  ,
  Placement.PCM_EFFCTV_NEXT_OFFRE_DT                      as PCM_EFFCTV_NEXT_OFFRE_DT          ,
  Placement.PCM_TYPE_OFFRE_MOBILE_CD                      as PCM_TYPE_OFFRE_MOBILE_CD          ,
  Placement.PCM_POINT_UTIL_NU                             as PCM_POINT_UTIL_NU                 ,
  Placement.PCM_BALANCE_POINT_NU                          as PCM_BALANCE_POINT_NU              ,
  Placement.PCM_STATUT_POINT_CD                           as PCM_STATUT_POINT_CD               ,
  Placement.PCM_POINT_DUE_NU                              as PCM_POINT_DUE_NU                  ,
  --Fin  QC 712 
   
  ------------------------------------------------------------------------------------------------
  --Cas de cloture de l'acte :
  Case  When Placement.FLAG_FIRST_RECEPTION_PSF not in (0,1)
          Then Placement.ORDER_DEPOSIT_DT
        Else  Null
  End                                                       as CLOSURE_DT                         ,
  Placement.QUEUE_TS                                        as QUEUE_TS                           ,
  Placement.RUN_ID                                          as RUN_ID                             ,
  Placement.STREAMING_TS                                    as STREAMING_TS                       ,
  '${KNB_DATE_VACATION}'                                    as CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                    as LAST_MODIF_TS                      ,
  0                                                         as HOT_IN                             ,
  1                                                         as FRESH_IN                           ,
  0                                                         as COHERENCE_IN                       
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_PCM Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_CAL ActeSoft
    On    Placement.ACTE_ID           = ActeSoft.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = ActeSoft.ORDER_DEPOSIT_DT
    --Jointure récupérer les infos de la table des matrices
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On    ActeSoft.TYPE_COMMANDE_ID               = Mat.TYPE_COMMANDE_ID
      And '${P_PIL_211}'                          = Mat.SEG_COM_ID_INI
      And ActeSoft.SEG_COM_ID_FINAL               = Mat.SEG_COM_ID_FINAL
      And ActeSoft.PERIODE_ID                     = Mat.PERIODE_ID
      And ActeSoft.OSCAR_VALUE_NU                 = Mat.CATEGORIE_CLIENT_ID
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE MatSC
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On    ActeSoft.TYPE_COMMANDE_ID               = MatSC.TYPE_COMMANDE_ID
      And '${P_PIL_211}'                          = MatSC.SEG_COM_ID_INI
      And ActeSoft.SEG_COM_ID_FINAL               = MatSC.SEG_COM_ID_FINAL
      And ActeSoft.PERIODE_ID                     = MatSC.PERIODE_ID
      And 'SC'                                    = MatSC.CATEGORIE_CLIENT_ID
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT Orga
    On    Placement.DISTRBTN_CHANNL_ID                        = Orga.DISTRBTN_CHANNL_ID
      And Placement.FLAG_PLT_CONV                             = Orga.FLAG_PLT_CONV
      And Placement.FLAG_TEAM_MKT                             = Orga.FLAG_TEAM_MKT
      And Placement.FLAG_TYPE_CMP                             = Orga.FLAG_TYPE_CMP
      And Orga.FRESH_IN                                       = 1
      And Orga.CURRENT_IN                                     = 1
      And Orga.CLOSURE_DT                                     is Null
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_WEB Orgaweb
    On    Placement.DISTRBTN_CHANNL_ID                        = Orgaweb.ORG_CHANNL_ID
      And Placement.STORE_NAME                            = Orgaweb.ORG_PDV_CD
      And Orgaweb.FRESH_IN                                    = 1
      And Orgaweb.CURRENT_IN                                  = 1
      And Orgaweb.CLOSURE_DT                                  is Null
    -- Jointure avec la Matrice du PDV ATH  
  Left Outer Join ${KNB_PCO_SOC}.ORG_R_CHANNEL_SOFT_PDV OrgaPDV
    On    Placement.DISTRBTN_CHANNL_ID                        = OrgaPDV.DISTRBTN_CHANNL_ID
      And Placement.STORE_NAME                                = OrgaPDV.PDV
      And OrgaPDV.FRESH_IN                                    = 1
      And OrgaPDV.CURRENT_IN                                  = 1
      And OrgaPDV.CLOSURE_DT                                  is Null
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_F_RETURN_PVC RetourGRV
    On    Placement.ACTE_ID           = RetourGRV.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT  = RetourGRV.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_SOC}.V_ACT_H_RETURN_CSO RetournCSO
    On    Placement.ACTE_ID             = RetournCSO.ACTE_ID
      And RetournCSO.CHECK_CURRENT_FLAG = 1
      And RetournCSO.CURRENT_IN         = 1
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    ActeSoft.PERIODE_ID                                 = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                              = 1
      And EtatPeriode.FRESH_IN                                = 1
      And EtatPeriode.CLOSURE_DT                              Is Null
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_ORGO3 OrgO3Enri
    On    Placement.ACTE_ID                                   = OrgO3Enri.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = OrgO3Enri.ORDER_DEPOSIT_DT      
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_TRC_AUTO TraceAuto
    On    Placement.ACTE_ID                                   = TraceAuto.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = TraceAuto.ORDER_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACT_ETASK_PCM_C_TRC_AUTO TraceAutoEtk
    On    Placement.ACTE_ID                                   = TraceAutoEtk.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = TraceAutoEtk.ORDER_DEPOSIT_DT  
  
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_ORDER_CANCEL VADCancel
    On    Placement.ACTE_ID                                   = VADCancel.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                          = VADCancel.ORDER_DEPOSIT_DT  
  Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB
   On EAN_Canal_WEB.EAN_CD = Placement.TERMINAL_CODE_EAN
   And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
   And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM
  On  EAN_Canal_DOM.EAN_CD = Placement.TERMINAL_CODE_EAN
  And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
  And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'
 Left Outer Join  ${KNB_PCO_SOC}.ORG_R_CHANNEL_ENRICH_NSW NSW2 -- MyShop
    On    Placement.ENR6PO_ORDR_ORGN = NSW2.ORDR_MSH_ORGN_DS and Placement.ENR6PO_TYPE_PF = NSW2.ORG_CHANNL_ID And NSW2.ORG_CHANNL_ID = '${P_PIL_630}'
 Left Outer Join  ${KNB_PCO_SOC}.ORG_R_CHANNEL_ENRICH_NSW NSW3 -- MyShopDOM
    On    Placement.ENR6PO_ORDR_ORGN = NSW3.ORDR_MSH_ORGN_DS and Placement.ENR6PO_TYPE_PF = NSW3.ORG_CHANNL_ID And NSW3.ORG_CHANNL_ID = '${P_PIL_631}'

Where
  (1=1)
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_SOFT_PCM;
.if errorcode <> 0 then .quit 1

