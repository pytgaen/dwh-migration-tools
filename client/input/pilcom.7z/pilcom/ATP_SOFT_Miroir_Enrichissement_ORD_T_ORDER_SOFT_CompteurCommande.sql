-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Miroir_Enrichissement_ORD_T_ORDER_SOFT_CompteurCommande.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  qui réalise le comptage des réémission des commandes SOFT
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------

.set width 2500;





--Insertion dans la table des commandes :



--On crée une table volatile afin d'avoir tous les états de commande reçu   

Create Volatile Table ${KNB_TERADATA_USER}.VOL_ORDER_SOFT_RCP(
  EXTERNAL_ORDER_ID                               Varchar(19)       Not Null            ,
  ORDER_STATUS_CD                                 Varchar(20)       Not Null            ,
  STATUS_MODIF_TS                                 Timestamp(0) format 'DD/MM/YYYYBHH:MI:SS',
  ORDER_DEPOSIT_TS                                Timestamp(0)                          ,
  FLAG_FIRST_RECEPTION_COM                        ByteInt                               ,
  FLAG_FIRST_RECEPTION_COM_STAT                   ByteInt                               
)
Primary Index (
  EXTERNAL_ORDER_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_TERADATA_USER}.VOL_ORDER_SOFT_RCP
(
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  ORDER_DEPOSIT_TS              ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT 
)
Select
  OrderSoc.EXTERNAL_ORDER_ID                                as EXTERNAL_ORDER_ID              ,
  OrderSoc.ORDER_STATUS_CD                                  as ORDER_STATUS_CD                ,
  OrderSoc.STATUS_MODIF_TS                                  as STATUS_MODIF_TS                ,
  OrderSoc.ORDER_DEPOSIT_TS                                 as ORDER_DEPOSIT_TS               ,
  OrderSoc.FLAG_FIRST_RECEPTION_COM                         as FLAG_FIRST_RECEPTION_COM       ,
  OrderSoc.FLAG_FIRST_RECEPTION_COM_STAT                    as FLAG_FIRST_RECEPTION_COM_STAT  
From
  ${KNB_COM_SOC}.V_ORD_F_ORDER_SOFT_COM OrderSoc
Where
  Exists
  (
    Select
      1
    From
      ${KNB_COM_TMP}.ATP_W_FACADE_ORDER OrderTmp
    Where
      (1=1)
      And OrderTmp.EXTERNAL_ORDER_ID      =   OrderSoc.EXTERNAL_ORDER_ID
      --On supprime ici dans le cas des réémissions d'une meme commande
      --And OrderTmp.ORDER_STATUS_CD        <>  OrderSoc.ORDER_STATUS_CD
      And OrderTmp.STATUS_MODIF_TS        <>  OrderSoc.STATUS_MODIF_TS
  )
  And Not Exists
  (
    Select
      1
    From
      ${KNB_COM_TMP}.ATP_W_FACADE_ORDER OrderTmp
    Where
      (1=1)
      And OrderTmp.EXTERNAL_ORDER_ID      =   OrderSoc.EXTERNAL_ORDER_ID
      --On supprime ici dans le cas des réémissions d'une meme commande
      And OrderTmp.ORDER_STATUS_CD        =  OrderSoc.ORDER_STATUS_CD
      And OrderTmp.STATUS_MODIF_TS        =  OrderSoc.STATUS_MODIF_TS
  )
;Insert Into ${KNB_TERADATA_USER}.VOL_ORDER_SOFT_RCP
(
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  STATUS_MODIF_TS               ,
  ORDER_DEPOSIT_TS              ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT 
)
Select
  OrderTmp.EXTERNAL_ORDER_ID                                as EXTERNAL_ORDER_ID              ,
  OrderTmp.ORDER_STATUS_CD                                  as ORDER_STATUS_CD                ,
  OrderTmp.STATUS_MODIF_TS                                  as STATUS_MODIF_TS                ,
  OrderTmp.ORDER_DEPOSIT_TS                                 as ORDER_DEPOSIT_TS               ,
  0                                                         as FLAG_FIRST_RECEPTION_COM       ,
  0                                                         as FLAG_FIRST_RECEPTION_COM_STAT  
From
  ${KNB_COM_TMP}.ATP_W_FACADE_ORDER OrderTmp
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_TERADATA_USER}.VOL_ORDER_SOFT_RCP Column (EXTERNAL_ORDER_ID);
.if errorcode <> 0 then .quit 1


Delete from ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_RECEP;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_RECEP
(
  EXTERNAL_ORDER_ID             ,
  ORDER_STATUS_CD               ,
  ORDER_DEPOSIT_DT              ,
  STATUS_MODIF_TS               ,
  FLAG_FIRST_RECEPTION_COM      ,
  FLAG_FIRST_RECEPTION_COM_STAT 
)
Select
  CalculTmp.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID                ,
  CalculTmp.ORDER_STATUS_CD                                       as ORDER_STATUS_CD                  ,
  Cast(CalculTmp.ORDER_DEPOSIT_TS as date format 'YYYYMMDD')      as ORDER_DEPOSIT_DT                 ,
  CalculTmp.STATUS_MODIF_TS                                       as STATUS_MODIF_TS                  ,
  --On fait une somme cumulative pour avoir le numéro de la reception
  Sum(CalculTmp.ChampPourSommer) Over ( Partition by CalculTmp.EXTERNAL_ORDER_ID
                                            Order By CalculTmp.STATUS_MODIF_TS
                                              Rows Unbounded Preceding
                                      )                           as FLAG_FIRST_RECEPTION_COM         ,
  case when CalculTmp.FLAG_FIRST_RECEPTION_COM_STAT  > 127
  then 127
  else CalculTmp.FLAG_FIRST_RECEPTION_COM_STAT  
  end as FLAG_FIRST_RECEPTION_COM_STAT
From 
  (
    Select
      EXTERNAL_ORDER_ID             as EXTERNAL_ORDER_ID  ,
      ORDER_STATUS_CD               as ORDER_STATUS_CD    ,
      STATUS_MODIF_TS               as STATUS_MODIF_TS    ,
      ORDER_DEPOSIT_TS              as ORDER_DEPOSIT_TS   ,
      --On calcul l'indicateur comptage pour avoir le numéro de récèption du statut de la commande
      Row_Number() Over(Partition by EXTERNAL_ORDER_ID,ORDER_STATUS_CD  Order by STATUS_MODIF_TS Asc)   as FLAG_FIRST_RECEPTION_COM_STAT ,
      --On test ici le statut Courrant de la ligne par rapport à la ligne N-1 
      Case  When Min(ORDER_STATUS_CD) Over (Partition by EXTERNAL_ORDER_ID order by STATUS_MODIF_TS Rows Between 1 Preceding and 1 Preceding ) = ORDER_STATUS_CD 
              --Si le Statut est le Même => Donc 0
              Then  0
              --Si ce n'est pas le même alors on flag à 1 pour indiquer le changement
              Else 1
      End                           as ChampPourSommer
    From
      ${KNB_TERADATA_USER}.VOL_ORDER_SOFT_RCP
  )CalculTmp
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_COM_TMP}.ORD_W_ORDER_SOFT_ENRI_RECEP;
.if errorcode <> 0 then .quit 1


