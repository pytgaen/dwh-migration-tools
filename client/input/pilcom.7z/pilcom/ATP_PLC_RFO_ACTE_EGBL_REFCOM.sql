---------------------------------------------------------------------------------
-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:   ATP_PLC_RFO_ACTE_EGBL_REFCOM.sql  $              -
-- TYPE         : Script SQL                                                    -
-- DESCRIPTION  : Perimetre RF - ACTE - SELECTION DES PLACEMENTS POUR           -
--                CONFRONTATION AVEC LE REFERENTIEL COMMERCIAL                  -
---------------------------------------------------------------------------------
--                 HISTORIQUE                                                   -
-- DATE            AUTEUR      CREATION/MODIFICATION                            -
-- 04/09/13        DARTIGUE    Creation                                         -
-- 10/01/14        AID         Modification mise ne norme DSM                   -
---------------------------------------------------------------------------------

.SET WIDTH 2000;

DELETE FROM      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM
                  (
                    ACTE_ID_GEN
                  , ACTE_ID
                  , SERVICE_ACCESS_ID
                  , INT_CREATED_BY_TS
                  , INT_CREATED_BY_DT
                  , INT_RESULT
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , EXTERNAL_PRODUCT_ID_FINAL_CH
                  , INTRNL_PRDCT_ID_OPENCAT_INI
                  , _INTRNL_PRDCT_ID_OPENCAT_INI
                  , BUSINESS_OFFER_BEGIN_DT
                  , LINE_START_DT
                  , LINE_TYPE
                  , IND_GAM_TYPE
                  , FREG_PARTY_ID
                  , PRODUCT_ID
                  , TYPE_SERVICE
                  )
SELECT             CASE WHEN CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_1 IS NULL
                        THEN INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.ACTE_ID * (-1)
                        ELSE    INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.ACTE_ID * 100
                             +  CAT_W_RFORCE_REFCOM._TECH
                   END                                                                          AS ACTE_ID_GEN
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.ACTE_ID                                                  AS ACTE_ID
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.SERVICE_ACCESS_ID                                        AS SERVICE_ACCESS_ID
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.INT_CREATED_BY_TS                                        AS INT_CREATED_BY_TS
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.INT_CREATED_BY_DT                                        AS INT_CREATED_BY_DT
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.INT_RESULT                                               AS INT_RESULT
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.EXTERNAL_PRODUCT_ID_FINAL                                AS EXTERNAL_PRODUCT_ID_FINAL
                 , CAST(INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.EXTERNAL_PRODUCT_ID_FINAL AS VARCHAR(30))           AS EXTERNAL_PRODUCT_ID_FINAL_CH
                 , NULL                                                                         AS INTRNL_PRDCT_ID_OPENCAT_INI
                 , NULL                                                                         AS _INTRNL_PRDCT_ID_OPENCAT_INI
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.BUSINESS_OFFER_BEGIN_DT                                  AS BUSINESS_OFFER_BEGIN_DT
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.LINE_START_DT                                            AS LINE_START_DT
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.LINE_TYPE                                                AS LINE_TYPE
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.IND_GAM_TYPE                                             AS IND_GAM_TYPE
                 , INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.FREG_PARTY_ID                                            AS FREG_PARTY_ID
                 , CAT_W_RFORCE_REFCOM.PRODUCT_ID                                               AS PRODUCT_ID
                 , CAT_W_RFORCE_REFCOM.TYPE_SERVICE                                             AS TYPE_SERVICE
FROM             ${KNB_PCO_TMP}.INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}                                                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}
LEFT JOIN        ${KNB_PCO_TMP}.CAT_W_RFORCE_REFCOM                                                CAT_W_RFORCE_REFCOM
ON                 1                                                                     =         1
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.EXTERNAL_PRODUCT_ID_FINAL                         =         CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_1
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.INT_RESULT                                        =         CAT_W_RFORCE_REFCOM.EXT_PRODUCT_ID_2
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.INT_CREATED_BY_DT                                 BETWEEN   CAT_W_RFORCE_REFCOM.PERIODE_DATE_DEB
                                                                                         AND       CAT_W_RFORCE_REFCOM.PERIODE_DATE_FIN
WHERE              1                                                                     =         1
-- EXTRACTION DES SEULS PLACEMENTS MANUELS NON IDENTIFIES COMME ETANT EN ERREUR ET POUR LESQUELS LE PRODUIT EST VALORISE
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.EXTERNAL_PRODUCT_ID_FINAL                       IS NOT NULL
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.IND_GAM_TYPE                                   <>        ${P_PIL_341}
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.IND_INT_RESULT_ERR                              =         0
AND                INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}.INT_TYPE                                        =        ${P_PIL_339}
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

COLLECT STATISTICS ON ${KNB_PCO_TMP}.INT_W_ACTE_${RFORCE_SUFFIX}_EGBL_REFCOM;

.IF ERRORCODE <> 0 THEN .QUIT 1;

