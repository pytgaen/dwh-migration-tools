-- $HEADER: mm2pco/current/sql/ATP_CHO_Placement_Consolidation_FusionEnrichi_Step2.sql 13_05#12 26-JUN-2019 11:39:25 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_FusionEnrichi_Step2.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de fusion de l'ensemble des enrichissements
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 17/12/2014      GMA         Ajout de la cloture
-- 29/03/2016      HLA         Ajout champs digital
-- 12/12/2016      HOB         Modif : Ajout Champs VA
-- 31/10/2017      HOB         Modification du Calcul d'axe classifiction OPEN/SOSH--IOBSP
-- 13/02/2019      LMU         Evol : Hierachisation IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_T_PLACEMENT_CHO all;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.INT_T_PLACEMENT_CHO
(
  ACTE_ID                     ,
  ACTE_ID_GEN                 ,
  DEMANDE_ID                  ,
  EXTERNAL_INT_ID             ,
  INT_DEPOSIT_TS              ,
  INT_DEPOSIT_DT              ,
  OPERATOR_PROVIDER_ID        ,
  RESOLU_ID                   ,
  CONCLU_ID                   ,
  SSCONCLU_ID                 ,
  TYPE_COMMANDE               ,
  RSFCOMMENTAIRE_DS           ,
  PLTF_CO                     ,
  INTRNL_SOURCE_ID            ,
  SOLDOFF_SRC_CD              ,
  PRODUCT_ID                  ,
  OTO_OFFER_CD                ,
  OTO_OFFER_TYPE_CD           ,
  LOGIN_CREA                  ,
  LOGIN_RESP                  ,
  INT_MODIF_TS                ,
  CANALVENTE                  ,
  OTO_OSCAR_VALUE_NU          ,
  PRODUIT_PRINCIPAL_CHO       ,
  IN_CLIDOS                   ,
  TYPE_OT_SO                  ,
  CANALDEM                    ,
  CANALDEM_MTHD               ,
  INT_REASON_CD               ,
  CLIENT_NU                   ,
  CLIENT_NU_NEW_PORTE         ,
  DOSSIER_NU                  ,
  DOSSIER_NU_NEW_PORTE        ,
  DOSSIER_DATE_ACTIV          ,
  DOSSIER_DATE_RESIL          ,
  DOSSIER_TYPE_RESIL          ,
  DOSSIER_MOTIF_RESIL         ,
  DMC_LINE_ID                 ,
  DMC_MASTER_LINE_ID          ,
  DMC_LINE_TYPE               ,
  DMC_ACTIVATION_DT           ,
  PAR_DEPRTMNT_ID             ,
  PAR_POSTAL_CD               ,
  PAR_INSEE_NB                ,
  PAR_BU_CD                   ,
  PAR_GEO_MACROZONE           ,
  PAR_UNIFIED_PARTY_ID        ,
  PAR_PARTY_REGRPMNT_ID       ,
  PAR_IRIS2000_CD             ,
  PAR_FIBER_IN                ,
  DMC_CONVERGENT_IN           ,
  DMC_LINE_ID_INT             ,
  DMC_LINE_TYPE_INT           ,
  DMC_ACTIVATION_DT_INT       ,
  DMC_SERVICE_ACCESS_ID       ,
  OFFRE_INT_PRE               ,
  PRESFACT_CO_PRECED          ,
  PRESFACT_CO_OFFRE_OPT_ACQ   ,
  INB_PRESFACT_ACQ_ADV        ,
  INB_PRESFACT_ACQ_AGAP       ,
  PARC_DT_DEBUT               ,
  PARC_DT_FIN                 ,
  ORDAGD_DT_CONF              ,
  CONTRCT_DT_SIGN_PREC        ,
  CONTRCT_DT_FIN_PREC         ,
  CONTRCT_DT_SIGN_POST        ,
  CONTRCT_DUREE_ENG           ,
  CONTRCT_UNIT_ENG            ,
  EDO_ID                      ,
  FLAG_PLT_CONV               ,
  FLAG_PLT_SCH                ,
  FLAG_TEAM_MKT               ,
  FLAG_TYPE_CMP               ,
  TYPE_EDO                    ,
  ORG_EDO_IOBSP               ,
  EDO_ID_HIER                 ,
  TYPE_EDO_HIER               ,
  ORG_REF_TRAV                ,
  ORG_AGENT_ID                ,
  ORG_AGENT_IOBSP             ,
  ORG_POC_XI                  ,
  ORG_NOM                     ,
  ORG_PRENOM                  ,
  ORG_GROUPE_ID               ,
  ORG_GROUPE_ID_HIER          ,
  ORG_ACTVT_REEL              ,
  ORG_RESP_REF_TRAV           ,
  ORG_RESP_AGENT_ID           ,
  ORG_RESP_XI                 ,
  ORG_RESP_ACTVT_REEL         ,
  PAR_LASTNAME                ,
  PAR_FIRSTNAME               ,
  PAR_TYPE                    ,
  PAR_IMSI                    ,
  PAR_EMAIL                   ,
  PAR_BILL_ADRESS_1           ,
  PAR_BILL_ADRESS_2           ,
  PAR_BILL_ADRESS_3           ,
  PAR_BILL_ADRESS_4           ,
  PAR_BILL_VILLE              ,
  PAR_BILL_CD_POSTAL          ,
  PAR_INSEE_CD                ,
  PAR_DO                      ,
  PAR_USCM                    ,
  PAR_USCM_DS                 ,
  PAR_USCM_USCM_DS            ,
  PAR_USCM_REGUSCM            ,
  PAR_USCM_REGUSCM_DS         ,
  PAR_AID                     ,
  PAR_ND                      ,
  PAR_MOB_IMEI                ,
  PAR_MOB_TAC                 ,
  PAR_MOB_SIM                 ,
  PAR_SCORE_NU_MOB            ,
  PAR_SCORE_IN_MOB            ,
  PAR_TRESHOLD_NU_MOB         ,
  PAR_SCORE_NU_INT            ,
  PAR_SCORE_IN_INT            ,
  PAR_TRESHOLD_NU_INT         ,
  FLAG_MAINT_INT_FALSE        ,
  CLOSURE_DT                  ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN                ,
  HOT_IN                    
)
Select
  Commande.ACTE_ID                                                                      as ACTE_ID                    ,
  Commande.ACTE_ID                                                                      as ACTE_ID_GEN                ,
  Commande.DEMANDE_ID                                                                   as DEMANDE_ID                 ,
  Commande.EXTERNAL_INT_ID                                                              as EXTERNAL_INT_ID            ,
  Commande.INT_DEPOSIT_TS                                                               as INT_DEPOSIT_TS             ,
  Commande.INT_DEPOSIT_DT                                                               as INT_DEPOSIT_DT             ,
  Commande.OPERATOR_PROVIDER_ID                                                         as OPERATOR_PROVIDER_ID       ,
  Commande.RESOLU_ID                                                                    as RESOLU_ID                  ,
  Commande.CONCLU_ID                                                                    as CONCLU_ID                  ,
  Commande.SSCONCLU_ID                                                                  as SSCONCLU_ID                ,
  Commande.TYPE_COMMANDE                                                                as TYPE_COMMANDE              ,
  Commande.RSFCOMMENTAIRE_DS                                                            as RSFCOMMENTAIRE_DS          ,
  Commande.PLTF_CO                                                                      as PLTF_CO                    ,
  Commande.INTRNL_SOURCE_ID                                                             as INTRNL_SOURCE_ID           ,
  Commande.SOLDOFF_SRC_CD                                                               as SOLDOFF_SRC_CD             ,
  Commande.PRODUCT_ID                                                                   as PRODUCT_ID                 ,
  Commande.OTO_OFFER_CD                                                                 as OTO_OFFER_CD               ,
  Commande.OTO_OFFER_TYPE_CD                                                            as OTO_OFFER_TYPE_CD          ,
  Commande.LOGIN_CREA                                                                   as LOGIN_CREA                 ,
  Commande.LOGIN_RESP                                                                   as LOGIN_RESP                 ,
  Commande.INT_MODIF_TS                                                                 as INT_MODIF_TS               ,
  Commande.CANALVENTE                                                                   as CANALVENTE                 ,
  Commande.OTO_OSCAR_VALUE_NU                                                           as OTO_OSCAR_VALUE_NU         ,
  Commande.PRODUIT_PRINCIPAL_CHO                                                        as PRODUIT_PRINCIPAL_CHO      ,
  Commande.IN_CLIDOS                                                                    as IN_CLIDOS                  ,
  Commande.TYPE_OT_SO                                                                   as TYPE_OT_SO                 ,
  Commande.CANALDEM                                                                     as CANALDEM                   ,
  Commande.CANALDEM_MTHD                                                                as CANALDEM_MTHD              ,
  Commande.INT_REASON_CD                                                                as INT_REASON_CD              ,
  Commande.CLIENT_NU                                                                    as CLIENT_NU                  ,
  Commande.CLIENT_NU_NEW_PORTE                                                          as CLIENT_NU_NEW_PORTE        ,
  Commande.DOSSIER_NU                                                                   as DOSSIER_NU                 ,
  Commande.DOSSIER_NU_NEW_PORTE                                                         as DOSSIER_NU_NEW_PORTE       ,
  Commande.DOSSIER_DATE_ACTIV                                                           as DOSSIER_DATE_ACTIV         ,
  Commande.DOSSIER_DATE_RESIL                                                           as DOSSIER_DATE_RESIL         ,
  Commande.DOSSIER_TYPE_RESIL                                                           as DOSSIER_TYPE_RESIL         ,
  Commande.DOSSIER_MOTIF_RESIL                                                          as DOSSIER_MOTIF_RESIL        ,
  --Ligne DMC
  Coalesce(LigneDMC.DMC_LINE_ID,Commande.DMC_LINE_ID)                                   as DMC_LINE_ID                ,
  Coalesce(LigneDMC.DMC_MASTER_LINE_ID,Commande.DMC_MASTER_LINE_ID)                     as DMC_MASTER_LINE_ID         ,
  Coalesce(LigneDMC.DMC_LINE_TYPE,Commande.DMC_LINE_TYPE)                               as DMC_LINE_TYPE              ,
  Coalesce(LigneDMC.DMC_ACTIVATION_DT,Commande.DMC_ACTIVATION_DT)                       as DMC_ACTIVATION_DT          ,
  Coalesce(LigneDMC.PAR_DEPRTMNT_ID,Commande.PAR_DEPRTMNT_ID)                           AS PAR_DEPRTMNT_ID            ,
  Coalesce(LigneDMC.PAR_POSTAL_CD,Commande.PAR_POSTAL_CD)                               AS PAR_POSTAL_CD              ,
  Coalesce(LigneDMC.PAR_INSEE_NB,Commande.PAR_INSEE_NB)                                 AS PAR_INSEE_NB               ,
  Coalesce(LigneDMC.PAR_BU_CD,Commande.PAR_BU_CD)                                       AS PAR_BU_CD                  ,
  Coalesce(IRIS.PAR_GEO_MACROZONE,Commande.PAR_GEO_MACROZONE)                           AS PAR_GEO_MACROZONE          ,
  Coalesce(LigneDMC.PAR_UNIFIED_PARTY_ID,Commande.PAR_UNIFIED_PARTY_ID)                 AS PAR_UNIFIED_PARTY_ID       ,
  Coalesce(LigneDMC.PAR_PARTY_REGRPMNT_ID,Commande.PAR_PARTY_REGRPMNT_ID)               AS PAR_PARTY_REGRPMNT_ID      ,
  Coalesce(IRIS.PAR_IRIS2000_CD,Commande.PAR_IRIS2000_CD)                               AS PAR_IRIS2000_CD            ,
  Coalesce(FIBER.PAR_FIBER_IN ,Commande.PAR_FIBER_IN)                                   AS PAR_FIBER_IN               ,
  --Conv DMC
  Coalesce(DmcConv.DMC_CONVERGENT_IN,Commande.DMC_CONVERGENT_IN)                        as DMC_CONVERGENT_IN          ,
  --Id Ligne Int DMC
  Coalesce(DmcInt.DMC_LINE_ID_INT,Commande.DMC_LINE_ID_INT)                             as DMC_LINE_ID_INT            ,
  Coalesce(DmcInt.DMC_LINE_TYPE_INT,Commande.DMC_LINE_TYPE_INT)                         as DMC_LINE_TYPE_INT          ,
  Coalesce(DmcInt.DMC_ACTIVATION_DT_INT,Commande.DMC_ACTIVATION_DT_INT)                 as DMC_ACTIVATION_DT_INT      ,
  Coalesce(DmcInt.DMC_SERVICE_ACCESS_ID,Commande.DMC_SERVICE_ACCESS_ID)                 as DMC_SERVICE_ACCESS_ID      ,
  --Prestation Précédante Internet
  Null                                                                                  as OFFRE_INT_PRE              ,
  --Presfacto_precedent enrichi
  Coalesce(ParcPre.PRESFACT_CO_PRECED,Commande.PRESFACT_CO_PRECED)                      as PRESFACT_CO_PRECED         ,
  Commande.PRESFACT_CO_OFFRE_OPT_ACQ                                                    as PRESFACT_CO_OFFRE_OPT_ACQ  ,
  --Champs à Enrichir
  Coalesce(ParcAcq.INB_PRESFACT_ACQ_ADV,Commande.INB_PRESFACT_ACQ_ADV)                  as INB_PRESFACT_ACQ_ADV       ,
  Coalesce(ParcAcq.INB_PRESFACT_ACQ_AGAP,Commande.INB_PRESFACT_ACQ_AGAP)                as INB_PRESFACT_ACQ_AGAP      ,
  Coalesce(ParcAcq.PARC_DT_DEBUT,Commande.PARC_DT_DEBUT)                                as PARC_DT_DEBUT              ,
  Coalesce(ParcAcq.PARC_DT_FIN,Commande.PARC_DT_FIN)                                    as PARC_DT_FIN                ,
  Coalesce(OrdreAgen.ORDAGD_DT_CONF,Commande.ORDAGD_DT_CONF)                            as ORDAGD_DT_CONF             ,
  Coalesce(ContrOld.CONTRCT_DT_SIGN_PREC,Commande.CONTRCT_DT_SIGN_PREC)                 as CONTRCT_DT_SIGN_PREC       ,
  Coalesce(ContrOld.CONTRCT_DT_FIN_PREC,Commande.CONTRCT_DT_FIN_PREC)                   as CONTRCT_DT_FIN_PREC        ,
  Coalesce(ContrNew.CONTRCT_DT_SIGN_POST,Commande.CONTRCT_DT_SIGN_POST)                 as CONTRCT_DT_SIGN_POST       ,
  Coalesce(ContrNew.CONTRCT_DUREE_ENG,Commande.CONTRCT_DUREE_ENG)                       as CONTRCT_DUREE_ENG          ,
  Coalesce(ContrNew.CONTRCT_UNIT_ENG,Commande.CONTRCT_UNIT_ENG)                         as CONTRCT_UNIT_ENG           ,
  --
  Coalesce(RefO3.EDO_ID,Commande.EDO_ID)                                                as EDO_ID                     ,
  Coalesce(RefO3.FLAG_PLT_CONV,Commande.FLAG_PLT_CONV)                                  as FLAG_PLT_CONV              ,
  Coalesce(RefO3.FLAG_PLT_SCH,Commande.FLAG_PLT_SCH)                                    as FLAG_PLT_SCH               ,
  Coalesce(Market.FLAG_TEAM_MKT,Commande.FLAG_TEAM_MKT)                                 as FLAG_TEAM_MKT              ,
  Coalesce(Market.FLAG_TYPE_CMP,Commande.FLAG_TYPE_CMP)                                 as FLAG_TYPE_CMP              ,
  Coalesce(RefO3.TYPE_EDO,Commande.TYPE_EDO)                                            as TYPE_EDO                   ,
  Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
  End                                                                                   as ORG_EDO_IOBSP              ,
  Coalesce(RefO3_Hier.EDO_ID_HIER,Commande.EDO_ID_HIER)                                 as EDO_ID_HIER                ,
  Coalesce(RefO3_Hier.TYPE_EDO_HIER,Commande.TYPE_EDO_HIER)                             as TYPE_EDO_HIER              ,
  --
  Commande.ORG_REF_TRAV                                                                 as ORG_REF_TRAV               ,
  Commande.ORG_AGENT_ID                                                                 as ORG_AGENT_ID               ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
  End                                                                                   as ORG_AGENT_IOBSP            ,
  Commande.ORG_POC_XI                                                                   as ORG_POC_XI                 ,
  Commande.ORG_NOM                                                                      as ORG_NOM                    ,
  Commande.ORG_PRENOM                                                                   as ORG_PRENOM                 ,
  Commande.ORG_GROUPE_ID                                                                as ORG_GROUPE_ID              ,
  Commande.ORG_GROUPE_ID_HIER                                                           as ORG_GROUPE_ID_HIER              ,
  Commande.ORG_ACTVT_REEL                                                               as ORG_ACTVT_REEL             ,
  Commande.ORG_RESP_REF_TRAV                                                            as ORG_RESP_REF_TRAV          ,
  Commande.ORG_RESP_AGENT_ID                                                            as ORG_RESP_AGENT_ID          ,
  Commande.ORG_RESP_XI                                                                  as ORG_RESP_XI                ,
  Commande.ORG_RESP_ACTVT_REEL                                                          as ORG_RESP_ACTVT_REEL        ,
  --Champs à Enrichir
  Coalesce(ClPostPaid.PAR_LASTNAME,ClPrePaid.PAR_LASTNAME,Commande.PAR_LASTNAME)        as PAR_LASTNAME               ,
  Coalesce(ClPostPaid.PAR_FIRSTNAME,ClPrePaid.PAR_FIRSTNAME,Commande.PAR_FIRSTNAME)     as PAR_FIRSTNAME              ,
  Coalesce(ClPostPaid.PAR_TYPE,Commande.PAR_TYPE)                                       as PAR_TYPE                   ,
  Commande.PAR_IMSI                                                                     as PAR_IMSI                   ,
  Coalesce(ClBal.PAR_EMAIL,Commande.PAR_EMAIL)                                          as PAR_EMAIL                  ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_1,Commande.PAR_BILL_ADRESS_1)                          as PAR_BILL_ADRESS_1          ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_2,Commande.PAR_BILL_ADRESS_2)                          as PAR_BILL_ADRESS_2          ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_3,Commande.PAR_BILL_ADRESS_3)                          as PAR_BILL_ADRESS_3          ,
  Coalesce(ClAdr.PAR_BILL_ADRESS_4,Commande.PAR_BILL_ADRESS_4)                          as PAR_BILL_ADRESS_4          ,
  Coalesce(ClAdr.PAR_BILL_VILLE,Commande.PAR_BILL_VILLE)                                as PAR_BILL_VILLE             ,
  Coalesce(ClAdr.PAR_BILL_CD_POSTAL,Commande.PAR_BILL_CD_POSTAL)                        as PAR_BILL_CD_POSTAL         ,
  Coalesce(ClAdr.PAR_INSEE_CD,Commande.PAR_INSEE_CD)                                    as PAR_INSEE_CD               ,
  Coalesce(ClAdr.PAR_DO,Commande.PAR_DO)                                                as PAR_DO                     ,
  Coalesce(ClUscm.PAR_USCM,Commande.PAR_USCM)                                           as PAR_USCM                   ,
  Coalesce(ClUscm.PAR_USCM_DS,Commande.PAR_USCM_DS)                                     as PAR_USCM_DS                ,
  Coalesce(ClUscm.PAR_USCM_USCM_DS,Commande.PAR_USCM_USCM_DS)                           as PAR_USCM_USCM_DS           ,
  Coalesce(ClUscm.PAR_USCM_REGUSCM,Commande.PAR_USCM_REGUSCM)                           as PAR_USCM_REGUSCM           ,
  Coalesce(ClUscm.PAR_USCM_REGUSCM_DS,Commande.PAR_USCM_REGUSCM_DS)                     as PAR_USCM_REGUSCM_DS        ,
  Coalesce(AttribInt.PAR_AID,Commande.PAR_AID)                                          as PAR_AID                    ,
  Coalesce(AttribInt.PAR_ND,Commande.PAR_ND)                                            as PAR_ND                     ,
  Coalesce(ClImei.PAR_MOB_IMEI,Commande.PAR_MOB_IMEI)                                   as PAR_MOB_IMEI               ,
  Coalesce(ClImei.PAR_MOB_TAC,Commande.PAR_MOB_TAC)                                     as PAR_MOB_TAC                ,
  Coalesce(ClSim.PAR_MOB_SIM,Commande.PAR_MOB_SIM)                                      as PAR_MOB_SIM                ,
  Coalesce(ClScore.PAR_SCORE_NU_MOB,Commande.PAR_SCORE_NU_MOB)                          as PAR_SCORE_NU_MOB           ,
  Coalesce(ClScore.PAR_SCORE_IN_MOB,Commande.PAR_SCORE_IN_MOB)                          as PAR_SCORE_IN_MOB           ,
  Coalesce(ClScore.PAR_TRESHOLD_NU_MOB,Commande.PAR_TRESHOLD_NU_MOB)                    as PAR_TRESHOLD_NU_MOB        ,
  --Convergence CLient INT
  Coalesce(DmcSC.PAR_SCORE_NU_INT,Commande.PAR_SCORE_NU_INT)                            as PAR_SCORE_NU_INT           ,
  Coalesce(DmcSC.PAR_SCORE_IN_INT,Commande.PAR_SCORE_IN_INT)                            as PAR_SCORE_IN_INT           ,
  Coalesce(DmcSC.PAR_TRESHOLD_NU_INT,Commande.PAR_TRESHOLD_NU_INT)                      as PAR_TRESHOLD_NU_INT        ,
  Coalesce(MaintInt.FLAG_MAINT_INT_FALSE, Commande.FLAG_MAINT_INT_FALSE)                as FLAG_MAINT_INT_FALSE       ,
  CloturePl.CLOSURE_DT                                                                  as CLOSURE_DT                 ,
  '${KNB_DATE_VACATION}'                                                                as CREATION_TS                ,
  '${KNB_DATE_VACATION}'                                                                as LAST_MODIF_TS              ,
  1                                                                                     as FRESH_IN                   ,
  0                                                                                     as COHERENCE_IN               ,
  0                                                                                     as HOT_IN                     
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 Commande
  --Attributs Internet
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_AT_INT AttribInt
    On    Commande.ACTE_ID        = AttribInt.ACTE_ID
      And Commande.INT_DEPOSIT_DT = AttribInt.INT_DEPOSIT_DT
  --Client Prépaid
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CLPREPAID ClPrePaid
    On    Commande.ACTE_ID        = ClPrePaid.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClPrePaid.INT_DEPOSIT_DT
  --Client PostPaid
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CLPOSTPAID ClPostPaid
    On    Commande.ACTE_ID        = ClPostPaid.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClPostPaid.INT_DEPOSIT_DT
  --Client Adresse Mail
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_BAL ClBal
    On    Commande.ACTE_ID        = ClBal.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClBal.INT_DEPOSIT_DT
  --Client Adresse postale
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_ADR ClAdr
    On    Commande.ACTE_ID        = ClAdr.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClAdr.INT_DEPOSIT_DT
  --Client Score
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_SCORE ClScore
    On    Commande.ACTE_ID        = ClScore.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClScore.INT_DEPOSIT_DT
  --Client IMEI
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_IMEI ClImei
    On    Commande.ACTE_ID        = ClImei.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClImei.INT_DEPOSIT_DT
  --Client SIM
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_SIM ClSim
    On    Commande.ACTE_ID        = ClSim.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClSim.INT_DEPOSIT_DT
  --Client Adresse USCM
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CL_USCM ClUscm
    On    Commande.ACTE_ID        = ClUscm.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClUscm.INT_DEPOSIT_DT
  --Contrat Old
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATOLD ContrOld
    On    Commande.ACTE_ID        = ContrOld.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ContrOld.INT_DEPOSIT_DT
  --Contrat New
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATNEW ContrNew
    On    Commande.ACTE_ID        = ContrNew.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ContrNew.INT_DEPOSIT_DT
  --Parc Précédant
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PARCPRE ParcPre
    On    Commande.ACTE_ID        = ParcPre.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ParcPre.INT_DEPOSIT_DT
  --Odre Agendé
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_ORDRAG OrdreAgen
    On    Commande.ACTE_ID        = OrdreAgen.ACTE_ID
      And Commande.INT_DEPOSIT_DT = OrdreAgen.INT_DEPOSIT_DT
  --Parc Acqui
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_PARCACQ ParcAcq
    On    Commande.ACTE_ID        = ParcAcq.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ParcAcq.INT_DEPOSIT_DT
  --Line DMC
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IDLINEDMC LigneDMC
    On    Commande.ACTE_ID        = LigneDMC.ACTE_ID
      And Commande.INT_DEPOSIT_DT = LigneDMC.INT_DEPOSIT_DT
  --Convergence du client
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_CV   DmcConv
    On    Commande.ACTE_ID        = DmcConv.ACTE_ID
      And Commande.INT_DEPOSIT_DT = DmcConv.INT_DEPOSIT_DT
  --ID Dmc Internet
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT   DmcInt
    On    Commande.ACTE_ID        = DmcInt.ACTE_ID
      And Commande.INT_DEPOSIT_DT = DmcInt.INT_DEPOSIT_DT
  --ID Dmc Internet Score
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_DMC_INT_SC   DmcSC
    On    Commande.ACTE_ID        = DmcSC.ACTE_ID
      And Commande.INT_DEPOSIT_DT = DmcSC.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_MAINTINTF   MaintInt
    On    Commande.ACTE_ID        = MaintInt.ACTE_ID
      And Commande.INT_DEPOSIT_DT = MaintInt.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_VENDEUR_O3  RefO3
    On    Commande.ACTE_ID        = RefO3.ACTE_ID
      And Commande.INT_DEPOSIT_DT = RefO3.INT_DEPOSIT_DT
      And Commande.INT_DEPOSIT_DT  >=  RefO3.START_VAL_AXS_DT
      And Commande.INT_DEPOSIT_DT  <   RefO3.END_VAL_AXS_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_VEND_O3_H  RefO3_Hier
    On    Commande.ACTE_ID        = RefO3_Hier.ACTE_ID
      And Commande.INT_DEPOSIT_DT = RefO3_Hier.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_TYPEMARKET   Market
    On    Commande.ACTE_ID        = Market.ACTE_ID
      And Commande.INT_DEPOSIT_DT = Market.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CLOTURE  CloturePl
    On    Commande.ACTE_ID        = CloturePl.ACTE_ID
      And Commande.INT_DEPOSIT_DT = CloturePl.INT_DEPOSIT_DT
  --Client Line IRIS2000    
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_IRIS IRIS
     On    Commande.ACTE_ID        = IRIS.ACTE_ID
      And Commande.INT_DEPOSIT_DT  = IRIS.INT_DEPOSIT_DT
  --Client PAR_FIBER_IN    
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_FIBER FIBER
     On    Commande.ACTE_ID        = FIBER.ACTE_ID
      And Commande.INT_DEPOSIT_DT  = FIBER.INT_DEPOSIT_DT
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    Coalesce(RefO3.EDO_ID,Commande.EDO_ID)    = EdoOBK.EDO_ID
        And  Commande.INT_DEPOSIT_DT                  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('ORANGEBANK')    And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Commande.ORG_AGENT_ID=CuidOBK.AGENT_ID
        And   Commande.INT_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
        And   Commande.INT_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY')) 
        
         
  Qualify Row_number() over (Partition By Commande.ACTE_ID,Commande.INT_DEPOSIT_DT Order By Commande.INT_DEPOSIT_TS asc)=1     
;  ;

;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_T_PLACEMENT_CHO;
.if errorcode <> 0 then .quit 1

