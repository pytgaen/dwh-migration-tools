 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_MigrationMobile.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des migrations mobiles
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000


--Identification des produits Migration Mobile AGC
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  2                                                             As REJECT_TYPE_ID         ,
  'IODA'                                                        As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  Case  When Mob2.EXTERNAL_ORDER_ID Is Not Null
          Then
                'Migration  ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
                      ||Coalesce(Trim(Mob2.ACT_CODE_MIGR_FINAL),'')
                      ||' ('||Coalesce(Trim(Mob2.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob2.ACT_PRODUCT_ID_FINAL),'')||')'
                      ||' > '
                      ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
                      ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
                      ||' )'
        Else  'Aucun Produit offre (OFFMOB/OFFCONV) en suppression Dans la Commande IODA / AGAP '
              ||'; CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
              ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
              ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
              ||' )'
  End                                                           As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Mob1.ORDER_DEPOSIT_DT)                                    As DateMinRecue           ,
  Max(Mob1.ORDER_DEPOSIT_DT)                                    As DateMaxRecue           
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_MOB Mob1
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_MOB Mob2
    On    Mob1.EXTERNAL_ORDER_ID        = Mob2.EXTERNAL_ORDER_ID
      And Mob2.ACT_OPER_ID_FINAL        = 'RMV' 
      And Mob2.ACT_TYPE_SERVICE_FINAL   In ('OFFMOB', 'OFFCONV')
      And Mob2.ORDER_DEPOSIT_DT         >= Current_Date - 30
Where
  (1=1)
  And Mob1.ACT_OPER_ID_FINAL            = 'ADD'
  And Mob1.ACT_TYPE_SERVICE_FINAL       In ('OFFMOB', 'OFFCONV')
  And Mob1.EXTERNAL_ORDER_ID            Like 'FID%'
  And Mob1.ACT_SEG_COM_ID_PRE           Is Null
  And Mob1.ORDER_DEPOSIT_DT             >= Current_Date - 30
Group by
  4
;
.if errorcode <> 0 Then .quit 1




--Identification des produits Migration Mobile Chorus
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  2                                                             As REJECT_TYPE_ID         ,
  'CHO'                                                         As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  'Migration  ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_PRE),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_PRE),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_PRE),'')||')'
        ||' > '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Mob1.INT_DEPOSIT_DT)                                      As DateMinRecue           ,
  Max(Mob1.INT_DEPOSIT_DT)                                      As DateMaxRecue           
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_CHO Mob1
Where
  (1=1)
  And Mob1.ACT_SEG_COM_ID_PRE           Is Not Null
  And Mob1.ACT_TYPE_SERVICE_FINAL       In ('OFFMOB', 'OFFCONV')
  And Mob1.INT_DEPOSIT_DT               >= Current_Date - 30
  And Mob1.ACT_CD like 'ERR%'
Group by
  4
;
.if errorcode <> 0 Then .quit 1




--Identification des produits Migration Mobile SFC
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  2                                                             As REJECT_TYPE_ID         ,
  'SFC'                                                         As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  'Migration  ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_PRE),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_PRE),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_PRE),'')||')'
        ||' > '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Mob1.ORD_DEPOSIT_DT)                                      As DateMinRecue           ,
  Max(Mob1.ORD_DEPOSIT_DT)                                      As DateMaxRecue           
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_CAR Mob1
Where
  (1=1)
  And Mob1.ACT_SEG_COM_ID_PRE           Is Not Null
  And Mob1.ACT_TYPE_SERVICE_FINAL       In ('OFFMOB', 'OFFCONV')
  And Mob1.ORD_DEPOSIT_DT               >= Current_Date - 30
  And Mob1.ACT_CD like 'ERR%'
Group by
  4
;
.if errorcode <> 0 Then .quit 1



--Identification des produits Migration Mobile OEE
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  2                                                             As REJECT_TYPE_ID         ,
  'OEE'                                                         As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  'Migration  ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_PRE),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_PRE),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_PRE),'')||')'
        ||' > '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Mob1.INT_DEPOSIT_DT)                                      As DateMinRecue           ,
  Max(Mob1.INT_DEPOSIT_DT)                                      As DateMaxRecue           
From
  ${KNB_PCO_VM}.V_INT_F_ACTE_OEE Mob1
Where
  (1=1)
  And Mob1.ACT_SEG_COM_ID_PRE           Is Not Null
  And Mob1.ACT_TYPE_SERVICE_FINAL       In ('OFFMOB', 'OFFCONV')
  And Mob1.INT_DEPOSIT_DT               >= Current_Date - 30
  And Mob1.ACT_CD like 'ERR%'
Group by
  4
;
.if errorcode <> 0 Then .quit 1




--Identification des produits Migration Mobile SOFT
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  2                                                             As REJECT_TYPE_ID         ,
  'SOFT'                                                        As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  Case  When Mob2.ORDER_EXTERNAL_ID Is Not Null
          Then
                'Migration  ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
                      ||Coalesce(Trim(Mob2.ACT_CODE_MIGR_FINAL),'')
                      ||' ('||Coalesce(Trim(Mob2.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob2.ACT_PRODUCT_ID_FINAL),'')||')'
                      ||' > '
                      ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
                      ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
                      ||' )'
        Else  'Aucun Produit offre (OFFMOB/OFFCONV) en suppression Dans la Commande SOFT / AGAP '
              ||'; CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
              ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
              ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
              ||' )'
  End                                                           As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Mob1.ORDER_DEPOSIT_DT)                                    As DateMinRecue           ,
  Max(Mob1.ORDER_DEPOSIT_DT)                                    As DateMaxRecue           
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB Mob1
  Left Outer Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB Mob2
    On    Mob1.ORDER_EXTERNAL_ID        = Mob2.ORDER_EXTERNAL_ID
      And Mob2.ACT_OPER_ID_FINAL        = 'RMV'
      And Mob2.ACT_TYPE_SERVICE_FINAL   In ('OFFMOB', 'OFFCONV')
      And Mob2.ORDER_DEPOSIT_DT         >= Current_Date - 30
Where
  (1=1)
  And Mob1.ACT_OPER_ID_FINAL            = 'ADD'
  And Mob1.ACT_TYPE_SERVICE_FINAL       In ('OFFMOB', 'OFFCONV')
  And Mob1.ORDER_OPER_ID                = 'MIGRA'
  And Mob1.ACT_SEG_COM_ID_PRE           Is Null
  And Mob1.ORDER_DEPOSIT_DT             >= Current_Date - 30
Group by
  4
;
.if errorcode <> 0 Then .quit 1





--Identification des produits Migration Mobile Shop To Web
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  2                                                             As REJECT_TYPE_ID         ,
  '6PO'                                                         As SOURCE_ID              ,
  'AGAP'                                                        As CATALOG_ID             ,
  'Migration  ; ( CODE_MIGRA_INITIAL (SEG - PRODUIT)  > CODE_MIGRA_FINAL (SEG - PRODUIT) ) ; ( '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_PRE),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_PRE),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_PRE),'')||')'
        ||' > '
        ||Coalesce(Trim(Mob1.ACT_CODE_MIGR_FINAL),'')
        ||' ('||Coalesce(Trim(Mob1.ACT_SEG_COM_ID_FINAL),'')||' - '||Coalesce(Trim(Mob1.ACT_PRODUCT_ID_FINAL),'')||')'
        ||' )'                                                  As ERROR_CD               ,
  'Aucune Information trouvée dans Kenobi'                      As INFO_CD                ,
  Count(*)                                                      As VolumeCas              ,
  Min(Mob1.ORDER_DEPOSIT_DT)                                    As DateMinRecue           ,
  Max(Mob1.ORDER_DEPOSIT_DT)                                    As DateMaxRecue           
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_NEWSHOP Mob1
Where
  (1=1)
  And Mob1.ACT_SEG_COM_ID_PRE           Is Not Null
  And Mob1.ACT_TYPE_SERVICE_FINAL       In ('OFFMOB', 'OFFCONV')
  And Mob1.ORDER_DEPOSIT_DT               >= Current_Date - 30
  And Mob1.ORDER_TYPE                   = 'PCM'
  And Mob1.ACT_CD                       Like 'ERR%'
Group by
  4
;
.if errorcode <> 0 Then .quit 1



-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
