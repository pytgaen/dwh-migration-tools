--$HEADER:   mm2pco/current/sql/ATP_JRC_Placement_Step4_Enrichissement_EDO.sql 13_05#1 06-FEV-2019 12:14:54 KRQJ9961
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_JRC_Placement_Step4_Enrichissement_EDO.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'alimentation des EDO et maj de la table temporaire 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 24/12/2018     JCR         Creation Humain Digital sprint 1 (Service Client)
-- 01/03/2021     EVI         PILCOM-815 : H&D - Ajout source H2H
----------------------------------------------------------------------------------------------
.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete des tables temporaires                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_EDO All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation POC-D (98I)                                                     ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_EDO
(
  ACTE_ID                    ,
  INTRCTN_DT                 ,
  ORG_EDO_ID                 
)
Select 
  Src.ACTE_ID             As ACTE_ID      ,
  Src.INTRCTN_DT          As INTRCTN_DT   ,
  EdoLnk.EDO_ID           As ORG_EDO_ID   

From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 Src
Inner Join  ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK EdoLnk
    On Coalesce (Src.OPRTR_TEAM_ACTVT_ID, Src.OPRTR_TEAM_HIERCH_ID, '#')  =   Coalesce (EdoLnk.EXTNL_VAL_COD_CD, '#')
    And Src.INTRCTN_DT                                                    >=  EdoLnk.START_EXTNL_VAL_DT
    And Src.INTRCTN_DT                                                    <   EdoLnk.END_EXTNL_VAL_DT
    And EdoLnk.EXTNL_COD_CD                                               = 'ADV'
    And EdoLnk.CURRENT_IN                                                 = 1
    And EdoLnk.CLOSURE_DT                                                 Is Null
Where 
  1 = 1
  And Src.APPLI_SOURCE_ID  = '98I'
Qualify Row_Number() Over(Partition by Src.ACTE_ID Order by EdoLnk.ROL_LINK_CD Asc, 
                                                   EdoLnk.START_EXTNL_VAL_DT Desc, 
                                                   Coalesce(EdoLnk.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc)=1
;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 3 : Alimentation CHO/OEE                                                         ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_EDO
(
  ACTE_ID                    ,
  INTRCTN_DT                 ,
  ORG_EDO_ID                 
)
Select 
  Src.ACTE_ID             As ACTE_ID      ,
  Src.INTRCTN_DT          As INTRCTN_DT   ,
  Edo.EDO_ID              As ORG_EDO_ID   

From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 Src
 Inner Join  ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO Edo
    On Coalesce (Src.OPRTR_TEAM_ACTVT_ID, Src.OPRTR_TEAM_HIERCH_ID, '#')  =   Coalesce (Edo.EXTNL_VAL_COD_CD, '#')
    And Src.INTRCTN_DT                                                    >=  Edo.START_EXTNL_VAL_DT
    And Src.INTRCTN_DT                                                    <   Edo.END_EXTNL_VAL_DT
    And Edo.EXTNL_COD_CD                                                  = 'REGARDSC'
    And Edo.CURRENT_IN                                                    = 1
    And Edo.CLOSURE_DT                                                    Is Null
Where 
  1 = 1
  And Src.APPLI_SOURCE_ID  In  ('CHO', 'OEE')
Qualify Row_Number() Over(Partition by Src.ACTE_ID Order by Edo.START_EXTNL_VAL_DT Desc, 
                                                   Coalesce(Edo.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc)=1
;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 4 : Alimentation MCRM                                                            ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_EDO
(
  ACTE_ID                    ,
  INTRCTN_DT                 ,
  ORG_EDO_ID                 
)
Select 
  Src.ACTE_ID                                                   As ACTE_ID      ,
  Src.INTRCTN_DT                                                As INTRCTN_DT   ,
  Coalesce (Src.OPRTR_TEAM_ACTVT_ID, Src.OPRTR_TEAM_HIERCH_ID)  As ORG_EDO_ID   

From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1 Src
Where 
  1 = 1
  And Src.APPLI_SOURCE_ID  In  ('MCR','H2H');
.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_EDO;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 5 : MAJ EDO dans la table temporaire                                             ----
----------------------------------------------------------------------------------------------
Update Cib
From  ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1      Cib ,
      ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_EDO    Src  
Set 
  ORG_EDO_ID      = Src.ORG_EDO_ID  
Where 
  1=1
  And Cib.ACTE_ID     = Src.ACTE_ID
  And Cib.INTRCTN_DT  = Src.INTRCTN_DT;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_JRC_1;
.if errorcode <> 0 then .quit 1