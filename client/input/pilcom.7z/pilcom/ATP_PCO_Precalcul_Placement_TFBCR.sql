-- $HEADER: mm2pco/current/sql/ATP_PCO_Precalcul_Placement_TFBCR.sql 13_05#2 30-AVR-2018 11:19:48 LXQG9925
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_Precalcul_Placement_TFBCR.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_TFINDICOM_CHO
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     GMA         Création
-- 06/02/2014     AID         Indus
-- 23/04/2018     LMU         Ajout de champs dans le cadre de RCS
---------------------------------------------------------------------------------

.set width 2000;

-- Création de la table volatile :

Create Volatile Table ${KNB_TERADATA_USER}.ID_BCR_TOLOAD (
  ID_BCR              Decimal(10)             Not Null
)
Primary index (
  ID_BCR
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


--On récupère la liste des ID BCR à recalculer :
Insert into ${KNB_TERADATA_USER}.ID_BCR_TOLOAD
Select
  ID_BCR as ID_BCR
From
  (
      Select
        Status.STATUTBCR_ID_BCR       as ID_BCR
      From
        ${KNB_IBU_SOC_V}.VF_THSTATUTBCR Status
      Where
        (1=1)
        And Status.LAST_MODIF_TS  >  cast('${KNB_PILCOM_PLACEMENT_BORNE_INF}' as timestamp(0))
        And Status.LAST_MODIF_TS  <= cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' as timestamp(0))
      Group by
        Status.STATUTBCR_ID_BCR
    Union
      Select
        Matricule.COMMARTICLE_ID_BCR  as ID_BCR
      From
        ${KNB_IBU_SOC_V}.VF_TFCOMMARTICLE Matricule
      Where
        (1=1)
        And Matricule.LAST_MODIF_TS  >  cast('${KNB_PILCOM_PLACEMENT_BORNE_INF}' as timestamp(0))
        And Matricule.LAST_MODIF_TS  <= cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' as timestamp(0))
      Group by
        Matricule.COMMARTICLE_ID_BCR
    Union
      Select
        Brc.BCR_ID_BCR                as ID_BCR
      From
        ${KNB_IBU_SOC_V}.VF_TFBCR Brc
      Where
        (1=1)
        And Brc.LAST_MODIF_TS  >  cast('${KNB_PILCOM_PLACEMENT_BORNE_INF}' as timestamp(0))
        And Brc.LAST_MODIF_TS  <= cast('${KNB_PILCOM_PLACEMENT_BORNE_MAX}' as timestamp(0))
      Group by
        Brc.BCR_ID_BCR
    Union
      --récupération des Acteurs ayant été modifié ou ajouté depuis la dernière fois.
      Select
        TmpCal.ID_BCR                as ID_BCR
      From
        (
            --On récupère les Id BCR ainsi que leur code dans les placements
            Select
              ID_BCR                ,
              IDENTIFIANT_FT        
            From
              ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM
            Group by
              ID_BCR                ,
              IDENTIFIANT_FT        
          Minus
            --On selectionne les Id BRC ainsi que leur code acteurs dans le socle
            Select
              PremStatut.STATUTBCR_ID_BCR     as ID_BCR         ,
              Acteur.ACTEUR_IDENTIFIANT_FT    as IDENTIFIANT_FT 
            From
              (
                Select
                  RefId.ID_BCR                          as STATUTBCR_ID_BCR       ,
                  Statut.STATUTBCR_ACT_ID               as STATUTBCR_ACT_ID       
                From
                  ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_PCM RefId
                  Left Outer Join  ${KNB_IBU_SOC_V}.VF_THSTATUTBCR Statut
                    On    RefId.ID_BCR=Statut.STATUTBCR_ID_BCR
                      And Statut.STATUTBCR_SB_STATUTBCR in ('SA')
                Where
                  (1=1)
                Qualify Row_Number() Over(Partition by RefId.ID_BCR Order By STATUTBCR_DATESTATUT Asc) = 1
              )PremStatut
              Left Outer Join ${KNB_IBU_SOC_V}.TDACTEUR Acteur
                On    PremStatut.STATUTBCR_ACT_ID   = Acteur.ACTEUR_ID
                  And Acteur.CURRENT_IN             = 1
                  And Acteur.CLOSURE_DT             is null
            Group by
              PremStatut.STATUTBCR_ID_BCR   ,
              Acteur.ACTEUR_IDENTIFIANT_FT  
        )TmpCal
  )Tmp
;
.if errorcode <> 0 then .quit 1

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC
-- **************************************************************

--Paramètre attendu : Les bornes de dates

--Delete des lignes
Delete From ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC
(
  ID_BCR                            ,
  DATESAISIEBCR                     ,
  DOSSIER_NU                        ,
  CLIENT_NU                         ,
  PRESFACT_CO                       ,
  USCM_CO_ADV                       ,
  USCM_CO_PCM                       ,
  NUMCATALMAIL                      ,
  CD_CANALDIST                      ,
  ADV_CO_BCR                        ,
  PDV_XI_BCR                        ,
  STATUTBCR_CO                      ,
  DUREEREENG                        ,
  TB_TYPEBCR                        ,
  NBPOINTSUTIL                      ,
  COMPLEMENT                        ,
  DATEVALIDATION                    ,
  NUMEROIMEI                        ,
  PV_POINTVENTE                     ,
  CODEVENDEUR                       ,
  ID_PROGRAMMEFID                   ,
  SEGMENTVALEURCLIENT               ,
  INDCARTESIM                   -- RCS
)
Select 
  Brc.BCR_ID_BCR                              as ID_BCR                    ,
  Brc.BCR_DATESAISIEBCR                       as DATESAISIEBCR             ,
  Brc.BCR_DOSSIER_NU                          as DOSSIER_NU                ,
  Brc.BCR_CLIENT_NU                           as CLIENT_NU                 ,
  Brc.BCR_PRESFACT_CO                         as PRESFACT_CO               ,
  Brc.BCR_USCM_CO_ADV                         as USCM_CO_ADV               ,
  Brc.BCR_USCM_CO_PCM                         as USCM_CO_PCM               ,
  Brc.BCR_NUMCATALMAIL                        as NUMCATALMAIL              ,
  Brc.BCR_CD_CANALDIST                        as CD_CANALDIST              ,
  Brc.BCR_ADV_CO_BCR                          as ADV_CO_BCR                ,
  Brc.BCR_PDV_XI_BCR                          as PDV_XI_BCR                ,
  Brc.BCR_STATUTBCR_CO                        as STATUTBCR_CO              ,
  Brc.BCR_DUREEREENG                          as DUREEREENG                ,
  Brc.BCR_TB_TYPEBCR                          as TB_TYPEBCR                ,
  Brc.BCR_NBPOINTSUTIL                        as NBPOINTSUTIL              ,
  Brc.BCR_COMPLEMENT                          as COMPLEMENT                ,
  Brc.BCR_DATEVALIDATION                      as DATEVALIDATION            ,
  Brc.BCR_NUMEROIMEI                          as NUMEROIMEI                ,
  Brc.BCR_PV_POINTVENTE                       as PV_POINTVENTE             ,
  Brc.BCR_CODEVENDEUR                         as CODEVENDEUR               ,
  Brc.BCR_ID_PROGRAMMEFID                     as ID_PROGRAMMEFID           ,
  Coalesce(Brc.BCR_SEGMENTVALEURCLIENT,'SC')  as SEGMENTVALEURCLIENT       ,
  Brc.BCR_INDCARTESIM                         as INDCARTESIM
From
  ${KNB_IBU_SOC_V}.VF_TFBCR Brc
  Inner Join ${KNB_TERADATA_USER}.ID_BCR_TOLOAD Vol
    On Brc.BCR_ID_BCR=Vol.ID_BCR
Qualify Row_Number() Over (Partition by Brc.BCR_ID_BCR Order by Brc.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.PLACEMENT_PCM_PRECALC;
.if errorcode <> 0 then .quit 1


