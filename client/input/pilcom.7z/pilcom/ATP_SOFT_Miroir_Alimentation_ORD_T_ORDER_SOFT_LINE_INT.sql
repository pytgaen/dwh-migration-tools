-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Miroir_Alimentation_ORD_T_ORDER_SOFT_LINE_INT.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  d'alimentation des tables mirroires lignes commandes internet
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------


.set width 2500;




--Insertion dans la table des commandes :

--TODO PAramétrage

Delete from ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT all ;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT
(
  EXTERNAL_ORDER_ID               ,
  ORDER_STATUS_CD                 ,
  STATUS_MODIF_TS                 ,
  APPLI_SOURCE_ID                 ,
  OPERATOR_PROVIDER_ID            ,
  ORDER_DEPOSIT_DT                ,
  ORDER_DEPOSIT_TS                ,
  ORDER_LINE_EXTERNAL_ID          ,
  EXT_OPER_ID                     ,
  ATOMIC_OFFR_ID                  ,
  ATOMIC_OFFR_DS                  ,
  FUNCTN_ID                       ,
  FUNCTN_DS                       ,
  FUNCTN_VALUE_ID                 ,
  SMPL_FNCTN_VALUE_NM             ,
  FUNCTN_VALUE_DS                 ,
  PREVIOUS_FUNCTN_VALUE_ID        ,
  PREVIOUS_SMPL_FNCTN_VALUE_NM    ,
  PREVIOUS_FUNCTN_VALUE_DS        ,
  QUEUE_TS                        ,
  RUN_ID                          ,
  STREAMING_TS                    ,
  CREATION_TS                     ,
  LAST_MODIF_TS                   ,
  HOT_IN                          ,
  FRESH_IN                        ,
  COHERENCE_IN                    
)
Select
  LigneInternet.EXTERNAL_ORDER_ID                                 as EXTERNAL_ORDER_ID              ,
  LigneInternet.ORDER_STATUS_CD                                   as ORDER_STATUS_CD                ,
  LigneInternet.STATUS_MODIF_TS                                   as STATUS_MODIF_TS                ,
  '${P_PIL_066}'                                                  as APPLI_SOURCE_ID                ,
  Null                                                            as OPERATOR_PROVIDER_ID           ,
  Cast(LigneInternet.ORDER_DEPOSIT_TS as date format 'YYYYMMDD')  as ORDER_DEPOSIT_DT               ,
  LigneInternet.ORDER_DEPOSIT_TS                                  as ORDER_DEPOSIT_TS               ,
  LigneInternet.ORDER_LINE_EXTERNAL_ID                            as ORDER_LINE_EXTERNAL_ID         ,
  LigneInternet.EXT_OPER_ID                                       as EXT_OPER_ID                    ,
  LigneInternet.ATOMIC_OFFR_ID                                    as ATOMIC_OFFR_ID                 ,
  LigneInternet.ATOMIC_OFFR_DS                                    as ATOMIC_OFFR_DS                 ,
  Coalesce(LigneInternet.FUNCTN_ID,'#')                           as FUNCTN_ID                      ,
  LigneInternet.FUNCTN_DS                                         as FUNCTN_DS                      ,
  --Alimentation des valeurs de fonctions
  Case  --Traitement pour supprimer la visibilité des mots de passe des client :
        When LigneInternet.FUNCTN_ID in (${L_PIL_031})
            Then Null
        When Substring(trim(LigneInternet.FUNCTN_VALUE_ID) from 1 for 2)  = 'VF'
            Then  Case  When Trim(LigneInternet.FUNCTN_VALUE_ID) = ''
                          Then Null
                        Else LigneInternet.FUNCTN_VALUE_ID
                  End
        --Cas Particulier des Fonction MODE_COMMERC et ModeRemise on doit mettre dans valeur de fonction meme si pas de VF
        When LigneInternet.FUNCTN_ID in (${L_PIL_030})
          Then  Case  When Trim(LigneInternet.FUNCTN_VALUE_ID) = ''
                        Then Null
                      Else LigneInternet.FUNCTN_VALUE_ID
                End
        Else Null
  End                                                       as FUNCTN_VALUE_ID                ,
  Case  --Traitement pour supprimer la visibilité des mots de passe des client :
        When LigneInternet.FUNCTN_ID in (${L_PIL_031})
            Then '${P_PIL_322}'
        When Substring(trim(LigneInternet.FUNCTN_VALUE_ID) from 1 for 2)  = 'VF'
            Then Null
        --Cas Particulier des Fonction MODE_COMMERC et ModeRemise on doit mettre dans valeur de fonction meme si pas de VF
        When LigneInternet.FUNCTN_ID in (${L_PIL_030})
            Then Null
        Else  Case  When Trim(LigneInternet.FUNCTN_VALUE_ID) = ''
                      Then Null
                    Else LigneInternet.FUNCTN_VALUE_ID
              End
  End                                                       as SMPL_FNCTN_VALUE_NM            ,
 Case   --Traitement pour supprimer la visibilité des mots de passe des client :
        When LigneInternet.FUNCTN_ID in (${L_PIL_031})
            Then Null
        When Substring(trim(LigneInternet.FUNCTN_VALUE_ID) from 1 for 2)  = 'VF'
          Then LigneInternet.FUNCTN_VALUE_DS
        When LigneInternet.FUNCTN_ID in (${L_PIL_030})
          Then LigneInternet.FUNCTN_VALUE_DS
        Else  Null
  End                                                       as FUNCTN_VALUE_DS                ,
  --Alimenation Valeurs de fonctions précédante :
  -- On ne valorise que s'il y a une modification
  Case  When LigneInternet.FUNCTN_VALUE_ID  = LigneInternet.PREVIOUS_FUNCTN_VALUE_ID
          Then Null
        Else
          Case  --Traitement pour supprimer la visibilité des mots de passe des client :
                When LigneInternet.PREVIOUS_FUNCTN_VALUE_ID in (${L_PIL_031})
                  Then Null
                When Substring(trim(LigneInternet.PREVIOUS_FUNCTN_VALUE_ID) from 1 for 2)  = 'VF'
                  Then
                        Case  When Trim(LigneInternet.PREVIOUS_FUNCTN_VALUE_ID) = ''
                                Then Null
                              Else LigneInternet.PREVIOUS_FUNCTN_VALUE_ID
                        End
                When LigneInternet.FUNCTN_ID in (${L_PIL_030}) And LigneInternet.PREVIOUS_FUNCTN_VALUE_ID is not null
                  Then
                        Case  When Trim(LigneInternet.PREVIOUS_FUNCTN_VALUE_ID) = ''
                                Then Null
                              Else LigneInternet.PREVIOUS_FUNCTN_VALUE_ID
                        End
                Else Null
          End
   End                                                       as PREVIOUS_FUNCTN_VALUE_ID       ,
  Case  When LigneInternet.FUNCTN_VALUE_ID=LigneInternet.PREVIOUS_FUNCTN_VALUE_ID
          Then Null
        Else
          Case  --Traitement pour supprimer la visibilité des mots de passe des client :
                When LigneInternet.PREVIOUS_FUNCTN_VALUE_ID in (${L_PIL_031})
                  Then '${P_PIL_322}'
                When Substring(trim(LigneInternet.PREVIOUS_FUNCTN_VALUE_ID) from 1 for 2)  = 'VF'
                  Then Null
                When LigneInternet.FUNCTN_ID in (${L_PIL_030}) And LigneInternet.PREVIOUS_FUNCTN_VALUE_ID is not null
                  Then Null
                Else
                  Case  When Trim(LigneInternet.PREVIOUS_FUNCTN_VALUE_ID) = ''
                          Then Null
                        Else LigneInternet.PREVIOUS_FUNCTN_VALUE_ID
                  End
          End
  End                                                       as PREVIOUS_SMPL_FNCTN_VALUE_NM   ,
  Case  When LigneInternet.FUNCTN_VALUE_ID  = LigneInternet.PREVIOUS_FUNCTN_VALUE_ID
          Then Null
        Else
          Case  --Traitement pour supprimer la visibilité des mots de passe des client :
                When LigneInternet.PREVIOUS_FUNCTN_VALUE_ID in (${L_PIL_031})
                  Then Null
                When Substring(trim(LigneInternet.PREVIOUS_FUNCTN_VALUE_ID) from 1 for 2)  = 'VF'
                  Then
                        LigneInternet.PREVIOUS_FUNCTN_VALUE_DS
                When LigneInternet.FUNCTN_ID in (${L_PIL_030}) And LigneInternet.PREVIOUS_FUNCTN_VALUE_ID is not null
                  Then
                        LigneInternet.PREVIOUS_FUNCTN_VALUE_DS
                Else Null
          End
  End                                                       as PREVIOUS_FUNCTN_VALUE_DS       ,
  LigneInternet.QUEUE_TS                                    as QUEUE_TS                       ,
  '${RUN_ID}'                                               as RUN_ID                         ,
  LigneInternet.STREAMING_TS                                as STREAMING_TS                   ,
  Current_Timestamp(0)                                      as CREATION_TS                    ,
  Null                                                      as LAST_MODIF_TS                  ,
  1                                                         as HOT_IN                         ,
  1                                                         as FRESH_IN                       ,
  0                                                         as COHERENCE_IN                   
From
  ${KNB_COM_TMP}.ATP_W_FACADE_ORDER_LINE_INT LigneInternet
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_COM_TMP}.ORD_T_ORDER_SOFT_LINE_INT;
.if errorcode <> 0 then .quit 1


