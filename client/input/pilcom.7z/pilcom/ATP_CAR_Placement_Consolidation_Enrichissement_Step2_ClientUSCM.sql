--$HEADER:   %HEADER% 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CAR_Placement_Consolidation_Enrichissement_Step2_ClientUSCM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 05/08/2015      AOU         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_CL_USCM All;
.if errorcode <> 0 then .quit 1





Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_CL_USCM
(
  ACTE_ID                   ,
  ORD_DEPOSIT_DT            ,
  PAR_USCM                  ,
  PAR_USCM_DS               ,
  PAR_USCM_USCM_DS          ,
  PAR_USCM_REGUSCM          ,
  PAR_USCM_REGUSCM_DS       
)
Select
  CalculTmp.ACTE_ID                 as ACTE_ID                    ,
  CalculTmp.ORD_DEPOSIT_DT          as ORD_DEPOSIT_DT             ,
  CalculTmp.PAR_USCM                as PAR_USCM                   ,
  --On enrichi les attributs du  code parc
  ReferentielUSCM.USCM_LL           as PAR_USCM_DS                ,
  ReferentielUSCM.USCM_LL_USCM      as PAR_USCM_USCM_DS           ,
  ReferentielUSCM.USCM_CO_REGUSCM   as PAR_USCM_REGUSCM           ,
  ReferentielUSCM.USCM_LB_REGUSCM   as PAR_USCM_REGUSCM_DS        
From
  (
    Select
      Tmp.ACTE_ID         as ACTE_ID        ,
      Tmp.ORD_DEPOSIT_DT  as ORD_DEPOSIT_DT ,
      --On calcul le code parc en fonction de la priorité
      Tmp.PAR_USCM        as PAR_USCM       
    From
      (
          --On enrichi en Premier Par client / et encadrement des date debut/fin
          Select
            RefId.ACTE_ID                             as ACTE_ID                ,
            RefId.ORD_DEPOSIT_DT                      as ORD_DEPOSIT_DT         ,
            Parc.PARCLI_USC_CO                        as PAR_USCM               ,
            1                                         as PRIO                   
          From
            ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_2 RefId
            Inner Join ${KNB_IBU_SOC}.V_THPARCLI Parc
              On    RefId.CLIENT_NU                             =   Parc.PARCLI_CLIENT_NU
                And (RefId.ORD_DEPOSIT_DT  - Interval '1' Day)  >=   Parc.PARCLI_DT_DEB
                And (
                        (RefId.ORD_DEPOSIT_DT  - Interval '1' Day)  <  Parc.PARCLI_DT_FIN
                      Or
                        Parc.PARCLI_DT_FIN Is Null
                    )
          Where
            (1=1)
            And   ( RefId.PAR_USCM Is Null )
            And   Parc.PARCLI_PLTF_CO <> 'VI1'
          Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Parc.PARCLI_DT_DEB Asc, Parc.PARCLI_DT_FIN Desc)=1
        Union all
          --On enrichi en Premier Par client / sur la date de début
          Select
            RefId.ACTE_ID                             as ACTE_ID                ,
            RefId.ORD_DEPOSIT_DT                      as ORD_DEPOSIT_DT         ,
            Parc.PARCLI_USC_CO                        as PAR_USCM               ,
            2                                         as PRIO                   
          From
            ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_2 RefId
            Inner Join ${KNB_IBU_SOC}.V_THPARCLI Parc
              On    RefId.CLIENT_NU                         =   Parc.PARCLI_CLIENT_NU
                And RefId.ORD_DEPOSIT_DT                    =   Parc.PARCLI_DT_DEB
          Where
            (1=1)
            And ( RefId.PAR_USCM Is Null )
            And   Parc.PARCLI_PLTF_CO <> 'VI1'
          Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Parc.CREATION_TS Desc)=1
        Union all
          --On enrichi en Premier Par client / sur la date de début
          Select
            RefId.ACTE_ID                             as ACTE_ID                ,
            RefId.ORD_DEPOSIT_DT                      as ORD_DEPOSIT_DT         ,
            Parc.PARCLI_USC_CO                        as PAR_USCM               ,
            3                                         as PRIO                   
          From
            ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_2 RefId
            Inner Join ${KNB_IBU_SOC}.V_THPARCLI Parc
              On    RefId.CLIENT_NU                             =   Parc.PARCLI_CLIENT_NU
                And (RefId.ORD_DEPOSIT_DT  - Interval '1' Day)  =   Parc.PARCLI_DT_DEB
          Where
            (1=1)
            And ( RefId.PAR_USCM Is Null )
            And   Parc.PARCLI_PLTF_CO <> 'VI1'
          Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Parc.CREATION_TS Desc)=1
        Union all
          --On enrichi en Premier Par client / toute Date
          Select
            RefId.ACTE_ID                             as ACTE_ID                ,
            RefId.ORD_DEPOSIT_DT                      as ORD_DEPOSIT_DT         ,
            Parc.PARCLI_USC_CO                        as PAR_USCM               ,
            4                                         as PRIO                   
          From
            ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_2 RefId
            Inner Join ${KNB_IBU_SOC}.V_THPARCLI Parc
              On    RefId.CLIENT_NU                           =   Parc.PARCLI_CLIENT_NU
          Where
            (1=1)
            And ( RefId.PAR_USCM Is Null)
          Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Parc.CREATION_TS Desc)=1
      )Tmp
    Qualify Row_number() Over (Partition by Tmp.ACTE_ID order by Tmp.PRIO asc)=1
  )CalculTmp
  Left Outer Join ${KNB_IBU_SOC}.V_TDUSCM ReferentielUSCM
    On    CalculTmp.PAR_USCM          = ReferentielUSCM.USCM_CO
      And ReferentielUSCM.CURRENT_IN  = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_CAR_CL_USCM;
.if errorcode <> 0 then .quit 1



.quit 0


