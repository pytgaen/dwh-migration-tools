-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  GEN_TableSumIHM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de la synthese de l'integration
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 18/08/2014      OCH         Creation
--------------------------------------------------------------------------------

.set width 2500;


Select 
         Trim (Coalesce(syn.NomTable,''))||
   '|'|| Trim (Coalesce(syn.NbLigne,''))||
   '|'|| Trim (Coalesce(Sum(NbLigne) over( partition by 1),'')) (title '')
From (
             Select 'ACT_F_ACT_EXF_CREA' As NomTable   , 
                    Count (*)            As NbLigne 
             From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA crea
             Where  crea.INJECTION_TS = ( Select Max(INJECTION_TS)
                                          From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_CREA
                                         )
             And Cast( crea.INJECTION_TS as Date ) = Current_Date
             UNION ALL
             Select 'ACT_F_ACT_EXF_MODIF' As NomTable   , 
                    Count (*)            As NbLigne 
             From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF modif
             Where  modif.INJECTION_TS = ( Select Max(INJECTION_TS)
                                           From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_MODIF
                                          )
             And Cast( modif.INJECTION_TS as Date ) = Current_Date
             UNION ALL
             Select 'ACT_F_ACT_EXF_SUPP' As NomTable   , 
                    Count (*)            As NbLigne 
             From  ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP supp
             Where  supp.INJECTION_TS = ( Select Max(INJECTION_TS)
                                          From ${KNB_PCO_IHM}.ACT_F_ACT_EXF_SUPP
                                        )
             And Cast( supp.INJECTION_TS as Date ) = Current_Date
) syn

 ;
 .if errorcode <> 0 then .quit 1
 
 .quit 0
