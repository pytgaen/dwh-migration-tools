--$HEADER: mm2pco/current/sql/ATP_SAH_Placement_Step1_Extraction.sql 13_05#14 27-NOV-2018 09:02:58 LXQG9925
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_SAH_Placement_Step1_Extraction.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'extraction SAVI SAH
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 05/07/2017      MDE         Creation
-- 18/09/2017      MDE         Modif : ajout filtre DOSSIER_DEB_DT au 01/10/2017
-- 23/05/2018      LMU         Ajout items Task Force + Corrections
-- 11/06/2018      LMU         Ajout etape 210
-- 12/06/2018      LMU         Modification : Ajout champ pour developpement BAL
-- 26/11/2018      LMU         Ajout extraction de la table TB_CLIENTS / SAV_F_CUSTOMER
-- 12/08/2020      ITA         Evolution SAVI REAP : PILCOM_404
-- 10/09/2020      ITA         PILCOM_404: Ajout de l etape 3 annulation ETP_FTT_CD =114
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table temporaire                                          ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT
(

    EXTERNAL_ORDR_ID                 ,
    ORDER_DEPOSIT_DT                 ,
    ORDER_DEPOSIT_TS                 ,
    ORDER_STATUS_CD                  ,
    ORDER_STATUS_DS                  ,
    ORDR_TYP_CD                      ,
    MOTIF_CD                         ,
    CODE_INTERNE_CD                  ,
    PREVIOUS_FAMILLE_CD              ,
    PREVIOUS_FAMILLE_LB              ,
    CIRCUIT_CD                       ,
    EST_GESTE_CO                     ,
    PAR_MSISDN_ID                    ,
    PAR_NDS                          ,
    EXT_AGENT_ID                     ,
    ORG_AGENT_ID                     ,
    ORG_LAST_NAME_NM                 ,
    ORG_FIRST_NAME_NM                ,
    EXT_SHOP_ID                      ,
    EXT_SHOP_ADV_CD                  ,
    PREVIOUS_EXT_PRODUCT_ID          ,
    PREVIOUS_EAN_CD                  ,
    PREVIOUS_IMEI_CD                 ,
    EXT_PRODUCT_ID                   ,
    EAN_CD                           ,
    IMEI_CD                          ,
    FAMILLE_CD                       ,
    FAMILLE_LB                       ,
    DOSSIER_DEB_DT                   ,
    DOSSIER_FIN_DT                   ,
    PANNE_CD                         ,
    AIDE_DIAG                        ,
    DIAG_PANNE_CD                    ,
    REPARATION_LB                    ,
    REPARATION_DT                    ,
    REPARATION_GARANTIE              ,
    PRE_DOSSIER                      ,
    NUMERO_CHRONOPOST                ,
    DOSSIER_PRET_CD                  ,
    DUPLIQUE_CD                      ,
    CASE_ID_SPAS                     ,
    CRI_CD                           ,
    COMMANDE_DT                      ,
    PANNE                            ,
    EST_GARANTIE                     ,
    CLIENT_CP                        ,
    FIN_GARANTIE_DT                  ,
    LIVRAISON_DT                     ,
    ACHAT_DT                         ,
    STATUT_COMMANDE_CD               ,
    POINT_RELAIS_CD                  ,
    PR_CODE_POSTAL_CD                ,
    LIVRAISON_MODE_CD                ,
    DATE1_PROPOSEE                   ,
    RI_DATE_ENVOI                    ,
    RI_POINT_RELAIS_RET_CD           ,
    PR_RI_CODE_POSTAL_CD             ,
    CLIENT_EAN_TERM                  ,
    ANNULATION_CD                    ,
    FACTURATION_MOTIF_CD             ,
    MOBILE_ECHANGE_DT                ,
    GARANTIE_FIN_DT                  ,
    ACCESSOIRE_CD                    ,
    IMEI_COFFRET                     ,
    PAYS_FIRST_CD                    ,
    MOTIF_PRET_CD                    ,
    PRET_PAYANT                      ,
    RESTITUTION_TERMINAL             ,
    ETAT_TERM_PRET_CD                ,
    A_ETE_FACT_PRET                  ,
    A_ETE_FACT_RESTI                 ,
    FAIT_GENERATEUR_DT               ,
    MOTIF_RESILIATION_CD             ,
    SYSTEME_FACTURATION              , --PILCOM_404
    ALLEGRO_CD                       , --PILCOM_404
    MONTANT_FACT_ALLEGRO             , --PILCOM_404
    TYPE_PROCESS                     , --PILCOM_404
    ETP_ANNUL_CD                     ,
    ETP_ANNUL_TS                     ,
    ETP_ANNUL_USR_CD                 ,
    ETP_ANNUL_ALLIANCE_CD            ,
    ETP_ANNUL_COMPTE_CD              ,
    ETP_ANNUL_EDO_ID                 

)
Select 
 
    ISE.DOSSIER_SAV_CD                                                          As EXTERNAL_ORDR_ID  ,
    Null                                                                        As ORDER_DEPOSIT_DT , 
    Null                                                                        As ORDER_DEPOSIT_TS , 
     ISE.ETAPE_EN_COURS                                                         As ORDER_STATUS_CD   ,
    Case  When  ISE.ETAPE_EN_COURS  in (90 , 80 ,70 )  
              Then  'Annulé'   
             Else Null 
     End                                                                        As ORDER_STATUS_DS ,
    Null                                                                        As ORDR_TYP_CD ,
    RN.TYPE_ACTE                                                                As MOTIF_CD,
    ISE.NATURE_SAV_CD                                                           As CODE_INTERNE_CD ,
    FRDET.FAMILLE_CD                                                            AS PREVIOUS_FAMILLE_CD ,
    ISE.FAMILLE_LB                                                              As PREVIOUS_FAMILLE_LB,
    RN.CIRCUIT_CD                                                               As CIRCUIT_CD  ,
    RN.EST_GESTE_CO As EST_GESTE_CO ,
    Case  When Substring(Trim( ISE.D_CLIENT_ND ) From 2 For 1)  in ('6','7')  
              Then   ISE.D_CLIENT_ND       
             Else Null 
     End                                                                        As PAR_MSISDN_ID ,
      Case  When Substring(Trim(ISE.D_CLIENT_ND) From 2 For 1)  in ('1','2','3','4','5')  
              Then ISE.D_CLIENT_ND
            Else Null 
      End                                                                       As PAR_NDS ,
     ISE.USER_CD                                                                As EXT_AGENT_ID ,
     USR.ID_ALLIANCE                                                            As ORG_AGENT_ID ,
     USR.NOM_USER                                                               As ORG_LAST_NAME_NM ,
     USR.PRENOM_USER                                                            As ORG_FIRST_NAME_NM ,
     ORGA.COMPTE_CD                                                             As EXT_SHOP_ID ,
     ORGA.CODE_ADV                                                              As EXT_SHOP_ADV_CD ,
     ISE.PANTERE_CD                                                             As PREVIOUS_EXT_PRODUCT_ID ,
     TRDET.EAN13_CD                                                             As PREVIOUS_EAN_CD ,
     coalesce (ISE.NUM_SERIE_IMEI,ORD.NUM_SERIE_IMEI, lon.NUM_SERIE_IMEI)       As PREVIOUS_IMEI_CD ,
     ISE.EC_PANTERE_CD                                                          As EXT_PRODUCT_ID ,
     TRFOUR.EAN13_CD                                                            As EAN_CD ,
     coalesce (ISE.EC_NUM_SERIE_IMEI,ORD.EC_NUM_SERIE_IMEI)                     As IMEI_CD ,
     FRFOUR.FAMILLE_CD                                                          As FAMILLE_CD ,
     ISE.EC_FAMILLE_LB                                                          As FAMILLE_LB ,
     ISE.DOSSIER_DEB_DT                                                         As DOSSIER_DEB_DT ,
     ISE.DOSSIER_FIN_DT                                                         As DOSSIER_FIN_DT ,
     ISE.PANNE_CD                                                               As PANNE_CD ,
     ISE.AIDE_DIAG                                                              As AIDE_DIAG ,
     ISE.DIAG_PANNE_CD                                                          As DIAG_PANNE_CD  ,
     ISE.REPARATION_LB                                                          As REPARATION_LB ,
     ISE.REPARATION_DT                                                          As REPARATION_DT ,
     ISE.REPARATION_GARANTIE                                                    As REPARATION_GARANTIE ,
     PRE_DOSSIER                                                                As PRE_DOSSIER ,
     ISE.NUMERO_CHRONOPOST                                                      As NUMERO_CHRONOPOST ,
     ISE.DOSSIER_PRET_CD                                                        As DOSSIER_PRET_CD,
     ISE.DUPLIQUE_CD                                                            As  DUPLIQUE_CD,
     ISE.CASE_ID_SPAS                                                           As CASE_ID_SPAS,
     ISE.CRI_CD                                                                 As CRI_CD  ,
     ORD.COMMANDE_DT                                                            As COMMANDE_DT ,
     ORD.PANNE                                                                  As PANNE,
     ORD.EST_GARANTIE                                                           As EST_GARANTIE,
     ORD.CLIENT_CP                                                              As CLIENT_CP ,
     ORD.FIN_GARANTIE_DT                                                        As FIN_GARANTIE_DT,
     ORD.LIVRAISON_DT                                                           As LIVRAISON_DT,
     ORD.ACHAT_DT                                                               As ACHAT_DT,
     ORD.STATUT_COMMANDE_CD                                                     As STATUT_COMMANDE_CD ,
     ORD.POINT_RELAIS_CD                                                        As POINT_RELAIS_CD,
     SP.CODE_POSTAL_CD                                                          As PR_CODE_POSTAL_CD ,
     --SP.CODE_POSTAL_CD                                                          As CODE_POSTAL_CD ,
     ORD.LIVRAISON_MODE_CD                                                      As LIVRAISON_MODE_CD ,
     ORD.DATE1_PROPOSEE                                                         As DATE1_PROPOSEE     , 
     ORD.RI_DATE_ENVOI                                                          As RI_DATE_ENVOI ,
     ORD.RI_POINT_RELAIS_RET_CD                                                 As RI_POINT_RELAIS_RET_CD ,
     SPO.CODE_POSTAL_CD                                                         As PR_RI_CODE_POSTAL_CD  ,
     ORD.CLIENT_EAN_TERM                                                        As CLIENT_EAN_TERM ,
     MC.ANNULATION_CD                                                           As ANNULATION_CD ,
     MC.FACTURATION_MOTIF_CD                                                    As FACTURATION_MOTIF_CD ,
     MC.MOBILE_ECHANGE_DT                                                       As MOBILE_ECHANGE_DT ,
     MC.GARANTIE_FIN_DT                                                         As GARANTIE_FIN_DT ,
     AC.ACCESSOIRE_CD                                                           As ACCESSOIRE_CD ,
     AC.IMEI_COFFRET                                                            As IMEI_COFFRET ,
     AC.PAYS_FIRST_CD                                                           As PAYS_FIRST_CD  ,
    lon.MOTIF_PRET_CD                                                           As MOTIF_PRET_CD  ,
    lon.PRET_PAYANT                                                             As PRET_PAYANT ,
    lon.RESTITUTION_TERMINAL                                                    As RESTITUTION_TERMINAL ,
    lon.ETAT_TERM_PRET_CD                                                       As ETAT_TERM_PRET_CD ,
    lon.A_ETE_FACT_PRET                                                         As A_ETE_FACT_PRET ,
    lon.A_ETE_FACT_RESTI                                                        As A_ETE_FACT_RESTI  ,
    cust.FAIT_GENERATEUR_DT                                                     As FAIT_GENERATEUR_DT , 
    cust.MOTIF_RESILIATION_CD                                                   As MOTIF_RESILIATION_CD, 
    CUST.SYSTEME_FACTURATION                                                    As SYSTEME_FACTURATION              , --PILCOM_404
    ISE.ALLEGRO_CD                                                              As ALLEGRO_CD                       , --PILCOM_404
    ISE.MONTANT_FACT_ALLEGRO                                                    As MONTANT_FACT_ALLEGRO             , --PILCOM_404
    RN.NATURE_LB_FTT                                                            As TYPE_PROCESS                     , --PILCOM_404
     -- Annulation 
    NULL                                                                        As ETP_ANNUL_CD                     ,
    NULL                                                                        As ETP_ANNUL_TS                     ,
    NULL                                                                        As ETP_ANNUL_USR_CD                 ,
    NULL                                                                        As ETP_ANNUL_ALLIANCE_CD            ,
    NULL                                                                        As ETP_ANNUL_COMPTE_CD              ,
    NULL                                                                        As ETP_ANNUL_EDO_ID                 
    

FROM ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_AFTER_SALE   ISE    

  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_F_ORDER_FTT  ORD
  On  ORD.DOSSIER_SAV_CD= ISE.DOSSIER_SAV_CD 
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_MOBILE  MC
  On MC.DOSSIER_SAV_CD= ISE.DOSSIER_SAV_CD 
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_F_ANOVO_PARTNER AC
  On AC.DOSSIER_SAV_CD= ISE.DOSSIER_SAV_CD 
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_KIND_AFTER_SALE RN
  On RN.NATURE_SAV_CD = ISE.NATURE_SAV_CD
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_DEVICE_FAMILY FRDET
  On FRDET.FAMILLE_LB = ISE.FAMILLE_LB
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_DEVICE_FAMILY FRFOUR
  On FRFOUR.FAMILLE_LB = ISE.EC_FAMILLE_LB
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_SERVICE_POINT SP
  On SP.POINT_RELAIS_CD = ORD.POINT_RELAIS_CD
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_SERVICE_POINT SPO
  On SPO.POINT_RELAIS_CD = ORD.RI_POINT_RELAIS_RET_CD
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_DEVICE TRDET 
  On TRDET.PANTERE_CD =ISE.PANTERE_CD
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_DEVICE TRFOUR
  On TRFOUR.PANTERE_CD =ISE.EC_PANTERE_CD
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_ORGA ORGA  
  On ORGA.COMPTE_CD =ISE.COMPTE_CD
  
  Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_R_USER USR
  On USR.USER_CD =ISE.USER_CD
  
   Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_F_LOAN LON
  On LON.DOSSIER_PRET_CD= ISE.DOSSIER_SAV_CD 
  
   Left  Outer Join   ${KNB_COM_SOC_V_PRS}.SAV_F_CUSTOMER CUST
   On CUST.CLIENT_CD = ISE.CLIENT_CD
   
   
where (1=1)
  And    ISE.DOSSIER_DEB_DT  >=  add_months(current_date ,-6)     --- ajouter filtre sur 6 mois 
  And    ISE.DOSSIER_DEB_DT  >=   cast('01102017' as date format 'DDMMYYYY')
  And    ISE.NATURE_SAV_CD   Is Not Null
 Qualify Row_Number() Over (Partition By  ISE.DOSSIER_SAV_CD Order By ISE.DOSSIER_DEB_DT Asc) = 1
;
.if errorcode <> 0 then .quit 1                                       

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT;             

.if errorcode <> 0 then .quit 1               



----------------------------------------------------------------------------------------------
-- Etape 2 : Creation/Alim  table volatile pour gerer les etapes                          ----
---------------------------------------------------------------------------------------------- 
-- US PILCOM_404 : 
-- AJOUT DES 4 NOUVEAUX CHAMPS  SYSTEME_FACTURATION ,  ALLEGRO_CD , MONTANT_FACT_ALLEGRO ET TYPE_PROCESS 
-- SUPPRESSION DES COLONNES 
-- ETP_X_TS, ETP_X_USR_CD, ETP_X_ALLIANCE_CD, ETP_X_COMPTE_CD, ETP_X_EDO_ID 
-- AVEC X <> 0,200,1,101,20,204
                       
  create volatile table ${KNB_TERADATA_USER}.ORD_V_EXT_ETP
 ( 
    EXTERNAL_ORDR_ID BIGINT NOT NULL,
    ETP_0_CD SMALLINT, 
    ETP_0_TS TIMESTAMP(0), 
    ETP_0_USR_CD VARCHAR(25), 
    ETP_0_ALLIANCE_CD VARCHAR(25)  ,
    ETP_0_COMPTE_CD  VARCHAR(25)   ,
    ETP_0_EDO_ID VARCHAR(25) , 
    ETP_0_ADV_CD VARCHAR(10),
    ETP_200_CD SMALLINT, 
    ETP_200_TS TIMESTAMP(0), 
    ETP_200_USR_CD VARCHAR(25), 
    ETP_200_ALLIANCE_CD VARCHAR(25)  ,
    ETP_200_COMPTE_CD  VARCHAR(25)   ,
    ETP_200_EDO_ID VARCHAR(25) ,
    ETP_200_ADV_CD VARCHAR(10),
    ETP_200_COM_FTT VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific,
    ETP_1_CD SMALLINT, 
    ETP_1_TS TIMESTAMP(0), 
    ETP_1_USR_CD VARCHAR(25), 
    ETP_1_ALLIANCE_CD VARCHAR(25)  ,
    ETP_1_COMPTE_CD  VARCHAR(25)   ,
    ETP_1_EDO_ID VARCHAR(25) , 
    ETP_1_ADV_CD VARCHAR(10),
    ETP_101_CD SMALLINT, 
    ETP_101_TS TIMESTAMP(0), 
    ETP_101_USR_CD VARCHAR(25), 
    ETP_101_ALLIANCE_CD VARCHAR(25)  ,
    ETP_101_COMPTE_CD  VARCHAR(25)   ,
    ETP_101_EDO_ID VARCHAR(25) , 
    ETP_101_ADV_CD VARCHAR(10),
    ETP_101_COM_FTT VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific,
    ETP_20_CD SMALLINT, 
    ETP_20_TS TIMESTAMP(0), 
    ETP_20_USR_CD VARCHAR(25), 
    ETP_20_ALLIANCE_CD VARCHAR(25)  ,
    ETP_20_COMPTE_CD  VARCHAR(25)   ,
    ETP_20_EDO_ID VARCHAR(25) , 
    ETP_20_ADV_CD VARCHAR(10),
    ETP_125_CD SMALLINT,
    ETP_125_TS TIMESTAMP(0),
    ETP_125_USR_CD VARCHAR(25),
    ETP_125_ALLIANCE_CD VARCHAR(25)  ,
    ETP_125_COMPTE_CD  VARCHAR(25)   ,
    ETP_125_EDO_ID VARCHAR(25) ,
    ETP_125_COM_FTT VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific,
    ETP_204_CD SMALLINT,
    ETP_204_TS TIMESTAMP(0),
    ETP_204_USR_CD VARCHAR(25), 
    ETP_204_ALLIANCE_CD VARCHAR(25), 
    ETP_204_COMPTE_CD VARCHAR(25), 
    ETP_204_EDO_ID VARCHAR(25),
    ETP_204_ADV_CD VARCHAR(10),
    ETP_204_COM_FTT VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific    
)
 
  Primary Index (
    EXTERNAL_ORDR_ID
         )
On Commit Preserve Rows
;
Collect Stat On  ${KNB_TERADATA_USER}.ORD_V_EXT_ETP Column( EXTERNAL_ORDR_ID);
.if errorcode <> 0 then .quit 1

-- US PILCOM_404 : 
-- AJOUT DES 4 NOUVEAUX CHAMPS  SYSTEME_FACTURATION ,  ALLEGRO_CD , MONTANT_FACT_ALLEGRO ET TYPE_PROCESS 
-- SUPPRESSION DES COLONNES 
-- ETP_X_TS, ETP_X_USR_CD, ETP_X_ALLIANCE_CD, ETP_X_COMPTE_CD, ETP_X_EDO_ID 
-- AVEC X <> 0,200,1,101,20,204

insert into ${KNB_TERADATA_USER}.ORD_V_EXT_ETP  
(
    EXTERNAL_ORDR_ID    ,
    ETP_0_CD            ,
    ETP_0_TS            ,
    ETP_0_USR_CD        ,
    ETP_0_ALLIANCE_CD   ,
    ETP_0_COMPTE_CD     ,
    ETP_0_EDO_ID        ,
    ETP_0_ADV_CD        ,
    ETP_200_CD          ,
    ETP_200_TS          ,
    ETP_200_USR_CD      ,
    ETP_200_ALLIANCE_CD ,
    ETP_200_COMPTE_CD   ,
    ETP_200_EDO_ID      ,
    ETP_200_ADV_CD      ,
    ETP_200_COM_FTT     ,
    ETP_1_CD            ,
    ETP_1_TS            ,
    ETP_1_USR_CD        ,
    ETP_1_ALLIANCE_CD   ,
    ETP_1_COMPTE_CD     ,
    ETP_1_EDO_ID        ,
    ETP_1_ADV_CD        ,
    ETP_101_CD          ,
    ETP_101_TS          ,
    ETP_101_USR_CD      ,
    ETP_101_ALLIANCE_CD ,
    ETP_101_COMPTE_CD   ,
    ETP_101_EDO_ID      ,
    ETP_101_ADV_CD      ,
    ETP_101_COM_FTT     ,
    ETP_20_CD           ,
    ETP_20_TS           ,
    ETP_20_USR_CD       ,
    ETP_20_ALLIANCE_CD  ,
    ETP_20_COMPTE_CD    ,
    ETP_20_EDO_ID       ,
    ETP_20_ADV_CD       ,
    ETP_125_CD          ,
    ETP_125_TS          ,
    ETP_125_USR_CD      ,
    ETP_125_ALLIANCE_CD ,
    ETP_125_COMPTE_CD   ,
    ETP_125_EDO_ID      ,
    ETP_125_COM_FTT     ,
    ETP_204_CD          ,
    ETP_204_TS          ,
    ETP_204_USR_CD      ,
    ETP_204_ALLIANCE_CD ,
    ETP_204_COMPTE_CD   ,
    ETP_204_EDO_ID      ,
    ETP_204_ADV_CD      ,
    ETP_204_COM_FTT     
    
)

Select  
  ISE.DOSSIER_SAV_CD                                                            As EXTERNAL_ORDR_ID ,
  Case When ISP.ETAPE_CD = 0  Then ISP.ETAPE_CD Else Null End                   As ETP_0_CD ,
  Case When ISP.ETAPE_CD = 0  Then ISP.ETAPE_TS Else Null End                   As ETP_0_TS ,
  Case When ISP.ETAPE_CD = 0  Then ISP.USER_CD Else Null End                    As ETP_0_USR_CD ,
  Case When ISP.ETAPE_CD = 0  Then USR.ID_ALLIANCE Else Null End                As ETP_0_ALLIANCE_CD   ,
  Case When ISP.ETAPE_CD = 0  Then USR.COMPTE_CD  Else Null End                 As ETP_0_COMPTE_CD     ,
  Case When ISP.ETAPE_CD = 0  Then USR.COMPTE_CD  Else Null End                 As ETP_0_EDO_ID ,
  Case When ISP.ETAPE_CD = 0  Then ORGAS.CODE_ADV  Else Null End                As ETP_0_ADV_CD ,  
             --          generaliser 
  Case When OSP.ETP_FTT_CD = 200  Then OSP.ETP_FTT_CD Else Null End              As ETP_200_CD ,
  Case When OSP.ETP_FTT_CD = 200  Then ISE.DOSSIER_DEB_DT Else Null End          As ETP_200_TS ,
  Case When OSP.ETP_FTT_CD = 200  Then ISE.USER_CD Else Null End                 As ETP_200_USR_CD ,
  Case When OSP.ETP_FTT_CD = 200  Then OSP.ACTEUR_LB Else Null End               As ETP_200_ALLIANCE_CD   ,
  Case When OSP.ETP_FTT_CD = 200  Then ISE.COMPTE_CD   Else Null End             As ETP_200_COMPTE_CD     ,
  Case When OSP.ETP_FTT_CD = 200  Then ISE.COMPTE_CD  Else Null End              As ETP_200_EDO_ID ,
  Case When OSP.ETP_FTT_CD = 200  Then ORGA.CODE_ADV  Else Null End              As ETP_200_ADV_CD ,
  Case When OSP.ETP_FTT_CD = 200  Then OSP.COMMENTAIRE_FTT  Else Null End        As ETP_200_COM_FTT,
        --
  Case When ISP.ETAPE_CD = 1  Then ISP.ETAPE_CD Else Null End                   As ETP_1_CD ,
  Case When ISP.ETAPE_CD = 1  Then ISP.ETAPE_TS Else Null End                   As ETP_1_TS ,
  Case When ISP.ETAPE_CD = 1  Then ISP.USER_CD Else Null End                    As ETP_1_USR_CD ,
  Case When ISP.ETAPE_CD = 1  Then USR.ID_ALLIANCE Else Null End                As ETP_1_ALLIANCE_CD   ,
  Case When ISP.ETAPE_CD = 1  Then USR.COMPTE_CD  Else Null End                 As ETP_1_COMPTE_CD     ,
  Case When ISP.ETAPE_CD = 1  Then USR.COMPTE_CD  Else Null End                 As ETP_1_EDO_ID ,
  Case When ISP.ETAPE_CD = 1  Then ORGAS.CODE_ADV  Else Null End                As ETP_1_ADV_CD , 
  
  --
  Case When OSP.ETP_FTT_CD = 101  Then OSP.ETP_FTT_CD Else Null End             As ETP_101_CD ,
  Case When OSP.ETP_FTT_CD = 101  Then OSP.ETAPE_FTT_DT Else Null End           As ETP_101_TS ,
  Case When OSP.ETP_FTT_CD = 101  Then UR.USER_CD Else Null End                 As ETP_101_USR_CD ,
  Case When OSP.ETP_FTT_CD = 101  Then OSP.ACTEUR_LB Else Null End              As ETP_101_ALLIANCE_CD   ,
  Case When OSP.ETP_FTT_CD = 101  Then UR.COMPTE_CD  Else Null End              As ETP_101_COMPTE_CD     ,
  Case When OSP.ETP_FTT_CD = 101  Then UR.COMPTE_CD  Else Null End              As ETP_101_EDO_ID ,
  Case When OSP.ETP_FTT_CD = 101  Then ORGA.CODE_ADV  Else Null End             As ETP_101_ADV_CD ,
  Case When OSP.ETP_FTT_CD = 101  Then OSP.COMMENTAIRE_FTT  Else Null End       As ETP_101_COM_FTT,
    
  Case When ISP.ETAPE_CD = 20  Then ISP.ETAPE_CD Else Null End                  As ETP_20_CD ,
  Case When ISP.ETAPE_CD = 20  Then ISP.ETAPE_TS Else Null End                  As ETP_20_TS ,
  Case When ISP.ETAPE_CD = 20  Then ISP.USER_CD Else Null End                   As ETP_20_USR_CD ,
  Case When ISP.ETAPE_CD = 20  Then USR.ID_ALLIANCE Else Null End               As ETP_20_ALLIANCE_CD   ,
  Case When ISP.ETAPE_CD = 20  Then USR.COMPTE_CD  Else Null End                As ETP_20_COMPTE_CD     ,
  Case When ISP.ETAPE_CD = 20  Then USR.COMPTE_CD  Else Null End                As ETP_20_EDO_ID ,
  Case When ISP.ETAPE_CD = 20  Then ORGAS.CODE_ADV  Else Null End               As ETP_20_ADV_CD , 
  
  Case When OSP.ETP_FTT_CD  = 125  Then OSP.ETP_FTT_CD Else Null End            As ETP_125_CD ,
  Case When OSP.ETP_FTT_CD  = 125  Then OSP.ETAPE_FTT_DT Else Null End          As ETP_125_TS ,
  Case When OSP.ETP_FTT_CD  = 125  Then UR.USER_CD Else Null End                As ETP_125_USR_CD ,
  Case When OSP.ETP_FTT_CD  = 125  Then OSP.ACTEUR_LB Else Null End             As ETP_125_ALLIANCE_CD   ,
  Case When OSP.ETP_FTT_CD  = 125  Then UR.COMPTE_CD  Else Null End             As ETP_125_COMPTE_CD     ,
  Case When OSP.ETP_FTT_CD  = 125  Then UR.COMPTE_CD  Else Null End             As ETP_125_EDO_ID ,
  Case When OSP.ETP_FTT_CD  = 125  Then OSP.COMMENTAIRE_FTT  Else Null End      As ETP_125_COM_FTT,
  
  Case When OSP.ETP_FTT_CD  = 204  Then OSP.ETP_FTT_CD Else Null End            As ETP_204_CD,
  Case When OSP.ETP_FTT_CD  = 204  Then OSP.ETAPE_FTT_DT Else Null End          As ETP_204_TS,
  Case When OSP.ETP_FTT_CD  = 204  Then UR.USER_CD Else Null End                As ETP_204_USR_CD,
  Case When OSP.ETP_FTT_CD  = 204  Then OSP.ACTEUR_LB Else Null End             As ETP_204_ALLIANCE_CD,
  Case When OSP.ETP_FTT_CD  = 204  Then UR.COMPTE_CD  Else Null End             As ETP_204_COMPTE_CD,
  Case When OSP.ETP_FTT_CD  = 204  Then UR.COMPTE_CD  Else Null End             As ETP_204_EDO_ID,
  Case When OSP.ETP_FTT_CD  = 204  Then ORGA.CODE_ADV  Else Null End            As ETP_204_ADV_CD,
  Case When OSP.ETP_FTT_CD  = 204  Then COMMENTAIRE_FTT  Else Null End          As ETP_204_COM_FTT

  
 FROM ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_AFTER_SALE   ISE  
 Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT  PRS
      On  PRS.EXTERNAL_ORDR_ID  = ISE.DOSSIER_SAV_CD
   Left Join ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_STEP ISP
     On  ISP.dossier_sav_cd= ISE.dossier_sav_cd 
     And ISP.ETAPE_CD in (20, 21, 22, 25, 26, 71, 0, 1,20 ) 
   Left Join ${KNB_COM_SOC_V_PRS}.SAV_F_ORDER_STEP OSP
    On   OSP.dossier_sav_cd= ISE.dossier_sav_cd 
    And  OSP.ETP_FTT_CD in  (125, 140, 165, 183, 170,200,101, 110, 204, 210 )
   Left Join ${KNB_COM_SOC_V_PRS}.SAV_R_USER USR
    On  USR.USER_CD =ISP.USER_CD
  Left Join ${KNB_COM_SOC_V_PRS}.SAV_R_USER UR
    On    UR.ID_ALLIANCE =OSP.ACTEUR_LB
    And     coalesce (UR.DEPART_DT , current_date )  >=  OSP.ETAPE_FTT_DT
    And     UR.ARRIVEE_DT                            <= OSP.ETAPE_FTT_DT 
  Left Join      ${KNB_COM_SOC_V_PRS}.SAV_R_ORGA ORGA  
    On UR.COMPTE_CD =ORGA.COMPTE_CD
  Left Join       ${KNB_COM_SOC_V_PRS}.SAV_R_ORGA ORGAS  
    On USR.COMPTE_CD =ORGAS.COMPTE_CD
 where  (1=1)
 Qualify Row_Number() Over (Partition By  ISE.DOSSIER_SAV_CD,ISP.ETAPE_CD, OSP.ETP_FTT_CD  Order By   ISE.DOSSIER_DEB_DT asc , OSP.ETAPE_FTT_DT asc , ISP.ETAPE_TS asc , UR.ARRIVEE_DT desc ) = 1    
  ;

.if errorcode <> 0 then .quit 1                                       

Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_ETP;             

.if errorcode <> 0 then .quit 1     
----------------------------------------------------------------------------------------------
-- Etape 4 : del table  ORD_W_PLACEMENT_SAH_STEP_EXT                          ----
----------------------------------------------------------------------------------------------  
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EXT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Alimentation de la table temporaire                                          ----
----------------------------------------------------------------------------------------------
-- US PILCOM_404 : 
-- AJOUT DES 4 NOUVEAUX CHAMPS  SYSTEME_FACTURATION ,  ALLEGRO_CD , MONTANT_FACT_ALLEGRO ET TYPE_PROCESS 
-- SUPPRESSION DES COLONNES 
-- ETP_X_TS, ETP_X_USR_CD, ETP_X_ALLIANCE_CD, ETP_X_COMPTE_CD, ETP_X_EDO_ID 
-- AVEC X <> 0,200,1,101,20,204
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EXT
(
    EXTERNAL_ORDR_ID    ,
    ETP_0_CD            ,
    ETP_0_TS            ,
    ETP_0_USR_CD        ,
    ETP_0_ALLIANCE_CD   ,
    ETP_0_COMPTE_CD     ,
    ETP_0_EDO_ID        ,
    ETP_0_ADV_CD        ,
    ETP_200_CD          ,
    ETP_200_TS          ,
    ETP_200_USR_CD      ,
    ETP_200_ALLIANCE_CD ,
    ETP_200_COMPTE_CD   ,
    ETP_200_EDO_ID      ,
    ETP_200_ADV_CD      ,
    ETP_200_COM_FTT     ,
    ETP_1_CD            ,
    ETP_1_TS            ,
    ETP_1_USR_CD        ,
    ETP_1_ALLIANCE_CD   ,
    ETP_1_COMPTE_CD     ,
    ETP_1_EDO_ID        ,
    ETP_1_ADV_CD        ,
    ETP_101_CD          ,
    ETP_101_TS          ,
    ETP_101_USR_CD      ,
    ETP_101_ALLIANCE_CD ,
    ETP_101_COMPTE_CD   ,
    ETP_101_EDO_ID      ,
    ETP_101_ADV_CD      ,
    ETP_101_COM_FTT     ,
    ETP_20_CD           ,
    ETP_20_TS           ,
    ETP_20_USR_CD       ,
    ETP_20_ALLIANCE_CD  ,
    ETP_20_COMPTE_CD    ,
    ETP_20_EDO_ID       ,
    ETP_20_ADV_CD       ,
    ETP_125_CD          ,
    ETP_125_TS          ,
    ETP_125_USR_CD      ,
    ETP_125_ALLIANCE_CD ,
    ETP_125_COMPTE_CD   ,
    ETP_125_EDO_ID      ,
    ETP_125_COM_FTT     ,    
    ETP_204_CD          ,
    ETP_204_TS          ,
    ETP_204_USR_CD      ,
    ETP_204_ALLIANCE_CD ,
    ETP_204_COMPTE_CD   ,
    ETP_204_EDO_ID      ,
    ETP_204_ADV_CD      ,
    ETP_204_COM_FTT     
    
)

Select
      
    ext.EXTERNAL_ORDR_ID                              As EXTERNAL_ORDR_ID      ,
    Max ( ext.ETP_0_CD        )                       As ETP_0_CD              ,
    Max ( ext.ETP_0_TS        )                       As ETP_0_TS              ,
    Max ( ext.ETP_0_USR_CD    )                       As ETP_0_USR_CD          ,
    Max ( ext.ETP_0_ALLIANCE_CD )                     As ETP_0_ALLIANCE_CD     ,
    Max ( ext.ETP_0_COMPTE_CD )                       As ETP_0_COMPTE_CD       ,
    Max ( ext.ETP_0_EDO_ID    )                       As ETP_0_EDO_ID          ,
    Max ( ext.ETP_0_ADV_CD    )                       As ETP_0_ADV_CD          ,
    Max ( ext.ETP_200_CD      )                       As ETP_200_CD            ,
    Max ( ext.ETP_200_TS      )                       As ETP_200_TS            ,
    Max ( ext.ETP_200_USR_CD  )                       As ETP_200_USR_CD        ,
    Max ( ext.ETP_200_ALLIANCE_CD )                   As ETP_200_ALLIANCE_CD   ,
    Max ( ext.ETP_200_COMPTE_CD )                     As ETP_200_COMPTE_CD     ,
    Max ( ext.ETP_200_EDO_ID  )                       As ETP_200_EDO_ID        ,
    Max ( ext.ETP_200_ADV_CD    )                     As ETP_200_ADV_CD        ,
    Max ( ext.ETP_200_COM_FTT  )                      As ETP_200_COM_FTT       ,
    Max ( ext.ETP_1_CD        )                       As ETP_1_CD              ,
    Max ( ext.ETP_1_TS        )                       As ETP_1_TS              ,
    Max ( ext.ETP_1_USR_CD    )                       As ETP_1_USR_CD          ,
    Max ( ext.ETP_1_ALLIANCE_CD )                     As ETP_1_ALLIANCE_CD     ,
    Max ( ext.ETP_1_COMPTE_CD )                       As ETP_1_COMPTE_CD       ,
    Max ( ext.ETP_1_EDO_ID    )                       As ETP_1_EDO_ID          ,
    Max ( ext.ETP_1_ADV_CD    )                       As ETP_1_ADV_CD          ,
    Max ( ext.ETP_101_CD      )                       As ETP_101_CD            ,
    Max ( ext.ETP_101_TS      )                       As ETP_101_TS            ,
    Max ( ext.ETP_101_USR_CD  )                       As ETP_101_USR_CD        ,
    Max ( ext.ETP_101_ALLIANCE_CD )                   As ETP_101_ALLIANCE_CD   ,
    Max ( ext.ETP_101_COMPTE_CD )                     As ETP_101_COMPTE_CD     ,
    Max ( ext.ETP_101_EDO_ID )                        As ETP_101_EDO_ID        ,
    Max ( ext.ETP_101_ADV_CD    )                     As ETP_101_ADV_CD        ,
    Max ( ext.ETP_101_COM_FTT    )                    As ETP_101_COM_FTT       ,
    Max ( ext.ETP_20_CD      )                        As ETP_20_CD             ,
    Max ( ext.ETP_20_TS      )                        As ETP_20_TS             ,
    Max ( ext.ETP_20_USR_CD  )                        As ETP_20_USR_CD         ,
    Max ( ext.ETP_20_ALLIANCE_CD )                    As ETP_20_ALLIANCE_CD    ,
    Max ( ext.ETP_20_COMPTE_CD )                      As ETP_20_COMPTE_CD      ,
    Max ( ext.ETP_20_EDO_ID  )                        As ETP_20_EDO_ID         ,
    Max ( ext.ETP_20_ADV_CD    )                      As ETP_20_ADV_CD         ,
    Max ( ext.ETP_125_CD      )                       As ETP_125_CD            ,
    Max ( ext.ETP_125_TS      )                       As ETP_125_TS            ,
    Max ( ext.ETP_125_USR_CD  )                       As ETP_125_USR_CD        ,
    Max ( ext.ETP_125_ALLIANCE_CD )                   As ETP_125_ALLIANCE_CD   ,
    Max ( ext.ETP_125_COMPTE_CD )                     As ETP_125_COMPTE_CD     ,
    Max ( ext.ETP_125_EDO_ID  )                       As ETP_125_EDO_ID        ,
    Max ( ext.ETP_125_COM_FTT  )                      As ETP_125_COM_FTT       ,
    Max( ext.ETP_204_CD)                              As ETP_204_CD            ,
    Max( ext.ETP_204_TS)                              As ETP_204_TS            ,
    Max( ext.ETP_204_USR_CD)                          As ETP_204_USR_CD        ,
    Max( ext.ETP_204_ALLIANCE_CD)                     As ETP_204_ALLIANCE_CD   ,
    Max( ext.ETP_204_COMPTE_CD)                       As ETP_204_COMPTE_CD     ,
    Max( ext.ETP_204_EDO_ID)                          As ETP_204_EDO_ID        ,
    Max( ext.ETP_204_ADV_CD    )                      As ETP_204_ADV_CD        ,
    Max( ext.ETP_204_COM_FTT)                         As ETP_204_COM_FTT       

 From
     ${KNB_TERADATA_USER}.ORD_V_EXT_ETP  ext
 Where
(1=1)

 group by ext.EXTERNAL_ORDR_ID    ;
  
.if errorcode <> 0 then .quit 1                                       

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EXT;             

.if errorcode <> 0 then .quit 1     
  
  

 ----------------------------------------------------------------------------------------------
-- Etape 3 : Fusion des extractions  REA                                                  ----
----------------------------------------------------------------------------------------------
-- US PILCOM_404 : 
-- AJOUT DES 4 NOUVEAUX CHAMPS  SYSTEME_FACTURATION ,  ALLEGRO_CD , MONTANT_FACT_ALLEGRO ET TYPE_PROCESS 
-- SUPPRESSION DES COLONNES 
-- ETP_X_TS, ETP_X_USR_CD, ETP_X_ALLIANCE_CD, ETP_X_COMPTE_CD, ETP_X_EDO_ID 
-- AVEC X <> 0,200,1,101,20,204
-- Critere de bascule du statut pre-dossier au statut dossier

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT
(
 
    EXTERNAL_ORDR_ID                 ,
    EXTERNAL_ACTE_ID                 ,
    ORDER_DEPOSIT_DT                 ,
    ORDER_DEPOSIT_TS                 ,
    TYPE_SOURCE_ID                   ,
    INTRNL_SOURCE_ID                 ,
    ORDER_STATUS_CD                  ,
    ORDER_STATUS_DS                  ,
    ORDR_TYP_CD                      ,
    MOTIF_CD                         ,
    CODE_INTERNE_CD                  ,
    PREVIOUS_FAMILLE_CD              ,
    PREVIOUS_FAMILLE_LB              ,
    CIRCUIT_CD                       ,
    EST_GESTE_CO                     ,
    PAR_MSISDN_ID                    ,
    PAR_NDS                          ,
    EXT_AGENT_ID                     ,
    ORG_AGENT_ID                     ,
    ORG_LAST_NAME_NM                 ,
    ORG_FIRST_NAME_NM                ,
    EXT_SHOP_ID                      ,
    EXT_SHOP_ADV_CD                  ,
    PREVIOUS_EXT_PRODUCT_ID          ,
    PREVIOUS_EAN_CD                  ,
    PREVIOUS_IMEI_CD                 ,
    EXT_PRODUCT_ID                   ,
    EAN_CD                           ,
    IMEI_CD                          ,
    FAMILLE_CD                       ,
    FAMILLE_LB                       ,
    DOSSIER_DEB_DT                   ,
    DOSSIER_FIN_DT                   ,
    PANNE_CD                         ,
    AIDE_DIAG                        ,
    DIAG_PANNE_CD                    ,
    REPARATION_LB                    ,
    REPARATION_DT                    ,
    REPARATION_GARANTIE              ,
    PRE_DOSSIER                      ,
    NUMERO_CHRONOPOST                ,
    DOSSIER_PRET_CD                  ,
    DUPLIQUE_CD                      ,
    CASE_ID_SPAS                     ,
    CRI_CD                           ,
    COMMANDE_DT                      ,
    PANNE                            ,
    EST_GARANTIE                     ,
    CLIENT_CP                        ,
    FIN_GARANTIE_DT                  ,
    LIVRAISON_DT                     ,
    ACHAT_DT                         ,
    STATUT_COMMANDE_CD               ,
    POINT_RELAIS_CD                  ,
    PR_CODE_POSTAL_CD                ,
    LIVRAISON_MODE_CD                ,
    DATE1_PROPOSEE                   ,
    RI_DATE_ENVOI                    ,
    RI_POINT_RELAIS_RET_CD           ,
    PR_RI_CODE_POSTAL_CD             ,
    CLIENT_EAN_TERM                  ,
    ANNULATION_CD                    ,
    FACTURATION_MOTIF_CD             ,
    MOBILE_ECHANGE_DT                ,
    GARANTIE_FIN_DT                  ,
    ACCESSOIRE_CD                    ,
    IMEI_COFFRET                     ,
    PAYS_FIRST_CD                    ,
    MOTIF_PRET_CD                    ,
    PRET_PAYANT                      ,
    RESTITUTION_TERMINAL             ,
    ETAT_TERM_PRET_CD                ,
    A_ETE_FACT_PRET                  ,
    A_ETE_FACT_RESTI                 ,
    FAIT_GENERATEUR_DT               ,
    MOTIF_RESILIATION_CD             ,
    SYSTEME_FACTURATION              , --PILCOM_404
    ALLEGRO_CD                       , --PILCOM_404
    MONTANT_FACT_ALLEGRO             , --PILCOM_404
    TYPE_PROCESS                     , --PILCOM_404
    ETP_ANNUL_CD                     ,
    ETP_ANNUL_TS                     ,
    ETP_ANNUL_USR_CD                 ,
    ETP_ANNUL_ALLIANCE_CD            ,
    ETP_ANNUL_COMPTE_CD              ,
    ETP_ANNUL_EDO_ID                 ,
    ETP_0_CD                         ,
    ETP_0_TS                         ,
    ETP_0_USR_CD                     ,
    ETP_0_ALLIANCE_CD                ,
    ETP_0_COMPTE_CD                  ,
    ETP_0_EDO_ID                     ,
    ETP_200_CD                       ,
    ETP_200_TS                       ,
    ETP_200_USR_CD                   ,
    ETP_200_ALLIANCE_CD              ,
    ETP_200_COMPTE_CD                ,
    ETP_200_EDO_ID                   ,
    ETP_200_COM_FTT                  ,
    ETP_1_CD                         ,
    ETP_1_TS                         ,
    ETP_1_USR_CD                     ,
    ETP_1_ALLIANCE_CD                ,
    ETP_1_COMPTE_CD                  ,
    ETP_1_EDO_ID                     ,
    ETP_101_CD                       ,
    ETP_101_TS                       ,
    ETP_101_USR_CD                   ,
    ETP_101_ALLIANCE_CD              ,
    ETP_101_COMPTE_CD                ,
    ETP_101_EDO_ID                   ,
    ETP_101_COM_FTT                  ,
    ETP_20_CD                        ,
    ETP_20_TS                        ,
    ETP_20_USR_CD                    ,
    ETP_20_ALLIANCE_CD               ,
    ETP_20_COMPTE_CD                 ,
    ETP_20_EDO_ID                    ,
    ETP_204_CD                       ,
    ETP_204_TS                       ,
    ETP_204_USR_CD                   ,
    ETP_204_ALLIANCE_CD              ,
    ETP_204_COMPTE_CD                ,
    ETP_204_EDO_ID                   ,
    ETP_204_COM_FTT                   
  )
  Select  
      
      PRS.EXTERNAL_ORDR_ID                  As      EXTERNAL_ORDR_ID                 ,
      --PILCOM_404 : Critere de bascule du statut pre-dossier au statut dossier 
      trim(PRS.EXTERNAL_ORDR_ID )||'|'|| 
      (
      Case 
            When   STP.ETP_204_CD    Is Not Null   Then 'REA'
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then 'REA'
            WHEN   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then 'REA'
            When   STP.ETP_1_CD      Is Not Null   Then 'REA'
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then 'REA'
      End
       )                                 As       EXTERNAL_ACTE_ID, 
      /*PILCOM_404
      Case 
        When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_ts
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is Null Then STP.ETP_101_ts
        When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ts
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ts
        
      End                                   As      ORDER_DEPOSIT_DT                  ,*/
      Case 
            When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_ts
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then STP.ETP_101_ts
            WHEN   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then STP.ETP_125_ts
            When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ts
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ts
      End As ORDER_DEPOSIT_DT ,
     /* PILCOM_404
     Case 
        When   STP.ETP_204_CD    IS Not Null   Then STP.ETP_204_ts
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then STP.ETP_101_ts
        When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ts
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ts
      End                                 As      ORDER_DEPOSIT_TS                  ,*/
      Case 
            When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_ts
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then STP.ETP_101_ts
            WHEN   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then STP.ETP_125_ts
            When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ts
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ts
      End As ORDER_DEPOSIT_TS ,     
      ${IdentifiantTechniqueSource}       As       TYPE_SOURCE_ID                   ,
      ${IdSourceInterne}                  As       INTRNL_SOURCE_ID                 ,
     PRS.ORDER_STATUS_CD                  As      ORDER_STATUS_CD                   ,
     PRS.ORDER_STATUS_DS                  As      ORDER_STATUS_DS                   ,
     /*PILCOM_404
     Case 
       When   STP.ETP_204_CD    Is Not Null   Then 'REA'
       When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then 'REA'
       When   STP.ETP_1_CD      Is Not Null   Then 'REA'
       When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then 'REA'

      End                                 As       ORDR_TYP_CD                      ,*/
      Case 
            When   STP.ETP_204_CD    Is Not Null   Then 'REA'
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then 'REA'
            WHEN   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then 'REA'
            When   STP.ETP_1_CD      Is Not Null   Then 'REA'
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then 'REA'
      End As ORDR_TYP_CD, 
     PRS.MOTIF_CD                         As      MOTIF_CD                          ,
     PRS.CODE_INTERNE_CD                  As      CODE_INTERNE_CD                   ,
     PRS.PREVIOUS_FAMILLE_CD              As      PREVIOUS_FAMILLE_CD               ,
     PRS.PREVIOUS_FAMILLE_LB              As      PREVIOUS_FAMILLE_LB               ,
     PRS.CIRCUIT_CD                       As      CIRCUIT_CD                        ,
     PRS.EST_GESTE_CO                     As      EST_GESTE_CO                      ,
     PRS.PAR_MSISDN_ID                    As      PAR_MSISDN_ID                     ,
     PRS.PAR_NDS                          As      PAR_NDS                           ,
     /* PILCOM_404
      Case
        When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_USR_CD
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is Null  Then PRS.EXT_AGENT_ID
        When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_USR_CD
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_USR_CD
      End                                 As      EXT_AGENT_ID                      ,*/
      Case 
            When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_USR_CD
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then PRS.EXT_AGENT_ID
            When   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then PRS.EXT_AGENT_ID
            When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_USR_CD
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_USR_CD 
      End As EXT_AGENT_ID ,
      /*PILCOM_404
       Case
        When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_ALLIANCE_CD
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is Null Then  PRS.ORG_AGENT_ID 
        When   STP.ETP_1_CD      Is Not Null   Then  STP.ETP_1_ALLIANCE_CD 
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then  STP.ETP_20_ALLIANCE_CD 
      End                                 As      ORG_AGENT_ID                      ,*/
      Case 
            When   STP.ETP_204_CD    Is Not Null Then  STP.ETP_204_ALLIANCE_CD
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then PRS.ORG_AGENT_ID 
            WHEN   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then PRS.ORG_AGENT_ID 
            When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ALLIANCE_CD 
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ALLIANCE_CD 
      End As ORG_AGENT_ID                                                             , 
     --PRS.ORG_LAST_NAME_NM                 As      ORG_LAST_NAME_NM                  ,
     --PRS.ORG_FIRST_NAME_NM                As      ORG_FIRST_NAME_NM                 ,
      null                                As      ORG_LAST_NAME_NM                  ,
      null                                As      ORG_FIRST_NAME_NM                 ,
    /*PILCOM_404
     Case
        When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_COMPTE_CD
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is Null Then PRS.EXT_SHOP_ID 
        When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_COMPTE_CD
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_COMPTE_CD
      End                                 As      EXT_SHOP_ID                        ,*/
     Case 
            When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_COMPTE_CD
            When   COALESCE(PRS.TYPE_PROCESS, '') <> 'RST' AND STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is  Null  Then PRS.EXT_SHOP_ID
            When   PRS.TYPE_PROCESS = 'RST'  AND STP.ETP_125_CD     Is Not Null   And STP.ETP_204_CD is  Null  Then PRS.EXT_SHOP_ID
            When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_COMPTE_CD
            When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_COMPTE_CD
     End As EXT_SHOP_ID   ,      
     /* PILCOM_404
      Case
        When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_ADV_CD   
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is Null Then STP.ETP_101_ADV_CD
        When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ADV_CD
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ADV_CD
      End                                 As      EXT_SHOP_ADV_CD                   ,*/
     Case
        When   STP.ETP_204_CD    Is Not Null   Then STP.ETP_204_ADV_CD   
        When   STP.ETP_101_CD    Is Not Null   And STP.ETP_204_CD is Null Then STP.ETP_101_ADV_CD
        When   STP.ETP_1_CD      Is Not Null   Then STP.ETP_1_ADV_CD
        When   STP.ETP_20_CD     Is Not Null   And STP.ETP_1_CD is  Null And STP.ETP_101_CD is  Null  Then STP.ETP_20_ADV_CD
      End                                 As      EXT_SHOP_ADV_CD                   ,
     PRS.PREVIOUS_EXT_PRODUCT_ID          As      PREVIOUS_EXT_PRODUCT_ID           ,
     PRS.PREVIOUS_EAN_CD                  As      PREVIOUS_EAN_CD                   ,
     PRS.PREVIOUS_IMEI_CD                 As      PREVIOUS_IMEI_CD                  ,
     PRS.EXT_PRODUCT_ID                   As      EXT_PRODUCT_ID                    ,
     PRS.EAN_CD                           As      EAN_CD                            ,
     PRS.IMEI_CD                          As      IMEI_CD                           ,
     PRS.FAMILLE_CD                       As      FAMILLE_CD                        ,
     PRS.FAMILLE_LB                       As      FAMILLE_LB                        ,
     PRS.DOSSIER_DEB_DT                   As      DOSSIER_DEB_DT                    ,
     PRS.DOSSIER_FIN_DT                   As      DOSSIER_FIN_DT                    ,
     PRS.PANNE_CD                         As      PANNE_CD                          ,
     PRS.AIDE_DIAG                        As      AIDE_DIAG                         ,
     PRS.DIAG_PANNE_CD                    As      DIAG_PANNE_CD                     ,
     PRS.REPARATION_LB                    As      REPARATION_LB                     ,
     PRS.REPARATION_DT                    As      REPARATION_DT                     ,
     PRS.REPARATION_GARANTIE              As      REPARATION_GARANTIE               ,
     PRS.PRE_DOSSIER                      As      PRE_DOSSIER                       ,
     PRS.NUMERO_CHRONOPOST                As      NUMERO_CHRONOPOST                 ,
     PRS.DOSSIER_PRET_CD                  As      DOSSIER_PRET_CD                   ,
     PRS.DUPLIQUE_CD                      As      DUPLIQUE_CD                       ,
     PRS.CASE_ID_SPAS                     As      CASE_ID_SPAS                      ,
     PRS.CRI_CD                           As      CRI_CD                            ,
     PRS.COMMANDE_DT                      As      COMMANDE_DT                       ,
     PRS.PANNE                            As      PANNE                             ,
     PRS.EST_GARANTIE                     As      EST_GARANTIE                      ,
     PRS.CLIENT_CP                        As      CLIENT_CP                         ,
     PRS.FIN_GARANTIE_DT                  As      FIN_GARANTIE_DT                   ,
     PRS.LIVRAISON_DT                     As      LIVRAISON_DT                      ,
     PRS.ACHAT_DT                         As      ACHAT_DT                          ,
     PRS.STATUT_COMMANDE_CD               As      STATUT_COMMANDE_CD                ,
     PRS.POINT_RELAIS_CD                  As      POINT_RELAIS_CD                   ,
     PRS.PR_CODE_POSTAL_CD                As      PR_CODE_POSTAL_CD                 ,
     PRS.LIVRAISON_MODE_CD                As      LIVRAISON_MODE_CD                 ,
     PRS.DATE1_PROPOSEE                   As      DATE1_PROPOSEE                    ,
     PRS.RI_DATE_ENVOI                    As      RI_DATE_ENVOI                     ,
     PRS.RI_POINT_RELAIS_RET_CD           As      RI_POINT_RELAIS_RET_CD            ,
     PRS.PR_RI_CODE_POSTAL_CD             As      PR_RI_CODE_POSTAL_CD              ,
     PRS.CLIENT_EAN_TERM                  As      CLIENT_EAN_TERM                   ,
     PRS.ANNULATION_CD                    As      ANNULATION_CD                     ,
     PRS.FACTURATION_MOTIF_CD             As      FACTURATION_MOTIF_CD              ,
     PRS.MOBILE_ECHANGE_DT                As      MOBILE_ECHANGE_DT                 ,
     PRS.GARANTIE_FIN_DT                  As      GARANTIE_FIN_DT                   ,
     PRS.ACCESSOIRE_CD                    As      ACCESSOIRE_CD                     ,
     PRS.IMEI_COFFRET                     As      IMEI_COFFRET                      ,
     PRS.PAYS_FIRST_CD                    As      PAYS_FIRST_CD                     ,
     PRS.MOTIF_PRET_CD                    As      MOTIF_PRET_CD                     ,
     PRS.PRET_PAYANT                      As      PRET_PAYANT                       ,
     PRS.RESTITUTION_TERMINAL             As      RESTITUTION_TERMINAL              ,
     PRS.ETAT_TERM_PRET_CD                As      ETAT_TERM_PRET_CD                 ,
     PRS.A_ETE_FACT_PRET                  As      A_ETE_FACT_PRET                   ,
     PRS.A_ETE_FACT_RESTI                 As      A_ETE_FACT_RESTI                  ,
     PRS.FAIT_GENERATEUR_DT               As      FAIT_GENERATEUR_DT                ,
     PRS.MOTIF_RESILIATION_CD             As      MOTIF_RESILIATION_CD              ,
     PRS.SYSTEME_FACTURATION              As      SYSTEME_FACTURATION               , --PILCOM_404
     PRS.ALLEGRO_CD                       As      ALLEGRO_CD                        , --PILCOM_404
     PRS.MONTANT_FACT_ALLEGRO             As      MONTANT_FACT_ALLEGRO              , --PILCOM_404
     PRS.TYPE_PROCESS                     As      TYPE_PROCESS                      , --PILCOM_404 
     PRS.ETP_ANNUL_CD                     As      ETP_ANNUL_CD                      ,
     PRS.ETP_ANNUL_TS                     As      ETP_ANNUL_TS                      ,
     PRS.ETP_ANNUL_USR_CD                 As      ETP_ANNUL_USR_CD                  ,
     PRS.ETP_ANNUL_ALLIANCE_CD            As      ETP_ANNUL_ALLIANCE_CD             ,
     PRS.ETP_ANNUL_COMPTE_CD              As      ETP_ANNUL_COMPTE_CD               ,
     PRS.ETP_ANNUL_EDO_ID                 As      ETP_ANNUL_EDO_ID                  ,
     STP.ETP_0_CD                         As      ETP_0_CD                          ,
     STP.ETP_0_TS                         As      ETP_0_TS                          ,
     STP.ETP_0_USR_CD                     As      ETP_0_USR_CD                      ,
     STP.ETP_0_ALLIANCE_CD                As      ETP_0_ALLIANCE_CD                 ,
     STP.ETP_0_COMPTE_CD                  As      ETP_0_COMPTE_CD                   ,
     STP.ETP_0_EDO_ID                     As      ETP_0_EDO_ID                      ,
     STP.ETP_200_CD                       As      ETP_200_CD                        ,
     STP.ETP_200_TS                       As      ETP_200_TS                        ,
     STP.ETP_200_USR_CD                   As      ETP_200_USR_CD                    ,
     STP.ETP_200_ALLIANCE_CD              As      ETP_200_ALLIANCE_CD               ,
     STP.ETP_200_COMPTE_CD                As      ETP_200_COMPTE_CD                 ,
     STP.ETP_200_EDO_ID                   As      ETP_200_EDO_ID                    ,
     STP.ETP_200_COM_FTT                  As      ETP_200_COM_FTT                   ,
     STP.ETP_1_CD                         As      ETP_1_CD                          ,
     STP.ETP_1_TS                         As      ETP_1_TS                          ,
     STP.ETP_1_USR_CD                     As      ETP_1_USR_CD                      ,
     STP.ETP_1_ALLIANCE_CD                As      ETP_1_ALLIANCE_CD                 ,
     STP.ETP_1_COMPTE_CD                  As      ETP_1_COMPTE_CD                   ,
     STP.ETP_1_EDO_ID                     As      ETP_1_EDO_ID                      ,
     STP.ETP_101_CD                       As      ETP_101_CD                        ,
     STP.ETP_101_TS                       As      ETP_101_TS                        ,
     STP.ETP_101_USR_CD                   As      ETP_101_USR_CD                    ,
     STP.ETP_101_ALLIANCE_CD              As      ETP_101_ALLIANCE_CD               ,
     STP.ETP_101_COMPTE_CD                As      ETP_101_COMPTE_CD                 ,
     STP.ETP_101_EDO_ID                   As      ETP_101_EDO_ID                    ,
     STP.ETP_101_COM_FTT                  As      ETP_101_COM_FTT                   ,
     STP.ETP_20_CD                        As      ETP_20_CD                         ,
     STP.ETP_20_TS                        As      ETP_20_TS                         ,
     STP.ETP_20_USR_CD                    As      ETP_20_USR_CD                     ,
     STP.ETP_20_ALLIANCE_CD               As      ETP_20_ALLIANCE_CD                ,
     STP.ETP_20_COMPTE_CD                 As      ETP_20_COMPTE_CD                  ,
     STP.ETP_20_EDO_ID                    As      ETP_20_EDO_ID                     ,
     STP.ETP_204_CD                       As      ETP_204_CD                        ,
     STP.ETP_204_TS                       As      ETP_204_TS                        ,
     STP.ETP_204_USR_CD                   As      ETP_204_USR_CD                    ,
     STP.ETP_204_ALLIANCE_CD              As      ETP_204_ALLIANCE_CD               ,
     STP.ETP_204_COMPTE_CD                As      ETP_204_COMPTE_CD                 ,
     STP.ETP_204_EDO_ID                   As      ETP_204_EDO_ID                    ,
     STP.ETP_204_COM_FTT                  As      ETP_204_COM_FTT                            
     
     
  from 
     ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT PRS
     Inner Join   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EXT  STP
      On        PRS.EXTERNAL_ORDR_ID = STP.EXTERNAL_ORDR_ID
  
  Where (1=1)  
    --And (STP.ETP_101_CD Is not Null Or STP.ETP_1_CD Is Not Null or STP.ETP_20_CD Is Not Null  )       
   AND EXTERNAL_ACTE_ID IS NOT NULL;
    
    
.if errorcode <> 0 then .quit 1                        
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT    ;
.if errorcode <> 0 then .quit 1  
    

----------------------------------------------------------------------------------------------
-- Etape 5 : Fusion des extractions  INIT                                                  ----
----------------------------------------------------------------------------------------------

-- US PILCOM_404 : 
-- AJOUT DES 4 NOUVEAUX CHAMPS  SYSTEME_FACTURATION ,  ALLEGRO_CD , MONTANT_FACT_ALLEGRO ET TYPE_PROCESS 
-- SUPPRESSION DES COLONNES 
-- ETP_X_TS, ETP_X_USR_CD, ETP_X_ALLIANCE_CD, ETP_X_COMPTE_CD, ETP_X_EDO_ID 
-- AVEC X <> 0,200,1,101,20,204

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT
(
 
    EXTERNAL_ORDR_ID                 ,
    EXTERNAL_ACTE_ID                 ,
    ORDER_DEPOSIT_DT                 ,
    ORDER_DEPOSIT_TS                 ,
    TYPE_SOURCE_ID                   ,
    INTRNL_SOURCE_ID                 ,
    ORDER_STATUS_CD                  ,
    ORDER_STATUS_DS                  ,
    ORDR_TYP_CD                      ,
    MOTIF_CD                         ,
    CODE_INTERNE_CD                  ,
    PREVIOUS_FAMILLE_CD              ,
    PREVIOUS_FAMILLE_LB              ,
    CIRCUIT_CD                       ,
    EST_GESTE_CO                     ,
    PAR_MSISDN_ID                    ,
    PAR_NDS                          ,
    EXT_AGENT_ID                     ,
    ORG_AGENT_ID                     ,
    ORG_LAST_NAME_NM                 ,
    ORG_FIRST_NAME_NM                ,
    EXT_SHOP_ID                      ,
    EXT_SHOP_ADV_CD                  ,
    PREVIOUS_EXT_PRODUCT_ID          ,
    PREVIOUS_EAN_CD                  ,
    PREVIOUS_IMEI_CD                 ,
    EXT_PRODUCT_ID                   ,
    EAN_CD                           ,
    IMEI_CD                          ,
    FAMILLE_CD                       ,
    FAMILLE_LB                       ,
    DOSSIER_DEB_DT                   ,
    DOSSIER_FIN_DT                   ,
    PANNE_CD                         ,
    AIDE_DIAG                        ,
    DIAG_PANNE_CD                    ,
    REPARATION_LB                    ,
    REPARATION_DT                    ,
    REPARATION_GARANTIE              ,
    PRE_DOSSIER                      ,
    NUMERO_CHRONOPOST                ,
    DOSSIER_PRET_CD                  ,
    DUPLIQUE_CD                      ,
    CASE_ID_SPAS                     ,
    CRI_CD                           ,
    COMMANDE_DT                      ,
    PANNE                            ,
    EST_GARANTIE                     ,
    CLIENT_CP                        ,
    FIN_GARANTIE_DT                  ,
    LIVRAISON_DT                     ,
    ACHAT_DT                         ,
    STATUT_COMMANDE_CD               ,
    POINT_RELAIS_CD                  ,
    PR_CODE_POSTAL_CD                ,
    LIVRAISON_MODE_CD                ,
    DATE1_PROPOSEE                   ,
    RI_DATE_ENVOI                    ,
    RI_POINT_RELAIS_RET_CD           ,
    PR_RI_CODE_POSTAL_CD             ,
    CLIENT_EAN_TERM                  ,
    ANNULATION_CD                    ,
    FACTURATION_MOTIF_CD             ,
    MOBILE_ECHANGE_DT                ,
    GARANTIE_FIN_DT                  ,
    ACCESSOIRE_CD                    ,
    IMEI_COFFRET                     ,
    PAYS_FIRST_CD                    ,
    MOTIF_PRET_CD                    ,
    PRET_PAYANT                      ,
    RESTITUTION_TERMINAL             ,
    ETAT_TERM_PRET_CD                ,
    A_ETE_FACT_PRET                  ,
    A_ETE_FACT_RESTI                 ,
    FAIT_GENERATEUR_DT               ,
    MOTIF_RESILIATION_CD             ,
    SYSTEME_FACTURATION              , --PILCOM_404
    ALLEGRO_CD                       , --PILCOM_404
    MONTANT_FACT_ALLEGRO             , --PILCOM_404
    TYPE_PROCESS                     , --PILCOM_404
    ETP_ANNUL_CD                     ,
    ETP_ANNUL_TS                     ,
    ETP_ANNUL_USR_CD                 ,
    ETP_ANNUL_ALLIANCE_CD            ,
    ETP_ANNUL_COMPTE_CD              ,
    ETP_ANNUL_EDO_ID                 ,
    ETP_0_CD                         ,
    ETP_0_TS                         ,
    ETP_0_USR_CD                     ,
    ETP_0_ALLIANCE_CD                ,
    ETP_0_COMPTE_CD                  ,
    ETP_0_EDO_ID                     ,
    ETP_200_CD                       ,
    ETP_200_TS                       ,
    ETP_200_USR_CD                   ,
    ETP_200_ALLIANCE_CD              ,
    ETP_200_COMPTE_CD                ,
    ETP_200_EDO_ID                   ,
    ETP_200_COM_FTT                  ,
    ETP_1_CD                         ,
    ETP_1_TS                         ,
    ETP_1_USR_CD                     ,
    ETP_1_ALLIANCE_CD                ,
    ETP_1_COMPTE_CD                  ,
    ETP_1_EDO_ID                     ,
    ETP_101_CD                       ,
    ETP_101_TS                       ,
    ETP_101_USR_CD                   ,
    ETP_101_ALLIANCE_CD              ,
    ETP_101_COMPTE_CD                ,
    ETP_101_EDO_ID                   ,
    ETP_101_COM_FTT                  ,
    ETP_20_CD                        ,
    ETP_20_TS                        ,
    ETP_20_USR_CD                    ,
    ETP_20_ALLIANCE_CD               ,
    ETP_20_COMPTE_CD                 ,
    ETP_20_EDO_ID                    ,
    ETP_204_CD                       ,
    ETP_204_TS                       ,
    ETP_204_USR_CD                   ,
    ETP_204_ALLIANCE_CD              ,
    ETP_204_COMPTE_CD                ,
    ETP_204_EDO_ID                   ,
    ETP_204_COM_FTT                  
    
  )
  Select  
      
      PRS.EXTERNAL_ORDR_ID                As      EXTERNAL_ORDR_ID                 ,
         trim(PRS.EXTERNAL_ORDR_ID )||'|'|| (Case 
       When   STP.ETP_0_CD      Is Not Null   Then 'INIT'
       When   STP.ETP_200_CD    Is Not Null   Then 'INIT'
      End    )                            As       EXTERNAL_ACTE_ID                ,
      Case 
        When   STP.ETP_0_CD      Is Not Null   Then STP.ETP_0_ts
        When   STP.ETP_200_CD    Is Not Null   Then STP.ETP_200_ts
      End                                 As      ORDER_DEPOSIT_DT                 ,
     Case 
        When   STP.ETP_0_CD      Is Not Null   Then STP.ETP_0_ts
        When   STP.ETP_200_CD    Is Not Null   Then STP.ETP_200_ts
      End                                 As      ORDER_DEPOSIT_TS                 ,
      ${IdentifiantTechniqueSource}       As       TYPE_SOURCE_ID                  ,
      ${IdSourceInterne}                  As       INTRNL_SOURCE_ID                ,
     PRS.ORDER_STATUS_CD                  As      ORDER_STATUS_CD                  ,
     PRS.ORDER_STATUS_DS                  As      ORDER_STATUS_DS                  ,
     Case 
       When   STP.ETP_0_CD      Is Not Null   Then 'INIT'
       When   STP.ETP_200_CD    Is Not Null   Then 'INIT'
     End                                  As       ORDR_TYP_CD                      ,
     PRS.MOTIF_CD                         As      MOTIF_CD                          ,
     PRS.CODE_INTERNE_CD                  As      CODE_INTERNE_CD                   ,
     PRS.PREVIOUS_FAMILLE_CD              As      PREVIOUS_FAMILLE_CD               ,
     PRS.PREVIOUS_FAMILLE_LB              As      PREVIOUS_FAMILLE_LB               ,
     PRS.CIRCUIT_CD                       As      CIRCUIT_CD                        ,
     PRS.EST_GESTE_CO                     As      EST_GESTE_CO                      ,
     PRS.PAR_MSISDN_ID                    As      PAR_MSISDN_ID                     ,
     PRS.PAR_NDS                          As      PAR_NDS                           ,
      Case 
        When   STP.ETP_0_CD      Is Not Null   Then STP.ETP_0_USR_CD
        When   STP.ETP_200_CD    Is Not Null   Then STP.ETP_200_USR_CD
      End                                As      EXT_AGENT_ID                      ,
      Case 
        When   STP.ETP_0_CD      Is Not Null   Then STP.ETP_0_ALLIANCE_CD 
        When   STP.ETP_200_CD    Is Not Null   Then STP.ETP_200_ALLIANCE_CD
     End                                  As      ORG_AGENT_ID                      ,
     --PRS.ORG_LAST_NAME_NM                 As      ORG_LAST_NAME_NM                  ,
     --PRS.ORG_FIRST_NAME_NM                As      ORG_FIRST_NAME_NM                 ,
      null                                As      ORG_LAST_NAME_NM                  ,
      null                                As      ORG_FIRST_NAME_NM                 ,
     Case 
        When   STP.ETP_0_CD      Is Not Null   Then STP.ETP_0_COMPTE_CD
        When   STP.ETP_200_CD    Is Not Null   Then STP.ETP_200_COMPTE_CD
     End                                 As      EXT_SHOP_ID                        ,
     Case 
        When   STP.ETP_0_CD      Is Not Null   Then STP.ETP_0_ADV_CD
        When   STP.ETP_200_CD    Is Not Null   Then STP.ETP_200_ADV_CD
     End                                 As       EXT_SHOP_ADV_CD                   ,
     PRS.PREVIOUS_EXT_PRODUCT_ID          As      PREVIOUS_EXT_PRODUCT_ID           ,
     PRS.PREVIOUS_EAN_CD                  As      PREVIOUS_EAN_CD                   ,
     PRS.PREVIOUS_IMEI_CD                 As      PREVIOUS_IMEI_CD                  ,
     PRS.EXT_PRODUCT_ID                   As      EXT_PRODUCT_ID                    ,
     PRS.EAN_CD                           As      EAN_CD                            ,
     PRS.IMEI_CD                          As      IMEI_CD                           ,
     PRS.FAMILLE_CD                       As      FAMILLE_CD                        ,
     PRS.FAMILLE_LB                       As      FAMILLE_LB                        ,
     PRS.DOSSIER_DEB_DT                   As      DOSSIER_DEB_DT                    ,
     PRS.DOSSIER_FIN_DT                   As      DOSSIER_FIN_DT                    ,
     PRS.PANNE_CD                         As      PANNE_CD                          ,
     PRS.AIDE_DIAG                        As      AIDE_DIAG                         ,
     PRS.DIAG_PANNE_CD                    As      DIAG_PANNE_CD                     ,
     PRS.REPARATION_LB                    As      REPARATION_LB                     ,
     PRS.REPARATION_DT                    As      REPARATION_DT                     ,
     PRS.REPARATION_GARANTIE              As      REPARATION_GARANTIE               ,
     PRS.PRE_DOSSIER                      As      PRE_DOSSIER                       ,
     PRS.NUMERO_CHRONOPOST                As      NUMERO_CHRONOPOST                 ,
     PRS.DOSSIER_PRET_CD                  As      DOSSIER_PRET_CD                   ,
     PRS.DUPLIQUE_CD                      As      DUPLIQUE_CD                       ,
     PRS.CASE_ID_SPAS                     As      CASE_ID_SPAS                      ,
     PRS.CRI_CD                           As      CRI_CD                            ,
     PRS.COMMANDE_DT                      As      COMMANDE_DT                       ,
     PRS.PANNE                            As      PANNE                             ,
     PRS.EST_GARANTIE                     As      EST_GARANTIE                      ,
     PRS.CLIENT_CP                        As      CLIENT_CP                         ,
     PRS.FIN_GARANTIE_DT                  As      FIN_GARANTIE_DT                   ,
     PRS.LIVRAISON_DT                     As      LIVRAISON_DT                      ,
     PRS.ACHAT_DT                         As      ACHAT_DT                          ,
     PRS.STATUT_COMMANDE_CD               As      STATUT_COMMANDE_CD                ,
     PRS.POINT_RELAIS_CD                  As      POINT_RELAIS_CD                   ,
     PRS.PR_CODE_POSTAL_CD                As      PR_CODE_POSTAL_CD                 ,
     PRS.LIVRAISON_MODE_CD                As      LIVRAISON_MODE_CD                 ,
     PRS.DATE1_PROPOSEE                   As      DATE1_PROPOSEE                    ,
     PRS.RI_DATE_ENVOI                    As      RI_DATE_ENVOI                     ,
     PRS.RI_POINT_RELAIS_RET_CD           As      RI_POINT_RELAIS_RET_CD            ,
     PRS.PR_RI_CODE_POSTAL_CD             As      PR_RI_CODE_POSTAL_CD              ,
     PRS.CLIENT_EAN_TERM                  As      CLIENT_EAN_TERM                   ,
     PRS.ANNULATION_CD                    As      ANNULATION_CD                     ,
     PRS.FACTURATION_MOTIF_CD             As      FACTURATION_MOTIF_CD              ,
     PRS.MOBILE_ECHANGE_DT                As      MOBILE_ECHANGE_DT                 ,
     PRS.GARANTIE_FIN_DT                  As      GARANTIE_FIN_DT                   ,
     PRS.ACCESSOIRE_CD                    As      ACCESSOIRE_CD                     ,
     PRS.IMEI_COFFRET                     As      IMEI_COFFRET                      ,
     PRS.PAYS_FIRST_CD                    As      PAYS_FIRST_CD                     ,
     PRS.MOTIF_PRET_CD                    As      MOTIF_PRET_CD                     ,
     PRS.PRET_PAYANT                      As      PRET_PAYANT                       ,
     PRS.RESTITUTION_TERMINAL             As      RESTITUTION_TERMINAL              ,
     PRS.ETAT_TERM_PRET_CD                As      ETAT_TERM_PRET_CD                 ,
     PRS.A_ETE_FACT_PRET                  As      A_ETE_FACT_PRET                   ,
     PRS.A_ETE_FACT_RESTI                 As      A_ETE_FACT_RESTI                  ,
     PRS.FAIT_GENERATEUR_DT               As      FAIT_GENERATEUR_DT                ,
     PRS.MOTIF_RESILIATION_CD             As      MOTIF_RESILIATION_CD              ,
     PRS.SYSTEME_FACTURATION              As      SYSTEME_FACTURATION               , --PILCOM_404
     PRS.ALLEGRO_CD                       As      ALLEGRO_CD                        , --PILCOM_404
     PRS.MONTANT_FACT_ALLEGRO             As      MONTANT_FACT_ALLEGRO              , --PILCOM_404
     PRS.TYPE_PROCESS                     As      TYPE_PROCESS                      , --PILCOM_404
     PRS.ETP_ANNUL_CD                     As      ETP_ANNUL_CD                      ,
     PRS.ETP_ANNUL_TS                     As      ETP_ANNUL_TS                      ,
     PRS.ETP_ANNUL_USR_CD                 As      ETP_ANNUL_USR_CD                  ,
     PRS.ETP_ANNUL_ALLIANCE_CD            As      ETP_ANNUL_ALLIANCE_CD             ,
     PRS.ETP_ANNUL_COMPTE_CD              As      ETP_ANNUL_COMPTE_CD               ,
     PRS.ETP_ANNUL_EDO_ID                 As      ETP_ANNUL_EDO_ID                  ,
     STP.ETP_0_CD                         As      ETP_0_CD                          ,
     STP.ETP_0_TS                         As      ETP_0_TS                          ,
     STP.ETP_0_USR_CD                     As      ETP_0_USR_CD                      ,
     STP.ETP_0_ALLIANCE_CD                As      ETP_0_ALLIANCE_CD                 ,
     STP.ETP_0_COMPTE_CD                  As      ETP_0_COMPTE_CD                   ,
     STP.ETP_0_EDO_ID                     As      ETP_0_EDO_ID                      ,
     STP.ETP_200_CD                       As      ETP_200_CD                        ,
     STP.ETP_200_TS                       As      ETP_200_TS                        ,
     STP.ETP_200_USR_CD                   As      ETP_200_USR_CD                    ,
     STP.ETP_200_ALLIANCE_CD              As      ETP_200_ALLIANCE_CD               ,
     STP.ETP_200_COMPTE_CD                As      ETP_200_COMPTE_CD                 ,
     STP.ETP_200_EDO_ID                   As      ETP_200_EDO_ID                    ,
     STP.ETP_200_COM_FTT                  As      ETP_200_COM_FTT                   ,
     STP.ETP_1_CD                         As      ETP_1_CD                          ,
     STP.ETP_1_TS                         As      ETP_1_TS                          ,
     STP.ETP_1_USR_CD                     As      ETP_1_USR_CD                      ,
     STP.ETP_1_ALLIANCE_CD                As      ETP_1_ALLIANCE_CD                 ,
     STP.ETP_1_COMPTE_CD                  As      ETP_1_COMPTE_CD                   ,
     STP.ETP_1_EDO_ID                     As      ETP_1_EDO_ID                      ,
     STP.ETP_101_CD                       As      ETP_101_CD                        ,
     STP.ETP_101_TS                       As      ETP_101_TS                        ,
     STP.ETP_101_USR_CD                   As      ETP_101_USR_CD                    ,
     STP.ETP_101_ALLIANCE_CD              As      ETP_101_ALLIANCE_CD               ,
     STP.ETP_101_COMPTE_CD                As      ETP_101_COMPTE_CD                 ,
     STP.ETP_101_EDO_ID                   As      ETP_101_EDO_ID                    ,
     STP.ETP_101_COM_FTT                  As      ETP_101_COM_FTT                   ,
     STP.ETP_20_CD                        As      ETP_20_CD                         ,
     STP.ETP_20_TS                        As      ETP_20_TS                         ,
     STP.ETP_20_USR_CD                    As      ETP_20_USR_CD                     ,
     STP.ETP_20_ALLIANCE_CD               As      ETP_20_ALLIANCE_CD                ,
     STP.ETP_20_COMPTE_CD                 As      ETP_20_COMPTE_CD                  ,
     STP.ETP_20_EDO_ID                    As      ETP_20_EDO_ID                     ,
     STP.ETP_204_CD                       As      ETP_204_CD                        ,
     STP.ETP_204_TS                       As      ETP_204_TS                        ,
     STP.ETP_204_USR_CD                   As      ETP_204_USR_CD                    ,
     STP.ETP_204_ALLIANCE_CD              As      ETP_204_ALLIANCE_CD               ,
     STP.ETP_204_COMPTE_CD                As      ETP_204_COMPTE_CD                 ,
     STP.ETP_204_EDO_ID                   As      ETP_204_EDO_ID                    ,
     STP.ETP_204_COM_FTT                  As      ETP_204_COM_FTT                            
           
  from 
     ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT PRS
     Inner Join   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EXT  STP
      On        PRS.EXTERNAL_ORDR_ID = STP.EXTERNAL_ORDR_ID
  Where (1=1)  
    And   (STP.ETP_0_CD Is not Null or STP.ETP_200_CD Is not Null   )    ;
    
    
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT    ;
.if errorcode <> 0 then .quit 1  

----------------------------------------------------------------------------------------------
-- Etape 6 : Creation/Alim  table volatile pour gerer les Annulations                  ----
----------------------------------------------------------------------------------------------      

 create volatile table ${KNB_TERADATA_USER}.ORD_V_EXT_ANL
 ( 
   DOSSIER_SAV_CD BIGINT NOT NULL,
   DOSSIER_DEB_DT DATE FORMAT 'YYYYMMDD' ,
   ETAPE_EN_COURS SMALLINT,
   ETP_ANNUL_CD SMALLINT,
   ETP_ANNUL_TS TIMESTAMP(0),
   ETP_ANNUL_USR_CD VARCHAR(25),
   ETP_ANNUL_ALLIANCE_CD VARCHAR(25)  ,
   ETP_ANNUL_COMPTE_CD  VARCHAR(25)   ,
   ETP_ANNUL_EDO_ID VARCHAR(25) ,
   STEP_ANL VARCHAR(1)
)
 
Primary Index (DOSSIER_SAV_CD)
On Commit Preserve Rows
;
Collect Stat On  ${KNB_TERADATA_USER}.ORD_V_EXT_ANL Column( DOSSIER_SAV_CD);
.if errorcode <> 0 then .quit 1      

----- etape1  annulation   ETAPE_CD =90 ou 70 ou 80 

insert into ${KNB_TERADATA_USER}.ORD_V_EXT_ANL  
(
   DOSSIER_SAV_CD          ,
   DOSSIER_DEB_DT          ,
   ETAPE_EN_COURS          ,
   ETP_ANNUL_CD            ,
   ETP_ANNUL_TS            ,
   ETP_ANNUL_USR_CD        ,
   ETP_ANNUL_ALLIANCE_CD   ,
   ETP_ANNUL_COMPTE_CD     ,
   ETP_ANNUL_EDO_ID        ,
   STEP_ANL                
 
)

  Select 
    
 ISE.DOSSIER_SAV_CD      ,
 ISE.DOSSIER_DEB_DT      ,
 ISE.ETAPE_EN_COURS      ,
 ISP.ETAPE_CD            ,
 ISP.ETAPE_TS            ,
 ISP.USER_CD             ,
 USR.ID_ALLIANCE         ,
 USR.COMPTE_CD           ,
 USR.COMPTE_CD           ,
 1

 FROM ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_AFTER_SALE   ISE  
 Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT  PRS
 On  PRS.EXTERNAL_ORDR_ID  = ISE.DOSSIER_SAV_CD
  Left Join ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_STEP ISP
     On ISP.dossier_sav_cd= ISE.dossier_sav_cd 
 Left Join ${KNB_COM_SOC_V_PRS}.SAV_R_USER USR
    On  USR.USER_CD =ISP.USER_CD
 Where (1=1) 
   And ISE.ETAPE_EN_COURS in  (90 , 80 , 70)
   And ISP.ETAPE_CD in  (90 , 80 , 70) 
 Qualify Row_Number() Over (Partition By  ISE.DOSSIER_SAV_CD  Order By   ISP.ETAPE_TS  Asc) = 1       ;

.if errorcode <> 0 then .quit 1                        
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_ANL    ;
.if errorcode <> 0 then .quit 1 

--- etape 2 annulation ETP_FTT_CD =199

insert into ${KNB_TERADATA_USER}.ORD_V_EXT_ANL  
(
   DOSSIER_SAV_CD          ,
   DOSSIER_DEB_DT          ,
   ETAPE_EN_COURS          ,
   ETP_ANNUL_CD            ,
   ETP_ANNUL_TS            ,
   ETP_ANNUL_USR_CD        ,
   ETP_ANNUL_ALLIANCE_CD   ,
   ETP_ANNUL_COMPTE_CD     ,
   ETP_ANNUL_EDO_ID        ,
   STEP_ANL
)

  Select 
    
  ISE.DOSSIER_SAV_CD      ,
  ISE.DOSSIER_DEB_DT      ,
  ISE.ETAPE_EN_COURS      ,
  OSP.ETP_FTT_CD          ,
  OSP.ETAPE_FTT_DT        ,
  UR.USER_CD              ,
  OSP.ACTEUR_LB           ,
  UR.COMPTE_CD            ,
  UR.COMPTE_CD            ,
   2
 FROM ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_AFTER_SALE   ISE  
 Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT  PRS
 On  PRS.EXTERNAL_ORDR_ID  = ISE.DOSSIER_SAV_CD
 Left Join ${KNB_COM_SOC_V_PRS}.SAV_F_ORDER_STEP OSP
    On OSP.dossier_sav_cd= ISE.dossier_sav_cd 
Left Join ${KNB_COM_SOC_V_PRS}.SAV_R_USER UR
    On    UR.ID_ALLIANCE =OSP.ACTEUR_LB
    And  coalesce (UR.DEPART_DT , current_date ) >=  OSP.ETAPE_FTT_DT
    And   UR.ARRIVEE_DT                          <= OSP.ETAPE_FTT_DT 
 Where (1=1) 
  And  ISE.ETAPE_EN_COURS in  (90 , 80 , 70)
  And  OSP.ETP_FTT_CD = 199
  And  Not Exists 
  (
   Select  
     1  
   FROM 
     ${KNB_TERADATA_USER}.ORD_V_EXT_ANL   AN
  Where  
  (1=1) 
    And AN.DOSSIER_SAV_CD=ISE.DOSSIER_SAV_CD    
  )
 
 Qualify Row_Number() Over (Partition By  ISE.DOSSIER_SAV_CD  Order By   OSP.ETAPE_FTT_DT  Asc , UR.ARRIVEE_DT desc    ) = 1  ;
 
.if errorcode <> 0 then .quit 1                        
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_ANL    ;
.if errorcode <> 0 then .quit 1  


--- PILCOM_404: Ajout de l etape 3 annulation ETP_FTT_CD =114 
--- A gerer de la meme facon que l etape 199 

insert into ${KNB_TERADATA_USER}.ORD_V_EXT_ANL  
(
   DOSSIER_SAV_CD          ,
   DOSSIER_DEB_DT          ,
   ETAPE_EN_COURS          ,
   ETP_ANNUL_CD            ,
   ETP_ANNUL_TS            ,
   ETP_ANNUL_USR_CD        ,
   ETP_ANNUL_ALLIANCE_CD   ,
   ETP_ANNUL_COMPTE_CD     ,
   ETP_ANNUL_EDO_ID        ,
   STEP_ANL
)

  Select 
    
  ISE.DOSSIER_SAV_CD      ,
  ISE.DOSSIER_DEB_DT      ,
  ISE.ETAPE_EN_COURS      ,
  OSP.ETP_FTT_CD          ,
  OSP.ETAPE_FTT_DT        ,
  UR.USER_CD              ,
  OSP.ACTEUR_LB           ,
  UR.COMPTE_CD            ,
  UR.COMPTE_CD            ,
   3
 FROM ${KNB_COM_SOC_V_PRS}.SAV_F_ISSUE_AFTER_SALE   ISE  
 Inner join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_PRESTA_EXT  PRS
 On  PRS.EXTERNAL_ORDR_ID  = ISE.DOSSIER_SAV_CD
 Left Join ${KNB_COM_SOC_V_PRS}.SAV_F_ORDER_STEP OSP
    On OSP.dossier_sav_cd= ISE.dossier_sav_cd 
Left Join ${KNB_COM_SOC_V_PRS}.SAV_R_USER UR
    On    UR.ID_ALLIANCE =OSP.ACTEUR_LB
    And  coalesce (UR.DEPART_DT , current_date ) >=  OSP.ETAPE_FTT_DT
    And   UR.ARRIVEE_DT                          <= OSP.ETAPE_FTT_DT 
 Where (1=1) 
  And  ISE.ETAPE_EN_COURS in  (90 , 80 , 70)
  And  OSP.ETP_FTT_CD = 114
  And  Not Exists 
  (
   Select  
     1  
   FROM 
     ${KNB_TERADATA_USER}.ORD_V_EXT_ANL   AN
  Where  
  (1=1) 
    And AN.DOSSIER_SAV_CD=ISE.DOSSIER_SAV_CD    
  )
 
 Qualify Row_Number() Over (Partition By  ISE.DOSSIER_SAV_CD  Order By   OSP.ETAPE_FTT_DT  Asc , UR.ARRIVEE_DT desc    ) = 1  ;
 
.if errorcode <> 0 then .quit 1                        
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_ANL    ;
.if errorcode <> 0 then .quit 1 


 ----------------------------------------------------------------------------------------------
-- Etape7 : Merge des annulation et extraction des prestations                             ----
----------------------------------------------------------------------------------------------    


Merge Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT  Tmp
 Using
  (
Select
      
   ext.DOSSIER_SAV_CD          ,
   ext.DOSSIER_DEB_DT          ,
   ext.ETAPE_EN_COURS          ,
   ext.ETP_ANNUL_CD            ,
   ext.ETP_ANNUL_TS            ,
   ext.ETP_ANNUL_USR_CD        ,
   ext.ETP_ANNUL_ALLIANCE_CD   ,
   ext.ETP_ANNUL_COMPTE_CD     ,
   ext.ETP_ANNUL_EDO_ID        ,
   ext.STEP_ANL
           
From
     ${KNB_TERADATA_USER}.ORD_V_EXT_ANL  ext
Where
    (1=1)  
   ) Soc
   On      Tmp.EXTERNAL_ORDR_ID       = Soc.DOSSIER_SAV_CD
   And     Tmp.DOSSIER_DEB_DT         = Soc.DOSSIER_DEB_DT
When matched then
 -- Si ça matche on met à jour   :
  Update set
  
    ETP_ANNUL_CD             =   Soc.ETP_ANNUL_CD          ,
    ETP_ANNUL_TS             =   Soc.ETP_ANNUL_TS          ,
    ETP_ANNUL_USR_CD         =   Soc.ETP_ANNUL_USR_CD      ,
    ETP_ANNUL_ALLIANCE_CD    =   Soc.ETP_ANNUL_ALLIANCE_CD ,
    ETP_ANNUL_COMPTE_CD      =   Soc.ETP_ANNUL_COMPTE_CD   ,
    ETP_ANNUL_EDO_ID         =   Soc.ETP_ANNUL_EDO_ID
;

.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_EXT    ;
.if errorcode <> 0 then .quit 1  

.quit 0
