-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Placement_Cold_Alimentation_Step4_Enrichissement_StatutResil.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  d'enrichissement du statut de résiliation pour le placement SOFT
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------

.set width 2500;





-------------------------------------------------------------------------------------------------------
-- Etape 1 : on dans VM Access Reseau on va voir le statut du client                               ----
-------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_RESINT;
.if errorcode <> 0 then .quit 1

--Identification des Ids à enrichir
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_RESINT
(
  EXTERNAL_ORDER_ID     ,
  ORDER_DEPOSIT_DT      ,
  SERVICE_ACCESS_ID     ,
  RESIL_INT_DT          ,
  RESIL_INT_MOTIF       ,
  RESIL_INT_MOTIF_DS    
)
Select
  RefAs.EXTERNAL_ORDER_ID                           as EXTERNAL_ORDER_ID      ,
  RefAs.ORDER_DEPOSIT_DT                            as ORDER_DEPOSIT_DT       ,
  RefAs.SERVICE_ACCESS_ID                           as SERVICE_ACCESS_ID      ,
  VmAccResORD.NETWORK_ACCESS_STATUS_DT              as RESIL_INT_DT           ,
  VmAccResORD.NETWORK_ACCESS_STATUS_DS              as RESIL_INT_MOTIF        ,
  Case  When  VmAccResORD.NETWORK_ACCESS_STATUS_DS  = 'S'
          Then 'Suspension'
        When  VmAccResORD.NETWORK_ACCESS_STATUS_DS  = 'RESCL'
          Then 'Resiliation Client'
        When  VmAccResORD.NETWORK_ACCESS_STATUS_DS  = 'RESFT'
          Then 'Resiliation Orange'
  End                                               as RESIL_INT_MOTIF_DS     
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_AS RefAs
  Inner Join ${KNB_COM_SOC_PRCA_V}.VF_PAR_F_RESEAUX_AGR_D_VM_ORD  VmAccResORD
      --Jointure sur l'AS
    On    RefAs.SERVICE_ACCESS_ID           = VmAccResORD.SERVICE_ACCESS_ID
      And VmAccResORD.CURRENT_IN            = 1
Where
  (1=1)
  And VmAccResORD.NETWORK_ACCESS_STATUS_DT    Is Not Null
  And VmAccResORD.NETWORK_ACCESS_STATUS_DT    >=  RefAs.ORDER_DEPOSIT_DT
  And VmAccResORD.NETWORK_ACCESS_STATUS_DS    Is Not Null
Qualify Row_Number() Over (Partition by RefAs.EXTERNAL_ORDER_ID, RefAs.ORDER_DEPOSIT_DT Order by VmAccResORD.START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1




Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SOFT_C_RESINT;
.if errorcode <> 0 then .quit 1

.quit 0



