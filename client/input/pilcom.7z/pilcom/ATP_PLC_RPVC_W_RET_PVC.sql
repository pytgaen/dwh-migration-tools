-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_RPVC_W_RET_PVC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Perimetre RPVC - REMUNERATION - Alimentation de la table ACT_T_RET_PVC -
--
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 06/1/13         YZH         Creation
-- 06/02/2014      AID         Indus
-- 16/10/2014      YZH         MODIFICATION
-- 07/11/2014      HZO         MODIFICATION : Left outer Join --> Inner Join 
---------------------------------------------------------------------------------

.SET WIDTH 2000;

DELETE FROM      ${KNB_PCO_TMP}.ACT_T_RET_PVC ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;


INSERT INTO      ${KNB_PCO_TMP}.ACT_T_RET_PVC
                  (
                    ACTE_ID,
                    ORDER_DEPOSIT_DT,
                    AGENT_ID_UPD,
                    ORG_NOM,
                    ORG_PRENOM,
                    AGENT_ID_UPD_TS,
                    CREATION_TS,
                    LAST_MODIF_TS,
                    FRESH_IN,
                    COHERENCE_IN
                  )
SELECT
                  Actreturn.ACTE_ID                                         AS ACTE_ID,
                  Actunified.ACT_DT                                         AS ORDER_DEPOSIT_DT,
                  Actreturn.CUID                                            AS AGENT_ID_UPD,
                  Actreturn.SELLER_LAST_NAME                                AS ORG_NOM,
                  Actreturn.SELLER_FIRST_NAME                               AS ORG_PRENOM,
                  Actreturn.FRESH_TS                                        AS AGENT_ID_UPD_TS,
                  Current_Timestamp(0)                                      AS CREATION_TS,
                  Current_Timestamp(0)                                      AS LAST_MODIF_TS,
                  1                                                         AS FRESH_IN,
                  1                                                         AS COHERENCE_IN
FROM              ${KNB_PCO_TMP}.ACT_W_RETURN_PVC              Actreturn
INNER JOIN        ${KNB_PCO_VM}. V_ORD_F_ACTE_UNIFIED          Actunified
ON                Actreturn.ACTE_ID=Actunified.ACTE_ID
Qualify count(1) over (partition by Actreturn.ACTE_ID, Actunified.ACT_DT order by 1) = 1
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- Collecter les stats
COLLECT STATISTICS ON ${KNB_PCO_TMP}.ACT_T_RET_PVC;

.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;
