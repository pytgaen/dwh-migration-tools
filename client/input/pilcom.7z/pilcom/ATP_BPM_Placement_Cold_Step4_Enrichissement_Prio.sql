-- $HEADER:   mm2pco/current/sql/ATP_BPM_Placement_Cold_Step4_Enrichissement_Prio.sql 13_05#3 25-JAN-2018 09:25:10 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BPM_Placement_Cold_Step4_Enrichissement_Prio.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'alimentation de la table de travail pour gérer la compétition client
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR        CREATION/MODIFICATION
-- 13/09/2016      ABO           Creation
-- 23/01/2018      JCR           Modification filtre sur le compte bancaire
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_C_PRIO All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP : La clé                                        ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_C_PRIO
(
  ACTE_ID                         ,
  ORDER_DEPOSIT_DT                ,
  COMPTTN_IN                      ,
  COMPTTN_ID                       
)
Select
  Tmp.ACTE_ID                                                           As ACTE_ID                        ,
  Tmp.ORDER_DEPOSIT_DT                                                  As ORDER_DEPOSIT_DT               ,
  --Si la Vente est la premiere alors il y a concurrence et c'est la maitre
  Case  --- Priorité aux commandes avec le COMPTE_BK_ID de renseigné sinon la vente mâitre est la plus récente
      When (Tmp.FLAG_COMPTE ='O' And Tmp.NUMLINE > 1) OR (Tmp.FLAG_COMPTE ='N' And Tmp.NUMLINE > 1) 
        Then 'O'
      When (Tmp.FLAG_COMPTE='O'  And Tmp.NUMLINE = 1)  OR (Tmp.FLAG_COMPTE='N'  And Tmp.NUMLINE = 1)  
        Then 'N'
  End                                                                   As COMPTTN_IN                     ,
  Case
      --Dans le cas où c'est la 1ere commande :
      When Tmp.NUMLINE = 1
        Then Null
      --Dans le cas où ce n'est pas la 1ere commande on récupère l'identifiant de la 1ere colonne
      Else
        (Max(Case When Tmp.NUMLINE > 1 Then Null Else Tmp.ACTE_ID end)
            Over  ( Partition by  Tmp.EXTERNAL_PRODUCT_ID               ,
                                  Tmp.CUST_BK_ID                         
                    Order by      Tmp.NUMLINE Asc                       ,
                                  Tmp.ACTE_ID Asc                        
                  )
        )
  End                                                      As COMPTTN_ID 
From
  (
    Select
      Placement.ACTE_ID                       As ACTE_ID                        ,
      Placement.ORDER_DEPOSIT_DT              As ORDER_DEPOSIT_DT               ,
      Placement.DATE_CREATE_TS                As DATE_CREATE_TS                 ,
      Placement.EXTERNAL_PRODUCT_ID           As EXTERNAL_PRODUCT_ID            ,
      Placement.CUST_BK_ID                    As CUST_BK_ID                     ,
      Placement.COMPTE_BK_ID                  As COMPTE_BK_ID                   ,
      Row_Number() Over (Partition By Placement.EXTERNAL_PRODUCT_ID,
                                      Placement.CUST_BK_ID
                         Order by Placement.DATE_CREATE_TS Asc) as NUMLINE      ,
      --Flag permettant de savoir si un ACCOUNT_START_TS est renseigné ou non        
      Case when Placement.ACCOUNT_START_TS is not null 
             then 'O'
           Else 'N'
      End                                      As FLAG_COMPTE
    From
      ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_C_1 Placement
    Where
      (1=1)
      --Commandes validées uniquement
    And Placement.CLOSURE_FONC_CD is null 
  )Tmp
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BPM_C_PRIO;
.if errorcode <> 0 then .quit 1

.quit 0


