--$HEADER:   mm2pco/current/sql/ATP_COE_Placement_Enrichissement_Step4_ALOES.sql 13_05#2 29-OCT-2018 15:04:15 GXPZ7694
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_COE_Placement_Enrichissement_ALOES.sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'Enrichissement CUID 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/10/2018       HOB          Creation
----------------------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_OEE All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation Tables avec les conseillers qui ont crées l'inter et ceux qui l'ont realisée                                         
----------------------------------------------------------------------------------------------
  Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_OEE
  (  
    ACTE_ID                     ,
    OPERATOR_PROVIDER_ID        ,
    ORDER_DEPOSIT_DT            ,
    EXTRNL_APPLI_SOURCE_ID      ,
    EXTERNAL_ORDER_ID           ,
    ORDR_TYP_CD                 ,
    EXTRNL_CONCLSN_ID           ,
    EXTRNL_DOSSIER_NU           ,
    EXTRNL_CLIENT_NU            ,
    ALOES_CREATED_AGENT_ID      ,
    ALOES_RESP_AGENT_ID         

    )
  Select
    Placement.ACTE_ID                                             as  ACTE_ID                      ,
    Placement.OPERATOR_PROVIDER_ID                                as  OPERATOR_PROVIDER_ID         ,
    Placement.ORDER_DEPOSIT_DT                                    as  ORDER_DEPOSIT_DT             ,
    Placement.EXTRNL_APPLI_SOURCE_ID                              as  EXTRNL_APPLI_SOURCE_ID       ,
    Placement.EXTERNAL_ORDER_ID                                   as  EXTERNAL_ORDER_ID            ,
    Placement.ORDR_TYP_CD                                         as  ORDR_TYP_CD                  ,
    Placement.EXTRNL_CONCLSN_ID                                   as  EXTRNL_CONCLSN_ID            ,
    Placement.EXTRNL_DOSSIER_NU                                   as  EXTRNL_DOSSIER_NU            ,
    Placement.EXTRNL_CLIENT_NU                                    as  EXTRNL_CLIENT_NU             ,
    AGENT_INIT.CONSEIL_LB_LOGIN_ALOES                             as  ALOES_CREATED_AGENT_ID       ,
    AGENT_REA.CONSEIL_LB_LOGIN_ALOES                              as  ALOES_RESP_AGENT_ID           
    
  From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_1  Placement 
       Left Outer Join ${KNB_IBU_SOC_V}.VF_TDCONSEIL AGENT_INIT
          On   Placement.EXTRNL_CREATED_XI_OEE    = AGENT_INIT.CONSEIL_XI
       Left Outer Join ${KNB_IBU_SOC_V}.VF_TDCONSEIL AGENT_REA
          On  Placement.EXTRNL_RESP_XI_OEE       = AGENT_REA.CONSEIL_XI
     
Where
  (1=1)
  And Placement.ALOES_CREATED_AGENT_ID is  null 
;

.if errorcode <> 0 then .quit 1            
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_OEE  ; 
.if errorcode <> 0 then .quit 1  
