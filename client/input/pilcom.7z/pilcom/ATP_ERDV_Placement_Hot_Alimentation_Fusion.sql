-- $HEADER: mm2pco/current/sql/ATP_ERDV_Placement_Hot_Alimentation_Fusion.sql 13_05#9 26-JUN-2019 11:40:03 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Placement_Hot_Alimentation_Fusion.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement de placement à chaud pour ERDV
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 06/01/2014      YZH         Creation
-- 29/04/2015      YZH         Modif: rajout flags SCH/AD
-- 02/11/2016      HOB         Modification VA
-- 21/11/2017      HOB         Alimentation Champs IOBSP
-- 12/02/2019      SSI         Alimentation Champs ORG_AGENT_IOBSP  
-- 06/05/2019      TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_ERDV_H All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_ERDV_H
(
    ACTE_ID                               ,
    EXTERNAL_ACTE_ID                      ,
    INTRNL_SOURCE_ID                      ,
    EXTERNAL_ORDER_ID                     ,
    ORDER_DEPOSIT_TS                      ,
    ORDER_DEPOSIT_DT                      ,
    INTERVENTION_ID                       ,
    ORDER_LINE_EXTERNAL_ID                ,
    ORDER_LINE_STATUS_CD                  ,
    TYPE_OP_NM                            ,
    AGENT_ID                              ,
    ORG_AGENT_IOBSP                       ,
    ORG_NOM_NM                            ,
    ORG_PRENOM_NM                         ,
    EDO_ID                                ,
    TYPE_EDO                              ,
    ORG_EDO_IOBSP                         ,
    FLAG_PLT_CONV                         ,
    FLAG_PLT_SCH                          ,
    FLAG_PLT_AD                           ,
    FLAG_PLT_PRO                          ,
    FLAG_TEAM_MKT                         ,
    FLAG_TYPE_CMP                         ,
    NETWRK_TYP_EDO_ID                     ,
    FLAG_TYPE_GEO                         ,
    FLAG_TYPE_CPT_NTK                     ,
    FLAG_TYPE_PTN_NTK                     ,
    ACTIVITY_UNIT_CD                      ,
    CONTRACT_CUSTOMER_LAST_NAME           ,
    CONTRACT_CUSTOMER_MARKET_SEG          ,
    CONTACT_CIVILITY_NM                   ,
    CONTACT_LAST_NAME_NM                  ,
    CONTACT_FIRST_NAME_NM                 ,
    CONTACT_MOBILE_NUMBER_NU              ,
    CONTACT_TEL_NUMBER_NU                 ,
    REF_GROUPED_OFFER_CD                  ,
    GPC_ID                                ,
    STATUS_INTERVENTION_CD                ,
    DATE_RESERVATION_TS                   ,
    DATE_BEGIN_TS                         ,
    REF_ERDV_CD                           ,
    ORDER_LINE_CONTRACT_DATE_TS           ,
    ORDER_LINE_WANTED_DATE_TS             ,
    ORDER_LINE_PREST_CD                   ,
    ORDER_LINE_QUANTITY_QT                ,
    ORDER_LINE_AMOUNT_AM                  ,
    ORDER_LINE_TVA_RT                     ,
    ORDER_LINE_OPER_CD                    ,
    DELIVERY_CUSTOMER_MARKET_SEG          ,
    DELIVERY_CUSTOMER_LAST_NAME           ,
    DELIVERY_CUSTOMER_ADDRESS_APPT        ,
    DELIVERY_CUSTOMER_ADDRESS_ESC         ,
    DELIVERY_CUSTOMER_ADDRESS_STG         ,
    DELIVERY_CUSTOMER_ADDRESS_BAT         ,
    DELIVERY_CUSTOMER_ADDRESS_RES         ,
    DELIVERY_CUSTOMER_ADDRESS_ZIP         ,
    DELIVERY_CUSTOMER_ADDRESS_NUM         ,
    DELIVERY_CUSTOMER_ADDRESS_ST_T        ,
    DELIVERY_CUSTOMER_ADDRESS_STR         ,
    DELIVERY_CUSTOMER_ADDRESS_CITY        ,
    DELIVERY_CUSTOMER_ADDRESS_INSE        ,
    REF_OFFRE_CIBLE_CD                    ,
    CATALOGUE_CD                          ,
    CUSTOMER_ND_NU                        ,
    CUSTOMER_NDS_NU                       ,
    CUSTOMER_BSS_ID                       ,
    BSS_PARTY_KNB_ID                      ,
    CUSTOMER_FGT_ID                       ,
    FREG_PARTY_KNB_ID                     ,
    SERVICE_ACCESS_ID                     ,
    LINE_ID                               ,
    MASTER_LINE_ID                        ,
    PAR_GEO_MACROZONE                     ,
    PAR_UNIFIED_PARTY_ID                  ,
    PAR_PARTY_REGRPMNT_ID                 ,
    CONVERGENT_IN                         ,
    QUEUE_TS                              ,
    RUN_ID                                ,
    STREAMING_TS                          ,
    CREATION_TS                           ,
    LAST_MODIF_TS                         ,
    HOT_IN                                ,
    FRESH_IN                              ,
    COHERENCE_IN
)
Select
  Placement.ACTE_ID                                        as ACTE_ID                                       ,
  Placement.EXTERNAL_ACTE_ID                               as EXTERNAL_ACTE_ID                              ,
  Placement.INTRNL_SOURCE_ID                               as INTRNL_SOURCE_ID                              ,
  Placement.EXTERNAL_ORDER_ID                              as EXTERNAL_ORDER_ID                             ,
  Placement.ORDER_DEPOSIT_TS                               as ORDER_DEPOSIT_TS                              ,
  Placement.ORDER_DEPOSIT_DT                               as ORDER_DEPOSIT_DT                              ,
  Placement.INTERVENTION_ID                                as INTERVENTION_ID                               ,
  Placement.ORDER_LINE_EXTERNAL_ID                         as ORDER_LINE_EXTERNAL_ID                        ,
  Placement.ORDER_LINE_STATUS_CD                           as ORDER_LINE_STATUS_CD                          ,
  Placement.TYPE_OP_NM                                     as TYPE_OP_NM                                    ,
  Placement.AGENT_ID                                       as AGENT_ID                                      ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                    as  ORG_AGENT_IOBSP                              ,
  Csl.ORG_NOM_NM                                           as ORG_NOM_NM                                    ,
  Csl.ORG_PRENOM_NM                                        as ORG_PRENOM_NM                                 ,
  O3.EDO_ID                                                as EDO_ID                                        ,
  O3.TYPE_EDO                                              as TYPE_EDO                                      ,
  Case When EdoOBK.EDO_ID is Not Null 
         Then 'O' 
          Else 'N'
  End                                                      as ORG_EDO_IOBSP                                 ,
  O3.FLAG_PLT_CONV                                         as FLAG_PLT_CONV                                 ,
  O3.FLAG_PLT_SCH                                          as FLAG_PLT_SCH                                  ,
  O3.FLAG_PLT_AD                                           as FLAG_PLT_AD                                   ,
  O3.FLAG_PLT_PRO                                          as FLAG_PLT_PRO                                  ,
  O3.FLAG_TEAM_MKT                                         as FLAG_TEAM_MKT                                 ,
  O3.FLAG_TYPE_CMP                                         as FLAG_TYPE_CMP                                 ,
  O3.NETWRK_TYP_EDO_ID                                     as NETWRK_TYP_EDO_ID                             ,
  O3.FLAG_TYPE_GEO                                         as FLAG_TYPE_GEO                                 ,
  O3.FLAG_TYPE_CPT_NTK                                     as FLAG_TYPE_CPT_NTK                             ,
  O3.FLAG_TYPE_PTN_NTK                                     as FLAG_TYPE_PTN_NTK                             ,
  Placement.ACTIVITY_UNIT_CD                               as ACTIVITY_UNIT_CD                              ,
  Placement.CONTRACT_CUSTOMER_LAST_NAME                    as CONTRACT_CUSTOMER_LAST_NAME                   ,
  Placement.CONTRACT_CUSTOMER_MARKET_SEG                   as CONTRACT_CUSTOMER_MARKET_SEG                  ,
  Placement.CONTACT_CIVILITY_NM                            as CONTACT_CIVILITY_NM                           ,
  Placement.CONTACT_LAST_NAME_NM                           as CONTACT_LAST_NAME_NM                          ,
  Placement.CONTACT_FIRST_NAME_NM                          as CONTACT_FIRST_NAME_NM                         ,
  Placement.CONTACT_MOBILE_NUMBER_NU                       as CONTACT_MOBILE_NUMBER_NU                      ,
  Placement.CONTACT_TEL_NUMBER_NU                          as CONTACT_TEL_NUMBER_NU                         ,
  Placement.REF_GROUPED_OFFER_CD                           as REF_GROUPED_OFFER_CD                          ,
  Placement.GPC_ID                                         as GPC_ID                                        ,
  Placement.STATUS_INTERVENTION_CD                         as STATUS_INTERVENTION_CD                        ,
  Placement.DATE_RESERVATION_TS                            as DATE_RESERVATION_TS                           ,
  Placement.DATE_BEGIN_TS                                  as DATE_BEGIN_TS                                 ,
  Placement.REF_ERDV_CD                                    as REF_ERDV_CD                                   ,
  Placement.ORDER_LINE_CONTRACT_DATE_TS                    as ORDER_LINE_CONTRACT_DATE_TS                   ,
  Placement.ORDER_LINE_WANTED_DATE_TS                      as ORDER_LINE_WANTED_DATE_TS                     ,
  Placement.ORDER_LINE_PREST_CD                            as ORDER_LINE_PREST_CD                           ,
  Placement.ORDER_LINE_QUANTITY_QT                         as ORDER_LINE_QUANTITY_QT                        ,
  Placement.ORDER_LINE_AMOUNT_AM                           as ORDER_LINE_AMOUNT_AM                          ,
  Placement.ORDER_LINE_TVA_RT                              as ORDER_LINE_TVA_RT                             ,
  Placement.ORDER_LINE_OPER_CD                             as ORDER_LINE_OPER_CD                            ,
  Placement.DELIVERY_CUSTOMER_MARKET_SEG                   as DELIVERY_CUSTOMER_MARKET_SEG                  ,
  Placement.DELIVERY_CUSTOMER_LAST_NAME                    as DELIVERY_CUSTOMER_LAST_NAME                   ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_APPT                 as DELIVERY_CUSTOMER_ADDRESS_APPT                ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_ESC                  as DELIVERY_CUSTOMER_ADDRESS_ESC                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_STG                  as DELIVERY_CUSTOMER_ADDRESS_STG                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_BAT                  as DELIVERY_CUSTOMER_ADDRESS_BAT                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_RES                  as DELIVERY_CUSTOMER_ADDRESS_RES                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_ZIP                  as DELIVERY_CUSTOMER_ADDRESS_ZIP                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_NUM                  as DELIVERY_CUSTOMER_ADDRESS_NUM                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_ST_T                 as DELIVERY_CUSTOMER_ADDRESS_ST_T                ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_STR                  as DELIVERY_CUSTOMER_ADDRESS_STR                 ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_CITY                 as DELIVERY_CUSTOMER_ADDRESS_CITY                ,
  Placement.DELIVERY_CUSTOMER_ADDRESS_INSE                 as DELIVERY_CUSTOMER_ADDRESS_INSE                ,
  Placement.REF_OFFRE_CIBLE_CD                             as REF_OFFRE_CIBLE_CD                            ,
  Placement.CATALOGUE_CD                                   as CATALOGUE_CD                                  ,
  Placement.CUSTOMER_ND_NU                                 as CUSTOMER_ND_NU                                ,
  Placement.CUSTOMER_NDS_NU                                as CUSTOMER_NDS_NU                               ,
  null                                                     as CUSTOMER_BSS_ID                               ,
  null                                                     as BSS_PARTY_KNB_ID                              ,
  null                                                     as CUSTOMER_FGT_ID                               ,
  null                                                     as FREG_PARTY_KNB_ID                             ,
  null                                                     as SERVICE_ACCESS_ID                             ,
  null                                                     as LINE_ID                                       ,
  null                                                     as MASTER_LINE_ID                                ,
  Null                                                     as PAR_GEO_MACROZONE                             ,
  Null                                                     as PAR_UNIFIED_PARTY_ID                          , 
  Null                                                     as PAR_PARTY_REGRPMNT_ID                         ,
  null                                                     as CONVERGENT_IN                                 ,
  Placement.QUEUE_TS                                       as QUEUE_TS                                      ,
  Placement.RUN_ID                                         as RUN_ID                                        ,
  Placement.STREAMING_TS                                   as STREAMING_TS                                  ,
  Current_Timestamp(0)                                     as CREATION_TS                                   ,
  Current_Timestamp(0)                                     as LAST_MODIF_TS                                 ,
  1                                                        as HOT_IN                                        ,
  1                                                        as FRESH_IN                                      ,
  0                                                        as COHERENCE_IN
From
    ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H Placement
  --  Enrichissement Conseiller
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_ENRI_CSL Csl
    On  Placement.ACTE_ID = Csl.ACTE_ID
  --  Enrichissement O3
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_ENRI_O3 O3
    On  Placement.ACTE_ID = O3.ACTE_ID
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On    O3.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')     And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On    Placement.AGENT_ID=CuidOBK.AGENT_ID
      And   Placement.ORDER_DEPOSIT_DT  >= CuidOBK.HABILL_BEGIN_DT 
      And   Placement.ORDER_DEPOSIT_DT   < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))  
      
   Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By Placement.ORDER_DEPOSIT_TS asc)=1     
;


.if errorcode <> 0 then .quit 1


Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_ERDV_H;
.if errorcode <> 0 then .quit 1

.quit 0
