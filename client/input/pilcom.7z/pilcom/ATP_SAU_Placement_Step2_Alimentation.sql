-- $HEADER: mm2pco/current/sql/ATP_SAU_Placement_Step2_Alimentation.sql 13_05#2 15-JUN-2017 14:04:08 FQJR5800
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SAU_Placement_Step1_Alimentation.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Alimentation acte_id SAVI SAU
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 16/05/2017      MDE         Creation
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAU_1 All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table temporaire                                          ----
----------------------------------------------------------------------------------------------


 
Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAU_1
(
  ACTE_ID                          ,
  EXTERNAL_ORDR_ID                 ,
  EXT_ORDR_LINE_NU                 ,
  ORDER_DEPOSIT_DT                 ,
  ORDER_DEPOSIT_TS                 ,
  TYPE_SOURCE_ID                   ,
  INTRNL_SOURCE_ID                 ,
  ORDER_STATUS                     ,
  ORDR_TYP_CD                      ,
  MOTIF_CD                         ,
  CODE_INTERNE_CD                  ,
  CODE_INTERNE_DS                  ,
  PRESTATION_CD                    ,
  OPSRV_EAN_CD                     ,
  PAR_MSISDN_ID                    ,
  PAR_NDS                          ,
  PAR_AID                          ,
  EXT_PRODUCT_PREVIOUS_ID          ,
  PREVIOUS_EAN_CD                  , 
  TERM_FAM_CD                      , 
  TERM_MODEL_DS                    ,
  TERM_IMEI_CD                     , 
  EXT_AGENT_ID                     ,
  ORG_AGENT_ID                     , 
  ORG_LAST_NAME_NM                 ,
  ORG_FIRST_NAME_NM                ,
  EXT_SHOP_ID                      , 
  EXT_SHOP_UNITE_CD                ,
  EXT_TYP_SHOP_CD                  ,
  EXT_SHOP_ADV_CD                  ,
  PAR_LASTNAME                     ,
  PAR_FIRSTNAME                    ,
  PAR_POSTAL_CD                    ,
  DMC_LINE_ID                      ,
  DMC_MAsTER_LINE_ID               ,
  DMC_LINE_TYPE                    ,
  DMC_ACTIVATION_DT                ,
  PAR_INSEE_NB                     ,
  PAR_BU_CD                        ,
  CLIENT_NU                        ,
  DOSSIER_NU                       ,
  PAR_FIBER_IN                     ,
  PAR_GEO_MACROZONE                ,
  PAR_UNIFIED_PARTY_ID             ,
  PAR_PARTY_REGRPMNT_ID            ,
  PAR_IRIS2000_CD                  ,
  PAR_PID_ID                       ,
  PAR_CID_ID                       ,
  PAR_FIRST_IN                     ,
  SERVICE_ACCESS_ID                ,
  PAR_DEPRTMNT_ID                  ,
  CUST_BU_CD                       ,
  EDO_ID                           ,
  TYPE_EDO_ID                      ,
  DISTRBTN_CHANNL_ID               ,      
  ACTIVITY                         ,        
  FLAG_PLT_SCH_IN                  ,
  FLAG_PLT_CONV_NB                 ,
  FLAG_TYPE_GEO_CD                 ,
  FLAG_TYPE_CPT_NTK                ,
  NETWRK_TYP_EDO_ID                ,
  FLAG_TYPE_PTN_NTK                ,
  ORG_CHANNEL_CD                   ,
  ORG_SUB_CHANNEL_CD               ,
  ORG_SUB_SUB_CHANNEL_CD           ,
  ORG_GT_ACTIVITY                  ,
  ORG_FIDELISATION                 ,
  ORG_WEB_ACTIVITY                 ,
  ORG_AUTO_ACTIVITY                ,
  ORG_REM_CHANNEL_CD               ,
  ORG_TEAM_LEVEL_1_CD              ,
  ORG_TEAM_LEVEL_1_DS              ,
  ORG_TEAM_LEVEL_2_CD              ,
  ORG_TEAM_LEVEL_2_DS              ,
  ORG_TEAM_LEVEL_3_CD              ,
  ORG_TEAM_LEVEL_3_DS              ,
  ORG_TEAM_LEVEL_4_CD              ,
  ORG_TEAM_LEVEL_4_DS              ,
  WORK_TEAM_LEVEL_1_CD             ,
  WORK_TEAM_LEVEL_1_DS             ,
  WORK_TEAM_LEVEL_2_CD             ,
  WORK_TEAM_LEVEL_2_DS             ,
  WORK_TEAM_LEVEL_3_CD             ,
  WORK_TEAM_LEVEL_3_DS             ,
  WORK_TEAM_LEVEL_4_CD             ,
  WORK_TEAM_LEVEL_4_DS             ,
  CREATION_TS                      ,
  LAST_MODIF_TS                    ,
  FRESH_IN                         ,
  COHERENCE_IN

)
Select
    ActeId.ACTE_ID                              	 AS  ACTE_ID                   ,
    Placement.EXTERNAL_ORDR_ID                 	  As  EXTERNAL_ORDR_ID           ,
    Placement.EXT_ORDR_LINE_NU                 	  As  EXT_ORDR_LINE_NU           ,
    Placement.ORDER_DEPOSIT_DT                 	  As  ORDER_DEPOSIT_DT           ,
    Placement.ORDER_DEPOSIT_TS                 	  As  ORDER_DEPOSIT_TS           ,
    Placement.TYPE_SOURCE_ID                   	  As  TYPE_SOURCE_ID             ,
    Placement.INTRNL_SOURCE_ID                 	  As  INTRNL_SOURCE_ID           ,
    Placement.ORDER_STATUS                     	  As  ORDER_STATUS               ,
    Placement.ORDR_TYP_CD                      	  As  ORDR_TYP_CD                ,
    Placement.MOTIF_CD                         	  As  MOTIF_CD                   ,
    Placement.CODE_INTERNE_CD                  	  As  CODE_INTERNE_CD            ,
    Placement.CODE_INTERNE_DS                  	  As  CODE_INTERNE_DS            ,
    Placement.PRESTATION_CD                       As PRESTATION_CD               ,
    Placement.OPSRV_EAN_CD                     	  As  OPSRV_EAN_CD               ,
    Placement.PAR_MSISDN_ID                    	  As  PAR_MSISDN_ID              ,
    Placement.PAR_NDS                          	  As  PAR_NDS                    ,
    Placement.PAR_AID                          	  As  PAR_AID                    ,
    Placement.EXT_PRODUCT_PREVIOUS_ID          	  As  EXT_PRODUCT_PREVIOUS_ID    ,
    Placement.PREVIOUS_EAN_CD                   	As  PREVIOUS_EAN_CD            , 
    Placement.TERM_FAM_CD                       	As  TERM_FAM_CD                , 
    Placement.TERM_MODEL_DS                    	  As  TERM_MODEL_DS              ,
    Placement.TERM_IMEI_CD                      	As  TERM_IMEI_CD               , 
    Placement.EXT_AGENT_ID                     	  As  EXT_AGENT_ID               ,
    Placement.ORG_AGENT_ID                      	As  ORG_AGENT_ID               , 
    Placement.ORG_LAST_NAME_NM                 	  As  ORG_LAST_NAME_NM           ,
    Placement.ORG_FIRST_NAME_NM                	  As  ORG_FIRST_NAME_NM          ,
    Placement.EXT_SHOP_ID                       	As  EXT_SHOP_ID                ,      
    Placement.EXT_SHOP_UNITE_CD                	  As  EXT_SHOP_UNITE_CD          ,
    Placement.EXT_TYP_SHOP_CD                  	  As  EXT_TYP_SHOP_CD            ,
    Placement.EXT_SHOP_ADV_CD                  	  As  EXT_SHOP_ADV_CD            ,
    Placement.PAR_LASTNAME                     	  As  PAR_LASTNAME               ,
    Placement.PAR_FIRSTNAME                    	  As  PAR_FIRSTNAME              ,
    Placement.PAR_POSTAL_CD                    	  As  PAR_POSTAL_CD              ,
    Placement.DMC_LINE_ID                      	  As  DMC_LINE_ID                ,
    Placement.DMC_MAsTER_LINE_ID               	  As  DMC_MAsTER_LINE_ID         ,
    Placement.DMC_LINE_TYPE                    	  As  DMC_LINE_TYPE              ,
    Placement.DMC_ACTIVATION_DT                	  As  DMC_ACTIVATION_DT          ,
    Placement.PAR_INSEE_NB                     	  As  PAR_INSEE_NB               ,
    Placement.PAR_BU_CD                        	  As  PAR_BU_CD                  ,
    Placement.CLIENT_NU                        	  As  CLIENT_NU                  ,
    Placement.DOSSIER_NU                       	  As  DOSSIER_NU                 ,
    Placement.PAR_FIBER_IN                     	  As  PAR_FIBER_IN               ,
    Placement.PAR_GEO_MACROZONE                	  As  PAR_GEO_MACROZONE          ,
    Placement.PAR_UNIFIED_PARTY_ID             	  As  PAR_UNIFIED_PARTY_ID       ,
    Placement.PAR_PARTY_REGRPMNT_ID            	  As  PAR_PARTY_REGRPMNT_ID      ,
    Placement.PAR_IRIS2000_CD                  	  As  PAR_IRIS2000_CD            ,
    Placement.PAR_PID_ID                       	  As  PAR_PID_ID                 ,
    Placement.PAR_CID_ID                       	  As  PAR_CID_ID                 ,
    Placement.PAR_FIRST_IN                     	  As  PAR_FIRST_IN               ,
    Placement.SERVICE_ACCESS_ID                	  As  SERVICE_ACCESS_ID          ,
    Placement.PAR_DEPRTMNT_ID                  	  As  PAR_DEPRTMNT_ID            ,
    Placement.CUST_BU_CD                       	  As  CUST_BU_CD                 ,
    Placement.EDO_ID                           	  As  EDO_ID                     ,
    Placement.TYPE_EDO_ID                      	  As  TYPE_EDO_ID                ,
    Placement.DISTRBTN_CHANNL_ID                  As  DISTRBTN_CHANNL_ID         ,
    Placement.ACTIVITY                            As  ACTIVITY                   ,
    Placement.FLAG_PLT_SCH_IN                  	  As  FLAG_PLT_SCH_IN            ,
    Placement.FLAG_PLT_CONV_NB                 	  As  FLAG_PLT_CONV_NB           ,
    Placement.FLAG_TYPE_GEO_CD                 	  As  FLAG_TYPE_GEO_CD           ,
    Placement.FLAG_TYPE_CPT_NTK                	  As  FLAG_TYPE_CPT_NTK          ,
    Placement.NETWRK_TYP_EDO_ID                	  As  NETWRK_TYP_EDO_ID          ,
    Placement.FLAG_TYPE_PTN_NTK                	  As  FLAG_TYPE_PTN_NTK          ,
    Placement.ORG_CHANNEL_CD                   	  As  ORG_CHANNEL_CD             ,
    Placement.ORG_SUB_CHANNEL_CD               	  As  ORG_SUB_CHANNEL_CD         ,
    Placement.ORG_SUB_SUB_CHANNEL_CD           	  As  ORG_SUB_SUB_CHANNEL_CD     ,
    Placement.ORG_GT_ACTIVITY                  	  As  ORG_GT_ACTIVITY            ,
    Placement.ORG_FIDELISATION                 	  As  ORG_FIDELISATION           ,
    Placement.ORG_WEB_ACTIVITY                 	  As  ORG_WEB_ACTIVITY           ,
    Placement.ORG_AUTO_ACTIVITY                	  As  ORG_AUTO_ACTIVITY          ,
    Placement.ORG_REM_CHANNEL_CD               	  As  ORG_REM_CHANNEL_CD         ,
    Placement.ORG_TEAM_LEVEL_1_CD              	  As  ORG_TEAM_LEVEL_1_CD        ,
    Placement.ORG_TEAM_LEVEL_1_DS              	  As  ORG_TEAM_LEVEL_1_DS        ,
    Placement.ORG_TEAM_LEVEL_2_CD              	  As  ORG_TEAM_LEVEL_2_CD        ,
    Placement.ORG_TEAM_LEVEL_2_DS              	  As  ORG_TEAM_LEVEL_2_DS        ,
    Placement.ORG_TEAM_LEVEL_3_CD              	  As  ORG_TEAM_LEVEL_3_CD        ,
    Placement.ORG_TEAM_LEVEL_3_DS              	  As  ORG_TEAM_LEVEL_3_DS        ,
    Placement.ORG_TEAM_LEVEL_4_CD              	  As  ORG_TEAM_LEVEL_4_CD        ,
    Placement.ORG_TEAM_LEVEL_4_DS              	  As  ORG_TEAM_LEVEL_4_DS        ,
    Placement.WORK_TEAM_LEVEL_1_CD             	  As  WORK_TEAM_LEVEL_1_CD       ,
    Placement.WORK_TEAM_LEVEL_1_DS             	  As  WORK_TEAM_LEVEL_1_DS       ,
    Placement.WORK_TEAM_LEVEL_2_CD             	  As  WORK_TEAM_LEVEL_2_CD       ,
    Placement.WORK_TEAM_LEVEL_2_DS             	  As  WORK_TEAM_LEVEL_2_DS       ,
    Placement.WORK_TEAM_LEVEL_3_CD             	  As  WORK_TEAM_LEVEL_3_CD       ,
    Placement.WORK_TEAM_LEVEL_3_DS             	  As  WORK_TEAM_LEVEL_3_DS       ,
    Placement.WORK_TEAM_LEVEL_4_CD             	  As  WORK_TEAM_LEVEL_4_CD       ,
    Placement.WORK_TEAM_LEVEL_4_DS             	  As  WORK_TEAM_LEVEL_4_DS       ,
    Placement.CREATION_TS                      	  As  CREATION_TS                ,
    Placement.LAST_MODIF_TS                    	  As  LAST_MODIF_TS              ,
    Placement.FRESH_IN                         	  As  FRESH_IN                   ,
    Placement.COHERENCE_IN	                      As  COHERENCE_IN
From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAU_EXT Placement
  Inner Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN ActeId
    On    Placement.EXTERNAL_ACTE_ID          = ActeId.EXTERNAL_ACTE_ID
      And Placement.TYPE_SOURCE_ID            = ActeId.TYPE_SOURCE_ID
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAU_1;
.if errorcode <> 0 then .quit 1

