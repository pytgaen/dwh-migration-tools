-- $HEADER:   mm2pco/current/sql/ATP_ETASK_Referentiel_Alimentation_Enrichissement_Step2_IDLineDMC.sql 13_05#6 02-JAN-2017 16:13:39 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ETASK_Referentiel_Alimentation_Enrichissement_Step2_IDLineDMC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 13/10/2015      MDE         Creation
-- 09/12/2016      HIB
-- 09/12/2016      HOB         MODIFICATION VA
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.ORD_W_REF_ETK_IDLINEDMC all;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK_IDLINEDMC
(
  EXTERNAL_ORDER_ID         ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  DEPARTMNT_ID              ,
  BU_CD                     ,
  POSTAL_CD                 ,
  INSEE_CD                  ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID 

)
Select
  RefId.EXTERNAL_ORDER_ID                         as EXTERNAL_ORDER_ID         ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT          ,
  LineDmc.LINE_ID                                 as DMC_LINE_ID               ,
  LineDmc.LINE_ID                                 as DMC_MASTER_LINE_ID        ,
  Ldmc.DEPRTMNT_ID                                as DEPARTMNT_ID              ,
  Geo.BU_CD                                       as BU_CD                     ,
  Ldmc.POSTAL_CD                                  as POSTAL_CD                 ,
  Ldmc.INSEE_NB                                   as INSEE_CD                  ,
  Ldmc.UNIFIED_PARTY_ID                           AS PAR_UNIFIED_PARTY_ID      , 
  Ldmc.PARTY_REGRPMNT_ID                          AS PAR_PARTY_REGRPMNT_ID
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK RefId
     Inner Join ${KNB_DMU_DMC_VM_V}.PAR_F_LNK_AR LineDmc
      --Jointure Client/Dossier
     On RefId.CUSTOMER_MSISDN_NU = LineDmc.RES_VALUE_DS
    And RefId.CLIENT_NU         = LineDmc.ADV_CLIENT_NU
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM Ldmc
     On LineDmc.LINE_ID = Ldmc.LINE_ID
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = Ldmc.DEPRTMNT_ID

Where
  (1=1)
  And RefId.DMC_LINE_ID   Is Null
  --And Ldmc.LINE_TYPE   In ('P','M')
  And Ldmc.CLOSURE_DT  Is Null
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_REF_ETK_IDLINEDMC;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 2 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_REF_ETK_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK_IRIS
(
  EXTERNAL_ORDER_ID             ,
  ORDER_DEPOSIT_DT              ,
  DMC_LINE_ID                   ,
  PAR_IRIS2000_CD               ,
  PAR_GEO_MACROZONE
)
Select
  RefId.EXTERNAL_ORDER_ID                         as EXTERNAL_ORDER_ID                        ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT                         ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                              ,
  FIBER.IRIS2000_CD                               as PAR_IRIS2000_CD                          ,
  FIBER.RESERV_4                                  AS PAR_GEO_MACROZONE 
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.LINE_FIBER_AVLB FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
  Where
  (1=1)
 Qualify Row_Number() Over (Partition by RefId.EXTERNAL_ORDER_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.LAST_MODIF_TS Desc)=1

  ;

.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_REF_ETK_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 3 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_REF_ETK_FIBER All;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK_FIBER
(
  EXTERNAL_ORDER_ID                     ,
  ORDER_DEPOSIT_DT            ,
  DMC_LINE_ID                 ,
  FIBER_IN
)
Select
  RefId.EXTERNAL_ORDER_ID                         as EXTERNAL_ORDER_ID                      ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT                       ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                            ,
  FIBER.FIBER_IN                                  as FIBER_IN
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK_IDLINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
  on RefId.DMC_LINE_ID = FIBER.LINE_ID
   Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.EXTERNAL_ORDER_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
  ;

.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_REF_ETK_FIBER;
.if errorcode <> 0 then .quit 1

.quit 0

