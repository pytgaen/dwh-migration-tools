-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:ATP_PCO_EnrichissementPlacementEng_VAD.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 16/12/2011     CDR         Création
-- 06/02/2014     AID         Indus
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_OLD All
;Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_NEW All
;
.if errorcode <> 0 then .quit 1

-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_TFINDICOM
-- **************************************************************

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_OLD
(
  ACTE_ID                   ,
  CONTRCT_DT_SIGN_PREC      ,
  CONTRCT_DT_FIN_PREC       
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  Cont.CONTRDOS_DT_DEB              as CONTRCT_DT_SIGN_PREC ,
  --On fais la différence entre les dates de contrats : J (Jour), M (Mois), A (Années)
  Case  --Dans les cas d'un contrat en jour
        When Cont.CONTRDOS_CO_UNIT_CONTRAT = 'J'
          Then (Cont.CONTRDOS_DT_DEB + Cast(Cont.CONTRDOS_NB_DUR_CONTRAT as interval day(4)))
        --Dans le cadre des mois :
        When Cont.CONTRDOS_CO_UNIT_CONTRAT = 'M'
          Then ADD_MONTHS(Cont.CONTRDOS_DT_DEB,Cont.CONTRDOS_NB_DUR_CONTRAT)
        --Dans le cadre des années
        When Cont.CONTRDOS_CO_UNIT_CONTRAT = 'A'
          Then (Cont.CONTRDOS_DT_DEB + Cast(Cont.CONTRDOS_NB_DUR_CONTRAT as interval Year))
        Else
          Null
  End                               as CONTRCT_DT_FIN_PREC  
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_THCONTRDOS Cont
    On    Inter.CLIENT_NU       = Cont.CONTRDOS_CLIENT_NU
      And Inter.DOSSIER_NU      = Cont.CONTRDOS_DOSSIER_NU
      And Inter.DATE_SAISIE_TS  > Cont.CONTRDOS_DT_DEB
Where
  (1=1)
  And Inter.CONTRCT_DT_SIGN_PREC Is Null
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Cont.CONTRDOS_DT_DEB desc)=1

--Calcul des attributs sur le nouveau contrat
;Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_NEW
(
  ACTE_ID                   ,
  CONTRCT_DT_SIGN_POST      ,
  CONTRCT_DUREE_ENG         ,
  CONTRCT_UNIT_ENG          
)
Select
  Inter.ACTE_ID                     as ACTE_ID              ,
  Cont.CONTRDOS_DT_DEB              as CONTRCT_DT_SIGN_POST ,
  Cont.CONTRDOS_NB_DUR_CONTRAT      as CONTRCT_DUREE_ENG    ,
  Cont.CONTRDOS_CO_UNIT_CONTRAT     as CONTRCT_UNIT_ENG     
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Inter
  Inner Join ${KNB_IBU_SOC_V}.VF_THCONTRDOS Cont
    On    Inter.CLIENT_NU       = Cont.CONTRDOS_CLIENT_NU
      And Inter.DOSSIER_NU      = Cont.CONTRDOS_DOSSIER_NU
      And Cont.CONTRDOS_DT_DEB  >= Inter.DATE_SAISIE_TS
      And Cont.CONTRDOS_DT_DEB  <= (Inter.DATE_SAISIE_TS + interval '45' day)
Where
  (1=1)
  And Inter.CONTRCT_DT_SIGN_PREC Is Null
Qualify Row_Number() Over (Partition by Inter.ACTE_ID Order by Cont.CONTRDOS_DT_DEB asc, Cont.CONTRDOS_NB_DUR_CONTRAT desc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_OLD;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_NEW;
.if errorcode <> 0 then .quit 1


.quit 0
