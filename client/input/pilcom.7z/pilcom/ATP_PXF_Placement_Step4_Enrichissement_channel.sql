--$HEADER: %HEADERS%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PXF_Placement_Step4_Enrichissement_channel.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Enrichissement Canal Macro
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/12/2020      EVI         Creation
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                           ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_CHANNEL All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_CHANNEL
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  ORG_CHANNEL_CD             ,
  ORG_SUB_CHANNEL_CD         ,
  ORG_SUB_SUB_CHANNEL_CD     ,
  ORG_REM_CHANNEL_CD         ,
  ORG_GT_ACTIVITY            ,
  ORG_WEB_ACTIVITY           ,
  ORG_AUTO_ACTIVITY          ,
  UNIFIED_SHOP_CD              
)

Select
  PXF.ACTE_ID                                                        As ACTE_ID                ,
  PXF.ORDER_DEPOSIT_DT                                               As ORDER_DEPOSIT_DT       ,
  -- Canal  
  Case   
    When RefEDO.FLAG_PLT_AD       = 1  
      Or RefEDO.FLAG_TYPE_PTN_NTK = 'GDT'  
      Then 'Dist'  
    Else 'NON PARAM'  
  End                                                                As ORG_CHANNEL_CD_AGR     ,
  --Sous Canal  
  Case    
    When ORG_CHANNEL_CD_AGR ='Dist' Then  
      Case   
        When RefEDO.NETWRK_TYP_EDO_ID = 'FT'  
          Then 'AD'  
        When RefEDO.NETWRK_TYP_EDO_ID = 'RP'   
          Then 'RP'  
        When RefEDO.NETWRK_TYP_EDO_ID = 'RC'  
          Then 'RC'  
        Else 'NON PARAM'  
      End   
    Else 'NON PARAM'  
  End                                                                As ORG_SUB_CHANNEL_CD_AGR ,
  --Sous Sous Canal   
  Case When RefEDO.FLAG_TYPE_GEO Is Not Null  
          Then 'Dom'  
       Else 'Metropole'  
  End                                                                As ORG_SUB_SUB_CHANNEL_CD ,
  --Canal de Rem  
  Case When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'AD'
       Else 'Exclus'
  End                                                                As ORG_REM_CHANNEL_CD     ,
  -- GT/Activite
  Case When RefEDO.FLAG_TYPE_PTN_NTK = 'GDT'
          Then 'GDT'
        Else 'Boutique FT'
  End                                                                As ORG_GT_ACTIVITY      ,
  'NON'                                                              As ORG_WEB_ACTIVITY     ,
  'NON'                                                              As ORG_AUTO_ACTIVITY    ,
   EdoLnk.EXTNL_VAL_COD_CD                                           As UNIFIED_SHOP_CD
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_EXTR PXF
  Left Outer Join  ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK EdoLnk
    On  PXF.EXTRNL_EDO_ID    =   EdoLnk.EDO_ID
    And PXF.ORDER_DEPOSIT_DT >=  EdoLnk.START_EXTNL_VAL_DT
    And PXF.ORDER_DEPOSIT_DT <   EdoLnk.END_EXTNL_VAL_DT
    And EdoLnk.EXTNL_COD_CD  = 'ADV'  
  Left Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    PXF.EXTRNL_EDO_ID = RefEDO.EDO_ID
    And   PXF.ORDER_DEPOSIT_DT  Between RefEDO.START_EXTNL_VAL_DT And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))  
Where
  (1=1)
  And PXF.EXTRNL_EDO_ID IS NOT NULL
Qualify Row_number() over (Partition by PXF.ACTE_ID,PXF.ORDER_DEPOSIT_DT Order By RefEDO.EDO_ID Asc, Case When EdoLnk.ROL_LINK_CD = 'HIR' Then 1 Else 2 End Asc ) = 1
;
.if errorcode <> 0 then .quit 1
Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_CHANNEL;
.if errorcode <> 0 then .quit 1

.quit 0




