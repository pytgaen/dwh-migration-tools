-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_Acte_Hot_Alimentation_PRP_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul des actes pour AGC PREPAID
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/04/2014      YZH         Creation
-- 13/10/2014      KBH         Modif QC #769
-- 06/07/2016      MDE         Modif : ORG_GT_ACTIVITY  tronqué
-- 12/12/2016      HOB         Modif : Ajout Champs VA
-- 19/12/2017      HOB         Modif IOBSP
-- 27/09/2019      EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF / ACT_UNITE_CD
-- 01/07/2020      JCR         Ajout colonne SIM_EAN_CD
--------------------------------------------------------------------------------

.set width 2500;

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_AGC_PRP_H All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_AGC_PRP_H
(
  -- Champs clés du flux
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  INTRNL_SOURCE_ID                  ,
  CONTEXT_ID                        ,
  EXTERNAL_ORDER_ID                 ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_TYPE_CD                     ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  INB_PRESFACT_ACQ_ADV              ,           
  INB_PRESFACT_ACQ_AGAP             ,
  SEG_PARC_DT_DEBUT                 ,
  INB_PARK_ID                       ,
  FLAG_HD                           ,
  ORG_CHANNEL_ID                    ,
  ORG_CHANNEL_CD                    ,
  ORG_SUB_CHANNEL_CD                ,
  ORG_SUB_SUB_CHANNEL_CD            ,
  ORG_REM_CHANNEL_CD                ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORIG_DEM                          ,
  CANALDEM_MTHD                     ,
  ORG_CHANNEL_ID_MACRO              ,
  ORG_CHANNEL_MACRO_LB              ,
  ORG_STORE_NAME                    ,
  ORG_FLAG_TYPE_PTN_NTK             ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_EDO_IOBSP                     ,
  ORG_AGENT_IOBSP                   ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  PAR_EXTERNAL_PARTY_FREG_ID        ,
  PAR_PARTY_KNB_FREG_ID             ,
  PAR_AID                           ,
  PAR_PARTY_KNB_BSS_ID              ,
  PAR_ND                            ,
  PAR_ACCES_SERVICE                 ,
  PAR_ADV_CLIENT_NU                 ,
  PAR_ADV_DOSSIER_NU                ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  OTO_OSCAR_VALUE_NU                ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_SIRET                         ,
  PAR_MARKET_SEG                    ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_CD_POSTAL                ,
  PAR_DO                            ,
  PAR_BU_CD                         ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  PAR_MOB_IMEI                      ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  SIM_EAN_CD                        ,
  PAR_MOB_IMSI                      ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  CONTRCT_DT_SIGN_PREC_MOB          ,
  CONTRCT_DT_FIN_PREC_MOB           ,
  CONTRCT_DT_SIGN_POST_MOB          ,
  CONTRCT_DUREE_ENG_MOB             ,
  CONTRCT_UNIT_ENG_MOB              ,
  CONFIRMATION_IN                   ,
  CONFIRMATION_DT                   ,
  CONFIRMATION_CALC_FIN_DT          ,
  DELIVERY_IN                       ,
  DELIVERY_DT                       ,
  DELIVERY_CALC_FIN_DT              ,
  DELIVERY_ONTIME_IN                ,
  DELIVERY_DEAD_LINE_NU             ,
  PERNNT_IN                         ,
  PERNNT_END_DT                     ,
  PERNNT_CALC_END_DT                ,  
  SEG_PRES_PARC_COMMANDE            ,
  CONCURENCE_IN                     ,
  CONCURENCE_CONCLU_IN              ,
  CONCURENCE_ID                     ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                         as ACTE_ID                            ,
  Placement.ACTE_ID                                         as ACTE_ID_GEN                        ,
  Placement.INTRNL_SOURCE_ID                                as INTRNL_SOURCE_ID                   ,
  Placement.CONTEXT_ID                                      as CONTEXT_ID                         ,
  Placement.EXTERNAL_ORDER_ID                               as EXTERNAL_ORDER_ID                  ,
  Placement.ORDER_DEPOSIT_TS                                as ORDER_DEPOSIT_TS                   ,
  Placement.ORDER_DEPOSIT_DT                                as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_TYPE_CD                                   as ORDER_TYPE_CD                      ,
  Null                                                      as ACT_PRODUCT_ID_PRE                 ,
  Null                                                      as ACT_SEG_COM_ID_PRE                 ,
  Null                                                      as ACT_SEG_COM_AGG_ID_PRE             ,
  Null                                                      as ACT_CODE_MIGR_PRE                  ,
  ActeAGC.TYPE_MVT_PRE                                      as ACT_OPER_ID_PRE                    ,
  ActeAGC.PRODUCT_ID_FINAL                                  as ACT_PRODUCT_ID_FINAL               ,
  ActeAGC.SEG_COM_ID_FINAL                                  as ACT_SEG_COM_ID_FINAL               ,
  ActeAGC.SEG_COM_AGG_ID_FINAL                              as ACT_SEG_COM_AGG_ID_FINAL           ,
  Null                                                      as ACT_CODE_MIGR_FINAL                ,
  ActeAGC.TYPE_MVT_FINAL                                    as ACT_OPER_ID_FINAL                  ,
  ActeAGC.TYPE_SERVICE_FINAL                                as ACT_TYPE_SERVICE_FINAL             ,
  ActeAGC.TYPE_COMMANDE_ID                                  as ACT_TYPE_COMMANDE_ID               ,
  Case
    -- Unite = CA  
    When Mat.UNITE_CD ='${P_PIL_490}' 
         Then   Null
    -- Unite = NB  
    When Mat.UNITE_CD ='${P_PIL_620}' 
         Then   ActeAGC.DELTA_TARIF
    -- Unite = MKT
    When Mat.UNITE_CD ='${P_PIL_623}' 
         Then   Mat.CA_MARKETING
    -- Unite = CA_CALIPSO (TMX)  
    When Mat.UNITE_CD ='${P_PIL_622}' 
         Then 0 
    Else Null
  END                                                       as ACT_DELTA_TARIF                    ,         
  Mat.UNITE_CD                                              as ACT_UNITE_CD                       ,
  Case  When Mat.ACTE_ID Is Not Null
          Then  Mat.ACTE_ID
        When ActeAGC.PERIODE_ID  = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit PlacÃ© est un produit inconnu de RefCom
        When  ActeAGC.PRODUCT_ID_FINAL  = '${P_PIL_223}'
          Then  '${P_PIL_224}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        When ActeAGC.SEG_COM_ID_FINAL in ('NS')
          Then  '${P_PIL_221}'
        Else '${P_PIL_220}'
  End                                                       as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID,'${P_PIL_067}')                  as ACT_REM_ID                         ,
  Coalesce(Mat.FLAG_ACT_REM,'N')                            as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC,'N')                         as ACT_FLAG_PEC_PERPVC                ,
  Case
    -- Unite = CA  
    When Mat.UNITE_CD ='${P_PIL_490}' 
         Then   Null
    -- Unite = NB  
    When Mat.UNITE_CD ='${P_PIL_620}' 
         Then   Coalesce(Mat.ACTE_VALO, 0)
    -- Unite = MKT
    When Mat.UNITE_CD ='${P_PIL_623}' 
         Then   ( ACT_DELTA_TARIF * Mat.TAUX_MARGE )
    -- Unite = CA_CALIPSO (TMX)  
    When Mat.UNITE_CD ='${P_PIL_622}' 
         Then 0
    Else Null
  END                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Mat.ACTE_FAMILLE_KPI,'NON PARAM')                as ACT_ACTE_FAMILLE_KPI               ,
  ActeAGC.PERIODE_ID                                        as ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                  as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            as ACT_PERIODE_CLOSURE_DT             ,
  Null                                                      as INB_PRESFACT_ACQ_ADV               ,
  Null                                                      as INB_PRESFACT_ACQ_AGAP              ,
  Null                                                      as SEG_PARC_DT_DEBUT                  ,
  Null                                                      as INB_PARK_ID                        ,
  Mat.HUMAINDIGITAL                                         as FLAG_HD                            ,
  Null                                                      as ORG_CHANNEL_ID                     ,
  --Calcul du canal de vente Macro
  'Dist'                                                    as ORG_CHANNEL_CD                     ,
  --Sous Canal
  Case When Placement.NETWRK_TYP_EDO_ID = 'FT'
       Then 'AD'
       When Placement.NETWRK_TYP_EDO_ID <> 'FT'
            And Placement.FLAG_TYPE_CPT_NTK Is Not Null 
       Then 'RC'
       When Placement.NETWRK_TYP_EDO_ID <> 'FT'
            And Placement.FLAG_TYPE_PTN_NTK Is Not Null 
       Then 'RP'       
  End                                                       as ORG_SUB_CHANNEL_CD                 ,
  --Sous Sous Canal
  Case  When ORG_SUB_CHANNEL_CD='RC' and Placement.FLAG_TYPE_CPT_NTK ='AUT'
        Then 'AUTRC'
       When ORG_SUB_CHANNEL_CD='RC' and Placement.FLAG_TYPE_CPT_NTK ='GRO'
        Then 'GROSS'
       When ORG_SUB_CHANNEL_CD='RC'
        Then Placement.FLAG_TYPE_CPT_NTK
       When 
        ( Placement.NETWRK_TYP_EDO_ID = 'FT' or ORG_SUB_CHANNEL_CD in ('AD', 'RP') )
        And FLAG_TYPE_GEO is Not NULL            
       Then 'DOM'
       Else 'Metropole'
  End                                                       as ORG_SUB_SUB_CHANNEL_CD             ,
  -- Canle Rem
  Case When Placement.NETWRK_TYP_EDO_ID = 'FT'
       Then 'AD'  
       Else 'Exclus'
  End                                                       as ORG_REM_CHANNEL_CD                 ,
  --ActivitÃ©
  Case When  ORG_SUB_CHANNEL_CD='AD'
       Then 'Boutique FT'     
       When  ORG_SUB_CHANNEL_CD='RC'
       Then  'Reseau Concurrent'              
       When  Placement.FLAG_TYPE_PTN_NTK is not Null
       Then  Placement.FLAG_TYPE_PTN_NTK        
  End                                                       as ORG_GT_ACTIVITY                    ,
  --Fidelisaion     
   'NONPARAM'                                               as ORG_FIDELISATION                   ,
  --ActivitÃ© Web
   'NON'                                                    as ORG_WEB_ACTIVITY                   ,
  --ActivitÃ© Automatique                              
   'NON'                                                    as ORG_AUTO_ACTIVITY                  ,
  Null                                                      as ORIG_DEM                           ,
  Null                                                      as CANALDEM_MTHD                      ,
  Null                                                      as ORG_CHANNEL_ID_MACRO               ,
  Null                                                      as ORG_CHANNEL_MACRO_LB               ,
  Placement.ADV_STORE_CD                                    as ORG_STORE_NAME                     ,
  Placement.FLAG_TYPE_PTN_NTK                               as ORG_FLAG_TYPE_PTN_NTK              ,
  Placement.EDO_ID                                          as ORG_EDO_ID                         ,
  Placement.TYPE_EDO                                        as ORG_TYPE_EDO                       ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                      ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                    ,
  Placement.FLAG_PLT_CONV                                   as ORG_FLAG_PLT_CONV                  ,
  Placement.FLAG_TEAM_MKT                                   as ORG_FLAG_TEAM_MKT                  ,
  Placement.FLAG_TYPE_CMP                                   as ORG_FLAG_TYPE_CMP                  ,
  Placement.NETWRK_TYP_EDO_ID                               as ORG_NETWRK_TYP_EDO_ID              ,
  Placement.FLAG_TYPE_GEO                                   as ORG_FLAG_TYPE_GEO                  ,
  Placement.FLAG_TYPE_CPT_NTK                               as ORG_FLAG_TYPE_CPT_NTK              ,              
  Null                                                      as ORG_REF_TRAV                       ,
  Placement.AGENT_ID                                        as ORG_AGENT_ID                       ,
  Null                                                      as ORG_POC_XI                         ,
  Placement.AGENT_ID                                        as ORG_AGENT_ID_UPD                   ,
  Null                                                      as ORG_AGENT_ID_UPD_DT                ,
  Placement.AGENT_LAST_NAME_NM                              as ORG_NOM                            ,
  Placement.AGENT_FIRST_NAME_NM                             as ORG_PRENOM                         ,
  Null                                                      as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitÃ©e
  Null                                                      as ORG_ACTVT_REEL                     ,
  Null                                                      as ORG_RESP_REF_TRAV                  ,
  Null                                                      as ORG_RESP_AGENT_ID                  ,
  Null                                                      as ORG_RESP_XI                        ,
  Null                                                      as PAR_EXTERNAL_PARTY_FREG_ID         ,
  Null                                                      as PAR_PARTY_KNB_FREG_ID              ,
  Null                                                      as PAR_AID                            ,
  Null                                                      as PAR_PARTY_KNB_BSS_ID               ,
  Null                                                      as PAR_ND                             ,
  Null                                                      as PAR_ACCES_SERVICE                  ,
  Placement.CUSTOMER_CLIENT_NU_ADV                          as PAR_ADV_CLIENT_NU                  ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                         as PAR_ADV_DOSSIER_NU                 ,
  Null                                                      as DMC_LINE_ID                        ,
  Null                                                      as DMC_MASTER_LINE_ID                 ,
  Null                                                      as PAR_GEO_MACROZONE                  ,
  Null                                                      as PAR_UNIFIED_PARTY_ID               ,
  Null                                                      as PAR_PARTY_REGRPMNT_ID              ,
  Placement.CUSTOMER_CATEGORIE                              as OTO_OSCAR_VALUE_NU                 ,
  Placement.CUSTOMER_LAST_NAME_NM                           as PAR_LASTNAME                       ,
  Placement.CUSTOMER_FIRST_NAME_NM                          as PAR_FIRSTNAME                      ,
  Placement.CUSTOMER_SIRET                                  as PAR_SIRET                          ,
  Placement.CUSTOMER_MARKET_SEG                             as PAR_MARKET_SEG                     ,
  Null                                                      as PAR_TYPE                           ,
  Null                                                      as PAR_EMAIL                          ,
  CUSTOMER_ADDRESS_1_NM                                     as PAR_BILL_ADRESS_1                  ,
  CUSTOMER_ADDRESS_2_NM                                     as PAR_BILL_ADRESS_2                  ,
  CUSTOMER_ADDRESS_3_NM                                     as PAR_BILL_ADRESS_3                  ,
  Placement.CUSTOMER_CITY                                   as PAR_BILL_ADRESS_4                  ,
  Placement.CUSTOMER_ADDRESS_POSTAL_CD                      as PAR_BILL_CD_POSTAL                 ,
  --Pour les domtom : 3 premiers
  Case  When    Substring(Trim(Placement.CUSTOMER_ADDRESS_POSTAL_CD) From 1 For 3) In (${L_PIL_034})
        Then    Substring(Trim(Placement.CUSTOMER_ADDRESS_POSTAL_CD) From 1 For 3)
        When    Placement.CUSTOMER_ADDRESS_POSTAL_CD Is not Null
        Then    Substring(Trim(Placement.CUSTOMER_ADDRESS_POSTAL_CD) From 1 For 2)
        Else    Null
  End                                                       as PAR_DO                             ,
  Null                                                      as PAR_BU_CD                          ,
  Null                                                      as PAR_USCM                           ,
  Null                                                      as PAR_USCM_DS                        ,
  Null                                                      as PAR_USCM_USCM_DS                   ,
  Null                                                      as PAR_USCM_REGUSCM                   ,
  Null                                                      as PAR_USCM_REGUSCM_DS                ,
  Placement.PAR_IMEI_CD                                     as PAR_MOB_IMEI                       ,
  Null                                                      as PAR_MOB_TAC                        ,
  Placement.PAR_SIM_CD                                      as PAR_MOB_SIM                        ,
  Placement.SIM_EAN_CD                                      as SIM_EAN_CD                         ,
  Null                                                      as PAR_MOB_IMSI                       ,
  Null                                                      as PAR_SCORE_NU_MOB                   ,
  Null                                                      as PAR_SCORE_IN_MOB                   ,
  Null                                                      as PAR_TRESHOLD_NU_MOB                ,
  Null                                                      as CONTRCT_DT_SIGN_PREC_MOB           ,
  Null                                                      as CONTRCT_DT_FIN_PREC_MOB            ,
  Null                                                      as CONTRCT_DT_SIGN_POST_MOB           ,
  Null                                                      as CONTRCT_DUREE_ENG_MOB              ,
  Null                                                      as CONTRCT_UNIT_ENG_MOB               ,
  Null                                                      as CONFIRMATION_IN                    ,
  Null                                                      as CONFIRMATION_DT                    ,
  Null                                                      as CONFIRMATION_CALC_FIN_DT           ,
  Null                                                      as DELIVERY_IN                        ,
  Null                                                      as DELIVERY_DT                        ,
  Null                                                      as DELIVERY_CALC_FIN_DT               ,
  Null                                                      as DELIVERY_ONTIME_IN                 ,
  Null                                                      as DELIVERY_DEAD_LINE_NU              ,
  Null                                                      as PERNNT_IN                          ,
  Null                                                      as PERNNT_END_DT                      ,
  Null                                                      as PERNNT_CALC_END_DT                 ,
  Null                                                      as SEG_PRES_PARC_COMMANDE             ,
  Null                                                      as CONCURENCE_IN                      ,
  Null                                                      as CONCURENCE_CONCLU_IN               ,
  Null                                                      as CONCURENCE_ID                      ,
  
  Null                                                      as CHECK_INITIAL_STATUS_CD            ,
  Null                                                      as CHECK_NAT_STATUS_CD                ,
  Null                                                      as CHECK_NAT_COMMENT                  ,
  Null                                                      as CHECK_NAT_STATUS_LN                ,
  Null                                                      as CHECK_LOC_STATUS_CD                ,
  Null                                                      as CHECK_LOC_COMMENT                  ,
  Null                                                      as CHECK_LOC_STATUS_LN                ,
  Null                                                      as CHECK_VALIDT_DT                    ,
  Placement.CLOSURE_DT                                      as CLOSURE_DT                         ,
  Placement.QUEUE_TS                                        as QUEUE_TS                           ,
  Placement.RUN_ID                                          as RUN_ID                             ,
  Placement.STREAMING_TS                                    as STREAMING_TS                       ,
  Current_timestamp(0)                                      as CREATION_TS                        ,
  Current_timestamp(0)                                      as LAST_MODIF_TS                      ,
  1                                                         as HOT_IN                             ,
  1                                                         as FRESH_IN                           ,
  0                                                         as COHERENCE_IN                       
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_AGC_PRP_H Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_AGC_PRP_CALC ActeAGC
    On    Placement.ACTE_ID                                = ActeAGC.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT                       = ActeAGC.ORDER_DEPOSIT_DT 
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat
      On  ActeAGC.TYPE_COMMANDE_ID                         = Mat.TYPE_COMMANDE_ID 
      And ActeAGC.SEG_COM_ID_FINAL                         = Mat.SEG_COM_ID_FINAL
      And ActeAGC.PERIODE_ID                               = Mat.PERIODE_ID
      And Coalesce(ActeAGC.SEG_COM_ID_PRE,'${P_PIL_211}')  = Mat.SEG_COM_ID_INI
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
      On  ActeAGC.PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                           = 1
      And EtatPeriode.FRESH_IN                             = 1
      And EtatPeriode.CLOSURE_DT                           Is Null    
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_AGC_PRP_H;
.if errorcode <> 0 then .quit 1

