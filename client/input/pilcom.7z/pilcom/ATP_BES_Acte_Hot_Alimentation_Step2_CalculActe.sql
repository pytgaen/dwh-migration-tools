-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Acte_Hot_Alimentation_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 24/03/2014      HZO         Modification
-- 30/06/2014      YZH         Modification (Distrib -> Dist)
-- 11/08/2014      HZO         Indus + Modification
-- 22/09/2015      MDE         Modif/Evol Enrichissement client
-- 13/01/2016      MDE         Modif/Evol Calcul CA
-- 09/12/2016      HOB         Modif VA
-- 26/04/2017      JCR         Ajout Coalesce pour le delta tarif pour filtrage des ventes avec CA=0.
-- 16/05/2017      HLA         Modif Pilotage Terminaux
-- 21/06/2017      HOB         Terminaux Nus en AD 
-- 03/07/2017      JCR         Modif du CA : pas de CA TTC si le CA HT est null 
-- 21/11/2017      HOB         Alimentation Champs IOBSP
-- 09/09/2019      EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF
-- 14/04/2020      EVI         PILCOM-407 : KPI2020 Lot 2 - Alimentation ACT_DELTA_TARIF / ACT_CA_TTC_AM
-- 22/03/2021      EVI         PILCOM-870 : Gestion CA Terminaux CARAIBES
--------------------------------------------------------------------------------

.set width 2500;

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_BESTAR_H All;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_BESTAR_H
(
  ACTE_ID                           ,
  ACTE_ID_GEN                       ,
  ACTE_ID_CMD_RAPPROCHEE            ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  ORDER_EXTERNAL_ID                 ,
  INTRNL_SOURCE_ID                  ,
  ACT_PRODUCT_ID_PRE                ,
  ACT_PRODUCT_DS_PRE                ,
  ACT_SEG_COM_ID_PRE                ,
  ACT_CODE_MIGR_PRE                 ,
  ACT_SEG_COM_AGG_ID_PRE            ,
  ACT_OPER_ID_PRE                   ,
  ACT_PRODUCT_ID_FINAL              ,
  ACT_PRODUCT_DS_FINAL              ,
  ACT_SEG_COM_ID_FINAL              ,
  ACT_SEG_COM_AGG_ID_FINAL          ,
  ACT_CODE_MIGR_FINAL               ,
  ACT_OPER_ID_FINAL                 ,
  ACT_TYPE_SERVICE_FINAL            ,
  ACT_TYPE_COMMANDE_ID              ,
  ACT_DELTA_TARIF                   ,
  ACT_UNITE_CD                      ,
  ACT_CD                            ,
  ACT_REM_ID                        ,
  ACT_FLAG_ACT_REM                  ,
  ACT_FLAG_PEC_PERPVC               ,
  ACT_ACTE_VALO                     ,
  ACT_ACTE_FAMILLE_KPI              ,
  ACT_PERIODE_ID                    ,
  ACT_PERIODE_STATUS                ,
  ACT_PERIODE_CLOSURE_DT            ,
  FLAG_HD                           ,
  ORG_CHANNEL_CD                    ,
  ORG_SUB_CHANNEL_CD                ,
  ORG_SUB_SUB_CHANNEL_CD            ,
  ORG_REM_CHANNEL_CD                ,
  ORG_GT_ACTIVITY                   ,
  ORG_FIDELISATION                  ,
  ORG_WEB_ACTIVITY                  ,
  ORG_AUTO_ACTIVITY                 ,
  ORG_EDO_ID                        ,
  ORG_TYPE_EDO                      ,
  ORG_EDO_IOBSP                     ,
  ORG_NETWRK_TYP_EDO_ID             ,
  ORG_FLAG_PLT_CONV                 ,
  ORG_FLAG_TEAM_MKT                 ,
  ORG_FLAG_TYPE_CMP                 ,
  ORG_FLAG_TYPE_GEO                 ,
  ORG_FLAG_TYPE_CPT_NTK             ,
  ORG_REF_TRAV                      ,
  ORG_AGENT_ID                      ,
  ORG_POC_XI                        ,
  ORG_AGENT_ID_UPD                  ,
  ORG_AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP                   ,
  ORG_NOM                           ,
  ORG_PRENOM                        ,
  ORG_GROUPE_ID                     ,
  ORG_ACTVT_REEL                    ,
  ORG_RESP_REF_TRAV                 ,
  ORG_RESP_AGENT_ID                 ,
  ORG_RESP_XI                       ,
  ORG_TYPE_CD                       ,
  ORG_TEAM_LEVEL_1_CD               ,
  ORG_TEAM_LEVEL_1_DS               ,
  ORG_TEAM_LEVEL_2_CD               ,
  ORG_TEAM_LEVEL_2_DS               ,
  ORG_TEAM_LEVEL_3_CD               ,
  ORG_TEAM_LEVEL_3_DS               ,
  ORG_TEAM_LEVEL_4_CD               ,
  ORG_TEAM_LEVEL_4_DS               ,
  WORK_TEAM_LEVEL_1_CD              ,
  WORK_TEAM_LEVEL_1_DS              ,
  WORK_TEAM_LEVEL_2_CD              ,
  WORK_TEAM_LEVEL_2_DS              ,
  WORK_TEAM_LEVEL_3_CD              ,
  WORK_TEAM_LEVEL_3_DS              ,
  WORK_TEAM_LEVEL_4_CD              ,
  WORK_TEAM_LEVEL_4_DS              ,
  CHECK_INITIAL_STATUS_CD           ,
  CHECK_NAT_STATUS_CD               ,
  CHECK_NAT_COMMENT                 ,
  CHECK_NAT_STATUS_LN               ,
  CHECK_LOC_STATUS_CD               ,
  CHECK_LOC_COMMENT                 ,
  CHECK_LOC_STATUS_LN               ,
  CHECK_VALIDT_DT                   ,
  CLIENT_NU                         ,
  DOSSIER_NU                        ,
  PAR_IMSI                          ,
  PAR_AID                           ,
  PAR_ND                            ,
  PAR_LASTNAME                      ,
  PAR_FIRSTNAME                     ,
  PAR_TYPE                          ,
  PAR_EMAIL                         ,
  PAR_INSEE_CD                      ,
  PAR_BILL_ADRESS_1                 ,
  PAR_BILL_ADRESS_2                 ,
  PAR_BILL_ADRESS_3                 ,
  PAR_BILL_ADRESS_4                 ,
  PAR_BILL_VILLE                    ,
  PAR_BILL_CD_POSTAL                ,
  PAR_DO                            ,
  PAR_SCORE_NU_MOB                  ,
  PAR_SCORE_IN_MOB                  ,
  PAR_TRESHOLD_NU_MOB               ,
  PAR_MOB_TAC                       ,
  PAR_MOB_SIM                       ,
  ACT_CA_LINE_AM                    ,
  ACT_CA_TTC_AM                     ,
  CODE_EAN                          ,
  PAR_MOB_IMEI                      ,
  ACT_PRESFACT_CO_PRE               ,
  DMC_LINE_ID                       ,
  DMC_MASTER_LINE_ID                ,
  PAR_DEPARTMNT_ID                  ,
  PAR_BU_CD                         ,
  PAR_POSTAL_CD                     ,
  CONTRCT_DT_SIGN_PREC              ,
  CONTRCT_DT_FIN_PREC               ,
  CONTRCT_DT_SIGN_POST              ,
  CONTRCT_DUREE_ENG                 ,
  CONTRCT_UNIT_ENG                  ,
  PAR_USCM                          ,
  PAR_USCM_DS                       ,
  PAR_USCM_USCM_DS                  ,
  PAR_USCM_REGUSCM                  ,
  PAR_USCM_REGUSCM_DS               ,
  PAR_GEO_MACROZONE                 ,
  PAR_UNIFIED_PARTY_ID              ,
  PAR_PARTY_REGRPMNT_ID             ,
  PAR_IRIS2000_CD                   ,
  PAR_FIBER_IN                      ,
  CLOSURE_DT                        ,
  QUEUE_TS                          ,
  RUN_ID                            ,
  STREAMING_TS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  HOT_IN                            ,
  FRESH_IN                          ,
  COHERENCE_IN                      
)
Select
  Placement.ACTE_ID                                         as ACTE_ID                            ,
  Placement.ACTE_ID                                         as ACTE_ID_GEN                        ,
  Acte.ACTE_ID_CMD_RAPPROCHEE                               as ACTE_ID_CMD_RAPPROCHEE             ,
  Placement.ORDER_DEPOSIT_DT                                as ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                as ORDER_DEPOSIT_TS                   ,
  Placement.ID_PANIER                                       as ORDER_EXTERNAL_ID                  ,
  Placement.INTRNL_SOURCE_ID                                as INTRNL_SOURCE_ID                   ,
  Acte.PRODUCT_ID_PRE                                       as ACT_PRODUCT_ID_PRE                 ,
  Acte.PRODUCT_DS_PRE                                       as ACT_PRODUCT_DS_PRE                 ,
  Acte.SEG_COM_ID_PRE                                       as ACT_SEG_COM_ID_PRE                 ,
  Acte.SEG_COM_AGG_ID_PRE                                   as ACT_SEG_COM_AGG_ID_PRE             ,
  Acte.CODE_MIGR_PRE                                        as ACT_CODE_MIGR_PRE                  ,
  Acte.TYPE_MVT_PRE                                         as ACT_OPER_ID_PRE                    ,
  Acte.PRODUCT_ID_FINAL                                     as ACT_PRODUCT_ID_FINAL               ,
  Acte.PRODUCT_DS_FINAL                                     as ACT_PRODUCT_DS_FINAL               ,
  Acte.SEG_COM_ID_FINAL                                     as ACT_SEG_COM_ID_FINAL               ,
  Acte.SEG_COM_AGG_ID_FINAL                                 as ACT_SEG_COM_AGG_ID_FINAL           ,
  Acte.CODE_MIGR_FINAL                                      as ACT_CODE_MIGR_FINAL                ,
  Acte.TYPE_MVT_FINAL                                       as ACT_OPER_ID_FINAL                  ,
  Acte.TYPE_SERVICE_FINAL                                   as ACT_TYPE_SERVICE_FINAL             ,
  Coalesce(Mat.TYPE_COMMANDE_ID, '${P_PIL_026}')            as ACT_TYPE_COMMANDE_ID               ,
  -- KPI2020
  Case
    -- Unité = CA  
    When Mat.UNITE_CD ='${P_PIL_490}' 
         Then   Coalesce(Acte.TERMINAL_PRICE_HT, 0)
    -- Unité = NB  
    When Mat.UNITE_CD ='${P_PIL_620}' Then
         Case 
           When Mat.ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
         Then 
            Case When Placement.FLAG_TYPE_GEO = 'CARAIBES'
               Then Coalesce(Acte.TERMINAL_PRICE_HT, 0)
               Else Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)
            End
           Else Null
         End
    -- Unité = MKT  
    When Mat.UNITE_CD ='${P_PIL_623}' 
         Then   Coalesce(Mat.CA_MARKETING, 0)
    -- Unité = CA_CALIPSO  
    When Mat.UNITE_CD ='${P_PIL_622}' 
         Then   Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)
    Else Null
  End                                                       as ACT_DELTA_TARIF_AGR                  ,
  Mat.UNITE_CD                                              as ACT_UNITE_CD                         ,
  Case
        When  Mat.ACTE_ID Is Not Null
          Then  Mat.ACTE_ID
        --Cas de rejet sur les périodes: -> ERR_ACTE_INCO_PERIODE_ID_INCO
        When  Acte.PERIODE_ID         = ${P_PIL_049}
          Then  '${P_PIL_217}'
        --Si le produit Placé est un produit inconnu de RefCom
        When  Acte.PRODUCT_ID_FINAL   = '${P_PIL_021}'
          Then '${P_PIL_224}'
        When Acte.SEG_COM_ID_FINAL    in ('NS')
          Then  '${P_PIL_221}'
        -- Si le segment est non Suivi alors on sort avec un code Acte Non Suivi : WAR_ACTE_NON_SUIVI
        --Sinon c'est un problème dans la matrice -> ERR_ACTE_INCO_NON_DEFINI_MATRICE_REFCOM
        Else '${P_PIL_220}'
  End                                                       as ACT_CD                             ,
  Coalesce(Mat.ACTE_REM_ID,'${P_PIL_067}')                  as ACT_REM_ID                         ,
  Coalesce(Mat.FLAG_ACT_REM,'N')                            as ACT_FLAG_ACT_REM                   ,
  Coalesce(Mat.FLAG_PEC_PERPVC,'N')                         as ACT_FLAG_PEC_PERPVC                ,
  -- KPI2020
  Case
    --Unité = NB
    When Mat.UNITE_CD ='${P_PIL_620}'
       Then Mat.ACTE_VALO
    -- Unité = CA / MKT / CA_CALIPSO 
    When Mat.UNITE_CD IN('${P_PIL_490}', '${P_PIL_623}', '${P_PIL_622}') 
       Then ( ACT_DELTA_TARIF_AGR * Mat.TAUX_MARGE )
    Else Coalesce(Mat.ACTE_VALO,0)
  End                                                       as ACT_ACTE_VALO                      ,
  Coalesce(Mat.ACTE_FAMILLE_KPI,'NON PARAM')                as ACT_ACTE_FAMILLE_KPI               ,
  Acte.PERIODE_ID                                           as ACT_PERIODE_ID                     ,
  Coalesce(EtatPeriode.PERIODE_STATUS, 'O')                 as ACT_PERIODE_STATUS                 ,
  EtatPeriode.PERIODE_CLOSURE_DT                            as ACT_PERIODE_CLOSURE_DT             ,
  -- KPI2020
  Mat.HUMAINDIGITAL                                         as FLAG_HD                            ,
  --Calcul du canal de vente Macro
  'Dist'                                                    as ORG_CHANNEL_CD                     ,
  --Sous Canal
  Case
        When Placement.NETWRK_TYP_EDO_ID = 'FT'
          Then 'AD'
        Else 'NONPARAM'
  End                                                       as ORG_SUB_CHANNEL_CD                 ,
  --Sous-Sous-Canal
  Case
        When Placement.NETWRK_TYP_EDO_ID = 'FT'
          Then
            Case
              When Placement.FLAG_TYPE_GEO is not null
                Then 'DOM'
              Else 'Metropole'
            end
          Else
            'NONPARAM'
  End                                                       as ORG_SUB_SUB_CHANNEL_CD             ,
  --Canal de Rem
  Case
        When Placement.NETWRK_TYP_EDO_ID = 'FT'
          Then 'AD'
        Else 'NONPARAM'
  End                                                       as ORG_REM_CHANNEL_CD                 ,
  --Activité
  Case
        When Placement.NETWRK_TYP_EDO_ID = 'FT'
          Then 'Boutique FT'
        Else 'Exclus'
  End                                                       as ORG_GT_ACTIVITY                    ,
  --Fidelisaion
  'NONPARAM'                                                as ORG_FIDELISATION                   ,
  --Activité Web
  'NON'                                                     as ORG_WEB_ACTIVITY                   ,
  --Activité Automatique
  'NON'                                                     as ORG_AUTO_ACTIVITY                  ,
  Placement.EDO_ID                                          as ORG_EDO_ID                         ,
  Placement.TYPE_EDO                                        as ORG_TYPE_EDO                       ,
  Placement.ORG_EDO_IOBSP                                   as ORG_EDO_IOBSP                      ,
  Placement.NETWRK_TYP_EDO_ID                               as ORG_NETWRK_TYP_EDO_ID              ,
  Placement.FLAG_PLT_CONV                                   as ORG_FLAG_PLT_CONV                  ,
  Placement.FLAG_TEAM_MKT                                   as ORG_FLAG_TEAM_MKT                  ,
  Placement.FLAG_TYPE_CMP                                   as ORG_FLAG_TYPE_CMP                  ,
  Placement.FLAG_TYPE_GEO                                   as ORG_FLAG_TYPE_GEO                  ,
  Placement.FLAG_TYPE_CPT_NTK                               as ORG_FLAG_TYPE_CPT_NTK              ,
  Null                                                      as ORG_REF_TRAV                       ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.USER_ID)        as ORG_AGENT_ID                       ,
  Null                                                      as ORG_POC_XI                         ,
  Coalesce(Placement.ORG_AGENT_ID,Placement.USER_ID)        as ORG_AGENT_ID_UPD                   ,
  Null                                                      as ORG_AGENT_ID_UPD_DT                ,
  Placement.ORG_AGENT_IOBSP                                 as ORG_AGENT_IOBSP                    ,
  Placement.ORG_NOM                                         as ORG_NOM                            ,
  Placement.ORG_PRENOM                                      as ORG_PRENOM                         ,
  Null                                                      as ORG_GROUPE_ID                      ,
  -- Calcul de l'activitée
  Null                                                      as ORG_ACTVT_REEL                     ,
  Null                                                      as ORG_RESP_REF_TRAV                  ,
  Null                                                      as ORG_RESP_AGENT_ID                  ,
  Null                                                      as ORG_RESP_XI                        ,
  -- Calcul des EDO 
  Null                                                      as ORG_TYPE_CD                        ,
  Null                                                      as ORG_TEAM_LEVEL_1_CD                ,
  Null                                                      as ORG_TEAM_LEVEL_1_DS                ,
  Null                                                      as ORG_TEAM_LEVEL_2_CD                ,
  Null                                                      as ORG_TEAM_LEVEL_2_DS                ,
  Null                                                      as ORG_TEAM_LEVEL_3_CD                ,
  Null                                                      as ORG_TEAM_LEVEL_3_DS                ,
  Null                                                      as ORG_TEAM_LEVEL_4_CD                ,
  Null                                                      as ORG_TEAM_LEVEL_4_DS                ,
  Null                                                      as WORK_TEAM_LEVEL_1_CD               ,
  Null                                                      as WORK_TEAM_LEVEL_1_DS               ,
  Null                                                      as WORK_TEAM_LEVEL_2_CD               ,
  Null                                                      as WORK_TEAM_LEVEL_2_DS               ,
  Null                                                      as WORK_TEAM_LEVEL_3_CD               ,
  Null                                                      as WORK_TEAM_LEVEL_3_DS               ,
  Null                                                      as WORK_TEAM_LEVEL_4_CD               ,
  Null                                                      as WORK_TEAM_LEVEL_4_DS               ,
  Null                                                      as CHECK_INITIAL_STATUS_CD            ,
  Null                                                      as CHECK_NAT_STATUS_CD                ,
  Null                                                      as CHECK_NAT_COMMENT                  ,
  Null                                                      as CHECK_NAT_STATUS_LN                ,
  Null                                                      as CHECK_LOC_STATUS_CD                ,
  Null                                                      as CHECK_LOC_COMMENT                  ,
  Null                                                      as CHECK_LOC_STATUS_LN                ,
  Null                                                      as CHECK_VALIDT_DT                    ,
    --Evol
  Placement.CLIENT_NU                                       as CLIENT_NU                          ,
  Coalesce(Placement.DOSSIER_NU ,Placement.MSISDN_NU)       as DOSSIER_NU                         ,
  Placement.PAR_IMSI                                        as PAR_IMSI                           ,
  Placement.PAR_AID                                         as PAR_AID                            ,
  Placement.PAR_ND                                          as PAR_ND                             ,
  Placement.PAR_LASTNAME                                    as PAR_LASTNAME                       ,
  Placement.PAR_FIRSTNAME                                   as PAR_FIRSTNAME                      , 
  Placement.PAR_TYPE                                        as PAR_TYPE                           ,
  Placement.PAR_EMAIL                                       as PAR_EMAIL                          , 
  Placement.PAR_INSEE_CD                                    as PAR_INSEE_CD                       ,
  Placement.PAR_BILL_ADRESS_1                               as PAR_BILL_ADRESS_1                  ,
  Placement.PAR_BILL_ADRESS_2                               as PAR_BILL_ADRESS_2                  ,
  Placement.PAR_BILL_ADRESS_3                               as PAR_BILL_ADRESS_3                  ,
  Placement.PAR_BILL_ADRESS_4                               as PAR_BILL_ADRESS_4                  ,
  Placement.PAR_BILL_VILLE                                  as PAR_BILL_VILLE                     ,
  Placement.PAR_BILL_CD_POSTAL                              as PAR_BILL_CD_POSTAL                 ,
  Placement.PAR_DO                                          as PAR_DO                             ,
  Placement.PAR_SCORE_NU_MOB                                as PAR_SCORE_NU_MOB                   ,
  Placement.PAR_SCORE_IN_MOB                                as PAR_SCORE_IN_MOB                   ,
  Placement.PAR_TRESHOLD_NU_MOB                             as PAR_TRESHOLD_NU_MOB                ,
  Placement.PAR_MOB_TAC                                     as PAR_MOB_TAC                        ,
  Placement.PAR_MOB_SIM                                     as PAR_MOB_SIM                        ,
  Case
    -- Unité = CA  
    When Mat.UNITE_CD ='${P_PIL_490}' 
         Then   Coalesce(Acte.TERMINAL_PRICE_HT, 0)
    -- Unité = NB  
    When Mat.UNITE_CD ='${P_PIL_620}' Then
         Case 
           When Mat.ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
         Then 
            Case When Placement.FLAG_TYPE_GEO = 'CARAIBES'
               Then Coalesce(Acte.TERMINAL_PRICE_HT, 0)
               Else Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)
            End
           Else Coalesce(Acte.TERMINAL_PRICE_HT, 0)
         End
    -- Unité = MKT  
    When Mat.UNITE_CD ='${P_PIL_623}' 
         Then   Coalesce(Mat.CA_MARKETING, 0)
    -- Unité = CA_CALIPSO  
    When Mat.UNITE_CD ='${P_PIL_622}' 
         Then   Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)
    Else Null
  End                                                       as ACT_CA_LINE_AM                     ,
  Case
    -- Unité = CA  
    When Mat.UNITE_CD ='${P_PIL_490}' 
         Then   Coalesce(Acte.TERMINAL_PRICE, 0)
    -- Unité = NB  
    When Mat.UNITE_CD ='${P_PIL_620}' Then 
        Case 
          When Mat.ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
         Then 
            Case When Placement.FLAG_TYPE_GEO = 'CARAIBES'
               Then Coalesce(Acte.TERMINAL_PRICE, 0)
               Else Coalesce (EAN_Canal_WEB.PRICE_TTC, EAN_Canal_DOM.PRICE_TTC, 0)
            End
          Else Coalesce(Acte.TERMINAL_PRICE, 0)
        End   
    -- Unité = MKT 
    When Mat.UNITE_CD ='${P_PIL_623}' 
         Then   Null
    -- Unité = CA_CALIPSO  
    When Mat.UNITE_CD ='${P_PIL_622}' 
         Then   Coalesce (EAN_Canal_WEB.PRICE_TTC, EAN_Canal_DOM.PRICE_TTC, 0)
    Else Null
  End                                                       as ACT_CA_TTC_AM                      ,
  Acte.CODE_EAN                                             as CODE_EAN                           ,
  Placement.PAR_MOB_IMEI                                    as PAR_MOB_IMEI                       ,
  Placement.PRESFACT_CO_PRECED                              as ACT_PRESFACT_CO_PRE                ,
  Placement.DMC_LINE_ID                                     as DMC_LINE_ID                        ,
  Placement.DMC_MASTER_LINE_ID                              as DMC_MASTER_LINE_ID                 ,
  Placement.PAR_DEPARTMNT_ID                                as PAR_DEPARTMNT_ID                   ,
  Placement.PAR_BU_CD                                       as PAR_BU_CD                          ,
  Placement.PAR_POSTAL_CD                                   as PAR_POSTAL_CD                      ,
  Placement.CONTRCT_DT_SIGN_PREC                            as CONTRCT_DT_SIGN_PREC               ,
  Placement.CONTRCT_DT_FIN_PREC                             as CONTRCT_DT_FIN_PREC                ,
  Placement.CONTRCT_DT_SIGN_POST                            as CONTRCT_DT_SIGN_POST               ,
  Placement.CONTRCT_DUREE_ENG                               as CONTRCT_DUREE_ENG                  ,
  Placement.CONTRCT_UNIT_ENG                                as CONTRCT_UNIT_ENG                   ,
  Placement.PAR_USCM                                        as PAR_USCM                           ,
  Placement.PAR_USCM_DS                                     as PAR_USCM_DS                        ,
  Placement.PAR_USCM_USCM_DS                                as PAR_USCM_USCM_DS                   ,
  Placement.PAR_USCM_REGUSCM                                as PAR_USCM_REGUSCM                   ,
  Placement.PAR_USCM_REGUSCM_DS                             as PAR_USCM_REGUSCM_DS                ,
  Placement.PAR_GEO_MACROZONE                               AS PAR_GEO_MACROZONE                  ,
  Placement.PAR_UNIFIED_PARTY_ID                            AS PAR_UNIFIED_PARTY_ID               ,
  Placement.PAR_PARTY_REGRPMNT_ID                           AS PAR_PARTY_REGRPMNT_ID              ,
  Placement.PAR_IRIS2000_CD                                 as PAR_IRIS2000_CD                    ,
  Placement.PAR_FIBER_IN                                    as PAR_FIBER_IN                       ,
  --
  Null                                                      as CLOSURE_DT                         ,
  Null                                                      as QUEUE_TS                           ,
  Placement.RUN_ID                                          as RUN_ID                             ,
  Null                                                      as STREAMING_TS                       ,
  '${KNB_DATE_VACATION}'                                    as CREATION_TS                        ,
  '${KNB_DATE_VACATION}'                                    as LAST_MODIF_TS                      ,
  1                                                         as HOT_IN                             ,
  1                                                         as FRESH_IN                           ,
  0                                                         as COHERENCE_IN                       
From
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_BESTAR_H Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_BESTAR_H_CAL Acte
    On    Placement.ACTE_ID                       = Acte.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT              = Acte.ORDER_DEPOSIT_DT
    --Jointure récupérer les infos de la table des matrices
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE Mat
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On    Acte.TYPE_COMMANDE_ID                   = Mat.TYPE_COMMANDE_ID
      And '${P_PIL_211}'                          = Mat.SEG_COM_ID_INI
      And Acte.SEG_COM_ID_FINAL                   = Mat.SEG_COM_ID_FINAL
      And Acte.PERIODE_ID                         = Mat.PERIODE_ID
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
    On    Acte.PERIODE_ID                                   = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                               = 1
      And EtatPeriode.FRESH_IN                                 = 1
      And EtatPeriode.CLOSURE_DT                               Is Null
  -- KPI2020 : Jointure Referentiel CALIPSO
  Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB
     On EAN_Canal_WEB.EAN_CD = Acte.CODE_EAN
     And Acte.ORDER_DEPOSIT_DT Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM
     On  EAN_Canal_DOM.EAN_CD = Acte.CODE_EAN
     And Acte.ORDER_DEPOSIT_DT Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'
    
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_BESTAR_H;
.if errorcode <> 0 then .quit 1

