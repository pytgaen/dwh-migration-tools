-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_GEN_Alimentation_Ref_Orga_RFOR_Step0_Ext.sql $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 22/05/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table de travail                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_RFOR All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table de travail                                          ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_RFOR(
  SOURCE                    ,
  CUID                      ,
  NOM                       ,
  PRENOM                    ,
  DT_DEBUT                  ,
  DT_FIN                    ,
  RAT_ORGA_EQUI_CO_GRP      ,
  EDO_ID_EQUI_RAT           ,
  FLAG_SCH_EQUI_RAT         ,
  FLAG_HIER_EQUI_RAT        ,
  FLAG_PLT_CONV_EQUI_RAT    ,
  TRAV_ORGA_EQUI_CO_GRP     ,
  EDO_ID_EQUI_TRAV          ,
  FLAG_SCH_EQUI_TRAV        ,
  FLAG_HIER_EQUI_TRAV       ,
  FLAG_PLT_CONV_EQUI_TRAV   
)
Select
  SOURCE                                                                        As SOURCE                           ,
  CUID                                                                          As CUID                             ,
  NOM                                                                           As NOM                              ,
  PRENOM                                                                        As PRENOM                           ,
  DT_DEBUT                                                                      As DT_DEBUT                         ,
  Coalesce( Max((DT_DEBUT - Interval '1' second )) Over (
                                                Partition by CUID
                                                   Order by DT_DEBUT rows between 1  following and 1 following
                                              ) 
                                              , Cast('29991231000000' As Timestamp(0) Format 'YYYYMMDDHHMISS')   )
                                                                                As DT_FIN                           ,
  RAT_ORGA_EQUI_CO_GRP                                                          As RAT_ORGA_EQUI_CO_GRP             ,
  EDO_ID_EQUI_RAT                                                               As EDO_ID_EQUI_RAT                  ,
  FLAG_SCH_EQUI_RAT                                                             As FLAG_SCH_EQUI_RAT                ,
  FLAG_HIER_EQUI_RAT                                                            As FLAG_HIER_EQUI_RAT               ,
  FLAG_PLT_CONV_EQUI_RAT                                                        As FLAG_PLT_CONV_EQUI_RAT           ,
  TRAV_ORGA_EQUI_CO_GRP                                                         As TRAV_ORGA_EQUI_CO_GRP            ,
  EDO_ID_EQUI_TRAV                                                              As EDO_ID_EQUI_TRAV                 ,
  FLAG_SCH_EQUI_TRAV                                                            As FLAG_SCH_EQUI_TRAV               ,
  FLAG_HIER_EQUI_TRAV                                                           As FLAG_HIER_EQUI_TRAV              ,
  FLAG_PLT_CONV_EQUI_TRAV                                                       As FLAG_PLT_CONV_EQUI_TRAV          
From
(
  Select
    SOURCE                                                                        As SOURCE                           ,
    CUID                                                                          As CUID                             ,
    NOM                                                                           As NOM                              ,
    PRENOM                                                                        As PRENOM                           ,
    DT_DEBUT                                                                      As DT_DEBUT                         ,
    DT_FIN                                                                        As DT_FIN                           ,
    RAT_ORGA_EQUI_CO_GRP                                                          As RAT_ORGA_EQUI_CO_GRP             ,
    EDO_ID_EQUI_RAT                                                               As EDO_ID_EQUI_RAT                  ,
    FLAG_SCH_EQUI_RAT                                                             As FLAG_SCH_EQUI_RAT                ,
    FLAG_HIER_EQUI_RAT                                                            As FLAG_HIER_EQUI_RAT               ,
    FLAG_PLT_CONV_EQUI_RAT                                                        As FLAG_PLT_CONV_EQUI_RAT           ,
    TRAV_ORGA_EQUI_CO_GRP                                                         As TRAV_ORGA_EQUI_CO_GRP            ,
    EDO_ID_EQUI_TRAV                                                              As EDO_ID_EQUI_TRAV                 ,
    FLAG_SCH_EQUI_TRAV                                                            As FLAG_SCH_EQUI_TRAV               ,
    FLAG_HIER_EQUI_TRAV                                                           As FLAG_HIER_EQUI_TRAV              ,
    FLAG_PLT_CONV_EQUI_TRAV                                                       As FLAG_PLT_CONV_EQUI_TRAV          ,
    Case  When max(EDO_ID_EQUI_RAT) Over (Partition by CUID
                                                  Order by DT_DEBUT rows between 1 preceding  and 1 preceding 
                                    ) = EDO_ID_EQUI_RAT

              Then 1
            Else 0
    End                                                                           As TO_BE_MERGED                     
  From
  (
    Select
      'RFOR'                                                                      As SOURCE                           ,
      Rforce.SWCREATEDBY                                                          As CUID                             ,
      RefEmp.LAST_NAME_NM                                                         As NOM                              ,
      RefEmp.FIRST_NAME_NM                                                        As PRENOM                           ,
      Cast(Rforce.SWDATECREATED  as timestamp(0) Format 'YYYYMMDDHHMISS')         As DT_DEBUT                         ,
      Cast('29991231000000' As Timestamp(0) Format 'YYYYMMDDHHMISS')              As DT_FIN                           ,
      Null                                                                        As RAT_ORGA_EQUI_CO_GRP             ,
      Cor.O3_TEAM_CD                                                              As EDO_ID_EQUI_RAT                  ,
      Null                                                                        As FLAG_SCH_EQUI_RAT                ,
      Null                                                                        As FLAG_HIER_EQUI_RAT               ,
      Null                                                                        As FLAG_PLT_CONV_EQUI_RAT           ,
      Null                                                                        As TRAV_ORGA_EQUI_CO_GRP            ,
      Cor.O3_TEAM_CD                                                              As EDO_ID_EQUI_TRAV                 ,
      Null                                                                        As FLAG_SCH_EQUI_TRAV               ,
      Null                                                                        As FLAG_HIER_EQUI_TRAV              ,
      Null                                                                        As FLAG_PLT_CONV_EQUI_TRAV          
    From ${KNB_COM_SOC}.V_INT_F_INTRCTN_HRF Rforce
      Left Outer Join
        ${KNB_COM_SOC}.V_INT_R_EMPLOYEE_RF as RefEmp
          On Rforce.SWCREATEDBY       = RefEmp.LOGIN_CD
            And RefEmp.CURRENT_IN     = 1
            And EMPLOYEE_STATUS_IN    = 1
      Inner Join ${KNB_COM_SOC}.V_INT_R_FT_ENTITY_RF Entity
          On Rforce.CD_EQU_RFORCE (CASESPECIFIC)     =     Entity.ENTITY_NAME_NM (CASESPECIFIC) 
      Inner join ${KNB_PCO_SOC}.V_ORG_F_TEAM_CORR Cor
          On Entity.ENTITY_ID   =   Cor.RF_TEAM_CD

    Where 
      (1=1)
      And (Rforce.CD_EQU_O3_ACTIVE is null or  Rforce.CD_EQU_O3_RATTACHEMENT is null)
      And Cor.O3_TEAM_CD is not null

    Qualify Row_number() over (Partition By SWCREATEDBY, SWDATECREATED order by FRESH_TS desc) = 1
  ) RFOEdo
  Qualify TO_BE_MERGED = 0
) RFOREdoMerged
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_RFOR;
.if errorcode <> 0 then .quit 1

