-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_PCM_Step1_Precalcul.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  d'extraction des placement soft pcm pour transformation en acte
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 17/10/2014      HZO         Calcul du flag perform
-- 12/04/2016      MDE         Evol  : profondeur calcul 100 jrs
-- 17/07/2017      HLA         Modif Pilotage Terminaux
-- 20/07/2017      JCR         Amelioration requete
-- 28/12/2017      MEL         Evol Placement EAN
-- 05/01/2017      HOB         Evol REFCOM
-- 27/03/2018      JCR         Correction TSUBV (>=)
-- 16/04/2018      JCR         Correction TSUBV (KPI)
-- 20/03/2020      EVI         PILCOM-354 : KPI2 – KPI 2 ACQ MOBILE => SOCLE MOBILE
-- 08/09/2020      TCL         Rajout du EXTERNAL_ORDER_ID pour les TSUBV
-- 02/10/2020      EVI         PILCOM-561 : Gestion TYPE_COMMANDE = SOSH_C
--------------------------------------------------------------------------------

.set width 2500;
-- **************************************************************
-- Alimentation de la table volatile --Extraction du KPI ACQ MOBILE
-- **************************************************************
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_EXT_KPI (
  PERIODE_ID                INTEGER          ,
  ACT_SEG_COM_ID_FINAL      VARCHAR(64)      
)
Primary Index (
    PERIODE_ID, ACT_SEG_COM_ID_FINAL
)
On Commit Preserve Rows
;
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_KPI Column( PERIODE_ID,ACT_SEG_COM_ID_FINAL);
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_EXT_KPI
(
  PERIODE_ID                                 ,
  ACT_SEG_COM_ID_FINAL                       
)

Select
Distinct
  SEG.PERIODE_ID           as  PERIODE_ID          ,
  SEG.SEG_COM_ID           as  ACT_SEG_COM_ID_FINAL
From ${KNB_COM_SOC}.CAT_R_PERIODE_COM_PILCOM PER
Inner Join ${KNB_COM_SOC}.CAT_R_SEG_COMMERCE_PILCOM   SEG
  On  SEG.PERIODE_ID            = PER.PERIODE_ID
  And SEG.ELIGIBLE_TERM_SUBV    = 1
  And SEG.CURRENT_IN            = 1
Where PER.PERIODE_DATE_FIN      >= Current_date-100
And   PER.CURRENT_IN            = 1  
;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.ORD_V_EXT_KPI;
.if errorcode <> 0 then .quit 1

-- **************************************************************
-- Alimentation de la table volatile --Extraction VU
-- **************************************************************
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_EXT_VU (
  ACTE_ID        BIGINT                   ,
  ACT_DT         DATE FORMAT 'YYYY-MM-DD' ,
  IMEI_CD        VARCHAR(20)              ,
  MSISDN_ID      CHAR(10)                 ,
  NDS_VALUE_DS   CHAR(10)                 ,
  EXTERNAL_ORDER_ID  VARCHAR(20)          
)
Primary Index (
    ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_VU Column( ACT_DT);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_VU Column( IMEI_CD);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_VU Column( MSISDN_ID);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_VU Column( NDS_VALUE_DS);
.if errorcode <> 0 then .quit 1
Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_VU Column( EXTERNAL_ORDER_ID);
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_EXT_VU
(
  ACTE_ID           ,
  ACT_DT            ,
  IMEI_CD           ,
  MSISDN_ID         ,
  NDS_VALUE_DS      ,
  EXTERNAL_ORDER_ID
)

Select

  ACTE_ID           ,
  ACT_DT            ,
  IMEI_CD           ,
  MSISDN_ID         ,
  NDS_VALUE_DS      ,
  ORDER_EXTERNAL_ID
From ${KNB_PCO_VM_GLB_V}.ORD_F_ACTE_UNIFIED V
Inner Join ${KNB_TERADATA_USER}.ORD_V_EXT_KPI K
On K.PERIODE_ID             = V.ACT_PERIODE_ID
And K.ACT_SEG_COM_ID_FINAL  = V.ACT_SEG_COM_ID_FINAL
Inner Join ${KNB_COM_SOC}.CAT_R_KPI_PILCOM KPI
On KPI.PERIODE_ID           = V.ACT_PERIODE_ID
And KPI.FAMILLE_KPI_ID      = V.ACT_ACTE_FAMILLE_KPI
And KPI.KPI_ID              = '${P_PIL_627}'
Where V.INTRNL_SOURCE_ID    = 1
And   V.TYPE_SOURCE_ID      = 'MOB'
And   V.CONCLDD_IN          = 'O'
And ( V.IMEI_CD Is Not Null 
      Or  (V.MSISDN_ID <> '0000000000' 
            And V.MSISDN_ID Is Not Null
           )
      Or  (V.NDS_VALUE_DS <> '0000000000' 
            And V.NDS_VALUE_DS Is Not Null
           )
	  Or V.ORDER_EXTERNAL_ID is not null
      )
And   V.ACT_DT >= current_date - 100

;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.ORD_V_EXT_VU;
.if errorcode <> 0 then .quit 1
-- **************************************************************
-- Alimentation de la table volatile --Extraction VU
-- **************************************************************


---------------------------------------------------------------------------------------------------------------
--Step 1 :
--Extraction des données de la table des placements
--et réorganisation pour pouvoir jointer dans la table des catalogues
--------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_EXT all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_EXT
(
  ACTE_ID                   ,
  EXTERNAL_ORDER_ID         ,
  ORDER_DEPOSIT_DT          ,
  VAD_ORDER_ID              ,
  TYPE_PRODUCT              ,
  EXT_OPER_ID               ,
  PRODUCT_TYPE              ,
  TERMINAL_CODE_EAN         ,
  TERMINAL_DS               ,
  TERMINAL_PRICE            ,
  NB_POINT_USED             ,
  DUREE_REENGAGEMENT        ,
  OSCAR_VALUE_NU            ,
  PERIODE_ID                ,
  TERM_PERFORM_IND          ,
  PAR_IMEI_CD               ,
  CUSTOMER_ND_AR            ,
  CUSTOMER_DOSSIER_NU_ADV   ,
  CODE_OFFR_VAD_ID          
)
Select
  Placement.ACTE_ID                                               as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                     as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT           ,
  Placement.VAD_ORDER_ID                                          as VAD_ORDER_ID               ,
  Placement.TYPE_PRODUCT                                          as TYPE_PRODUCT               ,
  --Reformatage des champs de mouvements
  Case  --Si c'est un RMV ou SUP ou RMP => RMV
        When (Placement.EXT_OPER_ID in ('${P_PIL_008}','${P_PIL_015}','${P_PIL_098}'))
          then '${P_PIL_008}'
        --Si C'est un ADM ou ADD Ou ADP => ADD
        When (Placement.EXT_OPER_ID in ('${P_PIL_005}','${P_PIL_091}','${P_PIL_099}'))
          then '${P_PIL_005}'
        Else Placement.EXT_OPER_ID
  End                                                             as EXT_OPER_ID                ,
  Case  When Placement.TYPE_PRODUCT = '${P_PIL_232}' 
          Then  '${P_PIL_234}'
        When  Substring(Placement.CUSTOMER_CLIENT_NU_ADV From 1 For 6)= '000000' --Dans le cas d'un Client Prepaid
          Then  ('${P_PIL_087}')  --Dans ce cas => BCR_PREPAID
        Else    ('${P_PIL_088}')  --Dans ce cas => BCR_POSTPAID
  End                                                             as PRODUCT_TYPE               ,
  --Code EAN
  Placement.TERMINAL_CODE_EAN                                     as TERMINAL_CODE_EAN          ,
  --Lib Terminal
  Placement.TERMINAL_DS                                           as TERMINAL_DS                ,
  --Prix
  Placement.TERMINAL_PRICE                                        as TERMINAL_PRICE             ,
  Placement.NB_POINT_USED                                         as NB_POINT_USED              ,
  Placement.DUREE_REENGAGEMENT                                    as DUREE_REENGAGEMENT         ,
  --Si c'est du VAD alors on met le code SC:
  Case  When Placement.TYPE_PRODUCT = '${P_PIL_232}'
          Then  Coalesce(Placement.OSCAR_VALUE_NU,'${P_PIL_104}')
        When Placement.TYPE_PRODUCT = '${P_PIL_231}'
          Then Placement.OSCAR_VALUE_NU
        Else   Placement.OSCAR_VALUE_NU
  End                                                             as OSCAR_VALUE_NU             ,
  --Période
  Coalesce(Periode.PERIODE_ID           ,${P_PIL_049}  )          as PERIODE_ID                 ,
  Placement.TERM_PERFORM_IND                                      as TERM_PERFORM_IND           ,
  Placement.PAR_IMEI_CD                                           as PAR_IMEI_CD                ,
  Placement.CUSTOMER_ND_AR                                        as CUSTOMER_ND_AR             ,
  Placement.CUSTOMER_DOSSIER_NU_ADV                               as CUSTOMER_DOSSIER_NU_ADV    ,
  Placement.CODE_OFFR_VAD_ID                                      as CODE_OFFR_VAD_ID    
From
  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_PCM Placement
  Left Outer Join  ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM Periode
    On    Placement.ORDER_DEPOSIT_DT              >= Periode.PERIODE_DATE_DEB
      And Placement.ORDER_DEPOSIT_DT              <= Periode.PERIODE_DATE_FIN
      And Periode.FRESH_IN                        = 1
      And Periode.CURRENT_IN                      = 1
      And Periode.CLOSURE_DT                      is null
Where
  (1=1)
  And Placement.FLAG_FIRST_RECEPTION_COM      =   1
  And Placement.FLAG_FIRST_RECEPTION_COM_STAT =   1
  And Placement.ORDER_DEPOSIT_DT              >=  Cast('${KNB_PILCOM_ACTE_BORNE_INF}' as Date Format 'YYYYMMDD')
  And Placement.TERMINAL_CODE_EAN         Is not null
  And Placement.ORDER_DEPOSIT_DT              >= (Current_date - ${P_PIL_534}) 
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_EXT;
.if errorcode <> 0 then .quit 1


-- **************************************************************
-- Alimentation de la table volatile --Extraction Commande des Actes MOB
-- avec un segment agrégé final SOSH
-- **************************************************************
Create Volatile Table ${KNB_TERADATA_USER}.ORD_V_EXT_SOSH_MOB (
  ORDER_EXTERNAL_ID        VARCHAR(19) ,
  ACT_SEG_COM_AGG_ID_FINAL VARCHAR(64)      
)
Primary Index (ORDER_EXTERNAL_ID)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_TERADATA_USER}.ORD_V_EXT_SOSH_MOB Column(ORDER_EXTERNAL_ID);
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_TERADATA_USER}.ORD_V_EXT_SOSH_MOB
(
  ORDER_EXTERNAL_ID        ,
  ACT_SEG_COM_AGG_ID_FINAL                       
)

Select Distinct
  SoftMOB.ORDER_EXTERNAL_ID           as  ORDER_EXTERNAL_ID          ,
  SoftMOB.ACT_SEG_COM_AGG_ID_FINAL    as  ACT_SEG_COM_AGG_ID_FINAL
From  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_EXT Placement
Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_MOB SoftMOB
  On SoftMOB.ORDER_EXTERNAL_ID = Placement.EXTERNAL_ORDER_ID 
 And SoftMOB.ACT_SEG_COM_AGG_ID_FINAL = 'SOSH'
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_TERADATA_USER}.ORD_V_EXT_SOSH_MOB;
.if errorcode <> 0 then .quit 1


---------------------------------------------------------------------------------------------------------------
--Step 2 :
--Jointure avec le catalogue pour récupérer les attributs pour la migration
---------------------------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_CAL all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_CAL
(
  ACTE_ID                   ,
  ACTE_ID_CMD_RAPPROCHEE    ,
  EXTERNAL_ORDER_ID         ,
  ORDER_DEPOSIT_DT          ,
  OSCAR_VALUE_NU            ,
  PERIODE_ID                ,
  PRODUCT_ID_PRE            ,
  SEG_COM_ID_PRE            ,
  SEG_COM_AGG_ID_PRE        ,
  CODE_MIGR_PRE             ,
  TYPE_MVT_PRE              ,
  PRODUCT_ID_FINAL          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  CODE_MIGR_FINAL           ,
  TYPE_SERVICE_FINAL        ,
  TYPE_MVT_FINAL            ,
  TYPE_COMMANDE_ID          ,
  DELTA_TARIF               ,
  TERMINAL_CODE_EAN         
)
Select
  Placement.ACTE_ID                                                                                         as ACTE_ID                    ,
  Case When TYPE_COMMANDE_ID = 'TSUBV' then coalesce(VuIMEI.ACTE_ID,VuMSISDN.ACTE_ID,VuNDS.ACTE_ID,VuExtId.ACTE_ID) 
  End                                                                                                       as ACTE_ID_CMD_RAPPROCHEE     ,
  Placement.EXTERNAL_ORDER_ID                                                                               as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                                                                as ORDER_DEPOSIT_DT           ,
  Placement.OSCAR_VALUE_NU                                                                                  as OSCAR_VALUE_NU             ,
  Placement.PERIODE_ID                                                                                      as PERIODE_ID                 ,
  Null                                                                                                      as PRODUCT_ID_PRE             ,
  Null                                                                                                      as SEG_COM_ID_PRE             ,
  Null                                                                                                      as SEG_COM_AGG_ID_PRE         ,
  Null                                                                                                      as CODE_MIGR_PRE              ,
  Null                                                                                                      as TYPE_MVT_PRE               ,
  TypeEAN.PRODUCT_ID                                                                                        as PRODUCT_ID_FINAL           ,
  TypeEAN.SEG_COM_ID                                                                                        as SEG_COM_ID_FINAL           ,
  TypeEAN.SEG_COM_AGG_ID                                                                                    as SEG_COM_AGG_ID_FINAL       ,
  TypeEAN.CODE_MIGRATION                                                                                    as CODE_MIGR_FINAL            ,
  TypeEAN.TYPE_SERVICE                                                                                      as TYPE_SERVICE_FINAL         ,
  Placement.EXT_OPER_ID                                                                                     as TYPE_MVT_FINAL             ,
  Case
         When TypeEAN.RGR_TYPE_SRV_CD ='TERMINAUX'  And Coalesce(VuIMEI.IMEI_CD,VuMSISDN.MSISDN_ID,VuNDS.NDS_VALUE_DS,VuExtId.EXTERNAL_ORDER_ID)  Is not null and Placement.ORDER_DEPOSIT_DT >=  cast('20170701'as DATE FORMAT 'YYYYMMDD') Then 'TSUBV'
        --Dans le cadre d'un PCM si c'est un PostPaid -> PCM
        When Placement.TYPE_PRODUCT = 'TPCM' And Placement.PRODUCT_TYPE='BCR_POSTPAID'
          Then  'PCM'
        --Dans le cadre d'un PCM si c'est un Prépaid -> ORM
        When Placement.TYPE_PRODUCT = 'TPCM' And Placement.PRODUCT_TYPE='BCR_PREPAID' 
          Then  'ORM'
        --Dans le cadre d'un VAD sur un non Perform
        When Placement.TYPE_PRODUCT = 'TVAD' And Placement.TERM_PERFORM_IND = 'C'
          Then  'PERF_C'
        --Dans le cadre d'un VAD sur un non Perform
        When Placement.TYPE_PRODUCT = 'TVAD' And Placement.TERM_PERFORM_IND = 'E'
          Then  'PERF_E'
        When Placement.ORDER_DEPOSIT_DT >= Cast('20201001' As Date Format 'YYYYMMDD') And Placement.CODE_OFFR_VAD_ID = 'TERMS'
		      Then 'SOSH_C'
        When Placement.ORDER_DEPOSIT_DT >= Cast('20201001' As Date Format 'YYYYMMDD') And SoftMOB.ACT_SEG_COM_AGG_ID_FINAL = 'SOSH'  And TypeEAN.RGR_TYPE_SRV_CD = 'TERMINAUX'
		      Then 'SOSH_C'
        --Dans le cadre d'un VAD sur un non Perform
        When Placement.TYPE_PRODUCT = 'TVAD' And Placement.TERM_PERFORM_IND Is Null
          Then  'ACQ'
  End                                                                                                       as TYPE_COMMANDE_ID           ,
  Placement.TERMINAL_PRICE                                                                                  as DELTA_TARIF                ,
      --Code EAN
  Placement.TERMINAL_CODE_EAN                                                                               as TERMINAL_CODE_EAN           
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_EXT Placement
  --Jointure pour récupérer EAN
  Inner Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_EAN TypeEAN
    On    Placement.TERMINAL_CODE_EAN         = TypeEAN.CODE_EAN
      And Placement.PERIODE_ID                = TypeEAN.PERIODE_ID

 Left Outer Join 
   (SEL ACTE_ID, IMEI_CD, ACT_DT From ${KNB_TERADATA_USER}.ORD_V_EXT_VU
   Where IMEI_CD Is Not Null
    QUALIFY Row_number () OVER (Partition By IMEI_CD, ACT_DT Order By ACTE_ID Asc) =1
            ) VuIMEI 
    On  Placement.PAR_IMEI_CD                 =  VuIMEI.IMEI_CD         
        And Placement.ORDER_DEPOSIT_DT        =  VuIMEI.ACT_DT          

 Left Outer Join 
   (SEL ACTE_ID, MSISDN_ID, ACT_DT From ${KNB_TERADATA_USER}.ORD_V_EXT_VU
   Where MSISDN_ID <> '0000000000'
   And  MSISDN_ID Is Not Null
    QUALIFY Row_number () OVER (Partition By MSISDN_ID, ACT_DT Order By ACTE_ID Asc) =1
            ) VuMSISDN 
    On Placement.CUSTOMER_DOSSIER_NU_ADV      =  VuMSISDN.MSISDN_ID     
        And Placement.ORDER_DEPOSIT_DT        =  VuMSISDN.ACT_DT        

 Left Outer Join 
   (SEL ACTE_ID, NDS_VALUE_DS, ACT_DT From ${KNB_TERADATA_USER}.ORD_V_EXT_VU
   Where NDS_VALUE_DS <> '0000000000'
   And NDS_VALUE_DS Is Not Null
    QUALIFY Row_number () OVER (Partition By NDS_VALUE_DS, ACT_DT Order By ACTE_ID Asc) =1
            ) VuNDS 
    On  Placement.CUSTOMER_ND_AR              =  VuNDS.NDS_VALUE_DS     
        And Placement.ORDER_DEPOSIT_DT        =  VuNDS.ACT_DT    

 Left Outer Join 
   (SEL ACTE_ID, EXTERNAL_ORDER_ID, ACT_DT From ${KNB_TERADATA_USER}.ORD_V_EXT_VU
   Where EXTERNAL_ORDER_ID Is Not Null
    QUALIFY Row_number () OVER (Partition By EXTERNAL_ORDER_ID, ACT_DT Order By ACTE_ID Asc) =1
            ) VuExtId
    On  Placement.VAD_ORDER_ID                =  VuExtId.EXTERNAL_ORDER_ID     
        And Placement.ORDER_DEPOSIT_DT        =  VuExtId.ACT_DT                   

 Left Outer Join ${KNB_TERADATA_USER}.ORD_V_EXT_SOSH_MOB SoftMOB
   On    SoftMOB.ORDER_EXTERNAL_ID = Placement.EXTERNAL_ORDER_ID 
     And SoftMOB.ACT_SEG_COM_AGG_ID_FINAL = 'SOSH'
   
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_CAL
(
  ACTE_ID                   ,
  EXTERNAL_ORDER_ID         ,
  ORDER_DEPOSIT_DT          ,
  OSCAR_VALUE_NU            ,
  PERIODE_ID                ,
  PRODUCT_ID_PRE            ,
  SEG_COM_ID_PRE            ,
  SEG_COM_AGG_ID_PRE        ,
  CODE_MIGR_PRE             ,
  TYPE_MVT_PRE              ,
  PRODUCT_ID_FINAL          ,
  SEG_COM_ID_FINAL          ,
  SEG_COM_AGG_ID_FINAL      ,
  CODE_MIGR_FINAL           ,
  TYPE_SERVICE_FINAL        ,
  TYPE_MVT_FINAL            ,
  TYPE_COMMANDE_ID          ,
  DELTA_TARIF               ,
  TERMINAL_CODE_EAN         
)
Select
  Placement.ACTE_ID                                                                                         as ACTE_ID                    ,
  Placement.EXTERNAL_ORDER_ID                                                                               as EXTERNAL_ORDER_ID          ,
  Placement.ORDER_DEPOSIT_DT                                                                                as ORDER_DEPOSIT_DT           ,
  Placement.OSCAR_VALUE_NU                                                                                  as OSCAR_VALUE_NU             ,
  Placement.PERIODE_ID                                                                                      as PERIODE_ID                 ,
  Null                                                                                                      as PRODUCT_ID_PRE             ,
  Null                                                                                                      as SEG_COM_ID_PRE             ,
  Null                                                                                                      as SEG_COM_AGG_ID_PRE         ,
  Null                                                                                                      as CODE_MIGR_PRE              ,
  Null                                                                                                      as TYPE_MVT_PRE               ,
  Coalesce(TypeEAN.PRODUCT_ID,'CODECAT INCONNU')                                                            as PRODUCT_ID_FINAL           ,
  Coalesce(TypeEAN.SEG_COM_ID,'CODECAT INCONNU')                                                            as SEG_COM_ID_FINAL           ,
  Coalesce(TypeEAN.SEG_COM_AGG_ID,'CODEMIGRAINCO')                                                          as SEG_COM_AGG_ID_FINAL       ,
  Coalesce(TypeEAN.CODE_MIGRATION,'CODEMIGRAINCO')                                                          as CODE_MIGR_FINAL            ,
  Coalesce(TypeEAN.TYPE_SERVICE,'')                                                                         as TYPE_SERVICE_FINAL         ,
  Placement.EXT_OPER_ID                                                                                     as TYPE_MVT_FINAL             ,
  Case
        --Dans le cadre d'un PCM si c'est un PostPaid -> PCM
        When Placement.TYPE_PRODUCT = 'TPCM' And Placement.PRODUCT_TYPE='BCR_POSTPAID'
          Then  'PCM'
        --Dans le cadre d'un PCM si c'est un Prépaid -> ORM
        When Placement.TYPE_PRODUCT = 'TPCM' And Placement.PRODUCT_TYPE='BCR_PREPAID'
          Then  'ORM'
        --Dans le cadre d'un VAD sur un non Perform
        When Placement.TYPE_PRODUCT = 'TVAD' And Placement.TERM_PERFORM_IND = 'C'
          Then  'PERF_C'
        --Dans le cadre d'un VAD sur un non Perform
        When Placement.TYPE_PRODUCT = 'TVAD' And Placement.TERM_PERFORM_IND = 'E'
          Then  'PERF_E'
        When Placement.ORDER_DEPOSIT_DT >= Cast('20201001' As Date Format 'YYYYMMDD') And Placement.CODE_OFFR_VAD_ID = 'TERMS'
		      Then 'SOSH_C'
        When Placement.ORDER_DEPOSIT_DT >= Cast('20201001' As Date Format 'YYYYMMDD') And SoftMOB.ACT_SEG_COM_AGG_ID_FINAL = 'SOSH'  And TypeEAN.RGR_TYPE_SRV_CD = 'TERMINAUX'
		      Then 'SOSH_C'
        --Dans le cadre d'un VAD sur un non Perform
        When Placement.TYPE_PRODUCT = 'TVAD' And Placement.TERM_PERFORM_IND Is Null
          Then  'ACQ'
  End                                                                                                       as TYPE_COMMANDE_ID           ,
  Placement.TERMINAL_PRICE                                                                                  as DELTA_TARIF                ,
      --Code EAN
  Placement.TERMINAL_CODE_EAN                                                                               as TERMINAL_CODE_EAN           
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_EXT Placement
  --Jointure pour récupérer EAN
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MOB TypeEAN
    On    Case  When Placement.TYPE_PRODUCT = 'TPCM' And Placement.PRODUCT_TYPE='BCR_POSTPAID'
                  Then 'PP_0000004'
                When Placement.TYPE_PRODUCT = 'TPCM' And Placement.PRODUCT_TYPE='BCR_PREPAID'
                  Then 'PP_0000003'
                When Placement.TYPE_PRODUCT = 'TVAD'
                  Then 'PV_0000005'
          End                                 = TypeEAN.PRODUCT_ID
      And Placement.PERIODE_ID                = TypeEAN.PERIODE_ID
 Left Outer Join ${KNB_TERADATA_USER}.ORD_V_EXT_SOSH_MOB SoftMOB
   On    SoftMOB.ORDER_EXTERNAL_ID = Placement.EXTERNAL_ORDER_ID 
     And SoftMOB.ACT_SEG_COM_AGG_ID_FINAL = 'SOSH'

Where
  (1=1)
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_CAL RefId
      Where
        (1=1)
        And Placement.ACTE_ID           = RefId.ACTE_ID
        And Placement.ORDER_DEPOSIT_DT  = RefId.ORDER_DEPOSIT_DT
    )
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_PCM_C_CAL;
.if errorcode <> 0 then .quit 1


