
-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCM_Acte_Alimentation_RechercheRapprochement.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de rapprochement
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/05/2014      HFO         Creation
-- 02/06/2014      MCA         Ajout rapprochement NSH->PCM
-- 11/06/2014      MCA         Modification clés de jointure AGC PCM 
-- 30/07/2014      GMA         Ajout champ croisement
-- 28/08/2014      MCA         Indus
-- 22/10/2014      YZH         Suppression de la partie IODA: croisement nominal  
-- 28/10/2014      MCA         Suppression de la partie NEWSHOP: croisement nominal
-- 05/03/2015      HZO         Ajout du filtre sur le CLOSURE_DT (Jointure Chorus)
-- 09/04/2015      HFO         ajout filtre  CLOSURE_DT is null
--------------------------------------------------------------------------------

.set width 2500;

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_PCM_TRC_CHO All;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_PCM_TRC_CHO 
(
  ACTE_ID                            ,
  ORDER_DEPOSIT_DT                   ,
  CPLT_ACTE_ID                       ,
  CPLT_INTRL_SOURCE_ID               ,
  CPLT_EXT_INT_ID                    ,
  CPLT_EXT_INT_DELT_ID               ,
  CPLT_RESOLU_ID                     ,
  CPLT_CONCLU_ID                     ,
  CPLT_INT_ORIGIN_CD                 ,
  CPLT_INT_REASON_CD                 ,
  CPLT_INT_RESULT_CD                 ,
  CPLT_ORG_AGENT_ID                  ,
  CPLT_ORG_NOM                       ,
  CPLT_ORG_PRENOM                    ,
  CPLT_ORG_STORE_NAME                ,
  CPLT_ORG_CHANNEL_CD                ,
  CPLT_ORG_SUB_CHANNEL_CD            ,
  CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
  CPLT_ORG_REM_CHANNEL_CD            ,
  CPLT_ORG_GT_ACTIVITY               ,
  CPLT_ORG_FIDELISATION              ,
  CPLT_ORG_AUTO_ACTIVITY             ,
  CPLT_ORG_WEB_ACTIVITY              ,
  CPLT_ORG_EDO_ID                    ,
  CPLT_ORG_TYPE_EDO                  ,
  CPLT_ORG_NETWRK_TYP_EDO_ID         ,
  CPLT_ORG_FLAG_PLT_CONV             ,
  CPLT_ORG_FLAG_TEAM_MKT             ,
  CPLT_ORG_FLAG_TYPE_CMP             ,
  CPLT_ORG_RESP_EDO_ID               ,
  CPLT_ORG_RESP_TYPE_EDO             ,
  CPLT_ORG_RESP_FLAG_PLT_CONV        ,
  CPLT_ORG_TEAM_LEVEL_1_CD           ,
  CPLT_ORG_TEAM_LEVEL_1_DS           ,
  CPLT_ORG_TEAM_LEVEL_2_CD           ,
  CPLT_ORG_TEAM_LEVEL_2_DS           ,
  CPLT_ORG_TEAM_LEVEL_3_CD           ,
  CPLT_ORG_TEAM_LEVEL_3_DS           ,
  CPLT_ORG_TEAM_LEVEL_4_CD           ,
  CPLT_ORG_TEAM_LEVEL_4_DS           ,
  CPLT_WORK_TEAM_LEVEL_1_CD          ,
  CPLT_WORK_TEAM_LEVEL_1_DS          ,
  CPLT_WORK_TEAM_LEVEL_2_CD          ,
  CPLT_WORK_TEAM_LEVEL_2_DS          ,
  CPLT_WORK_TEAM_LEVEL_3_CD          ,
  CPLT_WORK_TEAM_LEVEL_3_DS          ,
  CPLT_WORK_TEAM_LEVEL_4_CD          ,
  CPLT_WORK_TEAM_LEVEL_4_DS

)

Select
  Acte.ACTE_ID                                                      As ACTE_ID                            ,
  Acte.ORDER_DEPOSIT_DT                                             As ORDER_DEPOSIT_DT                   ,
  --Identifiant de l'acte complémentaire
  ActeCho.ACTE_ID                                                   As CPLT_ACTE_ID                       ,
  2                                                                 As CPLT_INTRL_SOURCE_ID               ,
  Coalesce(ActeCho.EXTERNAL_INT_ID, 1)                              As CPLT_EXT_INT_ID                    ,
  Coalesce(Trim(
                Substr( ActeCho.DEMANDE_ID,
                        Index(ActeCho.DEMANDE_ID,'S')+1,
                        Char_length(ActeCho.DEMANDE_ID)-Index(ActeCho.DEMANDE_ID,'S')+1
                      )
               ),
          1)                                                        As CPLT_EXT_INT_DELT_ID               ,
  ActeCho.RESOLU_ID                                                 As CPLT_RESOLU_ID                     ,
  ActeCho.CONCLU_ID                                                 As CPLT_CONCLU_ID                     ,
  ActeCho.INT_ORIGIN_CD                                             As CPLT_INT_ORIGIN_CD                 ,
  ActeCho.INT_REASON_CD                                             As CPLT_INT_REASON_CD                 ,
  ActeCho.INT_RESULT_CD                                             As CPLT_INT_RESULT_CD                 ,
  ActeCho.ORG_AGENT_ID                                              As CPLT_ORG_AGENT_ID                  ,
  ActeCho.ORG_NOM                                                   As CPLT_ORG_NOM                       ,
  ActeCho.ORG_PRENOM                                                As CPLT_ORG_PRENOM                    ,
  Null                                                              As CPLT_ORG_STORE_NAME                ,
  ActeCho.ORG_CHANNEL_CD                                            As CPLT_ORG_CHANNEL_CD                ,
  ActeCho.ORG_SUB_CHANNEL_CD                                        As CPLT_ORG_SUB_CHANNEL_CD            ,
  ActeCho.ORG_SUB_SUB_CHANNEL_CD                                    As CPLT_ORG_SUB_SUB_CHANNEL_CD        ,
  ActeCho.ORG_REM_CHANNEL_CD                                        As CPLT_ORG_REM_CHANNEL_CD            ,
  ActeCho.ORG_GT_ACTIVITY                                           As CPLT_ORG_GT_ACTIVITY               ,
  ActeCho.ORG_FIDELISATION                                          As CPLT_ORG_FIDELISATION              ,
  ActeCho.ORG_AUTO_ACTIVITY                                         As CPLT_ORG_AUTO_ACTIVITY             ,
  ActeCho.ORG_WEB_ACTIVITY                                          As CPLT_ORG_WEB_ACTIVITY              ,
  ActeCho.ORG_EDO_ID                                                As CPLT_ORG_EDO_ID                    ,
  ActeCho.ORG_TYPE_EDO                                              As CPLT_ORG_TYPE_EDO                  ,
  Null                                                              As CPLT_ORG_NETWRK_TYP_EDO_ID         ,
  ActeCho.ORG_FLAG_PLT_CONV                                         As CPLT_ORG_FLAG_PLT_CONV             ,
  ActeCho.ORG_FLAG_TEAM_MKT                                         As CPLT_ORG_FLAG_TEAM_MKT             ,
  ActeCho.ORG_FLAG_TYPE_CMP                                         As CPLT_ORG_FLAG_TYPE_CMP             ,
  ActeCho.ORG_RESP_EDO_ID                                           As CPLT_ORG_RESP_EDO_ID               ,
  ActeCho.ORG_RESP_TYPE_EDO                                         As CPLT_ORG_RESP_TYPE_EDO             ,
  ActeCho.ORG_RESP_FLAG_PLT_CONV                                    As CPLT_ORG_RESP_FLAG_PLT_CONV        ,
  ActeCho.ORG_TEAM_LEVEL_1_CD                                       As CPLT_ORG_TEAM_LEVEL_1_CD           ,
  ActeCho.ORG_TEAM_LEVEL_1_DS                                       As CPLT_ORG_TEAM_LEVEL_1_DS           ,
  ActeCho.ORG_TEAM_LEVEL_2_CD                                       As CPLT_ORG_TEAM_LEVEL_2_CD           ,
  ActeCho.ORG_TEAM_LEVEL_2_DS                                       As CPLT_ORG_TEAM_LEVEL_2_DS           ,
  ActeCho.ORG_TEAM_LEVEL_3_CD                                       As CPLT_ORG_TEAM_LEVEL_3_CD           ,
  ActeCho.ORG_TEAM_LEVEL_3_DS                                       As CPLT_ORG_TEAM_LEVEL_3_DS           ,
  ActeCho.ORG_TEAM_LEVEL_4_CD                                       As CPLT_ORG_TEAM_LEVEL_4_CD           ,
  ActeCho.ORG_TEAM_LEVEL_4_DS                                       As CPLT_ORG_TEAM_LEVEL_4_DS           ,
  ActeCho.WORK_TEAM_LEVEL_1_CD                                      As CPLT_WORK_TEAM_LEVEL_1_CD          ,
  ActeCho.WORK_TEAM_LEVEL_1_DS                                      As CPLT_WORK_TEAM_LEVEL_1_DS          ,
  ActeCho.WORK_TEAM_LEVEL_2_CD                                      As CPLT_WORK_TEAM_LEVEL_2_CD          ,
  ActeCho.WORK_TEAM_LEVEL_2_DS                                      As CPLT_WORK_TEAM_LEVEL_2_DS          ,
  ActeCho.WORK_TEAM_LEVEL_3_CD                                      As CPLT_WORK_TEAM_LEVEL_3_CD          ,
  ActeCho.WORK_TEAM_LEVEL_3_DS                                      As CPLT_WORK_TEAM_LEVEL_3_DS          ,
  ActeCho.WORK_TEAM_LEVEL_4_CD                                      As CPLT_WORK_TEAM_LEVEL_4_CD          ,
  ActeCho.WORK_TEAM_LEVEL_4_DS                                      As CPLT_WORK_TEAM_LEVEL_4_DS          
 
From
  --Les Actes à rechercher
  ${KNB_PCO_VM}.V_ORD_F_ACTE_PCM Acte
  Inner Join ${KNB_PCO_VM}.V_INT_F_ACTE_CHO ActeCho
    On  Acte.PAR_ADV_CLIENT_NU    = ActeCho.CLIENT_NU
    And Acte.PAR_ADV_DOSSIER_NU   = ActeCho.DOSSIER_NU
    And ActeCho.CLOSURE_DT        is  null
     ---Filtre pour ne prendre que ceux qui sont dans le périmètre de + ou - 3
    And Acte.ORDER_DEPOSIT_DT >= (ActeCho.INT_DEPOSIT_DT -3) 
    And Acte.ORDER_DEPOSIT_DT <= (ActeCho.INT_DEPOSIT_DT +3)
Where
  (1=1)
  And ActeCho.TYPE_OT_SO='PCM'
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order By ActeCho.LAST_MODIF_TS Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_PCM_TRC_CHO;
.if errorcode <> 0 then .quit 1

.quit 0
