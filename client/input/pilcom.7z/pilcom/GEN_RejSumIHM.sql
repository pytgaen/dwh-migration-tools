-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  GEN_RejSumIHM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de la synthese de rejet
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 13/08/2014      OCH         Creation
--------------------------------------------------------------------------------

.set width 2500;


Select 
         Trim (Coalesce(syn.nomTable,''))||
   '|'|| Trim (Coalesce(syn.NbLigne,''))  ||
   '|'|| Trim (Coalesce(SommeTotal. nbTotalLigne ,'')) (title '')
From (
             Select Case
                        When REJECT_CD like 'RJC_' Then 'ACT_F_ACT_EXF_CREA'
                        When REJECT_CD like 'RJM_' Then 'ACT_F_ACT_EXF_MODIF'
                        When REJECT_CD like 'RJS_' Then 'ACT_F_ACT_EXF_SUPP'
                    End                                      As nomTable,
                    Count (*) over( partition by nomTable)  as NbLigne
             From ( Select *
                    From ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
                    Where  INJECTION_TS = ( Select max(INJECTION_TS)
                                     From ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
                                    )
                    AND Cast( INJECTION_TS as Date ) = Current_Date
                    Qualify ROW_NUMBER() Over (Partition by  TYPE_MOVEMENT_CD,ACTE_ID,ORDER_DEPOSIT_TS,
                                                         LAST_NAME_CUSTOMER_NM,FIRST_NAME_CUSTOMER_NM,
                                                         MISISDN_ID,ND_ID,NDIP_ID,AGENT_ID,ACT_REM_ID,INJECTION_TS
                                                         order by 1) =1 
                   ) tRej
      ) syn,
      ( 
       Select Count(1) as nbTotalLigne
       From (   Select *
                From ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ
                Where  INJECTION_TS = ( Select max(INJECTION_TS)
                                        From ${KNB_PCO_SOC}.ACT_F_ACT_EXF_REJ )
                AND Cast( INJECTION_TS as Date ) = Current_Date
                Qualify ROW_NUMBER() Over (Partition by  TYPE_MOVEMENT_CD,ACTE_ID,ORDER_DEPOSIT_TS,
                                                         LAST_NAME_CUSTOMER_NM,FIRST_NAME_CUSTOMER_NM,
                                                         MISISDN_ID,ND_ID,NDIP_ID,AGENT_ID,ACT_REM_ID,INJECTION_TS
                                                         order by 1) =1 
             ) nbr
      ) SommeTotal
Qualify ROW_NUMBER() Over (Partition by syn.nomTable   Order by syn.nomTable) =1
 ;
 .if errorcode <> 0 then .quit 1
 
 .quit 0
