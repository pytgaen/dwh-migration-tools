-- $HEADER: mm2pco/current/sql/ATP_ETASK_Referentiel_Alimentation_Step1_Ref_Fusion.sql 13_05#8 13-JAN-2017 10:36:29 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ETASK_Referentiel_Alimentation_Step1_Ref_Fusion.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 14/10/2015     MDE         Creation
-- 09/12/2016     HOB         Modification VA
-- 27/10/2020     EVI         PILCOM-57 : Decommissionnement WEBPARTNER
--------------------------------------------------------------------------------


.set width 2000;



Delete From ${KNB_PCO_TMP}.ORD_W_REF_ETK All;
.if errorcode <> 0 then .quit 1

--------------fusion step1

 Insert into ${KNB_PCO_TMP}.ORD_W_REF_ETK
(
  EXTERNAL_ORDER_ID                                ,
  ORDER_DEPOSIT_DT                                 ,
  PARSIFAL_ORDER_ID                                ,
  EXT_APPLI_ID                                     ,
  ORDER_DEPOSIT_TS                                 ,
  AGENT_ID                                         ,
  DISTRBTN_CHANNL_ID                               ,
  CUSTOMER_CIVILITY_CD                             ,
  CUSTOMER_LAST_NM                                 ,
  CUSTOMER_FIRST_NM                                ,
  CUSTOMER_SIRET_CD                                ,
  CUSTOMER_BSS_ID                                  ,
  CUSTOMER_FGT_ID                                  ,
  CUSTOMER_ND_DS                                   ,
  CUSTOMER_MSISDN_NU                               ,
  CLIENT_NU                                        ,
  PAR_IMSI                                         ,
  CUSTOMER_CLIENT_ADV_NU                           ,
  ORDR_TYPE_IN                                     ,
  JOB_ID                                           ,
  JOB_NAME                                         ,
  EDO_ID                                           ,
  FLAG_PLT_CONV_NB                                 ,
  TYPE_EDO_ID                                      ,
  NETWRK_TYP_EDO_ID                                ,
  FLAG_TYPE_GEO_CD                                 ,
  FLAG_TYPE_CPT_NTK_NU                             ,
  FLAG_TYPE_PTN_NTK_NU                             ,
  ORG_CANAL_ID                                     ,
  ORG_CHANEL_CD                                    ,
  ORG_SUB_CHANEL_CD                                ,
  ORG_SUB_SUB_CHANEL_CD                            ,
  ORG_REM_CHANEL_CD                                ,
  ORG_GT_ACTIVITY                                  ,
  ORG_FIDELISATION                                 ,
  ORG_WEB_ACTIVITY                                 ,
  ORG_AUTO_ACTIVITY                                ,
  STORE_NM                                         ,
  LAST_MODIF_TS                                    ,
  FLAG_TEAM_MKT_NB                                 ,
  FLAG_TYPE_CMP_NU                                 ,
  SOURCE_CD                                        ,
  SERVICE_ACCESS_ID                                ,
  LAST_TRT_PARSIFAL_ID                             ,
  ORDR_ID                                          ,
  ORDR_ORGN_DS                                     ,
  DMC_LINE_ID                                      ,
  DMC_MASTER_LINE_ID                               ,
  DEPARTMNT_ID                                     ,
  BU_CD                                            ,
  POSTAL_CD                                        ,
  INSEE_CD                                         ,
  PAR_GEO_MACROZONE                                ,
  PAR_UNIFIED_PARTY_ID                             ,
  PAR_PARTY_REGRPMNT_ID                            ,
  PAR_IRIS2000_CD                                  ,
  PAR_FIBER_IN                                      
)
  Select 
  RefId.EXTERNAL_ORDER_ID                     as  EXTERNAL_ORDER_ID                      ,
  RefId.ORDER_DEPOSIT_DT                      as  ORDER_DEPOSIT_DT                       ,
  RefId.PARSIFAL_ORDER_ID                     as  PARSIFAL_ORDER_ID                      ,
  RefId.EXT_APPLI_ID                          as  EXT_APPLI_ID                           ,
  RefId.ORDER_DEPOSIT_TS                      as  ORDER_DEPOSIT_TS                       ,
  RefId.AGENT_ID                              as  AGENT_ID                               ,
  RefId.DISTRBTN_CHANNL_ID                    as  DISTRBTN_CHANNL_ID                     ,
  RefId.CUSTOMER_CIVILITY_CD                  as  CUSTOMER_CIVILITY_CD                   ,
  RefId.CUSTOMER_LAST_NM                      as  CUSTOMER_LAST_NM                       ,
  RefId.CUSTOMER_FIRST_NM                     as  CUSTOMER_FIRST_NM                      ,
  RefId.CUSTOMER_SIRET_CD                     as  CUSTOMER_SIRET_CD                      ,
  RefId.CUSTOMER_BSS_ID                       as  CUSTOMER_BSS_ID                        ,
  RefId.CUSTOMER_FGT_ID                       as  CUSTOMER_FGT_ID                        ,
  RefId.CUSTOMER_ND_DS                        as  CUSTOMER_ND_DS                         ,
  RefId.CUSTOMER_MSISDN_NU                    as  CUSTOMER_MSISDN_NU                     ,
  ClientDos.CLIENT_NU                         as  CLIENT_NU                              ,
  ClientDos.DOSSIER_NU_IMSI                   as  PAR_IMSI                               ,
  RefId.CUSTOMER_CLIENT_ADV_NU                as  CUSTOMER_CLIENT_ADV_NU                 ,
  RefId.ORDR_TYPE_IN                          as  ORDR_TYPE_IN                           ,
  RefId.JOB_ID                                as  JOB_ID                                 ,
  RefId.JOB_NAME                              as  JOB_NAME                               ,
  RefOrga.EDO_ID                              as  EDO_ID                                 ,
  RefId.FLAG_PLT_CONV_NB                      as  FLAG_PLT_CONV_NB                       ,
  RefOrga.TYPE_EDO_ID                         as  TYPE_EDO_ID                            ,
  RefId.NETWRK_TYP_EDO_ID                     as  NETWRK_TYP_EDO_ID                      ,
  RefId.FLAG_TYPE_GEO_CD                      as  FLAG_TYPE_GEO_CD                       ,
  RefId.FLAG_TYPE_CPT_NTK_NU                  as  FLAG_TYPE_CPT_NTK_NU                   ,
  RefId.FLAG_TYPE_PTN_NTK_NU                  as  FLAG_TYPE_PTN_NTK_NU                   ,
  RefOrga.ORG_CHANNL_ID                       as ORG_CANAL_ID                            ,
  --Calcul du canal de vente Macro
  RefOrga.ORG_CHANEL_CD                       as ORG_CHANEL_CD                           ,
  --Sous Canal 
  RefOrga.ORG_SUB_CHANEL_CD                   as ORG_SUB_CHANEL_CD                       ,
   --Sous-Sous-Canal
  RefOrga.ORG_SUB_SUB_CHANEL_CD               as ORG_SUB_SUB_CHANEL_CD                   ,
  --Canal de Rem
  RefOrga.ORG_REM_CHANEL_CD                   as ORG_REM_CHANEL_CD                       ,
  --Activité
  RefOrga.ORG_GT_ACTIVITY                     as ORG_GT_ACTIVITY                         ,
  --Fidelisaion
  NULL                                        as ORG_FIDELISATION                        ,
  --Activité Web
  RefOrga.ORG_WEB_ACTIVITY                    as ORG_WEB_ACTIVITY                        ,
  --Activité Automatique
  RefOrga.ORG_AUTO_ACTIVITY                   as ORG_AUTO_ACTIVITY                       ,
  RefOrga.ORG_PDV_CD                          as STORE_NM                                ,
  RefId.LAST_MODIF_TS                         as  LAST_MODIF_TS                          ,
  RefId.FLAG_TEAM_MKT_NB                      as  FLAG_TEAM_MKT_NB                       ,
  RefId.FLAG_TYPE_CMP_NU                      as  FLAG_TYPE_CMP_NU                       ,
  RefId.SOURCE_CD                             as  SOURCE_CD                              ,
  RefId.SERVICE_ACCESS_ID                     as  SERVICE_ACCESS_ID                      ,
  RefId.LAST_TRT_PARSIFAL_ID                  as  LAST_TRT_PARSIFAL_ID                   ,
  RefId.ORDR_ID                               as  ORDR_ID                                ,
  RefId.ORDR_ORGN_DS                          as  ORDR_ORGN_DS                           ,
  RefId.DMC_LINE_ID                           as  DMC_LINE_ID                            ,
  RefId.DMC_MASTER_LINE_ID                    as  DMC_MASTER_LINE_ID                     ,
  RefId.DEPARTMNT_ID                          as  DEPARTMNT_ID                           ,
  RefId.BU_CD                                 as  BU_CD                                  ,
  RefId.POSTAL_CD                             as  POSTAL_CD                              ,
  RefId.INSEE_CD                              as  INSEE_CD                               ,
  RefId.PAR_GEO_MACROZONE                     as  PAR_GEO_MACROZONE                      ,
  RefId.PAR_UNIFIED_PARTY_ID                  as  PAR_UNIFIED_PARTY_ID                   ,
  RefId.PAR_PARTY_REGRPMNT_ID                 as  PAR_PARTY_REGRPMNT_ID                  ,
  RefId.PAR_IRIS2000_CD                       as  PAR_IRIS2000_CD                        ,
  RefId.PAR_FIBER_IN                          as  PAR_FIBER_IN                           
From
  ${KNB_PCO_TMP}.ORD_W_REF_ETK_1 RefId
     -- On récupère client_nu:
       Left Outer Join ${KNB_PCO_TMP}.ORD_W_REF_ETK_CLIENT ClientDos
    On    RefId.EXTERNAL_ORDER_ID = ClientDos.EXTERNAL_ORDER_ID
      And RefId.ORDER_DEPOSIT_DT  = ClientDos.ORDER_DEPOSIT_DT
      -- On récupère l’axe Canal 32r:
      Left Outer Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_32R_WEB RefOrga
    On      RefId.DISTRBTN_CHANNL_ID   = RefOrga.ORG_CHANNL_ID
       And  RefOrga.ORG_WEB_PARTNER_IN = 'NON'
       And  RefOrga.CURRENT_IN                              = 1
       And  RefOrga.CLOSURE_DT                              Is Null
Where
  (1=1)
  Qualify Row_number() over (Partition By  RefId.EXTERNAL_ORDER_ID Order By RefId.ORDER_DEPOSIT_TS asc)=1
;

.if errorcode <> 0 then .quit 1

 Collect stat on ${KNB_PCO_TMP}.ORD_W_REF_ETK;
.if errorcode <> 0 then .quit 1



.quit 0
