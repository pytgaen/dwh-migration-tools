-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_AGCM_AlimCold_ORD_T_ACTE_UNIFIED_AGCM.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source AGCM dans la table ORD_T_ACTE_UNIFIED_AGCM  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 11/06/2014     MCA         Création
-- 12/11/2014     YZH         Ajout des attributs du parc 
-- 05/03/2015     HZO         Modif: Profondeur de recalcul 15 jours
-- 19/06/2015     OCH         Modif: digital
-- 26/01/2016     MDE         Evol Pilcom Digital 
-- 12/12/2016     HOB         Modif : Ajout Champs VA
-- 13/03/2017     HLA         Modif/Evol
-- 04/10/2017     HOB         Evol CIA CID/PID/FIRST
-- 27/09/2019     EVI         Alimentation Champs KPI2020 : ACT_CA_LINE_AM
-- 09/10/2019     EVI         KPI2020 : Mise en place du filtre sur les NS/NSTECH pour data enabler
-- 01/07/2020     JCR         Ajout colonne SIM_EAN_CD
-- 06/09/2021     BCH         PILCOM-967 : Suppression champs obsolètes VU
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_MOB --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_AGCM;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_AGCM 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_EDO_IOBSP                 ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  PERNNT_IN                     ,
  PERNNT_END_DT                 ,
  PERNNT_CALC_END_DT            ,
  PERNNT_MOTIF                  ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  PAR_IRIS2000_CD               ,
  ACT_CA_LINE_AM                ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  ORG_RESP_ID                   ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  MOB.ACTE_ID_GEN                                                          As ACTE_ID,
  Null                                                                     As OPERATOR_PROVIDER_ID,
  MOB.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID,
  '${P_PIL_368}'                                                           As TYPE_SOURCE_ID,
  MOB.ACTE_ID_GEN                                                          As MASTER_ACTE_ID,
  MOB.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID,
  ${P_PIL_354}                                                             As MASTER_FLAG,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND,
  Null                                                                     As CPLT_ACTE_ID,
  Null                                                                     As CPLT_INTRNL_SOURCE_ID,
  '${P_PIL_388}'                                                           As CPLT_IN,
  '${P_PIL_362}'                                                           As RULE_ID,
  Null                                                                     As OFFSET_NB,
  '${P_PIL_325}'                                                           As ACT_TYPE,
  MOB.EXTERNAL_ORDER_ID                                                    As ORDER_EXTERNAL_ID,
  Null                                                                     As STATUS_CD,
  Case When MOB.CONCURENCE_IN = '${P_PIL_356}' Then '${P_PIL_385}'
       When MOB.CONFIRMATION_IN = '${P_PIL_357}' Then '${P_PIL_386}' 
       When MOB.PERNNT_IN = '${P_PIL_356}' Then '${P_PIL_384}' 
       When MOB.DELIVERY_IN = '${P_PIL_356}' And MOB.PERNNT_IN = '${P_PIL_357}' Then '${P_PIL_387}' 
       When MOB.DELIVERY_IN = '${P_PIL_356}' Then '${P_PIL_383}' 
       When MOB.CONFIRMATION_IN = '${P_PIL_356}' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                      As ACT_UNIFIED_STATUS_CD,
  MOB.ORDER_DEPOSIT_TS                                                     As ACT_TS,
  MOB.ORDER_DEPOSIT_DT                                                     As ACT_DT,
  Extract(HOUR From MOB.ORDER_DEPOSIT_TS)                                  As ACT_HH,
  Null                                                                     As ACT_LAST_UPD_TS,
  MOB.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE,
  MOB.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE,
  MOB.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE,
  MOB.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE,
  MOB.ACT_OPER_ID_PRE                                                      As ACT_OPER_ID_PRE,
  MOB.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL,
  MOB.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL,
  MOB.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL,
  MOB.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL,
  --Dans PCM on ajoute que des produits
  'ADD'                                                                    As ACT_OPER_ID_FINAL,
  MOB.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL,
  MOB.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID,
  MOB.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF,
  MOB.ACT_CD                                                               As ACT_CD,
  MOB.ACT_REM_ID                                                           As ACT_REM_ID,
  MOB.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM,
  MOB.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And MOB.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And MOB.ORG_AGENT_ID_UPD Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And MOB.ORG_REM_CHANNEL_CD IN (${L_PIL_043}) 
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And SFI.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And MOB.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then 'O' 
       Else 'N'  
  End                                                                       As ACT_FLAG_PVC_REM,
  MOB.ACT_ACTE_VALO                                                         As ACT_ACTE_VALO,
  MOB.ACT_ACTE_FAMILLE_KPI                                                  As ACT_ACTE_FAMILLE_KPI,
  MOB.ACT_PERIODE_ID                                                        As ACT_PERIODE_ID,
  MOB.ACT_PERIODE_STATUS                                                    As ACT_PERIODE_STATUS               ,
  MOB.ACT_PERIODE_CLOSURE_DT                                                As ACT_PERIODE_CLOSURE_DT           ,
  MOB.ORIG_DEM                                                              As ORIGIN_CD,
  trim(MOB.ORG_AGENT_ID      )                                              As AGENT_ID,
  trim(MOB.ORG_AGENT_ID_UPD  )                                              As AGENT_ID_UPD,
  MOB.ORG_AGENT_ID_UPD_DT                                                   As AGENT_ID_UPD_DT,
  MOB.ORG_AGENT_IOBSP                                                       As ORG_AGENT_IOBSP,
  MOB.ORG_PRENOM                                                            As AGENT_FIRST_NAME,
  MOB.ORG_NOM                                                               As AGENT_LAST_NAME,
  MOB.ORG_STORE_NAME                                                        As UNIFIED_SHOP_CD,
  MOB.ORG_CHANNEL_ID_MACRO                                                  As ORG_SPE_CANAL_ID_MACRO,
  MOB.ORG_CHANNEL_ID                                                        As ORG_SPE_CANAL_ID,
  MOB.ORG_REM_CHANNEL_CD                                                    As ORG_REM_CHANNEL_CD,
  MOB.ORG_CHANNEL_CD                                                        As ORG_CHANNEL_CD,
  MOB.ORG_SUB_CHANNEL_CD                                                    As ORG_SUB_CHANNEL_CD,
  MOB.ORG_SUB_SUB_CHANNEL_CD                                                As ORG_SUB_SUB_CHANNEL_CD,
  MOB.ORG_GT_ACTIVITY                                                       As ORG_GT_ACTIVITY,
  MOB.ORG_FIDELISATION                                                      As ORG_FIDELISATION,
  MOB.ORG_WEB_ACTIVITY                                                      As ORG_WEB_ACTIVITY,
  MOB.ORG_AUTO_ACTIVITY                                                     As ORG_AUTO_ACTIVITY,
  MOB.ORG_EDO_ID                                                            As ORG_EDO_ID,
  MOB.ORG_TYPE_EDO                                                          As ORG_TYPE_EDO,
  MOB.ORG_EDO_IOBSP                                                         As ORG_EDO_IOBSP,
  MOB.ORG_FLAG_PLT_CONV                                                     As ORG_FLAG_PLT_CONV,
  MOB.ORG_FLAG_TEAM_MKT                                                     As ORG_FLAG_TEAM_MKT,
  MOB.ORG_FLAG_TYPE_CMP                                                     As ORG_FLAG_TYPE_CMP,
  Null                                                                      As ORG_RESP_EDO_ID,
  Null                                                                      As ORG_RESP_TYPE_EDO, 
  Null                                                                      As ORG_RESP_FLAG_PLT_CONV,
  Null                                                                      As ACTIVITY_CD,
  Null                                                                      As ACTIVITY_GROUPNG_CD,
  Null                                                                      As AUTO_ACTIVITY_IN,
  '${P_PIL_366}'                                                            As ORG_TYPE_CD,
  Null                                                                      As ORG_TEAM_TYPE_ID,
  Null                                                                      As ORG_TEAM_LEVEL_1_CD,
  Null                                                                      As ORG_TEAM_LEVEL_1_DS,
  Null                                                                      As ORG_TEAM_LEVEL_2_CD,
  Null                                                                      As ORG_TEAM_LEVEL_2_DS,
  Null                                                                      As ORG_TEAM_LEVEL_3_CD,
  Null                                                                      As ORG_TEAM_LEVEL_3_DS,
  Null                                                                      As ORG_TEAM_LEVEL_4_CD,
  Null                                                                      As ORG_TEAM_LEVEL_4_DS,
  Trim(MOB.WORK_TEAM_LEVEL_1_CD)                                            As WORK_TEAM_LEVEL_1_CD,
  MOB.WORK_TEAM_LEVEL_1_DS                                                  As WORK_TEAM_LEVEL_1_DS,
  Trim(MOB.WORK_TEAM_LEVEL_2_CD)                                            As WORK_TEAM_LEVEL_2_CD,
  MOB.WORK_TEAM_LEVEL_2_DS                                                  As WORK_TEAM_LEVEL_2_DS,
  Trim(MOB.WORK_TEAM_LEVEL_3_CD)                                            As WORK_TEAM_LEVEL_3_CD,
  MOB.WORK_TEAM_LEVEL_3_DS                                                  As WORK_TEAM_LEVEL_3_DS,
  Trim(MOB.WORK_TEAM_LEVEL_4_CD)                                            As WORK_TEAM_LEVEL_4_CD,
  MOB.WORK_TEAM_LEVEL_4_DS                                                  As WORK_TEAM_LEVEL_4_DS,
  MOB.CONFIRMATION_IN                                                       As CONFIRMATION_IN,
  Case When MOB.ACT_FLAG_PEC_PERPVC = 'N'
    Then 'O'
  Else MOB.PERNNT_IN                                                                   
  End                                                                       As PERNNT_IN,  
  Case When MOB.ACT_FLAG_PEC_PERPVC = 'N'
    Then Null
  Else MOB.PERNNT_END_DT                                                                   
  End                                                                       As PERNNT_END_DT,
  MOB.PERNNT_CALC_END_DT                                                    As PERNNT_CALC_END_DT,
  Case When MOB.ACT_FLAG_PEC_PERPVC = 'N'
    Then Null
  Else MOB.PERNNT_MOTIF                                                                   
  End                                                                       As PERNNT_MOTIF, 

  
  Null                                                                     As MIGRA_DT                      ,
  Null                                                                     As MIGRA_NEXT_OFFRE              ,
  MOB.SEG_PRES_PARC_COMMANDE                                               As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  Case  When  ( MOB.ORDER_DEPOSIT_DT + MOB.DELIVERY_DEAD_LINE_NU ) >= MOB.SEG_FIND_LIVR_DT
          Then MOB.SEG_FIND_LIVR_DT 
        Else Null
  End                                                                      As SEGMENT_DELIVERY_IN_PARK_DT      ,
  MOB.ORDER_CANCELING_DT                                                   As ORDER_CANCELING_DT               ,
  MOB.DMC_LINE_ID                                                          As LINE_ID,
  MOB.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID,
  MOB.PAR_TYPE                                                             As CUST_TYPE_CD,
  Coalesce(MOB.PAR_ADV_DOSSIER_NU, '0000000000')                           As MSISDN_ID,
  Coalesce(MOB.PAR_ND, '0000000000')                                       As NDS_VALUE_DS,
  MOB.PAR_ADV_CLIENT_NU                                                    As EXTERNAL_PARTY_ID,
  MOB.PAR_EXTERNAL_PARTY_BSS_ID                                            As RES_VALUE_DS,
  MOB.PAR_ACCES_SERVICE                                                    As PAR_ACCES_SERVICE,
  MOB.PAR_MOB_TAC                                                          As TAC_CD,
  MOB.PAR_MOB_IMEI                                                         As IMEI_CD,
  MOB.PAR_MOB_IMSI                                                         As IMSI_CD,
  Null                                                                     As HOM_START_DT,
  Null                                                                     As MOB_START_DT,
  Null                                                                     As I_SCORE_VALUE,
  Null                                                                     As I_SCORE_TRESHOLD,
  Null                                                                     As I_SCORE_IN,
  MOB.PAR_SCORE_NU_MOB                                                     As M_SCORE_VALUE,
  Case
    When MOB.PAR_TRESHOLD_NU_MOB > 100 Then -1
    Else MOB.PAR_TRESHOLD_NU_MOB        
  End                                                                      As M_SCORE_TRESHOLD,
  MOB.PAR_SCORE_IN_MOB                                                     As M_SCORE_IN,
  Cast(MOB.OTO_OSCAR_VALUE_NU As BYTEINT)                                  As OSCAR_VALUE,
  '${P_PIL_376}'                                                           AS CUST_BU_TYPE_CD,
  MOB.PAR_USCM                                                             As CUST_BU_CD,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE,
  Trim(
    Trim(Coalesce(Case When MOB.PAR_BILL_ADRESS_1 = 'null' Then Null Else MOB.PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When MOB.PAR_BILL_ADRESS_2 = 'null' Then Null Else MOB.PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When MOB.PAR_BILL_ADRESS_3 = 'null' Then Null Else MOB.PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(MOB.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(Case When MOB.PAR_BILL_ADRESS_4 = 'null' Then Null Else MOB.PAR_BILL_ADRESS_4 End,''))
  )                                                                        As ADDRESS_CONCAT_NM,
  Coalesce(MOB.PAR_POSTAL_CD,MOB.PAR_BILL_CD_POSTAL)                       As POSTAL_CD,
  MOB.PAR_INSEE_CD                                                         As INSEE_CD,
  MOB.PAR_BU_CD                                                            As BU_CD,
  Coalesce(MOB.PAR_DEPARTMNT_ID,MOB.PAR_DO )                               As DEPARTMNT_ID,
  MOB.PAR_GEO_MACROZONE                                                    as PAR_GEO_MACROZONE    ,
  MOB.PAR_UNIFIED_PARTY_ID                                                 as PAR_UNIFIED_PARTY_ID       ,
  MOB.PAR_PARTY_REGRPMNT_ID                                                as PAR_PARTY_REGRPMNT_ID   ,
  MOB.PAR_CID_ID                                                           as PAR_CID_ID                   ,
  MOB.PAR_PID_ID                                                           as PAR_PID_ID                   ,
  MOB.PAR_FIRST_IN                                                         as PAR_FIRST_IN                 ,
  MOB.PAR_IRIS2000_CD                                                      As PAR_IRIS2000_CD ,
  Case 
    -- Unite = NB
    When MOB.ACT_UNITE_CD = '${P_PIL_620}' 
     Then Null
	Else  Coalesce(MOB.ACT_DELTA_TARIF,0)
  End                                                                      As ACT_CA_LINE_AM,
  MOB.PAR_MOB_SIM                                                          As SIM_CD                        ,
  MOB.SIM_EAN_CD                                                           As SIM_EAN_CD                    ,
  MOB.ORG_RESP_AGENT_ID                                                    As ORG_RESP_ID                   ,
  MOB.CHECK_INITIAL_STATUS_CD                                              As CHECK_INITIAL_STATUS_CD,
  MOB.CHECK_NAT_STATUS_CD                                                  As CHECK_NAT_STATUS_CD,
  MOB.CHECK_NAT_COMMENT                                                    As CHECK_NAT_COMMENT,
  MOB.CHECK_NAT_STATUS_LN                                                  As CHECK_NAT_STATUS_LN,
  MOB.CHECK_LOC_STATUS_CD                                                  As CHECK_LOC_STATUS_CD,
  MOB.CHECK_LOC_COMMENT                                                    As CHECK_LOC_COMMENT,
  MOB.CHECK_LOC_STATUS_LN                                                  As CHECK_LOC_STATUS_LN,
  MOB.CHECK_VALIDT_DT                                                      As CHECK_VALIDT_DT,
  Null                                                                     As ACT_END_UNIFIED_DT,
  Null                                                                     As ACT_END_UNIFIED_DS,
  MOB.CLOSURE_DT                                                           As ACT_CLOSURE_DT,
  Case When MOB.CLOSURE_DT Is Not Null
       Then 'Acte Clos'        
  End                                                                      As ACT_CLOSURE_DS,
  MOB.HOT_IN                                                               As HOT_IN,
  Null                                                                     As RUN_ID,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS,
  1                                                                        As FRESH_IN,
  0                                                                        As COHERENCE_IN 
From ${KNB_PCO_VM}.V_ORD_F_ACTE_AGC_MOB MOB 
Where (1=1)
  And Substr(MOB.ACT_CD,1,3) Not In (${L_PIL_036})
  And MOB.ACT_SEG_COM_ID_FINAL <> '${P_PIL_295}'
  And MOB.ACT_CD <> '${P_PIL_067}'
  And MOB.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
  And MOB.HOT_IN = 0
  And MOB.ACT_PERIODE_ID > 12
  And MOB.ORDER_DEPOSIT_DT  >= Current_date - 250
  And ((MOB.LAST_MODIF_TS >  '${KNB_PILCOM_EXTRACT_BORNE_INF}'  And MOB.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or MOB.ORDER_DEPOSIT_DT  > Current_date - 15)
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_AGCM;
.if errorcode <> 0 then .quit 1;

