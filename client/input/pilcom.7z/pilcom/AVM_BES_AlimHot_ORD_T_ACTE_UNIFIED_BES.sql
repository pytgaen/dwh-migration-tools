--$HEADER:   %HEADER% 
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_BES_AlimHot_ORD_T_ACTE_UNIFIED_BES.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données chaudes de la source Bestar dans la table ORD_T_ACTE_UNIFIED_H_BES 
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 11/08/2014     KBH         Création
-- 29/09/2014     YZH         Modification sur les chams de clients
-- 19/06/2015     OCH         Modif: digital
-- 23/09/2015     MDE         Modif/Evol Enrichissement client
-- 13/01/2016     MDE         Modif/Evol Calcul CA
-- 09/12/2016     HOB         Modif VA
-- 07/03/2017     HLA         MODIFICATION 
-- 26/04/2017     JCR         Ajout non remontee des actes CA=0 dans la VU
-- 28/04/2017     JCR         Desactivation non remontee des actes CA=0 dans la VU
-- 28/04/2017     JCR         Activation des actes CA=0 dans la VU à partir du 1/06/2017
-- 21/06/2017     HOB         CA indicateurs
-- 30/06/2017     JCR         Mapping du CA HT et CA TTC
-- 21/11/2017     HOB         Alimentation Champs IOBSP
-- 24/09/2019     EVI         KPI2020 : Suppression Filtre ACT_CA_LINE_AM + Optimisation
-- 09/10/2019     EVI         KPI2020 : Mise en place du filtre sur les NS/NSTECH pour data enabler
-- 07/07/2020     EVI         PILCOM-503 : Indicateur eSim - New Champ SIM_EAN_CD
-- 14/09/2020     EVI         PILCOM-662 : Alimentation Vu.SIM_CD via Acte.PAR_MOB_SIM
-- 22/09/2021     EVI         PILCOM-792 : Gestion Retour/Annulation DSTAR
-- 30/09/2021     EVI         PILCOM-1022 : Refonte VU - Suppression champs obsolètes
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_H_BES --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_BES;
.if errorcode <> 0 then .quit 1;

-- BES

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_BES 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  ORG_AGENT_IOBSP               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_EDO_IOBSP                 ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  PAR_IRIS2000_CD               ,
  ----------------------
  ACT_CA_LINE_AM                ,
  ACT_CA_TTC_AM                 ,
  EAN_CD                        ,
  ----------------------
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  ---------------------
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  QUEUE_TS                      ,
  STREAMING_TS                  ,
  ACT_CREATION_TS               ,
  EXT_CREATION_TS               ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  BES.ACTE_ID                                                              As ACTE_ID,
  'COMXX'                                                                  As OPERATOR_PROVIDER_ID,
  BES.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID,
  '${P_PIL_368}'                                                           As TYPE_SOURCE_ID,
  BES.ACTE_ID                                                              As MASTER_ACTE_ID,
  BES.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID,
  ${P_PIL_354}                                                             As MASTER_FLAG,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND,
  Null                                                                     As CPLT_ACTE_ID,
  Null                                                                     As CPLT_INTRNL_SOURCE_ID,
  '${P_PIL_388}'                                                           As CPLT_IN,
  '${P_PIL_362}'                                                           As RULE_ID,
  Null                                                                     As OFFSET_NB,
  '${P_PIL_324}'                                                           As ACT_TYPE,
  BES.ORDER_EXTERNAL_ID                                                    As ORDER_EXTERNAL_ID,
  '${P_PIL_397}'                                                           As STATUS_CD,
  '${P_PIL_381}'                                                           As ACT_UNIFIED_STATUS_CD,
  BES.ORDER_DEPOSIT_TS                                                     As ACT_TS,
  BES.ORDER_DEPOSIT_DT                                                     As ACT_DT,
  Extract(HOUR From BES.ORDER_DEPOSIT_TS)                                  As ACT_HH,
  BES.ORDER_DEPOSIT_TS                                                     As ACT_LAST_UPD_TS,
  BES.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE,
  BES.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE,
  BES.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE,
  BES.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE,
  Case When ACT_PRODUCT_ID_PRE Is Not Null Then 'RMV'
       Else Null
  End                                                                      As ACT_OPER_ID_PRE,
  BES.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL,
  BES.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL,
  BES.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL,
  BES.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL,
  Null                                                                     As ACT_OPER_ID_FINAL,
  BES.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL,
  BES.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID,
  BES.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF,
  BES.ACT_CD                                                               As ACT_CD,
  BES.ACT_REM_ID                                                           As ACT_REM_ID,
  BES.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM,
  BES.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And BES.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And BES.ORG_AGENT_ID Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And BES.ORG_REM_CHANNEL_CD In (${L_PIL_043})
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And BES.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And BES.CLOSURE_DT              Is Null
                    -- Edo interne
                    And ( BES.ORG_TYPE_EDO        = 'INT' Or BES.ORG_TYPE_EDO  is Null )
                )
        Then 'O' 
       Else 'N'  
  End                                                                      As ACT_FLAG_PVC_REM,
  BES.ACT_ACTE_VALO                                                        As ACT_ACTE_VALO,
  BES.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI,
  BES.ACT_PERIODE_ID                                                       As ACT_PERIODE_ID,
  Coalesce(EtatPeriode.PERIODE_STATUS,'O')                                 As ACT_PERIODE_STATUS,
  EtatPeriode.PERIODE_CLOSURE_DT                                           As ACT_PERIODE_CLOSURE_DT,
  Null                                                                     As ORIGIN_CD,
  trim(BES.ORG_AGENT_ID)                                                   As AGENT_ID,
  trim(BES.ORG_AGENT_ID)                                                   As AGENT_ID_UPD,
  Null                                                                     As AGENT_ID_UPD_DT,
  BES.ORG_AGENT_IOBSP                                                      As ORG_AGENT_IOBSP       ,
  BES.ORG_PRENOM                                                           As AGENT_FIRST_NAME,
  BES.ORG_NOM                                                              As AGENT_LAST_NAME,
  Null                                                                     As UNIFIED_SHOP_CD,
  Null                                                                     As ORG_SPE_CANAL_ID_MACRO,
  Null                                                                     As ORG_SPE_CANAL_ID,
  BES.ORG_REM_CHANNEL_CD                                                   As ORG_REM_CHANNEL_CD,
  BES.ORG_CHANNEL_CD                                                       As ORG_CHANNEL_CD,
  BES.ORG_SUB_CHANNEL_CD                                                   As ORG_SUB_CHANNEL_CD,
  BES.ORG_SUB_SUB_CHANNEL_CD                                               As ORG_SUB_SUB_CHANNEL_CD,
  BES.ORG_GT_ACTIVITY                                                      As ORG_GT_ACTIVITY,
  BES.ORG_FIDELISATION                                                     As ORG_FIDELISATION,
  BES.ORG_WEB_ACTIVITY                                                     As ORG_WEB_ACTIVITY,
  BES.ORG_AUTO_ACTIVITY                                                    As ORG_AUTO_ACTIVITY,
  BES.ORG_EDO_ID                                                           As ORG_EDO_ID,
  BES.ORG_TYPE_EDO                                                         As ORG_TYPE_EDO,
  BES.ORG_EDO_IOBSP                                                        As ORG_EDO_IOBSP  ,
  BES.ORG_FLAG_PLT_CONV                                                    As ORG_FLAG_PLT_CONV,
  BES.ORG_FLAG_TEAM_MKT                                                    As ORG_FLAG_TEAM_MKT,
  BES.ORG_FLAG_TYPE_CMP                                                    As ORG_FLAG_TYPE_CMP,
  Null                                                                     As ORG_RESP_EDO_ID,
  Null                                                                     As ORG_RESP_TYPE_EDO, 
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV,
  Null                                                                     As ACTIVITY_CD,
  Null                                                                     As ACTIVITY_GROUPNG_CD,
  Null                                                                     As AUTO_ACTIVITY_IN,
  CASE WHEN BES.ORG_EDO_ID IS NOT NULL THEN 'O3'
       ELSE BES.ORG_REF_TRAV
  END                                                                      As ORG_TYPE_CD,
  Null                                                                     As ORG_TEAM_TYPE_ID                ,
  BES.ORG_TEAM_LEVEL_1_CD                                                  As ORG_TEAM_LEVEL_1_CD             ,
  BES.ORG_TEAM_LEVEL_1_DS                                                  As ORG_TEAM_LEVEL_1_DS             ,
  BES.ORG_TEAM_LEVEL_2_CD                                                  As ORG_TEAM_LEVEL_2_CD             ,
  BES.ORG_TEAM_LEVEL_2_DS                                                  As ORG_TEAM_LEVEL_2_DS             ,
  BES.ORG_TEAM_LEVEL_3_CD                                                  As ORG_TEAM_LEVEL_3_CD             ,
  BES.ORG_TEAM_LEVEL_3_DS                                                  As ORG_TEAM_LEVEL_3_DS             ,
  BES.ORG_TEAM_LEVEL_4_CD                                                  As ORG_TEAM_LEVEL_4_CD             ,
  BES.ORG_TEAM_LEVEL_4_DS                                                  As ORG_TEAM_LEVEL_4_DS             ,
  BES.WORK_TEAM_LEVEL_1_CD                                                 As WORK_TEAM_LEVEL_1_CD            ,
  BES.WORK_TEAM_LEVEL_1_DS                                                 As WORK_TEAM_LEVEL_1_DS            ,
  BES.WORK_TEAM_LEVEL_2_CD                                                 As WORK_TEAM_LEVEL_2_CD            ,
  BES.WORK_TEAM_LEVEL_2_DS                                                 As WORK_TEAM_LEVEL_2_DS            ,
  BES.WORK_TEAM_LEVEL_3_CD                                                 As WORK_TEAM_LEVEL_3_CD            ,
  BES.WORK_TEAM_LEVEL_3_DS                                                 As WORK_TEAM_LEVEL_3_DS            ,
  BES.WORK_TEAM_LEVEL_4_CD                                                 As WORK_TEAM_LEVEL_4_CD            ,
  BES.WORK_TEAM_LEVEL_4_DS                                                 As WORK_TEAM_LEVEL_4_DS            ,
  Null                                                                     As CONFIRMATION_IN                 ,
  Null                                                                     As MIGRA_DT                        ,
  Null                                                                     As MIGRA_NEXT_OFFRE                ,
  BES.DMC_LINE_ID                                                          As LINE_ID                         ,
  BES.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID                  ,
  BES.PAR_TYPE                                                             As CUST_TYPE_CD                    ,
  Coalesce(BES.DOSSIER_NU, '0000000000')                                   As MSISDN_ID                       ,
  Coalesce(BES.PAR_ND, '0000000000')                                       As NDS_VALUE_DS                    ,
  Coalesce(BES.CLIENT_NU, '0000000000')                                    As EXTERNAL_PARTY_ID               ,
  Null                                                                     As RES_VALUE_DS                    ,
  Null                                                                     As PAR_ACCES_SERVICE               ,
  BES.PAR_MOB_TAC                                                          As TAC_CD                          ,
  BES.PAR_MOB_IMEI                                                         As IMEI_CD                         ,
  BES.PAR_IMSI                                                             As IMSI_CD                         ,
  Null                                                                     As HOM_START_DT                    ,
  Null                                                                     As MOB_START_DT                    ,
  Null                                                                     As I_SCORE_VALUE                   ,
  Null                                                                     As I_SCORE_TRESHOLD                ,
  Null                                                                     As I_SCORE_IN                      ,
  BES.PAR_SCORE_NU_MOB                                                     As M_SCORE_VALUE                   ,
  Case
    When BES.PAR_TRESHOLD_NU_MOB > 100 Then -1
    Else BES.PAR_TRESHOLD_NU_MOB
  End                                                                      As M_SCORE_TRESHOLD                ,
  BES.PAR_SCORE_IN_MOB                                                     As M_SCORE_IN                      ,
  Null                                                                     As OSCAR_VALUE                     ,
  '${P_PIL_376}'                                                           As CUST_BU_TYPE_CD                 ,
  BES.PAR_USCM                                                             As CUST_BU_CD                      ,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE                    ,
  Trim(
    Trim(Coalesce(Case When BES.PAR_BILL_ADRESS_1 = 'null' Then Null Else BES.PAR_BILL_ADRESS_1 End,'')) || ' ' ||
    Trim(Coalesce(Case When BES.PAR_BILL_ADRESS_2 = 'null' Then Null Else BES.PAR_BILL_ADRESS_2 End,'')) || ' ' ||
    Trim(Coalesce(Case When BES.PAR_BILL_ADRESS_3 = 'null' Then Null Else BES.PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(Case When BES.PAR_BILL_ADRESS_4 = 'null' Then Null Else BES.PAR_BILL_ADRESS_4 End,'')) || ' ' ||
    Trim(Coalesce(BES.PAR_BILL_CD_POSTAL,'')) || ' ' ||
    Trim(Coalesce(BES.PAR_BILL_VILLE,''))
  )                                                                         As ADDRESS_CONCAT_NM              ,
   Coalesce(BES.PAR_POSTAL_CD,BES.PAR_BILL_CD_POSTAL )                      As POSTAL_CD                      ,
  BES.PAR_INSEE_CD                                                          As INSEE_CD                       ,
  BES.PAR_BU_CD                                                             As BU_CD                          ,
  Coalesce(BES.PAR_DEPARTMNT_ID,BES.PAR_DO )                                As DEPARTMNT_ID                   ,
  BES.PAR_GEO_MACROZONE                                                     As PAR_GEO_MACROZONE              ,
  BES.PAR_UNIFIED_PARTY_ID                                                  As PAR_UNIFIED_PARTY_ID           ,
  BES.PAR_PARTY_REGRPMNT_ID                                                 As PAR_PARTY_REGRPMNT_ID          ,
  Bes.PAR_CID_ID                                                            as PAR_CID_ID                     ,
  Bes.PAR_PID_ID                                                            as PAR_PID_ID                     ,
  Bes.PAR_FIRST_IN                                                          as PAR_FIRST_IN                   ,
  BES.PAR_IRIS2000_CD                                                       As PAR_IRIS2000_CD                ,
  -------
  BES.ACT_CA_LINE_AM                                                        As ACT_CA_LINE_AM                 ,
  BES.ACT_CA_TTC_AM                                                         As ACT_CA_TTC_AM                  ,
  BES.CODE_EAN                                                              As EAN_CD                         ,
  -------
  BES.PAR_MOB_SIM                                                           As SIM_CD                         ,
  Null                                                                      As SIM_EAN_CD                     ,
  -------
  BES.CHECK_INITIAL_STATUS_CD                                               As CHECK_INITIAL_STATUS_CD        ,
  BES.CHECK_NAT_STATUS_CD                                                   As CHECK_NAT_STATUS_CD            ,
  BES.CHECK_NAT_COMMENT                                                     As CHECK_NAT_COMMENT              ,
  BES.CHECK_NAT_STATUS_LN                                                   As CHECK_NAT_STATUS_LN            ,
  BES.CHECK_LOC_STATUS_CD                                                   As CHECK_LOC_STATUS_CD            ,
  BES.CHECK_LOC_COMMENT                                                     As CHECK_LOC_COMMENT              ,
  BES.CHECK_LOC_STATUS_LN                                                   As CHECK_LOC_STATUS_LN            ,
  BES.CHECK_VALIDT_DT                                                       As CHECK_VALIDT_DT                ,
  Null                                                                      As ACT_END_UNIFIED_DT             ,
  Case
    When BES.ACTE_ID_RETURN Is Not Null
      Then Case When BES.ORDER_CANCELING_DS = 'REMBOURSEMENT_CLASSIQUE'
                  Then 'Retour Dstar'
                Else 'Annulation Dstar'
           End
    Else Null
  End                                                                       As ACT_END_UNIFIED_DS             ,
  Case
    When BES.ACTE_ID_RETURN Is Not Null
      Then BES.ORDER_CANCELING_DT
    Else Null
  End                                                                       As ACT_CLOSURE_DT                 ,
  Case
    When BES.ACTE_ID_RETURN Is Not Null
      Then Case When BES.ORDER_CANCELING_DS = 'REMBOURSEMENT_CLASSIQUE'
                  Then 'Retour Dstar'
                Else 'Annulation Dstar'
           End
    Else Null
  End                                                                       As ACT_CLOSURE_DS                 ,
  BES.HOT_IN                                                                As HOT_IN                         ,
  BES.RUN_ID                                                                As RUN_ID                         ,
  Cast(SubString(Cast(BES.QUEUE_TS as Char(22)) From 1 For 19) AS Timestamp(0) format 'DD/MM/YYYYBHH:MI:SS')
                                                                            As QUEUE_TS                       ,
  Cast(SubString(Cast(BES.STREAMING_TS As Char(22)) From 1 For 19) As Timestamp(0))
                                                                            As STREAMING_TS                   ,
  BES.CREATION_TS                                                           As ACT_CREATION_TS                ,
  Current_Timestamp(0)                                                      As EXT_CREATION_TS                ,
  BES.CREATION_TS                                                           As CREATION_TS                    ,
  Null                                                                      As LAST_MODIF_TS                  ,
  1                                                                         As FRESH_IN                       ,
  0                                                                         As COHERENCE_IN
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_BESTAR BES 
Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
      On  BES.ACT_PERIODE_ID                               = EtatPeriode.PERIODE_ID
      And EtatPeriode.CURRENT_IN                           = 1
      And EtatPeriode.FRESH_IN                             = 1
      And EtatPeriode.CLOSURE_DT                           Is Null
Where
  (1=1)
  And Substr(ACT_CD,1,3)          Not In (${L_PIL_036})
  And BES.ACT_SEG_COM_ID_FINAL    Not In ('ACCINTERF','ACCINTERS','ACCINTERC')
  And BES.ACT_SEG_COM_ID_FINAL  <> '${P_PIL_295}'
  And BES.ACT_CD                <> '${P_PIL_067}'
  And BES.ACT_ACTE_FAMILLE_KPI    Not In (${L_PIL_626}) -- NS, NSTECH
  And BES.ORDER_DEPOSIT_DT      >= Current_date - 20
  And BES.HOT_IN                = 1
  And BES.CLOSURE_DT            Is Null
  -- la periode n est pas close
  And ( EtatPeriode.PERIODE_STATUS is Null Or EtatPeriode.PERIODE_STATUS = 'O' )
; 
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_H_BES;
.if errorcode <> 0 then .quit 1;
