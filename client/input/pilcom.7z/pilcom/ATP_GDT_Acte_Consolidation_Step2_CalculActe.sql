-- $HEADER: mm2pco/current/sql/ATP_GDT_Acte_Consolidation_Step2_CalculActe.sql 13_05#5 13-AOU-2019 11:33:53 KPRZ8434
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_GDT_Acte_Consolidation_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 13/08/2019      EVI         Creation
-- 07/10/2019      EVI         Alimentation Champs KPI2020 : FLAG_HD /ACT_ACTE_VALO / ACTE_DELTA_TARIF / ACT_UNITE_CD
-- 15/04/2020      EVI         PILCOM-421 : KPI2020 Lot 2 - Alimentation ACTE_DELTA_TARIF
-- 23/10/2020      EVI         PILCOM-734 : Recalcul sur + de 100 jours
--------------------------------------------------------------------------------

.set width 2500;

------------------------------------------------------------------------------------------
-- Suppression Table 
------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_GDT All;
.if errorcode <> 0 then .quit 1

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_RETURN_GDT;
.if errorcode <> 0 then .quit 1;


------------------------------------------------------------------------------------------
-- Alimentation Table Acte GDT
------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_GDT
(
   ACTE_ID                       ,   
   ACTE_ID_GEN                   ,
   ORDER_DEPOSIT_DT              ,
   ORDER_DEPOSIT_TS              ,
   ORDER_EXTERNAL_ID             ,
   ID_PANIER                     ,
   EXTERNAL_PRODUCT_ID           ,
   INTRNL_SOURCE_ID              ,
   ORG_AGENT_ID                  ,
   ORG_NOM                       ,
   ORG_PRENOM                    ,
   ACT_PRODUCT_ID_FINAL          ,
   ACT_PRODUCT_DS_FINAL          ,
   ACT_SEG_COM_ID_FINAL          ,
   ACT_SEG_COM_AGG_ID_FINAL      ,
   ACT_CODE_MIGR_FINAL           ,
   ACT_OPER_ID_FINAL             ,
   ACT_TYPE_COMMANDE_ID          ,
   ACT_TYPE_SERVICE_FINAL        ,
   ACT_CD                        ,
   ACT_REM_ID                    ,
   ACT_FLAG_ACT_REM              ,
   ACT_FLAG_PEC_PERPVC           ,
   ACT_VALO                      ,
   ACT_ACTE_FAMILLE_KPI          ,
   ACT_PERIODE_ID                ,
   ACT_PERIODE_STATUS            ,
   ACT_PERIODE_CLOSURE_DT        ,
   ACT_CA_LINE_AM                ,
   ACT_CA_TTC_AM                 ,
   ACT_DELTA_TARIF               ,
   ACT_UNITE_CD                  ,
   DMC_LINE_ID                   ,
   DMC_MASTER_LINE_ID            ,
   MSISDN_ID                     ,
   NDS_VALUE_DS                  ,
   EXTERNAL_PARTY_ID             ,
   PAR_MOB_IMEI                  ,
   PAR_MOB_IMSI                  ,
   PAR_DEPARTMNT_ID              ,
   PAR_POSTAL_CD                 ,
   PAR_INSEE_CD                  ,
   PAR_BU_CD                     ,
   PAR_IRIS2000_CD               ,
   PAR_GEO_MACROZONE             ,
   PAR_PARTY_REGRPMNT_ID         ,
   PAR_UNIFIED_PARTY_ID          ,
   PAR_PID_ID                    ,
   PAR_CID_ID                    ,
   PAR_FIRST_IN                  ,
   ORG_AGENT_IOBSP               ,
   ORG_EDO_IOBSP                 ,
   ADDRESS_CONCAT_NM             ,
   PAR_FIBER_IN                  ,
   ORG_EDO_ID                    ,
   ORG_TYPE_EDO                  ,
   ORG_TYPE_CD                   ,
   PAR_LASTNAME                  ,
   PAR_FIRSTNAME                 ,
   PAR_EMAIL                     ,
   UNIFIED_SHOP_CD               ,
   FLAG_HD                       ,
   ORG_CHANNEL_CD                ,
   ORG_SUB_CHANNEL_CD            ,
   ORG_SUB_SUB_CHANNEL_CD        ,
   ORG_GT_ACTIVITY               ,
   ORG_FIDELISATION              ,
   ORG_WEB_ACTIVITY              ,
   ORG_AUTO_ACTIVITY             ,
   ORG_REM_CHANNEL_CD            ,
   ORG_TEAM_LEVEL_1_CD           ,
   ORG_TEAM_LEVEL_1_DS           ,
   ORG_TEAM_LEVEL_2_CD           ,
   ORG_TEAM_LEVEL_2_DS           ,
   ORG_TEAM_LEVEL_3_CD           ,
   ORG_TEAM_LEVEL_3_DS           ,
   ORG_TEAM_LEVEL_4_CD           ,
   ORG_TEAM_LEVEL_4_DS           ,
   WORK_TEAM_LEVEL_1_CD          ,
   WORK_TEAM_LEVEL_1_DS          ,
   WORK_TEAM_LEVEL_2_CD          ,
   WORK_TEAM_LEVEL_2_DS          ,
   WORK_TEAM_LEVEL_3_CD          ,
   WORK_TEAM_LEVEL_3_DS          ,
   WORK_TEAM_LEVEL_4_CD          ,
   WORK_TEAM_LEVEL_4_DS          ,
   PRODUCT_ID_GDT                ,
   ACTE_ID_RETURN                ,
   ORDER_CANCELING_DT            ,  
   CREATION_TS                   ,
   LAST_MODIF_TS                 ,
   FRESH_IN                      ,
   COHERENCE_IN                   
)
Select
   Placement.ACTE_ID                                              As  ACTE_ID                      ,
   Placement.ACTE_ID                                              As  ACTE_ID_GEN                  ,
   Placement.ORDER_DEPOSIT_DT                                     As  ORDER_DEPOSIT_DT             ,
   Placement.ORDER_DEPOSIT_TS                                     As  ORDER_DEPOSIT_TS             ,
   Placement.ID_PANIER                                            As  ORDER_EXTERNAL_ID            ,
   Placement.ID_PANIER                                            As  ID_PANIER                    ,
   Placement.EXTERNAL_PRODUCT_ID                                  As  EXTERNAL_PRODUCT_ID          ,
   Placement.INTRNL_SOURCE_ID                                     As  INTRNL_SOURCE_ID             ,
   Placement.ORG_AGENT_ID                                         As  ORG_AGENT_ID                 ,
   Placement.ORG_NOM                                              As  ORG_NOM                      ,
   Placement.ORG_PRENOM                                           As  ORG_PRENOM                   ,
   ActeRef.PRODUCT_ID_FINAL                                       As  ACT_PRODUCT_ID_FINAL         ,
   ActeRef.PRODUCT_DS_FINAL                                       As  ACT_PRODUCT_DS_FINAL         ,
   ActeRef.SEG_COM_ID_FINAL                                       As  ACT_SEG_COM_ID_FINAL         ,
   ActeRef.SEG_COM_AGG_ID_FINAL                                   As  ACT_SEG_COM_AGG_ID_FINAL     ,
   ActeRef.CODE_MIGR_FINAL                                        As  ACT_CODE_MIGR_FINAL          ,
   ActeRef.TYPE_MVT_FINAL                                         As  ACT_OPER_ID_FINAL            ,
   ActeRef.TYPE_COMMANDE_ID                                       As  ACT_TYPE_COMMANDE_ID         ,
   ActeRef.TYPE_SERVICE_FINAL                                     As  ACT_TYPE_SERVICE_FINAL       ,
   Case 
     -- When Placement.ORDR_TYP_CD ='INIT' Then '${P_PIL_617}'
      When ActeRef.ACT_ID is Not Null Then ActeRef.ACT_ID
      When ActeRef.PERIODE_ID = ${P_PIL_049} Then '${P_PIL_217}' 
      When ActeRef.PRODUCT_ID_FINAL = '${P_PIL_223}' Then '${P_PIL_224}'
      When ActeRef.SEG_COM_ID_FINAL in ('NS') Then '${P_PIL_221}'
      Else '${P_PIL_220}' 
    End                                                           As  ACT_CD                       ,
   ActeRef.ACT_REM_ID                                             As  ACT_REM_ID                   ,
   ActeRef.FLAG_ACT_REM                                           As  ACT_FLAG_ACT_REM             ,
   ActeRef.FLAG_PEC_PERPVC                                        As  ACT_FLAG_PEC_PERPVC          ,
   Case
     -- Unite = NB  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_620}' 
          Then   ActeRef.ACTE_VALO
     -- Unite = CA / MKT / TMX
     When ActeRef.ACT_UNITE_CD IN ('${P_PIL_490}', '${P_PIL_623}', '${P_PIL_622}')  
          Then   ( ACT_DELTA_TARIF * ActeRef.TAUX_MARGE )
     Else Null
   End                                                            As  ACT_ACTE_VALO                ,
   Coalesce(ActeRef.ACTE_FAMILLE_KPI,'NON PARAM')                 As  ACT_ACTE_FAMILLE_KPI         ,
   ActeRef.PERIODE_ID                                             As  ACT_PERIODE_ID               ,
   Coalesce(EtatPeriode.PERIODE_STATUS,'O')                       As  ACT_PERIODE_STATUS           ,
   EtatPeriode.PERIODE_CLOSURE_DT                                 As  ACT_PERIODE_CLOSURE_DT       ,
   Case
     -- Unité = NB  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_620}' Then
          Case 
            When Mat.ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
              Then Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0) 
            Else ActeRef.TERMINAL_PRICE_HT
          End
     -- Unite = CA / MKT / TMX
     When ActeRef.ACT_UNITE_CD IN ('${P_PIL_490}', '${P_PIL_623}', '${P_PIL_622}')  
          Then   ACT_DELTA_TARIF
     Else Null
   End                                                            As  ACT_CA_LINE_AM               ,
   Case
     -- Unité = CA  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_490}' 
          Then   ActeRef.TERMINAL_PRICE
     -- Unité = NB  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_620}' 
          Then   ActeRef.TERMINAL_PRICE
     -- Unité = MKT 
     When ActeRef.ACT_UNITE_CD ='${P_PIL_623}' 
          Then   Null
     -- Unité = CA_CALIPSO  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_622}' 
          Then   Coalesce (EAN_Canal_WEB.PRICE_TTC, EAN_Canal_DOM.PRICE_TTC, 0)
     Else Null
   End                                                            As  ACT_CA_TTC_AM                ,
   Case
     -- Unite = CA  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_490}' 
          Then   ActeRef.TERMINAL_PRICE_HT
     -- Unite = NB  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_620}' Then
          Case 
            When Mat.ACTE_FAMILLE_KPI LIKE '${P_PIL_628}'
              Then Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0) 
            Else Null
          End
     -- Unite = MKT
     When ActeRef.ACT_UNITE_CD ='${P_PIL_623}' 
          Then   ActeRef.CA_MARKETING
     -- Unite = CA_CALIPSO (TMX)  
     When ActeRef.ACT_UNITE_CD ='${P_PIL_622}' 
          Then  Coalesce (EAN_Canal_WEB.PRICE_HT, EAN_Canal_DOM.PRICE_HT, 0)  
     Else Null
   End                                                            As  ACT_DELTA_TARIF              ,         
   ActeRef.ACT_UNITE_CD                                           As  ACT_UNITE_CD                 ,
   Placement.DMC_LINE_ID                                          As  DMC_LINE_ID                  ,
   Placement.DMC_MASTER_LINE_ID                                   As  DMC_MASTER_LINE_ID           ,
   Placement.MSISDN_ID                                            As  MSISDN_ID                    ,
   Placement.NDS_VALUE_DS                                         As  NDS_VALUE_DS                 ,
   Placement.EXTERNAL_PARTY_ID                                    As  EXTERNAL_PARTY_ID            ,
   Placement.PAR_MOB_IMEI                                         As  PAR_MOB_IMEI                 ,
   Placement.PAR_MOB_IMSI                                         As  PAR_MOB_IMSI                 ,
   Placement.PAR_DEPARTMNT_ID                                     As  PAR_DEPARTMNT_ID             ,
   Placement.PAR_POSTAL_CD                                        As  PAR_POSTAL_CD                ,
   Placement.PAR_INSEE_CD                                         As  PAR_INSEE_CD                 ,
   Placement.PAR_BU_CD                                            As  PAR_BU_CD                    ,
   Placement.PAR_IRIS2000_CD                                      As  PAR_IRIS2000_CD              ,
   Placement.PAR_GEO_MACROZONE                                    As  PAR_GEO_MACROZONE            ,
   Placement.PAR_PARTY_REGRPMNT_ID                                As  PAR_PARTY_REGRPMNT_ID        ,
   Placement.PAR_UNIFIED_PARTY_ID                                 As  PAR_UNIFIED_PARTY_ID         ,
   Placement.PAR_PID_ID                                           As  PAR_PID_ID                   ,
   Placement.PAR_CID_ID                                           As  PAR_CID_ID                   ,
   Placement.PAR_FIRST_IN                                         As  PAR_FIRST_IN                 ,
   Null                                                           As  ORG_AGENT_IOBSP              ,
   Placement.ORG_EDO_IOBSP                                        As  ORG_EDO_IOBSP                ,
   Placement.ADDRESS_CONCAT_NM                                    As  ADDRESS_CONCAT_NM            ,
   Null                                                           As  PAR_FIBER_IN                 ,
   Placement.EDO_ID                                               As  ORG_EDO_ID                   ,
   Placement.ORG_TYPE_EDO_CHANNEL                                 As  ORG_TYPE_EDO                 ,
   Placement.ORG_TYPE_CD                                          As  ORG_TYPE_CD                  ,
   Null                                                           As  PAR_LASTNAME                 ,
   Null                                                           As  PAR_FIRSTNAME                ,
   Null                                                           As  PAR_EMAIL                    ,
   Placement.UNIFIED_SHOP_CD                                      As  UNIFIED_SHOP_CD              ,
   ActeRef.HUMAINDIGITAL                                              As  FLAG_HD                      ,
   Placement.ORG_CHANNEL_CD                                       As  ORG_CHANNEL_CD               ,
   Placement.ORG_SUB_CHANNEL_CD                                   As  ORG_SUB_CHANNEL_CD           ,
   Placement.ORG_SUB_SUB_CHANNEL_CD                               As  ORG_SUB_SUB_CHANNEL_CD       ,
   Placement.ORG_GT_ACTIVITY                                      As  ORG_GT_ACTIVITY              ,
   Placement.ORG_FIDELISATION                                     As  ORG_FIDELISATION             ,
   Placement.ORG_WEB_ACTIVITY                                     As  ORG_WEB_ACTIVITY             ,
   Placement.ORG_AUTO_ACTIVITY                                    As  ORG_AUTO_ACTIVITY            ,
   Placement.ORG_REM_CHANNEL_CD                                   As  ORG_REM_CHANNEL_CD           ,
   Trim(Placement.ORG_TEAM_LEVEL_1_CD)                            As  ORG_TEAM_LEVEL_1_CD          ,
   Placement.ORG_TEAM_LEVEL_1_DS                                  As  ORG_TEAM_LEVEL_1_DS          ,
   Trim(Placement.ORG_TEAM_LEVEL_2_CD)                            As  ORG_TEAM_LEVEL_2_CD          ,
   Placement.ORG_TEAM_LEVEL_2_DS                                  As  ORG_TEAM_LEVEL_2_DS          ,
   Trim(Placement.ORG_TEAM_LEVEL_3_CD)                            As  ORG_TEAM_LEVEL_3_CD          ,
   Placement.ORG_TEAM_LEVEL_3_DS                                  As  ORG_TEAM_LEVEL_3_DS          ,
   Trim(Placement.ORG_TEAM_LEVEL_4_CD)                            As  ORG_TEAM_LEVEL_4_CD          ,
   Placement.ORG_TEAM_LEVEL_4_DS                                  As  ORG_TEAM_LEVEL_4_DS          ,
   trim(CAST(Placement.WORK_TEAM_LEVEL_1_CD AS VARCHAR(18)))      As  WORK_TEAM_LEVEL_1_CD         ,
   Placement.WORK_TEAM_LEVEL_1_DS                                 As  WORK_TEAM_LEVEL_1_DS         ,
   trim(CAST(Placement.WORK_TEAM_LEVEL_2_CD AS VARCHAR(18)))      As  WORK_TEAM_LEVEL_2_CD         ,
   Placement.WORK_TEAM_LEVEL_2_DS                                 As  WORK_TEAM_LEVEL_2_DS         ,
   CAST(Placement.WORK_TEAM_LEVEL_3_CD AS VARCHAR(18))            As  WORK_TEAM_LEVEL_3_CD         ,
   Placement.WORK_TEAM_LEVEL_3_DS                                 As  WORK_TEAM_LEVEL_3_DS         ,
   CAST(Placement.WORK_TEAM_LEVEL_4_CD AS VARCHAR(18))            As  WORK_TEAM_LEVEL_4_CD         ,
   Placement.WORK_TEAM_LEVEL_4_DS                                 As  WORK_TEAM_LEVEL_4_DS         ,
   ActeRef.PRODUCT_ID_GDT                                         As  PRODUCT_ID_GDT               ,
   Placement.ACTE_ID_RETURN                                       As  ACTE_ID_RETURN               ,
   Placement.ORDER_CANCELING_DT                                   As  ORDER_CANCELING_DT           ,  
   Current_Timestamp(0)                                           As  CREATION_TS                  ,
   Current_Timestamp(0)                                           As  LAST_MODIF_TS                ,
   1                                                              As  FRESH_IN                     ,
   0                                                              As  COHERENCE_IN                  
From
    ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_GDT Placement
  Inner Join ${KNB_PCO_TMP}.ORD_W_ACTE_GDT_CALC ActeRef
    On    Placement.ACTE_ID                       = ActeRef.ACTE_ID
      And Placement.ORDER_DEPOSIT_DT              = ActeRef.ORDER_DEPOSIT_DT
       --Jointure avec V_CAT_R_CLOSED_PERIOD_PILCOM
  Left outer join ${KNB_PCO_REFCOM}.V_CAT_R_CLOSED_PERIOD_PILCOM EtatPeriode
  On    EtatPeriode.PERIODE_ID     = ActeRef.PERIODE_ID
    And EtatPeriode.CURRENT_IN     = 1
    And EtatPeriode.FRESH_IN       = 1
    And EtatPeriode.CLOSURE_DT     Is Null
  Left Outer Join ${KNB_PCO_TMP}.CAT_W_SOFT_REFCOM_JOUR_MATRICE_GDT Mat
    --On réinterprete ici les commandes qui était en ADP et qui sorte en aquisition => On le remet en maintient
    On    ActeRef.TYPE_COMMANDE_ID                = Mat.TYPE_COMMANDE_ID
      And '${P_PIL_211}'                          = Mat.SEG_COM_ID_INI
      And ActeRef.SEG_COM_ID_FINAL                = Mat.SEG_COM_ID_FINAL
      And ActeRef.PERIODE_ID                      = Mat.PERIODE_ID
  -- KPI2020 : Jointure Referentiel CALIPSO
  Left Outer Join  ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_WEB
     On EAN_Canal_WEB.EAN_CD = Placement.EXTERNAL_PRODUCT_ID
     And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_WEB.BEGN_PRICE_DT And Coalesce(EAN_Canal_WEB.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_WEB.DISTRBTN_CHANNL_ID = '${P_PIL_624}'
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORD_F_CALIPSO_PVC  EAN_Canal_DOM
     On  EAN_Canal_DOM.EAN_CD = Placement.EXTERNAL_PRODUCT_ID
     And Placement.ORDER_DEPOSIT_DT Between EAN_Canal_DOM.BEGN_PRICE_DT And Coalesce(EAN_Canal_DOM.END_PRICE_DT, Cast('31/12/2999' As Date Format 'DD/MM/YYYY'))
     And EAN_Canal_DOM.DISTRBTN_CHANNL_ID = '${P_PIL_625}'

Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ACTE_GDT;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------------------------
-- Traitement Gestion Retour GDT
------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_RETURN_GDT
(
    ACTE_ID_RETURN
  , ACTE_ID_CANCELED
  , ID_PANIER
  , EXTERNAL_PRODUCT_ID
  , ORDER_DEPOSIT_DT
  , ORDER_CANCELING_DT
)
SELECT 
       RetourGDT.ACTE_ID                                            AS ACTE_ID_RETURN
      ,RefActe.ACTE_ID                                              AS ACTE_ID_CANCELED
      ,RetourGDT.PANIER_ID_ORIGINE                                  AS ID_PANIER
      ,RetourGDT.EXTERNAL_PRODUCT_ID                                AS EXTERNAL_PRODUCT_ID
      ,Cast(RetourGDT.ORDER_ORIGINE_TS as DATE FORMAT 'DD/MM/YYYY') AS ORDER_DEPOSIT_DT
      ,RetourGDT.ORDER_DEPOSIT_DT                                   AS ORDER_CANCELING_DT
FROM ${KNB_PCO_TMP}.ORD_T_ACTE_GDT RefActe
 Inner Join ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_GDT RetourGDT
   On RefActe.ID_PANIER            =  RetourGDT.PANIER_ID_ORIGINE
  And RefActe.EXTERNAL_PRODUCT_ID  =  RetourGDT.EXTERNAL_PRODUCT_ID
  And RefActe.ORDER_DEPOSIT_DT     =  Cast(RetourGDT.ORDER_ORIGINE_TS as DATE FORMAT 'DD/MM/YYYY')
  And RetourGDT.TYPE_VENTE = 'RETOUR'
Where
  (1=1)
  And RetourGDT.ACTE_ID_CANCELED Is Null
  And RefActe.ACTE_ID_RETURN     Is Null
Qualify Row_Number() Over (Partition by RetourGDT.ACTE_ID Order by RetourGDT.ACTE_ID,RefActe.ACTE_ID Asc) = Row_Number() Over (Partition by RefActe.ACTE_ID Order by RetourGDT.ACTE_ID,RefActe.ACTE_ID Asc)
;
.if errorcode <> 0 then .quit 1


Update ActeGDTCanceled
  From ${KNB_PCO_TMP}.ORD_T_ACTE_GDT ActeGDTCanceled
      ,${KNB_PCO_TMP}.ORD_W_ACTE_RETURN_GDT RetourGDT
Set  ACTE_ID_RETURN     = RetourGDT.ACTE_ID_RETURN
    ,ORDER_CANCELING_DT = RetourGDT.ORDER_CANCELING_DT
Where (1=1)
  And ActeGDTCanceled.ACTE_ID = RetourGDT.ACTE_ID_CANCELED
;
.if errorcode <> 0 then .quit 1

Update PlacementGDTCanceled
  From ${KNB_PCO_SOC}.ORD_F_PLACEMENT_GDT PlacementGDTCanceled
      ,${KNB_PCO_TMP}.ORD_W_ACTE_RETURN_GDT RetourGDT
Set  ACTE_ID_RETURN     = RetourGDT.ACTE_ID_RETURN
    ,ORDER_CANCELING_DT = RetourGDT.ORDER_CANCELING_DT
Where (1=1)
  And PlacementGDTCanceled.ACTE_ID = RetourGDT.ACTE_ID_CANCELED
;
.if errorcode <> 0 then .quit 1

Update PlacementGDTReturn
  From ${KNB_PCO_SOC}.ORD_F_PLACEMENT_GDT PlacementGDTReturn
      ,${KNB_PCO_TMP}.ORD_W_ACTE_RETURN_GDT RetourGDT
Set ACTE_ID_CANCELED = RetourGDT.ACTE_ID_CANCELED
Where (1=1)
  And PlacementGDTReturn.ACTE_ID = RetourGDT.ACTE_ID_RETURN
;
.if errorcode <> 0 then .quit 1


.quit 0