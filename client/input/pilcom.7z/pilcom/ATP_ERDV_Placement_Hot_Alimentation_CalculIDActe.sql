-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Placement_Hot_Alimentation_CalculIDActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement de placement à chaud pour ERDV
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 06/01/2014      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H All;
.if errorcode <> 0 then .quit 1



----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H
(
    ACTE_ID,                            
    EXTERNAL_ACTE_ID,                   
    INTRNL_SOURCE_ID,                   
    EXTERNAL_ORDER_ID,                  
    ORDER_DEPOSIT_TS,                   
    ORDER_DEPOSIT_DT,                   
    INTERVENTION_ID,                   
    ORDER_LINE_EXTERNAL_ID,             
    ORDER_LINE_STATUS_CD,               
    TYPE_OP_NM,
    AGENT_ID,                           
    ACTIVITY_UNIT_CD,                   
    CONTRACT_CUSTOMER_LAST_NAME,        
    CONTRACT_CUSTOMER_MARKET_SEG,       
    CONTACT_CIVILITY_NM,                
    CONTACT_LAST_NAME_NM,               
    CONTACT_FIRST_NAME_NM,                 
    CONTACT_MOBILE_NUMBER_NU,           
    CONTACT_TEL_NUMBER_NU,              
    REF_GROUPED_OFFER_CD,               
    GPC_ID,                             
    STATUS_INTERVENTION_CD,             
    DATE_RESERVATION_TS,                
    DATE_BEGIN_TS,                      
    REF_ERDV_CD,                        
    ORDER_LINE_CONTRACT_DATE_TS,        
    ORDER_LINE_WANTED_DATE_TS,          
    ORDER_LINE_PREST_CD,               
    ORDER_LINE_QUANTITY_QT,             
    ORDER_LINE_AMOUNT_AM,               
    ORDER_LINE_TVA_RT,                  
    ORDER_LINE_OPER_CD,                 
    DELIVERY_CUSTOMER_MARKET_SEG,       
    DELIVERY_CUSTOMER_LAST_NAME,        
    DELIVERY_CUSTOMER_ADDRESS_APPT,     
    DELIVERY_CUSTOMER_ADDRESS_ESC,      
    DELIVERY_CUSTOMER_ADDRESS_STG,      
    DELIVERY_CUSTOMER_ADDRESS_BAT,      
    DELIVERY_CUSTOMER_ADDRESS_RES,      
    DELIVERY_CUSTOMER_ADDRESS_ZIP,      
    DELIVERY_CUSTOMER_ADDRESS_NUM,     
    DELIVERY_CUSTOMER_ADDRESS_ST_T,     
    DELIVERY_CUSTOMER_ADDRESS_STR,      
    DELIVERY_CUSTOMER_ADDRESS_CITY,     
    DELIVERY_CUSTOMER_ADDRESS_INSE,     
    REF_OFFRE_CIBLE_CD,                 
    CATALOGUE_CD,                       
    CUSTOMER_ND_NU,                     
    CUSTOMER_NDS_NU,                    
    QUEUE_TS,                           
    RUN_ID,                             
    STREAMING_TS,                       
    CREATION_TS,                        
    LAST_MODIF_TS,                      
    HOT_IN,                             
    FRESH_IN,                           
    COHERENCE_IN                       
)   
Select
  ActeId.ACTE_ID                                           as ACTE_ID,                                       
  Placement.EXTERNAL_ACTE_ID                               as EXTERNAL_ACTE_ID,                             
  Placement.INTRNL_SOURCE_ID                               as INTRNL_SOURCE_ID,                             
  Placement.EXTERNAL_ORDER_ID                              as EXTERNAL_ORDER_ID,                            
  Placement.ORDER_DEPOSIT_TS                               as ORDER_DEPOSIT_TS,                             
  Placement.ORDER_DEPOSIT_DT                               as ORDER_DEPOSIT_DT,                             
  Placement.INTERVENTION_ID                                as INTERVENTION_ID,                              
  Placement.ORDER_LINE_EXTERNAL_ID                         as ORDER_LINE_EXTERNAL_ID,                       
  Placement.ORDER_LINE_STATUS_CD                           as ORDER_LINE_STATUS_CD,                         
  Placement.TYPE_OP_NM                                     as TYPE_OP_NM,
  Placement.AGENT_ID                                       as AGENT_ID,                                     
  Placement.ACTIVITY_UNIT_CD                               as ACTIVITY_UNIT_CD,                             
  Placement.CONTRACT_CUSTOMER_LAST_NAME                    as CONTRACT_CUSTOMER_LAST_NAME,                  
  Placement.CONTRACT_CUSTOMER_MARKET_SEG                   as CONTRACT_CUSTOMER_MARKET_SEG,                 
  Placement.CONTACT_CIVILITY_NM                            as CONTACT_CIVILITY_NM,                          
  Placement.CONTACT_LAST_NAME_NM                           as CONTACT_LAST_NAME_NM,                         
  Placement.CONTACT_FIRST_NAME_NM                          as CONTACT_FIRST_NAME,
  Placement.CONTACT_MOBILE_NUMBER_NU                       as CONTACT_MOBILE_NUMBER_NU,
  Placement.CONTACT_TEL_NUMBER_NU                          as CONTACT_TEL_NUMBER_NU,
  Placement.REF_GROUPED_OFFER_CD                           as REF_GROUPED_OFFER_CD,
  Placement.GPC_ID                                         as GPC_ID,
  Placement.STATUS_INTERVENTION_CD                         as STATUS_INTERVENTION_CD,
  Placement.DATE_RESERVATION_TS                            as DATE_RESERVATION_TS,
  Placement.DATE_BEGIN_TS                                  as DATE_BEGIN_TS,
  Placement.REF_ERDV_CD                                    as REF_ERDV_CD,
  Placement.ORDER_LINE_CONTRACT_DATE_TS                    as ORDER_LINE_CONTRACT_DATE_TS,
  Placement.ORDER_LINE_WANTED_DATE_TS                      as ORDER_LINE_WANTED_DATE_TS,
  Placement.ORDER_LINE_PREST_CD                            as ORDER_LINE_PREST_CD,
  Placement.ORDER_LINE_QUANTITY_QT                         as ORDER_LINE_QUANTITY_QT,
  Placement.ORDER_LINE_AMOUNT_AM                           as ORDER_LINE_AMOUNT_AM,
  Placement.ORDER_LINE_TVA_RT                              as ORDER_LINE_TVA_RT,
  Placement.ORDER_LINE_OPER_CD                             as ORDER_LINE_OPER_CD,
  Placement.DELIVERY_CUSTOMER_MARKET_SEG                   as DELIVERY_CUSTOMER_MARKET_SEG,
  Placement.DELIVERY_CUSTOMER_LAST_NAME                    as DELIVERY_CUSTOMER_LAST_NAME,
  Placement.DELIVERY_CUSTOMER_ADDRESS_APPT                 as DELIVERY_CUSTOMER_ADDRESS_APPT,
  Placement.DELIVERY_CUSTOMER_ADDRESS_ESC                  as DELIVERY_CUSTOMER_ADDRESS_ESC,
  Placement.DELIVERY_CUSTOMER_ADDRESS_STG                  as DELIVERY_CUSTOMER_ADDRESS_STG,
  Placement.DELIVERY_CUSTOMER_ADDRESS_BAT                  as DELIVERY_CUSTOMER_ADDRESS_BAT,
  Placement.DELIVERY_CUSTOMER_ADDRESS_RES                  as DELIVERY_CUSTOMER_ADDRESS_RES,
  Placement.DELIVERY_CUSTOMER_ADDRESS_ZIP                  as DELIVERY_CUSTOMER_ADDRESS_ZIP,
  Placement.DELIVERY_CUSTOMER_ADDRESS_NUM                  as DELIVERY_CUSTOMER_ADDRESS_NUM,
  Placement.DELIVERY_CUSTOMER_ADDRESS_ST_T                 as DELIVERY_CUSTOMER_ADDRESS_ST_T,
  Placement.DELIVERY_CUSTOMER_ADDRESS_STR                  as DELIVERY_CUSTOMER_ADDRESS_STR,
  Placement.DELIVERY_CUSTOMER_ADDRESS_CITY                 as DELIVERY_CUSTOMER_ADDRESS_CITY,
  Placement.DELIVERY_CUSTOMER_ADDRESS_INSE                 as DELIVERY_CUSTOMER_ADDRESS_INSE,
  Placement.REF_OFFRE_CIBLE_CD                             as REF_OFFRE_CIBLE_CD,
  Placement.CATALOGUE_CD                                   as CATALOGUE_CD,
  Placement.CUSTOMER_ND_NU                                 as CUSTOMER_ND_NU,
  Placement.CUSTOMER_NDS_NU                                as CUSTOMER_NDS_NU,
  Placement.QUEUE_TS                                       as QUEUE_TS,
  Placement.RUN_ID                                         as RUN_ID,
  Placement.STREAMING_TS                                   as STREAMING_TS,
  Placement.CREATION_TS                                    as CREATION_TS,
  Placement.LAST_MODIF_TS                                  as LAST_MODIF_TS,
  1                                                        as HOT_IN,
  1                                                        as FRESH_IN,
  0                                                        as COHERENCE_IN
From
  --On prend tout le contenu de la table miroir tmp
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H_EXT Placement
  --On jointe avec la table referentiel pour générer le bon nombre de ligne
  Inner Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN ActeId
    On    Placement.EXTERNAL_ACTE_ID          = ActeId.EXTERNAL_ACTE_ID
      And Placement.TYPE_SOURCE_ID            = ActeId.TYPE_SOURCE_ID
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERDV_H;
.if errorcode <> 0 then .quit 1

.quit 0
