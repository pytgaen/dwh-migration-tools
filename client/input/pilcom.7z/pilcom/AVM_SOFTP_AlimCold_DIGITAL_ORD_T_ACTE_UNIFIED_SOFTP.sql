-- $HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_SOFTP_AlimCold_DIGITAL_ORD_T_ACTE_UNIFIED_SOFTP.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source SOFTP dans la table ORD_T_ACTE_UNIFIED_SOFTP  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
--22/07/2019      SSI         Creation
--07/05/2020      YAB         Modification de l'alimentation ACT_CA_LINE_AM SOFT PCM KPI2020
--02/07/2020      TCL         Rajout du SIM_CD et SIM_EAN_CD
-- 13/10/2020     EVI         PILCOM-724 : Gestion Retour PVC - Correction Bug ecrasement CUID
-- 28/04/2021     EVI         PILCOM-800 : REFONTE DIGITAL - Alimentation EXTERNAL_PARTY_ID
-- 22/06/2021     BCH         PILCOM-944 : Suppression des colonnes obsolètes de ORD_T_ACTE_UNIFIED_SOFTP
--------------------------------------------------------------------------------
.set width 5000

--------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_SOFTP --
--------------------------------------



Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTP
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  ORG_AGENT_IOBSP               ,
  ORG_EDO_IOBSP                 ,
  PAR_IRIS2000_CD               ,
  ACT_CA_LINE_AM                ,
  --------
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  EAN_CD                        ,
  ORG_RESP_ID                   ,
   --Ajout QC 712 : Ajout Code TAC,EAN,IMEI
  TAC_PREVIOUS_CD               ,
  IMEI_PREVIOUS_CD              ,
  EAN_PREVIOUS_CD               ,
  PCM_PREVIOUS_OFFRE_CD         ,
  COMMARTICLE_RP_REFPRIX_CD     ,
    --Fin  QC 712 
  PCM_COMMTMNT_PERIOD_NU        ,
  PCM_LEVEL_POINT_NU            ,
  PCM_OFFRE_CD                  ,
  PCM_EFFCTV_NEXT_OFFRE_DT      ,
  PCM_TYPE_OFFRE_MOBILE_CD      ,
  PCM_POINT_UTIL_NU             ,
  PCM_BALANCE_POINT_NU          ,
  PCM_STATUT_POINT_CD           ,
  PCM_POINT_DUE_NU              ,
  --------
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                  
)
Select
  SFP.ACTE_ID_GEN                                                          As ACTE_ID,
  SFP.OPERATOR_PROVIDER_ID                                                 As OPERATOR_PROVIDER_ID,
  SFP.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID,
  '${P_PIL_369}'                                                           As TYPE_SOURCE_ID,
  SFP.ACTE_ID_GEN                                                          As MASTER_ACTE_ID,
  SFP.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID,
  ${P_PIL_354}                                                             AS MASTER_FLAG,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND,
  DIGITAL.ACTE_ID_INTRCTN                                                  As CPLT_ACTE_ID                 ,
  -- Si c'est un traçage Auto ALors c'est ReFoce => 11 ou ETASK ->16
   Case  When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then  31 -- code de la source JRC
    Else Null
  End                                                                       As CPLT_INTRNL_SOURCE_ID       ,
   Case  When DIGITAL.ACTE_ID_INTRCTN In ('${P_INT_031}','${P_PIL_520}')  
          Then  '${P_PIL_356}'
        When DIGITAL.ACTE_ID_INTRCTN Is Not Null  
          Then  '${P_PIL_356}'
        Else    '${P_PIL_357}'
  End                                                                       As CPLT_IN                     ,
  Case  When SFP.CPLT_ACTE_ID = '${P_INT_031}'  
          Then  '${P_PIL_048}'
        When SFP.CPLT_ACTE_ID = '${P_PIL_520}'  
          Then  '${P_PIL_521}'    
       When  SFP.CPLT_ACTE_ID Not In ('${P_INT_031}','${P_PIL_520}')  
          Then '${P_PIL_436}'
      When  SFP.CPLT_ACTE_ID is Null
         Then  '${P_PIL_362}'
  End                                                                       As RULE_ID                      ,
  Null                                                                     As OFFSET_NB,
  '${P_PIL_325}'                                                           As ACT_TYPE,
  Case When SFP.ORDER_REF_EXTERNAL_ID Is Null
        Then SFP.ORDER_EXTERNAL_ID
        Else SFP.ORDER_REF_EXTERNAL_ID
  End                                                                      As ORDER_EXTERNAL_ID,
  SFP.ORDER_LAST_STATUT_CD                                                 As STATUS_CD,
  Case When SFP.CONCURENCE_IN = '${P_PIL_356}' Then '${P_PIL_385}'
       When SFP.CONFIRMATION_IN = '${P_PIL_357}' Then '${P_PIL_386}' 
       When SFP.PERENNITE_IN = '${P_PIL_356}' Then '${P_PIL_384}' 
       When SFP.DELIVERY_IN = '${P_PIL_356}' And SFP.PERENNITE_IN = '${P_PIL_357}' Then '${P_PIL_387}' 
       When SFP.DELIVERY_IN = '${P_PIL_356}' Then '${P_PIL_383}' 
       When SFP.CONFIRMATION_IN = '${P_PIL_356}' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                      As ACT_UNIFIED_STATUS_CD,
  SFP.ORDER_DEPOSIT_TS                                                     As ACT_TS,
  SFP.ORDER_DEPOSIT_DT                                                     As ACT_DT,
  Extract(HOUR From SFP.ORDER_DEPOSIT_TS)                                  As ACT_HH,
  SFP.ORDER_LAST_STATUT_MODIF_TS                                           As ACT_LAST_UPD_TS,
  SFP.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE,
  SFP.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE,
  SFP.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE,
  SFP.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE,
  SFP.ACT_OPER_ID_PRE                                                      As ACT_OPER_ID_PRE,
  SFP.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL,
  SFP.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL,
  SFP.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL,
  SFP.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL,
  SFP.ACT_OPER_ID_FINAL                                                    As ACT_OPER_ID_FINAL,
  SFP.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL,
  SFP.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID,
  SFP.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF,
  SFP.ACT_CD                                                               As ACT_CD,
  SFP.ACT_REM_ID                                                           As ACT_REM_ID,
  SFP.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM,
  SFP.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC,
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And SFP.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And SFP.ORG_AGENT_ID_UPD Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And SFP.ORG_REM_CHANEL_CD IN (${L_PIL_043}) 
                    --L'acte ne doit pas être déjà en parc (Condition de vente conclue)
                    --And SFI.SEG_PRES_PARC_COMMANDE  = 0
                    --L'acte ne doit pas être annulé
                    And SFP.CLOSURE_DT              Is Null
                    --Remarque Le statut SFI.ORDER_LAST_STATUT_CD de la commande est géré apres dans GRV
                    --Remarque Le statut CSO SFI.CHECK_NAT_STATUS_CD de la commande est géré apres dans GRV
                )
        Then 'O' 
       Else 'N'  
  End                                                                      As ACT_FLAG_PVC_REM,
  SFP.ACT_ACTE_VALO                                                        As ACT_ACTE_VALO,
  SFP.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI,
  SFP.ACT_PERIODE_ID                                                       As ACT_PERIODE_ID,
  SFP.ACT_PERIODE_STATUS                                                   As ACT_PERIODE_STATUS             ,
  SFP.ACT_PERIODE_CLOSURE_DT                                               As ACT_PERIODE_CLOSURE_DT         ,
  Null                                                                     As ORIGIN_CD,
 Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Trim (DIGITAL.INT_OPRTR_ID)
    Else Trim(SFP.ORG_AGENT_ID)
  End                                                                      As AGENT_ID                        ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null And SFP.ORG_AGENT_ID_UPD_DT Is Null
    Then Trim (DIGITAL.INT_OPRTR_ID)
    Else Trim(SFP.ORG_AGENT_ID_UPD)
  End                                                                      As AGENT_ID_UPD                    ,
  SFP.ORG_AGENT_ID_UPD_DT                                                  As AGENT_ID_UPD_DT                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFP.ORG_PRENOM
  End                                                                      As AGENT_FIRST_NAME                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFP.ORG_NOM
  End                                                                      As AGENT_LAST_NAME                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_UNIFIED_SHOP_CD
    Else SFP.ORG_STORE_NAME
  End                                                                      As UNIFIED_SHOP_CD                 ,
  Null                                                                     As ORG_SPE_CANAL_ID_MACRO          ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFP.ORG_CANAL_ID
  End                                                                      As ORG_SPE_CANAL_ID                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_REM_CHANNEL_CD
    Else SFP.ORG_REM_CHANEL_CD
  End                                                                      As ORG_REM_CHANNEL_CD              ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_CHANNEL_CD
    Else SFP.ORG_CHANEL_CD
  End                                                                      As ORG_CHANNEL_CD                  ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_CHANNEL_CD
    Else SFP.ORG_SUB_CHANEL_CD
  End                                                                      As ORG_SUB_CHANNEL_CD              ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_SUB_SUB_CHANNEL_CD
    Else SFP.ORG_SUB_SUB_CHANEL_CD
  End                                                                      As ORG_SUB_SUB_CHANNEL_CD          ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_GT_ACTIVITY
    Else SFP.ORG_GT_ACTIVITY
  End                                                                      As ORG_GT_ACTIVITY                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_FIDELISATION
    Else SFP.ORG_FIDELISATION
  End                                                                      As ORG_FIDELISATION                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_WEB_ACTIVITY
    Else SFP.ORG_WEB_ACTIVITY
  End                                                                      As ORG_WEB_ACTIVITY                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_AUTO_ACTIVITY
    Else SFP.ORG_AUTO_ACTIVITY
  End                                                                      As ORG_AUTO_ACTIVITY               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_ID
    Else SFP.ORG_EDO_ID
  End                                                                      As ORG_EDO_ID                      ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TYPE_EDO
    Else SFP.ORG_TYPE_EDO
  End                                                                      As ORG_TYPE_EDO                    ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFP.ORG_FLAG_PLT_CONV
  End                                                                      As ORG_FLAG_PLT_CONV               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFP.ORG_FLAG_TEAM_MKT
  End                                                                      As ORG_FLAG_TEAM_MKT               ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then Null
    Else SFP.ORG_FLAG_TYPE_CMP
  End                                                                      As ORG_FLAG_TYPE_CMP               ,
  Null                                                                     As ORG_RESP_EDO_ID                 ,
  Null                                                                     As ORG_RESP_TYPE_EDO               ,
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV          ,
  Null                                                                     As ACTIVITY_CD                     ,
  Null                                                                     As ACTIVITY_GROUPNG_CD             ,
  Null                                                                     As AUTO_ACTIVITY_IN                ,
  '${P_PIL_366}'                                                           As ORG_TYPE_CD                     ,
  Null                                                                     As ORG_TEAM_TYPE_ID                ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_CD
    Else Trim(SFP.ORG_TEAM_LEVEL_1_CD)
  End                                                                      As ORG_TEAM_LEVEL_1_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_1_DS
    Else Trim(SFP.ORG_TEAM_LEVEL_1_DS)
  End                                                                      As ORG_TEAM_LEVEL_1_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_CD
    Else Trim(SFP.ORG_TEAM_LEVEL_2_CD)
  End                                                                      As ORG_TEAM_LEVEL_2_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_2_DS
    Else Trim(SFP.ORG_TEAM_LEVEL_2_DS)
  End                                                                      As ORG_TEAM_LEVEL_2_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_CD
    Else Trim(SFP.ORG_TEAM_LEVEL_3_CD)
  End                                                                      As ORG_TEAM_LEVEL_3_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_3_DS
    Else Trim(SFP.ORG_TEAM_LEVEL_3_DS)
  End                                                                      As ORG_TEAM_LEVEL_3_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_CD
    Else Trim(SFP.ORG_TEAM_LEVEL_4_CD)
  End                                                                      As ORG_TEAM_LEVEL_4_CD             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_TEAM_LEVEL_4_DS
    Else Trim(SFP.ORG_TEAM_LEVEL_4_DS)
  End                                                                      As ORG_TEAM_LEVEL_4_DS             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_CD
    Else Trim(SFP.WORK_TEAM_LEVEL_1_CD)
  End                                                                      As WORK_TEAM_LEVEL_1_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_1_DS
    Else Trim(SFP.WORK_TEAM_LEVEL_1_DS)
  End                                                                      As WORK_TEAM_LEVEL_1_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_CD
    Else Trim(SFP.WORK_TEAM_LEVEL_2_CD)
  End                                                                      As WORK_TEAM_LEVEL_2_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_2_DS
    Else Trim(SFP.WORK_TEAM_LEVEL_2_DS)
  End                                                                      As WORK_TEAM_LEVEL_2_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_CD
    Else Trim(SFP.WORK_TEAM_LEVEL_3_CD)
  End                                                                      As WORK_TEAM_LEVEL_3_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_3_DS
    Else Trim(SFP.WORK_TEAM_LEVEL_3_DS)
  End                                                                      As WORK_TEAM_LEVEL_3_DS            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_CD
    Else Trim(SFP.WORK_TEAM_LEVEL_4_CD)
  End                                                                      As WORK_TEAM_LEVEL_4_CD            ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_WORK_TEAM_LEVEL_4_DS
    Else Trim(SFP.WORK_TEAM_LEVEL_4_DS)
  End                                                                      As WORK_TEAM_LEVEL_4_DS            ,
  SFP.CONFIRMATION_IN                                                      As CONFIRMATION_IN,
  Null                                                                     As MIGRA_DT                      ,
  Null                                                                     As MIGRA_NEXT_OFFRE              ,
  0                                                                        As PRES_SEGMENT_IN_PARK_BEFORE_IN   ,
  Null                                                                     As SEGMENT_DELIVERY_IN_PARK_DT      ,
  SFP.ORDER_CANCELING_DT                                                   As ORDER_CANCELING_DT               ,
  SFP.DMC_LINE_ID                                                          As LINE_ID                           ,
  SFP.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID                    ,
  Null                                                                     As CUST_TYPE_CD                      ,
  Coalesce(SFP.PAR_ADV_DOSSIER_NU,'0000000000')                            As MSISDN_ID                         ,
  Coalesce(SFP.PAR_ND,'0000000000')                                        As NDS_VALUE_DS                      ,
  Coalesce(SFP.PAR_EXTERNAL_PARTY_ID,SFP.PAR_EXTERNAL_PARTY_FREG_ID)       As EXTERNAL_PARTY_ID                 ,
  SFP.PAR_AID                                                              As RES_VALUE_DS                      ,
  SFP.PAR_ACCES_SERVICE                                                    As PAR_ACCES_SERVICE                 ,
  PlSFP.PAR_TAC_CD                                                         As TAC_CD                            ,
  PlSFP.PAR_IMEI_CD                                                        As IMEI_CD                           ,
  SFP.PAR_MOB_IMSI                                                         As IMSI_CD                           ,
  Null                                                                     As HOM_START_DT                      ,
  Null                                                                     As MOB_START_DT                      ,
  SFP.PAR_SCORE_NU_INT                                                     As I_SCORE_VALUE                     ,
  SFP.PAR_TRESHOLD_NU_INT                                                  As I_SCORE_TRESHOLD                  ,
  Case
    When SFP.PAR_SCORE_IN_INT = 'O' Then 1
    Else 0
  End                                                                      As I_SCORE_IN                        ,
  SFP.PAR_SCORE_NU_MOB                                                     As M_SCORE_VALUE                     ,
  SFP.PAR_TRESHOLD_NU_MOB                                                  As M_SCORE_TRESHOLD                  ,
  SFP.PAR_SCORE_IN_MOB                                                     As M_SCORE_IN                        ,
  Case
    When SFP.OTO_OSCAR_VALUE_NU ='S' Then '-1'
    Else SFP.OTO_OSCAR_VALUE_NU
  End                                                                      As OSCAR_VALUE                       ,
  '${P_PIL_380}'                                                           AS CUST_BU_TYPE_CD                   ,
  SFP.PAR_BU_CD                                                            As CUST_BU_CD                        ,
  '${P_PIL_372}'                                                           As ADDRESS_TYPE                      ,
  Trim(
  Coalesce(SFP.PAR_BILL_ADRESS_1,'') || 
  Coalesce(SFP.PAR_BILL_CD_POSTAL,'') || ' ' || 
  Coalesce(SFP.PAR_BILL_ADRESS_4,'')
      )                                                                    As ADDRESS_CONCAT_NM                 ,
  SFP.PAR_POSTAL_CD                                                        As POSTAL_CD                         ,
  SFP.PAR_INSEE_CD                                                         As INSEE_CD                          ,
  Case When COM_O${KNB_SUFFIX}.IsNumber(SFP.PAR_BU_CD)=1
         Then SFP.PAR_BU_CD
       Else Null
  End                                                                      As BU_CD                             ,
  SFP.PAR_DEPRTMNT_ID                                                      As DEPARTMNT_ID                      ,
  SFP.PAR_GEO_MACROZONE                                                    as PAR_GEO_MACROZONE                 ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_UNIFIED_PARTY_ID
    Else SFP.PAR_UNIFIED_PARTY_ID
  End                                                                      as PAR_UNIFIED_PARTY_ID              ,
  SFP.PAR_PARTY_REGRPMNT_ID                                                as PAR_PARTY_REGRPMNT_ID             ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.CID_ID
    Else SFP.PAR_CID_ID
  End                                                                      as PAR_CID_ID                        ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.RAP_PID_ID
    Else SFP.PAR_PID_ID
  End                                                                      as PAR_PID_ID                        ,
  SFP.PAR_FIRST_IN                                                         as PAR_FIRST_IN                      ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.ORG_AGENT_IOBSP
    Else SFP.ORG_AGENT_IOBSP
  End                                                                      as ORG_AGENT_IOBSP                   ,
  Case When DIGITAL.ACTE_ID_INTRCTN Is Not Null
    Then DIGITAL.NEW_ORG_EDO_IOBSP
    Else SFP.ORG_EDO_IOBSP
  End                                                                      as ORG_EDO_IOBSP                     ,
  SFP.PAR_IRIS2000_CD                                                      As PAR_IRIS2000_CD                   ,

  Case when (SFP.ACT_UNITE_CD<>'${P_PIL_620}') Or (SFP.ACT_UNITE_CD='${P_PIL_620}' and SFP.ACT_ACTE_FAMILLE_KPI LIKE '${P_PIL_628}')
        Then  Coalesce(SFP.ACT_DELTA_TARIF,0)
         Else Null
  End                                                                      As ACT_CA_LINE_AM                ,
   -----------
  SFP.PAR_MOB_SIM                                                          As SIM_CD                            ,
  Null                                                                     As SIM_EAN_CD                        ,   
  PlSFP.TERMINAL_CODE_EAN                                                  As EAN_CD                            ,
  SFP.ORG_RESP_AGENT_ID                                                    As ORG_RESP_ID                       ,
       --Ajout QC 712 : Ajout Code TAC,EAN,IMEI
  SFP.TAC_PREVIOUS_CD                                                      as TAC_PREVIOUS_CD                   ,
  SFP.IMEI_PREVIOUS_CD                                                     as IMEI_PREVIOUS_CD                  ,
  SFP.EAN_PREVIOUS_CD                                                      as EAN_PREVIOUS_CD                   ,
  PlSFP.PRESFACT_CO_PRE_ADV                                                as PCM_PREVIOUS_OFFRE_CD             ,
  SFP.COMMARTICLE_RP_REFPRIX_CD                                            as COMMARTICLE_RP_REFPRIX_CD         ,
  SFP.PCM_COMMTMNT_PERIOD_NU                                               as PCM_COMMTMNT_PERIOD_NU            ,
  SFP.PCM_LEVEL_POINT_NU                                                   as PCM_LEVEL_POINT_NU                ,
  SFP.CO_OFFRE_TERM_CD                                                     as PCM_OFFRE_CD                      ,
  SFP.PCM_EFFCTV_NEXT_OFFRE_DT                                             as PCM_EFFCTV_NEXT_OFFRE_DT          ,
  SFP.PCM_TYPE_OFFRE_MOBILE_CD                                             as PCM_TYPE_OFFRE_MOBILE_CD          ,
  SFP.PCM_POINT_UTIL_NU                                                    as PCM_POINT_UTIL_NU                 ,
  SFP.PCM_BALANCE_POINT_NU                                                 as PCM_BALANCE_POINT_NU              ,
  SFP.PCM_STATUT_POINT_CD                                                  as PCM_STATUT_POINT_CD               ,
  SFP.PCM_POINT_DUE_NU                                                     as PCM_POINT_DUE_NU                  ,
  --Fin QC 712 
  SFP.CHECK_INITIAL_STATUS_CD                                              As CHECK_INITIAL_STATUS_CD,
  SFP.CHECK_NAT_STATUS_CD                                                  As CHECK_NAT_STATUS_CD,
  SFP.CHECK_NAT_COMMENT                                                    As CHECK_NAT_COMMENT,
  SFP.CHECK_NAT_STATUS_LN                                                  As CHECK_NAT_STATUS_LN,
  SFP.CHECK_LOC_STATUS_CD                                                  As CHECK_LOC_STATUS_CD,
  SFP.CHECK_LOC_COMMENT                                                    As CHECK_LOC_COMMENT,
  SFP.CHECK_LOC_STATUS_LN                                                  As CHECK_LOC_STATUS_LN,
  SFP.CHECK_VALIDT_DT                                                      As CHECK_VALIDT_DT,
  Null                                                                     As ACT_END_UNIFIED_DT,
  Null                                                                     As ACT_END_UNIFIED_DS,
  SFP.CLOSURE_DT                                                           As ACT_CLOSURE_DT,
  Case When SFP.CLOSURE_DT Is Not Null
       Then 'Acte Source Supprimé'        
  End                                                                      As ACT_CLOSURE_DS,
  SFP.HOT_IN                                                               As HOT_IN,
  SFP.RUN_ID                                                               As RUN_ID,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS,
  1                                                                        As FRESH_IN,
  0                                                                        As COHERENCE_IN 
From
  ${KNB_PCO_VM}.V_ORD_F_ACTE_SOFT_PCM SFP
  Left outer Join ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_PCM PlSFP
    On    SFP.ACTE_ID              =   PlSFP.ACTE_ID
      And SFP.ORDER_DEPOSIT_TS     =   PlSFP.ORDER_DEPOSIT_TS
  Inner Join ${KNB_PCO_VM}.V_ORD_F_ACTE_DIGITAL DIGITAL
    On SFP.ACTE_ID            = DIGITAL.ACTE_ID
    And SFP.ORDER_DEPOSIT_DT  = DIGITAL.ACT_DT
    And DIGITAL.CURRENT_IN = 1
Where
  (1=1)
  And Substr(SFP.ACT_CD,1,3) Not In (${L_PIL_036})
  And SFP.ACT_SEG_COM_ID_FINAL <> '${P_PIL_295}'
  And SFP.ACT_CD <> '${P_PIL_067}'
  And SFP.ORDER_DEPOSIT_DT > '20130402' 
  And SFP.HOT_IN = 0
  And SFP.ORDER_DEPOSIT_DT >= Current_date - 250
  And SFP.ORG_CHANEL_CD                IN ('Online','DNU')
  And ((SFP.LAST_MODIF_TS >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And SFP.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') or SFP.ORDER_DEPOSIT_DT > Current_date - 15)
  And SFP.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
  And Not Exists (
    Select 'X' 
    From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTP SP
    Where SP.ACTE_ID = DIGITAL.ACTE_ID
    And SP.ACT_DT  = DIGITAL.ACT_DT
  )
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_SOFTP;
.if errorcode <> 0 then .quit 1;

