-- $HEADER: mm2pco/current/sql/ATP_NSH_Placement_Cold_Enrichissement_LineDMC.sql 13_05#7 09-JAN-2017 17:57:12 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_Enrichissement_LineDMC.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement line DMC
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 27/03/2014      MCA         Creation
-- 31/07/2014      MCA         Indus
-- 09/01/2017      JCR         Modification Ventes associées
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------------------
Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC all;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------

----------------------------------------------------------------------------
-- Etape 1 : On recherche l'identifiant ligne dans DMC
----------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  DMC_LINE_ID               ,
  DMC_MASTER_LINE_ID        ,
  CLIENT_NU                 ,
  DEPRTMNT_ID               ,
  BU_CD                     ,
  POSTAL_CD                 ,
  INSEE_NB                  ,
  PAR_UNIFIED_PARTY_ID      ,
  PAR_PARTY_REGRPMNT_ID
)
Select
  Refdmc.ACTE_ID                                  as ACTE_ID                    ,
  Refdmc.ORDER_DEPOSIT_DT                         as ORDER_DEPOSIT_DT           ,
  LineDmc.LINE_ID                                 as DMC_LINE_ID                ,
  LineDmc.MASTER_LINE_ID                          as DMC_MASTER_LINE_ID         ,
  Dossier.DOSSIER_CLIENT_NU                       as CLIENT_NU                  ,
  LineDmc.DEPRTMNT_ID                             as DEPRTMNT_ID                ,
  Geo.BU_CD                                       as BU_CD                      ,
  LineDmc.POSTAL_CD                               as POSTAL_CD                  ,
  LineDmc.INSEE_NB                                as INSEE_NB                   ,
  LineDmc.UNIFIED_PARTY_ID                        as PAR_UNIFIED_PARTY_ID       ,
  LineDmc.PARTY_REGRPMNT_ID                       as PAR_PARTY_REGRPMNT_ID      
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP Refdmc
  Inner join ${KNB_IBU_SOC}.V_TDDOSSIER Dossier
     On      Refdmc.PAR_ADV_DOSSIER_NU = Dossier.DOSSIER_NU
       and Dossier.DOSSIER_DT_CREAT <= Refdmc.ORDER_DEPOSIT_TS
       and  Refdmc.ORDER_DEPOSIT_TS< Coalesce(Dossier.DOSSIER_DT_RESIL,cast('2999-12-31 00:00:00'as timestamp(0)))
  Left Outer Join ${KNB_DMU_DMC_VM_V}.PAR_F_AR_VM LineDmc
    On   Dossier.DOSSIER_NU_IMSI = LineDmc.IMSI_CD
  Left Outer Join ${KNB_DMU_DMC_VM_V}.GEO_R_BUSINESS_UNIT  Geo
     On Geo.DEPT_CD = LineDmc.DEPRTMNT_ID
  
Where
  (1=1)
  And LineDmc.CLOSURE_DT  Is Null
Qualify Row_Number() Over (Partition by Refdmc.EXTERNAL_ORDER_ID_SPO, Refdmc.ORDER_DEPOSIT_TS Order by LineDmc.START_DT ,LineDmc.LINE_ID Desc)=1

;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC
;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 2 : Enrichissement avec le code IRIS2000
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_IRIS All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_IRIS
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  LINE_ID                   ,
  PAR_IRIS2000_CD           ,
  PAR_GEO_MACROZONE
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_LINE_ID                               as LINE_ID                    ,
  LFIBER.IRIS2000_CD                              as PAR_IRIS2000_CD            ,
  LFIBER.RESERV_4                                 as PAR_GEO_MACROZONE
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC RefId
  Inner Join ${KNB_DMU_DMC_VM_V}.LINE_FIBER_AVLB LFIBER
    on RefId.DMC_LINE_ID = LFIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by LFIBER.LAST_MODIF_TS Desc)=1  
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_IRIS;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------
-- Etape 3 : Enrichissement avec le PAR_FIBER_IN
----------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_FIBER All;
.if errorcode <> 0 then .quit 1

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_FIBER
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT            ,
  DMC_LINE_ID                ,
  PAR_FIBER_IN
)
Select
  RefId.ACTE_ID                                   as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT                          as ORDER_DEPOSIT_DT           ,
  RefId.DMC_LINE_ID                               as DMC_LINE_ID                ,
  FIBER.FIBER_IN                                  as PAR_FIBER_IN            
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_LINEDMC RefId
  Inner Join ${KNB_DMC_VM_V}.PAR_F_AR_VM_CPLT FIBER
    on RefId.DMC_LINE_ID = FIBER.LINE_ID
Qualify Row_Number() Over (Partition by RefId.ACTE_ID, RefId.ORDER_DEPOSIT_DT Order by FIBER.START_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_FIBER;
.if errorcode <> 0 then .quit 1


