--$HEADER:   mm2pco/current/sql/ATP_COE_Placement_Step7_Fusion_Final.sql 13_05#7 26-JUN-2019 11:39:31 NNGS2043
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_COE_Placement_Step5_Fusion .sql 
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Fusion Enrichissement Placements 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/10/2018       HOB          Creation
-- 13/02/2019       LMU          Evol : Hierachisation IOBSP  
-- 06/05/2019       TCL          Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
----------------------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table Temporaire                                                ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_COE All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Affectation ACTE_ID                                               ----
----------------------------------------------------------------------------------------------
  Insert Into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_COE
  (  
    ACTE_ID                     ,
    EXTERNAL_ORDER_ID           ,
    TYPE_SOURCE_ID              ,
    INTRNL_SOURCE_ID            ,
    OPERATOR_PROVIDER_ID        ,
    ORDER_DEPOSIT_TS            ,
    ORDER_DEPOSIT_DT            ,
    EXTRNL_APPLI_SOURCE_ID      ,
    ORDR_TYP_CD                 ,
    EXTRNL_INTRCTN_ID           ,
    EXTRNL_CATEGORY_ID          ,
    EXTRNL_THEME_ID             ,
    EXTRNL_RESLTN_ID            ,
    EXTRNL_INIT_RESLTN_ID       ,
    EXTRNL_CONCLSN_ID           ,
    EXTRNL_SUBCONC_CD           ,
    INIT_MOTIF_RCS              ,
    INIT_MOTIF_STATUS_CD        ,
    EXT_PRODUCT_ID_1            ,
    EXT_PRODUCT_ID_2            ,
    EXT_PRODUCT_ID_3            ,
    EXTRNL_STATUS_CD            ,
    STATUS_UNIFIED_CD           ,
    EXTRNL_DOSSIER_NU           ,
    EXTRNL_CLIENT_NU            ,
    DMC_LINE_ID                 ,
    DMC_MASTER_LINE_ID          ,
    DMC_CUST_TYPE_CD            ,
    DMC_NDS_VALUE_DS            ,
    DMC_EXTERNAL_PARTY_ID       ,
    DMC_RES_VALUE_DS            ,
    DMC_SERVICE_ACCESS_ID       ,
    DMC_LINE_TYPE               ,
    DMC_START_DT                ,
    DMC_ACTIVATION_DT           ,
    DMC_POSTAL_CD               ,
    PAR_INSEE_NB                ,
    PAR_BU_CD                   ,
    DMC_DEPRTMNT_ID             ,
    DMC_CUST_BU_CD              ,
    DMC_ADDRESS_CONCAT_NM       ,
    DMC_ADDRESS_TYPE            ,
    DMC_CONVERGENT_IN           ,
    PAR_GEO_MACROZONE           ,
    PAR_UNIFIED_PARTY_ID        ,
    PAR_PARTY_REGRPMNT_ID       ,
    PAR_IRIS2000_CD             ,
    PAR_CID_ID                  ,
    PAR_PID_ID                  ,
    PAR_FIRST_IN                ,
    PAR_FIBER_IN                ,
    EXTRNL_CHANNL_CD            ,
    ORG_AGENT_IOBSP             ,
    ORG_AGENT_ID                ,
    EXTRNL_SHOP_ID              ,
    ORG_EDO_IOBSP               ,
    EDO_ID                      ,
    TYPE_EDO_ID                 ,
    DISTRBTN_CHANNL_ID          ,
    FLAG_AD_SC                  ,
    FLAG_PLT_SCH_IN             ,
    FLAG_PLT_CONV_NB            ,
    FLAG_TYPE_GEO_CD            ,
    FLAG_TYPE_CPT_NTK           ,
    NETWRK_TYP_EDO_ID           ,
    FLAG_TYPE_PTN_NTK           ,
    ORG_CHANNEL_CD              ,
    ORG_SUB_CHANNEL_CD          ,
    ORG_SUB_SUB_CHANNEL_CD      ,
    ORG_GT_ACTIVITY             ,
    ORG_FIDELISATION            ,
    ORG_WEB_ACTIVITY            ,
    ORG_AUTO_ACTIVITY           ,
    ORG_REM_CHANNEL_CD          ,
    EXTRNL_CREATED_DT           ,
    EXTRNL_CREATED_TS           ,
    EXTRNL_CREATED_XI_POC       ,
    EXTRNL_CREATED_XI_OEE       ,
    EXTRNL_CREATED_AGENT_ID     ,
    EXTRNL_RESP_XI_POC          ,
    EXTRNL_RESP_XI_OEE          ,
    EXTRNL_RESP_AGENT_ID        ,
    EXTRNL_LASTMANT_TS          ,
    EXTRNL_CLOSED_TS            ,
    EXTRNL_SUP_TS               ,
    EXTRNL_PLTF_CO              ,
    EXTRNL_PDV_XI               ,
    EXTRNL_TYPE_CD              ,
    EXTRNL_USCM_CD              ,
    EXTRNL_SCORE_IN             ,
    EXTRNL_SCORE_NU             ,
    EXTRNL_THRESHOLD_NU         ,
    EXTRNL_CREATED_ACTIVITY_CD  ,
    EXTRNL_RESP_ACTIVITY_CD     ,
    IODA_AGENT_ID               ,
    IODA_SHOP_CD                ,
    IODA_CONTEXT_ORDER          ,
    ALOES_CREATED_AGENT_ID      ,
    ALOES_RESP_AGENT_ID         ,
    RCS_MOTIV_INVC_CD           ,
    RCS_ENR_ACTE_ID             ,
    ORG_TEAM_LEVEL_1_CD         ,
    ORG_TEAM_LEVEL_1_DS         ,
    ORG_TEAM_LEVEL_2_CD         ,
    ORG_TEAM_LEVEL_2_DS         ,
    ORG_TEAM_LEVEL_3_CD         ,
    ORG_TEAM_LEVEL_3_DS         ,
    ORG_TEAM_LEVEL_4_CD         ,
    ORG_TEAM_LEVEL_4_DS         ,
    WORK_TEAM_LEVEL_1_CD        ,
    WORK_TEAM_LEVEL_1_DS        ,
    WORK_TEAM_LEVEL_2_CD        ,
    WORK_TEAM_LEVEL_2_DS        ,
    WORK_TEAM_LEVEL_3_CD        ,
    WORK_TEAM_LEVEL_3_DS        ,
    WORK_TEAM_LEVEL_4_CD        ,
    WORK_TEAM_LEVEL_4_DS        ,
    CREATION_TS                 ,
    LAST_MODIF_TS               ,
    FRESH_IN                    ,
    COHERENCE_IN
  )
  Select
    Placement.ACTE_ID                                                              as  ACTE_ID                            ,
    Placement.EXTERNAL_ORDER_ID                                                   as  EXTERNAL_ORDER_ID                  ,
    Placement.TYPE_SOURCE_ID                                                      as  TYPE_SOURCE_ID                     ,
    Placement.INTRNL_SOURCE_ID                                                    as  INTRNL_SOURCE_ID                   ,
    Placement.OPERATOR_PROVIDER_ID                                                as  OPERATOR_PROVIDER_ID               ,
    Placement.ORDER_DEPOSIT_TS                                                    as  ORDER_DEPOSIT_TS                  ,
    Placement.ORDER_DEPOSIT_DT                                                    as  ORDER_DEPOSIT_DT                   ,
    Placement.EXTRNL_APPLI_SOURCE_ID                                              as  EXTRNL_APPLI_SOURCE_ID             ,
    Placement.ORDR_TYP_CD                                                         as  ORDR_TYP_CD                        ,
    Placement.EXTRNL_INTRCTN_ID                                                   as  EXTRNL_INTRCTN_ID                  ,
    Placement.EXTRNL_CATEGORY_ID                                                  as  EXTRNL_CATEGORY_ID                 ,
    Placement.EXTRNL_THEME_ID                                                     as  EXTRNL_THEME_ID                    ,
    Placement.EXTRNL_RESLTN_ID                                                    as  EXTRNL_RESLTN_ID                   ,
    Placement.EXTRNL_INIT_RESLTN_ID                                               as  EXTRNL_INIT_RESLTN_ID              ,
    Placement.EXTRNL_CONCLSN_ID                                                   as  EXTRNL_CONCLSN_ID                  ,
    Placement.EXTRNL_SUBCONC_CD                                                   as  EXTRNL_SUBCONC_CD                  ,
    Placement.INIT_MOTIF_RCS                                                      as  INIT_MOTIF_RCS                     ,
    Placement.INIT_MOTIF_STATUS_CD                                                as  INIT_MOTIF_STATUS_CD               ,
    Placement.EXT_PRODUCT_ID_1                                                    as  EXT_PRODUCT_ID_1                   ,
    Placement.EXT_PRODUCT_ID_2                                                    as  EXT_PRODUCT_ID_2                   ,
    Placement.EXT_PRODUCT_ID_3                                                    as  EXT_PRODUCT_ID_3                   ,
    Placement.EXTRNL_STATUS_CD                                                    as  EXTRNL_STATUS_CD                   ,
    Placement.STATUS_UNIFIED_CD                                                   as  STATUS_UNIFIED_CD                  ,
    Placement.EXTRNL_DOSSIER_NU                                                   as  EXTRNL_DOSSIER_NU                  ,
    Placement.EXTRNL_CLIENT_NU                                                    as  EXTRNL_CLIENT_NU                   ,
    Placement.DMC_LINE_ID                                                         as  DMC_LINE_ID                        ,
    Placement.DMC_MASTER_LINE_ID                                                  as  DMC_MASTER_LINE_ID                 ,
    Placement.DMC_CUST_TYPE_CD                                                    as  DMC_CUST_TYPE_CD                   ,
    Placement.DMC_NDS_VALUE_DS                                                    as  DMC_NDS_VALUE_DS                   ,
    Placement.DMC_EXTERNAL_PARTY_ID                                               as  DMC_EXTERNAL_PARTY_ID              ,
    Placement.DMC_RES_VALUE_DS                                                    as  DMC_RES_VALUE_DS                   ,
    Placement.DMC_SERVICE_ACCESS_ID                                               as  DMC_SERVICE_ACCESS_ID              ,
    Placement.DMC_LINE_TYPE                                                       as  DMC_LINE_TYPE                      ,
    Placement.DMC_START_DT                                                        as  DMC_START_DT                       ,
    Placement.DMC_ACTIVATION_DT                                                   as  DMC_ACTIVATION_DT                  ,
    Placement.DMC_POSTAL_CD                                                       as  DMC_POSTAL_CD                      ,
    Placement.PAR_INSEE_NB                                                        as  PAR_INSEE_NB                       ,
    Placement.PAR_BU_CD                                                           as  PAR_BU_CD                          ,
    Placement.DMC_DEPRTMNT_ID                                                     as  DMC_DEPRTMNT_ID                    ,
    Placement.DMC_CUST_BU_CD                                                      as  DMC_CUST_BU_CD                     ,
    Placement.DMC_ADDRESS_CONCAT_NM                                               as  DMC_ADDRESS_CONCAT_NM              ,
    Placement.DMC_ADDRESS_TYPE                                                    as  DMC_ADDRESS_TYPE                   ,
    Placement.DMC_CONVERGENT_IN                                                   as  DMC_CONVERGENT_IN                  ,
    Placement.PAR_GEO_MACROZONE                                                   as  PAR_GEO_MACROZONE                  ,
    Placement.PAR_UNIFIED_PARTY_ID                                                as  PAR_UNIFIED_PARTY_ID               ,
    Placement.PAR_PARTY_REGRPMNT_ID                                               as  PAR_PARTY_REGRPMNT_ID              ,
    Placement.PAR_IRIS2000_CD                                                     as  PAR_IRIS2000_CD                    ,
    Placement.PAR_CID_ID                                                          as  PAR_CID_ID                         ,
    Placement.PAR_PID_ID                                                          as  PAR_PID_ID                         ,
    Placement.PAR_FIRST_IN                                                        as  PAR_FIRST_IN                       ,
    Placement.PAR_FIBER_IN                                                        as  PAR_FIBER_IN                       ,
    Placement.EXTRNL_CHANNL_CD                                                    as  EXTRNL_CHANNL_CD                   ,
    Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                                           as  ORG_AGENT_IOBSP                    ,
    Placement.ORG_AGENT_ID                                                        as  ORG_AGENT_ID                       ,
    Placement.EXTRNL_SHOP_ID                                                      as  EXTRNL_SHOP_ID                     ,
    Case When EdoOBK.EDO_ID is Not Null
            Then 'O'
            Else 'N'
    End                                                                           as  ORG_EDO_IOBSP                      ,
    Placement.EDO_ID                                                              as  EDO_ID                             ,
    Placement.TYPE_EDO_ID                                                         as  TYPE_EDO_ID                        ,
    Placement.DISTRBTN_CHANNL_ID                                                  as  DISTRBTN_CHANNL_ID                 ,
    Placement.FLAG_AD_SC                                                          as  FLAG_AD_SC                         ,
    Placement.FLAG_PLT_SCH_IN                                                     as  FLAG_PLT_SCH_IN                    ,
    Placement.FLAG_PLT_CONV_NB                                                    as  FLAG_PLT_CONV_NB                   ,
    Placement.FLAG_TYPE_GEO_CD                                                    as  FLAG_TYPE_GEO_CD                   ,
    Placement.FLAG_TYPE_CPT_NTK                                                   as  FLAG_TYPE_CPT_NTK                  ,
    Placement.NETWRK_TYP_EDO_ID                                                   as  NETWRK_TYP_EDO_ID                  ,
    Placement.FLAG_TYPE_PTN_NTK                                                   as  FLAG_TYPE_PTN_NTK                  ,
    Placement.ORG_CHANNEL_CD                                                      as  ORG_CHANNEL_CD                     ,
    Placement.ORG_SUB_CHANNEL_CD                                                  as  ORG_SUB_CHANNEL_CD                 ,
    Placement.ORG_SUB_SUB_CHANNEL_CD                                              as  ORG_SUB_SUB_CHANNEL_CD             ,
    Placement.ORG_GT_ACTIVITY                                                     as  ORG_GT_ACTIVITY                    ,
    Placement.ORG_FIDELISATION                                                    as  ORG_FIDELISATION                   ,
    Placement.ORG_WEB_ACTIVITY                                                    as  ORG_WEB_ACTIVITY                   ,
    Placement.ORG_AUTO_ACTIVITY                                                   as  ORG_AUTO_ACTIVITY                  ,
    Placement.ORG_REM_CHANNEL_CD                                                  as  ORG_REM_CHANNEL_CD                 ,
    Placement.EXTRNL_CREATED_DT                                                   as  EXTRNL_CREATED_DT                  ,
    Placement.EXTRNL_CREATED_TS                                                   as  EXTRNL_CREATED_TS                  ,
    Placement.EXTRNL_CREATED_XI_POC                                               as  EXTRNL_CREATED_XI_POC              ,
    Placement.EXTRNL_CREATED_XI_OEE                                               as  EXTRNL_CREATED_XI_OEE              ,
    Placement.EXTRNL_CREATED_AGENT_ID                                             as  EXTRNL_CREATED_AGENT_ID            ,
    Placement.EXTRNL_RESP_XI_POC                                                  as  EXTRNL_RESP_XI_POC                 ,
    Placement.EXTRNL_RESP_XI_OEE                                                  as  EXTRNL_RESP_XI_OEE                 ,
    Placement.EXTRNL_RESP_AGENT_ID                                                as  EXTRNL_RESP_AGENT_ID               ,
    Placement.EXTRNL_LASTMANT_TS                                                  as  EXTRNL_LASTMANT_TS                 ,
    Placement.EXTRNL_CLOSED_TS                                                    as  EXTRNL_CLOSED_TS                   ,
    Placement.EXTRNL_SUP_TS                                                       as  EXTRNL_SUP_TS                      ,
    Placement.EXTRNL_PLTF_CO                                                      as  EXTRNL_PLTF_CO                     ,
    Placement.EXTRNL_PDV_XI                                                       as  EXTRNL_PDV_XI                      ,
    Placement.EXTRNL_TYPE_CD                                                      as  EXTRNL_TYPE_CD                     ,
    Placement.EXTRNL_USCM_CD                                                      as  EXTRNL_USCM_CD                     ,
    Placement.EXTRNL_SCORE_IN                                                     as  EXTRNL_SCORE_IN                    ,
    Placement.EXTRNL_SCORE_NU                                                     as  EXTRNL_SCORE_NU                    ,
    Placement.EXTRNL_THRESHOLD_NU                                                 as  EXTRNL_THRESHOLD_NU                ,
    Placement.EXTRNL_CREATED_ACTIVITY_CD                                          as  EXTRNL_CREATED_ACTIVITY_CD         ,
    Placement.EXTRNL_RESP_ACTIVITY_CD                                             as  EXTRNL_RESP_ACTIVITY_CD            ,
    Placement.IODA_AGENT_ID                                                       as  IODA_AGENT_ID                      ,
    Placement.IODA_SHOP_CD                                                        as  IODA_SHOP_CD                       ,
    Placement.IODA_CONTEXT_ORDER                                                  as  IODA_CONTEXT_ORDER                 ,
    Placement.ALOES_CREATED_AGENT_ID                                              as  ALOES_CREATED_AGENT_ID             ,
    Placement.ALOES_RESP_AGENT_ID                                                 as  ALOES_RESP_AGENT_ID                ,
    Coalesce(ActeADV.EXTRNL_OPSRV_DS,Placement.RCS_MOTIV_INVC_CD)                 as  RCS_MOTIV_INVC_CD                  ,
    Coalesce(ActeADV.ACTE_ID, Placement.RCS_ENR_ACTE_ID)                          as  RCS_ENR_ACTE_ID                    ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_1_CD,Placement.ORG_TEAM_LEVEL_1_CD)            as  ORG_TEAM_LEVEL_1_CD                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_1_DS,Placement.ORG_TEAM_LEVEL_1_DS)            as  ORG_TEAM_LEVEL_1_DS                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_2_CD,Placement.ORG_TEAM_LEVEL_2_CD)            as  ORG_TEAM_LEVEL_2_CD                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_2_DS,Placement.ORG_TEAM_LEVEL_2_DS)            as  ORG_TEAM_LEVEL_2_DS                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_3_CD,Placement.ORG_TEAM_LEVEL_3_CD)            as  ORG_TEAM_LEVEL_3_CD                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_3_DS,Placement.ORG_TEAM_LEVEL_3_DS)            as  ORG_TEAM_LEVEL_3_DS                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_4_CD,Placement.ORG_TEAM_LEVEL_4_CD)            as  ORG_TEAM_LEVEL_4_CD                ,
    Coalesce(HIERO3.ORG_TEAM_LEVEL_4_DS,Placement.ORG_TEAM_LEVEL_4_DS)            as  ORG_TEAM_LEVEL_4_DS                ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_1_CD,Placement.WORK_TEAM_LEVEL_1_CD)          as  WORK_TEAM_LEVEL_1_CD               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_1_DS,Placement.WORK_TEAM_LEVEL_1_DS)          as  WORK_TEAM_LEVEL_1_DS               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_2_CD,Placement.WORK_TEAM_LEVEL_2_CD)          as  WORK_TEAM_LEVEL_2_CD               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_2_DS,Placement.WORK_TEAM_LEVEL_2_DS)          as  WORK_TEAM_LEVEL_2_DS               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_3_CD,Placement.WORK_TEAM_LEVEL_3_CD)          as  WORK_TEAM_LEVEL_3_CD               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_3_DS,Placement.WORK_TEAM_LEVEL_3_DS)          as  WORK_TEAM_LEVEL_3_DS               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_4_CD,Placement.WORK_TEAM_LEVEL_4_CD)          as  WORK_TEAM_LEVEL_4_CD               ,
    Coalesce(HIERO3.WORK_TEAM_LEVEL_4_DS,Placement.WORK_TEAM_LEVEL_4_DS)          as  WORK_TEAM_LEVEL_4_DS               ,
    Placement.CREATION_TS                                                         as  CREATION_TS                        ,
    Placement.LAST_MODIF_TS                                                       as  LAST_MODIF_TS                      ,
    Placement.FRESH_IN                                                            as  FRESH_IN                           ,
    Placement.COHERENCE_IN                                                        as  COHERENCE_IN                       
 From  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_COE_1  Placement  
    Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_COE_HIERO3 HIERO3
       On    Placement.ACTE_ID              =  HIERO3.ACTE_ID  
        And  Placement.ORDER_DEPOSIT_DT     =  HIERO3.ORDER_DEPOSIT_DT
    Left Outer Join ${KNB_PCO_SOC}.V_BIL_F_PLACEMENT_ADV ActeADV 
       On    ActeADV.MSISDN_ID                = Placement.EXTRNL_DOSSIER_NU         
       And   ActeADV.ORDER_DEPOSIT_DT Between Placement.ORDER_DEPOSIT_DT And (Placement.ORDER_DEPOSIT_DT + 10)
         -- IOBSP
   Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
      On   Placement.EDO_ID   = EdoOBK.EDO_ID
        And Placement.ORDER_DEPOSIT_DT  >= EdoOBK.START_VAL_AXS_DT
        And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')     And  EdoOBK.CURRENT_IN        = 1
   Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On  Placement.ORG_AGENT_ID      = CuidOBK.AGENT_ID
      AND Placement.ORDER_DEPOSIT_DT >= CuidOBK.HABILL_BEGIN_DT
      AND Placement.ORDER_DEPOSIT_DT < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
      
  

    
Where
  (1=1)
  Qualify Row_number() over (Partition By Placement.ACTE_ID,Placement.ORDER_DEPOSIT_DT Order By ActeADV.ORDER_DEPOSIT_TS asc)=1
;                                                                     

.if errorcode <> 0 then .quit 1            
Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_COE  ; 
.if errorcode <> 0 then .quit 1  


