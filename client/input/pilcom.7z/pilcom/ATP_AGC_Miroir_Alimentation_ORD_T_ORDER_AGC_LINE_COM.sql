-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_AGC_Miroir_Alimentation_ORD_T_ORDER_AGC_LINE_COM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'alimentation de la table de commandes AGC: ORD_T_ORDER_AGC_LINE_COM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/03/2014      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;




--Insertion dans la table des lignes de commandes :

--TODO PAramétrage

Delete from ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM all ;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM
(
  CONTEXT_ID                  ,
  EXTERNAL_ORDER_ID           ,
  ORDER_DEPOSIT_TS            ,
  ORDER_DEPOSIT_DT            ,
  ORDER_TYPE_CD               ,
  OPTION_IODA                 ,
  OPTION_ACTION               ,
  ORIGINAL_OFFER_CD           ,
  NEW_OFFER_CD                ,
  OFFER_DS                    ,
  START_OFFER_DT              ,
  MSISDN_PORTED               ,
  LAST_IMEI_CD                ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  TERMINAL_MSISDN_ID          ,
  NEW_SIM_CD                  ,
  NEW_EAN_CD                  ,
  TERMINAL_PRICE              ,
  DISCOUNT                    ,
  PCM_REMNNG_UNPAID           ,
  CALIPSO_CD                  ,
  ENGGMNT_DURATION            ,
  SECOND_IMEI_CD              ,
  SECOND_EAN_CD               ,
  SECOND_MSISDN_ID            ,
  SECOND_SIM_CD               ,
  INVOICE_ADDRESS_MAIL_NM     ,
  IMEI_CD                     ,
  EAN_CD                      ,
  QUEUE_TS                    ,
  RUN_ID                      ,
  STREAMING_TS                ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  HOT_IN                      ,
  FRESH_IN                    ,
  COHERENCE_IN
)
Select
  LigneCom.CONTEXT_ID                                               as CONTEXT_ID                     ,
  LigneCom.EXTERNAL_ORDER_ID                                        as EXTERNAL_ORDER_ID              ,
  CAST(CAST(LigneCom.ORDER_DEPOSIT_TS At Time Zone 'Europe Central' AS VARCHAR(19)) AS TIMESTAMP(0)) as ORDER_DEPOSIT_TS,
  Cast(ORDER_DEPOSIT_TS as date format 'YYYYMMDD')                  as ORDER_DEPOSIT_DT               ,
  LigneCom.ORDER_TYPE_CD                                            as ORDER_TYPE_CD                  ,
  LigneCom.OPTION_IODA                                              as OPTION_IODA                    ,
  LigneCom.OPTION_ACTION                                            as OPTION_ACTION                  ,
  LigneCom.ORIGINAL_OFFER_CD                                        as ORIGINAL_OFFER_CD              ,
  LigneCom.NEW_OFFER_CD                                             as NEW_OFFER_CD                   ,
  LigneCom.OFFER_DS                                                 as OFFER_DS                       ,
  LigneCom.START_OFFER_DT                                           as START_OFFER_DT                 ,
  LigneCom.MSISDN_PORTED                                            as MSISDN_PORTED                  ,
  LigneCom.LAST_IMEI_CD                                             as LAST_IMEI_CD                   ,
  LigneCom.TERMINAL_BRAND                                           as TERMINAL_BRAND                 ,
  LigneCom.TERMINAL_MODEL                                           as TERMINAL_MODEL                 ,
  LigneCom.TERMINAL_MSISDN_ID                                       as TERMINAL_MSISDN_ID             ,
  LigneCom.NEW_SIM_CD                                               as NEW_SIM_CD                     ,
  LigneCom.NEW_EAN_CD                                               as NEW_EAN_CD                     ,
  LigneCom.TERMINAL_PRICE                                           as TERMINAL_PRICE                 ,
  LigneCom.DISCOUNT                                                 as DISCOUNT                       ,
  LigneCom.PCM_REMNNG_UNPAID                                        as PCM_REMNNG_UNPAID              ,
  LigneCom.CALIPSO_CD                                               as CALIPSO_CD                     ,  
  LigneCom.ENGGMNT_DURATION                                         as ENGGMNT_DURATION               ,
  LigneCom.SECOND_IMEI_CD                                           as SECOND_IMEI_CD                 ,
  LigneCom.SECOND_EAN_CD                                            as SECOND_EAN_CD                  ,
  LigneCom.SECOND_MSISDN_ID                                         as SECOND_MSISDN_ID               ,
  LigneCom.SECOND_SIM_CD                                            as SECOND_SIM_CD                  ,
  LigneCom.INVOICE_ADDRESS_MAIL_NM                                  as INVOICE_ADDRESS_MAIL_NM        ,
  LigneCom.IMEI_CD                                                  as IMEI_CD                        ,
  LigneCom.EAN_CD                                                   as EAN_CD                         ,
  LigneCom.QUEUE_TS                                                 as QUEUE_TS                       ,
  '${RUN_ID}'                                                       as RUN_ID                         ,
  LigneCom.STREAMING_TS                                             as STREAMING_TS                   ,
  Current_Timestamp(0)                                              as CREATION_TS                    ,
  Null                                                              as LAST_MODIF_TS                  ,
  1                                                                 as HOT_IN                         ,
  1                                                                 as FRESH_IN                       ,
  0                                                                 as COHERENCE_IN
From
  ${KNB_COM_TMP}.ORD_W_ORDER_AGC_LINE_COM LigneCom
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_COM_TMP}.ORD_T_ORDER_AGC_LINE_COM;
.if errorcode <> 0 then .quit 1


