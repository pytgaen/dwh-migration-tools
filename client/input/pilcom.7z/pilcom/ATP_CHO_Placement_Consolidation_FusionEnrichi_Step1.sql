-- $HEADER: mm2pco/current/sql/ATP_CHO_Placement_Consolidation_FusionEnrichi_Step1.sql 13_05#2 27-JAN-2016 11:35:55 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_FusionEnrichi_Step1.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 12/12/2016     HOB         Modif : Ajout Champs VA
--------------------------------------------------------------------------------

.set width 2500;


Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 all;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2
(
  ACTE_ID                     ,
  DEMANDE_ID                  ,
  EXTERNAL_INT_ID             ,
  INT_DEPOSIT_TS              ,
  INT_DEPOSIT_DT              ,
  OPERATOR_PROVIDER_ID        ,
  RESOLU_ID                   ,
  CONCLU_ID                   ,
  SSCONCLU_ID                 ,
  TYPE_COMMANDE               ,
  RSFCOMMENTAIRE_DS           ,
  PLTF_CO                     ,
  INTRNL_SOURCE_ID            ,
  SOLDOFF_SRC_CD              ,
  PRODUCT_ID                  ,
  OTO_OFFER_CD                ,
  OTO_OFFER_TYPE_CD           ,
  LOGIN_CREA                  ,
  LOGIN_RESP                  ,
  INT_MODIF_TS                ,
  CANALVENTE                  ,
  OTO_OSCAR_VALUE_NU          ,
  PRODUIT_PRINCIPAL_CHO       ,
  IN_CLIDOS                   ,
  TYPE_OT_SO                  ,
  CANALDEM                    ,
  CANALDEM_MTHD               ,
  INT_REASON_CD               ,
  CLIENT_NU                   ,
  CLIENT_NU_NEW_PORTE         ,
  DOSSIER_NU                  ,
  DOSSIER_NU_NEW_PORTE        ,
  DOSSIER_DATE_ACTIV          ,
  DOSSIER_DATE_RESIL          ,
  DOSSIER_TYPE_RESIL          ,
  DOSSIER_MOTIF_RESIL         ,
  DMC_LINE_ID                 ,
  DMC_MASTER_LINE_ID          ,
  DMC_LINE_TYPE               ,
  DMC_ACTIVATION_DT           ,
  PAR_DEPRTMNT_ID             ,
  PAR_POSTAL_CD               ,
  PAR_INSEE_NB                ,
  PAR_BU_CD                   ,
  PAR_GEO_MACROZONE           ,
  PAR_UNIFIED_PARTY_ID        ,
  PAR_PARTY_REGRPMNT_ID       ,
  PAR_IRIS2000_CD             ,
  PAR_FIBER_IN                ,
  DMC_CONVERGENT_IN           ,
  DMC_LINE_ID_INT             ,
  DMC_LINE_TYPE_INT           ,
  DMC_ACTIVATION_DT_INT       ,
  DMC_SERVICE_ACCESS_ID       ,
  OFFRE_INT_PRE               ,
  PRESFACT_CO_PRECED          ,
  PRESFACT_CO_OFFRE_OPT_ACQ   ,
  INB_PRESFACT_ACQ_ADV        ,
  INB_PRESFACT_ACQ_AGAP       ,
  PARC_DT_DEBUT               ,
  PARC_DT_FIN                 ,
  ORDAGD_DT_CONF              ,
  CONTRCT_DT_SIGN_PREC        ,
  CONTRCT_DT_FIN_PREC         ,
  CONTRCT_DT_SIGN_POST        ,
  CONTRCT_DUREE_ENG           ,
  CONTRCT_UNIT_ENG            ,
  EDO_ID                      ,
  FLAG_PLT_CONV               ,
  FLAG_PLT_SCH                ,
  FLAG_TEAM_MKT               ,
  FLAG_TYPE_CMP               ,
  TYPE_EDO                    ,
  EDO_ID_HIER                 ,
  TYPE_EDO_HIER               ,
  ORG_REF_TRAV                ,
  ORG_AGENT_ID                ,
  ORG_POC_XI                  ,
  ORG_NOM                     ,
  ORG_PRENOM                  ,
  ORG_GROUPE_ID               ,
  ORG_GROUPE_ID_HIER          ,
  ORG_ACTVT_REEL              ,
  ORG_RESP_REF_TRAV           ,
  ORG_RESP_AGENT_ID           ,
  ORG_RESP_XI                 ,
  ORG_RESP_ACTVT_REEL         ,
  PAR_LASTNAME                ,
  PAR_FIRSTNAME               ,
  PAR_TYPE                    ,
  PAR_IMSI                    ,
  PAR_EMAIL                   ,
  PAR_BILL_ADRESS_1           ,
  PAR_BILL_ADRESS_2           ,
  PAR_BILL_ADRESS_3           ,
  PAR_BILL_ADRESS_4           ,
  PAR_BILL_VILLE              ,
  PAR_BILL_CD_POSTAL          ,
  PAR_INSEE_CD                ,
  PAR_DO                      ,
  PAR_USCM                    ,
  PAR_USCM_DS                 ,
  PAR_USCM_USCM_DS            ,
  PAR_USCM_REGUSCM            ,
  PAR_USCM_REGUSCM_DS         ,
  PAR_AID                     ,
  PAR_ND                      ,
  PAR_MOB_IMEI                ,
  PAR_MOB_TAC                 ,
  PAR_MOB_SIM                 ,
  PAR_SCORE_NU_MOB            ,
  PAR_SCORE_IN_MOB            ,
  PAR_TRESHOLD_NU_MOB         ,
  PAR_SCORE_NU_INT            ,
  PAR_SCORE_IN_INT            ,
  PAR_TRESHOLD_NU_INT         ,
  FLAG_MAINT_INT_FALSE
)
Select
  Commande.ACTE_ID                                                            as ACTE_ID                    ,
  Commande.DEMANDE_ID                                                         as DEMANDE_ID                 ,
  Commande.EXTERNAL_INT_ID                                                    as EXTERNAL_INT_ID            ,
  Commande.INT_DEPOSIT_TS                                                     as INT_DEPOSIT_TS             ,
  Commande.INT_DEPOSIT_DT                                                     as INT_DEPOSIT_DT             ,
  Commande.OPERATOR_PROVIDER_ID                                               as OPERATOR_PROVIDER_ID       ,
  Commande.RESOLU_ID                                                          as RESOLU_ID                  ,
  Commande.CONCLU_ID                                                          as CONCLU_ID                  ,
  Coalesce(SousConclu.SSCONCLU_ID,Commande.SSCONCLU_ID)                       as SSCONCLU_ID                ,
  Commande.TYPE_COMMANDE                                                      as TYPE_COMMANDE              ,
  Commande.RSFCOMMENTAIRE_DS                                                  as RSFCOMMENTAIRE_DS          ,
  Commande.PLTF_CO                                                            as PLTF_CO                    ,
  Commande.INTRNL_SOURCE_ID                                                   as INTRNL_SOURCE_ID           ,
  Commande.SOLDOFF_SRC_CD                                                     as SOLDOFF_SRC_CD             ,
  Commande.PRODUCT_ID                                                         as PRODUCT_ID                 ,
  Commande.OTO_OFFER_CD                                                       as OTO_OFFER_CD               ,
  Commande.OTO_OFFER_TYPE_CD                                                  as OTO_OFFER_TYPE_CD          ,
  Commande.LOGIN_CREA                                                         as LOGIN_CREA                 ,
  Commande.LOGIN_RESP                                                         as LOGIN_RESP                 ,
  Commande.INT_MODIF_TS                                                       as INT_MODIF_TS               ,
  Commande.CANALVENTE                                                         as CANALVENTE                 ,
  Commande.OTO_OSCAR_VALUE_NU                                                 as OTO_OSCAR_VALUE_NU         ,
  Commande.PRODUIT_PRINCIPAL_CHO                                              as PRODUIT_PRINCIPAL_CHO      ,
  Commande.IN_CLIDOS                                                          as IN_CLIDOS                  ,
  Commande.TYPE_OT_SO                                                         as TYPE_OT_SO                 ,
  Coalesce(CanalDem.CANALDEM,Commande.CANALDEM)                               as CANALDEM                   ,
  Coalesce(CanalDem.CANALDEM_MTHD,Commande.CANALDEM_MTHD)                     as CANALDEM_MTHD              ,
  Coalesce(CanalDem.INT_REASON_CD,Commande.INT_REASON_CD)                     as INT_REASON_CD              ,
  --Coalesce(ClientDos.CLIENT_NU,Commande.CLIENT_NU)                            as CLIENT_NU                  ,
  --Coalesce(ClientDos.DOSSIER_NU,Commande.DOSSIER_NU)                          as DOSSIER_NU                 ,
  --Enrichissement du client dossier + la portabilité + Statut Dossier
  Coalesce(ClientDosRes.CLIENT_NU,ClientDos.CLIENT_NU,Commande.CLIENT_NU)     as CLIENT_NU                  ,
  Coalesce(ClientDosRes.CLIENT_NU_NEW_PORTE,Commande.CLIENT_NU_NEW_PORTE)     as CLIENT_NU_NEW_PORTE        ,
  Coalesce(ClientDosRes.DOSSIER_NU,ClientDos.DOSSIER_NU,Commande.DOSSIER_NU)  as DOSSIER_NU                 ,
  Coalesce(ClientDosRes.DOSSIER_NU_NEW_PORTE,Commande.DOSSIER_NU_NEW_PORTE)   as DOSSIER_NU_NEW_PORTE       ,
  Coalesce(NumIMSI.DOSSIER_DATE_ACTIV,Commande.DOSSIER_DATE_ACTIV)            as DOSSIER_DATE_ACTIV         ,
  Coalesce(NumIMSI.DOSSIER_DATE_RESIL,Commande.DOSSIER_DATE_RESIL)            as DOSSIER_DATE_RESIL         ,
  Coalesce(NumIMSI.DOSSIER_TYPE_RESIL,Commande.DOSSIER_TYPE_RESIL)            as DOSSIER_TYPE_RESIL         ,
  Coalesce(NumIMSI.DOSSIER_MOTIF_RESIL,Commande.DOSSIER_MOTIF_RESIL)          as DOSSIER_MOTIF_RESIL        ,
  Commande.DMC_LINE_ID                                                        as DMC_LINE_ID                ,
  Commande.DMC_MASTER_LINE_ID                                                 as DMC_MASTER_LINE_ID         ,
  Commande.DMC_LINE_TYPE                                                      as DMC_LINE_TYPE              ,
  Commande.DMC_ACTIVATION_DT                                                  as DMC_ACTIVATION_DT          ,
  Commande.PAR_DEPRTMNT_ID                                                    As PAR_DEPRTMNT_ID            ,
  Commande.PAR_POSTAL_CD                                                      As PAR_POSTAL_CD              ,
  Commande.PAR_INSEE_NB                                                       As PAR_INSEE_NB               ,
  Commande.PAR_BU_CD                                                          As PAR_BU_CD                  ,
  Commande.PAR_GEO_MACROZONE                                                  As PAR_GEO_MACROZONE          ,
  Commande.PAR_UNIFIED_PARTY_ID                                               As PAR_UNIFIED_PARTY_ID       ,
  Commande.PAR_PARTY_REGRPMNT_ID                                              As PAR_PARTY_REGRPMNT_ID      ,
  Commande.PAR_IRIS2000_CD                                                    As PAR_IRIS2000_CD            ,
  Commande.PAR_FIBER_IN                                                       As PAR_FIBER_IN               ,
  Commande.DMC_CONVERGENT_IN                                                  as DMC_CONVERGENT_IN          ,
  Commande.DMC_LINE_ID_INT                                                    as DMC_LINE_ID_INT            ,
  Commande.DMC_LINE_TYPE_INT                                                  as DMC_LINE_TYPE_INT          ,
  Commande.DMC_ACTIVATION_DT_INT                                              as DMC_ACTIVATION_DT_INT      ,
  Commande.DMC_SERVICE_ACCESS_ID                                              as DMC_SERVICE_ACCESS_ID      ,
  Commande.OFFRE_INT_PRE                                                      as OFFRE_INT_PRE              ,
  Commande.PRESFACT_CO_PRECED                                                 as PRESFACT_CO_PRECED         ,
  --On place Ici Le code de l'option ou offre acquise
  Coalesce(SousConclu.SSCONCLU_ID,Commande.SSCONCLU_ID)                       as PRESFACT_CO_OFFRE_OPT_ACQ  ,
  Commande.INB_PRESFACT_ACQ_ADV                                               as INB_PRESFACT_ACQ_ADV       ,
  Commande.INB_PRESFACT_ACQ_AGAP                                              as INB_PRESFACT_ACQ_AGAP      ,
  Commande.PARC_DT_DEBUT                                                      as PARC_DT_DEBUT              ,
  Commande.PARC_DT_FIN                                                        as PARC_DT_FIN                ,
  Commande.ORDAGD_DT_CONF                                                     as ORDAGD_DT_CONF             ,
  Commande.CONTRCT_DT_SIGN_PREC                                               as CONTRCT_DT_SIGN_PREC       ,
  Commande.CONTRCT_DT_FIN_PREC                                                as CONTRCT_DT_FIN_PREC        ,
  Commande.CONTRCT_DT_SIGN_POST                                               as CONTRCT_DT_SIGN_POST       ,
  Commande.CONTRCT_DUREE_ENG                                                  as CONTRCT_DUREE_ENG          ,
  Commande.CONTRCT_UNIT_ENG                                                   as CONTRCT_UNIT_ENG           ,
  Commande.EDO_ID                                                             as EDO_ID                     ,
  Commande.FLAG_PLT_CONV                                                      as FLAG_PLT_CONV              ,
  Commande.FLAG_PLT_SCH                                                       as FLAG_PLT_SCH               ,
  Commande.FLAG_TEAM_MKT                                                      as FLAG_TEAM_MKT              ,
  Commande.FLAG_TYPE_CMP                                                      as FLAG_TYPE_CMP              ,
  Commande.TYPE_EDO                                                           as TYPE_EDO                   ,
  Commande.EDO_ID_HIER                                                        as EDO_ID_HIER                ,
  Commande.TYPE_EDO_HIER                                                      as TYPE_EDO_HIER              ,
  Coalesce(VendeurVente.ORG_REF_TRAV,Commande.ORG_REF_TRAV)                   as ORG_REF_TRAV               ,
  Coalesce(VendeurVente.ORG_AGENT_ID,Commande.ORG_AGENT_ID)                   as ORG_AGENT_ID               ,
  Coalesce(VendeurVente.ORG_POC_XI,Commande.ORG_POC_XI)                       as ORG_POC_XI                 ,
  Coalesce(VendeurVente.ORG_NOM,Commande.ORG_NOM)                             as ORG_NOM                    ,
  Coalesce(VendeurVente.ORG_PRENOM,Commande.ORG_PRENOM)                       as ORG_PRENOM                 ,
  Coalesce(VendeurVente.ORG_GROUPE_ID,Commande.ORG_GROUPE_ID)                 as ORG_GROUPE_ID              ,
  Coalesce(VendeurVente.ORG_GROUPE_ID_HIER,Commande.ORG_GROUPE_ID_HIER)       as ORG_GROUPE_ID_HIER         ,
  Coalesce(VendeurActiv.ORG_ACTVT_REEL,Commande.ORG_ACTVT_REEL)               as ORG_ACTVT_REEL             ,
  Coalesce(VendeurResp.ORG_RESP_REF_TRAV,Commande.ORG_RESP_REF_TRAV)          as ORG_RESP_REF_TRAV          ,
  Coalesce(VendeurResp.ORG_RESP_AGENT_ID,Commande.ORG_RESP_AGENT_ID)          as ORG_RESP_AGENT_ID          ,
  Coalesce(VendeurResp.ORG_RESP_XI,Commande.ORG_RESP_XI)                      as ORG_RESP_XI                ,
  Coalesce(RespActiv.ORG_RESP_ACTVT_REEL,RespActiv.ORG_RESP_ACTVT_REEL)       as ORG_RESP_ACTVT_REEL        ,
  Commande.PAR_LASTNAME                                                       as PAR_LASTNAME               ,
  Commande.PAR_FIRSTNAME                                                      as PAR_FIRSTNAME              ,
  Commande.PAR_TYPE                                                           as PAR_TYPE                   ,
  Coalesce(NumIMSI.PAR_IMSI,Commande.PAR_IMSI)                                as PAR_IMSI                   ,
  Commande.PAR_EMAIL                                                          as PAR_EMAIL                  ,
  Commande.PAR_BILL_ADRESS_1                                                  as PAR_BILL_ADRESS_1          ,
  Commande.PAR_BILL_ADRESS_2                                                  as PAR_BILL_ADRESS_2          ,
  Commande.PAR_BILL_ADRESS_3                                                  as PAR_BILL_ADRESS_3          ,
  Commande.PAR_BILL_ADRESS_4                                                  as PAR_BILL_ADRESS_4          ,
  Commande.PAR_BILL_VILLE                                                     as PAR_BILL_VILLE             ,
  Commande.PAR_BILL_CD_POSTAL                                                 as PAR_BILL_CD_POSTAL         ,
  Commande.PAR_INSEE_CD                                                       as PAR_INSEE_CD               ,
  Commande.PAR_DO                                                             as PAR_DO                     ,
  Commande.PAR_USCM                                                           as PAR_USCM                   ,
  Commande.PAR_USCM_DS                                                        as PAR_USCM_DS                ,
  Commande.PAR_USCM_USCM_DS                                                   as PAR_USCM_USCM_DS           ,
  Commande.PAR_USCM_REGUSCM                                                   as PAR_USCM_REGUSCM           ,
  Commande.PAR_USCM_REGUSCM_DS                                                as PAR_USCM_REGUSCM_DS        ,
  Commande.PAR_AID                                                            as PAR_AID                    ,
  Commande.PAR_ND                                                             as PAR_ND                     ,
  Commande.PAR_MOB_IMEI                                                       as PAR_MOB_IMEI               ,
  Commande.PAR_MOB_TAC                                                        as PAR_MOB_TAC                ,
  Commande.PAR_MOB_SIM                                                        as PAR_MOB_SIM                ,
  Commande.PAR_SCORE_NU_MOB                                                   as PAR_SCORE_NU_MOB           ,
  Commande.PAR_SCORE_IN_MOB                                                   as PAR_SCORE_IN_MOB           ,
  Commande.PAR_TRESHOLD_NU_MOB                                                as PAR_TRESHOLD_NU_MOB        ,
  Commande.PAR_SCORE_NU_INT                                                   as PAR_SCORE_NU_INT           ,
  Commande.PAR_SCORE_IN_INT                                                   as PAR_SCORE_IN_INT           ,
  Commande.PAR_TRESHOLD_NU_INT                                                as PAR_TRESHOLD_NU_INT        ,
  Commande.FLAG_MAINT_INT_FALSE                                               as FLAG_MAINT_INT_FALSE
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_1 Commande
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_VENDEUR VendeurVente
    On    Commande.ACTE_ID        = VendeurVente.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VendeurVente.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_VENDACTIV VendeurActiv
    On    Commande.ACTE_ID        = VendeurActiv.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VendeurActiv.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_VENDRESP VendeurResp
    On    Commande.ACTE_ID        = VendeurResp.ACTE_ID
      And Commande.INT_DEPOSIT_DT = VendeurResp.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_SSCONCLU SousConclu
    On    Commande.ACTE_ID        = SousConclu.ACTE_ID
      And Commande.INT_DEPOSIT_DT = SousConclu.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CLIDOSS ClientDos
    On    Commande.ACTE_ID        = ClientDos.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClientDos.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CANALDEM CanalDem
    On    Commande.ACTE_ID        = CanalDem.ACTE_ID
      And Commande.INT_DEPOSIT_DT = CanalDem.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CLIDOSSRES ClientDosRes
    On    Commande.ACTE_ID        = ClientDosRes.ACTE_ID
      And Commande.INT_DEPOSIT_DT = ClientDosRes.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_RESPACTIV RespActiv
    On    Commande.ACTE_ID        = RespActiv.ACTE_ID
      And Commande.INT_DEPOSIT_DT = RespActiv.INT_DEPOSIT_DT
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CLIIMSI NumIMSI
    On    Commande.ACTE_ID        = NumIMSI.ACTE_ID
      And Commande.INT_DEPOSIT_DT = NumIMSI.INT_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2;
.if errorcode <> 0 then .quit 1

