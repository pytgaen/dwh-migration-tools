--$HEADER:   mm2pco/current/sql/ATP_SOFT_MOB_Acte_Consolidation_Enrichissement_Step2_VAD_Annulation.sql 13_05#5 23-AVR-2018 14:00:29 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_MOB_Acte_Consolidation_Enrichissement_Step2_VAD_Annulation.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : 
--------------------------------------------------------------------------------
--                HISTORIQUE
--²
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 30/05/2016      HLA         Creation
-- 23/04/2018      JCR         Ajout pour propager annulation cmd SOFT
--------------------------------------------------------------------------------

.set width 2500;

Delete from ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_ORDER_CANCEL all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_ORDER_CANCEL
(
  ACTE_ID                        ,
  ORDER_DEPOSIT_DT               ,
  ORDER_CANCELING_DT              
 )
 
 select 
  RefId.ACTE_ID                  as ACTE_ID             ,
  RefId.ORDER_DEPOSIT_DT         as ORDER_DEPOSIT_DT    ,
  Case  When  SOFT_M.ORDER_LAST_STATUT_CD   In ('ANNULE')
            Then Cast(SOFT_M.ORDER_LAST_STATUT_MODIF_TS as Date)
            Else VAD.CDE_DATE_ANNULATION
  End                            as ORDER_CANCELING_DT

From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_CAL RefId

  Inner join ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_MOB SOFT_M
    On      RefId.ACTE_ID             = SOFT_M.ACTE_ID
     And    RefId.ORDER_DEPOSIT_DT    = SOFT_M.ORDER_DEPOSIT_DT
  
  Left Outer Join ${KNB_IBU_SOC_V}.VF_ORD_F_ORDER_VAD VAD
    On    SOFT_M.VAD_ORDER_ID  = VAD.CDE_REFERENCE
     And  VAD.ETAT = '${P_PIL_515}'
     And  (Coalesce(VAD.MOTIF_ANNULATION,'#') Not In (${L_PIL_124})  Or  VAD.MOTIF_ANNULATION Is Null )

Where
  (1=1)
  And ( SOFT_M.ORDER_LAST_STATUT_CD In ('ANNULE')
      Or 
        VAD.CDE_REFERENCE Is Not Null
       )
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_ORDER_CANCEL;
.if errorcode <> 0 then .quit 1
