-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERC_Placement_Cold_Alimentation_Step5_Enrichissement_O3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'enrichissement O3
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 26/03/2014      MCA         Creation
-- 19/08/2014      MCA         Indus
-- 22/10/2014      HZO         Mise à Jour des RG pour le calcul des Flags (SCH et convergence)
-- 03/03/2016      TPI         QC 1072 : Modification paramètres
--------------------------------------------------------------------------------

.set width 2500;



--On calcul en avance de phase le code O3

----------------------------------------------------------------------------------------------
Delete from ${KNB_PCO_TMP}.ORD_W_ORDER_ERC_O3;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------



Insert into ${KNB_PCO_TMP}.ORD_W_ORDER_ERC_O3
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  ,
  FLAG_TYPE_GEO             ,
  FLAG_TYPE_CPT_NTK         ,
  NETWRK_TYP_EDO_ID         
)
Select
  RefId.ACTE_ID                                               as ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT     ,
  RefId.EDO_ID                                                as EDO_ID               ,
  --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                   as FLAG_PLT_CONV        ,
        Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                   as FLAG_PLT_SCH         ,
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT' --
                Then  'INT'
              Else    'EXT'
        End                                                   as TYPE_EDO             ,
        RefEdoDOM.AXS_CLSSF_ID                                as FLAG_TYPE_GEO        ,
        RefEdoCompNetwork.AXS_CLSSF_ID                        as FLAG_TYPE_CPT_NTK    ,
        RefEdo.NETWRK_TYP_EDO_ID                              as NETWRK_TYP_EDO_ID    
       
From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC RefId
    Left Outer Join
    (--On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
        Select
          EDO_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
          And EdoAx.FRESH_IN          = 1
          And EdoAx.CURRENT_IN        = 1
          And EdoAx.CLOSURE_DT        Is Null
        Group By
          EDO_ID
    ) RefEdoConv
        On  RefId.EDO_ID   = RefEdoConv.EDO_ID
        --On va dans le referentiel axs_edo pour remonter les CARAIBES et REUNION
    Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111}) -- 'CARAIBES','REUNION'
            And EdoAx.FRESH_IN              = 1
            And EdoAx.CURRENT_IN            = 1
            And EdoAx.CLOSURE_DT            Is Null
         Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoDOM
          On  RefId.EDO_ID   = RefEdoDOM.EDO_ID
          --On va dans le referentiel axs_edo pour remonter les GSS et GSA
    Left Outer Join
      (
       Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID       
      From
        ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112}) -- 'GSS','GSA','AUTRC'
        And EdoAx.FRESH_IN              = 1
        And EdoAx.CURRENT_IN            = 1
        And EdoAx.CLOSURE_DT            Is Null
      Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoCompNetwork
          On  RefId.EDO_ID   = RefEdoCompNetwork.EDO_ID
    Left Outer Join
      (
       --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
        Select
          EDO_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
            Group By
            EDO_ID
    ) RefEdoAVSC
        On  RefId.EDO_ID   = RefEdoAVSC.EDO_ID
         --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
    Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
        On    RefId.EDO_ID         = RefEdo.EDO_ID
        And RefEdo.CURRENT_IN     = 1

Where
  (1=1)
Qualify Row_Number() Over(Partition by RefId.ACTE_ID Order By RefId.ORDER_DEPOSIT_DT Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_ORDER_ERC_O3;
.if errorcode <> 0 then .quit 1


----Etape 2 : Insertion des Lignes Online
Insert into ${KNB_PCO_TMP}.ORD_W_ORDER_ERC_O3
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  ,
  FLAG_TYPE_GEO             ,
  FLAG_TYPE_CPT_NTK         ,
  NETWRK_TYP_EDO_ID         
)
select 
  RefId.ACTE_ID                                               as ACTE_ID              ,
  RefId.ORDER_DEPOSIT_DT                                      as ORDER_DEPOSIT_DT     ,
  107008                                                      as EDO_ID               ,
  0                                                           as FLAG_PLT_CONV        ,
  0                                                           as FLAG_PLT_SCH         ,
  'INT'                                                       as TYPE_EDO             ,
  0                                                           as FLAG_TYPE_GEO        ,
  NULL                                                        as FLAG_TYPE_CPT_NTK    ,
  NULL                                                        as NETWRK_TYP_EDO_ID     
  
From
   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_ERC RefId
   
Where 
(1=1)
 and RefId.STORE_CD='ONLINE'
 and NOT EXISTS 
 (
   Select 
     1 
   From 
     ${KNB_PCO_TMP}.ORD_W_ORDER_ERC_O3 RefO3 
   Where
     (1=1)
     And  RefO3.ACTE_ID           = RefId.ACTE_ID
     And  RefO3.ORDER_DEPOSIT_DT  = RefId.ORDER_DEPOSIT_DT
   )
 Qualify Row_Number() Over(Partition by RefId.ACTE_ID Order By RefId.ORDER_DEPOSIT_DT Desc)=1
  ;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_ORDER_ERC_O3;
.if errorcode <> 0 then .quit 1

.quit 0


