-- $HEADER: mm2pco/current/sql/ATP_PIF_Placement_Consolidation_Enrichissement_Step1_O3.sql 13_05#5 13-AVR-2017 08:51:25 FQJR5800
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step1_O3.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/08/2016      HLA         Creation
-- 16/12/2016      HLA         Modification
-- 10/04/2017      JCR         Modif: ajout restriction dans le quickwin priorité SC QC 1641 + QC 1642
-- 07/07/2021      BCH         PILCOM-933 : Optimisation O3
-- 17/08/2021      BCH         PILCOM-833 : Modification jointure Placements PIF
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 5 : Alimentation de la table -> ONline pour calcul Hier                          ----
---------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     
 )
Select
  PIF.ACTE_ID                             AS ACTE_ID                   ,
  PIF.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT          ,
  Null                                    AS AGENT_ID                  ,
  Canal.EDO_ID                            As EDO_ID                    
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 PIF
  Inner Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_PIF Canal
    On    PIF.PIF_CANAL_DS    = Canal.PIF_CANAL_DS
      And Canal.CURRENT_IN    = 1
      And Canal.CLOSURE_DT    Is Null
 Where
   (1=1)
Qualify Row_number() over (Partition by PIF.ACTE_ID,PIF.ORDER_DEPOSIT_DT Order By Canal.EDO_ID Asc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP  AD                                             ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  DISTRBTN_CHANNL_ID         ,
  ACTIVITY                   ,
  FLAG_PLT_CONV_NB           ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_TYPE_PTN_NTK          ,
  FLAG_PLT_SCH_IN            ,
  PRIO                       ,
  FLAG_AD_SC                 
)
Select
  PIF.ACTE_ID                             AS ACTE_ID                                 ,
  PIF.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT                        ,
  ORG.CUID                                AS AGENT_ID                                ,
  ORG.EDO_ID                              As EDO_ID                                  ,
  ORG.TYPE_EDO                            As TYPE_EDO_ID                             ,
  PrioTypeEDO.DISTRBTN_CHANNL_ID          As DISTRBTN_CHANNL_ID                      ,
  ORG.ACTIVITY                            As ACTIVITY                                ,
  ORG.FLAG_PLT_CONV_NB                    As FLAG_PLT_CONV_NB                        ,
  ORG.FLAG_TYPE_GEO_CD                    As FLAG_TYPE_GEO_CD                        ,
 Case   When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'GSS'
          Then 'GSS'
        When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'GSA'
          Then 'GSA'
        When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'AUTRC'
          Then 'AUT'
        When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'GROSS'
          Then 'GRO'
  End                                     As FLAG_TYPE_CPT_NTK                       ,
  ORG.NETWRK_TYP_EDO_ID                   As NETWRK_TYP_EDO_ID                       ,
  Case  When PrioTypeBoutique.DISTRBTN_CHANNL_ID  = 'MOBI'
          Then 'Mob'
        When PrioTypeBoutique.DISTRBTN_CHANNL_ID  In ('PSE','PST')
          Then 'GDT'
        When PrioTypeBoutique.DISTRBTN_CHANNL_ID  In ('FC')
          Then 'FC'
  End                                      As FLAG_TYPE_PTN_NTK                      ,
  0                                        As FLAG_PLT_SCH_IN                        ,
  0                                        As PRIO                                   ,
  1                                        As FLAG_AD_SC                             
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 As PIF
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_AD_EDO As ORG
        On    PIF.ORG_AGENT_ID       =   ORG.CUID
         And  PIF.ORDER_DEPOSIT_TS    >=  ORG.DT_DEBUT
         And  PIF.ORDER_DEPOSIT_TS    <=  ORG.DT_FIN
  Left Outer Join
  (
    Select
      EDO_ID                As  EDO_ID                  ,
      DISTRBTN_CHANNL_ID    As DISTRBTN_CHANNL_ID       
    From
      (
        Select
          EDO_ID                      As  EDO_ID                  ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID in ('MOBI','PSE','PST')
                  Then 'RP'
                When EdoAx.VAL_AXS_CLSSF_ID in ('GSS','GSA','GROSS','AUTRC')
                  Then 'RC'
                Else EdoAx.VAL_AXS_CLSSF_ID
          End                         As DISTRBTN_CHANNL_ID       ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID = 'BTQ'
                  Then 0
                When EdoAx.VAL_AXS_CLSSF_ID = 'PAP'
                  Then 1
                When EdoAx.VAL_AXS_CLSSF_ID in ('MOBI','PSE','PST')
                  Then 3
                When EdoAx.VAL_AXS_CLSSF_ID in ('GSS','GSA','GROSS','AUTRC')
                  Then 4
          End                         As PRIO                     
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In ('BTQ','PAP','MOBI','PSE','PST','GSS','GSA','GROSS','AUTRC')
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      )Tmp
    Qualify Row_Number() Over (Partition by EDO_ID Order by PRIO Asc)=1
  )PrioTypeEDO
    On ORG.EDO_ID   = PrioTypeEDO.EDO_ID
  Left Outer Join
  (
    Select
      EDO_ID                As  EDO_ID                  ,
      DISTRBTN_CHANNL_ID    As DISTRBTN_CHANNL_ID       
    From
      (
        Select
          EDO_ID                      As  EDO_ID                  ,
          EdoAx.VAL_AXS_CLSSF_ID      As DISTRBTN_CHANNL_ID       ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID = 'MOBI'
                  Then 0
                When EdoAx.VAL_AXS_CLSSF_ID = 'PSE'
                  Then 1
                When EdoAx.VAL_AXS_CLSSF_ID = 'PST'
                  Then 2
                When EdoAx.VAL_AXS_CLSSF_ID = 'FC'
                  Then 4
          End                         As PRIO                     
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In ('MOBI','PSE','PST','FC')
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      )Tmp
    Qualify Row_Number() Over (Partition by EDO_ID Order by PRIO Asc)=1
  )PrioTypeBoutique
    On ORG.EDO_ID   = PrioTypeBoutique.EDO_ID
  Left Outer Join
  (
    Select
      EDO_ID                As  EDO_ID                  ,
      DISTRBTN_CHANNL_ID    As DISTRBTN_CHANNL_ID       
    From
      (
        Select
          EDO_ID                      As  EDO_ID                  ,
          EdoAx.VAL_AXS_CLSSF_ID      As DISTRBTN_CHANNL_ID       ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID = 'GSS'
                  Then 0
                When EdoAx.VAL_AXS_CLSSF_ID = 'GSA'
                  Then 1
                When EdoAx.VAL_AXS_CLSSF_ID = 'GROSS'
                  Then 2
                When EdoAx.VAL_AXS_CLSSF_ID = 'AUTRC'
                  Then 4
          End                         As PRIO                     
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In ('GSS','GSA','GROSS','AUTRC')
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      )Tmp
    Qualify Row_Number() Over (Partition by EDO_ID Order by PRIO Asc)=1
  )PrioTypeBoutiqueRC
    On ORG.EDO_ID   = PrioTypeBoutiqueRC.EDO_ID
Where
   (1=1)
    And Not Exists
    (
      
      Select
        1
      From
        ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3 O3
      Where
         PIF.ACTE_ID=O3.ACTE_ID
      )
    And ORG.EDO_ID Is Not Null
-- Verification qu’il n’y a rien dans le QW SC avec une date de debut posterieure au QW AD 
    And Not Exists ( 
        Select 
        1 
        From ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORGSC
        where  PIF.ORG_AGENT_ID              =     ORGSC.CUID
        And PIF.ORDER_DEPOSIT_TS      >=    ORGSC.DT_DEBUT
        And PIF.ORDER_DEPOSIT_TS      <=    ORGSC.DT_FIN
        And ORGSC.DT_DEBUT            >     ORG.DT_DEBUT
    )
Qualify Row_number() over (Partition by PIF.ACTE_ID,PIF.ORDER_DEPOSIT_DT Order By  ORG.DT_DEBUT Desc, ORG.EDO_ID Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 3 : Alimentation de la table TMP  SC                                                ----
----------------------------------------------------------------------------------------------

--Calcul de l'activité
Create Volatile Table ${KNB_TERADATA_USER}.ORG_V_ACTIVITY_PIF(
  ACTE_ID       Bigint        Not Null      ,
  ACTIVITY      Varchar(45)                 
)
Primary Index (
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1



Insert Into ${KNB_TERADATA_USER}.ORG_V_ACTIVITY_PIF
(
  ACTE_ID     ,
  ACTIVITY    
)
Select
  RefAct.ACTE_ID                  as ACTE_ID            ,
  RefAct.ACTIVITY                 as ACTIVITY           
From
  (
    Select
      Placement.ACTE_ID                       As ACTE_ID              ,
      Placement.ORDER_DEPOSIT_DT              As ORDER_DEPOSIT_DT     ,
      ACTIVITY.CUID                           As AGENT_ID             ,
      ACTIVITY.START_ACTIVITY_TS              As START_ACTIVITY_TS    ,
      ACTIVITY.END_ACTIVITY_TS                As END_ACTIVITY_TS      ,
      ACTIVITY.ACTIVITY                       As ACTIVITY             ,
      Case  When ACTIVITY.SOURCE = 'RFOR'
              Then 1
            When ACTIVITY.SOURCE = 'CHO'
              Then 2
            Else 3
      End                                     As PRIO
    From
      ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 Placement
      Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_ACTIVITY As ACTIVITY
        On    Placement.ORG_AGENT_ID          =   ACTIVITY.CUID
          And Placement.ORDER_DEPOSIT_TS      >=  ACTIVITY.START_ACTIVITY_TS
          And Placement.ORDER_DEPOSIT_TS      <=  ACTIVITY.END_ACTIVITY_TS
    Where
      (1=1)
    Qualify Row_number() over
                              (
                                Partition by
                                  Placement.ACTE_ID                 
                                Order By
                                  PRIO ASC                          ,
                                  ACTIVITY.START_ACTIVITY_TS Desc   ,
                                  ACTIVITY.END_ACTIVITY_TS Desc
                              ) = 1
  ) RefAct
;
.if errorcode <> 0 then .quit 1

Collect stat On ${KNB_TERADATA_USER}.ORG_V_ACTIVITY_PIF Column(ACTE_ID);
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  DISTRBTN_CHANNL_ID         ,
  ACTIVITY                   ,
  FLAG_PLT_SCH_IN            ,
  FLAG_PLT_CONV_NB           ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_TYPE_PTN_NTK          ,
  PRIO                       ,
  FLAG_AD_SC
)
Select
  PIF.ACTE_ID                             AS ACTE_ID                   ,
  PIF.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT          ,
  ORG.CUID                                AS AGENT_ID                  ,
  ORG.EDO_ID_EQUI_RAT                     As EDO_ID                    ,
  ORG.FLAG_HIER_EQUI_RAT                  As TYPE_EDO_ID               ,
  NULL                                    As DISTRBTN_CHANNL_ID        ,
  Activity.ACTIVITY                       As ACTIVITY                  ,
  ORG.FLAG_SCH_EQUI_RAT                   As FLAG_PLT_SCH_IN           ,
  ORG.FLAG_PLT_CONV_EQUI_RAT              As FLAG_PLT_CONV_NB          ,
  NULL                                    As FLAG_TYPE_GEO_CD          ,
  NULL                                    As FLAG_TYPE_CPT_NTK         ,
  NULL                                    As NETWRK_TYP_EDO_ID         ,
  NULL                                    As FLAG_TYPE_PTN_NTK         ,
  Case  When ORG.SOURCE = 'MCRM'
          Then 1
        When ORG.SOURCE = 'POCC'
          Then 2
        When ORG.SOURCE = 'HRF'
          Then 3
        When ORG.SOURCE = 'RFOR'
          Then 4
        When ORG.SOURCE = 'EDL'
          Then 5
        When ORG.SOURCE = 'OEE'
          Then 6
        Else 7
  End                                     As PRIO                    ,
  0                                       As FLAG_AD_SC
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 As PIF
  Inner Join ${KNB_PCO_SOC}.V_ORG_H_AGENT_LNK_EDO As ORG
    On    PIF.ORG_AGENT_ID        =   ORG.CUID
     And  PIF.ORDER_DEPOSIT_TS      >=  ORG.DT_DEBUT
     And  PIF.ORDER_DEPOSIT_TS      <=   ORG.DT_FIN
  Left Outer Join ${KNB_TERADATA_USER}.ORG_V_ACTIVITY_PIF Activity
    On    PIF.ACTE_ID             = Activity.ACTE_ID
Where
   (1=1)
  And ORG.EDO_ID_EQUI_RAT Is Not Null
  And
  not  exists (
    select 1
     from   ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3 AD
       where
         PIF.ACTE_ID=AD.ACTE_ID
      )
Qualify Row_number() over (Partition by PIF.ACTE_ID,PIF.ORDER_DEPOSIT_DT Order By PRIO Asc , ORG.DT_DEBUT Desc, ORG.EDO_ID_EQUI_RAT Asc, ORG.DT_FIN Desc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 4 : Calcul de l'EDO par le code Externe dans le cas où cela ne marche pas       ----
---------------------------------------------------------------------------------------------



Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3
(
  ACTE_ID                    ,
  ORDER_DEPOSIT_DT           ,
  AGENT_ID                   ,
  EDO_ID                     ,
  TYPE_EDO_ID                ,
  DISTRBTN_CHANNL_ID         ,
  ACTIVITY                   ,
  FLAG_PLT_SCH_IN            ,
  FLAG_PLT_CONV_NB           ,
  FLAG_TYPE_GEO_CD           ,
  FLAG_TYPE_CPT_NTK          ,
  NETWRK_TYP_EDO_ID          ,
  FLAG_TYPE_PTN_NTK          ,
  PRIO                       ,
  FLAG_AD_SC
)
Select
  PIF.ACTE_ID                             AS ACTE_ID                   ,
  PIF.ORDER_DEPOSIT_DT                    AS ORDER_DEPOSIT_DT          ,
  PIF.ORG_AGENT_ID                        AS AGENT_ID                  ,
  RefEDO.EDO_ID                           As EDO_ID                    ,
  RefEDO.TYPE_EDO                         As TYPE_EDO_ID               ,
  PrioTypeEDO.DISTRBTN_CHANNL_ID          As DISTRBTN_CHANNL_ID        ,
  NULL                                    As ACTIVITY                  ,
  RefEDO.FLAG_PLT_SCH                     As FLAG_PLT_SCH_IN           ,
  RefEDO.FLAG_PLT_CONV                    As FLAG_PLT_CONV_NB          ,
  RefEDO.FLAG_TYPE_GEO                    As FLAG_TYPE_GEO_CD          ,
 Case   When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'GSS'
          Then 'GSS'
        When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'GSA'
          Then 'GSA'
        When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'AUTRC'
          Then 'AUT'
        When PrioTypeBoutiqueRC.DISTRBTN_CHANNL_ID  = 'GROSS'
          Then 'GRO'
  End                                     As FLAG_TYPE_CPT_NTK         ,
  RefEDO.NETWRK_TYP_EDO_ID                As NETWRK_TYP_EDO_ID         ,
  Case  When PrioTypeBoutique.DISTRBTN_CHANNL_ID  = 'MOBI'
          Then 'Mob'
        When PrioTypeBoutique.DISTRBTN_CHANNL_ID  In ('PSE','PST')
          Then 'GDT'
        When PrioTypeBoutique.DISTRBTN_CHANNL_ID  In ('FC')
          Then 'FC'
  End                                     As FLAG_TYPE_PTN_NTK         ,
  NULL                                    As PRIO                      ,
  RefEDO.FLAG_PLT_AD                      As FLAG_AD_SC                
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_1 PIF
  Inner Join ${KNB_PCO_TMP}.CAT_W_PILCOM_REFO3_JOUR RefEDO
    On    PIF.PIF_SELLR_SHOP_ID = RefEDO.EXTNL_VAL_COD_CD
      And PIF.ORDER_DEPOSIT_DT    Between RefEDO.START_EXTNL_VAL_DT And Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD'))
  Left Outer Join
  (
    Select
      EDO_ID                As  EDO_ID                  ,
      DISTRBTN_CHANNL_ID    As DISTRBTN_CHANNL_ID       
    From
      (
        Select
          EDO_ID                      As  EDO_ID                  ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID in ('MOBI','PSE','PST')
                  Then 'RP'
                When EdoAx.VAL_AXS_CLSSF_ID in ('GSS','GSA','GROSS','AUTRC')
                  Then 'RC'
                Else EdoAx.VAL_AXS_CLSSF_ID
          End                         As DISTRBTN_CHANNL_ID       ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID = 'BTQ'
                  Then 0
                When EdoAx.VAL_AXS_CLSSF_ID = 'PAP'
                  Then 1
                When EdoAx.VAL_AXS_CLSSF_ID in ('MOBI','PSE','PST')
                  Then 3
                When EdoAx.VAL_AXS_CLSSF_ID in ('GSS','GSA','GROSS','AUTRC')
                  Then 4
          End                         As PRIO                     
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In ('BTQ','PAP','MOBI','PSE','PST','GSS','GSA','GROSS','AUTRC')
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      )Tmp
    Qualify Row_Number() Over (Partition by EDO_ID Order by PRIO Asc)=1
  )PrioTypeEDO
    On RefEDO.EDO_ID   = PrioTypeEDO.EDO_ID
  Left Outer Join
  (
    Select
      EDO_ID                As  EDO_ID                  ,
      DISTRBTN_CHANNL_ID    As DISTRBTN_CHANNL_ID       
    From
      (
        Select
          EDO_ID                      As  EDO_ID                  ,
          EdoAx.VAL_AXS_CLSSF_ID      As DISTRBTN_CHANNL_ID       ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID = 'MOBI'
                  Then 0
                When EdoAx.VAL_AXS_CLSSF_ID = 'PSE'
                  Then 1
                When EdoAx.VAL_AXS_CLSSF_ID = 'PST'
                  Then 2
                When EdoAx.VAL_AXS_CLSSF_ID = 'FC'
                  Then 4
          End                         As PRIO                     
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In ('MOBI','PSE','PST','FC')
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      )Tmp
    Qualify Row_Number() Over (Partition by EDO_ID Order by PRIO Asc)=1
  )PrioTypeBoutique
    On RefEDO.EDO_ID   = PrioTypeBoutique.EDO_ID
  Left Outer Join
  (
    Select
      EDO_ID                As  EDO_ID                  ,
      DISTRBTN_CHANNL_ID    As DISTRBTN_CHANNL_ID       
    From
      (
        Select
          EDO_ID                      As  EDO_ID                  ,
          EdoAx.VAL_AXS_CLSSF_ID      As DISTRBTN_CHANNL_ID       ,
          Case  When EdoAx.VAL_AXS_CLSSF_ID = 'GSS'
                  Then 0
                When EdoAx.VAL_AXS_CLSSF_ID = 'GSA'
                  Then 1
                When EdoAx.VAL_AXS_CLSSF_ID = 'GROSS'
                  Then 2
                When EdoAx.VAL_AXS_CLSSF_ID = 'AUTRC'
                  Then 4
          End                         As PRIO                     
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
        (1=1)
        And EdoAx.VAL_AXS_CLSSF_ID  In ('GSS','GSA','GROSS','AUTRC')
        And EdoAx.FRESH_IN          = 1
        And EdoAx.CURRENT_IN        = 1
        And EdoAx.CLOSURE_DT        Is Null
      )Tmp
    Qualify Row_Number() Over (Partition by EDO_ID Order by PRIO Asc)=1
  )PrioTypeBoutiqueRC
    On RefEDO.EDO_ID   = PrioTypeBoutiqueRC.EDO_ID
Where
   (1=1)
  And
  Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3 AD
      where
        PIF.ACTE_ID=AD.ACTE_ID
      )
Qualify Row_Number() Over(Partition by  PIF.ACTE_ID
                          Order by      RefEDO.START_EXTNL_VAL_DT Desc    ,
                                        Coalesce(RefEDO.END_EXTNL_VAL_DT, Cast('99991231' AS Date Format 'YYYYMMDD')) Desc  
                         )=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3;
.if errorcode <> 0 then .quit 1




----------------------------------------------------------------------------------------------
-- Etape 5 : Delete de la table TMP    Calcul Hier                                        ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_HIER_O3 All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 6 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_HIER_O3
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  AGENT_ID                    ,
  UNIFIED_SHOP_CD             ,
  TYPE_EDO_ID                 ,
  ORG_TEAM_LEVEL_1_CD         ,
  ORG_TEAM_LEVEL_1_DS         ,
  ORG_TEAM_LEVEL_2_CD         ,
  ORG_TEAM_LEVEL_2_DS         ,
  ORG_TEAM_LEVEL_3_CD         ,
  ORG_TEAM_LEVEL_3_DS         ,
  ORG_TEAM_LEVEL_4_CD         ,
  ORG_TEAM_LEVEL_4_DS         ,
  WORK_TEAM_LEVEL_1_CD        ,
  WORK_TEAM_LEVEL_1_DS        ,
  WORK_TEAM_LEVEL_2_CD        ,
  WORK_TEAM_LEVEL_2_DS        ,
  WORK_TEAM_LEVEL_3_CD        ,
  WORK_TEAM_LEVEL_3_DS        ,
  WORK_TEAM_LEVEL_4_CD        ,
  WORK_TEAM_LEVEL_4_DS        

)
Select
  PIF.ACTE_ID                               AS ACTE_ID                     ,
  PIF.ORDER_DEPOSIT_DT                      AS ORDER_DEPOSIT_DT            ,
  PIF.AGENT_ID                              As AGENT_ID                    ,
  RefPDV.EXTNL_VAL_COD_CD                   As UNIFIED_SHOP_CD             ,
  Case    When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                    WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                Or  WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                Or  WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                Or  WLvl1.ORG_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                )
            Then '${P_PIL_236}'
          Else '${P_PIL_235}'
  End                                       As TYPE_EDO_ID                 ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As ORG_TEAM_LEVEL_1_CD         ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As ORG_TEAM_LEVEL_1_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As ORG_TEAM_LEVEL_2_CD         ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As ORG_TEAM_LEVEL_2_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As ORG_TEAM_LEVEL_3_CD         ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As ORG_TEAM_LEVEL_3_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As ORG_TEAM_LEVEL_4_CD         ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As ORG_TEAM_LEVEL_4_DS         ,
  Trim(WLvl1.ORG_TEAM_LEVEL_1_CD)           As WORK_TEAM_LEVEL_1_CD        ,
  WLvl1.ORG_TEAM_LEVEL_1_DS                 As WORK_TEAM_LEVEL_1_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_2_CD)           As WORK_TEAM_LEVEL_2_CD        ,
  WLvl1.ORG_TEAM_LEVEL_2_DS                 As WORK_TEAM_LEVEL_2_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_3_CD)           As WORK_TEAM_LEVEL_3_CD        ,
  WLvl1.ORG_TEAM_LEVEL_3_DS                 As WORK_TEAM_LEVEL_3_DS        ,
  Trim(WLvl1.ORG_TEAM_LEVEL_4_CD)           As WORK_TEAM_LEVEL_4_CD        ,
  WLvl1.ORG_TEAM_LEVEL_4_DS                 As WORK_TEAM_LEVEL_4_DS         
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_O3 PIF
  --On jointe dans l'orga Hierarchique
  Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_HIE_LVL_ALL WLvl1
     On   PIF.EDO_ID                           =   WLvl1.ORG_TEAM_LEVEL_1_CD
      And PIF.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_1_START_DT
      And PIF.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_1_END_DT
      And PIF.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_2_START_DT
      And PIF.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_2_END_DT
      And PIF.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_3_START_DT
      And PIF.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_3_END_DT
      And PIF.ORDER_DEPOSIT_DT                 >=  WLvl1.ORG_TEAM_LEVEL_4_START_DT
      And PIF.ORDER_DEPOSIT_DT                 <=  WLvl1.ORG_TEAM_LEVEL_4_END_DT
  Left Outer Join ${KNB_COM_SOC}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPDV
    On PIF.EDO_ID                       =   RefPDV.EDO_ID
      And RefPDV.CURRENT_IN             =   1
      And RefPDV.CLOSURE_DT             Is Null
      And RefPDV.EXTNL_COD_CD           =   'ADV'
Where
  (1=1)
Qualify Row_Number() Over (Partition By PIF.ACTE_ID,PIF.ORDER_DEPOSIT_DT Order By           WLvl1.ORG_TEAM_LEVEL_1_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_PRIORITE Asc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_START_DT Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_1_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_2_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_3_CD Desc,
                                                                          WLvl1.ORG_TEAM_LEVEL_4_CD Desc
                          ) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_EDO_HIER_O3;
.if errorcode <> 0 then .quit 1


.quit 0
