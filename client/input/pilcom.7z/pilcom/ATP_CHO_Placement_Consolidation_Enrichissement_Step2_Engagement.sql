-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CHO_Placement_Consolidation_Enrichissement_Step2_Engagement.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


  Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATOLD all
; Delete from ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATNEW all
;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------
--On calcul la date de fin de contrat avant l'acte de vente :
------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATOLD
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  CONTRCT_DT_SIGN_PREC      ,
  CONTRCT_DT_FIN_PREC       
)
Select
  RefId.ACTE_ID                     as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT             ,
  Cont.CONTRDOS_DT_SIGN_CONTRAT     as CONTRCT_DT_SIGN_PREC       ,
  --On fais la différence entre les dates de contrats : J (Jour), M (Mois), A (Années)
  Case  --Dans les cas d'un contrat en jour
        When Cont.CONTRDOS_CO_UNIT_CONTRAT = 'J'
          Then (Cont.CONTRDOS_DT_SIGN_CONTRAT + Cast(Cont.CONTRDOS_NB_DUR_CONTRAT as interval day(4)))
        --Dans le cadre des mois :
        When Cont.CONTRDOS_CO_UNIT_CONTRAT = 'M'
          Then ADD_MONTHS(Cont.CONTRDOS_DT_SIGN_CONTRAT,Cont.CONTRDOS_NB_DUR_CONTRAT)
        --Dans le cadre des années
        When Cont.CONTRDOS_CO_UNIT_CONTRAT = 'A'
          Then (Cont.CONTRDOS_DT_SIGN_CONTRAT + Cast(Cont.CONTRDOS_NB_DUR_CONTRAT as interval Year))
        Else
          Null
  End                               as CONTRCT_DT_FIN_PREC        
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 RefId
  Inner Join ${KNB_IBU_SOC}.V_THCONTRDOS Cont
    On    RefId.CLIENT_NU         = Cont.CONTRDOS_CLIENT_NU
      And RefId.DOSSIER_NU        = Cont.CONTRDOS_DOSSIER_NU
      --On regarde dans la table des contrats avant
      And RefId.INT_DEPOSIT_DT    > Cast(Cont.CONTRDOS_DT_SIGN_CONTRAT as Date)
Where
  (1=1)
  And RefId.CONTRCT_DT_SIGN_PREC Is Null
  And Cont.CONTRDOS_NB_DUR_CONTRAT    In (${L_PIL_021})
  And Cont.CONTRDOS_CO_UNIT_CONTRAT   in (${L_PIL_020})
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Cont.CONTRDOS_DT_SIGN_CONTRAT desc, Cont.CONTRDOS_NB_DUR_CONTRAT Desc)=1

------------------------------------------------------------------------
--On calcul la date de fin de contrat Apres l'acte de vente :
------------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATNEW
(
  ACTE_ID                   ,
  INT_DEPOSIT_DT            ,
  CONTRCT_DT_SIGN_POST      ,
  CONTRCT_DUREE_ENG         ,
  CONTRCT_UNIT_ENG          
)
Select
  RefId.ACTE_ID                     as ACTE_ID                    ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT             ,
  Cont.CONTRDOS_DT_SIGN_CONTRAT     as CONTRCT_DT_SIGN_POST       ,
  Cont.CONTRDOS_NB_DUR_CONTRAT      as CONTRCT_DUREE_ENG          ,
  Cont.CONTRDOS_CO_UNIT_CONTRAT     as CONTRCT_UNIT_ENG           
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_2 RefId
  Inner Join ${KNB_IBU_SOC}.V_THCONTRDOS Cont
    On    RefId.CLIENT_NU       = Cont.CONTRDOS_CLIENT_NU
      And RefId.DOSSIER_NU      = Cont.CONTRDOS_DOSSIER_NU
      And RefId.INT_DEPOSIT_DT  <= Cast(Cont.CONTRDOS_DT_SIGN_CONTRAT as Date)
      And (RefId.INT_DEPOSIT_DT + interval '45' day) >= Cast(Cont.CONTRDOS_DT_SIGN_CONTRAT as Date)
Where
  (1=1)
  And RefId.CONTRCT_DT_SIGN_POST      Is Null
  And Cont.CONTRDOS_NB_DUR_CONTRAT    In (${L_PIL_021})
  And Cont.CONTRDOS_CO_UNIT_CONTRAT   in (${L_PIL_020})
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by Cont.CONTRDOS_DT_SIGN_CONTRAT Asc, Cont.CONTRDOS_NB_DUR_CONTRAT Desc)=1
;
.if errorcode <> 0 then .quit 1



Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATOLD;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.INT_W_PLACEMENT_CHO_CONTRATNEW;
.if errorcode <> 0 then .quit 1


.quit 0
