-- $HEADER: mm2pco/current/sql/ATP_PLC_RFO_Extr_PLACEMENT.sql 13_05#7 20-DEC-2017 10:17:00 GXPZ7694
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_HRF_Extr_PLACEMENT.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Perimetre RF - ACTE - EXTRACTION DES PLACEMENTS POUR TRANSFORMATION EN ACTE -
--
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 03/09/13        DARTIGUE    Creation
-- 18/02/16        MDE         Evol digital
-- 13/04/2016      MDE         Evol  : profondeur calcul 100 jrs 
-- 06/01/2017      HOB        Modif VA
-- 05/12/2017     HOB        Modif:Ajout Champs IOBSP
---------------------------------------------------------------------------------

-- PURGE DU TAMPON

DELETE FROM      ${KNB_PCO_TMP}.INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX} ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO      ${KNB_PCO_TMP}.INT_W_PLACEMENT_EXTRCT_${RFORCE_SUFFIX}
                  (
                    ACTE_ID                    
                  , EXTERNAL_ACTE_ID           
                  , TYPE_SOURCE_ID             
                  , INT_ID                     
                  , INT_DETL_ID                
                  , INT_TYPE                   
                  , INT_CREATED_BY_TS          
                  , INT_CREATED_BY_DT          
                  , INT_SRC                    
                  , INT_RESULT                 
                  , INT_REASON                 
                  , INT_DETL_SRC               
                  , DRK_PARTY_ID               
                  , FREG_PARTY_ID              
                  , EUREKA_PARTY_ID            
                  , PAR_PARC_CD                
                  , PAR_WKNESS_SCO             
                  , PAR_STORE_CD               
                  , REM_CHANNEL_CD
                  , ORG_REM_CHANNEL_CD             
                  , ORG_CHANNEL_CD             
                  , ORG_SUB_CHANNEL_CD
                  , ORG_SUB_SUB_CHANNEL_CD                        
                  , ACTIVITY_CD
                  , ORG_GT_ACTIVITY      
                  , ORG_FIDELISATION     
                  , ORG_WEB_ACTIVITY     
                  , ORG_AUTO_ACTIVITY    
                  , ORG_EDO_ID           
                  , ORG_EDO_DS           
                  , ORG_TYPE_EDO         
                  , ORG_EDO_IOBSP         
                  , ORG_FLAG_PLT_CONV    
                  , ORG_FLAG_TEAM_MKT    
                  , ORG_FLAG_TYPE_CMP    
                  , ORG_EDO_FATHR_ID_NIV1
                  , ORG_EDO_FATHR_DS_NIV1
                  , ORG_EDO_FATHR_ID_NIV2
                  , ORG_EDO_FATHR_DS_NIV2
                  , ORG_EDO_FATHR_ID_NIV3
                  , ORG_EDO_FATHR_DS_NIV3
                  , AUTO_ACTIVITY_IN           
                  , ORG_TEAM_TYPE_ID           
                  , AGENT_LOGIN_CD             
                  , ORG_AGENT_IOBSP
                  , AGENT_FIRST_NAME           
                  , AGENT_LAST_NAME            
                  , EXTERNAL_TEAM_CD           
                  , EXTERNAL_TEAM_NM           
                  , O3_ACTIVE_TEAM_CD          
                  , O3_RATTACHEMENT_TEAM_CD    
                  , INT_DETL_HABLT             
                  , INT_CANAL_VENTE
                  , ORG_CANAL_ID            
                  , ID_FACADE                  
                  , EXTERNAL_PRODUCT_ID_FINAL
                  , EXTERNAL_GAM_PRODUCT_ID    
                  , IND_GAM_TYPE
                  , NEW_OC_OCATID              
                  , OLD_OC_OCATID              
                  , LINE_ID                    
                  , MASTER_LINE_ID             
                  , LINE_TYPE                  
                  , LINE_START_DT              
                  , OPERATOR_PROVIDER_ID       
                  , SERVICE_ACCESS_ID
                  , BUSINESS_OFFER_BEGIN_DT          
                  , PARTY_KNB_ID               
                  , TERMINTN_VALUE_DS          
                  , EXTERNAL_SYSTEM_ID         
                  , EXTERNAL_PARTY_ID          
                  , FREG_PARTY_EXTERNL_ID
                  , BSS_PARTY_EXTERNL_ID          
                  , RES_VALUE_DS                        
                  , SIRET_CODE_CD              
                  , LAST_NAME_NM               
                  , FIRST_NAME_NM              
                  , NAME_NM                    
                  , INST_ADDRESS1_NM           
                  , INST_ADDRESS2_NM           
                  , INST_ADDRESS3_NM           
                  , INST_ADDRESS4_NM           
                  , INST_ADDRESS5_NM           
                  , INST_ADDRESS6_NM           
                  , MAIN_ADDRESS1_NM           
                  , MAIN_ADDRESS2_NM           
                  , MAIN_ADDRESS3_NM           
                  , MAIN_ADDRESS4_NM           
                  , MAIN_ADDRESS5_NM           
                  , MAIN_ADDRESS6_NM           
                  , BILL_ADDRESS1_NM           
                  , BILL_ADDRESS2_NM           
                  , BILL_ADDRESS3_NM           
                  , BILL_ADDRESS4_NM           
                  , BILL_ADDRESS5_NM           
                  , BILL_ADDRESS6_NM           
                  , INSEE_NB                   
                  , POSTAL_CD                  
                  , DEPARTMNT_ID               
                  , PAR_FIBER_IN
                  , PAR_GEO_MACROZONE
                  , PAR_UNIFIED_PARTY_ID 
                  , PAR_PARTY_REGRPMNT_ID           
                  , PAR_IRIS2000_CD 
                  , PAR_BU_CD
                  , CITY_LN                    
                  , SCORE_VALUE
                  , SCORE_THRESHOLD
                  , SCORE_IN
                  , TAC_ID
                  , IMEI_CD
                  , IMSI_CD
                  , IND_INT_RESULT_ERR
                  , IND_DMC_COH_DOMAIN
                  , IND_TECH_DMC_THRESHOLD_TYPE
                  , IND_TECH_DMC_THRESHOLD
                  , IND_DMC_THRESHOLD_TYPE
                  , IND_DMC_THRESHOLD
                  , IND_TECH_VMTIERS_THRES_T
                  , IND_TECH_VMTIERS_THRES
                  , IND_TECH_SOC_TERMNTN_DUP
                  , IND_TECH_SOC_TERMNTN_THRES_T
                  , IND_TECH_SOC_TERMNTN_THRES
                  , IND_TECH_SOC_ADRSS_DUP
                  , IND_TECH_SOC_ADRSS_THRES_T
                  , IND_TECH_SOC_ADRSS_THRES
                  , IND_TECH_KNB_AS_DUP
                  , RUN_ID
                  )
SELECT             V_INT_F_PLACEMENT_HRF.ACTE_ID                                                          AS ACTE_ID
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_ACTE_ID                                                 AS EXTERNAL_ACTE_ID
               ,   V_INT_F_PLACEMENT_HRF.TYPE_SOURCE_ID                                                   AS TYPE_SOURCE_ID
               ,   V_INT_F_PLACEMENT_HRF.INT_ID                                                           AS INT_ID
               ,   V_INT_F_PLACEMENT_HRF.INT_DETL_ID                                                      AS INT_DETL_ID
               ,   V_INT_F_PLACEMENT_HRF.INT_TYPE                                                         AS INT_TYPE
               ,   V_INT_F_PLACEMENT_HRF.INT_CREATED_BY_TS                                                AS INT_CREATED_BY_TS
               ,   V_INT_F_PLACEMENT_HRF.INT_CREATED_BY_DT                                                AS INT_CREATED_BY_DT
               ,   V_INT_F_PLACEMENT_HRF.INT_SRC                                                          AS INT_SRC
               ,   V_INT_F_PLACEMENT_HRF.INT_RESULT                                                       AS INT_RESULT
               ,   V_INT_F_PLACEMENT_HRF.INT_REASON                                                       AS INT_REASON
               ,   V_INT_F_PLACEMENT_HRF.INT_DETL_SRC                                                     AS INT_DETL_SRC
               ,   V_INT_F_PLACEMENT_HRF.DRK_PARTY_ID                                                     AS DRK_PARTY_ID
               ,   V_INT_F_PLACEMENT_HRF.FREG_PARTY_ID                                                    AS FREG_PARTY_ID
               ,   V_INT_F_PLACEMENT_HRF.EUREKA_PARTY_ID                                                  AS EUREKA_PARTY_ID
               ,   V_INT_F_PLACEMENT_HRF.PAR_PARC_CD                                                      AS PAR_PARC_CD
               ,   V_INT_F_PLACEMENT_HRF.PAR_WKNESS_SCO                                                   AS PAR_WKNESS_SCO
               ,   V_INT_F_PLACEMENT_HRF.PAR_STORE_CD                                                     AS PAR_STORE_CD
               ,   V_INT_F_PLACEMENT_HRF.REM_CHANNEL_CD                                                   AS REM_CHANNEL_CD
               ,   V_INT_F_PLACEMENT_HRF.ORG_REM_CHANNEL_CD                                               AS ORG_REM_CHANNEL_CD
               ,   V_INT_F_PLACEMENT_HRF.ORG_CHANNEL_CD                                                   AS ORG_CHANNEL_CD
               ,   V_INT_F_PLACEMENT_HRF.ORG_SUB_CHANNEL_CD                                               AS ORG_SUB_CHANNEL_CD
               ,   V_INT_F_PLACEMENT_HRF.ORG_SUB_SUB_CHANNEL_CD                                           AS ORG_SUB_SUB_CHANNEL_CD
               ,   V_INT_F_PLACEMENT_HRF.ACTIVITY_CD                                                      AS ACTIVITY_CD
               ,   V_INT_F_PLACEMENT_HRF.ORG_GT_ACTIVITY                                                  AS ORG_GT_ACTIVITY
               ,   V_INT_F_PLACEMENT_HRF.ORG_FIDELISATION                                                 AS ORG_FIDELISATION
               ,   V_INT_F_PLACEMENT_HRF.ORG_WEB_ACTIVITY                                                 AS ORG_WEB_ACTIVITY
               ,   V_INT_F_PLACEMENT_HRF.ORG_AUTO_ACTIVITY                                                AS ORG_AUTO_ACTIVITY
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_ID                                                       AS ORG_EDO_ID
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_DS                                                       AS ORG_EDO_DS
               ,   V_INT_F_PLACEMENT_HRF.ORG_TYPE_EDO                                                     AS ORG_TYPE_EDO
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_IOBSP                                                    AS ORG_EDO_IOBSP
               ,   V_INT_F_PLACEMENT_HRF.ORG_FLAG_PLT_CONV                                                AS ORG_FLAG_PLT_CONV
               ,   V_INT_F_PLACEMENT_HRF.ORG_FLAG_TEAM_MKT                                                AS ORG_FLAG_TEAM_MKT
               ,   V_INT_F_PLACEMENT_HRF.ORG_FLAG_TYPE_CMP                                                AS ORG_FLAG_TYPE_CMP
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_FATHR_ID_NIV1                                            AS ORG_EDO_FATHR_ID_NIV1
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_FATHR_DS_NIV1                                            AS ORG_EDO_FATHR_DS_NIV1
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_FATHR_ID_NIV2                                            AS ORG_EDO_FATHR_ID_NIV2
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_FATHR_DS_NIV2                                            AS ORG_EDO_FATHR_DS_NIV2
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_FATHR_ID_NIV3                                            AS ORG_EDO_FATHR_ID_NIV3
               ,   V_INT_F_PLACEMENT_HRF.ORG_EDO_FATHR_DS_NIV3                                            AS ORG_EDO_FATHR_DS_NIV3
               ,   V_INT_F_PLACEMENT_HRF.AUTO_ACTIVITY_IN                                                 AS AUTO_ACTIVITY_IN
               ,   V_INT_F_PLACEMENT_HRF.ORG_TEAM_TYPE_ID                                                 AS ORG_TEAM_TYPE_ID
               ,   V_INT_F_PLACEMENT_HRF.AGENT_LOGIN_CD                                                   AS AGENT_LOGIN_CD
               ,   V_INT_F_PLACEMENT_HRF.ORG_AGENT_IOBSP                                                  AS ORG_AGENT_IOBSP
               ,   V_INT_F_PLACEMENT_HRF.AGENT_FIRST_NAME                                                 AS AGENT_FIRST_NAME
               ,   V_INT_F_PLACEMENT_HRF.AGENT_LAST_NAME                                                  AS AGENT_LAST_NAME
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_TEAM_CD                                                 AS EXTERNAL_TEAM_CD
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_TEAM_NM                                                 AS EXTERNAL_TEAM_NM
               ,   V_INT_F_PLACEMENT_HRF.O3_ACTIVE_TEAM_CD                                                AS O3_ACTIVE_TEAM_CD
               ,   V_INT_F_PLACEMENT_HRF.O3_RATTACHEMENT_TEAM_CD                                          AS O3_RATTACHEMENT_TEAM_CD
               ,   V_INT_F_PLACEMENT_HRF.INT_DETL_HABLT                                                   AS INT_DETL_HABLT
               ,   V_INT_F_PLACEMENT_HRF.INT_CANAL_VENTE                                                  AS INT_CANAL_VENTE
               ,   V_INT_F_PLACEMENT_HRF.ORG_CANAL_ID                                                     AS ORG_CANAL_ID
               ,   V_INT_F_PLACEMENT_HRF.ID_FACADE                                                        AS ID_FACADE
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_PRODUCT_ID_FINAL                                        AS EXTERNAL_PRODUCT_ID_FINAL
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_GAM_PRODUCT_ID                                          AS EXTERNAL_GAM_PRODUCT_ID
               ,   V_INT_F_PLACEMENT_HRF.IND_GAM_TYPE                                                     AS IND_GAM_TYPE
               ,   V_INT_F_PLACEMENT_HRF.NEW_OC_OCATID                                                    AS NEW_OC_OCATID
               ,   V_INT_F_PLACEMENT_HRF.OLD_OC_OCATID                                                    AS OLD_OC_OCATID
               ,   V_INT_F_PLACEMENT_HRF.LINE_ID                                                          AS LINE_ID
               ,   V_INT_F_PLACEMENT_HRF.MASTER_LINE_ID                                                   AS MASTER_LINE_ID
               ,   V_INT_F_PLACEMENT_HRF.LINE_TYPE                                                        AS LINE_TYPE
               ,   V_INT_F_PLACEMENT_HRF.LINE_START_DT                                                    AS LINE_START_DT
               ,   V_INT_F_PLACEMENT_HRF.OPERATOR_PROVIDER_ID                                             AS OPERATOR_PROVIDER_ID
               ,   V_INT_F_PLACEMENT_HRF.SERVICE_ACCESS_ID                                                AS SERVICE_ACCESS_ID
               ,   V_INT_F_PLACEMENT_HRF.BUSINESS_OFFER_BEGIN_DT                                          AS BUSINESS_OFFER_BEGIN_DT
               ,   V_INT_F_PLACEMENT_HRF.PARTY_KNB_ID                                                     AS PARTY_KNB_ID
               ,   V_INT_F_PLACEMENT_HRF.TERMINTN_VALUE_DS                                                AS TERMINTN_VALUE_DS
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_SYSTEM_ID                                               AS EXTERNAL_SYSTEM_ID
               ,   V_INT_F_PLACEMENT_HRF.EXTERNAL_PARTY_ID                                                AS EXTERNAL_PARTY_ID
               ,   V_INT_F_PLACEMENT_HRF.FREG_PARTY_EXTERNL_ID                                            AS FREG_PARTY_EXTERNL_ID
               ,   V_INT_F_PLACEMENT_HRF.BSS_PARTY_EXTERNL_ID                                             AS BSS_PARTY_EXTERNL_ID
               ,   V_INT_F_PLACEMENT_HRF.RES_VALUE_DS                                                     AS RES_VALUE_DS
               ,   V_INT_F_PLACEMENT_HRF.SIRET_CODE_CD                                                    AS SIRET_CODE_CD
               ,   V_INT_F_PLACEMENT_HRF.LAST_NAME_NM                                                     AS LAST_NAME_NM
               ,   V_INT_F_PLACEMENT_HRF.FIRST_NAME_NM                                                    AS FIRST_NAME_NM
               ,   V_INT_F_PLACEMENT_HRF.NAME_NM                                                          AS NAME_NM
               ,   V_INT_F_PLACEMENT_HRF.INST_ADDRESS1_NM                                                 AS INST_ADDRESS1_NM
               ,   V_INT_F_PLACEMENT_HRF.INST_ADDRESS2_NM                                                 AS INST_ADDRESS2_NM
               ,   V_INT_F_PLACEMENT_HRF.INST_ADDRESS3_NM                                                 AS INST_ADDRESS3_NM
               ,   V_INT_F_PLACEMENT_HRF.INST_ADDRESS4_NM                                                 AS INST_ADDRESS4_NM
               ,   V_INT_F_PLACEMENT_HRF.INST_ADDRESS5_NM                                                 AS INST_ADDRESS5_NM
               ,   V_INT_F_PLACEMENT_HRF.INST_ADDRESS6_NM                                                 AS INST_ADDRESS6_NM
               ,   V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS1_NM                                                 AS MAIN_ADDRESS1_NM
               ,   V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS2_NM                                                 AS MAIN_ADDRESS2_NM
               ,   V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS3_NM                                                 AS MAIN_ADDRESS3_NM
               ,   V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS4_NM                                                 AS MAIN_ADDRESS4_NM
               ,   V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS5_NM                                                 AS MAIN_ADDRESS5_NM
               ,   V_INT_F_PLACEMENT_HRF.MAIN_ADDRESS6_NM                                                 AS MAIN_ADDRESS6_NM
               ,   V_INT_F_PLACEMENT_HRF.BILL_ADDRESS1_NM                                                 AS BILL_ADDRESS1_NM
               ,   V_INT_F_PLACEMENT_HRF.BILL_ADDRESS2_NM                                                 AS BILL_ADDRESS2_NM
               ,   V_INT_F_PLACEMENT_HRF.BILL_ADDRESS3_NM                                                 AS BILL_ADDRESS3_NM
               ,   V_INT_F_PLACEMENT_HRF.BILL_ADDRESS4_NM                                                 AS BILL_ADDRESS4_NM
               ,   V_INT_F_PLACEMENT_HRF.BILL_ADDRESS5_NM                                                 AS BILL_ADDRESS5_NM
               ,   V_INT_F_PLACEMENT_HRF.BILL_ADDRESS6_NM                                                 AS BILL_ADDRESS6_NM
               ,   V_INT_F_PLACEMENT_HRF.INSEE_NB                                                         AS INSEE_NB
               ,   V_INT_F_PLACEMENT_HRF.POSTAL_CD                                                        AS POSTAL_CD
               ,   V_INT_F_PLACEMENT_HRF.DEPARTMNT_ID                                                     AS DEPARTMNT_ID
               ,   V_INT_F_PLACEMENT_HRF.PAR_FIBER_IN                                                     AS PAR_FIBER_IN
               ,   V_INT_F_PLACEMENT_HRF.PAR_GEO_MACROZONE                                               AS PAR_GEO_MACROZONE
               ,   V_INT_F_PLACEMENT_HRF.PAR_UNIFIED_PARTY_ID                                            AS PAR_UNIFIED_PARTY_ID
               ,   V_INT_F_PLACEMENT_HRF.PAR_PARTY_REGRPMNT_ID                                            AS PAR_PARTY_REGRPMNT_ID
               ,   V_INT_F_PLACEMENT_HRF.PAR_IRIS2000_CD                                                  AS PAR_IRIS2000_CD 
               ,   V_INT_F_PLACEMENT_HRF.PAR_BU_CD                                                        AS PAR_BU_CD
               ,   V_INT_F_PLACEMENT_HRF.CITY_LN                                                          AS CITY_LN
               ,   V_INT_F_PLACEMENT_HRF.SCORE_VALUE                                                      AS SCORE_VALUE
               ,   V_INT_F_PLACEMENT_HRF.SCORE_THRESHOLD                                                  AS SCORE_THRESHOLD
               ,   V_INT_F_PLACEMENT_HRF.SCORE_IN                                                         AS SCORE_IN
               ,   V_INT_F_PLACEMENT_HRF.TAC_ID                                                           AS TAC_ID
               ,   V_INT_F_PLACEMENT_HRF.IMEI_CD                                                          AS IMEI_CD
               ,   V_INT_F_PLACEMENT_HRF.IMSI_CD                                                          AS IMSI_CD
               ,   V_INT_F_PLACEMENT_HRF.IND_INT_RESULT_ERR                                               IND_INT_RESULT_ERR
               ,   V_INT_F_PLACEMENT_HRF.IND_DMC_COH_DOMAIN                                               IND_DMC_COH_DOMAIN
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD_TYPE                                      IND_TECH_DMC_THRESHOLD_TYPE
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_DMC_THRESHOLD                                           IND_TECH_DMC_THRESHOLD
               ,   V_INT_F_PLACEMENT_HRF.IND_DMC_THRESHOLD_TYPE                                           IND_DMC_THRESHOLD_TYPE
               ,   V_INT_F_PLACEMENT_HRF.IND_DMC_THRESHOLD                                                IND_DMC_THRESHOLD
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_VMTIERS_THRES_T                                         IND_TECH_VMTIERS_THRES_T
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_VMTIERS_THRES                                           IND_TECH_VMTIERS_THRES
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_TERMNTN_DUP                                         IND_TECH_SOC_TERMNTN_DUP
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_TERMNTN_THRES_T                                     IND_TECH_SOC_TERMNTN_THRES_T
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_TERMNTN_THRES                                       IND_TECH_SOC_TERMNTN_THRES
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_ADRSS_DUP                                           IND_TECH_SOC_ADRSS_DUP
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_ADRSS_THRES_T                                       IND_TECH_SOC_ADRSS_THRES_T
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_SOC_ADRSS_THRES                                         IND_TECH_SOC_ADRSS_THRES
               ,   V_INT_F_PLACEMENT_HRF.IND_TECH_KNB_AS_DUP                                              IND_TECH_KNB_AS_DUP
               ,   V_INT_F_PLACEMENT_HRF.RUN_ID                                                           RUN_ID
FROM             ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_HRF                                                        V_INT_F_PLACEMENT_HRF
-- SELECTION DES INTERACTIONS POUR LA VACATION CONSIDEREE
WHERE              1                                                                               =         1
AND                V_INT_F_PLACEMENT_HRF.INT_CREATED_BY_DT         >= (Current_date - ${P_PIL_538})
AND               (
                    V_INT_F_PLACEMENT_HRF.INT_ID
                  , V_INT_F_PLACEMENT_HRF.INT_DETL_ID
                  )                                                                                IN
                  (
                    SELECT             INT_W_INTRCTN_EXTRCT_${RFORCE_SUFFIX}.FORCONTACTID
                                     , INT_W_INTRCTN_EXTRCT_${RFORCE_SUFFIX}.FORDETAILCONTACTID
                    FROM             ${KNB_PCO_TMP}.INT_W_INTRCTN_EXTRCT_${RFORCE_SUFFIX}          INT_W_INTRCTN_EXTRCT_${RFORCE_SUFFIX}
                  )                   
QUALIFY ROW_NUMBER() OVER (PARTITION BY ACTE_ID ORDER BY RUN_ID DESC) =  1
;

.IF ERRORCODE <> 0 THEN .QUIT 1;
