-- $HEADER: mm2pco/current/sql/ATP_PIF_Placement_Consolidation_Enrichissement_Step2_Calcul_Canal.sql 13_05#1 20-SEP-2016 10:59:33 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step2_Calcul_Canal.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Sql  
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 02/08/2016      HLA         Creation
-- 16/12/2016      HLA         Modification
-- 17/08/2021      BCH         PILCOM-833 : Modification jointure Placements PIF
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CHANNEL All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP  Pour les cannaux par défaut 4,6,13             ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CHANNEL
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  ORG_REM_CHANNEL_CD          ,
  ORG_CHANNEL_CD              ,
  ORG_SUB_CHANNEL_CD          ,
  ORG_SUB_SUB_CHANNEL_CD      ,
  ORG_GT_ACTIVITY             ,
  ORG_FIDELISATION            ,
  ORG_WEB_ACTIVITY            ,
  ORG_AUTO_ACTIVITY           
)
Select
  PIF.ACTE_ID                             As ACTE_ID                                  ,
  PIF.ORDER_DEPOSIT_DT                    As ORDER_DEPOSIT_DT                         ,
  Canal.ORG_REM_CHANNEL_CD                As ORG_REM_CHANNEL_CD                       ,
  Canal.ORG_CHANNEL_CD                    As ORG_CHANNEL_CD                           ,
  Canal.ORG_SUB_CHANNEL_CD                As ORG_SUB_CHANNEL_CD                       ,
  Canal.ORG_SUB_SUB_CHANNEL_CD            As ORG_SUB_SUB_CHANNEL_CD                   ,
  Canal.ORG_GT_ACTIVITY                   As ORG_GT_ACTIVITY                          ,
  Canal.ORG_FIDELISATION                  As ORG_FIDELISATION                         ,
  Canal.ORG_WEB_ACTIVITY                  As ORG_WEB_ACTIVITY                         ,
  Canal.ORG_AUTO_ACTIVITY                 As ORG_AUTO_ACTIVITY                        
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 PIF
  Inner Join ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_PIF Canal
    On    PIF.PIF_CANAL_DS    = Canal.PIF_CANAL_DS
      And Canal.CURRENT_IN    = 1
      And Canal.CLOSURE_DT    Is Null
Where
  (1=1)
Qualify Row_number() over (Partition by PIF.ACTE_ID Order By  Canal.ORG_REM_CHANNEL_CD Asc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CHANNEL;
.if errorcode <> 0 then .quit 1


------------------------------------------------------
------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CHANNEL
(
  ACTE_ID                     ,
  ORDER_DEPOSIT_DT            ,
  ORG_REM_CHANNEL_CD          ,
  ORG_CHANNEL_CD              ,
  ORG_SUB_CHANNEL_CD          ,
  ORG_SUB_SUB_CHANNEL_CD      ,
  ORG_GT_ACTIVITY             ,
  ORG_FIDELISATION            ,
  ORG_WEB_ACTIVITY            ,
  ORG_AUTO_ACTIVITY           
)
Select
  PIF.ACTE_ID                             As ACTE_ID                                  ,
  PIF.ORDER_DEPOSIT_DT                    As ORDER_DEPOSIT_DT                         ,
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'AD'
        When ORG_SUB_SUB_CHANNEL_CD_AGR = 'PAP Int'
          Then 'PAP'
        When ORG_SUB_SUB_CHANNEL_CD_AGR = 'PAP Ext'
          Then 'Exclus'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP'
          Then 'Exclus'
        When ORG_SUB_CHANNEL_CD_AGR = 'RC'
          Then 'Exclus'
        When Coalesce(PIF.FLAG_PLT_SCH_IN,1) = 1 And ORG_CHANNEL_CD_AGR in ('CCO','SCH')
          Then 'SCH'
        When ORG_CHANNEL_CD_AGR in ('CCO','SCH')
          Then 'CCO'
        Else 'Non PARAM'
  End                                     As ORG_REM_CHANNEL_CD                       ,
  --Calcul du canal de vente Macro
  Case  When PIF.DISTRBTN_CHANNL_ID in ('PAP','BTQ','RP','RC')
          Then 'Dist'
        When PIF.FLAG_AD_SC = 0
           Then  Case   When Coalesce(PIF.FLAG_PLT_CONV_NB,0)  = 1
                          Then 'CCO'
                        Else
                           Case   When Coalesce(PIF.FLAG_PLT_SCH_IN,1) = 1
                                    Then 'SCH'
                                  Else 'CCO'
                            End
                  End
        Else 'Non PARAM'
   End                                    As ORG_CHANNEL_CD_AGR                       ,
  --Sous Canal
  Case  When PIF.DISTRBTN_CHANNL_ID = 'PAP'
          Then 'PAP'
        When (PIF.DISTRBTN_CHANNL_ID = 'BTQ' And FLAG_TYPE_PTN_NTK Is Not Null Or PIF.DISTRBTN_CHANNL_ID = 'RP')
          Then 'RP'
        When PIF.DISTRBTN_CHANNL_ID = 'RC'
          Then 'RC'
        When PIF.DISTRBTN_CHANNL_ID = 'BTQ'
          Then 'AD'
        When PIF.FLAG_AD_SC = 0  And PIF.WORK_TEAM_LEVEL_1_CD Is Not Null
          Then  Case  When Coalesce(PIF.FLAG_PLT_CONV_NB,0)  = 1
                        Then 'Convergent'
                      Else
                        Case  When Coalesce(PIF.FLAG_PLT_SCH_IN,1) = 1
                                Then  'Home'
                              Else    'Mobile'
                        End
                End
        Else 'Non PARAM'
  End                                      As ORG_SUB_CHANNEL_CD_AGR                  ,
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'PAP' And PIF.TYPE_EDO_ID  = 'INT'
          Then 'PAP Int'
        When ORG_SUB_CHANNEL_CD_AGR = 'PAP'
          Then 'PAP Ext'
        When ORG_SUB_CHANNEL_CD_AGR in ('AD','RP') And FLAG_TYPE_GEO_CD Is Not Null
          Then 'DOM'
        When ORG_SUB_CHANNEL_CD_AGR in ('AD','RP')
          Then 'Metropole'
        When ORG_SUB_CHANNEL_CD_AGR = 'RC' And PIF.FLAG_TYPE_CPT_NTK In ('GSS','GSA')
          Then PIF.FLAG_TYPE_CPT_NTK
        When ORG_SUB_CHANNEL_CD_AGR = 'RC' And PIF.FLAG_TYPE_CPT_NTK In ('AUT')
          Then 'AUTRC'
        When ORG_SUB_CHANNEL_CD_AGR = 'RC' And PIF.FLAG_TYPE_CPT_NTK In ('GRO')
          Then 'GROSS'
        When PIF.FLAG_AD_SC = 0
          Then
            Case  When PIF.ACTIVITY Like '%CTC%'
                    Then 'CTC'
                  When PIF.ACTIVITY Like '%Front Prévenance%'
                    Then 'Front Prevenance'
                  Else 'Front'
            End
        Else 'Non PARAM'
  End                                     As ORG_SUB_SUB_CHANNEL_CD_AGR               ,
  Case  When ORG_SUB_CHANNEL_CD_AGR = 'AD'
          Then 'Boutique FT'
        When ORG_SUB_CHANNEL_CD_AGR = 'PAP'
          Then 'Porte a Porte'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP' And PIF.FLAG_TYPE_PTN_NTK = 'Mob'
          Then 'Mobistore'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP' And PIF.FLAG_TYPE_PTN_NTK = 'GDT'
          Then 'GDT'
        When ORG_SUB_CHANNEL_CD_AGR = 'RP' And PIF.FLAG_TYPE_PTN_NTK = 'FC'
          Then 'CARAIBES'
        When ORG_SUB_CHANNEL_CD_AGR = 'RC'
          Then 'Reseau Concurrent'
        When PIF.FLAG_AD_SC = 0
          Then PIF.ACTIVITY
        Else 'Non PARAM'
  End                                     As ORG_GT_ACTIVITY                          ,
  Null                                    As ORG_FIDELISATION                         ,
  Case  When ORG_CHANNEL_CD_AGR = 'AD'
          Then 'NON'
        When ORG_SUB_SUB_CHANNEL_CD_AGR = 'CTC'
          Then 'OUI'
        Else 'NON'
  End                                     As ORG_WEB_ACTIVITY                         ,
  Case  When ORG_CHANNEL_CD_AGR = 'AD'
          Then 'NON'
        Else 'NON'
  End                                     As ORG_AUTO_ACTIVITY                        
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 PIF
Where
  (1=1)
  And PIF.WORK_TEAM_LEVEL_1_CD  Is Not Null
  And PIF.PIF_CANAL_DS          Not In (select PIF_CANAL_DS from ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_PIF)
Qualify Row_number() over (Partition by PIF.ACTE_ID Order By  ORG_REM_CHANNEL_CD Asc) = 1
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_CHANNEL;
.if errorcode <> 0 then .quit 1





.quit 0
