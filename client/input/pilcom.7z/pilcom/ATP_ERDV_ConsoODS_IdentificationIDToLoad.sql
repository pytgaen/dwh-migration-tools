-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_ConsoODS_IdentificationIDToLoad.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Consommation ODS
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 20/12/2013      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;




-- Suppression de la table des identifiants à traiter :
Delete from ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD all;
.if errorcode <> 0 then .quit 1



-- Alimentation de la table des identifiants à traiter
Locking ${DatabaseODS}.ORD_O_ORDER_ERDV_COM for Access
Locking ${DatabaseODS}.ORD_O_ORDER_ERDV_LINE_COM for Access
Locking ${DatabaseODS}.ORD_O_ORDER_ERDV_OPERATION for Access

Insert Into ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD
(
  MSG_ID
)
Select
  CalculFinal.MSG_ID as MSG_ID
From
  (
    --On agrège l'ensemble sur la clé afin de supprimer les null des sous ensemble de requete
    Select
      FusionComm.MSG_ID                   as MSG_ID             ,
      Coalesce(Max(NB_LINE_ORDER_NU),0)   as NB_LINE_ORDER_NU   ,
      Coalesce(Max(COUNTLINEORDER),0)     as COUNTLINEORDER     ,
      Coalesce(Max(NB_LINE_OPER_NU),0)    as NB_LINE_OPER_NU    ,
      Coalesce(Max(COUNTLINEOPER),0)      as COUNTLINEOPER      
    From
      (
          --On requete pour calculer le nombre de ligne de commande par message
          Select
            Com.MSG_ID                              as MSG_ID             ,
            Com.NB_LINE_ORDER_NU                    as NB_LINE_ORDER_NU   ,
            Count(LigneCom.MSG_ID)                  as COUNTLINEORDER     ,
            null                                    as NB_LINE_OPER_NU    ,
            null                                    as COUNTLINEOPER
          From
            ${DatabaseODS}.ORD_O_ORDER_ERDV_COM Com
            Inner Join ${DatabaseODS}.ORD_O_ORDER_ERDV_LINE_COM LigneCom
            On Com.MSG_ID = LigneCom.MSG_ID
          Where
            (1=1)
            --On ne selectionne que les lignes qui n'ont pas été complète
          And Com.ORDER_COMPLETED_IN  = 0
          Group by Com.MSG_ID, Com.NB_LINE_ORDER_NU
          Union All
          --On requete pour calculer le nombre d'opérations programmées par message
          Select
            Com.MSG_ID                              as MSG_ID             ,
            null                                    as NB_LINE_ORDER_NU   ,
            null                                    as COUNTLINEORDER     ,
            Com.NB_LINE_OPER_NU                     as NB_LINE_OPER_NU    ,
            Count(LigneOper.MSG_ID)                 as COUNTLINEOPER
          From
            ${DatabaseODS}.ORD_O_ORDER_ERDV_COM Com
            Inner Join ${DatabaseODS}.ORD_O_ORDER_ERDV_OPERATION LigneOper
            On Com.MSG_ID = LigneOper.MSG_ID
          Where
            (1=1)
            --On ne selectionne que les lignes qui n'ont pas été complète
          And Com.ORDER_COMPLETED_IN  = 0
          Group by Com.MSG_ID, NB_LINE_OPER_NU
      )FusionComm
    Group By
      FusionComm.MSG_ID
  )CalculFinal
Where
  (1=1)
  And CalculFinal.NB_LINE_ORDER_NU = CalculFinal.COUNTLINEORDER
  And CalculFinal.NB_LINE_OPER_NU  = CalculFinal.COUNTLINEOPER
;
.if errorcode <> 0 then .quit 1

--On collecte les stats sur la table 
Collect Stat ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD;
.if errorcode <> 0 then .quit 1

--On procèdes aux alimentations des tables Temporaires pour ces commandes :

--On fait la purge des tables TMP
Delete from ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_COM all;
.if errorcode <> 0 then .quit 1

Delete from ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_LINE_COM all;
.if errorcode <> 0 then .quit 1

Delete from ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_OPERATION all;
.if errorcode <> 0 then .quit 1



--Insertion dans la table des commandes :
Locking ${DatabaseODS}.ORD_O_ORDER_ERDV_COM for Access
Locking ${DatabaseODS}.ORD_O_ORDER_ERDV_LINE_COM for Access
Locking ${DatabaseODS}.ORD_O_ORDER_ERDV_OPERATION for Access

Insert Into ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_COM
(
  MSG_ID,
  EXTERNAL_ORDER_ID,
  ORDER_DEPOSIT_TS,
  ORDER_VALIDATION_TS,
  AGENT_ID,
  ACTIVITY_UNIT_CD,
  CUSTOMER_LAST_NAME_NM,
  CUSTOMER_MARKET_SEG_CD,
  CONTACT_CIVILITY_NM,
  CONTACT_LAST_NAME_NM,
  CONTACT_FIRST_NAME_NM,
  CONTACT_MOBILE_NUMBER_NU,
  CONTACT_TEL_NUMBER_NU,
  OBSERVATIONS_CONTACT_DS,
  REF_GROUPED_OFFER_CD,
  INTERVENTION_ID,
  GPC_ID,
  STATUS_INTERVENTION_CD,
  DATE_RESERVATION_TS,
  DATE_BEGIN_TS,
  OBSERVATIONS_INTERVENTION_DS,
  REF_ERDV_CD,
  NB_LINE_ORDER_NU,
  NB_LINE_OPER_NU,
  ORDER_COMPLETED_IN,
  QUEUE_TS,
  STREAMING_TS 
) 
Select
  Com.MSG_ID                                 as MSG_ID,
  Com.EXTERNAL_ORDER_ID                      as EXTERNAL_ORDER_ID,
  Com.ORDER_DEPOSIT_TS                       as ORDER_DEPOSIT_TS,
  Com.ORDER_VALIDATION_TS                    as ORDER_VALIDATION_TS,
  Com.AGENT_ID                               as AGENT_ID,
  Com.ACTIVITY_UNIT_CD                       as ACTIVITY_UNIT_CD,
  Com.CUSTOMER_LAST_NAME_NM                  as CUSTOMER_LAST_NAME_NM,
  Com.CUSTOMER_MARKET_SEG_CD                 as CUSTOMER_MARKET_SEG_CD,
  Com.CONTACT_CIVILITY_NM                    as CONTACT_CIVILITY_NM,
  Com.CONTACT_LAST_NAME_NM                   as CONTACT_LAST_NAME_NM,
  Com.CONTACT_FIRST_NAME_NM                  as CONTACT_FIRST_NAME_NM,
  Com.CONTACT_MOBILE_NUMBER_NU               as CONTACT_MOBILE_NUMBER_NU,
  Com.CONTACT_TEL_NUMBER_NU                  as CONTACT_TEL_NUMBER_NU,
  Com.OBSERVATIONS_CONTACT_DS                as OBSERVATIONS_CONTACT_DS,
  Com.REF_GROUPED_OFFER_CD                   as REF_GROUPED_OFFER_CD,
  Com.INTERVENTION_ID                        as INTERVENTION_ID,
  Com.GPC_ID                                 as GPC_ID,
  Com.STATUS_INTERVENTION_CD                 as STATUS_INTERVENTION_CD,
  Com.DATE_RESERVATION_TS                    as DATE_RESERVATION_TS,
  Com.DATE_BEGIN_TS                          as DATE_BEGIN_TS,
  Com.OBSERVATIONS_INTERVENTION_DS           as OBSERVATIONS_INTERVENTION_DS,
  Com.REF_ERDV_CD                            as REF_ERDV_CD,
  Com.NB_LINE_ORDER_NU                       as NB_LINE_ORDER_NU,
  Com.NB_LINE_OPER_NU                        as NB_LINE_OPER_NU,
  1                                          as ORDER_COMPLETED_IN,
  QUEUE_TS                                   as QUEUE_TS,
  STREAMING_TS                               as STREAMING_TS
From
  ${DatabaseODS}.ORD_O_ORDER_ERDV_COM Com
  Inner Join ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD RefId
  On  Com.MSG_ID = RefId.MSG_ID
;
.if errorcode <> 0 then .quit 1



--Insertion dans la table des lignes de commandes :
Insert Into ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_LINE_COM
(
  MSG_ID,
  EXTERNAL_ORDER_ID,
  ORDER_LINE_EXTERNAL_ID,
  ORDER_LINE_STATUS_CD,
  ORDER_LINE_CONTRACT_DATE_TS,
  ORDER_LINE_WANTED_DATE_TS,
  ORDER_LINE_PREST_CD,
  ORDER_LINE_QUANTITY_QT,
  ORDER_LINE_AMOUNT_AM,
  ORDER_LINE_TVA_RT,
  ORDER_LINE_OPER_CD,
  CUSTOMER_MARKET_SEG_CD,
  CUSTOMER_LAST_NAME_NM,
  CUSTOMER_ADDRESS_APPT_NM,
  CUSTOMER_ADDRESS_ESC_NM,
  CUSTOMER_ADDRESS_STAGE_NM,
  CUSTOMER_ADDRESS_BAT_NM,
  CUSTOMER_ADDRESS_RESIDENCE_NM,
  CUSTOMER_ADDRESS_ZIPCODE_CD,
  CUSTOMER_ADDRESS_NUMBER_NU,
  CUSTOMER_ADDRESS_STR_TYPE_CD,
  CUSTOMER_ADDRESS_STREET_NM,
  CUSTOMER_ADDRESS_CITY_NM,
  CUSTOMER_ADDRESS_INSEE_CD,
  REF_OFFRE_CIBLE_CD,
  CATALOGUE_CD,
  CUSTOMER_ND_NU,
  CUSTOMER_NDS_NU,
  QUEUE_TS,
  STREAMING_TS
)
Select
  LigneCom.MSG_ID                           as MSG_ID                            ,
  LigneCom.EXTERNAL_ORDER_ID                as EXTERNAL_ORDER_ID                 ,
  LigneCom.ORDER_LINE_EXTERNAL_ID           as ORDER_LINE_EXTERNAL_ID            ,
  LigneCom.ORDER_LINE_STATUS_CD             as ORDER_LINE_STATUS_CD              ,
  LigneCom.ORDER_LINE_CONTRACT_DATE_TS      as ORDER_LINE_CONTRACT_DATE_TS       ,
  LigneCom.ORDER_LINE_WANTED_DATE_TS        as ORDER_LINE_WANTED_DATE_TS         ,
  LigneCom.ORDER_LINE_PREST_CD              as ORDER_LINE_PREST_CD               ,
  LigneCom.ORDER_LINE_QUANTITY_QT           as ORDER_LINE_QUANTITY_QT            ,
  LigneCom.ORDER_LINE_AMOUNT_AM             as ORDER_LINE_AMOUNT_AM              ,
  LigneCom.ORDER_LINE_TVA_RT                as ORDER_LINE_TVA_RT                 ,
  LigneCom.ORDER_LINE_OPER_CD               as ORDER_LINE_OPER_CD                ,
  LigneCom.CUSTOMER_MARKET_SEG_CD           as CUSTOMER_MARKET_SEG_CD            ,
  LigneCom.CUSTOMER_LAST_NAME_NM            as CUSTOMER_LAST_NAME_NM             ,
  LigneCom.CUSTOMER_ADDRESS_APPT_NM         as CUSTOMER_ADDRESS_APPT_NM          ,
  LigneCom.CUSTOMER_ADDRESS_ESC_NM          as CUSTOMER_ADDRESS_ESC_NM           ,
  LigneCom.CUSTOMER_ADDRESS_STAGE_NM        as CUSTOMER_ADDRESS_STAGE_NM         ,
  LigneCom.CUSTOMER_ADDRESS_BAT_NM          as CUSTOMER_ADDRESS_BAT_NM           ,
  LigneCom.CUSTOMER_ADDRESS_RESIDENCE_NM    as CUSTOMER_ADDRESS_RESIDENCE_NM     ,
  LigneCom.CUSTOMER_ADDRESS_ZIPCODE_CD      as CUSTOMER_ADDRESS_ZIPCODE_CD       ,
  LigneCom.CUSTOMER_ADDRESS_NUMBER_NU       as CUSTOMER_ADDRESS_NUMBER_NU        ,
  LigneCom.CUSTOMER_ADDRESS_STR_TYPE_CD  as CUSTOMER_ADDRESS_STR_TYPE_CD   ,
  LigneCom.CUSTOMER_ADDRESS_STREET_NM       as CUSTOMER_ADDRESS_STREET_NM        ,
  LigneCom.CUSTOMER_ADDRESS_CITY_NM         as CUSTOMER_ADDRESS_CITY_NM          ,
  LigneCom.CUSTOMER_ADDRESS_INSEE_CD        as CUSTOMER_ADDRESS_INSEE_CD         ,
  LigneCom.REF_OFFRE_CIBLE_CD               as REF_OFFRE_CIBLE_CD                ,
  LigneCom.CATALOGUE_CD                     as CATALOGUE_CD                      ,
  LigneCom.CUSTOMER_ND_NU                   as CUSTOMER_ND_NU                    ,
  LigneCom.CUSTOMER_NDS_NU                  as CUSTOMER_NDS_NU                   ,
  LigneCom.QUEUE_TS                         as QUEUE_TS                       	 ,
  LigneCom.STREAMING_TS                     as STREAMING_TS
From
  ${DatabaseODS}.ORD_O_ORDER_ERDV_LINE_COM LigneCom
  Inner Join ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD RefId
  On  LigneCom.MSG_ID = RefId.MSG_ID
;
.if errorcode <> 0 then .quit 1



--Insertion dans la table des opérations programmées :
Insert Into ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_OPERATION
(
  MSG_ID,
  EXTERNAL_ORDER_ID,
  ORDER_LINE_EXTERNAL_ID,
  TYPE_OP_NM,
  QUEUE_TS,
  STREAMING_TS
)
Select
  Oper.MSG_ID                               as MSG_ID                         ,
  Oper.EXTERNAL_ORDER_ID                    as EXTERNAL_ORDER_ID              ,
  Oper.ORDER_LINE_EXTERNAL_ID               as ORDER_LINE_EXTERNAL_ID         ,
  Oper.TYPE_OP_NM                           as TYPE_OP_NM                     ,
  Oper.QUEUE_TS                             as QUEUE_TS                       ,
  Oper.STREAMING_TS                         as STREAMING_TS
From
  ${DatabaseODS}.ORD_O_ORDER_ERDV_OPERATION Oper
  Inner Join ${KNB_COM_TMP}.ORD_W_IDORDER_ERDV_TO_LOAD RefId
  On  Oper.MSG_ID = RefId.MSG_ID
;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_COM;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_LINE_COM;
.if errorcode <> 0 then .quit 1

Collect Stat on ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_OPERATION;
.if errorcode <> 0 then .quit 1
