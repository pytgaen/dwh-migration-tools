-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ODS_PCO_Streaming_LanceRattrapage_AGC.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 30/10/2014      GAM         Chargement de table pour les reprises
-- 18/11/2014      VMO         MAJ
--------------------------------------------------------------------------------

.set width 2500;

Create Multiset Volatile Table ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD(
  CONTEXT_ID Integer  NOT NULL,
  QUEUE_TS TIMESTAMP(2) FORMAT 'DD/MM/YYYYBHH:MI:SS.s(2)' NOT NULL 
)
PRIMARY INDEX ( CONTEXT_ID )
On Commit Preserve Rows;
.if errorcode <> 0 then .quit 1



Collect Stat On ${DatabaseODS}.REP_O_ORDER_AGC_COM Column(CONTEXT_ID,QUEUE_TS);
.if errorcode <> 0 then .quit 1
Collect Stat On ${DatabaseODS}.REP_O_ORDER_AGC_LINE_COM Column(CONTEXT_ID,QUEUE_TS);
.if errorcode <> 0 then .quit 1


Locking ${DatabaseODS}.REP_O_ORDER_AGC_COM for access
Locking ${DatabaseODS}.REP_O_ORDER_AGC_LINE_COM for access
Insert into ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD
(
  CONTEXT_ID,
  QUEUE_TS
)
Select
  CalculFinal.CONTEXT_ID as CONTEXT_ID,
  CalculFinal.QUEUE_TS as QUEUE_TS
From
  (
    --On agrège l'ensemble sur la clé afin de supprimer les null des sous ensemble de requete
    Select
      FusionComm.CONTEXT_ID               as CONTEXT_ID                   ,
      FusionComm.QUEUE_TS                 as QUEUE_TS                     ,
      Coalesce(Max(NB_LINE_ORDER),0)      as NB_LINE_ORDER                ,
      Coalesce(Max(COUNTLINEORDER),0)     as COUNTLINEORDER
    From
      (
          --On requete pour calculer le nombre de ligne de commande par contexte  et queue_ts
          Select
            Com.CONTEXT_ID                          as CONTEXT_ID         ,
            Com.QUEUE_TS                            as QUEUE_TS           ,
            Com.NB_LINE_ORDER                       as NB_LINE_ORDER      ,
            Count(LigneCom.CONTEXT_ID)              as COUNTLINEORDER
          From
            ${DatabaseODS}.REP_O_ORDER_AGC_COM Com
            Inner Join ${DatabaseODS}.REP_O_ORDER_AGC_LINE_COM LigneCom
            On  Com.CONTEXT_ID = LigneCom.CONTEXT_ID
            And Com.QUEUE_TS   = LigneCom.QUEUE_TS
          Where
            (1=1)
          Group by Com.CONTEXT_ID, Com.QUEUE_TS, Com.NB_LINE_ORDER
      )FusionComm
    Group By
      FusionComm.CONTEXT_ID,
      FusionComm.QUEUE_TS
  )CalculFinal
Where
  (1=1)
  And CalculFinal.NB_LINE_ORDER = CalculFinal.COUNTLINEORDER
  And Not exists (
    Select 1 From ${DatabaseODS}.ORD_O_ORDER_AGC_COM ods
    Where CalculFinal.CONTEXT_ID=ods.CONTEXT_ID
  )
;
.if errorcode <> 0 then .quit 1


--On collecte les stats sur la table Volatile
Collect Stat ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD Column(CONTEXT_ID);
.if errorcode <> 0 then .quit 1

--On procèdes aux alimentations des tables Temporaires pour ces commandes :


--Insertion dans la table des commandes :
Insert Into ${DatabaseODS}.ORD_O_ORDER_AGC_COM
(
 CONTEXT_ID,
 MAIN_MSISDN_ID,
 SECOND_MSISDN_ID,
 HOLDER_CIVILITY,
 HOLDER_LAST_NAME,
 HOLDER_FIRST_NAME,
 HOLDER_SIRET,
 HOLDER_ADDRESS_NM_1,
 HOLDER_ADDRESS_NM_2,
 HOLDER_ADDRESS_NM_3,
 HOLDER_ADDRRESS_NM_4,
 HOLDER_ADDRESS_POSTAL_CD,
 HOLDER_CITY,
 HOLDER_BANK_CD,
 HOLDER_OFFICE_CD,
 HOLRDER_ACCOUNT_CD,
 HOLDER_RIB_KEY_CD,
 HOLDER_MAIL,
 CUSTOMER_CLIENT_NU_ADV,
 CUSTOMER_MARKET_SEG,
 CUSTOMER_CIVILITY,
 CUSTOMER_LAST_NAME_NM,
 CUSTOMER_FIRST_NAME_NM,
 CUSTOMER_NAME_NM,
 CUSTOMER_SIRET,
 CUSTOMER_ADDRESS_1_NM,
 CUSTOMER_ADDRESS_2_NM,
 CUSTOMER_ADDRESS_3_NM,
 CUSTOMER_ADDRESS_4_NM,
 CUSTOMER_ADDRESS_POSTAL_CD,
 CUSTOMER_CITY,
 CUSTOMER_CATEGORIE,
 STORE_CD,
 ADV_STORE_CD,
 AGENT_ID,
 AGENT_LAST_NAME_NM,
 AGENT_FIRST_NAME_NM,
 NB_LINE_ORDER,
 ORDER_COMPLETED,
 QUEUE_TS,
 STREAMING_TS
)
Select
 Com.CONTEXT_ID,
 Com.MAIN_MSISDN_ID,
 Com.SECOND_MSISDN_ID,
 Com.HOLDER_CIVILITY,
 Com.HOLDER_LAST_NAME,
 Com.HOLDER_FIRST_NAME,
 Com.HOLDER_SIRET,
 Com.HOLDER_ADDRESS_NM_1,
 Com.HOLDER_ADDRESS_NM_2,
 Com.HOLDER_ADDRESS_NM_3,
 Com.HOLDER_ADDRRESS_NM_4,
 Com.HOLDER_ADDRESS_POSTAL_CD,
 Com.HOLDER_CITY,
 Com.HOLDER_BANK_CD,
 Com.HOLDER_OFFICE_CD,
 Com.HOLRDER_ACCOUNT_CD,
 Com.HOLDER_RIB_KEY_CD,
 Com.HOLDER_MAIL,
 Com.CUSTOMER_CLIENT_NU_ADV,
 Com.CUSTOMER_MARKET_SEG,
 Com.CUSTOMER_CIVILITY,
 Com.CUSTOMER_LAST_NAME_NM,
 Com.CUSTOMER_FIRST_NAME_NM,
 Com.CUSTOMER_NAME_NM,
 Com.CUSTOMER_SIRET,
 Com.CUSTOMER_ADDRESS_1_NM,
 Com.CUSTOMER_ADDRESS_2_NM,
 Com.CUSTOMER_ADDRESS_3_NM,
 Com.CUSTOMER_ADDRESS_4_NM,
 Com.CUSTOMER_ADDRESS_POSTAL_CD,
 Com.CUSTOMER_CITY,
 Com.CUSTOMER_CATEGORIE,
 Com.STORE_CD,
 Com.ADV_STORE_CD,
 Com.AGENT_ID,
 Com.AGENT_LAST_NAME_NM,
 Com.AGENT_FIRST_NAME_NM,
 Com.NB_LINE_ORDER,
 0 As ORDER_COMPLETED,
 Com.QUEUE_TS,
 Com.STREAMING_TS
From
  ${DatabaseODS}.REP_O_ORDER_AGC_COM Com
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD RefId
    On    Com.CONTEXT_ID = RefId.CONTEXT_ID

--Insertion dans la table des lignes de commandes Internet :
;Insert Into ${DatabaseODS}.ORD_O_ORDER_AGC_LINE_COM
Select
  LigneInternet.*
From
  ${DatabaseODS}.REP_O_ORDER_AGC_LINE_COM LigneInternet
  Inner Join ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD RefId
    On   LigneInternet.CONTEXT_ID = RefId.CONTEXT_ID
;
.if errorcode <> 0 then .quit 1


--delete 

Delete
From
  ${DatabaseODS}.REP_O_ORDER_AGC_COM
Where
  (1=1)
  And
    (CONTEXT_ID,QUEUE_TS)
    In 
    (
      Select
        CONTEXT_ID,QUEUE_TS
      From
        ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD
    )
;
.if errorcode <> 0 then .quit 1

Delete
From
  ${DatabaseODS}.REP_O_ORDER_AGC_LINE_COM
Where
  (1=1)
  And
    (CONTEXT_ID,QUEUE_TS)
    In 
    (
      Select
        CONTEXT_ID,QUEUE_TS
      From
        ${KNB_TERADATA_USER}.ATP_V_IDORDER_IODA_TO_LOAD
    )
;
.if errorcode <> 0 then .quit 1


Collect Stat On ${DatabaseODS}.REP_O_ORDER_AGC_COM Column(CONTEXT_ID,QUEUE_TS);
.if errorcode <> 0 then .quit 1
Collect Stat On ${DatabaseODS}.REP_O_ORDER_AGC_LINE_COM Column(CONTEXT_ID,QUEUE_TS);
.if errorcode <> 0 then .quit 1
