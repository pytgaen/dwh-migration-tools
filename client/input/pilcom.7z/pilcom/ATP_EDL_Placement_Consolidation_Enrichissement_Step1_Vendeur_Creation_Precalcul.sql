-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EDL_Placement_Consolidation_Enrichissement_Step1_Vendeur_Creation_Precalcul.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'Enrichissement Vendeur Création
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      AID         Industrialisation
--------------------------------------------------------------------------------

.set width 2500;


--Delete des lignes
Delete From ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDEUR_1 All;
.if errorcode <> 0 then .quit 1





---------------------------------------------------------------------------------
--Problématique : EDL Nous envoie un XI Conseil
--On veut un XI Poc :
-- Etape Préliminaire : On passe le XI Conseil En CUI
---------------------------------------------------------------------------------

--Vendeur de la vente
Insert into  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDEUR_1
(
  ACTE_ID               ,
  INT_DEPOSIT_DT        ,
  INT_DEPOSIT_TS        ,
  CUID                  ,
  CONSEIL_XI            ,
  ORG_ACTVT_REEL        ,
  ORG_POC_XI            ,
  ORG_REF_TRAV          
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.INT_DEPOSIT_DT              as INT_DEPOSIT_DT       ,
  RefId.INT_DEPOSIT_TS              as INT_DEPOSIT_TS       ,
  Conseil.CONSEIL_LB_UTIL           as CUID                 ,
  Conseil.CONSEIL_XI                as CONSEIL_XI           ,
  RefId.ORG_ACTVT_REEL              as ORG_ACTVT_REEL       ,
  RefId.ORG_POC_XI                  as ORG_POC_XI           ,
  RefId.ORG_REF_TRAV                as ORG_REF_TRAV         
From
  ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_1 RefId
  Inner Join ${KNB_IBU_SOC}.V_TDCONSEIL Conseil
    On  RefId.CONSEIL_XI_CREA = Conseil.CONSEIL_XI
Where
  (1=1)
  And (     RefId.ORG_POC_XI Is Null
        Or
            RefId.ORG_REF_TRAV='OEEEDEL'
        Or
            RefId.ORG_ACTVT_REEL Is Null
      )
  And Conseil.CONSEIL_LB_UTIL Is not Null
;
.if errorcode <> 0 then .quit 1

--On collecte les stats sur la table volatile
Collect stat on ${KNB_PCO_TMP}.INT_W_PLACEMENT_EDL_VENDEUR_1;
.if errorcode <> 0 then .quit 1


.quit 0
