--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_SOFTM_CrossActes_CHO_ORD_T_ACTE_UNIFIED.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de croisement de la source SOFTM avec la source CHO
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 18/05/2014     HFO         Création
-- 15/07/2014     GMA         QC : 527 / 599 Modif des croisements
-- 09/11/2015     HZO         Modification : Modification du Rule_ID = 18
-- 14/12/2017     JCR         Modification : ajout IOBSP
-- 19/09/2018     JCR         Correction robots
-- 09/04/2019     SII.........Modification les rapprochements historiques
-- 23/05/2019     JCR         les actes Omnicanaaux doivent conserver les informations omnicanal : 
--                             on met à jour juste le lien entre maitre et esclave.
-- 28/06/2021     EVI         PILCOM-945 : Suppression Champs Obsolète VU 
---------------------------------------------------------------------------------


.set width 5000

--------------------------------
-- Table : ORD_T_ACTE_UNIFIED --
--------------------------------

Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-- Identification Croisement Regle Par IMSI_CD

Insert Into ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
(
  MASTER_ACTE_ID                  ,
  SLAVE_ACTE_ID                   ,
  MASTER_SOURCE_ID                ,
  SLAVE_SOURCE_ID                 ,
  RULE_ID                         ,
  MASTER_NB_FOUND                 ,
  ORG_REM_CHANNEL_CD              ,
  ORG_CHANNEL_CD                  ,
  ORG_SUB_CHANNEL_CD              ,
  ORG_SUB_SUB_CHANNEL_CD          ,
  ORG_GT_ACTIVITY                 ,
  ORG_FIDELISATION                ,
  ORG_WEB_ACTIVITY                ,
  ORG_AUTO_ACTIVITY               ,
  ORG_EDO_ID                      ,
  ORG_TYPE_EDO                    ,
  ORG_EDO_IOBSP                   ,
  ORG_FLAG_PLT_CONV               ,
  ORG_FLAG_TEAM_MKT               ,
  ORG_FLAG_TYPE_CMP               ,
  ORG_RESP_EDO_ID                 ,
  ORG_RESP_TYPE_EDO               ,
  ORG_RESP_FLAG_PLT_CONV          ,
  WORK_TEAM_LEVEL_1_CD            ,
  WORK_TEAM_LEVEL_1_DS            ,
  WORK_TEAM_LEVEL_2_CD            ,
  WORK_TEAM_LEVEL_2_DS            ,
  WORK_TEAM_LEVEL_3_CD            ,
  WORK_TEAM_LEVEL_3_DS            ,
  WORK_TEAM_LEVEL_4_CD            ,
  WORK_TEAM_LEVEL_4_DS            ,
  OFFSET                          
)
Select 
  RES.MASTER_ACTE_ID                ,
  RES.SLAVE_ACTE_ID                 ,
  RES.MASTER_SOURCE_ID              ,
  RES.SLAVE_SOURCE_ID               ,
  RES.RULE_ID                       ,
  RES.MASTER_NB_FOUND               ,
  RES.ORG_REM_CHANNEL_CD            ,
  RES.ORG_CHANNEL_CD                ,
  RES.ORG_SUB_CHANNEL_CD            ,
  RES.ORG_SUB_SUB_CHANNEL_CD        ,
  RES.ORG_GT_ACTIVITY               ,
  RES.ORG_FIDELISATION              ,
  RES.ORG_WEB_ACTIVITY              ,
  RES.ORG_AUTO_ACTIVITY             ,
  RES.ORG_EDO_ID                    ,
  RES.ORG_TYPE_EDO                  ,
  RES.ORG_EDO_IOBSP                 ,
  RES.ORG_FLAG_PLT_CONV             ,
  RES.ORG_FLAG_TEAM_MKT             ,
  RES.ORG_FLAG_TYPE_CMP             ,
  RES.ORG_RESP_EDO_ID               ,
  RES.ORG_RESP_TYPE_EDO             ,
  RES.ORG_RESP_FLAG_PLT_CONV        ,
  RES.WORK_TEAM_LEVEL_1_CD          ,
  RES.WORK_TEAM_LEVEL_1_DS          ,
  RES.WORK_TEAM_LEVEL_2_CD          ,
  RES.WORK_TEAM_LEVEL_2_DS          ,
  RES.WORK_TEAM_LEVEL_3_CD          ,
  RES.WORK_TEAM_LEVEL_3_DS          ,
  RES.WORK_TEAM_LEVEL_4_CD          ,
  RES.WORK_TEAM_LEVEL_4_DS          ,
  RES.OFFSET                        
From 
(
  Select
    MASTER.ACTE_ID                                                                            As MASTER_ACTE_ID,
    SLAVE.ACTE_ID                                                                             As SLAVE_ACTE_ID,
    MASTER.INTRNL_SOURCE_ID                                                                   As MASTER_SOURCE_ID,
    SLAVE.INTRNL_SOURCE_ID                                                                    As SLAVE_SOURCE_ID,
    ${P_PIL_485}                                                                              As RULE_ID,
    Count(*) Over (Partition By SLAVE.ACTE_ID)                                                As MASTER_NB_FOUND,  
    Case  When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_REM_CHANNEL_CD
            Else Coalesce(SLAVE.ORG_REM_CHANNEL_CD, MASTER.ORG_REM_CHANNEL_CD)
      End                                                                                       As ORG_REM_CHANNEL_CD,
      Case  When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_CHANNEL_CD
            When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_CHANNEL_CD
            Else MASTER.ORG_CHANNEL_CD
      End                                                                                       As ORG_CHANNEL_CD,
      Case  When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_SUB_CHANNEL_CD
            When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_SUB_CHANNEL_CD
            Else MASTER.ORG_SUB_CHANNEL_CD
      End                                                                                       As ORG_SUB_CHANNEL_CD,
      Case When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_SUB_SUB_CHANNEL_CD
           When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_SUB_SUB_CHANNEL_CD
           Else MASTER.ORG_SUB_SUB_CHANNEL_CD 
      End                                                                                       As ORG_SUB_SUB_CHANNEL_CD,
      Case When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_GT_ACTIVITY
           When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_GT_ACTIVITY
           Else MASTER.ORG_GT_ACTIVITY
      End                                                                                       As ORG_GT_ACTIVITY,
      Case When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_FIDELISATION
          When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_FIDELISATION
           Else MASTER.ORG_FIDELISATION
      End                                                                                       As ORG_FIDELISATION,
      Case When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_WEB_ACTIVITY
           When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_WEB_ACTIVITY
           Else MASTER.ORG_WEB_ACTIVITY
      End                                                                                       As ORG_WEB_ACTIVITY,
      Case When MASTER.ORG_SPE_CANAL_ID IN (${L_PIL_047}) OR MASTER.AGENT_ID IN ('MMMM2841','MMMM5438')
              Then SLAVE.ORG_AUTO_ACTIVITY
           When SLAVE.ORG_REM_CHANNEL_CD Is Not Null
              Then SLAVE.ORG_AUTO_ACTIVITY
           Else MASTER.ORG_AUTO_ACTIVITY
      End                                                                                       As ORG_AUTO_ACTIVITY,

      Coalesce(SLAVE.ORG_EDO_ID,MASTER.ORG_EDO_ID)                                              As ORG_EDO_ID               ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_TYPE_EDO
            Else MASTER.ORG_TYPE_EDO
      End                                                                                       As ORG_TYPE_EDO             ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_EDO_IOBSP
            Else MASTER.ORG_EDO_IOBSP
      End                                                                                       As ORG_EDO_IOBSP             ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_FLAG_PLT_CONV
            Else MASTER.ORG_FLAG_PLT_CONV
      End                                                                                       As ORG_FLAG_PLT_CONV        ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_FLAG_TEAM_MKT
            Else MASTER.ORG_FLAG_TEAM_MKT
      End                                                                                       As ORG_FLAG_TEAM_MKT        ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_FLAG_TYPE_CMP
            Else MASTER.ORG_FLAG_TYPE_CMP
      End                                                                                       As ORG_FLAG_TYPE_CMP        ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_RESP_EDO_ID
            Else MASTER.ORG_RESP_EDO_ID
      End                                                                                       As ORG_RESP_EDO_ID          ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_RESP_TYPE_EDO
            Else MASTER.ORG_RESP_TYPE_EDO
      End                                                                                       As ORG_RESP_TYPE_EDO        ,
      Case  When SLAVE.ORG_EDO_ID Is Not Null
              Then SLAVE.ORG_RESP_FLAG_PLT_CONV
            Else MASTER.ORG_RESP_FLAG_PLT_CONV
      End                                                                                       As ORG_RESP_FLAG_PLT_CONV   ,
      -- Calcule H1
      Coalesce(SLAVE.WORK_TEAM_LEVEL_1_CD,MASTER.WORK_TEAM_LEVEL_1_CD)                          As WORK_TEAM_LEVEL_1_CD,
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_1_DS
            Else MASTER.WORK_TEAM_LEVEL_1_DS
      End                                                                                       As WORK_TEAM_LEVEL_1_DS,
      -- Calcul H2
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_2_CD
            Else MASTER.WORK_TEAM_LEVEL_2_CD
      End                                                                                       As WORK_TEAM_LEVEL_2_CD,
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_2_DS
            Else MASTER.WORK_TEAM_LEVEL_2_DS
      End                                                                                       As WORK_TEAM_LEVEL_2_DS,
      --Calcul H3
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_3_CD
            Else MASTER.WORK_TEAM_LEVEL_3_CD
      End                                                                                       As WORK_TEAM_LEVEL_3_CD,
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_3_DS
            Else MASTER.WORK_TEAM_LEVEL_3_DS
      End                                                                                       As WORK_TEAM_LEVEL_3_DS,
      --calcul H4
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_4_CD
            Else MASTER.WORK_TEAM_LEVEL_4_CD
      End                                                                                       As WORK_TEAM_LEVEL_4_CD,
      Case  When SLAVE.WORK_TEAM_LEVEL_1_CD Is Not Null
              Then SLAVE.WORK_TEAM_LEVEL_4_DS
            Else MASTER.WORK_TEAM_LEVEL_4_DS
      End                                                                                       As WORK_TEAM_LEVEL_4_DS,
    Abs((MASTER.ACT_TS - SLAVE.ACT_TS) Day(4) To Second)                                      As DIFF_TS, 
    (Extract(Day From DIFF_TS) * 86400) + (Extract(Hour From DIFF_TS) * 3600) + 
    (Extract(Minute From DIFF_TS) * 60) + Extract(Second From DIFF_TS)                        As OFFSET_SEC,
    MASTER.ACT_DT - SLAVE.ACT_DT                                                              As OFFSET 
  From
    ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} ${SourceTmp}
    Inner join ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED ${SourceSoc}
      On    MASTER.IMSI_CD = SLAVE.IMSI_CD 
        And MASTER.ACT_DT = SLAVE.ACT_DT
        And MASTER.ACT_SEG_COM_ID_FINAL = SLAVE.ACT_SEG_COM_ID_FINAL
  Where
    (1=1)
    And ${SourceTmp}.INTRNL_SOURCE_ID = '${SourceAlimId}' 
    And ${SourceTmp}.TYPE_SOURCE_ID In ( '${SourceAlimTyp}' )
    And ${SourceTmp}.ACT_CLOSURE_DT Is Null 
    And ${SourceTmp}.ACT_END_UNIFIED_DT Is Null 
    And ${SourceSoc}.INTRNL_SOURCE_ID = '${SourceEnrId}' 
    And ${SourceSoc}.TYPE_SOURCE_ID In ( '${SourceEnrTyp}' )
    And ${SourceSoc}.ACT_CLOSURE_DT Is Null 
    And ${SourceSoc}.ACT_END_UNIFIED_DT Is Null 
  Qualify Row_Number() Over(Partition By SLAVE.ACTE_ID Order By OFFSET_SEC Asc) = 1
)RES;
.if errorcode <> 0 then .quit 1;
  
Collect Stats On ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr};
.if errorcode <> 0 then .quit 1;

-- Alimentation des maîtres ou esclaves dans le TMP 

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} 
(
  ACTE_ID
, OPERATOR_PROVIDER_ID
, INTRNL_SOURCE_ID
, TYPE_SOURCE_ID
, MASTER_ACTE_ID
, MASTER_INTRNL_SOURCE_ID
, MASTER_FLAG
, MASTER_NB_FOUND
, CPLT_ACTE_ID
, CPLT_INTRNL_SOURCE_ID
, CPLT_IN
, RULE_ID
, OFFSET_NB
, ACT_TYPE
, ORDER_EXTERNAL_ID
, STATUS_CD
, ACT_UNIFIED_STATUS_CD
, ACT_TS
, ACT_DT
, ACT_HH
, ACT_LAST_UPD_TS
, ACT_PRODUCT_ID_PRE
, ACT_SEG_COM_ID_PRE
, ACT_SEG_COM_AGG_ID_PRE
, ACT_CODE_MIGR_PRE
, ACT_OPER_ID_PRE
, ACT_PRODUCT_ID_FINAL
, ACT_SEG_COM_ID_FINAL
, ACT_SEG_COM_AGG_ID_FINAL
, ACT_CODE_MIGR_FINAL
, ACT_OPER_ID_FINAL
, ACT_TYPE_SERVICE_FINAL
, ACT_TYPE_COMMANDE_ID
, ACT_DELTA_TARIF
, ACT_CD
, ACT_REM_ID
, ACT_FLAG_ACT_REM
, ACT_FLAG_PEC_PERPVC
, ACT_FLAG_PVC_REM
, ACT_ACTE_VALO
, ACT_ACTE_FAMILLE_KPI
, ACT_PERIODE_ID
, ACT_PERIODE_STATUS
, ACT_PERIODE_CLOSURE_DT
, ORIGIN_CD
, AGENT_ID
, AGENT_ID_UPD
, AGENT_ID_UPD_DT
, ORG_AGENT_IOBSP
, AGENT_FIRST_NAME
, AGENT_LAST_NAME
, UNIFIED_SHOP_CD
, ORG_SPE_CANAL_ID_MACRO
, ORG_SPE_CANAL_ID
, ORG_REM_CHANNEL_CD
, ORG_CHANNEL_CD
, ORG_SUB_CHANNEL_CD
, ORG_SUB_SUB_CHANNEL_CD
, ORG_GT_ACTIVITY
, ORG_FIDELISATION
, ORG_WEB_ACTIVITY
, ORG_AUTO_ACTIVITY
, ORG_EDO_ID
, ORG_TYPE_EDO
, ORG_EDO_IOBSP
, ORG_FLAG_PLT_CONV
, ORG_FLAG_TEAM_MKT
, ORG_FLAG_TYPE_CMP
, ORG_RESP_EDO_ID
, ORG_RESP_TYPE_EDO
, ORG_RESP_FLAG_PLT_CONV
, ACTIVITY_CD
, ACTIVITY_GROUPNG_CD
, AUTO_ACTIVITY_IN
, ORG_TYPE_CD
, ORG_TEAM_TYPE_ID
, ORG_TEAM_LEVEL_1_CD
, ORG_TEAM_LEVEL_1_DS
, ORG_TEAM_LEVEL_2_CD
, ORG_TEAM_LEVEL_2_DS
, ORG_TEAM_LEVEL_3_CD
, ORG_TEAM_LEVEL_3_DS
, ORG_TEAM_LEVEL_4_CD
, ORG_TEAM_LEVEL_4_DS
, WORK_TEAM_LEVEL_1_CD
, WORK_TEAM_LEVEL_1_DS
, WORK_TEAM_LEVEL_2_CD
, WORK_TEAM_LEVEL_2_DS
, WORK_TEAM_LEVEL_3_CD
, WORK_TEAM_LEVEL_3_DS
, WORK_TEAM_LEVEL_4_CD
, WORK_TEAM_LEVEL_4_DS
, CONFIRMATION_IN
, CONCLDD_IN
, COMPTTN_IN
, COMPTTN_ID
, PERNNT_IN
, PERNNT_END_DT
, PERNNT_MOTIF
, PERNNT_CALC_END_DT
, MIGRA_DT
, MIGRA_NEXT_OFFRE
, PRES_SEGMENT_IN_PARK_BEFORE_IN
, SEGMENT_DELIVERY_IN_PARK_DT
, ORDER_CANCELING_DT
, LINE_ID
, MASTER_LINE_ID
, CUST_TYPE_CD
, MSISDN_ID
, NDS_VALUE_DS
, EXTERNAL_PARTY_ID
, RES_VALUE_DS
, PAR_ACCES_SERVICE
, TAC_CD
, IMEI_CD
, IMSI_CD
, HOM_START_DT
, MOB_START_DT
, I_SCORE_VALUE
, I_SCORE_TRESHOLD
, I_SCORE_IN
, M_SCORE_VALUE
, M_SCORE_TRESHOLD
, M_SCORE_IN
, OSCAR_VALUE
, CUST_BU_TYPE_CD
, CUST_BU_CD
, ADDRESS_TYPE
, ADDRESS_CONCAT_NM
, POSTAL_CD
, INSEE_CD
, BU_CD
, DEPARTMNT_ID
, PAR_GEO_MACROZONE
, PAR_UNIFIED_PARTY_ID
, PAR_PARTY_REGRPMNT_ID
, PAR_CID_ID
, PAR_PID_ID
, PAR_FIRST_IN
, PAR_IRIS2000_CD
, COMMARTICLE_RP_REFPRIX_CD
, ACT_CA_LINE_AM
, ACT_CA_TTC_AM
, EAN_CD
, SIM_CD
, SIM_EAN_CD
, ORG_RESP_ID
, EAN_PREVIOUS_CD
, TAC_PREVIOUS_CD
, IMEI_PREVIOUS_CD
, PCM_PREVIOUS_OFFRE_CD
, PCM_COMMTMNT_PERIOD_NU
, PCM_LEVEL_POINT_NU
, PCM_OFFRE_CD
, PCM_EFFCTV_NEXT_OFFRE_DT
, PCM_TYPE_OFFRE_MOBILE_CD
, PCM_POINT_UTIL_NU
, PCM_BALANCE_POINT_NU
, PCM_STATUT_POINT_CD
, PCM_POINT_DUE_NU
, PAR_ELIGIBLE_FIBER_IN
, CHECK_INITIAL_STATUS_CD
, CHECK_NAT_STATUS_CD
, CHECK_NAT_COMMENT
, CHECK_NAT_STATUS_LN
, CHECK_LOC_STATUS_CD
, CHECK_LOC_COMMENT
, CHECK_LOC_STATUS_LN
, CHECK_VALIDT_DT
, ACT_END_UNIFIED_DT
, ACT_END_UNIFIED_DS
, ACT_CLOSURE_DT
, ACT_CLOSURE_DS
, HOT_IN
, RUN_ID
, CREATION_TS
, LAST_MODIF_TS
, FRESH_IN
, COHERENCE_IN)
Select
  SOC.ACTE_ID
, SOC.OPERATOR_PROVIDER_ID
, SOC.INTRNL_SOURCE_ID
, SOC.TYPE_SOURCE_ID
, SOC.MASTER_ACTE_ID
, SOC.MASTER_INTRNL_SOURCE_ID
, SOC.MASTER_FLAG
, SOC.MASTER_NB_FOUND
, SOC.CPLT_ACTE_ID
, SOC.CPLT_INTRNL_SOURCE_ID
, SOC.CPLT_IN
, SOC.RULE_ID
, SOC.OFFSET_NB
, SOC.ACT_TYPE
, SOC.ORDER_EXTERNAL_ID
, SOC.STATUS_CD
, SOC.ACT_UNIFIED_STATUS_CD
, SOC.ACT_TS
, SOC.ACT_DT
, SOC.ACT_HH
, SOC.ACT_LAST_UPD_TS
, SOC.ACT_PRODUCT_ID_PRE
, SOC.ACT_SEG_COM_ID_PRE
, SOC.ACT_SEG_COM_AGG_ID_PRE
, SOC.ACT_CODE_MIGR_PRE
, SOC.ACT_OPER_ID_PRE
, SOC.ACT_PRODUCT_ID_FINAL
, SOC.ACT_SEG_COM_ID_FINAL
, SOC.ACT_SEG_COM_AGG_ID_FINAL
, SOC.ACT_CODE_MIGR_FINAL
, SOC.ACT_OPER_ID_FINAL
, SOC.ACT_TYPE_SERVICE_FINAL
, SOC.ACT_TYPE_COMMANDE_ID
, SOC.ACT_DELTA_TARIF
, SOC.ACT_CD
, SOC.ACT_REM_ID
, SOC.ACT_FLAG_ACT_REM
, SOC.ACT_FLAG_PEC_PERPVC
, SOC.ACT_FLAG_PVC_REM
, SOC.ACT_ACTE_VALO
, SOC.ACT_ACTE_FAMILLE_KPI
, SOC.ACT_PERIODE_ID
, SOC.ACT_PERIODE_STATUS
, SOC.ACT_PERIODE_CLOSURE_DT
, SOC.ORIGIN_CD
, SOC.AGENT_ID
, SOC.AGENT_ID_UPD
, SOC.AGENT_ID_UPD_DT
, SOC.ORG_AGENT_IOBSP
, SOC.AGENT_FIRST_NAME
, SOC.AGENT_LAST_NAME
, SOC.UNIFIED_SHOP_CD
, SOC.ORG_SPE_CANAL_ID_MACRO
, SOC.ORG_SPE_CANAL_ID
, SOC.ORG_REM_CHANNEL_CD
, SOC.ORG_CHANNEL_CD
, SOC.ORG_SUB_CHANNEL_CD
, SOC.ORG_SUB_SUB_CHANNEL_CD
, SOC.ORG_GT_ACTIVITY
, SOC.ORG_FIDELISATION
, SOC.ORG_WEB_ACTIVITY
, SOC.ORG_AUTO_ACTIVITY
, SOC.ORG_EDO_ID
, SOC.ORG_TYPE_EDO
, SOC.ORG_EDO_IOBSP
, SOC.ORG_FLAG_PLT_CONV
, SOC.ORG_FLAG_TEAM_MKT
, SOC.ORG_FLAG_TYPE_CMP
, SOC.ORG_RESP_EDO_ID
, SOC.ORG_RESP_TYPE_EDO
, SOC.ORG_RESP_FLAG_PLT_CONV
, SOC.ACTIVITY_CD
, SOC.ACTIVITY_GROUPNG_CD
, SOC.AUTO_ACTIVITY_IN
, SOC.ORG_TYPE_CD
, SOC.ORG_TEAM_TYPE_ID
, SOC.ORG_TEAM_LEVEL_1_CD
, SOC.ORG_TEAM_LEVEL_1_DS
, SOC.ORG_TEAM_LEVEL_2_CD
, SOC.ORG_TEAM_LEVEL_2_DS
, SOC.ORG_TEAM_LEVEL_3_CD
, SOC.ORG_TEAM_LEVEL_3_DS
, SOC.ORG_TEAM_LEVEL_4_CD
, SOC.ORG_TEAM_LEVEL_4_DS
, SOC.WORK_TEAM_LEVEL_1_CD
, SOC.WORK_TEAM_LEVEL_1_DS
, SOC.WORK_TEAM_LEVEL_2_CD
, SOC.WORK_TEAM_LEVEL_2_DS
, SOC.WORK_TEAM_LEVEL_3_CD
, SOC.WORK_TEAM_LEVEL_3_DS
, SOC.WORK_TEAM_LEVEL_4_CD
, SOC.WORK_TEAM_LEVEL_4_DS
, SOC.CONFIRMATION_IN
, SOC.CONCLDD_IN
, SOC.COMPTTN_IN
, SOC.COMPTTN_ID
, SOC.PERNNT_IN
, SOC.PERNNT_END_DT
, SOC.PERNNT_MOTIF
, SOC.PERNNT_CALC_END_DT
, SOC.MIGRA_DT
, SOC.MIGRA_NEXT_OFFRE
, SOC.PRES_SEGMENT_IN_PARK_BEFORE_IN
, SOC.SEGMENT_DELIVERY_IN_PARK_DT
, SOC.ORDER_CANCELING_DT
, SOC.LINE_ID
, SOC.MASTER_LINE_ID
, SOC.CUST_TYPE_CD
, SOC.MSISDN_ID
, SOC.NDS_VALUE_DS
, SOC.EXTERNAL_PARTY_ID
, SOC.RES_VALUE_DS
, SOC.PAR_ACCES_SERVICE
, SOC.TAC_CD
, SOC.IMEI_CD
, SOC.IMSI_CD
, SOC.HOM_START_DT
, SOC.MOB_START_DT
, SOC.I_SCORE_VALUE
, SOC.I_SCORE_TRESHOLD
, SOC.I_SCORE_IN
, SOC.M_SCORE_VALUE
, SOC.M_SCORE_TRESHOLD
, SOC.M_SCORE_IN
, SOC.OSCAR_VALUE
, SOC.CUST_BU_TYPE_CD
, SOC.CUST_BU_CD
, SOC.ADDRESS_TYPE
, SOC.ADDRESS_CONCAT_NM
, SOC.POSTAL_CD
, SOC.INSEE_CD
, SOC.BU_CD
, SOC.DEPARTMNT_ID
, SOC.PAR_GEO_MACROZONE
, SOC.PAR_UNIFIED_PARTY_ID
, SOC.PAR_PARTY_REGRPMNT_ID
, SOC.PAR_CID_ID
, SOC.PAR_PID_ID
, SOC.PAR_FIRST_IN
, SOC.PAR_IRIS2000_CD
, SOC.COMMARTICLE_RP_REFPRIX_CD
, SOC.ACT_CA_LINE_AM
, SOC.ACT_CA_TTC_AM
, SOC.EAN_CD
, SOC.SIM_CD
, SOC.SIM_EAN_CD
, SOC.ORG_RESP_ID
, SOC.EAN_PREVIOUS_CD
, SOC.TAC_PREVIOUS_CD
, SOC.IMEI_PREVIOUS_CD
, SOC.PCM_PREVIOUS_OFFRE_CD
, SOC.PCM_COMMTMNT_PERIOD_NU
, SOC.PCM_LEVEL_POINT_NU
, SOC.PCM_OFFRE_CD
, SOC.PCM_EFFCTV_NEXT_OFFRE_DT
, SOC.PCM_TYPE_OFFRE_MOBILE_CD
, SOC.PCM_POINT_UTIL_NU
, SOC.PCM_BALANCE_POINT_NU
, SOC.PCM_STATUT_POINT_CD
, SOC.PCM_POINT_DUE_NU
, SOC.PAR_ELIGIBLE_FIBER_IN
, SOC.CHECK_INITIAL_STATUS_CD
, SOC.CHECK_NAT_STATUS_CD
, SOC.CHECK_NAT_COMMENT
, SOC.CHECK_NAT_STATUS_LN
, SOC.CHECK_LOC_STATUS_CD
, SOC.CHECK_LOC_COMMENT
, SOC.CHECK_LOC_STATUS_LN
, SOC.CHECK_VALIDT_DT
, SOC.ACT_END_UNIFIED_DT
, SOC.ACT_END_UNIFIED_DS
, SOC.ACT_CLOSURE_DT
, SOC.ACT_CLOSURE_DS
, SOC.HOT_IN
, SOC.RUN_ID
, SOC.CREATION_TS
, SOC.LAST_MODIF_TS
, SOC.FRESH_IN
, SOC.COHERENCE_IN
From ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED SOC 
Inner Join 
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr}
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET) = 1
) SRC
On  SOC.ACTE_ID = SRC.${SourceSoc}_ACTE_ID 
And SOC.INTRNL_SOURCE_ID = '${SourceEnrId}' 
And SOC.TYPE_SOURCE_ID In ( '${SourceEnrTyp}' )
Qualify Row_Number() Over (Partition by SOC.ACTE_ID Order by SOC.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1;

-- Enrichissement Esclave depuis maître

Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
     ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} SRC
Set
  MASTER_ACTE_ID          = SRC.MASTER_ACTE_ID,
  MASTER_INTRNL_SOURCE_ID = SRC.MASTER_SOURCE_ID,
  MASTER_FLAG             = ${P_PIL_355},
  MASTER_NB_FOUND         = SRC.MASTER_NB_FOUND,
  RULE_ID                 = SRC.RULE_ID,
  OFFSET_NB               = SRC.OFFSET,
  CPLT_ACTE_ID            = Null,
  CPLT_INTRNL_SOURCE_ID   = Null,
  CPLT_IN                 = '${P_PIL_388}' 
Where (1=1)
And CIB.ACTE_ID = SRC.SLAVE_ACTE_ID;
.if errorcode <> 0 then .quit 1;

-- On met a jour les maitres qui ne sont pas omnicanal : on met a jour tous les champs
Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET) = 1
) SRC
Set
  MASTER_ACTE_ID                = SRC.MASTER_ACTE_ID              ,
  MASTER_INTRNL_SOURCE_ID       = SRC.MASTER_SOURCE_ID            ,
  MASTER_FLAG                   = ${P_PIL_354}                    ,
  RULE_ID                       = SRC.RULE_ID                     ,
  OFFSET_NB                     = SRC.OFFSET                      ,
  CPLT_ACTE_ID                  = SRC.SLAVE_ACTE_ID               ,
  CPLT_INTRNL_SOURCE_ID         = SRC.SLAVE_SOURCE_ID             ,
  CPLT_IN                       = '${P_PIL_356}'                  ,
  ORG_REM_CHANNEL_CD            = SRC.ORG_REM_CHANNEL_CD          ,
  ORG_CHANNEL_CD                = SRC.ORG_CHANNEL_CD              ,
  ORG_SUB_CHANNEL_CD            = SRC.ORG_SUB_CHANNEL_CD          ,
  ORG_SUB_SUB_CHANNEL_CD        = SRC.ORG_SUB_SUB_CHANNEL_CD      ,
  ORG_GT_ACTIVITY               = SRC.ORG_GT_ACTIVITY             ,
  ORG_FIDELISATION              = SRC.ORG_FIDELISATION            ,
  ORG_WEB_ACTIVITY              = SRC.ORG_WEB_ACTIVITY            ,
  ORG_AUTO_ACTIVITY             = SRC.ORG_AUTO_ACTIVITY           ,
  ORG_EDO_ID                    = SRC.ORG_EDO_ID                  ,
  ORG_TYPE_EDO                  = SRC.ORG_TYPE_EDO                ,
  ORG_EDO_IOBSP                 = SRC.ORG_EDO_IOBSP               ,
  ORG_FLAG_PLT_CONV             = SRC.ORG_FLAG_PLT_CONV           ,
  ORG_FLAG_TEAM_MKT             = SRC.ORG_FLAG_TEAM_MKT           ,
  ORG_FLAG_TYPE_CMP             = SRC.ORG_FLAG_TYPE_CMP           ,
  ORG_RESP_EDO_ID               = SRC.ORG_RESP_EDO_ID             ,
  ORG_RESP_TYPE_EDO             = SRC.ORG_RESP_TYPE_EDO           ,
  ORG_RESP_FLAG_PLT_CONV        = SRC.ORG_RESP_FLAG_PLT_CONV      ,
  WORK_TEAM_LEVEL_1_CD          = SRC.WORK_TEAM_LEVEL_1_CD        ,
  WORK_TEAM_LEVEL_1_DS          = SRC.WORK_TEAM_LEVEL_1_DS        ,
  WORK_TEAM_LEVEL_2_CD          = SRC.WORK_TEAM_LEVEL_2_CD        ,
  WORK_TEAM_LEVEL_2_DS          = SRC.WORK_TEAM_LEVEL_2_DS        ,
  WORK_TEAM_LEVEL_3_CD          = SRC.WORK_TEAM_LEVEL_3_CD        ,
  WORK_TEAM_LEVEL_3_DS          = SRC.WORK_TEAM_LEVEL_3_DS        ,
  WORK_TEAM_LEVEL_4_CD          = SRC.WORK_TEAM_LEVEL_4_CD        ,
  WORK_TEAM_LEVEL_4_DS          = SRC.WORK_TEAM_LEVEL_4_DS        
Where 
  (1=1)
  And CIB.ACTE_ID = SRC.MASTER_ACTE_ID
  And Coalesce(CIB.RULE_ID,-1)      <>  '${P_PIL_436}'  --On exclu les lignes qui ont été enrichie par un traçage Automatique
  And CIB.ORG_WEB_ACTIVITY  <> 'Omnicanal'
;
.if errorcode <> 0 then .quit 1;


-- On met a jour les maitres omnicanal : on met a jour uniquement les champs qui permettent le lien
-- Le reste est inchange pour rester conforme a l'omnicanal
Update CIB
From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_${SourceAlim} CIB,
(
  Select *
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${SourceAlim}_${SourceEnr} 
  QUALIFY Row_Number() OVER(Partition By MASTER_ACTE_ID Order By OFFSET) = 1
) SRC
Set
  MASTER_ACTE_ID                = SRC.MASTER_ACTE_ID              ,
  MASTER_INTRNL_SOURCE_ID       = SRC.MASTER_SOURCE_ID            ,
  MASTER_FLAG                   = ${P_PIL_354}                    ,
  RULE_ID                       = SRC.RULE_ID                     ,
  OFFSET_NB                     = SRC.OFFSET                      ,
  CPLT_ACTE_ID                  = SRC.SLAVE_ACTE_ID               ,
  CPLT_INTRNL_SOURCE_ID         = SRC.SLAVE_SOURCE_ID             ,
  CPLT_IN                       = '${P_PIL_356}'                  
Where 
  (1=1)
  And CIB.ACTE_ID = SRC.MASTER_ACTE_ID
  And Coalesce(CIB.RULE_ID,-1)      <>  '${P_PIL_436}'  --On exclu les lignes qui ont été enrichie par un traçage Automatique
  And CIB.ORG_WEB_ACTIVITY  = 'Omnicanal'
;
.if errorcode <> 0 then .quit 1;

.quit 0



