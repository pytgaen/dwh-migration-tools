--$HEADER: %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile: ATP_PCO_EnrichissementPlacementVendeurO3_PCM.sql $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script de fusion des données entre celles provenant de l'enrichissement pour la péernenité 
--                et les données non prises en compte par cette enrichissement pre placement (EDEL)
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 09/09/2013     GMA         Création
-- 06/02/2014     AID         Indus
-- 11/01/2016     OCH         Ajout du EDO PCM par defaut
-- 02/03/2016     TPI         QC 1072 : Modification paramètres
-- 28/06/2016     GMA         Modification Passage multicanal Edo pas défault
---------------------------------------------------------------------------------

.set width 2000;

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3 All;
.if errorcode <> 0 then .quit 1

--------------------------------------------------------------------
-- On recherche dans O3 pour les lignes "Point de Vente renseigné"
--------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  ,
  FLAG_TYPE_GEO             ,
  FLAG_TYPE_CPT_NTK         ,
  FLAG_TYPE_PTN_NTK         
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             ,
  RefO3.FLAG_TYPE_GEO               as FLAG_TYPE_GEO        ,
  RefO3.FLAG_TYPE_CPT_NTK           as FLAG_TYPE_CPT_NTK    ,
  RefO3.FLAG_TYPE_PTN_NTK           as FLAG_TYPE_PTN_NTK    
From
  (
    Select
      RefId.ACTE_ID                                             as ACTE_ID                    ,
      RefId.DATESAISIEBCR                                       as DATESAISIEBCR              ,
      Coalesce(RefConseil.ORG_REF_TRAV,RefId.ORG_REF_TRAV)      as ORG_REF_TRAV               ,
      Coalesce(RefConseil.ORG_GROUPE_ID,RefId.ORG_GROUPE_ID)    as ORG_GROUPE_ID              ,
      RefId.PV_POINTVENTE                                       as PV_POINTVENTE  
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM    RefId
      Left Outer Join  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR  RefConseil
        On  RefId.ACTE_ID = RefConseil.ACTE_ID
    Where RefId.PV_POINTVENTE IS NOT NULL
    And RefId.CD_CANALDIST Not IN('5','9')
  ) RefId
  Inner Join
    (
      Select
        RefPdv.EDO_ID                                                                         as EDO_ID               ,
        RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
        RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   as TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
              Else    0
        End                                                                                   as FLAG_PLT_CONV        ,
        Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                                                   as FLAG_PLT_SCH         ,
        Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
        Case  When RefEdo.STATT_EDO_CD = '${P_PIL_437}'
                Then 1
              Else 0
        End                                                                                   as FLAG_EDO_ACT         ,
        Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
        Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT             ,
        RefPdv.ROL_LINK_CD                                                                    as ROL_LINK_CD          ,
        RefEdoDOM.AXS_CLSSF_ID                                                                as FLAG_TYPE_GEO        ,
        RefEdoCompNetwork.AXS_CLSSF_ID                                                        as FLAG_TYPE_CPT_NTK    ,
        Case    When RefEdoConcNetwork.AXS_CLSSF_ID In ('MOBI')
                  Then 'Mobistore'
                When RefEdoConcNetwork.AXS_CLSSF_ID In ('PSE','PST')
                  Then 'GDT'
                When RefEdoConcNetwork.AXS_CLSSF_ID In ('FC')
                  Then 'CARAIBES'
        End                                                                                   as FLAG_TYPE_PTN_NTK   
      From
        ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO_LNK RefPdv
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoAVSC
        On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
        ---------Ajout Multicanal
        --On va dans le referentiel axs_edo pour remonter les flags GEO
        Left Outer Join
        (
          Select
            EDO_ID                          As EDO_ID             ,
            VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111})
            And EdoAx.FRESH_IN              = 1
            And EdoAx.CURRENT_IN            = 1
            And EdoAx.CLOSURE_DT            Is Null
          Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
        ) RefEdoDOM
        On  RefPdv.EDO_ID   = RefEdoDOM.EDO_ID         
        --On va dans le referentiel axs_edo pour remonter le flag de réseau compétitif
        Left Outer Join
        (
          Select
            EDO_ID                          As EDO_ID             ,
            VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112})
            And EdoAx.FRESH_IN              = 1
            And EdoAx.CURRENT_IN            = 1
            And EdoAx.CLOSURE_DT            Is Null
          Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
        ) RefEdoCompNetwork
        On  RefPdv.EDO_ID   = RefEdoCompNetwork.EDO_ID
      --On va dans le referentiel axs_edo pour remonter le flag de réseau concurrentiel
      Left Outer Join
        (
          Select
            EDO_ID                          As EDO_ID             ,
            VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_130}) -- 'MOBI','PSE','PST'
            And EdoAx.FRESH_IN              = 1
            And EdoAx.CURRENT_IN            = 1
            And EdoAx.CLOSURE_DT            Is Null
          Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
        ) RefEdoConcNetwork
        On  RefPdv.EDO_ID   = RefEdoConcNetwork.EDO_ID
        ---------Fin Ajout Multicanal
          --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
        Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
          On    RefPdv.EDO_ID         = RefEdo.EDO_ID
            And RefEdo.CURRENT_IN     = 1
            And RefEdo.CLOSURE_DT     Is Null
      Where
        (1=1)
        And RefPdv.CURRENT_IN   = 1
        And RefPdv.CLOSURE_DT   Is Null
    )RefO3
    On    RefId.PV_POINTVENTE     = RefO3.EXTNL_VAL_COD_CD
      And RefId.DATESAISIEBCR     >= RefO3.START_EXTNL_VAL_DT
      And RefId.DATESAISIEBCR     <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
      And RefId.DATESAISIEBCR     >= RefO3.OPEN_DT
      And RefId.DATESAISIEBCR     <= RefO3.CLOSE_DT
Where
  (1=1)
Qualify Row_Number() Over(Partition by RefId.ACTE_ID Order by RefO3.ROL_LINK_CD Asc, RefO3.FLAG_EDO_ACT Desc, RefO3.START_EXTNL_VAL_DT Desc, Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD')) Desc)=1
;
.if errorcode <> 0 then .quit 1

-----------------------------------------------------------------------------------------
-- On recherche dans O3 pour les lignes "Point de vente non renseigné" et Orga = "POCSC"
-----------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
From
  (
    Select
      RefId.ACTE_ID                                             as ACTE_ID                    ,
      RefId.DATESAISIEBCR                                       as DATESAISIEBCR              ,
      Coalesce(RefConseil.ORG_REF_TRAV,RefId.ORG_REF_TRAV)      as ORG_REF_TRAV               ,
      Coalesce(RefConseil.ORG_GROUPE_ID,RefId.ORG_GROUPE_ID)    as ORG_GROUPE_ID              ,
      RefId.PV_POINTVENTE                                       as PV_POINTVENTE  
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM    RefId
      Left Outer Join  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR  RefConseil
        On  RefId.ACTE_ID = RefConseil.ACTE_ID
    Where RefId.PV_POINTVENTE IS NULL
    And RefId.CD_CANALDIST Not IN('5','9')
  ) RefId
  Inner Join
    (
      Select
        RefPdv.EDO_ID                                                                         as EDO_ID               ,
        RefPdv.START_EXTNL_VAL_DT                                                             as START_EXTNL_VAL_DT   ,
        RefPdv.EXTNL_VAL_COD_CD                                                               as EXTNL_VAL_COD_CD     ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   as TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        Case  When RefEdoConv.EDO_ID Is Not Null
                Then  1 --Si on trouve une correspondance alors c'est un plateau convergent
              Else    0
        End                                                                                   as FLAG_PLT_CONV        ,
        Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
        End                                                                                   as FLAG_PLT_SCH         ,
        Coalesce(RefPdv.END_EXTNL_VAL_DT, Cast('9999-12-31' as date format 'YYYY-MM-DD'))     as END_EXTNL_VAL_DT     ,
        Case  When RefEdo.STATT_EDO_CD = '${P_PIL_437}'
                Then 1
              Else 0
        End                                                                                   as FLAG_EDO_ACT         ,
        Coalesce(RefEdo.OPEN_DT, cast('1900-01-01' as date format 'YYYY-MM-DD'))              as OPEN_DT              ,
        Coalesce(RefEdo.CLOSE_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))             as CLOSE_DT                      
      From
        ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO RefPdv
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        On  RefPdv.EDO_ID   = RefEdoConv.EDO_ID
        Left Outer Join
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoAVSC
        On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
          --On va dans le référentiel des EDO pour savoir si c'est un PDV interne ou Externe
        Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
          On    RefPdv.EDO_ID         = RefEdo.EDO_ID
            And RefEdo.CURRENT_IN     = 1
            And RefEdo.CLOSURE_DT     Is Null
      Where
        (1=1)
        And RefPdv.EXTNL_COD_CD = 'REGARDSC'
        And RefPdv.CURRENT_IN   = 1
        And RefPdv.CLOSURE_DT   Is Null
    )RefO3
    On    RefId.ORG_GROUPE_ID     = RefO3.EXTNL_VAL_COD_CD
      And RefId.DATESAISIEBCR     >= RefO3.START_EXTNL_VAL_DT
      And RefId.DATESAISIEBCR     <= Coalesce(RefO3.END_EXTNL_VAL_DT, Cast('99991231' as Date Format 'YYYYMMDD'))
      And RefId.DATESAISIEBCR     >= RefO3.OPEN_DT
      And RefId.DATESAISIEBCR     <= RefO3.CLOSE_DT
Where
  (1=1)
      And RefId.ORG_REF_TRAV    = 'POCSC'
      And RefId.ORG_GROUPE_ID   IS NOT NULL
Qualify Row_Number() Over(Partition by RefId.ACTE_ID, RefId.DATESAISIEBCR ORDER BY RefO3.START_EXTNL_VAL_DT DESC, RefO3.FLAG_EDO_ACT DESC, COALESCE(RefO3.END_EXTNL_VAL_DT, CAST('99991231' AS DATE FORMAT 'YYYYMMDD')) DESC)=1
;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
-- On recherche dans O3 pour les lignes "Point de vente non renseigné" et Orage = "OEEEDEL"
-------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  RefO3.FLAG_PLT_CONV               as FLAG_PLT_CONV        ,
  RefO3.FLAG_PLT_SCH                as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
From
  (
    Select
      RefId.ACTE_ID                                             as ACTE_ID                    ,
      RefId.DATESAISIEBCR                                       as DATESAISIEBCR              ,
      Coalesce(RefConseil.ORG_REF_TRAV,RefId.ORG_REF_TRAV)      as ORG_REF_TRAV               ,
      Coalesce(RefConseil.ORG_GROUPE_ID,RefId.ORG_GROUPE_ID)    as ORG_GROUPE_ID              ,
      RefId.PV_POINTVENTE                                       as PV_POINTVENTE  
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM    RefId
      Left Outer Join  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEUR  RefConseil
        On  RefId.ACTE_ID = RefConseil.ACTE_ID
    Where RefId.PV_POINTVENTE IS NULL
    And RefId.CD_CANALDIST Not IN('5','9')
  ) RefId
  INNER JOIN
    (
      SELECT
        RefEdo.EDO_ID                                                                         AS EDO_ID               ,
        Conv.ORG_GROUPE_ID                                                                    AS ORG_GROUPE_ID        ,
        RefEdo.START_DT                                                                       AS START_DT             ,
        COALESCE(RefEdo.CLOSE_DT,CURRENT_DATE)                                                AS CLOSE_DT             ,
        --On détermine si c'est un plateau Interne ou Externe
        Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                                                   AS TYPE_EDO             ,
        --On vérifie si le plateau travail sur du convergent ou pas
        CASE  WHEN RefEdoConv.EDO_ID IS NOT NULL
                THEN  1 --Si on trouve une correspondance alors c'est un plateau convergent
              ELSE    0
        END                                                                                   AS FLAG_PLT_CONV        ,
        CASE  WHEN RefEdoAVSC.EDO_ID IS NOT NULL
                THEN  1
              ELSE    0
        END                                                                                   AS FLAG_PLT_SCH         

      FROM ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
               
      INNER JOIN ${KNB_PCO_SOC}.ORG_R_TRANS_CONSEIL_O3 Conv
          ON RefEdo.EDO_ID = Conv.EDO_ID
             AND Conv.CURRENT_IN     = 1
             AND Conv.CLOSURE_DT     IS NULL
             
        LEFT OUTER JOIN
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO a déjà été convergent
          Select
            EDO_ID
          From
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_110}) -- 'SOSH','OPEN'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
          Group By
            EDO_ID
        ) RefEdoConv
        ON  RefEdo.EDO_ID   = RefEdoConv.EDO_ID
        LEFT OUTER JOIN
        (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
         SELECT
            EDO_ID
          FROM
            ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
          WHERE
            (1=1)
            AND EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            AND EdoAx.FRESH_IN          = 1
            AND EdoAx.CURRENT_IN        = 1
            AND EdoAx.CLOSURE_DT        IS NULL
          GROUP BY
            EDO_ID
        ) RefEdoAVSC
        ON  RefEdo.EDO_ID   = RefEdoAVSC.EDO_ID
        
      WHERE
        (1=1)
        AND RefEdo.CURRENT_IN   = 1
        AND RefEdo.CLOSURE_DT   IS NULL
    )RefO3
    ON    RefId.ORG_GROUPE_ID    = RefO3.ORG_GROUPE_ID
      AND RefId.DATESAISIEBCR >= RefO3.START_DT
      AND RefId.DATESAISIEBCR <=  RefO3.CLOSE_DT
WHERE
  (1=1)
  AND RefId.ORG_REF_TRAV    = 'OEEEDEL'
QUALIFY ROW_NUMBER() OVER(PARTITION BY RefId.ACTE_ID, RefId.DATESAISIEBCR ORDER BY RefO3.START_DT DESC, RefO3.CLOSE_DT DESC)=1
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3;
.if errorcode <> 0 then .quit 1



--On regarde EDO dans la table de parametrage
Create Volatile Table ${KNB_TERADATA_USER}.PCM_V_EDO_CHANNEL (
  CD_CANALDIST          CHAR(1)          Not Null,
  EDO_ID                BIGINT            ,
  TYPE_EDO              VARCHAR(255)
  )
Primary Index (
  CD_CANALDIST
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------

Insert into ${KNB_TERADATA_USER}.PCM_V_EDO_CHANNEL
(
 CD_CANALDIST ,
 EDO_ID       ,
 TYPE_EDO     
)
Select
 OrgChannelPcm.CD_CANALDIST                                       as CD_CANALDIST ,
 OrgChannelPcm.EDO_ID                                             as EDO_ID       ,
 Case  When RefEdo.NETWRK_TYP_EDO_ID = 'FT'
                Then  '${P_PIL_235}'
              Else    '${P_PIL_236}'
        End                                                       as TYPE_EDO
From
  ${KNB_PCO_SOC}.V_ORG_R_CHANNEL_PCM OrgChannelPcm
  Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo
    On  RefEdo.EDO_ID   = OrgChannelPcm.EDO_ID
WHERE
  (1=1)
  AND RefEdo.CURRENT_IN   = 1
  AND RefEdo.CLOSURE_DT   IS NULL
  AND OrgChannelPcm.EDO_ID Is Not Null
QUALIFY ROW_NUMBER() OVER(PARTITION BY OrgChannelPcm.CD_CANALDIST ORDER BY OrgChannelPcm.CREATION_TS DESC)=1 
;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_TERADATA_USER}.PCM_V_EDO_CHANNEL Column (CD_CANALDIST);
.if errorcode <> 0 then .quit 1



Update TbEnri
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3 TbEnri,
  ${KNB_TERADATA_USER}.PCM_V_EDO_CHANNEL RefO3 ,
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM RefId
Set
  EDO_ID        = RefO3.EDO_ID      ,
  FLAG_PLT_CONV = 0                 ,
  FLAG_PLT_SCH  = 0                 ,
  TYPE_EDO      =RefO3.TYPE_EDO     
Where
  (1=1)
  And RefId.CD_CANALDIST    = RefO3.CD_CANALDIST
  And RefId.ACTE_ID         = TbEnri.ACTE_ID
  And RefId.CD_CANALDIST    In ('8')
  And TbEnri.EDO_ID         Is Null
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3;
.if errorcode <> 0 then .quit 1


-------------------------------------------------------------------------------------------
-- On recherche dans O3 pour les lignes RefId.CD_CANALDIST Not IN('5','9')
-------------------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3
(
  ACTE_ID                   ,
  ORG_GROUPE_ID             ,
  EDO_ID                    ,
  FLAG_PLT_CONV             ,
  FLAG_PLT_SCH              ,
  TYPE_EDO                  
)
Select
  RefId.ACTE_ID                     as ACTE_ID              ,
  RefId.ORG_GROUPE_ID               as ORG_GROUPE_ID        ,
  RefO3.EDO_ID                      as EDO_ID               ,
  0                                 as FLAG_PLT_CONV        ,
  0                                 as FLAG_PLT_SCH         ,
  RefO3.TYPE_EDO                    as TYPE_EDO             
  
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM    RefId
  Inner Join  ${KNB_TERADATA_USER}.PCM_V_EDO_CHANNEL RefO3
    On RefId.CD_CANALDIST = RefO3.CD_CANALDIST
Where
  (1=1)
  And RefId.CD_CANALDIST in ('5','9','8')
  And Not Exists
    (
      Select
        1
      From
        ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3 RefdejaEnri
      Where
        RefId.ACTE_ID=RefdejaEnri.ACTE_ID
    )
;
.if errorcode <> 0 then .quit 1
Collect stat on ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3;
.if errorcode <> 0 then .quit 1








--Recherche du INT/EXT
Update RefId
From
  (
    Select
      RefVend.ACTE_ID                             as ACTE_ID              ,
      RefId.DATESAISIEBCR                         as DATESAISIEBCR        ,
      Case  When (  --Si l'un des EDO père est externe alors c'est un EDO externe
                      OrgWork.WORK_TEAM_LEVEL_1_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_2_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_3_TYPE_EDO ='${P_PIL_236}'
                  Or  OrgWork.WORK_TEAM_LEVEL_4_TYPE_EDO ='${P_PIL_236}'
                  )
              Then '${P_PIL_236}'
              Else '${P_PIL_235}'
      End                                         as TYPE_EDO             
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3 RefVend
      Inner Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_INTER_PCM RefId
        On    RefVend.ACTE_ID                     =   RefId.ACTE_ID
      Inner Join ${KNB_PCO_TMP}.ORG_T_REF_ORGA_O3_FONC_LVL_ALL OrgWork
        On    RefVend.EDO_ID                      =   OrgWork.WORK_TEAM_LEVEL_1_CD
          And RefId.DATESAISIEBCR                 >=  OrgWork.WORK_TEAM_LEVEL_1_START_DT
          And RefId.DATESAISIEBCR                 <=  OrgWork.WORK_TEAM_LEVEL_1_END_DT
          And RefId.DATESAISIEBCR                 >=  OrgWork.WORK_TEAM_LEVEL_2_START_DT
          And RefId.DATESAISIEBCR                 <=  OrgWork.WORK_TEAM_LEVEL_2_END_DT
          And RefId.DATESAISIEBCR                 >=  OrgWork.WORK_TEAM_LEVEL_3_START_DT
          And RefId.DATESAISIEBCR                 <=  OrgWork.WORK_TEAM_LEVEL_3_END_DT
          And RefId.DATESAISIEBCR                 >=  OrgWork.WORK_TEAM_LEVEL_4_START_DT
          And RefId.DATESAISIEBCR                 <=  OrgWork.WORK_TEAM_LEVEL_4_END_DT
    Qualify Row_Number() Over (Partition by RefVend.ACTE_ID Order by  OrgWork.WORK_TEAM_LEVEL_1_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_PRIORITE Asc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_START_DT Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_1_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_2_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_3_CD Desc,
                                                                      OrgWork.WORK_TEAM_LEVEL_4_CD Desc
                              )=1
  )RefEnri,
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_PCM_VENDEURO3 RefId
Set
  TYPE_EDO= RefEnri.TYPE_EDO
Where
  (1=1)
  And RefId.ACTE_ID               = RefEnri.ACTE_ID
;
.if errorcode <> 0 then .quit 1



.quit 0
