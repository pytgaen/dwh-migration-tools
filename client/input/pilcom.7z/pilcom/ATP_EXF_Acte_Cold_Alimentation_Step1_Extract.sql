-- $HEADER: mm2pco/current/sql/ATP_EXF_Acte_Cold_Alimentation_Step1_Extract.sql 13_05#3 28-NOV-2017 15:17:23 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_EXF_Acte_Cold_Alimentation_Step1_Extract.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'extraction du placement EXF du Socle
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 15/07/2014      OCH         Création
-- 12/04/2015      MDE         Evol  : profondeur calcul 100 jrs
-- 21/11/2017      HOB         Alimentation Champs IOBSP
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_EXTR All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_EXTR
(
ACTE_ID                    ,
EXTERNAL_ACTE_ID           ,
TYPE_MOVEMENT_CD           ,
INTRNL_SOURCE_ID           ,
ORDER_DEPOSIT_DT           ,
ORDER_DEPOSIT_TS           ,
NUM_ORDER_NU               ,
COMMENT_DS                 ,
LAST_NAME_CUSTOMER_NM      ,
FIRST_NAME_CUSTOMER_NM     ,
MISISDN_ID                 ,
ND_ID                      ,
NDIP_ID                    ,
TYPE_CUSTOMER_CD           ,
TYPE_SOURCE_CD             ,
ENGAGMNT_NB                ,
AGENT_ID                   ,
ORG_AGENT_IOBSP            ,
NATURE_CD                  ,
OSCAR_VALUE_CD             ,
INJECTION_TS               ,
CLOSURE_DT                 ,
ORG_REF_TRAV_ID            ,
ORG_AGENT_ID               ,
ORG_POC_XI                 ,
ORG_LAST_NAME_NM           ,
ORG_FIRST_NAME_NM          ,
WORK_GROUPE_ID             ,
ORG_GROUPE_ID              ,
ORG_ACTVT_REAL_ID          ,
ORG_RESP_REF_TRAV_ID       ,
ORG_RESP_AGENT_ID          ,
ORG_RESP_XI_ID             ,
ORG_RESP_REAL_ACTIVITY_CD  ,
ACT_REM_ID                 ,
CDR_ID                     ,
EDO_ID                     ,
ORG_EDO_IOBSP              ,
PLT_CONV_IN                ,
PLT_SCH_IN                 ,
TEAM_MKT_IN                ,
TYPE_CMP_IN                ,
TYPE_GEO_IN                ,
TYPE_CPT_NTK_IN            ,
TYPE_EDO_IN                ,
NETWRK_TYP_EDO_ID          ,
QUANTT_QT                  ,
CA_AM                      ,
CA_LINE_AM                 ,
HOT_IN                     ,
CREATION_TS                ,
LAST_MODIF_TS              ,
FRESH_IN                   ,
COHERENCE_IN

)
Select
PlSoc.ACTE_ID                       As  ACTE_ID                    ,
PlSoc.EXTERNAL_ACTE_ID              As  EXTERNAL_ACTE_ID           ,
PlSoc.TYPE_MOVEMENT_CD              As  TYPE_MOVEMENT_CD           ,
PlSoc.INTRNL_SOURCE_ID              As  INTRNL_SOURCE_ID           ,
PlSoc.ORDER_DEPOSIT_DT              As  ORDER_DEPOSIT_DT           ,
PlSoc.ORDER_DEPOSIT_TS              As  ORDER_DEPOSIT_TS           ,
PlSoc.NUM_ORDER_NU                  As  NUM_ORDER_NU               ,
PlSoc.COMMENT_DS                    As  COMMENT_DS                 ,
PlSoc.LAST_NAME_CUSTOMER_NM         As  LAST_NAME_CUSTOMER_NM      ,
PlSoc.FIRST_NAME_CUSTOMER_NM        As  FIRST_NAME_CUSTOMER_NM     ,
PlSoc.MISISDN_ID                    As  MISISDN_ID                 ,
PlSoc.ND_ID                         As  ND_ID                      ,
PlSoc.NDIP_ID                       As  NDIP_ID                    ,
PlSoc.TYPE_CUSTOMER_CD              As  TYPE_CUSTOMER_CD           ,
PlSoc.TYPE_SOURCE_CD                As  TYPE_SOURCE_CD             ,
PlSoc.ENGAGMNT_NB                   As  ENGAGMNT_NB                ,
PlSoc.AGENT_ID                      As  AGENT_ID                   ,
PlSoc.ORG_AGENT_IOBSP               As  ORG_AGENT_IOBSP            ,
PlSoc.NATURE_CD                     As  NATURE_CD                  ,
PlSoc.OSCAR_VALUE_CD                As  OSCAR_VALUE_CD             ,
PlSoc.INJECTION_TS                  As  INJECTION_TS               ,
PlSoc.CLOSURE_DT                    As  CLOSURE_DT                 ,
PlSoc.ORG_REF_TRAV_ID               As  ORG_REF_TRAV_ID            ,
PlSoc.ORG_AGENT_ID                  As  ORG_AGENT_ID               ,
PlSoc.ORG_POC_XI                    As  ORG_POC_XI                 ,
PlSoc.ORG_LAST_NAME_NM              As  ORG_LAST_NAME_NM           ,
PlSoc.ORG_FIRST_NAME_NM             As  ORG_FIRST_NAME_NM          ,
PlSoc.WORK_GROUPE_ID                As  WORK_GROUPE_ID             ,
PlSoc.ORG_GROUPE_ID                 As  ORG_GROUPE_ID              ,
PlSoc.ORG_ACTVT_REAL_ID             As  ORG_ACTVT_REAL_ID          ,
PlSoc.ORG_RESP_REF_TRAV_ID          As  ORG_RESP_REF_TRAV_ID       ,
PlSoc.ORG_RESP_AGENT_ID             As  ORG_RESP_AGENT_ID          ,
PlSoc.ORG_RESP_XI_ID                As  ORG_RESP_XI_ID             ,
PlSoc.ORG_RESP_REAL_ACTIVITY_CD     As  ORG_RESP_REAL_ACTIVITY_CD  ,
PlSoc.ACT_REM_ID                    As  ACT_REM_ID                 ,
PlSoc.CDR_ID                        As  CDR_ID                     ,
PlSoc.EDO_ID                        As  EDO_ID                     ,
PlSoc.ORG_EDO_IOBSP                 As  ORG_EDO_IOBSP              ,
PlSoc.PLT_CONV_IN                   As  PLT_CONV_IN                ,
PlSoc.PLT_SCH_IN                    As  PLT_SCH_IN                 ,
PlSoc.TEAM_MKT_IN                   As  TEAM_MKT_IN                ,
PlSoc.TYPE_CMP_IN                   As  TYPE_CMP_IN                ,
PlSoc.TYPE_GEO_IN                   As  TYPE_GEO_IN                ,
PlSoc.TYPE_CPT_NTK_IN               As  TYPE_CPT_NTK_IN            ,
PlSoc.TYPE_EDO_IN                   As  TYPE_EDO_IN                ,
PlSoc.NETWRK_TYP_EDO_ID             As  NETWRK_TYP_EDO_ID          ,
PlSoc.QUANTT_QT                     As  QUANTT_QT                  ,
PlSoc.CA_AM                         As  CA_AM                      ,
PlSoc.CA_LINE_AM                    As  CA_LINE_AM                 ,
PlSoc.HOT_IN                        As  HOT_IN                     ,
PlSoc.CREATION_TS                   As  CREATION_TS                ,
PlSoc.LAST_MODIF_TS                 As  LAST_MODIF_TS              ,
PlSoc.FRESH_IN                      As  FRESH_IN                   ,
PlSoc.COHERENCE_IN                  As  COHERENCE_IN

From
  ${KNB_PCO_SOC}.V_ACT_F_PLACEMENT_EXF PlSoc
  
where          1    =    1
  And   PlSoc.ORDER_DEPOSIT_DT >= (Current_date - ${P_PIL_532})
  
;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.ACT_W_PLACEMENT_EXF_C_EXTR;
.if errorcode <> 0 then .quit 1

.quit 0
