-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSH_Placement_Cold_Enrichissement_AttributUSCM.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL d'enrichissement des attributs USCM
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 28/03/2014      MCA         Creation
-- 18/07/2014      MCA         Indus
--------------------------------------------------------------------------------

.set width 2500;

--------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_USCM All;
.if errorcode <> 0 then .quit 1
--------------------------------------------------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_USCM
(
  ACTE_ID                   ,
  ORDER_DEPOSIT_DT          ,
  PAR_USCM                  ,
  PAR_USCM_DS               ,
  PAR_USCM_USCM_DS          ,
  PAR_USCM_REGUSCM          ,
  PAR_USCM_REGUSCM_DS
)
Select
  RefId.ACTE_ID                     as ACTE_ID                    ,
  RefId.ORDER_DEPOSIT_DT            as ORDER_DEPOSIT_DT           ,
  ReferentielUSCM.USCM_CO           as PAR_USCM                   ,
  --On enrichi les attributs du  code parc
  ReferentielUSCM.USCM_LL           as PAR_USCM_DS                ,
  ReferentielUSCM.USCM_LL_USCM      as PAR_USCM_USCM_DS           ,
  ReferentielUSCM.USCM_CO_REGUSCM   as PAR_USCM_REGUSCM           ,
  ReferentielUSCM.USCM_LB_REGUSCM   as PAR_USCM_REGUSCM_DS        
From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_C_NEWSHOP RefId
  Inner Join ${KNB_IBU_SOC}.V_TDUSCM ReferentielUSCM
    On    ReferentielUSCM.CURRENT_IN    = 1
      And CLOSURE_DT                    Is Null
Where
  (1=1)
Qualify Row_Number() Over (Partition by RefId.ACTE_ID Order by ReferentielUSCM.CREATION_TS Desc)=1
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_NSH_CL_USCM
;
.if errorcode <> 0 then .quit 1
