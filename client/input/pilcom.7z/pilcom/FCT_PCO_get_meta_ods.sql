-----------------------------------------------------------------------------------------
-- $HEADER: %HEADER%
-----------------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:  FCT_PCO_get_meta_ods.sql $                                -
-- TYPE         : Script SQL                                                            -
-- DESCRIPTION  : Selection fraîcheur max/min/nombre/DB.TABLE ODS                       -
-----------------------------------------------------------------------------------------
--                 HISTORIQUE                                                           -
-- DATE            AUTEUR      CREATION/MODIFICATION                                    -
-- 00/00/00        XXX         Creation                                                 -
-- 10/01/14        AID         Modification mise ne norme DSM                           -
-----------------------------------------------------------------------------------------


.set width 250;


-- Selection fraîcheur max/min/nombre/DB.TABLE ODS de fichiers à traiter
SELECT
'export NBR_FRESH_TS="' || 
TRIM(CAST(NB AS VARCHAR(19))) ||'";'||
'export MIN_FRESH_TS="' || 
CAST(MIN_FRESH_TS AS VARCHAR(19)) ||'";'||
'export MAX_FRESH_TS="' || 
CAST(MAX_FRESH_TS AS VARCHAR(19)) ||'";'||
'export KNB_ODS_SOURCE_TABLE="' ||
CAST(SOURCE_TABLE AS VARCHAR(62)) ||'"'
(TITLE '')
FROM
(
  SELECT
    COUNT(FRESH_TS) AS NB,
    COALESCE(MIN(FRESH_TS),CAST('${KNB_PCO_DEFAULT_T0}' AS TIMESTAMP(0))) AS MIN_FRESH_TS,
    COALESCE(MAX(FRESH_TS),CAST('${KNB_PCO_DEFAULT_T0}' AS TIMESTAMP(0))) AS MAX_FRESH_TS,
    COALESCE(TRIM(MAX(TARGET_BASE_NM)||'.'||MAX(TARGET_TABLE_NM)),'-') AS SOURCE_TABLE 
  FROM
  ${KNB_PCO_TECH}.MET_W_COMPLETUDE_${FCT_PCO_SOURCE_CD}
  WHERE 
  (1=1)
  AND APPLI_SOURCE_CD = '${FCT_PCO_SOURCE_CD}'
  AND FILE_CD = '${FCT_PCO_FILE_CD}'
) W;

.if errorcode <> 0 then .quit 1



