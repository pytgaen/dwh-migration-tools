-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Miroir_Alimentation_ORD_T_ORDER_ERDV_OPER.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 24/12/2013      YZH         Creation
--------------------------------------------------------------------------------

.set width 2500;




--Insertion dans la table des opération programmées :

--TODO PAramétrage

Delete from ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_OPERATION all ;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_OPERATION
(
  EXTERNAL_ORDER_ID       ,
  ORDER_LINE_EXTERNAL_ID  ,
  TYPE_OP_NM              ,
  QUEUE_TS                ,
  RUN_ID                  ,
  STREAMING_TS            ,
  CREATION_TS             ,
  LAST_MODIF_TS           ,
  HOT_IN                  ,
  FRESH_IN                ,
  COHERENCE_IN
)
Select
  Oper.EXTERNAL_ORDER_ID                                 as EXTERNAL_ORDER_ID                     ,
  Oper.ORDER_LINE_EXTERNAL_ID                            as ORDER_LINE_EXTERNAL_ID                ,
  Oper.TYPE_OP_NM                                        as TYPE_OP_NM                            ,
  Oper.QUEUE_TS                                          as QUEUE_TS                              ,
  '${RUN_ID}'                                            as RUN_ID                                ,
  Oper.STREAMING_TS                                      as STREAMING_TS                          ,
  Current_Timestamp(0)                                   as CREATION_TS                           ,
  Null                                                   as LAST_MODIF_TS                         ,
  1                                                      as HOT_IN                                ,
  1                                                      as FRESH_IN                              ,
  0                                                      as COHERENCE_IN
From
  ${KNB_COM_TMP}.ORD_W_ORDER_ERDV_OPERATION Oper
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_COM_TMP}.ORD_T_ORDER_ERDV_OPERATION;
.if errorcode <> 0 then .quit 1


