-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Cold_Alimentation_INT_Step4_CalculPerennite.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de fusions des indicateurs de perennités
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013       GMA        Creation
-- 29/07/2014       HFO        Ajout indicateur suplémentaire pérennité
-- 04/03/2015       HFO         Ajout de type de resil (DOSSIER_TYPE_RESIL,DOSSIER_MOTIF_RESIL) pour stabilisation pérénnité
--------------------------------------------------------------------------------

.set width 2500;



----------------------------------------------------------------------------------------------
-- Etape 1 : On fusionne les données pour tester apres la pérénitée                       ----
----------------------------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_PRC all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_PRC
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  REALZTN_DT                  ,
  SEG_LIVR_DT                 ,
  CONTRCT_DT                  ,
  CANCELLNG_DT                ,
  SEG_RESIL_DT                ,
  SEG_COM_ID_LAST_PER         ,
  SEG_COM_ID_SOLD             ,
  SEG_COM_ID_FIND             ,
  SEG_FIND_LIVR_DT            ,
  SEG_FIND_CANCEL_DT          ,
  SEG_COM_ID_NEXT_PARC        ,
  SEG_NEXT_PARC_LIVR_DT       ,
  SEG_NEXT_PARC_CANCEL_DT     ,
  SEG_COM_ID_FINAL_PARC       ,
  SEG_FINAL_PARC_LIVR_DT      ,
  SEG_FINAL_PARC_CANCEL_DT    ,
  SEG_COM_ID_LAST_IN_PARC     ,
  NB_IN_OUT_PARC              ,
  POURCENTAGE_PRES_PARC       ,
  PERNNT_IN                   ,
  PERNNT_END_DT               ,
  PERNNT_MOTIF                ,
  SEG_COM_ID_FINAL_ORDER      ,
  SEG_FINAL_ORDER_DT          ,
  SEG_FINAL_ORDER_CANCEL_DT   ,
  DOSSIER_TYPE_RESIL          ,
  DOSSIER_MOTIF_RESIL         
)
Select
  Placement.ACTE_ID                                                                                       as ACTE_ID            ,
  Placement.INT_DEPOSIT_DT                                                                                as INT_DEPOSIT_DT     ,
  --Incidateur livraison
  ---------------------------------------------------------------------------------------------------------
  Placement.PARC_DT_DEBUT                                                                                 as REALZTN_DT         ,
  Case  --On prend celui trouver sur le Segement
        When PerSegOption.REALZTN_DT Is Not Null
          Then PerSegOption.REALZTN_DT
        When PerSegForfait.DEB_PERENNITE  Is Not Null
          Then PerSegForfait.DEB_PERENNITE
        Else Placement.PARC_DT_DEBUT
  End                                                                                                     as SEG_LIVR_DT        ,
  --------------------------------------------------------------------------------------------------------
  -- Indicateur de date contract
  Null                                                                                                    as CONTRCT_DT         ,
  --------------------------------------------------------------------------------------------------------
  -- Indicateur de date contract
  Placement.PARC_DT_FIN                                                                                   as CANCELLNG_DT       ,
  Case  --On prend celui trouver sur le Segement
        When PerSegOption.ACTE_ID Is Not Null
          Then  Case  When PerSegOption.CANCELLNG_DT = '29991231'
                        Then  Null
                      Else    PerSegOption.CANCELLNG_DT
                End
        When PerSegForfait.ACTE_ID Is Not Null
          Then  Case  When PerSegForfait.FIN_PERENNITE = '29991231'
                        Then  Null
                      Else    PerSegForfait.FIN_PERENNITE
                End
        Else Placement.PARC_DT_FIN
  End                                                                                                     as SEG_RESIL_DT      ,
  --On met le segment sur lequel il a été le dernier a etre calculer
  Case    When PerSegForfait.FIN_LAST_SEG Is Not Null
            Then PerSegForfait.FIN_LAST_SEG
          When PerSegOption.SEG_COM_ID    Is Not Null
            Then PerSegOption.SEG_COM_ID
          Else Null
  End                                                                                                     as SEG_COM_ID_LAST_PER      ,
  --------------------------------------------------------------------------------------------------------
  --Indicateur complémentaire à la pérennité
  --Segment Vendu
  Case    When PerSegForfait.SEG_COM_ID Is Not Null
            Then  PerSegForfait.SEG_COM_ID
          When PerSegOption.SEG_COM_ID    Is Not Null
            Then  PerSegOption.SEG_COM_ID
          Else Null
  End                                                                                                     as SEG_COM_ID_SOLD      ,
  --Segment trouvé en parc suite à la vente
  Case    When PerSegForfait.SEG_COM_ID_FIND Is Not Null
            Then PerSegForfait.SEG_COM_ID_FIND
          When PerSegOption.SEG_COM_ID    Is Not Null
            Then PerSegOption.SEG_COM_ID
          Else Null
  End                                                                                                     as SEG_COM_ID_FIND      ,
  --Date de livraison du Segment trouvé en parc suite à la vente
  Case    When PerSegForfait.REALZTN_DT Is Not Null
            Then PerSegForfait.REALZTN_DT
          When PerSegOption.REALZTN_DT    Is Not Null
            Then PerSegOption.REALZTN_DT
          Else Null
  End                                                                                                     as SEG_FIND_LIVR_DT      ,
  --Date de livraison du Segment trouvé en parc suite à la vente
  Case    When PerSegForfait.CANCELLNG_DT Is Not Null
            Then PerSegForfait.CANCELLNG_DT
          When PerSegOption.CANCELLNG_DT    Is Not Null
            Then PerSegOption.CANCELLNG_DT
          Else Null
  End                                                                                                     as SEG_FIND_CANCEL_DT   ,
  Case    When PerSegForfait.SEG_COM_ID_NEXT Is Not Null
            Then PerSegForfait.SEG_COM_ID_NEXT
          When PerSegOption.DATE_IN_PARC_NEXT  Is Not Null
            Then PerSegOption.SEG_COM_ID
          Else Null
  End                                                                                                     as SEG_COM_ID_NEXT_PARC   ,
  Case    When PerSegForfait.DATE_IN_PARC_NEXT Is Not Null
            Then PerSegForfait.DATE_IN_PARC_NEXT
          When PerSegOption.DATE_IN_PARC_NEXT  Is Not Null
            Then PerSegOption.DATE_IN_PARC_NEXT
          Else Null
  End                                                                                                     as SEG_NEXT_PARC_LIVR_DT  ,
  Case    When PerSegForfait.DATE_OUT_PARC_NEXT Is Not Null
            Then PerSegForfait.DATE_OUT_PARC_NEXT
          When PerSegOption.DATE_OUT_PARC_NEXT  Is Not Null
            Then PerSegOption.DATE_OUT_PARC_NEXT
          Else Null
  End                                                                                                     as SEG_NEXT_PARC_CANCEL_DT,
  Case  When PerSegForfait.DATE_IN_PARC_FINAL Is Not Null
          Then  PerSegForfait.FIN_LAST_SEG
        When PerSegOption.DATE_IN_PARC_FINAL Is Not Null
          Then  PerSegOption.SEG_COM_ID
        Else    Null
  End                                                                                                     as SEG_COM_ID_FINAL_PARC    ,
  Case  When PerSegForfait.DATE_IN_PARC_FINAL Is Not Null
          Then  PerSegForfait.DATE_IN_PARC_FINAL
        When PerSegOption.DATE_IN_PARC_FINAL Is Not Null
          Then  PerSegOption.DATE_IN_PARC_FINAL
        Else    Null
  End                                                                                                     as SEG_FINAL_PARC_LIVR_DT   ,
  Case  When PerSegForfait.DATE_OUT_PARC_FINAL Is Not Null
          Then  PerSegForfait.DATE_OUT_PARC_FINAL
        When PerSegOption.DATE_OUT_PARC_FINAL Is Not Null
          Then  PerSegOption.DATE_OUT_PARC_FINAL
        Else    Null
  End                                                                                                     as SEG_FINAL_PARC_CANCEL_DT ,
  Case  When PerSegForfait.FIN_PER_SEG  Is Not Null
          Then PerSegForfait.FIN_PER_SEG
        When PerSegOption.SEG_COM_ID    Is Not Null
          Then PerSegForfait.SEG_COM_ID
  End                                                                                                     as SEG_COM_ID_LAST_IN_PARC  ,
  Coalesce( PerSegForfait.NB_IN_OUT_PARC,
            PerSegOption.NB_IN_OUT_PARC
           )                                                                                              as NB_IN_OUT_PARC           ,
  Case  When  PerSegForfait.POURCENTAGE_PRES_PARC Is Not Null
          Then  Case  When  PerSegForfait.POURCENTAGE_PRES_PARC < 0
                            Or PerSegForfait.POURCENTAGE_PRES_PARC > 100
                        Then -1
                      Else PerSegForfait.POURCENTAGE_PRES_PARC
                End
        When  PerSegOption.POURCENTAGE_PRES_PARC Is Not Null
          Then  Case  When  PerSegOption.POURCENTAGE_PRES_PARC < 0
                            Or PerSegOption.POURCENTAGE_PRES_PARC > 100
                        Then -1
                      Else PerSegOption.POURCENTAGE_PRES_PARC
                End
        Else Null
  End                                                                                                       as POURCENTAGE_PRES_PARC            ,
  Coalesce(PerResil.PERNNT_IN,PerSefgForfaitAGENDE.PERNNT_IN,PerSefgOptionAGENDE.PERNNT_IN)                 as PERNNT_IN                        ,
  Coalesce(PerResil.PERNNT_END_DT,PerSefgForfaitAGENDE.PERNNT_END_DT,PerSefgOptionAGENDE.PERNNT_END_DT)     as PERNNT_END_DT                    ,
  Coalesce(PerResil.PERNNT_MOTIF,PerSefgForfaitAGENDE.PERNNT_MOTIF,PerSefgOptionAGENDE.PERNNT_MOTIF)        as PERNNT_MOTIF                     ,
  Coalesce(PerResil.SEG_COM_ID_FINAL_ORDER,PerSefgForfaitAGENDE.SEG_COM_ID_FINAL_ORDER)                     as SEG_COM_ID_FINAL_ORDER           ,
  Coalesce(PerSefgForfaitAGENDE.SEG_FINAL_ORDER_DT,PerSefgOptionAGENDE.SEG_FINAL_ORDER_DT)                  as SEG_FINAL_ORDER_DT               ,
  Coalesce(PerSefgForfaitAGENDE.SEG_FINAL_ORDER_CANCEL_DT,PerSefgOptionAGENDE.SEG_FINAL_ORDER_CANCEL_DT)    as SEG_FINAL_ORDER_CANCEL_DT        ,
  Placement.DOSSIER_TYPE_RESIL                                                                              as DOSSIER_TYPE_RESIL               ,
  Placement.DOSSIER_MOTIF_RESIL                                                                             as DOSSIER_MOTIF_RESIL               
  
From
  ${KNB_PCO_TMP}.INT_W_ACTE_CHO_EXRACT Placement
  Left Outer Join ${KNB_PCO_TMP}.INT_W_ACTE_CHO_SEG_SO_ACQ PerSegOption
    On    Placement.ACTE_ID           = PerSegOption.ACTE_ID
      And Placement.INT_DEPOSIT_DT    = PerSegOption.INT_DEPOSIT_DT
  Left Outer Join  ${KNB_PCO_TMP}.INT_W_ACTE_CHO_SEG_OT_ACQ PerSegForfait
    On    Placement.ACTE_ID           = PerSegForfait.ACTE_ID
      And Placement.INT_DEPOSIT_DT    = PerSegForfait.INT_DEPOSIT_DT
      And PerSegForfait.TYPE_ENRI     <>'N'
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_ACTCLI_OT PerSefgForfaitAGENDE
    On    Placement.ACTE_ID           = PerSefgForfaitAGENDE.ACTE_ID
      And Placement.INT_DEPOSIT_DT    = PerSefgForfaitAGENDE.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_ACTCLI_SO PerSefgOptionAGENDE
    On    Placement.ACTE_ID           = PerSefgOptionAGENDE.ACTE_ID
      And Placement.INT_DEPOSIT_DT    = PerSefgOptionAGENDE.INT_DEPOSIT_DT
  Left Outer Join   ${KNB_PCO_TMP}.INT_W_ACTE_CHO_CHECK_RESIL_PER PerResil
    On    Placement.ACTE_ID           = PerResil.ACTE_ID 
      And Placement.INT_DEPOSIT_DT    = PerResil.INT_DEPOSIT_DT

Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_PRC;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : On Lance le calcul
----------------------------------------------------------------------------------------------


Delete from ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_FULL all;
.if errorcode <> 0 then .quit 1


Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_FULL
(
  ACTE_ID                         ,
  INT_DEPOSIT_DT                  ,
  REALZTN_DT                      ,
  CONTRCT_DT                      ,
  CANCELLNG_DT                    ,
  PERENNITE_PVC_IN                ,
  PERENNITE_PVC_FIN_DT            ,
  PERENNITE_PVC_CALC_FIN_DT       ,
  SEG_COM_ID_LAST_PER             ,
  SEG_COM_ID_SOLD                 ,
  SEG_COM_ID_FIND                 ,
  SEG_FIND_LIVR_DT                ,
  SEG_FIND_CANCEL_DT              ,
  SEG_COM_ID_NEXT_PARC            ,
  SEG_NEXT_PARC_LIVR_DT           ,
  SEG_NEXT_PARC_CANCEL_DT         ,
  SEG_COM_ID_FINAL_PARC           ,
  SEG_FINAL_PARC_LIVR_DT          ,
  SEG_FINAL_PARC_CANCEL_DT        ,
  SEG_COM_ID_LAST_IN_PARC         ,
  NB_IN_OUT_PARC                  ,
  POURCENTAGE_PRES_PARC           ,
  PERNNT_IN                       ,
  PERNNT_END_DT                   ,
  PERNNT_MOTIF                    ,
  PERNNT_CALC_END_DT              ,
  SEG_COM_ID_FINAL_ORDER          ,
  SEG_FINAL_ORDER_DT              ,
  SEG_FINAL_ORDER_CANCEL_DT       
)
Select
  PrecalCalculTmp.ACTE_ID           as ACTE_ID              ,
  PrecalCalculTmp.INT_DEPOSIT_DT    as INT_DEPOSIT_DT       ,
  PrecalCalculTmp.REALZTN_DT        as REALZTN_DT           ,
  PrecalCalculTmp.CONTRCT_DT        as CONTRCT_DT           ,
  PrecalCalculTmp.CANCELLNG_DT      as CANCELLNG_DT         ,
  --------------------------------------------------------------------------------------------------------------------------
  -- Calcul de l'indicateur de Pérennité PVC
  --------------------------------------------------------------------------------------------------------------------------
  Case  When RefAct.PERENNITE_PVC_CALC_FIN_DT is not null  -- le calcul à déjà eu lieu pour cet ID
          Then RefAct.PERENNITE_PVC_IN  --Alors on remet la valeur précédement calculée
        Else  --Sinon on regarde si la parc n'est pas cloturé
          Case  When PrecalCalculTmp.DATE_LIVRAISON Is Null -- Si c'est une date fausse alors NC
                    Then 'NC'
                --Lorsque c'est null alors c'est perenne
                When PrecalCalculTmp.DATE_FIN_PARC Is Null
                    Then  'O'
                --Si la date de fin est Supérieur à 60 jours par rapport à la date de saisie
                When PrecalCalculTmp.DATE_FIN_PARC is not Null  And (PrecalCalculTmp.DATE_FIN_PARC - PrecalCalculTmp.INT_DEPOSIT_DT) >= 60
                    Then  'O'
                      
                Else      'N'
          End
  End                                                         as PERENNITE_PVC_IN         ,
  --Dans de Fin de présence en parc
  Case  When RefAct.PERENNITE_PVC_CALC_FIN_DT is not null  -- le calcul à déjà eu lieu pour cet ID
          Then RefAct.PERENNITE_PVC_FIN_DT  --Alors on remet la valeur précédement calculée
        Else  --Sinon on regarde si la parc n'est pas cloturé
          Case  When PrecalCalculTmp.DATE_FIN_PARC Is Null -- Si c'est une date fausse alors NC
                  Then Null
                When PrecalCalculTmp.DATE_FIN_PARC = Cast('00010101' as date format 'YYYYMMDD')
                  Then Null
                When PrecalCalculTmp.DATE_FIN_PARC is not Null --Si le parc est cloturé alors 
                    Then PrecalCalculTmp.DATE_FIN_PARC
                Else Null
          End
  End                                                         as PERENNITE_PVC_FIN_DT     ,
  --Dans de Fin de calcul de présence en parc
  Case  When RefAct.PERENNITE_PVC_CALC_FIN_DT Is Not Null --Si la commande n'est pas validée mais que le
            --Dernier calcul est valorisé (Cas > 200 jours on ne calcul plus)
            Then RefAct.PERENNITE_PVC_CALC_FIN_DT
        When (Cast(Current_date as  date format 'YYYYMMDD') - PrecalCalculTmp.INT_DEPOSIT_DT ) >= 60
            Then Cast(Current_date as  date format 'YYYYMMDD')
        Else Null
  End                                                         as PERENNITE_PVC_CALC_FIN_DT,
  PrecalCalculTmp.SEG_COM_ID_LAST_PER                         as SEG_COM_ID_LAST_PER      ,
  PrecalCalculTmp.SEG_COM_ID_SOLD                             as SEG_COM_ID_SOLD          ,
  PrecalCalculTmp.SEG_COM_ID_FIND                             as SEG_COM_ID_FIND          ,
  PrecalCalculTmp.SEG_FIND_LIVR_DT                            as SEG_FIND_LIVR_DT         ,
  PrecalCalculTmp.SEG_FIND_CANCEL_DT                          as SEG_FIND_CANCEL_DT       ,
  PrecalCalculTmp.SEG_COM_ID_NEXT_PARC                        as SEG_COM_ID_NEXT_PARC     ,
  PrecalCalculTmp.SEG_NEXT_PARC_LIVR_DT                       as SEG_NEXT_PARC_LIVR_DT    ,
  PrecalCalculTmp.SEG_NEXT_PARC_CANCEL_DT                     as SEG_NEXT_PARC_CANCEL_DT  ,
  PrecalCalculTmp.SEG_COM_ID_FINAL_PARC                       as SEG_COM_ID_FINAL_PARC    ,
  PrecalCalculTmp.SEG_FINAL_PARC_LIVR_DT                      as SEG_FINAL_PARC_LIVR_DT   ,
  PrecalCalculTmp.SEG_FINAL_PARC_CANCEL_DT                    as SEG_FINAL_PARC_CANCEL_DT ,
  PrecalCalculTmp.SEG_COM_ID_LAST_IN_PARC                     as SEG_COM_ID_LAST_IN_PARC  ,
  PrecalCalculTmp.NB_IN_OUT_PARC                              as NB_IN_OUT_PARC           ,
  PrecalCalculTmp.POURCENTAGE_PRES_PARC                       as POURCENTAGE_PRES_PARC    ,
  ---------------------------------------------------------------------------------------------------------------------
  --Calcul des indicateurs Perennité Avec date action clients
  Case  When RefAct.PERNNT_CALC_END_DT is not null  -- le calcul à déjà eu lieu pour cet ID
          Then RefAct.PERNNT_IN  --Alors on remet la valeur précédement calculée
        Else  --Sinon on regarde si la parc n'est pas cloturé
          Case  When PrecalCalculTmp.DOSSIER_TYPE_RESIL='CHAPP'
                    Then 'O'
                When PrecalCalculTmp.PERNNT_IN = 'N' --Alors on a retrouvé une date action sur le client
                    Then  'N'
                --Lorsque c'est null alors c'est perenne
                When (PrecalCalculTmp.DATE_FIN_PARC Is Null Or PrecalCalculTmp.DATE_FIN_PARC = Cast('00010101' as date format 'YYYYMMDD'))
                    Then  'O'
                --Si la date de fin est Supérieur à 60 jours par rapport à la date de saisie
                When PrecalCalculTmp.DATE_FIN_PARC is not Null  And (PrecalCalculTmp.DATE_FIN_PARC - PrecalCalculTmp.INT_DEPOSIT_DT) >= 60
                    Then  'O'
                Else      'N'
          End
  End                                                         as PERNNT_IN                ,
  Case  When RefAct.PERNNT_CALC_END_DT is not null  -- le calcul à déjà eu lieu pour cet ID
          Then RefAct.PERNNT_END_DT  --Alors on remet la valeur précédement calculée
        Else  --Sinon on regarde si la parc n'est pas cloturé
          Case  When PrecalCalculTmp.DOSSIER_TYPE_RESIL='CHAPP'
                    Then Null
                When PrecalCalculTmp.PERNNT_IN = 'N' --Alors on a retrouvé une date action sur le client
                    Then  PrecalCalculTmp.PERNNT_END_DT
                When PrecalCalculTmp.DATE_FIN_PARC Is Null -- Si c'est une date fausse alors NC
                  Then Null
                When PrecalCalculTmp.DATE_FIN_PARC = Cast('00010101' as date format 'YYYYMMDD')
                  Then Null
                When PrecalCalculTmp.DATE_FIN_PARC is not Null  And (PrecalCalculTmp.DATE_FIN_PARC - PrecalCalculTmp.INT_DEPOSIT_DT) >= 60 --Si le parc est cloturé alors 
                    Then Null
                Else PrecalCalculTmp.DATE_FIN_PARC
          End
  End                                                         as PERNNT_END_DT           ,
  --Calcul du motif Non perennité
  Case  When RefAct.PERNNT_CALC_END_DT is not null  -- le calcul à déjà eu lieu pour cet ID
          Then RefAct.PERNNT_MOTIF  --Alors on remet la valeur précédement calculée
        Else  --Sinon on regarde si la parc n'est pas cloturé
          Case  When PrecalCalculTmp.DOSSIER_TYPE_RESIL='CHAPP'
                    Then Null
                 When PrecalCalculTmp.PERNNT_IN = 'N' --Alors on a retrouvé une date action sur le client
                    Then  PrecalCalculTmp.PERNNT_MOTIF
                When PrecalCalculTmp.DATE_FIN_PARC Is Null -- Si c'est une date fausse alors NC
                  Then Null
                When PrecalCalculTmp.DATE_FIN_PARC = Cast('00010101' as date format 'YYYYMMDD')
                  Then Null
                When PrecalCalculTmp.DATE_FIN_PARC is not Null  And (PrecalCalculTmp.DATE_FIN_PARC - PrecalCalculTmp.INT_DEPOSIT_DT) >= 60 --Si le parc est cloturé alors 
                  Then Null
                Else  Case  When PrecalCalculTmp.SEG_COM_ID_SOLD=PrecalCalculTmp.SEG_COM_ID_LAST_PER
                              Then  'Résiliation'
                            Else    'Migration'
                      End
          End
  End                                                         as PERNNT_MOTIF           ,
  --Dans de Fin de calcul de présence en parc
  Case  When RefAct.PERNNT_CALC_END_DT Is Not Null --Si la commande n'est pas validée mais que le
            --Dernier calcul est valorisé (Cas > 200 jours on ne calcul plus)
            Then RefAct.PERNNT_CALC_END_DT
        When (Cast(Current_date as  date format 'YYYYMMDD') - PrecalCalculTmp.INT_DEPOSIT_DT ) >= 60
            Then Cast(Current_date as  date format 'YYYYMMDD')
        Else Null
  End                                                         as PERNNT_CALC_END_DT       ,
  PrecalCalculTmp.SEG_COM_ID_FINAL_ORDER                      as SEG_COM_ID_FINAL_ORDER   ,
  PrecalCalculTmp.SEG_FINAL_ORDER_DT                          as SEG_FINAL_ORDER_DT       ,
  PrecalCalculTmp.SEG_FINAL_ORDER_CANCEL_DT                   as SEG_FINAL_ORDER_CANCEL_DT
From
  (
    Select
      RefId.ACTE_ID                   as ACTE_ID              ,
      RefId.INT_DEPOSIT_DT            as INT_DEPOSIT_DT       ,
      RefId.CONTRCT_DT                as CONTRCT_DT           ,
      RefId.CANCELLNG_DT              as CANCELLNG_DT         ,
      ---------------------------------------------------------------------------------------------------------------------------
      --Calcul de la date Livraison
      ---------------------------------------------------------------------------------------------------------------------------
      Case
            -- Si la date de début est valorisée et est valide et est >= La date de dépot -1
            --Cas de la livraison sur le Produit
            When    (RefId.REALZTN_DT Is Not Null And RefId.REALZTN_DT >= (RefId.INT_DEPOSIT_DT - 1))
              Then  RefId.REALZTN_DT
            --Case de la livraison sur le segment :
            When    (RefId.SEG_LIVR_DT Is Not Null)
              Then  RefId.SEG_LIVR_DT
            When    (RefId.REALZTN_DT Is Not Null)
              Then  Cast('00010101' as date format 'YYYYMMDD')
            Else
                    Null
      End                                               as DATE_LIVRAISON    ,
      ---------------------------------------------------------------------------------------------------------------------------
      --Calcul de la date de Fin Parc 
      ---------------------------------------------------------------------------------------------------------------------------
      Case  -- Si la date de début de parc est valorisée et est valide et est >= La date de dépot -1 => Recherche de la fin de parc
            --S'il y a pérénnité sur le segment alors on garde
            When    (RefId.SEG_LIVR_DT Is Not Null)
              Then  RefId.SEG_RESIL_DT
            When    (RefId.REALZTN_DT Is Not Null And RefId.REALZTN_DT >= (RefId.INT_DEPOSIT_DT - 1))
              Then  RefId.CANCELLNG_DT
            When    (RefId.REALZTN_DT Is Not Null)
              Then  Cast('00010101' as date format 'YYYYMMDD')
            Else
                    Null
      End                                               as DATE_FIN_PARC            ,
      RefId.REALZTN_DT                                  as REALZTN_DT               ,
      RefId.SEG_COM_ID_LAST_PER                         as SEG_COM_ID_LAST_PER      ,
      RefId.SEG_COM_ID_SOLD                             as SEG_COM_ID_SOLD          ,
      RefId.SEG_COM_ID_FIND                             as SEG_COM_ID_FIND          ,
      RefId.SEG_FIND_LIVR_DT                            as SEG_FIND_LIVR_DT         ,
      RefId.SEG_FIND_CANCEL_DT                          as SEG_FIND_CANCEL_DT       ,
      RefId.SEG_COM_ID_NEXT_PARC                        as SEG_COM_ID_NEXT_PARC     ,
      RefId.SEG_NEXT_PARC_LIVR_DT                       as SEG_NEXT_PARC_LIVR_DT    ,
      RefId.SEG_NEXT_PARC_CANCEL_DT                     as SEG_NEXT_PARC_CANCEL_DT  ,
      RefId.SEG_COM_ID_FINAL_PARC                       as SEG_COM_ID_FINAL_PARC    ,
      RefId.SEG_FINAL_PARC_LIVR_DT                      as SEG_FINAL_PARC_LIVR_DT   ,
      RefId.SEG_FINAL_PARC_CANCEL_DT                    as SEG_FINAL_PARC_CANCEL_DT ,
      RefId.SEG_COM_ID_LAST_IN_PARC                     as SEG_COM_ID_LAST_IN_PARC  ,
      RefId.NB_IN_OUT_PARC                              as NB_IN_OUT_PARC           ,
      RefId.POURCENTAGE_PRES_PARC                       as POURCENTAGE_PRES_PARC    ,
      RefId.PERNNT_IN                                   as PERNNT_IN                ,
      RefId.PERNNT_END_DT                               as PERNNT_END_DT            ,
      RefId.PERNNT_MOTIF                                as PERNNT_MOTIF             ,
      RefId.SEG_COM_ID_FINAL_ORDER                      as SEG_COM_ID_FINAL_ORDER   ,
      RefId.SEG_FINAL_ORDER_DT                          as SEG_FINAL_ORDER_DT       ,
      RefId.SEG_FINAL_ORDER_CANCEL_DT                   as SEG_FINAL_ORDER_CANCEL_DT,
      RefId.DOSSIER_TYPE_RESIL                          as DOSSIER_TYPE_RESIL       ,
      RefId.DOSSIER_MOTIF_RESIL                         as DOSSIER_MOTIF_RESIL        
      
    From
      ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_PRC RefId
  )PrecalCalculTmp
  Left Outer Join ${KNB_PCO_VM}.V_INT_F_ACTE_CHO  RefAct
    On    PrecalCalculTmp.ACTE_ID           = RefAct.ACTE_ID
      And PrecalCalculTmp.INT_DEPOSIT_DT    = RefAct.INT_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_CHO_PER_FULL;
.if errorcode <> 0 then .quit 1


.quit 0




