-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SOFT_Acte_Hot_Alimentation_INT_Step2_CalculActe.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  de calcul  acte (migration ) SOFT Internet à Chaud
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
-- 03/06/2016      MDE         Modif / REFCOM KNB_PCO_REFCOM 
--------------------------------------------------------------------------------


.set width 2500;



-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.${ReferentielPrefix}ACT_T_CALC_ACTE_SOFT
-- **************************************************************
Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL All;
.if errorcode <> 0 then .quit 1

---------------------------------------
----- partie migration = 1
---------------------------------------

Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL
(
  ACTE_ID                                   ,
  EXTERNAL_ORDER_ID                         ,
  ORDER_DEPOSIT_DT                          ,
  OSCAR_VALUE_NU                            ,
  PERIODE_ID                                ,
  PRODUCT_ID_PRE                            ,
  SEG_COM_ID_PRE                            ,
  SEG_COM_AGG_ID_PRE                        ,
  CODE_MIGR_PRE                             ,
  TYPE_MVT_PRE                              ,
  PRODUCT_ID_FINAL                          ,
  SEG_COM_ID_FINAL                          ,
  SEG_COM_AGG_ID_FINAL                      ,
  CODE_MIGR_FINAL                           ,
  TYPE_SERVICE_FINAL                        ,
  TYPE_MVT_FINAL                            ,
  TYPE_COMMANDE_ID                          ,
  DELTA_TARIF                               ,
  ACTE_ID_FUS                               ,
  PRODUCT_DS_PRE                            
)
Select
  ActeCreation.ACTE_ID                                                        as ACTE_ID                    ,
  ActeCreation.EXTERNAL_ORDER_ID                                              as EXTERNAL_ORDER_ID          ,
  ActeCreation.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT           ,
  ActeCreation.OSCAR_VALUE_NU                                                 as OSCAR_VALUE_NU             ,
  ActeCreation.PERIODE_ID                                                     as PERIODE_ID                 ,
  ActeDelete.PRODUCT_ID                                                       as PRODUCT_ID_PRE             ,
  --On ne valorise le produit précédant que lorsqu'on a détecter une migration :
  Case  When ActeDelete.EXTERNAL_ORDER_ID Is Not Null
          Then ActeDelete.SEG_COM_ID
        Else Null
  End                                                                         as SEG_COM_ID_PRE             ,
  --On ne valorise le produit précédant que lorsqu'on a détecter une migration :
  Case  When ActeDelete.EXTERNAL_ORDER_ID Is Not Null
          Then ActeDelete.SEG_COM_AGG_ID
        Else Null
  End                                                                         as SEG_COM_AGG_ID_PRE         ,
  ActeDelete.CODE_MIGRATION                                                   as CODE_MIGR_PRE              ,
  ActeDelete.EXT_OPER_ID                                                      as TYPE_MVT_PRE               ,
  ActeCreation.PRODUCT_ID                                                     as PRODUCT_ID_FINAL           ,
  ActeCreation.SEG_COM_ID                                                     as SEG_COM_ID_FINAL           ,
  ActeCreation.SEG_COM_AGG_ID                                                 as SEG_COM_AGG_ID_FINAL       ,
  ActeCreation.CODE_MIGRATION                                                 as CODE_MIGR_FINAL            ,
  ActeCreation.TYPE_SERVICE                                                   as TYPE_SERVICE_FINAL         ,
  ActeCreation.EXT_OPER_ID                                                    as TYPE_MVT_FINAL             ,
  --Calcul Du Type de commande
  Case  When  (ActeDelete.EXTERNAL_ORDER_ID is null And ActeCreation.EXT_OPER_ID = '${P_PIL_005}')
          Then '${P_PIL_026}'
        When  (ActeDelete.EXTERNAL_ORDER_ID is null And ActeCreation.EXT_OPER_ID = '${P_PIL_008}')
          Then '${P_PIL_027}'
        When (  --Cas des maintient RTC :
                  --Le cas des non migrations
                  ActeDelete.EXTERNAL_ORDER_ID Is Null
                  -- Il faut un maintient :
                  And ActeCreation.EXT_OPER_ID                    = '${P_PIL_007}'
                  --Et un access RTC
                  And ActeCreation.TYPE_SERVICE                   In ('ACCRTC')
                  --Et un type de déménagement
                  And ActeCreation.ACTE_OPERTR_ID_COMPST_OFFR     = '${P_PIL_249}'
              )
          Then 'DMAINT'
        When  (ActeDelete.EXTERNAL_ORDER_ID is null And ActeCreation.EXT_OPER_ID = '${P_PIL_007}')
          Then '${P_PIL_028}'
        When  (   --Il faut un motif de commande à déménagement
                      ActeCreation.ACTE_OPERTR_ID_COMPST_OFFR     = '${P_PIL_249}' 
                  --Que le code Suffix soit non null
                  And MatMig.SUFFIXE_TYPE_CDE                     Is Not Null
                  --Que ça soit une migration iso offre
                  And ActeCreation.SEG_COM_ID                     = ActeDelete.SEG_COM_ID
              )
          Then Trim(MatMig.SUFFIXE_TYPE_CDE)||Trim(MatMig.TYPE_COMMANDE_ID)
        Else  Coalesce(MatMig.TYPE_COMMANDE_ID,'MEF')
  End                                                                         as TYPE_COMMANDE_ID           ,
  (Coalesce(ActeCreation.TARIF_HT,0) - Coalesce(ActeDelete.TARIF_HT,0))       as DELTA_TARIF                ,
  --On purge les Ids des lignes dont on a fait la migration
  Case  When ActeDelete.EXT_OPER_ID = 'RMV'
          Then ActeDelete.ACTE_ID
        Else
          Null
  End                                                                         as ACTE_ID_FUS                ,
  Null                                                                        as PRODUCT_DS_PRE             
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_ELI ActeCreation
  --Jointure sur la matrice de migration suivant le produit final + le mouvement Final
  Left Outer Join  ${KNB_PCO_REFCOM}.V_CAT_R_MAT_MIGR_PILCOM MatMig
    On ActeCreation.CODE_MIGRATION        = MatMig.CODE_MIGRATION_FINAL
      And ActeCreation.EXT_OPER_ID        = MatMig.MOUVEMENT_FINAL
      And ActeCreation.PERIODE_ID         = MatMig.PERIODE_ID
      And MatMig.CURRENT_IN               = 1
      And MatMig.CLOSURE_DT               is null 
   --Jointure sur la matrice de migration suivant le produit Ini + le mouvement Ini
  Left Outer Join ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_ELI ActeDelete
    On MatMig.CODE_MIGRATION_INITIAL      = ActeDelete.CODE_MIGRATION
      And ActeDelete.EXT_OPER_ID          = MatMig.MOUVEMENT_INITIAL
      And ActeCreation.EXTERNAL_ORDER_ID  = ActeDelete.EXTERNAL_ORDER_ID
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE=${P_PIL_019}
Qualify Row_Number() Over (Partition by ActeCreation.ACTE_ID order by ActeDelete.CODE_MIGRATION desc)=1

-----------------------------------------------------------------------------------------------------
--On réalise le calcul pour les produits non migrable
-----------------------------------------------------------------------------------------------------
;Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL
(
  ACTE_ID                                   ,
  EXTERNAL_ORDER_ID                         ,
  ORDER_DEPOSIT_DT                          ,
  OSCAR_VALUE_NU                            ,
  PERIODE_ID                                ,
  PRODUCT_ID_PRE                            ,
  SEG_COM_ID_PRE                            ,
  SEG_COM_AGG_ID_PRE                        ,
  CODE_MIGR_PRE                             ,
  TYPE_MVT_PRE                              ,
  PRODUCT_ID_FINAL                          ,
  SEG_COM_ID_FINAL                          ,
  SEG_COM_AGG_ID_FINAL                      ,
  CODE_MIGR_FINAL                           ,
  TYPE_SERVICE_FINAL                        ,
  TYPE_MVT_FINAL                            ,
  TYPE_COMMANDE_ID                          ,
  DELTA_TARIF                               ,
  ACTE_ID_FUS                               ,
  PRODUCT_DS_PRE                            
)
Select
  ActeCreation.ACTE_ID                                                        as ACTE_ID                    ,
  ActeCreation.EXTERNAL_ORDER_ID                                              as EXTERNAL_ORDER_ID          ,
  ActeCreation.ORDER_DEPOSIT_DT                                               as ORDER_DEPOSIT_DT           ,
  ActeCreation.OSCAR_VALUE_NU                                                 as OSCAR_VALUE_NU             ,
  ActeCreation.PERIODE_ID                                                     as PERIODE_ID                 ,
  Null                                                                        as PRODUCT_ID_PRE             ,
  Null                                                                        as SEG_COM_ID_PRE             ,
  Null                                                                        as SEG_COM_AGG_ID_PRE         ,
  Null                                                                        as CODE_MIGR_PRE              ,
  Null                                                                        as TYPE_MVT_PRE               ,
  ActeCreation.PRODUCT_ID                                                     as PRODUCT_ID_FINAL           ,
  ActeCreation.SEG_COM_ID                                                     as SEG_COM_ID_FINAL           ,
  ActeCreation.SEG_COM_AGG_ID                                                 as SEG_COM_AGG_ID_FINAL       ,
  ActeCreation.CODE_MIGRATION                                                 as CODE_MIGR_FINAL            ,
  ActeCreation.TYPE_SERVICE                                                   as TYPE_SERVICE_FINAL         ,
  ActeCreation.EXT_OPER_ID                                                    as TYPE_MVT_FINAL             ,
  --Calcul Du Type de commande
  Case  When ActeCreation.EXT_OPER_ID = '${P_PIL_005}'
          Then '${P_PIL_016}'
        When ActeCreation.EXT_OPER_ID = '${P_PIL_008}'
          Then '${P_PIL_017}'
        --Cas des maintient
        When (  --Cas des maintient RTC :
                  -- Il faut un maintient :
                  ActeCreation.EXT_OPER_ID                        = '${P_PIL_007}'
                  --Et un access RTC
                  And ActeCreation.TYPE_SERVICE                   in ('ACCRTC')
                  --Et un type de déménagement
                  And ActeCreation.ACTE_OPERTR_ID_COMPST_OFFR     = '${P_PIL_249}'
              )
            Then 'DMAINT'
        When ActeCreation.EXT_OPER_ID = '${P_PIL_007}'
          Then '${P_PIL_018}'
  End                                                                         as TYPE_COMMANDE_ID           ,
  (Coalesce(ActeCreation.TARIF_HT,0))                                         as DELTA_TARIF                ,
  Null                                                                        as ACTE_ID_FUS                ,
  Null                                                                        as PRODUCT_DS_PRE             
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_PRECAL_ELI ActeCreation
Where
  (1=1)
  And ActeCreation.MIGRATION_POSSIBLE=${P_PIL_020}
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------------------------------------------------
--On purge les Ids Dont on a migré :
------------------------------------------------------------------------------------------------------------------
Delete
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL RefId
Where
  (1=1)
  And Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL RefSup
    Where
      (1=1)
      And RefId.ACTE_ID   = RefSup.ACTE_ID_FUS
  )
;
.if errorcode <> 0 then .quit 1



Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------------------------------------------------------
-- On rejoute le libellé du produit précédant 
------------------------------------------------------------------------------------------------------------------
Update RefId
From
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_INT_CAL    RefId       ,
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SOFT_INT   Placement   
Set
  PRODUCT_DS_PRE    = Case  When  Placement.TYPE_PRODUCT = 'OC'
                              Then Placement.COMPST_OFFR_DS
                            When  Placement.TYPE_PRODUCT = 'OA'
                              Then Coalesce(Placement.COMPST_OFFR_DS,'')||' - '||Coalesce(Placement.ATOMIC_OFFR_DS,'')
                            When  Placement.TYPE_PRODUCT = 'FVF'
                              Then Coalesce(Placement.COMPST_OFFR_DS,'')||' - '||Coalesce(Placement.ATOMIC_OFFR_DS,'')||' - '||Coalesce(Placement.FUNCTN_DS,'')||' - '||Coalesce(Placement.FUNCTN_VALUE_DS,'')
                      End
Where
  (1=1)
  And RefId.ACTE_ID_FUS =Placement.ACTE_ID
;
.if errorcode <> 0 then .quit 1


.quit 0
