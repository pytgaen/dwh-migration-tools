 --$HEADER: %HEADER%
----------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_REFCOM_Check_Step2_ProduitPrestationFixe.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de vérifications des produits EAN
----------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 20/11/2015     GMA         Création
----------------------------------------------------------------------------------

.set width 5000



-- Vérification des EAN BeStar
Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     
)
Select
  1                                                             As REJECT_TYPE_ID         ,
  'EBP'                                                         As SOURCE_ID              ,
  'FIX'                                                         As CATALOG_ID             ,
  'Produit Externe manquant ; ( PRESTA-FIX ) ; ( '
        ||Trim(Placement.EXT_PRODUCT_ID)
        ||' )'                                                  As ERROR_CD               ,
  Case  When Placement.EXT_PRODUCT_DS  Is  Null
          Then 'Aucune Information trouvée dans Kenobi'
        Else
          'Libellé Produit : '
          ||Trim(Coalesce(Placement.EXT_PRODUCT_DS,''))
  End                                                         As INFO_CD                ,
  Placement.VolumeCas                                         As VOLUME_NB              ,
  Placement.DateMinRecue                                      As MIN_RECEIVED_DT        ,
  Placement.DateMaxRecue                                      As MAX_RECEIVED_DT        
From
  (
    Select
      Placement.OFFRE_OPT_ACQ                   As EXT_PRODUCT_ID     ,
      Null                                      As EXT_PRODUCT_DS     ,
      Count(*)                                  As VolumeCas          ,
      Min(Placement.ORD_DEPOSIT_DT)             As DateMinRecue       ,
      Max(Placement.ORD_DEPOSIT_DT)             As DateMaxRecue       
    From
      ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_EBP Placement
    Where
      (1=1)
      And Placement.OFFRE_OPT_ACQ          Is Not Null
      And Placement.ORD_TYPE_NM             = 'O'
      And Placement.ORD_DEPOSIT_DT          >= Current_date -30
    Group by
      EXT_PRODUCT_ID    ,
      EXT_PRODUCT_DS    
  ) Placement
  Left Outer Join ${KNB_PCO_REFCOM}.V_CAT_R_REF_PRODUCT_PRF Catalogue
    On  Placement.EXT_PRODUCT_ID        = Catalogue.EXT_PRODUCT_ID
    And Catalogue.CURRENT_IN            = 1
    And Catalogue.CLOSURE_DT            Is Null
    And Catalogue.PERIODE_ID            =(Select Max(PERIODE_ID) From ${KNB_PCO_REFCOM}.V_CAT_R_PERIODE_COM_PILCOM Where CURRENT_IN=1 And FRESH_IN=1 And CLOSURE_DT is null)
Where
  (1=1)
  And Catalogue.EXT_PRODUCT_ID          Is Null
;
.if errorcode <> 0 Then .quit 1






-----------------------------------------------------------------------------------------------------------------
-- On Bascule les données dans la table finale :
-----------------------------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS
(
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  CREATION_TS         ,
  LAST_MODIF_TS       ,
  FRESH_IN            ,
  COHERENCE_IN        
)
Select
  REJECT_TYPE_ID      ,
  SOURCE_ID           ,
  CATALOG_ID          ,
  ERROR_CD            ,
  INFO_CD             ,
  VOLUME_NB           ,
  MIN_RECEIVED_DT     ,
  MAX_RECEIVED_DT     ,
  Current_Timestamp(0),
  Current_Timestamp(0),
  1                   ,
  1                   
From
  ${KNB_PCO_TMP}.FLW_T_REFCOM_LOGS_TMP
;
.if errorcode <> 0 Then .quit 1





.quit 0
