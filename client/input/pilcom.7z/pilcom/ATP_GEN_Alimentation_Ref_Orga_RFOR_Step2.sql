-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:    ATP_GEN_Alimentation_Ref_Orga_RFOR_Step2.sql $  
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE    
--
-- DATE            AUTEUR       CREATION/MODIFICATION
-- 22/05/2014      HZO          Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORG_T_AGENT_LNK_EDO Where SOURCE = 'RFOR';
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORG_T_AGENT_LNK_EDO(
  SOURCE                    ,
  CUID                      ,
  NOM                       ,
  PRENOM                    ,
  DT_DEBUT                  ,
  DT_FIN                    ,
  RAT_ORGA_EQUI_CO_GRP      ,
  EDO_ID_EQUI_RAT           ,
  FLAG_SCH_EQUI_RAT         ,
  FLAG_HIER_EQUI_RAT        ,
  FLAG_PLT_CONV_EQUI_RAT    ,
  TRAV_ORGA_EQUI_CO_GRP     ,
  EDO_ID_EQUI_TRAV          ,
  FLAG_SCH_EQUI_TRAV        ,
  FLAG_HIER_EQUI_TRAV       ,
  FLAG_PLT_CONV_EQUI_TRAV   
)
Select
  RFOR.SOURCE                                                   as SOURCE                           ,
  RFOR.CUID                                                     as CUID                             ,
  RFOR.NOM                                                      as NOM                              ,
  RFOR.PRENOM                                                   as PRENOM                           ,
  RFOR.DT_DEBUT                                                 as DT_DEBUT                         ,
  RFOR.DT_FIN                                                   as DT_FIN                           ,
  RFOR.RAT_ORGA_EQUI_CO_GRP                                     as RAT_ORGA_EQUI_CO_GRP             ,
  RFOR.EDO_ID_EQUI_RAT                                          as EDO_ID_EQUI_RAT                  ,
  RAT.FLAG_SCH_EQUI_RAT                                         as FLAG_SCH_EQUI_RAT                ,
  RAT.FLAG_EDO_RAT                                              as FLAG_HIER_EQUI_RAT               ,
  RAT.FLAG_PLT_CONV_RAT                                         as FLAG_PLT_CONV_EQUI_RAT           ,
  RFOR.TRAV_ORGA_EQUI_CO_GRP                                    as TRAV_ORGA_EQUI_CO_GRP            ,
  RFOR.EDO_ID_EQUI_TRAV                                         as EDO_ID_EQUI_TRAV                 ,
  TRAV.FLAG_SCH_EQUI_TRAV                                       as FLAG_SCH_EQUI_TRAV               ,
  TRAV.FLAG_EDO_TRAV                                            as FLAG_HIER_EQUI_TRAV              ,
  TRAV.FLAG_PLT_CONV_TRAV                                       as FLAG_PLT_CONV_EQUI_TRAV          
From 
  ${KNB_PCO_TMP}.ORG_W_AGENT_LNK_EDO_RFOR RFOR
    --Enrichissement Orga Equipe de Rattachement
    Left Outer Join ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_RAT_RFOR as RAT
      On    RFOR.CUID             = RAT.UPPER_ID_FT
        And RFOR.DT_DEBUT         = RAT.CSLORGA_DT_DEB
    --Enrichissement Orga Equipe de Travail
    Left Outer Join ${KNB_PCO_TMP}.ORG_W_AGENT_ORG_EQUI_TRA_RFOR as TRAV
      On    RFOR.CUID             = TRAV.UPPER_ID_FT
        And RFOR.DT_DEBUT         = TRAV.CSLORGA_DT_DEB
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORG_T_AGENT_LNK_EDO;
.if errorcode <> 0 then .quit 1
