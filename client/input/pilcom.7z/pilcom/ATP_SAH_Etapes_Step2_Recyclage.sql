--$HEADER: %HEADER%
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : ATP_SAH_Etapes_Step2_Recyclage.sql
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de recyclage des Etapes SAVI (MDV)
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 26/05/2020      EVI         Creation
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Recyclage des Etapes SAVI  (Eviter la perte d'information)                   ----
----------------------------------------------------------------------------------------------

Merge Into  ${KNB_PCO_TMP}.ORD_W_ETP_SAVI_EXT Tmp
Using
( Select 
    Soc.DOSSIER_SAV_CD     As     DOSSIER_SAV_CD  , 
    Soc.ETP_CD             As     ETP_CD          ,
    Soc.ETP_TS             As     ETP_TS          ,
    Soc.ETP_EDO_ID         As     ETP_EDO_ID      
  From ${KNB_PCO_SOC}.V_ORD_F_ETP_SAVI Soc
  Where 
  (1=1)
    ) SocEtp
On           Tmp.DOSSIER_SAV_CD  = SocEtp.DOSSIER_SAV_CD
        And  Tmp.ETP_CD          = SocEtp.ETP_CD
        And  Tmp.ETP_TS          = SocEtp.ETP_TS

-- Si ça matche on met à jour :
When matched then
Update set 
    ETP_EDO_ID   = SocEtp.ETP_EDO_ID    
;
.if errorcode <> 0 then .quit 1

Collect Stat On  ${KNB_PCO_TMP}.ORD_W_ETP_SAVI_EXT;
.if errorcode <> 0 then .quit 1                    

                  
