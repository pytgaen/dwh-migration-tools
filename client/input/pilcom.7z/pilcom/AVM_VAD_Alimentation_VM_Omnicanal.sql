--$HEADER:   mm2pco/current/sql/AVM_VAD_Alimentation_VM_Omnicanal.sql 13_05#2 26-SEP-2018 10:31:42 GXPZ7694
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_VAD_Alimentation_VM_Omnicanal.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL de Alimentation de la VM Omnicanalité 
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 31/08/2018      HOB        Création
-- 24/09/2018      HOB        Moodif Unified
--------------------------------------------------------------------------------

.set width 5000


Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_OMNCNL;
.if errorcode <> 0 then .quit 1;

-- Identification Croisement 

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_OMNCNL
(   
     CODE_PROCESS                   ,
     ACTE_ID                       ,
     ACT_DT                        ,
     INTRCTN_DT                    ,
     DELAI_DT                      ,
     INTRCTN_ID                    ,
     KEYGEN_CD                     ,
     APPLI_SOURCE_ID               ,
     UNIFIED_PARTY_ID              ,
     PID_ID                        ,
     INT_OPRTR_ID                  ,
     OPRTR_TEAM_HIERCH_ID          ,
     OPRTR_TEAM_ACTVT_ID           ,
     UNVRS_CD                      ,
     DIRCTN_CD                     ,
     CHANL_CD                      ,
     MEDIA_CD                      ,
     ORIGN_CD                      ,
     WAY_CD                        ,
     REASN_CD                      ,
     REASN_DETL_CD                 ,
     CONCLSN_CD                    ,
     ORG_REM_CHANNEL_CD            ,
     ORG_CHANNEL_CD                ,
     ORG_SUB_CHANNEL_CD            ,
     ORG_SUB_SUB_CHANNEL_CD        ,
     ORG_GT_ACTIVITY               ,
     ORG_FIDELISATION              ,
     ORG_WEB_ACTIVITY              ,
     ORG_AUTO_ACTIVITY             ,
     ORG_EDO_ID                    ,
     ORG_TEAM_TYPE_ID              ,
     UNIFIED_SHOP_CD               ,
     ORG_TEAM_LEVEL_1_CD           ,
     ORG_TEAM_LEVEL_1_DS           ,
     ORG_TEAM_LEVEL_2_CD           ,
     ORG_TEAM_LEVEL_2_DS           ,
     ORG_TEAM_LEVEL_3_CD           ,
     ORG_TEAM_LEVEL_3_DS           ,
     ORG_TEAM_LEVEL_4_CD           ,
     ORG_TEAM_LEVEL_4_DS           ,
     WORK_TEAM_LEVEL_1_CD          ,
     WORK_TEAM_LEVEL_1_DS          ,
     WORK_TEAM_LEVEL_2_CD          ,
     WORK_TEAM_LEVEL_2_DS          ,
     WORK_TEAM_LEVEL_3_CD          ,
     WORK_TEAM_LEVEL_3_DS          ,
     WORK_TEAM_LEVEL_4_CD          ,
     WORK_TEAM_LEVEL_4_DS          ,
     NEW_ORG_REM_CHANNEL_CD        ,
     NEW_ORG_CHANNEL_CD            ,
     NEW_ORG_SUB_CHANNEL_CD        ,
     NEW_ORG_SUB_SUB_CHANNEL_CD    ,
     NEW_ORG_GT_ACTIVITY           ,
     NEW_ORG_FIDELISATION          ,
     NEW_ORG_WEB_ACTIVITY          ,
     NEW_ORG_AUTO_ACTIVITY         ,
     NEW_ORG_EDO_ID                ,
     NEW_ORG_TEAM_TYPE_ID          ,
     NEW_UNIFIED_SHOP_CD           ,
     NEW_ORG_TEAM_LEVEL_1_CD       ,
     NEW_ORG_TEAM_LEVEL_1_DS       ,
     NEW_ORG_TEAM_LEVEL_2_CD       ,
     NEW_ORG_TEAM_LEVEL_2_DS       ,
     NEW_ORG_TEAM_LEVEL_3_CD       ,
     NEW_ORG_TEAM_LEVEL_3_DS       ,
     NEW_ORG_TEAM_LEVEL_4_CD       ,
     NEW_ORG_TEAM_LEVEL_4_DS       ,
     NEW_WORK_TEAM_LEVEL_1_CD      ,
     NEW_WORK_TEAM_LEVEL_1_DS      ,
     NEW_WORK_TEAM_LEVEL_2_CD      ,
     NEW_WORK_TEAM_LEVEL_2_DS      ,
     NEW_WORK_TEAM_LEVEL_3_CD      ,
     NEW_WORK_TEAM_LEVEL_3_DS      ,
     NEW_WORK_TEAM_LEVEL_4_CD      ,
     NEW_WORK_TEAM_LEVEL_4_DS      ,
     CREATION_TS                   ,
     LAST_MODIF_TS                 ,
     FRESH_IN                      ,
     COHERENCE_IN
)
Select 
    'Omnicanal'                           ,
     InfDig.ACTE_ID                       ,
     InfDig.ACT_DT                        ,
     JRC.INTRCTN_DT                       ,
     InfDig.DELAI_DT                      ,
     JRC.INTRCTN_ID                       ,
     JRC.KEYGEN_CD                        ,
     JRC.APPLI_SOURCE_ID                  ,
     JRC.UNIFIED_PARTY_ID                 ,
     JRC.PID_ID                           ,
     JRC.INT_OPRTR_ID                     ,
     JRC.OPRTR_TEAM_HIERCH_ID             ,
     JRC.OPRTR_TEAM_ACTVT_ID              ,
     JRC.UNVRS_CD                         ,
     JRC.DIRCTN_CD                        ,
     JRC.CHANL_CD                         ,
     JRC.MEDIA_CD                         ,
     JRC.ORIGN_CD                         ,
     JRC.WAY_CD                           ,
     JRC.REASN_CD                         ,
     JRC.REASN_DETL_CD                    ,
     JRC.CONCLSN_CD                       ,
     InfDig.ORG_REM_CHANNEL_CD            ,
     InfDig.ORG_CHANNEL_CD                ,
     InfDig.ORG_SUB_CHANNEL_CD            ,
     InfDig.ORG_SUB_SUB_CHANNEL_CD        ,
     InfDig.ORG_GT_ACTIVITY               ,
     InfDig.ORG_FIDELISATION              ,
     InfDig.ORG_WEB_ACTIVITY              ,
     InfDig.ORG_AUTO_ACTIVITY             ,
     InfDig.ORG_EDO_ID                    ,
     InfDig.ORG_TYPE_EDO                  ,
     InfDig.UNIFIED_SHOP_CD               ,
     Trim(InfDig.ORG_TEAM_LEVEL_1_CD )    ,
     InfDig.ORG_TEAM_LEVEL_1_DS           ,
     Trim(InfDig.ORG_TEAM_LEVEL_2_CD )    ,
     InfDig.ORG_TEAM_LEVEL_2_DS           ,
     Trim(InfDig.ORG_TEAM_LEVEL_3_CD)     ,
     InfDig.ORG_TEAM_LEVEL_3_DS           ,
     Trim(InfDig.ORG_TEAM_LEVEL_4_CD)     ,
     InfDig.ORG_TEAM_LEVEL_4_DS           ,
     Trim(InfDig.WORK_TEAM_LEVEL_1_CD )   ,
     InfDig.WORK_TEAM_LEVEL_1_DS          ,
     Trim(InfDig.WORK_TEAM_LEVEL_2_CD)    ,
     InfDig.WORK_TEAM_LEVEL_2_DS          ,
     Trim(InfDig.WORK_TEAM_LEVEL_3_CD )    ,
     InfDig.WORK_TEAM_LEVEL_3_DS          ,
     Trim(InfDig.WORK_TEAM_LEVEL_4_CD )    ,
     InfDig.WORK_TEAM_LEVEL_4_DS          ,
     JRC.ORG_REM_CHANNEL_CD               ,
     JRC.ORG_CHANNEL_CD                   ,
     JRC.ORG_SUB_CHANNEL_CD               ,
     JRC.ORG_SUB_SUB_CHANNEL_CD           ,
     JRC.ORG_GT_ACTIVITY                  ,
     JRC.ORG_FIDELISATION                 ,
     JRC.ORG_WEB_ACTIVITY                 ,
     JRC.ORG_AUTO_ACTIVITY                ,
     JRC.ORG_EDO_ID                       ,
     JRC.ORG_TEAM_TYPE_ID                 ,
     JRC.UNIFIED_SHOP_CD                  ,
     Trim(JRC.ORG_TEAM_LEVEL_1_CD  )      ,
     JRC.ORG_TEAM_LEVEL_1_DS              ,
     Trim(JRC.ORG_TEAM_LEVEL_2_CD )       ,
     JRC.ORG_TEAM_LEVEL_2_DS              ,
     Trim(JRC.ORG_TEAM_LEVEL_3_CD)        ,
     JRC.ORG_TEAM_LEVEL_3_DS              ,
     Trim(JRC.ORG_TEAM_LEVEL_4_CD)        ,
     JRC.ORG_TEAM_LEVEL_4_DS              ,
     Trim(JRC.WORK_TEAM_LEVEL_1_CD)       ,
     JRC.WORK_TEAM_LEVEL_1_DS             ,
     Trim(JRC.WORK_TEAM_LEVEL_2_CD)       ,
     JRC.WORK_TEAM_LEVEL_2_DS             ,
     Trim(JRC.WORK_TEAM_LEVEL_3_CD )      ,
     JRC.WORK_TEAM_LEVEL_3_DS             ,
     Trim(JRC.WORK_TEAM_LEVEL_4_CD)       ,
     JRC.WORK_TEAM_LEVEL_4_DS             ,
     CREATION_TS                          ,
     LAST_MODIF_TS                        ,
     FRESH_IN                             ,
     COHERENCE_IN
From 
( ---Récupération des infos des actes digitaux dans la table de actes en se basant sur la tables croisement) 
  Select
    Acte_Omnicanal.MASTER_ACTE_ID                                                             As ACTE_ID                ,
    Acte_Omnicanal.SLAVE_ACTE_ID                                                              As ACTE_ID_INTRCTN        ,
    Acte_Omnicanal.MASTER_ACT_DT                                                              As ACT_DT                 ,
    Acte_Omnicanal.SLAVE_ACT_DT                                                               As ACT_DT_INTRCTN         ,
    Acte_Omnicanal.OFFSET                                                                     As DELAI_DT               ,
    Actes.ORG_CHANNEL_CD                                                                      As ORG_CHANNEL_CD         ,
    Actes.ORG_SUB_CHANNEL_CD                                                                  As ORG_SUB_CHANNEL_CD     ,
    Actes.ORG_SUB_SUB_CHANNEL_CD                                                              As ORG_SUB_SUB_CHANNEL_CD ,
    Actes.ORG_REM_CHANNEL_CD                                                                  As ORG_REM_CHANNEL_CD     ,
    Actes.ORG_GT_ACTIVITY                                                                     As ORG_GT_ACTIVITY        ,
    Actes.ORG_FIDELISATION                                                                    As ORG_FIDELISATION       ,
    Actes.ORG_AUTO_ACTIVITY                                                                   As ORG_AUTO_ACTIVITY      ,
    Actes.ORG_WEB_ACTIVITY                                                                    As ORG_WEB_ACTIVITY       ,
    Actes.ORG_EDO_ID                                                                          As ORG_EDO_ID             ,
    Actes.ORG_TYPE_EDO                                                                        As ORG_TYPE_EDO           ,
    Actes.ORG_STORE_NAME                                                                      As UNIFIED_SHOP_CD        ,
    Actes.ORG_TEAM_LEVEL_1_CD                                                                 As ORG_TEAM_LEVEL_1_CD    ,
    Actes.ORG_TEAM_LEVEL_1_DS                                                                 As ORG_TEAM_LEVEL_1_DS    ,
    Actes.ORG_TEAM_LEVEL_2_CD                                                                 As ORG_TEAM_LEVEL_2_CD    ,
    Actes.ORG_TEAM_LEVEL_2_DS                                                                 As ORG_TEAM_LEVEL_2_DS    ,
    Actes.ORG_TEAM_LEVEL_3_CD                                                                 As ORG_TEAM_LEVEL_3_CD    ,
    Actes.ORG_TEAM_LEVEL_3_DS                                                                 As ORG_TEAM_LEVEL_3_DS    ,
    Actes.ORG_TEAM_LEVEL_4_CD                                                                 As ORG_TEAM_LEVEL_4_CD    ,
    Actes.ORG_TEAM_LEVEL_4_DS                                                                 As ORG_TEAM_LEVEL_4_DS    ,
    Actes.WORK_TEAM_LEVEL_1_CD                                                                As WORK_TEAM_LEVEL_1_CD   ,
    Actes.WORK_TEAM_LEVEL_1_DS                                                                As WORK_TEAM_LEVEL_1_DS   ,
    Actes.WORK_TEAM_LEVEL_2_CD                                                                As WORK_TEAM_LEVEL_2_CD   ,
    Actes.WORK_TEAM_LEVEL_2_DS                                                                As WORK_TEAM_LEVEL_2_DS   ,
    Actes.WORK_TEAM_LEVEL_3_CD                                                                As WORK_TEAM_LEVEL_3_CD   ,
    Actes.WORK_TEAM_LEVEL_3_DS                                                                As WORK_TEAM_LEVEL_3_DS   ,
    Actes.WORK_TEAM_LEVEL_4_CD                                                                As WORK_TEAM_LEVEL_4_CD   ,
    Actes.WORK_TEAM_LEVEL_4_DS                                                                As WORK_TEAM_LEVEL_4_DS
  From ${KNB_PCO_TMP}.ORD_W_ACTE_CROSS_${Source}_JRC Acte_Omnicanal
  Inner join ${KNB_PCO_VM}.${TableSource} Actes
    On  Acte_Omnicanal.MASTER_ACTE_ID           =  Actes.ACTE_ID
    And Acte_Omnicanal.MASTER_ACT_DT            =  Actes.ORDER_DEPOSIT_DT
    And Acte_Omnicanal.ORG_WEB_ACTIVITY = 'omnicanal'
  Where
   (1=1)
   )InfDig
   Inner Join ${KNB_PCO_SOC}.V_INT_F_PLACEMENT_JRC  JRC
     On    JRC.ACTE_ID      = InfDig.ACTE_ID_INTRCTN      
     And   JRC.INTRCTN_DT   = InfDig.ACT_DT_INTRCTN          
   ;

.if errorcode <> 0 then .quit 1;
Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_OMNCNL;
.if errorcode <> 0 then .quit 1;

.quit 0

