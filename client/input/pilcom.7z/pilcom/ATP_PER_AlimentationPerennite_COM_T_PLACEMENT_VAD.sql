--$HEADER: mm2pco/current/sql/ATP_PER_AlimentationPerennite_COM_T_PLACEMENT_VAD.sql 13_05#30 26-JUN-2019 11:44:28 NNGS2043
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:  ATP_PER_AlimentationPerennite_COM_T_PLACEMENT_VAD.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script d'Alimentation de la table ${KNB_PCO_TMP}.COM_T_TFINDICOM_CHO
--
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 29/07/2011     MHA         Création
-- 06/02/2014     AID         Indus
-- 22/09/2014     HZO         Modification : Perform
-- 11/01/2016     OCH         Ajout du EDO WEBPART
-- 13/01/2016     MDE         Evol: Calcul CA -ajout TARIF_HT
-- 24/03/2016     OCH         Ajout Msosh
-- 16/01/2017     HOB         Ajout Ventes Associes
-- 22/11/2017     MEL         Ajout indicateur IOBSP
-- 05/10/2018     LMU         Ajout champs VAD Mobile (RS lot 2)
-- 15/02/2019     SSI         Alimentation Champs ORG_AGENT_IOBSP  
-- 06/05/2019     TCL         Correction nom du champ AGENT_IOBSP_LEVEL_CD => AGENT_IOBSP_LEVEL_ID
-- 04/06/2020     TCL         Developpement de l'US 443 sur le calcul du DEPARTMNT_ID
-- 17/06/2020     TCL         Ajout du champ NSCE pour les KPI ESIM
-- 21/10/2020     ITA         PILCOM_737 : Decommissionnement enrichissement VAD par webpartner 6PO

.set width 2000;


-- **************************************************************
-- Alimentation de la table ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD
-- **************************************************************
  

--Delete des lignes
Delete From ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD All;
.if errorcode <> 0 then .quit 1


--------------------------------------------------------------------------------------------
-- Etape 1 : On regarde le statut du dossier dans ADV :
--------------------------------------------------------------------------------------------

--On regarde le statut du dossier
Create Volatile Table ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER (
  ACTE_ID               Bigint                  Not null  ,
  CDE_REFERENCE         Varchar(20)             Not null  ,
  DOSSIER_NU            Char(10)                Not null  ,
  DOSSIER_NU_PREC_PORTE Char(10)                          ,
  CLIENT_NU             Char(10)                Not null  ,
  DATE_SAISIE           Date Format 'YYYYMMDD'  Not null  ,
  DATE_ACTIV_DOS        Date Format 'YYYYMMDD'            ,
  DATE_RESIL_DOS        Date Format 'YYYYMMDD'            ,
  CO_RESILDOS           Varchar(5)                        
)
Primary Index (
  CDE_REFERENCE
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1





--Confirmation PostPaid
Insert into ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER
(
  ACTE_ID               ,
  CDE_REFERENCE         ,
  DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE ,
  CLIENT_NU             ,
  DATE_SAISIE           ,
  DATE_ACTIV_DOS        ,
  DATE_RESIL_DOS        ,
  CO_RESILDOS           
)
Select
  Vad.ACTE_ID                                                               as ACTE_ID                ,
  Vad.CDE_REFERENCE                                                         as CDE_REFERENCE          ,
  Vad.DOSSIER_NU                                                            as DOSSIER_NU             ,
  Vad.DOSSIER_NU_PREC_PORTE                                                 as DOSSIER_NU_PREC_PORTE  ,
  Vad.CLIENT_NU                                                             as CLIENT_NU              ,
  Vad.DATE_SAISIE                                                           as DATE_SAISIE            ,
  DossierCli.DOSSIER_DT_CREAT                                               as DATE_ACTIV_DOS         ,
  Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
          --Si le dossier est clotur? alors on prend la date de r?sil
          Then Coalesce(DossierCli.DOSSIER_DT_RESIL,DossierCli.DOSSIER_DT_DER_CHGT)
        Else
          --Sinon on prend rien
          Null
  End                                                                       as DATE_RESIL_DOS         ,
  Case  When   DossierCli.DOSSIER_CO_STD in (60,70,90)
          --Si le dossier est clotur? alors on prend la date de r?sil
          Then DossierCli.DOSSIER_CO_RESILDOS
        Else
          --Sinon on prend rien
          Null
  End                                                                       as CO_RESILDOS            
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Vad
  left Outer Join ${KNB_IBU_SOC_V}.VF_TDDOSSIER DossierCli
    On    Vad.DOSSIER_NU        =   DossierCli.DOSSIER_NU
      And Vad.CLIENT_NU         =   DossierCli.DOSSIER_CLIENT_NU
Where
  (1=1)
  And Vad.TYPE_LIG_CDE    in ('OT')
  And Vad.TYPPROD_CO      in ('POSTPAID')
  And Vad.DOSSIER_NU      Is Not Null
  And Vad.CLIENT_NU       Is Not Null
;
.if errorcode <> 0 then .quit 1


--Dans le cas des resiliations Pour cause de migration de Num?ro On recherche le nouveau num?ro

--On regarde le statut du dossier
Create Volatile Table ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER_PORTA (
  ACTE_ID               Bigint                  Not null  ,
  CDE_REFERENCE         Varchar(20)             Not null  ,
  DOSSIER_NU            Char(10)                Not null  ,
  DOSSIER_NU_PREC_PORTE Char(10)                          ,
  CLIENT_NU             Char(10)                Not null  ,
  DATE_SAISIE           Date Format 'YYYYMMDD'  Not null  ,
  DATE_ACTIV_DOS        Date Format 'YYYYMMDD'            ,
  DATE_RESIL_DOS        Date Format 'YYYYMMDD'            ,
  CO_RESILDOS           Varchar(5)                        
)
Primary Index (
  CDE_REFERENCE
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1



Insert into ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER_PORTA
(
  ACTE_ID               ,
  CDE_REFERENCE         ,
  DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE ,
  CLIENT_NU             ,
  DATE_SAISIE           ,
  DATE_ACTIV_DOS        ,
  DATE_RESIL_DOS        ,
  CO_RESILDOS           
)
Select
  RefDossier.ACTE_ID              as ACTE_ID                ,
  RefDossier.CDE_REFERENCE        as CDE_REFERENCE          ,
  -- Si l'on trouve un dossier actif alors on rattache le client ? son nouveau dossier
  DossierCli.DOSSIER_NU           as DOSSIER_NU             ,
  -- On passe l'ancien dossier dans le num?ro port?
  RefDossier.DOSSIER_NU           as DOSSIER_NU_PREC_PORTE  ,
  RefDossier.CLIENT_NU            as CLIENT_NU              ,
  RefDossier.DATE_SAISIE          as DATE_SAISIE            ,
  RefDossier.DATE_ACTIV_DOS       as DATE_ACTIV_DOS         ,
  Null                            as DATE_RESIL_DOS         ,
  Null                            as CO_RESILDOS            
From
  ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER RefDossier
  Inner Join ${KNB_IBU_SOC_V}.VF_TDDOSSIER DossierCli
    On    RefDossier.CLIENT_NU      = DossierCli.DOSSIER_CLIENT_NU
      And RefDossier.DATE_ACTIV_DOS = DossierCli.DOSSIER_DT_CREAT
      And DossierCli.DOSSIER_CO_STD Not in (60,70,90,99999)
Where
  (1=1)
  And RefDossier.DATE_RESIL_DOS Is Not Null
  And RefDossier.CO_RESILDOS ='CHAPP'
QUALIFY ROW_NUMBER() OVER (PARTITION BY DossierCli.DOSSIER_CLIENT_NU ORDER BY DOSSIER_DT_DER_CHGT DESC) = 1
;
.if errorcode <> 0 then .quit 1


-- On met a jour la table avec les nouvelles informations Sur le dossier 
-- avant le calcul des ?l?ments de parc :
Update TblTmpFull
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER  TblTmpFull  ,
  ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER  Dossier     
Set
  DOSSIER_NU            = Dossier.DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE = Dossier.DOSSIER_NU_PREC_PORTE ,
  DOSSIER_DT_CREAT      = Dossier.DATE_ACTIV_DOS        ,
  DOSSIER_DT_RESIL      = Dossier.DATE_RESIL_DOS        
Where
    -- Ajout de la jointure avec l'acte_id
    TblTmpFull.CDE_REFERENCE=Dossier.CDE_REFERENCE
;
.if errorcode <> 0 then .quit 1


Update TblTmpFull
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER        TblTmpFull  ,
  ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER_PORTA  Dossier    
Set
  DOSSIER_NU            = Dossier.DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE = Dossier.DOSSIER_NU_PREC_PORTE ,
  DOSSIER_DT_CREAT      = Dossier.DATE_ACTIV_DOS        ,
  DOSSIER_DT_RESIL      = Dossier.DATE_RESIL_DOS        
Where 
    TblTmpFull.CDE_REFERENCE=Dossier.CDE_REFERENCE
;
.if errorcode <> 0 then .quit 1

Drop table ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER;
.if errorcode <> 0 then .quit 1

Drop table ${KNB_TERADATA_USER}.VAD_PER_VAL_DOSSIER_PORTA;
.if errorcode <> 0 then .quit 1


------------------------------------------------------------------------------------------
-- Creation des tables Tmp du parc :

Create Volatile Table ${KNB_TERADATA_USER}.VAD_PER_PARC (
  ACTE_ID             Bigint                  Not null  ,
  DOSSIER_NU          Char(10)                Not null  ,
  CLIENT_NU           Char(10)                Not null  ,
  DATE_SAISIE         Date Format 'YYYYMMDD'  Not null  ,
  PRESFACT_CO         Char(5)                           ,
  SRVFCDOS_DT_DEBUT   Date Format 'YYYYMMDD'            ,
  SRVFCDOS_DT_FIN     Date Format 'YYYYMMDD'            
)
Primary Index (
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1


--Dans d'activation dans sachem
Create Volatile Table ${KNB_TERADATA_USER}.VAD_PER_VAL_SACHEM (
  ACTE_ID             Bigint                  Not null  ,
  DOSSIER_NU          Char(10)                Not null  ,
  CLIENT_NU           Char(10)                Not null  ,
  DATE_SAISIE         Date Format 'YYYYMMDD'  Not null  ,
  DATE_ACTIV_SACHEM   Date Format 'YYYYMMDD'            ,
  DATE_RESIL_SACHEM   Date Format 'YYYYMMDD'            
)
Primary Index (
  ACTE_ID
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1




--Pour la recherche en parc :
Insert into ${KNB_TERADATA_USER}.VAD_PER_PARC
(
  ACTE_ID             ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  DATE_SAISIE         ,
  PRESFACT_CO         ,
  SRVFCDOS_DT_DEBUT   ,
  SRVFCDOS_DT_FIN     
)
Select
  Requete.ACTE_ID                                                                       as ACTE_ID            ,
  Requete.DOSSIER_NU                                                                    as DOSSIER_NU         ,
  Requete.CLIENT_NU                                                                     as CLIENT_NU          ,
  Requete.DATE_SAISIE                                                                   as DATE_SAISIE        ,
  Requete.PRESFACT_CO_COM                                                               as PRESFACT_CO_COM    ,
  Requete.SRVFCDOS_DT_DEBUT                                                             as SRVFCDOS_DT_DEBUT  ,
  Case When Requete.SRVFCDOS_DT_FIN=cast('29991231' as Date Format 'YYYYMMDD') Then null
    Else Requete.SRVFCDOS_DT_FIN
  End                                                                                   as SRVFCDOS_DT_FIN     
From
  (
    Select
      Vad.ACTE_ID                                                                         as ACTE_ID          ,
      Vad.DOSSIER_NU                                                                      as DOSSIER_NU       ,
      Vad.CLIENT_NU                                                                       as CLIENT_NU        ,
      Vad.DATE_SAISIE                                                                     as DATE_SAISIE      ,
      Vad.PRESFACT_CO_COM                                                                 as PRESFACT_CO_COM  ,
      Min(ParcADV.SRVFCDOS_DT_DEBUT)                                                      as SRVFCDOS_DT_DEBUT,
      Max(coalesce(ParcADV.SRVFCDOS_DT_FIN,cast('29991231' as date format 'YYYYMMDD')))   as SRVFCDOS_DT_FIN  
    From
      ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Vad
      Inner Join ${KNB_IBU_SOC_V}.VF_TFSRVFCDOS ParcADV
        On    Vad.DOSSIER_NU      = ParcADV.SRVFCDOS_DOSSIER_NU
          And Vad.CLIENT_NU       = ParcADV.SRVFCDOS_CLIENT_NU
          And Vad.PRESFACT_CO_COM = ParcADV.SRVFCDOS_PRESFACT_CO
          And (Vad.DATE_SAISIE - Interval '1' Day) <= ParcADV.SRVFCDOS_DT_DEBUT
          And ParcADV.CLOSURE_DT is null
    Where
      (1=1)
      And Vad.TYPE_LIG_CDE in ('OT','SO')
      And Vad.PRESFACT_CO_COM is not null
      And Vad.TYPPROD_CO in ('POSTPAID')
    Group by
      Vad.ACTE_ID             ,
      Vad.DOSSIER_NU          ,
      Vad.CLIENT_NU           ,
      Vad.DATE_SAISIE         ,
      Vad.PRESFACT_CO_COM     
  )Requete
--Confirmation Prepaid
;Insert into ${KNB_TERADATA_USER}.VAD_PER_VAL_SACHEM
(
  ACTE_ID             ,
  DOSSIER_NU          ,
  CLIENT_NU           ,
  DATE_SAISIE         ,
  DATE_ACTIV_SACHEM   ,
  DATE_RESIL_SACHEM   
)
Select
  Vad.ACTE_ID                                   as ACTE_ID          ,
  Vad.DOSSIER_NU                                as DOSSIER_NU       ,
  Vad.CLIENT_NU                                 as CLIENT_NU        ,
  Vad.DATE_SAISIE                               as DATE_SAISIE      ,
  DossierCli.DATE_ACTV_DOSS                     as DATE_ACTIV_SACHEM,
  Case  When DossierCli.IDNT_ETAT_PRNC in (4,5,6,7,8,9,10)
          Then DossierCli.DATE_CHNG_ETAT
        Else
          Null
  End                                           as DATE_RESIL_SACHEM
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Vad
  Inner Join ${KNB_DFRA_SOC_V}.V_DOSSIER DossierCli
    On    Cast(Vad.DOSSIER_NU as Integer)   =   DossierCli.NUMR_MSIS_COUR
      And Cast(Vad.CLIENT_NU  as Integer)   =   DossierCli.NUMR_DOSS_ADV
      And DossierCli.DATE_SUPP_LOGQ is null
Where
  (1=1)
  And Vad.TYPE_LIG_CDE    in ('OT')
  And Vad.TYPPROD_CO      in ('PREPAID')
;
.if errorcode <> 0 then .quit 1


Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD
(
  ACTE_ID               ,
  APPLI_SOURCE_ID       ,
  CDE_REFERENCE         ,
  DATE_SAISIE           ,
  DATE_SAISIE_TS        ,
  DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE ,
  CLIENT_NU             ,
  PAR_IMSI              ,
  PAR_MOB_SIM           ,
  DOSSIER_DT_CREAT      ,
  DOSSIER_DT_RESIL      ,
  DOSSIER_DATE_RESIL    ,
  DOSSIER_TYPE_RESIL    ,
  DOSSIER_MOTIF_RESIL   ,
  PRESFACT_CO_COM       ,
  PARC_DT_DEBUT         ,
  PARC_DT_FIN           ,
  PRESFACT_CO_PREC      ,
  USCM_CO               ,
  CANALDIST             ,
  PDV                   ,
  STATUT_CDE            ,
  DUREE_ENGAGEMENT      ,
  TYPE_DUR_ENGAGEMENT   ,
  TYPE_LIG_CDE          ,
  CDE_LIG_ID            ,
  EXT_PRODUCT_ID        ,
  PRIX_HT               ,
  DATEVALIDATION        ,
  DATE_DECLA_SACHEM     ,
  DATE_LIVRAISON        ,
  NUMEROIMEI            ,
  CODEVENDEUR           ,
  EAN_FTT               ,
  CODE_TAC              ,
  CODEVENDEUR_MOD       ,
  STATUT_CLOS           ,
  STATUT_ANNUL          ,
  AID                   ,
  ND                    ,
  BCR_ID                ,
  TYPPROD_CO            ,
  CONTRCT_DT_SIGN_PREC  ,
  CONTRCT_DT_FIN_PREC   ,
  CONTRCT_DT_SIGN_POST  ,
  CONTRCT_DUREE_ENG     ,
  CONTRCT_UNIT_ENG      ,
  EDO_ID                ,
  FLAG_PLT_CONV         ,
  FLAG_PLT_SCH          ,
  FLAG_TEAM_MKT         ,
  FLAG_TYPE_CMP         ,
  TYPE_EDO              ,
  ORG_REF_TRAV          ,
  TERM_PERFORM_IND      ,
  ORG_AGENT_ID          ,
  ORG_POC_XI            ,
  ORG_NOM               ,
  ORG_PRENOM            ,
  ORG_ACTVT_REEL        ,
  ORG_GROUPE_ID         ,
  ORG_POC_XI_RESP       ,
  ORG_AGENT_RESP_ID     ,
  DMC_LINE_ID           ,
  DMC_MASTER_LINE_ID    ,
  DMC_LINE_TYPE         , -- RCS
  RCS_MOTIV_INVC_CD     , -- RCS
  RCS_ENR_ACTE_ID       , -- RCS
  PAR_DEPARTMNT_ID      ,
  PAR_BU_CD             ,
  PAR_CID_ID            ,
  PAR_PID_ID            ,
  PAR_FIRST_IN          ,
  ORG_AGENT_IOBSP       ,
  ORG_EDO_IOBSP         ,
  PAR_POSTAL_CD         ,
  PAR_INSEE_CD          ,
  PAR_GEO_MACROZONE     ,
  PAR_UNIFIED_PARTY_ID  ,
  PAR_PARTY_REGRPMNT_ID ,
  PAR_IRIS2000_CD       ,
  PAR_FIBER_IN          ,
 -- WEB_PARTNER_CD        ,PILCOM_737
  REDIRECTION_CD        ,
  PAR_LASTNAME          ,
  PAR_FIRSTNAME         ,
  PAR_TYPE              ,
  PAR_EMAIL             ,
  PAR_BILL_ADRESS_1     ,
  PAR_BILL_ADRESS_2     ,
  PAR_BILL_ADRESS_3     ,
  PAR_BILL_ADRESS_4     ,
  PAR_BILL_VILLE        ,
  PAR_BILL_CD_POSTAL    ,
  PAR_DO                ,
  PAR_SCORE_NU          ,
  PAR_SCORE_IN          ,
  PAR_TRESHOLD_NU       ,
  TARIF_HT              ,
  RCS_IN                , -- RCS
  RCS_MOTIF_ID          , -- RCS
  RCS_CODE_ADV_MOTIF    , -- RCS
  CLOSURE_DT            ,
  CREATION_TS           ,
  LAST_MODIF_TS         ,
  FRESH_IN              ,
  COHERENCE_IN          
)
Select
  Vad.ACTE_ID                                                         as ACTE_ID              ,
  Vad.APPLI_SOURCE_ID                                                 as APPLI_SOURCE_ID      ,
  Vad.CDE_REFERENCE                                                   as CDE_REFERENCE        ,
  Vad.DATE_SAISIE                                                     as DATE_SAISIE          ,
  Vad.DATE_SAISIE_TS                                                  as DATE_SAISIE_TS       ,
  Vad.DOSSIER_NU                                                      as DOSSIER_NU           ,
  Vad.DOSSIER_NU_PREC_PORTE                                           as DOSSIER_NU_PREC_PORTE,
  Vad.CLIENT_NU                                                       as CLIENT_NU            ,
  Coalesce(NumImsi.PAR_IMSI,Vad.PAR_IMSI)                             as PAR_IMSI             ,
  Vad.PAR_MOB_SIM                                                     as PAR_MOB_SIM          ,
  Coalesce(Sachem.DATE_ACTIV_SACHEM,Vad.DOSSIER_DT_CREAT)             as DOSSIER_DT_CREAT     ,
  Coalesce(Sachem.DATE_RESIL_SACHEM,Vad.DOSSIER_DT_RESIL)             as DOSSIER_DT_RESIL     ,
  Coalesce(ResDosImsi.DATE_RESIL_DOS,Vad.DOSSIER_DATE_RESIL)          as DOSSIER_DATE_RESIL   ,
  Coalesce(ResDosImsi.CO_RESILDOS,Vad.DOSSIER_TYPE_RESIL)             as DOSSIER_TYPE_RESIL   ,
  Coalesce(ResDosImsi.DOSSIER_MOTIF_RESIL,Vad.DOSSIER_MOTIF_RESIL)    as DOSSIER_MOTIF_RESIL  ,
  Vad.PRESFACT_CO_COM                                                 as PRESFACT_CO_COM      ,
  Coalesce(Parc.SRVFCDOS_DT_DEBUT,Vad.PARC_DT_DEBUT)                  as PARC_DT_DEBUT        ,
  Parc.SRVFCDOS_DT_FIN                                                as PARC_DT_FIN          ,
  Vad.PRESFACT_CO_PREC                                                as PRESFACT_CO_PREC     ,
  Vad.USCM_CO                                                         as USCM_CO              ,
  NULL                                                                as CANALDIST            ,
  Vad.PDV                                                             as PDV                  ,
  Vad.STATUT_CDE                                                      as STATUT_CDE           ,
  Vad.DUREE_ENGAGEMENT                                                as DUREE_ENGAGEMENT     ,
  Vad.TYPE_DUR_ENGAGEMENT                                             as TYPE_DUR_ENGAGEMENT  ,
  Vad.TYPE_LIG_CDE                                                    as TYPE_LIG_CDE         ,
  Vad.CDE_LIG_ID                                                      as CDE_LIG_ID           ,
  Vad.EXT_PRODUCT_ID                                                  as EXT_PRODUCT_ID       ,
  Vad.PRIX_HT                                                         as PRIX_HT              ,
  Vad.DATEVALIDATION                                                  as DATEVALIDATION       ,
  Vad.DATE_DECLA_SACHEM                                               as DATE_DECLA_SACHEM    ,
  Vad.DATE_LIVRAISON                                                  as DATE_LIVRAISON       ,
  Vad.NUMEROIMEI                                                      as NUMEROIMEI           ,
  Vad.CODEVENDEUR                                                     as CODEVENDEUR          ,
  Vad.EAN_FTT                                                         as EAN_FTT              ,
  Vad.CODE_TAC                                                        as CODE_TAC             ,
  Vad.CODEVENDEUR_MOD                                                 as CODEVENDEUR_MOD      ,
  Vad.STATUT_CLOS                                                     as STATUT_CLOS          ,
  Vad.STATUT_ANNUL                                                    as STATUT_ANNUL         ,
  Vad.AID                                                             as AID                  ,
  Vad.ND                                                              as ND                   ,
  Vad.BCR_ID                                                          as BCR_ID               ,
  Vad.TYPPROD_CO                                                      as TYPPROD_CO           ,
  Coalesce(Vad.CONTRCT_DT_SIGN_PREC,ContratOld.CONTRCT_DT_SIGN_PREC)                ,
  Coalesce(Vad.CONTRCT_DT_FIN_PREC,ContratOld.CONTRCT_DT_FIN_PREC)                  ,
  Coalesce(Vad.CONTRCT_DT_SIGN_POST,ContratNew.CONTRCT_DT_SIGN_POST)                ,
  Coalesce(Vad.CONTRCT_DUREE_ENG,ContratNew.CONTRCT_DUREE_ENG)                      ,
  Coalesce(Vad.CONTRCT_UNIT_ENG,ContratNew.CONTRCT_UNIT_ENG)                        ,
  Coalesce(VendO3.EDO_ID,Vad.EDO_ID)               as EDO_ID               ,--PILCOM_737
  Coalesce(VendO3.FLAG_PLT_CONV,Vad.FLAG_PLT_CONV,0)                  as FLAG_PLT_CONV        ,
  Coalesce(VendO3.FLAG_PLT_SCH,Vad.FLAG_PLT_SCH,0)                    as FLAG_PLT_SCH         ,
  Coalesce(CmpMarket.FLAG_TEAM_MKT,Vad.FLAG_TEAM_MKT)                 as FLAG_TEAM_MKT        ,
  Coalesce(CmpMarket.FLAG_TYPE_CMP,Vad.FLAG_TYPE_CMP)                 as FLAG_TYPE_CMP        ,
  Coalesce(VendO3.TYPE_EDO,Vad.TYPE_EDO)         as TYPE_EDO          , --PILCOM_737
  Coalesce(Vad.ORG_REF_TRAV,Vendeur.ORG_REF_TRAV)                                   ,
  Vad.TERM_PERFORM_IND                                                as TERM_PERFORM_IND     ,
  Coalesce(Vad.ORG_AGENT_ID,Vendeur.ORG_AGENT_ID)                                   ,
  Coalesce(Vad.ORG_POC_XI,Vendeur.ORG_POC_XI)                                       ,
  Coalesce(Vendeur.ORG_NOM,Vad.ORG_NOM)                                             ,
  Coalesce(Vendeur.ORG_PRENOM,Vad.ORG_PRENOM)                                       ,
  Coalesce(Vad.ORG_ACTVT_REEL,ActiviteVendeur.ORG_ACTVT_REEL)                       ,
  Coalesce(Vad.ORG_GROUPE_ID,Vendeur.ORG_GROUPE_ID)                                 ,
  Coalesce(ActiviteResponsable.ORG_POC_XI_RESP,Vad.ORG_POC_XI_RESP)                 ,
  Coalesce(ActiviteResponsable.ORG_AGENT_RESP_ID,Vad.ORG_AGENT_RESP_ID)             ,
  Coalesce(Vad.DMC_LINE_ID, LineDMC.DMC_LINE_ID)                                    ,
  Coalesce(Vad.DMC_MASTER_LINE_ID, LineDMC.DMC_MASTER_LINE_ID)                      ,
  Coalesce(Vad.DMC_LINE_TYPE, LineDMC.DMC_LINE_TYPE)                                ,
  Coalesce(ActesADV.EXTRNL_OPSRV_DS, Vad.RCS_MOTIV_INVC_CD) as RCS_MOTIV_INVC_CD    ,
  Coalesce(ActesADV.ACTE_ID, Vad.RCS_ENR_ACTE_ID)           as RCS_ENR_ACTE_ID      ,
  Case 
     When Vad.PAR_DEPARTMNT_ID is not Null then Vad.PAR_DEPARTMNT_ID
     Else Case
              When LineDMC.DEPARTMNT_ID is null or LineDMC.DEPARTMNT_ID in ('998','999')
                 Then trim(Vad.PAR_DO)
                 Else LineDMC.DEPARTMNT_ID
              End
     End                                                    as PAR_DEPARTMNT_ID     ,
  Coalesce(Vad.PAR_BU_CD,LineDMC.BU_CD)                     as PAR_BU_CD            ,
  Coalesce(Vad.PAR_CID_ID, LineDMC.PAR_CID_ID)              as PAR_CID_ID           ,
  Coalesce(Vad.PAR_PID_ID, LineDMC.PAR_PID_ID)              as PAR_PID_ID           ,
  Coalesce(Vad.PAR_FIRST_IN, LineDMC.PAR_FIRST_IN)          as PAR_FIRST_IN         ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                   as  ORG_AGENT_IOBSP         ,
  case when  EdoOBK.EDO_ID is null
        Then 'N'
        Else 'O'
  End                                                       As ORG_EDO_IOBSP        ,
  Coalesce(Vad.PAR_POSTAL_CD,LineDMC.POSTAL_CD)             as PAR_POSTAL_CD        ,
  Coalesce(Vad.PAR_INSEE_CD,LineDMC.INSEE_CD)               as PAR_INSEE_CD         ,
  Coalesce(Vad.PAR_GEO_MACROZONE,IRIS.PAR_GEO_MACROZONE)    as PAR_GEO_MACROZONE      ,
  Coalesce(Vad.PAR_UNIFIED_PARTY_ID,LineDMC.PAR_UNIFIED_PARTY_ID)  as PAR_UNIFIED_PARTY_ID  ,
  Coalesce(Vad.PAR_PARTY_REGRPMNT_ID,LineDMC.PAR_PARTY_REGRPMNT_ID)  as PAR_PARTY_REGRPMNT_ID ,
  Coalesce(Vad.PAR_IRIS2000_CD,IRIS.PAR_IRIS2000_CD)        as PAR_IRIS2000_CD      ,
  Coalesce(Vad.PAR_FIBER_IN,FIBER.FIBER_IN)              as PAR_FIBER_IN         ,
  --ConvWEBPART.WEBPARTNR_NAME_NM                             as WEB_PARTNER_CD       , PILCOM_737
  Null                                                      as REDIRECTION_CD       ,
  Coalesce(Vad.PAR_LASTNAME,ClientVAD.PAR_LASTNAME,Client.PAR_LASTNAME)             ,
  Coalesce(Vad.PAR_FIRSTNAME,ClientVAD.PAR_FIRSTNAME,Client.PAR_FIRSTNAME)          ,
  Coalesce(Vad.PAR_TYPE,Client.PAR_TYPE)                                            ,
  Coalesce(Vad.PAR_EMAIL,Bal.PAR_EMAIL)                                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_1,Adr.PAR_BILL_ADRESS_1)                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_2,Adr.PAR_BILL_ADRESS_2)                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_3,Adr.PAR_BILL_ADRESS_3)                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_4,Adr.PAR_BILL_ADRESS_4)                             ,
  Coalesce(Vad.PAR_BILL_VILLE,Adr.PAR_BILL_VILLE)                                   ,
  Coalesce(Vad.PAR_BILL_CD_POSTAL,Adr.PAR_BILL_CD_POSTAL)                           ,
  Coalesce(Vad.PAR_DO,Adr.PAR_DO)                                                   ,
  Coalesce(Vad.PAR_SCORE_NU,Score.PAR_SCORE_NU)                                     ,
  Coalesce(Vad.PAR_SCORE_IN,Score.PAR_SCORE_IN)                                     ,
  Coalesce(Vad.PAR_TRESHOLD_NU,Score.PAR_TRESHOLD_NU)                               ,
  Vad.TARIF_HT                                              as TARIF_HT             ,
  Vad.RCS_IN                                                as RCS_IN               ,
  Vad.RCS_MOTIF_ID                                          as RCS_MOTIF_ID         ,
  Vad.RCS_CODE_ADV_MOTIF                                    as RCS_CODE_ADV_MOTIF   ,
  Null                                                      as CLOSURE_DT           ,
  '${KNB_BATCH_DATE}'                                       as CREATION_TS          ,
  '${KNB_BATCH_DATE}'                                       as LAST_MODIF_TS        ,
  1                                                         as FRESH_IN             ,
  0                                                         as COHERENCE_IN         
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Vad
  Left Outer Join ${KNB_TERADATA_USER}.VAD_PER_PARC Parc
    On Vad.ACTE_ID  = Parc.ACTE_ID
  Left Outer Join ${KNB_TERADATA_USER}.VAD_PER_VAL_SACHEM Sachem
    On Vad.ACTE_ID  = Sachem.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_OLD ContratOld
    On    Vad.ACTE_ID = ContratOld.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_NEW ContratNew
    On    Vad.ACTE_ID = ContratNew.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEUR Vendeur
    On    Vad.ACTE_ID = Vendeur.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ACTIV   ActiviteVendeur
    On    Vad.ACTE_ID = ActiviteVendeur.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESP    ActiviteResponsable
    On    Vad.ACTE_ID = ActiviteResponsable.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT_VAD ClientVAD
    On    Vad.ACTE_ID = ClientVAD.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT     Client
    On    Vad.ACTE_ID = Client.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_BAL        Bal
    On    Vad.ACTE_ID = Bal.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ADR        Adr
    On    Vad.ACTE_ID = Adr.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_SCORE      Score
    On    Vad.ACTE_ID = Score.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_DMC_VAD      LineDMC
    On    Vad.ACTE_ID = LineDMC.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_IRIS      IRIS
    On    Vad.ACTE_ID = IRIS.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_FIBER      FIBER
    On    Vad.ACTE_ID = FIBER.ACTE_ID
    -- PILCOM_737
 -- Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_VAD_WEBPART      ConvWEBPART 
  --  On    Vad.ACTE_ID = ConvWEBPART.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3    VendO3
    On    Vad.ACTE_ID = VendO3.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_TYPEMARKET   CmpMarket
    On    Vad.ACTE_ID = CmpMarket.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_IMSI   NumImsi
    On    Vad.ACTE_ID = NumImsi.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESDOSIMSI   ResDosImsi
    On    Vad.ACTE_ID = ResDosImsi.ACTE_ID
  --- Indicateur IOBSP
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
    On  Vad.EDO_ID   = EdoOBK.EDO_ID
      And Vad.DATE_SAISIE  >= EdoOBK.START_VAL_AXS_DT
      And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN = 1 --(ORANGEBANK)=
  Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Vad.ORG_AGENT_ID=CuidOBK.AGENT_ID 
      AND Vad.DATE_SAISIE >= CuidOBK.HABILL_BEGIN_DT 
      AND Vad.DATE_SAISIE < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
  Left Outer Join ${KNB_PCO_SOC}.V_BIL_F_PLACEMENT_ADV               ActesADV     -- RCS
      On   ActesADV.MSISDN_ID         =       Vad.DOSSIER_NU
      And  ActesADV.ORDER_DEPOSIT_DT  Between Vad.DATE_SAISIE
      And  Vad.DATE_SAISIE        + 10
      And  Vad.TYPE_LIG_CDE        = 'RCS'
Where
  (1=1)
   And       Vad.TYPE_LIG_CDE in ('OT','SO')

Qualify Row_number() over (Partition By Vad.ACTE_ID,Vad.DATE_SAISIE Order By Vad.DATE_SAISIE_TS asc)=1
;
.if errorcode <> 0 then .quit 1







Insert into ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD
(
  ACTE_ID               ,
  APPLI_SOURCE_ID       ,
  CDE_REFERENCE         ,
  DATE_SAISIE           ,
  DATE_SAISIE_TS        ,
  DOSSIER_NU            ,
  DOSSIER_NU_PREC_PORTE ,
  CLIENT_NU             ,
  PAR_IMSI              ,
  PAR_MOB_SIM           ,
  DOSSIER_DT_CREAT      ,
  DOSSIER_DT_RESIL      ,
  DOSSIER_DATE_RESIL    ,
  DOSSIER_TYPE_RESIL    ,
  DOSSIER_MOTIF_RESIL   ,
  PRESFACT_CO_COM       ,
  PARC_DT_DEBUT         ,
  PARC_DT_FIN           ,
  PRESFACT_CO_PREC      ,
  USCM_CO               ,
  CANALDIST             ,
  PDV                   ,
  STATUT_CDE            ,
  DUREE_ENGAGEMENT      ,
  TYPE_DUR_ENGAGEMENT   ,
  TYPE_LIG_CDE          ,
  CDE_LIG_ID            ,
  EXT_PRODUCT_ID        ,
  PRIX_HT               ,
  DATEVALIDATION        ,
  DATE_DECLA_SACHEM     ,
  DATE_LIVRAISON        ,
  NUMEROIMEI            ,
  CODEVENDEUR           ,
  EAN_FTT               ,
  CODE_TAC              ,
  CODEVENDEUR_MOD       ,
  STATUT_CLOS           ,
  STATUT_ANNUL          ,
  AID                   ,
  ND                    ,
  BCR_ID                ,
  TYPPROD_CO            ,
  CONTRCT_DT_SIGN_PREC  ,
  CONTRCT_DT_FIN_PREC   ,
  CONTRCT_DT_SIGN_POST  ,
  CONTRCT_DUREE_ENG     ,
  CONTRCT_UNIT_ENG      ,
  EDO_ID                , 
  FLAG_PLT_CONV         ,
  FLAG_PLT_SCH          ,
  FLAG_TEAM_MKT         ,
  FLAG_TYPE_CMP         ,
  TYPE_EDO              ,
  ORG_REF_TRAV          ,
  TERM_PERFORM_IND      ,
  ORG_AGENT_ID          ,
  ORG_POC_XI            ,
  ORG_NOM               ,
  ORG_PRENOM            ,
  ORG_ACTVT_REEL        ,
  ORG_GROUPE_ID         ,
  ORG_POC_XI_RESP       ,
  ORG_AGENT_RESP_ID     ,
  DMC_LINE_ID           ,
  DMC_MASTER_LINE_ID    ,
  DMC_LINE_TYPE         , -- RCS
  RCS_MOTIV_INVC_CD     , -- RCS
  RCS_ENR_ACTE_ID       , -- RCS
  PAR_DEPARTMNT_ID      ,
  PAR_BU_CD             ,
  PAR_CID_ID            ,
  PAR_PID_ID            ,
  PAR_FIRST_IN          ,
  ORG_AGENT_IOBSP       ,
  ORG_EDO_IOBSP         ,
  PAR_POSTAL_CD         ,
  PAR_INSEE_CD          ,
  PAR_GEO_MACROZONE     ,
  PAR_UNIFIED_PARTY_ID  ,
  PAR_PARTY_REGRPMNT_ID ,
  PAR_IRIS2000_CD       ,
  PAR_FIBER_IN          ,
 -- WEB_PARTNER_CD        ,PILCOM_737
  REDIRECTION_CD        ,
  PAR_LASTNAME          ,
  PAR_FIRSTNAME         ,
  PAR_TYPE              ,
  PAR_EMAIL             ,
  PAR_BILL_ADRESS_1     ,
  PAR_BILL_ADRESS_2     ,
  PAR_BILL_ADRESS_3     ,
  PAR_BILL_ADRESS_4     ,
  PAR_BILL_VILLE        ,
  PAR_BILL_CD_POSTAL    ,
  PAR_DO                ,
  PAR_SCORE_NU          ,
  PAR_SCORE_IN          ,
  PAR_TRESHOLD_NU       ,
  TARIF_HT              ,
  RCS_IN                , -- RCS
  RCS_MOTIF_ID          , -- RCS
  RCS_CODE_ADV_MOTIF    , -- RCS
  CLOSURE_DT            ,
  CREATION_TS           ,
  LAST_MODIF_TS         ,
  FRESH_IN              ,
  COHERENCE_IN          
)
Select
  Vad.ACTE_ID               as ACTE_ID              ,
  Vad.APPLI_SOURCE_ID       as APPLI_SOURCE_ID      ,
  Vad.CDE_REFERENCE         as CDE_REFERENCE        ,
  Vad.DATE_SAISIE           as DATE_SAISIE          ,
  Vad.DATE_SAISIE_TS        as DATE_SAISIE_TS       ,
  Vad.DOSSIER_NU            as DOSSIER_NU           ,
  Vad.DOSSIER_NU_PREC_PORTE as DOSSIER_NU_PREC_PORTE,
  Vad.CLIENT_NU             as CLIENT_NU            ,
  Coalesce(NumImsi.PAR_IMSI,Vad.PAR_IMSI)                             as PAR_IMSI               ,
  Vad.PAR_MOB_SIM           as PAR_MOB_SIM          ,
  Vad.DOSSIER_DT_CREAT      as DOSSIER_DT_CREAT     ,
  Vad.DOSSIER_DT_RESIL      as DOSSIER_DT_RESIL     ,
  Coalesce(ResDosImsi.DATE_RESIL_DOS,Vad.DOSSIER_DATE_RESIL)          as DOSSIER_DATE_RESIL     ,
  Coalesce(ResDosImsi.CO_RESILDOS,Vad.DOSSIER_TYPE_RESIL)             as DOSSIER_TYPE_RESIL     ,
  Coalesce(ResDosImsi.DOSSIER_MOTIF_RESIL,Vad.DOSSIER_MOTIF_RESIL)    as DOSSIER_MOTIF_RESIL    ,
  Vad.PRESFACT_CO_COM       as PRESFACT_CO_COM      ,
  Null                      as PARC_DT_DEBUT        ,
  Null                      as PARC_DT_FIN          ,
  Vad.PRESFACT_CO_PREC      as PRESFACT_CO_PREC     ,
  Vad.USCM_CO               as USCM_CO              ,
  Null                      as CANALDIST            ,
  Vad.PDV                   as PDV                  ,
  Vad.STATUT_CDE            as STATUT_CDE           ,
  Vad.DUREE_ENGAGEMENT      as DUREE_ENGAGEMENT     ,
  Vad.TYPE_DUR_ENGAGEMENT   as TYPE_DUR_ENGAGEMENT  ,
  Vad.TYPE_LIG_CDE          as TYPE_LIG_CDE         ,
  Vad.CDE_LIG_ID            as CDE_LIG_ID           ,
  Vad.EXT_PRODUCT_ID        as EXT_PRODUCT_ID       ,
  Vad.PRIX_HT               as PRIX_HT              ,
  Vad.DATEVALIDATION        as DATEVALIDATION       ,
  Vad.DATE_DECLA_SACHEM     as DATE_DECLA_SACHEM    ,
  Vad.DATE_LIVRAISON        as DATE_LIVRAISON       ,
  Vad.NUMEROIMEI            as NUMEROIMEI           ,
  Vad.CODEVENDEUR           as CODEVENDEUR          ,
  Vad.EAN_FTT               as EAN_FTT              ,
  Vad.CODE_TAC              as CODE_TAC             ,
  Vad.CODEVENDEUR_MOD       as CODEVENDEUR_MOD      ,
  Vad.STATUT_CLOS           as STATUT_CLOS          ,
  Vad.STATUT_ANNUL          as STATUT_ANNUL         ,
  Vad.AID                   as AID                  ,
  Vad.ND                    as ND                   ,
  Vad.BCR_ID                as BCR_ID               ,
  Vad.TYPPROD_CO            as TYPPROD_CO           ,
  Coalesce(Vad.CONTRCT_DT_SIGN_PREC,ContratOld.CONTRCT_DT_SIGN_PREC)                ,
  Coalesce(Vad.CONTRCT_DT_FIN_PREC,ContratOld.CONTRCT_DT_FIN_PREC)                  ,
  Coalesce(Vad.CONTRCT_DT_SIGN_POST,ContratNew.CONTRCT_DT_SIGN_POST)                ,
  Coalesce(Vad.CONTRCT_DUREE_ENG,ContratNew.CONTRCT_DUREE_ENG)                      ,
  Coalesce(Vad.CONTRCT_UNIT_ENG,ContratNew.CONTRCT_UNIT_ENG)                        ,
  Coalesce(VendO3.EDO_ID,Vad.EDO_ID)     as EDO_ID               , 
  --Par d?faut si la Team n'est pas retrouv? on met non convergent
  Coalesce(VendO3.FLAG_PLT_CONV,Vad.FLAG_PLT_CONV,0)        as FLAG_PLT_CONV        ,
  Coalesce(VendO3.FLAG_PLT_SCH,Vad.FLAG_PLT_SCH,0)            as FLAG_PLT_SCH         ,
  Coalesce(CmpMarket.FLAG_TEAM_MKT,Vad.FLAG_TEAM_MKT)       as FLAG_TEAM_MKT        ,
  Coalesce(CmpMarket.FLAG_TYPE_CMP,Vad.FLAG_TYPE_CMP)       as FLAG_TYPE_CMP        ,
  Coalesce(VendO3.TYPE_EDO,Vad.TYPE_EDO)                    as TYPE_EDO        , 
  Coalesce(Vad.ORG_REF_TRAV,Vendeur.ORG_REF_TRAV)                                   ,
  Vad.TERM_PERFORM_IND                                      as TERM_PERFORM_IND     ,
  Coalesce(Vad.ORG_AGENT_ID,Vendeur.ORG_AGENT_ID)                                   ,
  Coalesce(Vad.ORG_POC_XI,Vendeur.ORG_POC_XI)                                       ,
  Coalesce(Vendeur.ORG_NOM,Vad.ORG_NOM)                                             ,
  Coalesce(Vendeur.ORG_PRENOM,Vad.ORG_PRENOM)                                       ,
  Coalesce(Vad.ORG_ACTVT_REEL,ActiviteVendeur.ORG_ACTVT_REEL)                       ,
  Coalesce(Vad.ORG_GROUPE_ID,Vendeur.ORG_GROUPE_ID)                                 ,
  Coalesce(ActiviteResponsable.ORG_POC_XI_RESP,Vad.ORG_POC_XI_RESP)                 ,
  Coalesce(ActiviteResponsable.ORG_AGENT_RESP_ID,Vad.ORG_AGENT_RESP_ID)             ,
  Coalesce(Vad.DMC_LINE_ID, LineDMC.DMC_LINE_ID)                                    ,
  Coalesce(Vad.DMC_MASTER_LINE_ID, LineDMC.DMC_MASTER_LINE_ID)                      ,
  Coalesce(Vad.DMC_LINE_TYPE, LineDMC.DMC_LINE_TYPE)        as DMC_LINE_TYPE        , -- RCS
  Coalesce(ActesADV.EXTRNL_OPSRV_DS, Vad.RCS_MOTIV_INVC_CD) as RCS_MOTIV_INVC_CD    , -- RCS
  Coalesce(ActesADV.ACTE_ID, Vad.RCS_ENR_ACTE_ID)           as RCS_ENR_ACTE_ID      , -- RCS
  Case 
     When Vad.PAR_DEPARTMNT_ID is not Null then Vad.PAR_DEPARTMNT_ID
     Else Case
              When LineDMC.DEPARTMNT_ID is null or LineDMC.DEPARTMNT_ID in ('998','999')
                 Then trim(Vad.PAR_DO)
                 Else LineDMC.DEPARTMNT_ID
              End
     End                                                    as PAR_DEPARTMNT_ID     ,
  Coalesce(Vad.PAR_BU_CD,LineDMC.BU_CD)                     as PAR_BU_CD            ,
  Coalesce(Vad.PAR_CID_ID, LineDMC.PAR_CID_ID)              as PAR_CID_ID           ,
  Coalesce(Vad.PAR_PID_ID, LineDMC.PAR_PID_ID)              as PAR_PID_ID           ,
  Coalesce(Vad.PAR_FIRST_IN, LineDMC.PAR_FIRST_IN)          as PAR_FIRST_IN         ,
  Case
          When CuidOBK.AGENT_ID is Null 
            Then '0'
          When CuidOBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
            Then '3'
          Else   '2'
    End                                                   as  ORG_AGENT_IOBSP         ,
  case when  EdoOBK.EDO_ID is null
          Then 'N'
          Else 'O'
  End                                                       as ORG_EDO_IOBSP        ,
  Coalesce(Vad.PAR_POSTAL_CD,LineDMC.POSTAL_CD)             as PAR_POSTAL_CD        ,
  Coalesce(Vad.PAR_INSEE_CD,LineDMC.INSEE_CD)               as PAR_INSEE_CD         ,
  Coalesce(Vad.PAR_GEO_MACROZONE,IRIS.PAR_GEO_MACROZONE)    as PAR_GEO_MACROZONE    ,
  Coalesce(Vad.PAR_UNIFIED_PARTY_ID,LineDMC.PAR_UNIFIED_PARTY_ID)    as PAR_UNIFIED_PARTY_ID  ,
  Coalesce(Vad.PAR_PARTY_REGRPMNT_ID,LineDMC.PAR_PARTY_REGRPMNT_ID)  as PAR_PARTY_REGRPMNT_ID ,
  Coalesce(Vad.PAR_IRIS2000_CD,IRIS.PAR_IRIS2000_CD)        as PAR_IRIS2000_CD      ,
  Coalesce(Vad.PAR_FIBER_IN,FIBER.FIBER_IN)              as PAR_FIBER_IN         ,
  --ConvWEBPART.WEBPARTNR_NAME_NM                             as WEB_PARTNER_CD       , PILCOM_737
  Null                                                    as REDIRECTION_CD       ,
  Coalesce(Vad.PAR_LASTNAME,ClientVAD.PAR_LASTNAME,Client.PAR_LASTNAME)             ,
  Coalesce(Vad.PAR_FIRSTNAME,ClientVAD.PAR_FIRSTNAME,Client.PAR_FIRSTNAME)          ,
  Coalesce(Vad.PAR_TYPE,Client.PAR_TYPE)                                            ,
  Coalesce(Vad.PAR_EMAIL,Bal.PAR_EMAIL)                                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_1,Adr.PAR_BILL_ADRESS_1)                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_2,Adr.PAR_BILL_ADRESS_2)                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_3,Adr.PAR_BILL_ADRESS_3)                             ,
  Coalesce(Vad.PAR_BILL_ADRESS_4,Adr.PAR_BILL_ADRESS_4)                             ,
  Coalesce(Vad.PAR_BILL_VILLE,Adr.PAR_BILL_VILLE)                                   ,
  Coalesce(Vad.PAR_BILL_CD_POSTAL,Adr.PAR_BILL_CD_POSTAL)                           ,
  Coalesce(Vad.PAR_DO,Adr.PAR_DO)                                                   ,
  Coalesce(Vad.PAR_SCORE_NU,Score.PAR_SCORE_NU)                                     ,
  Coalesce(Vad.PAR_SCORE_IN,Score.PAR_SCORE_IN)                                     ,
  Coalesce(Vad.PAR_TRESHOLD_NU,Score.PAR_TRESHOLD_NU)                               ,
  Vad.TARIF_HT                                              as TARIF_HT             ,
  Vad.RCS_IN                                                as RCS_IN               , -- RCS
  Vad.RCS_MOTIF_ID                                          as RCS_MOTIF_ID         , -- RCS
  Vad.RCS_CODE_ADV_MOTIF                                    as RCS_CODE_ADV_MOTIF   , -- RCS
  Null                                                      as CLOSURE_DT           ,
  '${KNB_BATCH_DATE}'                                       as CREATION_TS          ,
  '${KNB_BATCH_DATE}'                                       as LAST_MODIF_TS        ,
  1                                                         as FRESH_IN             ,
  0                                                         as COHERENCE_IN         
From
  ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_INTER Vad
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_OLD ContratOld
    On    Vad.ACTE_ID = ContratOld.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CONT_NEW ContratNew
    On    Vad.ACTE_ID = ContratNew.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEUR Vendeur
    On    Vad.ACTE_ID = Vendeur.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ACTIV   ActiviteVendeur
    On    Vad.ACTE_ID = ActiviteVendeur.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESP    ActiviteResponsable
    On    Vad.ACTE_ID = ActiviteResponsable.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT_VAD ClientVAD
    On    Vad.ACTE_ID = ClientVAD.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_CLIENT     Client
    On    Vad.ACTE_ID = Client.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_BAL        Bal
    On    Vad.ACTE_ID = Bal.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_ADR        Adr
    On    Vad.ACTE_ID = Adr.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_SCORE      Score
    On    Vad.ACTE_ID = Score.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_DMC_VAD      LineDMC
    On    Vad.ACTE_ID = LineDMC.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_IRIS      IRIS
    On    Vad.ACTE_ID = IRIS.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.INT_W_PLACEMENT_VAD_FIBER      FIBER
    On    Vad.ACTE_ID = FIBER.ACTE_ID
    --PILCOM_737
  --Left Outer Join ${KNB_PCO_TMP}.ORD_W_PLACEMENT_VAD_WEBPART      ConvWEBPART
   -- On    Vad.ACTE_ID = ConvWEBPART.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_VENDEURO3    VendO3
    On    Vad.ACTE_ID = VendO3.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_TYPEMARKET   CmpMarket
    On    Vad.ACTE_ID = CmpMarket.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_IMSI   NumImsi
    On    Vad.ACTE_ID = NumImsi.ACTE_ID
  Left Outer Join ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD_RESDOSIMSI   ResDosImsi
    On    Vad.ACTE_ID = ResDosImsi.ACTE_ID
  -- Indicateur IOBSP
  Left Outer Join ${KNB_COM_SOC_V_PRS}.ORG_H_AXS_EDO EdoOBK
    On  Vad.EDO_ID   = EdoOBK.EDO_ID
      And Vad.DATE_SAISIE  >= EdoOBK.START_VAL_AXS_DT
      And EdoOBK.VAL_AXS_CLSSF_ID  in ('${P_PIL_163}')    And  EdoOBK.CURRENT_IN = 1 --('ORANGEBANK')
  Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CuidOBK
      On Vad.ORG_AGENT_ID=CuidOBK.AGENT_ID 
      AND Vad.DATE_SAISIE >= CuidOBK.HABILL_BEGIN_DT 
      AND Vad.DATE_SAISIE < Coalesce (CuidOBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
  Left Outer Join ${KNB_PCO_SOC}.V_BIL_F_PLACEMENT_ADV               ActesADV     -- RCS
      On   ActesADV.MSISDN_ID         =       Vad.DOSSIER_NU
      And  ActesADV.ORDER_DEPOSIT_DT  Between Vad.DATE_SAISIE
      And  Vad.DATE_SAISIE        + 10
      And  Vad.TYPE_LIG_CDE       = 'RCS'

Where
  (1=1)
  And      Vad.TYPE_LIG_CDE not in ('OT','SO')

Qualify Row_number() over (Partition By Vad.ACTE_ID,Vad.DATE_SAISIE Order By Vad.DATE_SAISIE_TS asc)=1
;
.if errorcode <> 0 then .quit 1

Collect stats on ${KNB_PCO_TMP}.COM_T_PLACEMENT_VAD;
.if errorcode <> 0 then .quit 1

