-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_Referentiel_Alimentation_O3_Step1_Calcul_Conseiller.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de Calcul du rattachement conseiller / O3
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
--------------------------------------------------------------------------------

.set width 2500;


Create Volatile Table ${KNB_TERADATA_USER}.ORG_V_REF_O3_HIE_CUID_EDO (
  AGENT_CUID                            Char(10)              Not Null    ,
  EDO_ID                                BigInt                Not Null    ,
  PERIODE_ID                            Integer               Not Null    ,
  MOIS_1                                Date    Format 'YYYYMMDD'         ,
  MOIS_2                                Date    Format 'YYYYMMDD'         
)
Primary Index (
  AGENT_CUID  ,
  EDO_ID      
)
On Commit Preserve Rows
;
.if errorcode <> 0 then .quit 1




Insert into ${KNB_TERADATA_USER}.ORG_V_REF_O3_HIE_CUID_EDO
(
  AGENT_CUID        ,
  EDO_ID            ,
  PERIODE_ID        ,
  MOIS_1            ,
  MOIS_2            
)
Select
  AA_Agent_EDO.AGENT_CUID             as AGENT_CUID   ,
  AA_Agent_EDO.EDO_ID                 as EDO_ID       ,
  AA_Agent_EDO.PERIODE_ID             as PERIODE_ID   ,
  AA_Agent_EDO.MOIS_APPLICATION_1     as MOIS_1       ,
  AA_Agent_EDO.MOIS_APPLICATION_2     as MOIS_2       
From
  (
    Select
      Unif.AGENT_ID_UPD                                                                           as AGENT_CUID         ,
      Unif.ORG_EDO_ID                                                                             as EDO_ID             ,
      Unif.ACT_PERIODE_ID                                                                         as PERIODE_ID         ,
      RefPer.PERIODE_DATE_DEB                                                                     as DATE_DEB           ,
      RefPer.PERIODE_DATE_FIN                                                                     as DATE_FIN           ,
      Cast(
            Cast('01/'||cast(add_months(PERIODE_DATE_DEB , 4) as format 'MM/YYYY') as char(10))
            as date  format 'DD/MM/YYYY'
          )                                                                                       as MOIS_APPLICATION_1 ,
      Cast(
            Cast('01/'||cast(add_months(PERIODE_DATE_DEB , 5) as format 'MM/YYYY') as char(10))
            as date  format 'DD/MM/YYYY'
          )                                                                                       as MOIS_APPLICATION_2 
    From
      ${KNB_PCO_VM}.V_ORD_F_ACTE_UNIFIED Unif 
      Inner Join ${KNB_PCO_REFCOM}.CAT_R_PERIODE_COM_PILCOM RefPer
        On    Unif.ACT_PERIODE_ID   = RefPer.PERIODE_ID
          And RefPer.CURRENT_IN     = 1
          And RefPer.CLOSURE_DT     Is Null
    Where
      (1=1)
      And Unif.ORG_EDO_ID         Is Not Null
      --And Unif.CONCLU_PVC_IN      = 'O'
      --And Unif.PERENNITE_PVC_IN   In ('O','N','NC')
      And Unif.AGENT_ID_UPD       Is Not Null
  ) AA_Agent_EDO
Qualify Row_number()  Over (Partition By AA_Agent_EDO.AGENT_CUID, AA_Agent_EDO.EDO_ID, AA_Agent_EDO.PERIODE_ID Order By AA_Agent_EDO.MOIS_APPLICATION_1 asc) = 1
;
.if ErrorCode <> 0 Then .Quit 1;


Collect Stat On ${KNB_TERADATA_USER}.ORG_V_REF_O3_HIE_CUID_EDO Column(AGENT_CUID,EDO_ID);
.if ErrorCode <> 0 Then .Quit 1;
----------------


Delete From ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_CUID_EDO all;
.if ErrorCode <> 0 Then .Quit 1;


Insert Into ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_CUID_EDO
(
  AGENT_CUID    ,
  EDO_ID        ,
  MOIS          
)
Select
  RefId.AGENT_CUID        As AGENT_CUID   ,
  RefId.EDO_ID            As EDO_ID       ,
  RefId.MOIS_1            As MOIS         
From
  ${KNB_TERADATA_USER}.ORG_V_REF_O3_HIE_CUID_EDO RefId
;
.if ErrorCode <> 0 Then .Quit 1;



--On collecte les stats sur la table 
Collect Stat On ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_CUID_EDO;
.if ErrorCode <> 0 Then .Quit 1;

Insert Into ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_CUID_EDO
(
  AGENT_CUID    ,
  EDO_ID        ,
  MOIS          
)
Select
  RefId.AGENT_CUID        As AGENT_CUID   ,
  RefId.EDO_ID            As EDO_ID       ,
  RefId.MOIS_2            As MOIS         
From
  ${KNB_TERADATA_USER}.ORG_V_REF_O3_HIE_CUID_EDO RefId
Where
  Not Exists
  (
    Select
      1
    From
      ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_CUID_EDO RefIns
    Where
      (1=1)
      And RefId.AGENT_CUID    = RefIns.AGENT_CUID
      And RefId.EDO_ID        = RefIns.EDO_ID
      And RefId.MOIS_2        = RefIns.MOIS
  )
;
.if ErrorCode <> 0 Then .Quit 1;


Collect Stat On ${KNB_PCO_TMP}.ORG_W_REF_O3_HIE_CUID_EDO;
.if ErrorCode <> 0 Then .Quit 1;


.quit 0


