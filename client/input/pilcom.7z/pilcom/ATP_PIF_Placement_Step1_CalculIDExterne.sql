-- $HEADER:   mm2pco/current/sql/ATP_PIF_Placement_Step1_CalculIDExterne.sql 13_05#1 20-SEP-2016 11:05:41 FDGX6201
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Step1_CalculIDExterne.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/07/2017      HLA         Creation
-- 17/08/2021      BCH         PILCOM-833 : New PIF / Décom BOI
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
--Delete From  All;
Delete from ${KNB_PCO_TMP}.ORD_W_Placement_PIF_IDEXTERNE all;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_Placement_PIF_IDEXTERNE
(
  EXTERNAL_ACTE_ID                   ,
  TYPE_SOURCE_ID                     ,
  INTRNL_SOURCE_ID                   ,
  INTERST_GET_ID                     ,
  FIBR_INTERST_CANL_DS               ,
  INTERST_GET_CREATN_DT              ,
  INTERST_GET_SUPP_IN                ,
  INTERST_GET_SUPP_DT                ,
  INTERST_AGNT_ID                    ,
  INTERST_SELLR_SHOP_ID              ,
  INTERST_GET_DOSS_NUMBR_DS          ,
  CONTCT_NAME_NM                     ,
  CONTCT_FIRSTNM_NM                  ,
  EMAIL_DS                           ,
  PHONE_FIX_DS                       ,
  ND_DS                              ,
  PHONE_MOBILE_DS                    ,
  MSISDN_ID                          ,
  CREATN_TYP                         ,
  RAD                                
)
Select
  INTERST_GET_ID                             As EXTERNAL_ACTE_ID                          ,
  ${IdentifiantTechniqueSource}              As TYPE_SOURCE_ID                            ,
  ${IdSourceInterne}                         As INTRNL_SOURCE_ID                          ,
  FIB.INTERST_GET_ID                         As INTERST_GET_ID                            ,
  FIB.FIBR_INTERST_CANL_DS                   AS FIBR_INTERST_CANL_DS                      ,
  FIB.INTERST_GET_CREATN_DT                  As INTERST_GET_CREATN_DT                     ,
  FIB.INTERST_GET_SUPP_IN                    As INTERST_GET_SUPP_IN                       ,
  FIB.INTERST_GET_SUPP_DT                    As INTERST_GET_SUPP_DT                       ,
  FIB.INTERST_AGNT_ID                        As INTERST_AGNT_ID                           ,
  FIB.INTERST_SELLR_SHOP_ID                  As INTERST_SELLR_SHOP_ID                     ,
  FIB.INTERST_GET_DOSS_NUMBR_DS              As INTERST_GET_DOSS_NUMBR_DS                 ,
  FIB.CONTCT_NAME_NM                         As CONTCT_NAME_NM                            ,
  FIB.CONTCT_FIRSTNM_NM                      As CONTCT_FIRSTNM_NM                         ,
  FIB.EMAIL_DS                               As EMAIL_DS                                  ,
  FIB.PHONE_FIX_DS                           As PHONE_FIX_DS                              ,
  FIB.ND_DS                                  As ND_DS                                     ,
  FIB.PHONE_MOBILE_DS                        As PHONE_MOBILE_DS                           ,
  FIB.MSISDN_ID                              As MSISDN_ID                                 ,
  FIB.CREATN_TYP                           As CREATN_TYP                                  ,
  FIB.RAD                                  As RAD                                         
From
  ${KNB_PCO_TMP}.ORD_W_Placement_PIF_EXT FIB
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_Placement_PIF_IDEXTERNE;
.if errorcode <> 0 then .quit 1


