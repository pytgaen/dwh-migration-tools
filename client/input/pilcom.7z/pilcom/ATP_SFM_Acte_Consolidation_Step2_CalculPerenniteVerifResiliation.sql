-- $HEADER: mm2pco/current/sql/ATP_SFM_Acte_Consolidation_Step2_CalculPerenniteVerifResiliation.sql 13_05#2 05-OCT-2016 15:17:57 TLSD0863
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SFM_Acte_Consolidation_Step2_CalculPerenniteVerifResiliation.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/08/2014      HFO         CREATION
-- 05/10/2016      GMA         Remonte de la resiliation client Mobile à la place de l'internet
--------------------------------------------------------------------------------

.set width 2500;


Delete From ${KNB_PCO_TMP}.INT_W_ACTE_SFM_CHECK_RESIL_PER All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindre dans le référentiel fusionné
-------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.INT_W_ACTE_SFM_CHECK_RESIL_PER
(
  ACTE_ID                     ,
  INT_DEPOSIT_DT              ,
  PAR_IMSI                    ,
  DOSSIER_TYPE_RESIL          ,
  PERNNT_IN                   ,
  PERNNT_END_DT               ,
  PERNNT_MOTIF                ,
  SEG_COM_ID_FINAL_ORDER      
)
Select 
  Acte.ACTE_ID                                                    as ACTE_ID                        ,
  Acte.ORDER_DEPOSIT_DT                                           as INT_DEPOSIT_DT                 ,
  Acte.PAR_IMSI_CD                                                as PAR_IMSI                       ,
  Placement.RESIL_MOB_MOTIF                                       as DOSSIER_TYPE_RESIL             ,
  'N'                                                             as PERNNT_IN                      ,
  Placement.RESIL_MOB_DT                                          as PERNNT_END_DT                  ,
  Placement.RESIL_MOB_MOTIF_DS                                    as PERNNT_MOTIF                   ,
  Acte.SEG_COM_ID                                                 as SEG_COM_ID_FINAL_ORDER         
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_MOB_C_PRECAL Acte
  Inner Join  ${KNB_PCO_SOC}.V_ORD_F_PLACEMENT_SOFT_MOB Placement
    On    Acte.ACTE_ID                    =   Placement.ACTE_ID
      And Acte.ORDER_DEPOSIT_DT           =   Placement.ORDER_DEPOSIT_DT
  Inner Join ${KNB_PCO_SOC}.CAT_R_PARAM_RESIL_PER Per
    On    Placement.RESIL_MOB_MOTIF       =   Per.RESIL_INT_MOTIF
      And Per.PERENNITE_LOSS_FLAG         =   'Oui'
      --And Per.CURRENT_IN                  =   1
      --And Per.CLOSURE_DT                  Is Null
Where (1 = 1)
  And Placement.RESIL_MOB_DT <= Acte.ORDER_DEPOSIT_DT + 60
  And Placement.RESIL_MOB_DT >= Acte.ORDER_DEPOSIT_DT
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.INT_W_ACTE_SFM_CHECK_RESIL_PER;
.if errorcode <> 0 then .quit 1

.quit 0
