--$HEADER:   mm2pco/current/sql/ATP_SAH_Placement_Step7_Enrichissement_StepEDOID.sql 13_05#1 31-JUL-2017 17:07:24 FQJR5800
----------------------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_SAH_Placement_Step7_Enrichissement_StepEDOID.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'alimentation des placements 
----------------------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 18/07/2017      MDE         Creation
----------------------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EDOID All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EDOID
(   
 
    ORDER_DEPOSIT_DT                  ,
    EXT_AGENT_ID                      ,
    ORG_AGENT_ID                      ,
    EXT_SHOP_ID                       ,
    EDO_ID                             
   

)
Select
    Placement.ORDER_DEPOSIT_DT           As     ORDER_DEPOSIT_DT       ,
    Placement.EXT_AGENT_ID               As     EXT_AGENT_ID           ,
    Placement.ORG_AGENT_ID               As     ORG_AGENT_ID           ,
    Placement.EXT_SHOP_ID                As     EXT_SHOP_ID            ,
    Placement.EDO_ID                     As     EDO_ID
From          
  --On prend tout le contenu de la table miroir tmp                      
  ${KNB_PCO_TMP}.ORD_T_PLACEMENT_SAVI_SAH_1     Placement 
  Where 
  (1=1)
  And  Placement.EDO_ID          Is Not Null
  And  Placement.EXT_AGENT_ID    Is Not Null
  Qualify Row_Number() Over (Partition by  Placement.ORDER_DEPOSIT_DT , Placement.EXT_AGENT_ID   Order by  Placement.ORDER_DEPOSIT_DT asc)=1 ;
.if errorcode <> 0 then .quit 1  
Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_SAH_STEP_EDOID ;
.if errorcode <> 0 then .quit 1 
.quit 0
