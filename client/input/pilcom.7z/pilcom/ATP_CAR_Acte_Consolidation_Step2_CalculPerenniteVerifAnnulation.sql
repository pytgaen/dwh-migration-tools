--$HEADER:   %HEADER% 
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_CAR_Acte_Consolidation_CalculPerenniteVerifAnnulation.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de verification annulation actes ACARE 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 21/08/2015      AOU         Creation
--------------------------------------------------------------------------------

.set width 2500;



Delete From ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_CHECK_CANCLNG All;
.if errorcode <> 0 then .quit 1

-------------------------------------------------------------------------------------------
--Step 1 : On Selectionne les data pour les joindres dans l référentiel fusionné
-------------------------------------------------------------------------------------------


Insert into ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_CHECK_CANCLNG
(
  ACTE_ID                 ,
  ORD_DEPOSIT_DT          
)
Select
  Acte.ACTE_ID                          as ACTE_ID                ,
  Acte.ORD_DEPOSIT_DT                   as ORD_DEPOSIT_DT         
From
  --Pannel des Actes à rechercher
  ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_EXRACT Acte
  Inner Join  ${KNB_PCO_TMP}.ORD_W_AGENDE_SEG_REFCOM_DB RefAgend
    On    Acte.PAR_IMSI           = RefAgend.DOSSIER_NU_IMSI
      And Acte.SEG_COM_ID_LP      = RefAgend.SEG_COM_ID
      And Acte.ORD_DEPOSIT_DT     = RefAgend.ORDAGD_DEMANDE_DT
Where
  (1=1)
  --On filtre sur le type de commande qui nous intéresse
  And Acte.TYPE_COMMANDE          in ('MIGR','MAINT','FIDELISATION','DEMGT','ACQ')
  --on supprime les segment générique de cette recherche
  And Acte.SEG_COM_ID_LP          Not In ('NS','OPTTECH','OPT_INC')
  --And Acte.TYPE_OT_SO             in ('SO')
  And Acte.PAR_IMSI               Is Not Null
  -- On filtre les ordres annulé
  And RefAgend.ORDAGD_ETAT        = 'K'
  --On recherche les annulation uniquement pour les ajouts:
  And RefAgend.ORDAGD_OPE         In ('A')
Qualify Row_Number() Over (Partition By Acte.ACTE_ID Order by Coalesce(RefAgend.ORDAGD_DT_TRAIT,RefAgend.ORDAGD_DT_EFFET) Desc)=1
;
.if errorcode <> 0 then .quit 1


Collect stat on ${KNB_PCO_TMP}.ORD_W_ACTE_CAR_CHECK_CANCLNG;
.if errorcode <> 0 then .quit 1






.quit 0


