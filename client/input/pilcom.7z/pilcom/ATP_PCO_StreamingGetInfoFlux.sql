-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PCO_StreamingGetInfoFlux.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql permettant l'export des tables d'infos sur le streaming
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------

Select
  Trim(Cast(START_TIME as  char(10)))||'|'||
  Trim(Cast(END_TIME as  char(10)))||'|'||
  Trim(Coalesce(PATERN_DAY,''))||'|'||
  DATABASE_CIBLE||'|'||
  TABLE_CIBLE||'|'||
  CHAMP_TS||'|'||
  Coalesce(SPECIF_FLOW_CFG,'')||'|'||
  Coalesce(SPECIF_FLOW_SQL,'') (title '')
From
  ${KNB_PCO_TECH}.ADM_R_RECEIVED_STREAM_FLOW
Where
  (1=1)
  And APPLI_SOURCE_CD='${nomSource}'
  And FLOW_CD='${nomFlux}'
;
.if ErrorCode <> 0 Then .Quit 1;
