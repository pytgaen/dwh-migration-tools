--$HEADER: mm2pco/current/sql/ATP_NSW_Placement_Cold_CalculDelta_Jour.sql 13_05#1 23-OCT-2019 10:47:29 NNGS2043
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_NSW_Placement_Hot_CalculDelta_Jour.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL d'extraction des donnÃ©es NSW
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 09/01/2014      OCH         Creation
-- 28/12/2016      HLA         Modification EvoZoffres:( Nouveau parcours ) 
-- 24/04/2017      MDE         Evol MSISDN fournis par MyShop QC1657
-- 18/09/2017     HOB         Nouveaux Parcours
-- 25/09/2018      TCL         Nouveau parcours 97 Dashboard Digital
-- 02/10/2019      TCL         Décom 6PO à chaud: reprise du dev

--------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_ORDER_NSW_WEB_C_EXT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------
------- Insertion des migrations d'offres MySHOP
-------------------------------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_W_ORDER_NSW_WEB_C_EXT
(
  ORDR_ID                       ,
  TYPE_PRODUCT_CD               ,
  SUBSCRPTN_ID                  ,
  ORDR_TYPLG_DS                 ,
  ORDR_TYPLG_CD                 ,
  ORDR_CATGR_DS                 ,
  ORDR_CATGR_CD                 ,
  ORDR_CREATN_TS                ,
  ORDR_CREATN_DT                ,
  ORDR_END_DT                   ,
  ORDR_LAST_MODF_DT             ,
  ORDR_ORGN_DS                  ,
  ORDR_ORGN_CD                  ,
  ORDR_MSH_ORGN_DS              ,
  VAD_ID                        ,
  SCORNG_IN                     ,
  SCORNG_CD                     ,
  AGNT_ID                       ,
  AMNT_ORD_PAYED_AM             ,
  AMNT_MONTH_AM                 ,
  PHONE_ID                      ,
  SELLER_AGNT_ID                ,
  SHOP_NAME_DS                  ,
  SHOP_COD_DS                   ,
  SHOP_ADV_CODE_DS              ,
  BRAND_SHOP_DS                 ,
  SOFT_RESLT_PARSIFAL_ID        ,
  ETASK_RESLT_ETASK_ID          ,
  OPAL_ID                       ,
  MSISDN_DS                     ,
  RECHG_PROCH_IN                ,
  WEBPARTNR_ID                  ,
  MSISDN_RECHG_ID               ,
  MSISDN_ID                     ,
  CODFCTN_ORNG_DS               ,
  CODFCTN_INIT_DS               ,
  ACTN_CATGR_CD                 ,
  ARTCL_ID                      ,
  ARTCL_TYP_CD                  ,
  UNIT_PRIC_AM                  ,
  PRIC_AM                       ,
  PRIC_HT_AM                    ,
  OPTN_ACTVTN_DT                ,
  VALID_DURTN_DU                ,
  VALID_END_DT                  ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN
)
Select
  RefSpo.ORDR_ID                                                      as ORDR_ID                           ,
  Matrice.TYPE_PRODUCT_CD                                             as TYPE_PRODUCT_CD                   ,
  Null                                                                as SUBSCRPTN_ID                      ,
  Null                                                                as ORDR_TYPLG_DS                     ,
  RefSpo.ORDR_TYPLG_CD                                                as ORDR_TYPLG_CD                     ,
  Null                                                                as ORDR_CATGR_DS                     ,
  RefSpo.ORDR_CATGR_CD                                                as ORDR_CATGR_CD                     ,
  RefSpo.ORDR_CREATN_DT                                               as ORDR_CREATN_TS                    ,
  cast (RefSpo.ORDR_CREATN_DT as Date FORMAT 'YYYYMMDD')              as ORDR_CREATN_DT                    ,
  Null                                                   as ORDR_END_DT                       ,
  RefSpo.FRESH_TS                                                     as ORDR_LAST_MODF_DT                 ,
  Null                                                                as ORDR_ORGN_DS                      ,
  8                                                                   as ORDR_ORGN_CD                      ,
  RefSPO.ORDR_MSH_ORGN_DS                                             as ORDR_MSH_ORGN_DS                  ,
  RefSPO.VAD_ID                                                       as VAD_ID                            ,
  NULL                                                                as SCORNG_IN                         ,
  NULL                                                                as SCORNG_CD                         ,
  NULL                                                                as AGNT_ID                           ,
  NULL                                                                as AMNT_ORD_PAYED_AM                 ,
  Null                                                                as AMNT_MONTH_AM                     ,
  NULL                                                                as PHONE_ID                          ,
  NULL                                                                as SELLER_AGNT_ID                    ,
  NULL                                                                as SHOP_NAME_DS                      ,
  NULL                                                                as SHOP_COD_DS                       ,
  NULL                                                                as SHOP_ADV_CODE_DS                  ,
  NULL                                                                as BRAND_SHOP_DS                     ,
  NULL                                                                as SOFT_RESLT_PARSIFAL_ID            ,
  NULL                                                                as ETASK_RESLT_ETASK_ID              ,
  NULL                                                                as OPAL_ID                           ,
  Case When substr(RefSpo.MSISDN_ID,1,2) = '33' 
               then cast ('0'||SUBSTRING(trim(RefSpo.MSISDN_ID) from 3)  as VARCHAR(15) )   
              Else RefSpo.MSISDN_ID 
	End                                                                 as MSISDN_DS                         ,
  RefSpo.RECHG_PROCH_IN                                               as RECHG_PROCH_IN                    ,
  NULL                                                                as WEBPARTNR_ID                      ,
  Case When Matrice.TYPE_PRODUCT_CD in ('R') 
         Then   Case when  substr(RefSpo.MSISDN_RECHG_ID,1,2) = '33' 
                         then  cast ('0'||SUBSTRING(trim(RefSpo.MSISDN_RECHG_ID  ) from 3)  as VARCHAR(15) ) 
                       else RefSpo.MSISDN_RECHG_ID
                 End        
        Else Case When substr(RefSpo.MSISDN_ID,1,2) = '33' 
                    then cast ('0'||SUBSTRING(trim(RefSpo.MSISDN_ID) from 3)  as VARCHAR(15) )   
                  Else RefSpo.MSISDN_ID 
            End      
  End                                                                 as MSISDN_RECHG_ID                   ,
 -- QC1657
  Case When substr(RefSpo.MSISDN_ID,1,2) = '33' 
               then cast ('0'||SUBSTRING(trim(RefSpo.MSISDN_ID) from 3)  as VARCHAR(15) )   
              Else RefSpo.MSISDN_ID 
	End                                                                 as MSISDN_ID                         ,
 
  --
 
 
  DetSpo.ARTCL_CD                                                     as CODFCTN_ORNG_DS                   ,
  Null                                                                as CODFCTN_INIT_DS                   ,
  DetSpo.ACTN_CATGR_CD                                                as ACTN_CATGR_CD                     ,
  --DetSpo.ARTCL_CD                                                     as ARTCL_ID                          ,
  Null                                                                as ARTCL_ID                          ,
  DetSpo.ARTCL_TYP_CD                                                 as ARTCL_TYP_CD                      ,
  RefSpo.UNIT_PRIC_AM                                                 as UNIT_PRIC_AM                      ,
  RefSpo.PRIC_AM                                                      as PRIC_AM                           ,
  RefSpo.PRIC_HT_AM                                                   as PRIC_HT_AM                        ,
  DetSpo.OPTN_ACTVTN_DT                                               as OPTN_ACTVTN_DT                    ,
  DetSpo.VALID_DURTN_DU                                               as VALID_DURTN_DU                    ,
  DetSpo.VALID_END_DT                                                 as VALID_END_DT                      ,
  Current_Timestamp(0)                                                as CREATION_TS                       ,
  Current_Timestamp(0)                                                as LAST_MODIF_TS                     ,
  1                                                                   as FRESH_IN                          ,
  0                                                                   as COHERENCE_IN

From ${KNB_SPO_DM_GLB}.ORD_F_ORDR_BSKT_MSH_OL_D_VM RefSpo
    Inner join ${KNB_SPO_DM_GLB}.ORD_F_ART_BSKT_MSH_OL_D_VM DetSpo
    On DetSpo.ORDR_ID = RefSpo.ORDR_ID
 
    Inner Join ${KNB_PCO_SOC}.ORG_R_MATRICE_NSW_MS Matrice
      on   RefSpo.ORDR_TYPLG_CD        = Matrice.ORDR_TYPLG_CD
       And DetSpo.ARTCL_TYP_CD         = Matrice.ARTCL_TYP_CD 
       And DetSpo.ACTN_CATGR_CD        = Matrice.ACTN_CATGR_CD
       And RefSpo.ORDR_STATT_CD        = Matrice.ORDR_STATT_CD
where
  (1=1)
 
 And RefSpo.ORDR_CREATN_DT is not null 
  
 And ((
          RefSpo.FRESH_TS > '${KNB_PILCOM_PLACEMENT_BORNE_INF}'
        And
          RefSpo.FRESH_TS <= '${KNB_PILCOM_PLACEMENT_BORNE_MAX}'
      ) Or RefSpo.ORDR_CREATN_DT >= Current_Date - 5 )
;
.if errorcode <> 0 then .quit 1



