-- $HEADER: mm2pco/current/sql/ATP_BES_Placement_Hot_Alimentation_Step1_CalculIDExterne.sql 13_05#5 03-MAI-2017 11:20:53 KRQJ9961
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_BES_Placement_Hot_Alimentation_Step1_CalculIDExterne.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 20/03/2014      HZO         Modification
-- 11/09/2015      MDE         Modif/Evol
-- 03/05/2017      JCR         Patch pour pallier les envois avec USER_ID IS NULL de Bestar non conformes au CI
-- 16/11/2020      EVI         PILCOM-613 : Vue Chewbacca
-- 22/09/2021      EVI         PILCOM-792 : Gestion Retour/Annulation DSTAR
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_EXT All;
.if errorcode <> 0 then .quit 1

----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_EXT
(
  EXTERNAL_ACTE_ID      ,
  TYPE_SOURCE_ID        ,
  INTRNL_SOURCE_ID      ,
  ID_PANIER             ,
  SEQ_PANIER            ,
  ORDER_DEPOSIT_DT      ,
  ORDER_DEPOSIT_TS      ,
  CODE_EAN              ,
  CUID                  ,
  USER_ID               ,
  CODE_CDR              ,
  CODE_SOUS_FAMILLE     ,
  QUANTITE              ,
  CA_GLOBALE            ,
  CA_LINE               ,
  TVA_GLOBALE_NU        ,
  TVA_LINE_NU           ,
  IMEI_CD               ,
  MSISDN_NU             ,
  NAME_NM               ,
  ADRESS1_NM            ,
  ADRESS2_NM            ,
  ADRESS3_NM            ,
  POSTAL_CD             ,
  VILLE_NM              ,
  TYPE_VENTE            , 
  PANIER_ID_ORIGINE     ,
  CREATION_TS           ,
  LAST_MODIF_TS         ,
  FRESH_IN              ,
  COHERENCE_IN          ,
  RUN_ID                
)
Select
  --La clé est définie à partir de l'id du panier + Le code EAN + la séquence de quantité + User ID (Ajouté a cause d'un problème de doublon
  (Trim(Placement.ID_PANIER)||'|'||Trim(Placement.CODE_EAN)||'|'||Trim(Quantite.ID_QUANTITE)||'|'||Trim(Placement.USER_ID)||'|'|| Trim(coalesce(Placement.IMEI_CD , '' )))           As EXTERNAL_ACTE_ID   ,
  --Paramètre dans le shell
  ${IdentifiantTechniqueSource}                                                                                     As TYPE_SOURCE_ID     ,
  --Paramètre dans le shell d'execution
  ${IdSourceInterne}                                                                                                As INTRNL_SOURCE_ID   ,
  Placement.ID_PANIER                                                                                               As ID_PANIER          ,
  Quantite.ID_QUANTITE                                                                                              As SEQ_PANIER         ,
  Placement.ORDER_DEPOSIT_DT                                                                                        As ORDER_DEPOSIT_DT   ,
  Placement.ORDER_DEPOSIT_TS                                                                                        As ORDER_DEPOSIT_TS   ,
  Placement.CODE_EAN                                                                                                As CODE_EAN           ,
  Placement.CUID                                                                                                    As CUID               ,
  Placement.USER_ID                                                                                                 As USER_ID            ,
  Placement.CODE_CDR                                                                                                As CODE_CDR           ,
  Placement.CODE_SOUS_FAMILLE                                                                                       As CODE_SOUS_FAMILLE  ,
  Placement.QUANTITE                                                                                                As QUANTITE           ,
  Placement.CA                                                                                                      As CA_GLOBALE         ,
  Placement.CA/Placement.QUANTITE                                                                                   As CA_LINE            ,
  Placement.TVA_NU                                                                                                  As TVA_GLOBALE_NU     ,
  Placement.TVA_NU/Placement.QUANTITE                                                                               As TVA_LINE_NU        ,
  Placement.IMEI_CD                                                                                                 As IMEI_CD            ,
  Placement.MSISDN_NU                                                                                               As MSISDN_NU          ,
  Placement.NAME_NM                                                                                                 As NAME_NM            ,
  Placement.ADRESS1_NM                                                                                              As ADRESS1_NM         ,
  Placement.ADRESS2_NM                                                                                              As ADRESS2_NM         ,
  Placement.ADRESS3_NM                                                                                              As ADRESS3_NM         ,
  Placement.POSTAL_CD                                                                                               As POSTAL_CD          , 
  Placement.VILLE_NM                                                                                                As VILLE_NM           ,
  Placement.TRANSCTN_TYPE_NM                                                                                        As TYPE_VENTE         , 
  Placement.ID_PANIER_ORIGINE_ID                                                                                    As PANIER_ID_ORIGINE  ,
  Current_Timestamp(0)                                                                                              As CREATION_TS        ,
  Current_Timestamp(0)                                                                                              As LAST_MODIF_TS      ,
  1                                                                                                                 As FRESH_IN           ,
  1                                                                                                                 As COHERENCE_IN       ,
  ${RUN_ID}                                                                                                         As RUN_ID             
From
  -- Vue Chewbacca
  ${KNB_CSM_GLB_PIL_V}.CSM_F_ORDER_CBK Placement
  --On jointe avec la table referentiel pour générer le bon nombre de ligne
  Inner Join ${KNB_PCO_TMP}.ORD_T_PILCOM_GEN_QUANTITY Quantite
    On ABS(Placement.QUANTITE) = Quantite.REF_QUANTITE
Where
  1=1
  And Placement.USER_ID IS NOT NULL
  And (Placement.TRANSCTN_TYPE_NM IN ('VENTE')
       Or 
       (Placement.TRANSCTN_TYPE_NM IN('ANNULATION_VENTE','REMBOURSEMENT_CLASSIQUE') 
        And 
        Placement.ORDER_DEPOSIT_DT >= Cast('01/11/2021' As Date Format 'DD/MM/YYYY')
       )
      )
  And  (  Placement.LAST_MODIF_TS    > '${KNB_PILCOM_PLACEMENT_BORNE_INF}' -- date de derniere modification extraite
      Or
       Placement.CREATION_TS       >  '${KNB_PILCOM_PLACEMENT_BORNE_INF}')
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_W_PLACEMENT_BESTAR_H_EXT;
.if errorcode <> 0 then .quit 1

.quit 0
