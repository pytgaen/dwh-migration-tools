-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PLC_CRF_Referentiel_CalculParcPCA.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : Sql  Calcul du parc PCA sur l'AS + Segement Refcom
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 25/02/2013      GMA         Creation
-- 10/01/2014      GMA         Mise à jour normes DSM
--------------------------------------------------------------------------------

-- ENRICHISSEMENT AVEC L'ACCES DE SERVICE
DELETE FROM      ${KNB_PCO_TMP}.INB_T_PART_INB_HRF ALL
;

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- CONSTITUTION DU FLUX ENTRANT

INSERT INTO      ${KNB_PCO_TMP}.INB_T_PART_INB_HRF
                 (
                   SERVICE_ACCESS_ID
                 , MIN_REALZTN_DT
                 , PARK_ID
                 , REALZTN_DT
                 , REALIZTN_HH
                 , CANCELLNG_DT
                 , CANCELLNG_HH
                 , COMPST_OFFR_ID
                 , ATOMIC_OFFR_ID
                 , FUNCTN_ID
                 , FUNCTN_VALUE_ID
                 , PRODUCT_ID
                 , IND_TECH_PCA_EDP_MULTI_AS
                 , CLOSRE_DT
                 , LAST_MODIF_TS
                 , CREATION_TS
                 , FRESH_IN
                 , COHERENCE_IN
                 )
SELECT             INB_W_PARK_AS_HRF.ACCES_SERVICE                                              AS SERVICE_ACCESS_ID
                 , INB_W_PARK_AS_HRF.MIN_REALZTN_DT                                             AS MIN_REALZTN_DT
                 , COALESCE(T.T_PARK_ID, -1)                                                    AS PARK_ID                  
                 , T.T_REALZTN_DT                                                               AS REALZTN_DT               
                 , T.T_REALIZTN_HH                                                              AS REALIZTN_HH              
                 , T.T_CANCELLNG_DT                                                             AS CANCELLNG_DT             
                 , T.T_CANCELLNG_HH                                                             AS CANCELLNG_HH             
                 , T.T_COMPST_OFFR_ID                                                           AS COMPST_OFFR_ID           
                 , T.T_ATOMIC_OFFR_ID                                                           AS ATOMIC_OFFR_ID           
                 , T.T_FUNCTN_ID                                                                AS FUNCTN_ID                
                 , T.T_FUNCTN_VALUE_ID                                                          AS FUNCTN_VALUE_ID          
                 , T.T_PRODUCT_ID                                                               AS PRODUCT_ID               
                 , T.T_IND_TECH_PCA_EDP_MULTI_AS                                                AS IND_TECH_PCA_EDP_MULTI_AS
                 , NULL                                                                         AS CLOSRE_DT
                 , CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}') AS LAST_MODIF_TS
                 , CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}') AS CREATION_TS
                 , 1                                                                            AS FRESH_IN
                 , 0                                                                            AS COHERENCE_IN
FROM             ${KNB_PCO_TMP}.INB_W_PARK_AS_HRF                                                  INB_W_PARK_AS_HRF
LEFT JOIN         (                 
                    SELECT             INB_F_PART_INB.ACCES_SERVICE                                                           AS T_SERVICE_ACCESS_ID
                                     , INB_W_PARK_HRF.PARK_ID                                                                 AS T_PARK_ID
                                     , INB_W_PARK_HRF.REALZTN_DT                                                              AS T_REALZTN_DT
                                     , INB_W_PARK_HRF.REALIZTN_HH                                                             AS T_REALIZTN_HH
                                     , INB_W_PARK_HRF.CANCELLNG_DT                                                            AS T_CANCELLNG_DT
                                     , INB_W_PARK_HRF.CANCELLNG_HH                                                            AS T_CANCELLNG_HH
                                     , INB_W_PARK_HRF.COMPST_OFFR_ID                                                          AS T_COMPST_OFFR_ID
                                     , INB_W_PARK_HRF.ATOMIC_OFFR_ID                                                          AS T_ATOMIC_OFFR_ID
                                     , INB_W_PARK_HRF.FUNCTN_ID                                                               AS T_FUNCTN_ID
                                     , INB_W_PARK_HRF.FUNCTN_VALUE_ID                                                         AS T_FUNCTN_VALUE_ID
                                     , INB_W_PARK_HRF.PRODUCT_ID                                                              AS T_PRODUCT_ID
                                     , COUNT(*) OVER(
                                                      PARTITION BY INB_W_PARK_HRF.PARK_ID
                                                    )                                                                         AS T_IND_TECH_PCA_EDP_MULTI_AS
                    
                    FROM             ${KNB_COM_SOC_V_PRS}.INB_F_PART_INB                                                         INB_F_PART_INB
                    JOIN             ${KNB_PCO_TMP}.INB_W_PARK_HRF                                                               INB_W_PARK_HRF
                    ON                 1                                                                               =         1
                    AND                INB_W_PARK_HRF.PARK_ID                                                          =         INB_F_PART_INB.PARK_ID
                    WHERE              1                                                                               =         1
                    -- SELECTION DE L'ETAT COURANT DES COUPLES (ACCES DE SERVICE, EDP) ACTIFS 
                    AND                INB_F_PART_INB.CURRENT_IN                                                       =         1
                    AND                INB_F_PART_INB.CLOSURE_DT                                                       IS NULL
                    -- SELECTION DES COUPLES (ACCES DE SERVICE, EDP) DONT L'ACCES DE SERVICE EST VALORISE
                    AND                INB_F_PART_INB.ACCES_SERVICE                                                    IS NOT NULL
                    -- SELECTION DES COUPLES (ACCES DE SERVICE, EDP) ISSUS DE EFB ET CORRESPONDANT AU ROLE 'DETENTEUR'
                    AND                INB_F_PART_INB.PARTY_ROL_ID                                                     =      '${P_PIL_292}'
                    AND                INB_F_PART_INB.APPLI_SOURCE_ID                                                  =      '${P_PIL_052}'
                    -- DEDOUBLONNAGE TECHNIQUE POUR SUPPRESSION DES DOUBLONS SUR LE COUPLE (EDP, AS)
                    QUALIFY            ROW_NUMBER() OVER(
                                                          PARTITION BY INB_F_PART_INB.ACCES_SERVICE
                                                                     , INB_W_PARK_HRF.PARK_ID
                                                         -- CONSERVATION DU COUPLE LE PLUS RECEMMENT CREE
                                                          ORDER BY     INB_F_PART_INB.CREATION_TS DESC
                                                        )                                                              =         1
                  ) T(
                       T_SERVICE_ACCESS_ID
                     , T_PARK_ID
                     , T_REALZTN_DT
                     , T_REALIZTN_HH
                     , T_CANCELLNG_DT
                     , T_CANCELLNG_HH
                     , T_COMPST_OFFR_ID
                     , T_ATOMIC_OFFR_ID
                     , T_FUNCTN_ID
                     , T_FUNCTN_VALUE_ID
                     , T_PRODUCT_ID
                     , T_IND_TECH_PCA_EDP_MULTI_AS
                     )
ON                 1                                                                     =         1
AND                INB_W_PARK_AS_HRF.ACCES_SERVICE                                       =         T.T_SERVICE_ACCESS_ID
;                 

.IF ERRORCODE <> 0 THEN .QUIT 1;

-- CLOTURE DES EDP ABSENTS DU FLUX ENTRANT
INSERT INTO      ${KNB_PCO_TMP}.INB_T_PART_INB_HRF
                 (
                   SERVICE_ACCESS_ID
                 , MIN_REALZTN_DT
                 , PARK_ID
                 , REALZTN_DT
                 , REALIZTN_HH
                 , CANCELLNG_DT
                 , CANCELLNG_HH
                 , COMPST_OFFR_ID
                 , ATOMIC_OFFR_ID
                 , FUNCTN_ID
                 , FUNCTN_VALUE_ID
                 , PRODUCT_ID
                 , IND_TECH_PCA_EDP_MULTI_AS
                 , CLOSRE_DT
                 , LAST_MODIF_TS
                 , CREATION_TS
                 , FRESH_IN
                 , COHERENCE_IN
                 )
SELECT             V_INB_F_PART_INB_HRF.SERVICE_ACCESS_ID                                                 AS SERVICE_ACCESS_ID
                 , V_INB_F_PART_INB_HRF.MIN_REALZTN_DT                                                    AS MIN_REALZTN_DT
                 , V_INB_F_PART_INB_HRF.PARK_ID                                                           AS PARK_ID                  
                 , V_INB_F_PART_INB_HRF.REALZTN_DT                                                        AS REALZTN_DT               
                 , V_INB_F_PART_INB_HRF.REALIZTN_HH                                                       AS REALIZTN_HH              
                 , V_INB_F_PART_INB_HRF.CANCELLNG_DT                                                      AS CANCELLNG_DT             
                 , V_INB_F_PART_INB_HRF.CANCELLNG_HH                                                      AS CANCELLNG_HH             
                 , V_INB_F_PART_INB_HRF.COMPST_OFFR_ID                                                    AS COMPST_OFFR_ID           
                 , V_INB_F_PART_INB_HRF.ATOMIC_OFFR_ID                                                    AS ATOMIC_OFFR_ID           
                 , V_INB_F_PART_INB_HRF.FUNCTN_ID                                                         AS FUNCTN_ID                
                 , V_INB_F_PART_INB_HRF.FUNCTN_VALUE_ID                                                   AS FUNCTN_VALUE_ID          
                 , V_INB_F_PART_INB_HRF.PRODUCT_ID                                                        AS PRODUCT_ID               
                 , V_INB_F_PART_INB_HRF.IND_TECH_PCA_EDP_MULTI_AS                                         AS IND_TECH_PCA_EDP_MULTI_AS
                 , CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}') (DATE)    AS CLOSRE_DT
                 , CAST('${KNB_BATCH_DATE}' AS TIMESTAMP(0) FORMAT '${KNB_PCO_FORMAT_TS_TECH}')           AS LAST_MODIF_TS
                 , V_INB_F_PART_INB_HRF.CREATION_TS                                                       AS CREATION_TS
                 , 1                                                                                      AS FRESH_IN
                 , 0                                                                                      AS COHERENCE_IN
FROM             ${KNB_PCO_SOC}.V_INB_F_PART_INB_HRF                                                         V_INB_F_PART_INB_HRF
WHERE              1                                                                               =         1
AND                                                                                                NOT EXISTS
                  (
                    SELECT             1
                    FROM             ${KNB_PCO_TMP}.INB_T_PART_INB_HRF                             INB_T_PART_INB_HRF_INNER
                    WHERE              1                                                 =         1
                    AND                INB_T_PART_INB_HRF_INNER.SERVICE_ACCESS_ID        =         V_INB_F_PART_INB_HRF.SERVICE_ACCESS_ID
                    AND                INB_T_PART_INB_HRF_INNER.PARK_ID                  =         V_INB_F_PART_INB_HRF.PARK_ID     
                  )
AND               V_INB_F_PART_INB_HRF.CLOSRE_DT                                                   IS NULL
;                 

.IF ERRORCODE <> 0 THEN .QUIT 1;
