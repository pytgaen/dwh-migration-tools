--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PIF_Placement_Consolidation_Enrichissement_Step2_Rercherche_ACQ.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- O7/10/2016      HLA         Creation
--------------------------------------------------------------------------------

.set width 2500;

----------------------------------------------------------------------------
-- Etape 1 : 
----------------------------------------------------------------------------

Delete from ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBRE_ACQ all;
.if errorcode <> 0 then .quit 1

Insert Into ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBRE_ACQ
(
  ACTE_ID              ,
  ORDER_DEPOSIT_DT     ,
  PARC_SEG_COM_ID      ,
  PARC_REALZTN_DT      ,
  PERENNITE_END_DT     ,
  DATE_REM_TS           
 )
Select 
   RefId.ACTE_ID                             AS  ACTE_ID                ,
   RefId.ORDER_DEPOSIT_DT                    AS  ORDER_DEPOSIT_DT       ,
   Parc.SEG_COM_ID                           As  PARC_SEG_COM_ID        ,
   Parc.REALZTN_DT                           As  PARC_REALZTN_DT        ,
   Case When Parc.SERVICE_ACCESS_ID is null
          Then current_date
       else Null
   End                                        As  PERENNITE_END_DT       ,
 Case When Parc.SERVICE_ACCESS_ID is not null 
       Then Cast(cast(cast(current_date as date format'YYYYMMDD') as varchar(6))|| '01' as date format 'YYYYMMDD' ) -1       
      else Null
  End                                          As DATE_REM_TS
   
From ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_2 RefId 
 --Si existe dans le parc
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_ACTE_SOFT_C_INT_PCAFUS_F Parc
    On     RefID.SERVICE_ACCESS_ID   = Parc.SERVICE_ACCESS_ID
      And  Parc.SEG_COM_ID         Like '%FIB%' 
      And  RefId.SERVICE_ACCESS_ID <> -1
      And  RefId.ORDER_DEPOSIT_DT  <=  Parc.REALZTN_DT
      And   (
                current_date <=  Parc.CANCELLNG_DT
                  Or
                Parc.CANCELLNG_DT           Is Null
           )
Where (1=1)
  -- DATE entre 1 et 31 M-2  
  And Cast(Cast(RefID.DATE_TRANS_TS as date format'YYYYMMDD') as varchar(6)) = Cast( Cast(ADD_MONTHS(Current_date,-2) as date format'YYYYMMDD')  as varchar(6))
  -- PIF TRANS
  And RefId.DATE_TRANS_TS IS NOT NULL 
  And RefId.DATE_REM_TS IS NULL   
  And RefId.ORDER_CANCELLING_DT IS NULL
  And RefId.PERENNITE_END_DT is null
  And Cast(Cast(RefId.DATE_TRANS_TS as date format'YYYYMMDD') as varchar(8))  > '${P_PIL_545}'
  
Qualify Row_number() over (Partition by RefId.ACTE_ID Order By Parc.REALZTN_DT  Desc) = 1

;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PIF_FIBRE_ACQ;
.if errorcode <> 0 then .quit 1

    