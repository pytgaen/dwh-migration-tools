--$HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_PXF_Placement_Step5_Fusion_Placement.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL Fusion des placements PXF
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 04/12/2020      EVI         Creation
--------------------------------------------------------------------------------
.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                           ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ORD_T_PLACEMENT_PXF All;
.if errorcode <> 0 then .quit 1

------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP
------------------------------------------------------------------
Insert into ${KNB_PCO_TMP}.ORD_T_PLACEMENT_PXF
(
    ACTE_ID               
  , EXTRNL_ORDER_ID       
  , TYPE_SOURCE_ID        
  , INTRNL_SOURCE_ID      
  , ORDER_DEPOSIT_TS      
  , ORDER_DEPOSIT_DT      
  , LAST_UPDATE_TS        
  , ORDER_CANCELING_DT    
  , ORDER_CANCELING_TS    
  , EXTRNL_STATUS_CD      
  , STATUS_UNIFIED_CD     
  , EXTRNL_EAN_CD         
  -- Axe Client
  , EXTRNL_PHONE_NUMBER   
  , EXTRNL_MOBILE_NUMBER  
  , EXTRNL_POSTAL_CODE    
  , EXTRNL_CUSTOMER_STATUS
  , DEPARTMNT_ID          
  , DMC_ACTIVATION_DT     
  , DMC_LINE_ID           
  , DMC_MASTER_LINE_ID    
  , DMC_CUST_TYPE_CD      
  , DMC_NDS_VALUE_DS      
  , DMC_MSISDN_ID         
  , DMC_EXTERNAL_PARTY_ID 
  , DMC_RES_VALUE_DS      
  , DMC_SERVICE_ACCESS_ID 
  , DMC_LINE_TYPE         
  , DMC_START_DT          
  , DMC_POSTAL_CD         
  , PAR_INSEE_NB          
  , PAR_BU_CD             
  , DMC_DEPRTMNT_ID       
  , PAR_GEO_MACROZONE     
  , PAR_UNIFIED_PARTY_ID  
  , PAR_PARTY_REGRPMNT_ID 
  , PAR_IRIS2000_CD       
  , PAR_CID_ID            
  , PAR_PID_ID            
  , PAR_FIRST_IN          
  , PAR_FIBER_IN          
  -- Axe Organisation
  , ORG_AGENT_ID          
  , ORG_AGENT_IOBSP       
  , EXTRNL_TYPE_AGENCE    
  , EXTRNL_EDO_ID         
  , ORG_EDO_ID            
  , ORG_EDO_IOBSP         
  , ORG_TYPE_CD           
  , ORG_TYPE_EDO          
  , WORK_TEAM_LEVEL_1_CD  
  , WORK_TEAM_LEVEL_1_DS  
  , WORK_TEAM_LEVEL_2_CD  
  , WORK_TEAM_LEVEL_2_DS  
  , WORK_TEAM_LEVEL_3_CD  
  , WORK_TEAM_LEVEL_3_DS  
  , WORK_TEAM_LEVEL_4_CD  
  , WORK_TEAM_LEVEL_4_DS  
  -- Axe Canal
  , ORG_CHANNEL_CD        
  , ORG_SUB_CHANNEL_CD    
  , ORG_SUB_SUB_CHANNEL_CD
  , ORG_REM_CHANNEL_CD    
  , ORG_GT_ACTIVITY       
  , ORG_WEB_ACTIVITY      
  , ORG_AUTO_ACTIVITY     
  , UNIFIED_SHOP_CD       
  -- Champs Techniques 
  , CREATION_TS           
  , LAST_MODIF_TS         
  , FRESH_IN              
  , COHERENCE_IN          

)
Select
  PXF.ACTE_ID                                                             As ACTE_ID                ,
  PXF.EXTRNL_ORDER_ID                                                     As EXTRNL_ORDER_ID        ,
  PXF.TYPE_SOURCE_ID                                                      As TYPE_SOURCE_ID         ,
  PXF.INTRNL_SOURCE_ID                                                    As INTRNL_SOURCE_ID       ,
  PXF.ORDER_DEPOSIT_TS                                                    As ORDER_DEPOSIT_TS       ,
  PXF.ORDER_DEPOSIT_DT                                                    As ORDER_DEPOSIT_DT       ,
  PXF.LAST_UPDATE_TS                                                      As LAST_UPDATE_TS         ,
  PXF.ORDER_CANCELING_DT                                                  As ORDER_CANCELING_DT     ,
  PXF.ORDER_CANCELING_TS                                                  As ORDER_CANCELING_TS     ,
  PXF.EXTRNL_STATUS_CD                                                    As EXTRNL_STATUS_CD       ,
  PXF.STATUS_UNIFIED_CD                                                   As STATUS_UNIFIED_CD      ,
  PXF.EXTRNL_EAN_CD                                                       As EXTRNL_EAN_CD          ,
  -- Axe Client                   
  PXF.EXTRNL_PHONE_NUMBER                                                 As EXTRNL_PHONE_NUMBER    ,
  PXF.EXTRNL_MOBILE_NUMBER                                                As EXTRNL_MOBILE_NUMBER   ,
  PXF.EXTRNL_POSTAL_CODE                                                  As EXTRNL_POSTAL_CODE     ,
  PXF.EXTRNL_CUSTOMER_STATUS                                              As EXTRNL_CUSTOMER_STATUS ,
  Case 
    When DMC_LINE_ID_AGR Is Not Null
      Then Coalesce(PXF_DMC.DEPARTMNT_ID, PXF.DEPARTMNT_ID)
    Else 
      Case 
        When PXF.EXTRNL_POSTAL_CODE Is Not Null Then
          Case 
            When substr(PXF.EXTRNL_POSTAL_CODE,1,3) In ('971','972','973','974','975','976','980','986','987','988')
              Then substr(PXF.EXTRNL_POSTAL_CODE,1,3)
            Else substr(PXF.EXTRNL_POSTAL_CODE,1,2)
          End 
        Else PXF.DEPARTMNT_ID
      End
  End                                                                     As DEPARTMNT_ID           ,
  Coalesce(PXF_DMC.DMC_ACTIVATION_DT    , PXF.DMC_ACTIVATION_DT    )      As DMC_ACTIVATION_DT      ,
  Coalesce(PXF_DMC.DMC_LINE_ID          , PXF.DMC_LINE_ID          )      As DMC_LINE_ID_AGR        ,
  Coalesce(PXF_DMC.DMC_MASTER_LINE_ID   , PXF.DMC_MASTER_LINE_ID   )      As DMC_MASTER_LINE_ID     ,
  Coalesce(PXF_DMC.DMC_CUST_TYPE_CD     , PXF.DMC_CUST_TYPE_CD     )      As DMC_CUST_TYPE_CD       ,
  Coalesce(PXF_DMC.DMC_NDS_VALUE_DS     , PXF.DMC_NDS_VALUE_DS     )      As DMC_NDS_VALUE_DS       ,
  Coalesce(PXF_DMC.DMC_MSISDN_ID        , PXF.DMC_MSISDN_ID        )      As DMC_MSISDN_ID          ,
  Coalesce(PXF_DMC.DMC_EXTERNAL_PARTY_ID, PXF.DMC_EXTERNAL_PARTY_ID)      As DMC_EXTERNAL_PARTY_ID  ,
  Coalesce(PXF_DMC.DMC_RES_VALUE_DS     , PXF.DMC_RES_VALUE_DS     )      As DMC_RES_VALUE_DS       ,
  Coalesce(PXF_DMC.DMC_SERVICE_ACCESS_ID, PXF.DMC_SERVICE_ACCESS_ID)      As DMC_SERVICE_ACCESS_ID  ,
  Coalesce(PXF_DMC.DMC_LINE_TYPE        , PXF.DMC_LINE_TYPE        )      As DMC_LINE_TYPE          ,
  Coalesce(PXF_DMC.DMC_START_DT         , PXF.DMC_START_DT         )      As DMC_START_DT           ,
  Coalesce(PXF_DMC.DMC_POSTAL_CD        , PXF.DMC_POSTAL_CD        )      As DMC_POSTAL_CD          ,
  Coalesce(PXF_DMC.PAR_INSEE_NB         , PXF.PAR_INSEE_NB         )      As PAR_INSEE_NB           ,
  Coalesce(PXF_DMC.PAR_BU_CD            , PXF.PAR_BU_CD            )      As PAR_BU_CD              ,
  Coalesce(PXF_DMC.DMC_DEPRTMNT_ID      , PXF.DMC_DEPRTMNT_ID      )      As DMC_DEPRTMNT_ID        ,
  Coalesce(PXF_DMC.PAR_GEO_MACROZONE    , PXF.PAR_GEO_MACROZONE    )      As PAR_GEO_MACROZONE      ,
  Coalesce(PXF_DMC.PAR_UNIFIED_PARTY_ID , PXF.PAR_UNIFIED_PARTY_ID )      As PAR_UNIFIED_PARTY_ID   ,
  Coalesce(PXF_DMC.PAR_PARTY_REGRPMNT_ID, PXF.PAR_PARTY_REGRPMNT_ID)      As PAR_PARTY_REGRPMNT_ID  ,
  Coalesce(PXF_DMC.PAR_IRIS2000_CD      , PXF.PAR_IRIS2000_CD      )      As PAR_IRIS2000_CD        ,
  Coalesce(PXF_DMC.PAR_CID_ID           , PXF.PAR_CID_ID           )      As PAR_CID_ID             ,
  Coalesce(PXF_DMC.PAR_PID_ID           , PXF.PAR_PID_ID           )      As PAR_PID_ID             ,
  Coalesce(PXF_DMC.PAR_FIRST_IN         , PXF.PAR_FIRST_IN         )      As PAR_FIRST_IN           ,
  Coalesce(PXF_DMC.PAR_FIBER_IN         , PXF.PAR_FIBER_IN         )      As PAR_FIBER_IN           ,
  -- Axe Organisation
  PXF.ORG_AGENT_ID                                                        As ORG_AGENT_ID           ,
  Case
    When CUID_OBK.AGENT_ID is Null
      Then '0'
    When CUID_OBK.AGENT_IOBSP_LEVEL_ID = 'IOBSP3'
      Then '3'
    Else   '2'
  End                                                                     As ORG_AGENT_IOBSP        ,
  PXF.EXTRNL_TYPE_AGENCE                                                  As EXTRNL_TYPE_AGENCE     ,
  PXF.EXTRNL_EDO_ID                                                       As EXTRNL_EDO_ID          ,
  Coalesce(PXF_O3.ORG_EDO_ID          , PXF.ORG_EDO_ID          )         As ORG_EDO_ID             ,
  Coalesce(PXF_O3.ORG_EDO_IOBSP       , PXF.ORG_EDO_IOBSP       )         As ORG_EDO_IOBSP          ,
  Coalesce(PXF_O3.ORG_TYPE_CD         , PXF.ORG_TYPE_CD         )         As ORG_TYPE_CD            ,
  Coalesce(PXF_O3.ORG_TYPE_EDO        , PXF.ORG_TYPE_EDO        )         As ORG_TYPE_EDO           ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_1_CD, PXF.WORK_TEAM_LEVEL_1_CD)         As WORK_TEAM_LEVEL_1_CD   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_1_DS, PXF.WORK_TEAM_LEVEL_1_DS)         As WORK_TEAM_LEVEL_1_DS   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_2_CD, PXF.WORK_TEAM_LEVEL_2_CD)         As WORK_TEAM_LEVEL_2_CD   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_2_DS, PXF.WORK_TEAM_LEVEL_2_DS)         As WORK_TEAM_LEVEL_2_DS   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_3_CD, PXF.WORK_TEAM_LEVEL_3_CD)         As WORK_TEAM_LEVEL_3_CD   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_3_DS, PXF.WORK_TEAM_LEVEL_3_DS)         As WORK_TEAM_LEVEL_3_DS   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_4_CD, PXF.WORK_TEAM_LEVEL_4_CD)         As WORK_TEAM_LEVEL_4_CD   ,
  Coalesce(PXF_O3.WORK_TEAM_LEVEL_4_DS, PXF.WORK_TEAM_LEVEL_4_DS)         As WORK_TEAM_LEVEL_4_DS   ,
  -- Axe Canal
  Coalesce(PXF_CH.ORG_CHANNEL_CD        , PXF.ORG_CHANNEL_CD        )     As ORG_CHANNEL_CD         ,
  Coalesce(PXF_CH.ORG_SUB_CHANNEL_CD    , PXF.ORG_SUB_CHANNEL_CD    )     As ORG_SUB_CHANNEL_CD     ,
  Coalesce(PXF_CH.ORG_SUB_SUB_CHANNEL_CD, PXF.ORG_SUB_SUB_CHANNEL_CD)     As ORG_SUB_SUB_CHANNEL_CD ,
  Coalesce(PXF_CH.ORG_REM_CHANNEL_CD    , PXF.ORG_REM_CHANNEL_CD    )     As ORG_REM_CHANNEL_CD     ,
  Coalesce(PXF_CH.ORG_GT_ACTIVITY       , PXF.ORG_GT_ACTIVITY       )     As ORG_GT_ACTIVITY        ,
  Coalesce(PXF_CH.ORG_WEB_ACTIVITY      , PXF.ORG_WEB_ACTIVITY      )     As ORG_WEB_ACTIVITY       ,
  Coalesce(PXF_CH.ORG_AUTO_ACTIVITY     , PXF.ORG_AUTO_ACTIVITY     )     As ORG_AUTO_ACTIVITY      ,
  Coalesce(PXF_CH.UNIFIED_SHOP_CD       , PXF.UNIFIED_SHOP_CD       )     As UNIFIED_SHOP_CD        ,
  -- Champs Techniques 
  PXF.CREATION_TS                                                         As CREATION_TS            ,
  PXF.LAST_MODIF_TS                                                       As LAST_MODIF_TS          ,
  PXF.FRESH_IN                                                            As FRESH_IN               ,
  PXF.COHERENCE_IN                                                        As COHERENCE_IN               

  From
  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_EXTR PXF
  --Enrichissement  O3
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_O3 PXF_O3
    On    PXF.ACTE_ID          = PXF_O3.ACTE_ID
      And PXF.ORDER_DEPOSIT_DT = PXF_O3.ORDER_DEPOSIT_DT 
  --Enrichissement  Channel
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_CHANNEL PXF_CH
    On    PXF.ACTE_ID          = PXF_CH.ACTE_ID
      And PXF.ORDER_DEPOSIT_DT = PXF_CH.ORDER_DEPOSIT_DT 
  --Enrichissement  DMC
  Left Outer Join  ${KNB_PCO_TMP}.ORD_W_PLACEMENT_PXF_DMC PXF_DMC
    On    PXF.ACTE_ID          = PXF_DMC.ACTE_ID
      And PXF.ORDER_DEPOSIT_DT = PXF_DMC.ORDER_DEPOSIT_DT 
  --Enrichissement  AGENT IOBSP
  Left Outer Join  ${KNB_OBK_SOC_V}.BNK_R_AGENT CUID_OBK
    On    PXF.ORG_AGENT_ID=CUID_OBK.AGENT_ID
      And PXF.ORDER_DEPOSIT_DT  >= CUID_OBK.HABILL_BEGIN_DT
      And PXF.ORDER_DEPOSIT_DT   < Coalesce (CUID_OBK.CLOSURE_DT, Cast ('31/12/2999' as date format 'DD/MM/YYYY'))
Where
  (1=1)
 Qualify Row_number() over (Partition By PXF.ACTE_ID,PXF.ORDER_DEPOSIT_DT Order By PXF.ORDER_DEPOSIT_TS asc)=1  
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ORD_T_PLACEMENT_PXF;
.if errorcode <> 0 then .quit 1

.quit 0





