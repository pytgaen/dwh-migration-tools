-----------------------------------------------------------------------------------------
-- $HEADER: %HEADER%
-----------------------------------------------------------------------------------------
-- NOM FICHIER  : $Workfile:  FCT_PCO_Ge_Fresh_FromMirror.sql $                          -
-- TYPE         : Script SQL                                                            -
-- DESCRIPTION  : Récuperation de la derniere fraicheur integrée pour un Miroir         -
-----------------------------------------------------------------------------------------
--                 HISTORIQUE                                                           -
-- DATE            AUTEUR      CREATION/MODIFICATION                                    -
-- 00/00/00        XXX         Creation                                                 -
-- 10/01/14        AID         Modification mise ne norme DSM                           -
-----------------------------------------------------------------------------------------
.set width 250;

SELECT
'export FRESH_TS="' ||
TRIM(CAST(
COALESCE(MAX(FRESH_TS),CAST('${KNB_PCO_DEFAULT_T0}' AS TIMESTAMP(0))) 
AS CHAR(19)))||'"'
(TITLE'')
FROM 
${KNB_SRC_MIRROR_NM}
;

.if errorcode <> 0 then .quit 1
