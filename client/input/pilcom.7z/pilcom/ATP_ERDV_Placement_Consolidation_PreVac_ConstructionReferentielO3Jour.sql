-- $HEADER:   %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERDV_Placement_Consolidation_PreVac_ConstructionReferentielO3Jour.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de construction du référentiel O3 pour ERDV
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 27/12/2013      YZH         Creation
-- 29/04/2015      YZH         Modif: rajout flags SCH/AD
-- 02/07/2015       GMA         Modification Pour ajouter le Delete Insert En MS
-- 02/03/2016      TPI         QC 1072 : Modification paramètres
--------------------------------------------------------------------------------

.set width 2500;




----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                        ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.CAT_W_ERDV_REF_O3
;Insert Into ${KNB_PCO_TMP}.CAT_W_ERDV_REF_O3
(
  EDO_ID              ,
  EXTNL_VAL_COD_CD    ,
  TYPE_EDO            ,
  FLAG_PLT_CONV       ,
  FLAG_PLT_SCH        ,
  FLAG_PLT_AD         ,
  FLAG_PLT_PRO        ,
  NETWRK_TYP_EDO_ID   ,
  FLAG_TYPE_GEO       ,
  FLAG_TYPE_CPT_NTK   ,
  FLAG_TYPE_PTN_NTK   ,
  START_EXTNL_VAL_DT  ,
  END_EXTNL_VAL_DT
)
Select
  RefEdo.EDO_ID                                                                                   AS EDO_ID                   ,
  RefPdv.EXTNL_VAL_COD_CD                                                                         AS EXTNL_VAL_COD_CD         ,
  Case When RefEdo.NETWRK_TYP_EDO_ID = 'FT' 
    Then  '${P_PIL_235}'  --"INT""
  Else    '${P_PIL_236}'  --"EXT"
  End                                                                                             AS TYPE_EDO                 ,
  Case When RefEdoConv.EDO_ID Is Not Null
    Then  1  -- plateau convergent
  Else    0
  End                                                                                             AS FLAG_PLT_CONV            , 
  Case  When RefEdoAVSC.EDO_ID Is Not Null
                Then  1
              Else    0
  End                                                                                             AS FLAG_PLT_SCH             ,
     --On verifie si le plateau travail sur du AD
  Case  When RefEdoAD.EDO_ID Is Not Null
          Then  1 --Si on trouve une correspondance alors c'est un plateau AD
        Else    0
  End                                                                                             AS FLAG_PLT_AD              ,
  Case  When RefEdoPRO.EDO_ID Is Not Null
          Then  1 --Si on trouve une correspondance alors c'est un plateau PRO
        Else    0
  End                                                                                             AS FLAG_PLT_PRO             ,    
  RefEdo.NETWRK_TYP_EDO_ID                                                                        AS NETWRK_TYP_EDO_ID        ,
  RefEdoDOM.AXS_CLSSF_ID                                                                          AS FLAG_TYPE_GEO            ,
  RefEdoCompNetwork.AXS_CLSSF_ID                                                                  AS FLAG_TYPE_CPT_NTK        ,
  Case When RefEdoPartNetwork.AXS_CLSSF_ID in ('MOBI', 'GSS') 
       Then  'Mobistore'
       When RefEdoPartNetwork.AXS_CLSSF_ID in ('PSE' , 'PST')
       Then  'GDT'
  End                                                                                             AS FLAG_TYPE_PTN_NTK        ,
  RefPdv.START_EXTNL_VAL_DT                                                                       AS START_EXTNL_VAL_DT       ,
  Coalesce(RefPdv.END_EXTNL_VAL_DT, cast('9999-12-31' as date format 'YYYY-MM-DD'))               AS END_EXTNL_VAL_DT
From
    ${KNB_SOC_O3}.V_ORG_F_EXTNL_VAL_COD_EDO RefPdv -- table EDO
Left outer join               -- Sous-quete pour avoir les EDO convergents
(
    Select EDO_ID
    From
      ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
      Inner Join ${KNB_SOC_O3}.V_ORG_R_VAL_AXS_CLSSF ClassAx
        On    EdoAx.VAL_AXS_CLSSF_ID  = ClassAx.AXS_CLSSF_ID
          And ClassAx.FRESH_IN        = 1
          And ClassAx.CURRENT_IN      = 1
          And ClassAx.CLOSURE_DT      Is Null
    Where
      (1=1)
      And ClassAx.NAME_CLSSF_DS   In (${L_PIL_110}) -- 'SOSH','OPEN' 
      And EdoAx.FRESH_IN          = 1
      And EdoAx.CURRENT_IN        = 1
      And EdoAx.CLOSURE_DT        Is Null
    Group By EDO_ID
) RefEdoConv
  On  RefEdoConv.EDO_ID = RefPdv.EDO_ID
Inner Join ${KNB_SOC_O3}.V_ORG_F_EDO RefEdo -- Ref EDO
  On RefPdv.EDO_ID = RefEdo.EDO_ID
--On va dans le referentiel axs_edo pour remonter les flags GEO
Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_111}) -- 'CARAIBES','REUNION'
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoDOM
  On  RefPdv.EDO_ID   = RefEdoDOM.EDO_ID
   --On va dans le referentiel axs_edo pour remonter le flag de réseau compétitif
Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_112}) -- 'GSS','GSA','AUTRC'
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoCompNetwork
      On  RefPdv.EDO_ID   = RefEdoCompNetwork.EDO_ID
  --On va dans le referentiel axs_edo pour remonter le flag de réseau partenaire
Left Outer Join
      (
        Select
          EDO_ID                          As EDO_ID             ,
          VAL_AXS_CLSSF_ID                As AXS_CLSSF_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID      In (${L_PIL_115}) -- 'MOBI','GSS','PSE','PST'
          And EdoAx.FRESH_IN              = 1
          And EdoAx.CURRENT_IN            = 1
          And EdoAx.CLOSURE_DT            Is Null
        Qualify Row_number() Over (Partition By EDO_ID Order By AXS_CLSSF_ID Asc)=1
      ) RefEdoPartNetwork
      On  RefPdv.EDO_ID   = RefEdoPartNetwork.EDO_ID
Left Outer Join
      (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
        Select
          EDO_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_113}) -- 'GSCR','1014'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
            Group By
            EDO_ID
      ) RefEdoAVSC
      On  RefPdv.EDO_ID   = RefEdoAVSC.EDO_ID
Left Outer Join
      (
         --On applique ici la sous- requete qui permet de savoir si l'EDO est AD
        Select
          EDO_ID                      AS EDO_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
          (1=1)
          And EdoAx.VAL_AXS_CLSSF_ID   In (${L_PIL_114}) -- 'BTQ'
          And EdoAx.FRESH_IN          = 1
          And EdoAx.CURRENT_IN        = 1
          And EdoAx.CLOSURE_DT        Is Null
        Group By  EDO_ID
      ) RefEdoAD
      On  RefPdv.EDO_ID        = RefEdoAD.EDO_ID
Left Outer Join
      (
          --On applique ici la sous- requete qui permet de savoir si l'EDO appartient à un plateau AVSC (1014)
        Select
          EDO_ID
        From
          ${KNB_SOC_O3}.V_ORG_F_AXS_EDO EdoAx
        Where
            (1=1)
            And EdoAx.VAL_AXS_CLSSF_ID  in (${L_PIL_123}) -- 'GSCP','1016','ATH'
            And EdoAx.FRESH_IN          = 1
            And EdoAx.CURRENT_IN        = 1
            And EdoAx.CLOSURE_DT        Is Null
            Group By
            EDO_ID
      ) RefEdoPRO
      On  RefPdv.EDO_ID   = RefEdoPRO.EDO_ID           
-- Filtre sur Code externe='EDS' pour eRDV            
Where RefPdv.EXTNL_COD_CD ='${P_PIL_441}' 
And RefPdv.CURRENT_IN = 1
And RefPdv.CLOSURE_DT Is Null
And RefEdo.CURRENT_IN = 1
And RefEdo.CLOSURE_DT Is Null
;
.if errorcode <> 0 then .quit 1




Collect Stat On ${KNB_PCO_TMP}.CAT_W_ERDV_REF_O3;
.if errorcode <> 0 then .quit 1

.quit 0
