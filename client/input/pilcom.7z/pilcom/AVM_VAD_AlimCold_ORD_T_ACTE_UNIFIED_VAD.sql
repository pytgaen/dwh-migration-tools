--$HEADER:   %HEADER%
---------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   AVM_VAD_AlimCold_ORD_T_ACTE_UNIFIED_VAD.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : Script SQL d'alimentation des données froide de la source VAD dans la table ORD_T_ACTE_UNIFIED_VAD  
-------------------------------------------------------------------------------
--                 HISTORIQUE
--
-- DATE           AUTEUR      CREATION/MODIFICATION
-- 30/05/2013     CBR         Création
-- 26/03/2014     AID         Indus  
-- 30/07/2014     HFO         Pérennité
-- 06/11/2014     MCA         Modif: Suppression rapprochement Newshop avec VAD
-- 05/03/2015     HZO         Modif: Profondeur de recalcul 15 jours
-- 04/06/2015     OCH         MODIFICATION 
-- 16/07/2015     HFO         MODIFICATION  ajout CA pour VAD Un nvx chps = ACT_CA_LINE_AM
-- 19/12/2016     HOB         Modif VA Ajout Champs
-- 15/03/2017     HLA         Modification 
-- 16/04/2019     GRH         Modification ( Ajout Filtre sur Canal  <> Online )
-- 09/10/2019     EVI         KPI2020 : Mise en place du filtre sur les NS/NSTECH pour data enabler
-- 03/03/2020     EVI         PILCOM-310 : Modification Alimentation ORDER_CANCELING_DT 
-- 21/07/2020     EVI         PILCOM-502 : Indicateur eSim - New Champ SIM_EAN_CD
-- 08/07/2021     BCH         PILCOM-946 : Suppression des colonnes obsolètes de ORD_T_ACTE_UNIFIED_VAD
---------------------------------------------------------------------------------

.set width 5000

------------------------------------
-- Table : ORD_T_ACTE_UNIFIED_VAD --
------------------------------------

Delete From ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_VAD;
.if errorcode <> 0 then .quit 1;

Insert Into ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_VAD 
(
  ACTE_ID                       ,
  OPERATOR_PROVIDER_ID          ,
  INTRNL_SOURCE_ID              ,
  TYPE_SOURCE_ID                ,
  MASTER_ACTE_ID                ,
  MASTER_INTRNL_SOURCE_ID       ,
  MASTER_FLAG                   ,
  MASTER_NB_FOUND               ,
  CPLT_ACTE_ID                  ,
  CPLT_INTRNL_SOURCE_ID         ,
  CPLT_IN                       ,
  RULE_ID                       ,
  OFFSET_NB                     ,
  ACT_TYPE                      ,
  ORDER_EXTERNAL_ID             ,
  STATUS_CD                     ,
  ACT_UNIFIED_STATUS_CD         ,
  ACT_TS                        ,
  ACT_DT                        ,
  ACT_HH                        ,
  ACT_LAST_UPD_TS               ,
  ACT_PRODUCT_ID_PRE            ,
  ACT_SEG_COM_ID_PRE            ,
  ACT_SEG_COM_AGG_ID_PRE        ,
  ACT_CODE_MIGR_PRE             ,
  ACT_OPER_ID_PRE               ,
  ACT_PRODUCT_ID_FINAL          ,
  ACT_SEG_COM_ID_FINAL          ,
  ACT_SEG_COM_AGG_ID_FINAL      ,
  ACT_CODE_MIGR_FINAL           ,
  ACT_OPER_ID_FINAL             ,
  ACT_TYPE_SERVICE_FINAL        ,
  ACT_TYPE_COMMANDE_ID          ,
  ACT_DELTA_TARIF               ,
  ACT_CD                        ,
  ACT_REM_ID                    ,
  ACT_FLAG_ACT_REM              ,
  ACT_FLAG_PEC_PERPVC           ,
  ACT_FLAG_PVC_REM              ,
  ACT_ACTE_VALO                 ,
  ACT_ACTE_FAMILLE_KPI          ,
  ACT_PERIODE_ID                ,
  ACT_PERIODE_STATUS            ,
  ACT_PERIODE_CLOSURE_DT        ,
  ORIGIN_CD                     ,
  AGENT_ID                      ,
  AGENT_ID_UPD                  ,
  AGENT_ID_UPD_DT               ,
  AGENT_FIRST_NAME              ,
  AGENT_LAST_NAME               ,
  UNIFIED_SHOP_CD               ,
  ORG_SPE_CANAL_ID_MACRO        ,
  ORG_SPE_CANAL_ID              ,
  ORG_REM_CHANNEL_CD            ,
  ORG_CHANNEL_CD                ,
  ORG_SUB_CHANNEL_CD            ,
  ORG_SUB_SUB_CHANNEL_CD        ,
  ORG_GT_ACTIVITY               ,
  ORG_FIDELISATION              ,
  ORG_WEB_ACTIVITY              ,
  ORG_AUTO_ACTIVITY             ,
  ORG_EDO_ID                    ,
  ORG_TYPE_EDO                  ,
  ORG_FLAG_PLT_CONV             ,
  ORG_FLAG_TEAM_MKT             ,
  ORG_FLAG_TYPE_CMP             ,
  ORG_RESP_EDO_ID               ,
  ORG_RESP_TYPE_EDO             ,
  ORG_RESP_FLAG_PLT_CONV        ,
  ACTIVITY_CD                   ,
  ACTIVITY_GROUPNG_CD           ,
  AUTO_ACTIVITY_IN              ,
  ORG_TYPE_CD                   ,
  ORG_TEAM_TYPE_ID              ,
  ORG_TEAM_LEVEL_1_CD           ,
  ORG_TEAM_LEVEL_1_DS           ,
  ORG_TEAM_LEVEL_2_CD           ,
  ORG_TEAM_LEVEL_2_DS           ,
  ORG_TEAM_LEVEL_3_CD           ,
  ORG_TEAM_LEVEL_3_DS           ,
  ORG_TEAM_LEVEL_4_CD           ,
  ORG_TEAM_LEVEL_4_DS           ,
  WORK_TEAM_LEVEL_1_CD          ,
  WORK_TEAM_LEVEL_1_DS          ,
  WORK_TEAM_LEVEL_2_CD          ,
  WORK_TEAM_LEVEL_2_DS          ,
  WORK_TEAM_LEVEL_3_CD          ,
  WORK_TEAM_LEVEL_3_DS          ,
  WORK_TEAM_LEVEL_4_CD          ,
  WORK_TEAM_LEVEL_4_DS          ,
  CONFIRMATION_IN               ,
  PERNNT_IN                     ,
  PERNNT_END_DT                 ,
  PERNNT_MOTIF                  ,
  PERNNT_CALC_END_DT            ,
  MIGRA_DT                      ,
  MIGRA_NEXT_OFFRE              ,
  PRES_SEGMENT_IN_PARK_BEFORE_IN,
  SEGMENT_DELIVERY_IN_PARK_DT   ,
  ORDER_CANCELING_DT            ,
  LINE_ID                       ,
  MASTER_LINE_ID                ,
  CUST_TYPE_CD                  ,
  MSISDN_ID                     ,
  NDS_VALUE_DS                  ,
  EXTERNAL_PARTY_ID             ,
  RES_VALUE_DS                  ,
  PAR_ACCES_SERVICE             ,
  TAC_CD                        ,
  IMEI_CD                       ,
  IMSI_CD                       ,
  HOM_START_DT                  ,
  MOB_START_DT                  ,
  I_SCORE_VALUE                 ,
  I_SCORE_TRESHOLD              ,
  I_SCORE_IN                    ,
  M_SCORE_VALUE                 ,
  M_SCORE_TRESHOLD              ,
  M_SCORE_IN                    ,
  OSCAR_VALUE                   ,
  CUST_BU_TYPE_CD               ,
  CUST_BU_CD                    ,
  ADDRESS_TYPE                  ,
  ADDRESS_CONCAT_NM             ,
  POSTAL_CD                     ,
  INSEE_CD                      ,
  BU_CD                         ,
  DEPARTMNT_ID                  ,
  ACT_CA_LINE_AM                ,
  PAR_GEO_MACROZONE             ,
  PAR_UNIFIED_PARTY_ID          ,
  PAR_PARTY_REGRPMNT_ID         ,
  PAR_CID_ID                    ,
  PAR_PID_ID                    ,
  PAR_FIRST_IN                  ,
  ORG_AGENT_IOBSP               ,
  ORG_EDO_IOBSP                 ,
  PAR_IRIS2000_CD               ,
  EAN_CD                        ,
  SIM_CD                        ,
  SIM_EAN_CD                    ,
  ORG_RESP_ID                   ,
  CHECK_INITIAL_STATUS_CD       ,
  CHECK_NAT_STATUS_CD           ,
  CHECK_NAT_COMMENT             ,
  CHECK_NAT_STATUS_LN           ,
  CHECK_LOC_STATUS_CD           ,
  CHECK_LOC_COMMENT             ,
  CHECK_LOC_STATUS_LN           ,
  CHECK_VALIDT_DT               ,
  ACT_END_UNIFIED_DT            ,
  ACT_END_UNIFIED_DS            ,
  ACT_CLOSURE_DT                ,
  ACT_CLOSURE_DS                ,
  HOT_IN                        ,
  RUN_ID                        ,
  CREATION_TS                   ,
  LAST_MODIF_TS                 ,
  FRESH_IN                      ,
  COHERENCE_IN                   
)
Select
  VAD.ACTE_ID_GEN                                                          As ACTE_ID                         ,
  VAD.OPERATOR_PROVIDER_ID                                                 As OPERATOR_PROVIDER_ID            ,
  VAD.INTRNL_SOURCE_ID                                                     As INTRNL_SOURCE_ID                ,
  '${P_PIL_368}'                                                           As TYPE_SOURCE_ID                  ,
  VAD.ACTE_ID_GEN                                                          As MASTER_ACTE_ID                  ,
  VAD.INTRNL_SOURCE_ID                                                     As MASTER_INTRNL_SOURCE_ID         ,
  ${P_PIL_354}                                                             As MASTER_FLAG                     ,
  ${P_PIL_375}                                                             As MASTER_NB_FOUND                 ,
  VAD.CPLT_ACTE_ID                                                         As CPLT_ACTE_ID                    ,
  VAD.CPLT_INTRL_SOURCE_ID                                                 As CPLT_INTRNL_SOURCE_ID           ,
  Case  When VAD.CPLT_ACTE_ID Is Not Null
          Then  'O'
        Else    'N'
  End                                                                      As CPLT_IN                         ,
  '${P_PIL_362}'                                                           As RULE_ID                         ,
  Null                                                                     As OFFSET_NB                       ,
  '${P_PIL_325}'                                                           As ACT_TYPE                        ,
  VAD.ORDER_EXTERNAL_ID                                                    As ORDER_EXTERNAL_ID               ,
  VAD.ORDER_STATUT_CD                                                      As STATUS_CD                       ,
  Case When VAD.CONCURENCE_IN = '${P_PIL_356}' Then '${P_PIL_385}'
       When VAD.CONFIRMATION_IN = '${P_PIL_357}' Then '${P_PIL_386}' 
       When VAD.PERENNITE_IN = '${P_PIL_356}' Then '${P_PIL_384}' 
       When VAD.DELIVERY_IN = '${P_PIL_356}' And VAD.PERENNITE_IN = '${P_PIL_357}' Then '${P_PIL_387}' 
       When VAD.DELIVERY_IN = '${P_PIL_356}' Then '${P_PIL_383}' 
       When VAD.CONFIRMATION_IN = '${P_PIL_356}' Then '${P_PIL_382}'
       Else '${P_PIL_381}'
  End                                                                      As ACT_UNIFIED_STATUS_CD           ,
  VAD.ORDER_DEPOSIT_TS                                                     As ACT_TS                          ,
  VAD.ORDER_DEPOSIT_DT                                                     As ACT_DT                          ,
  Extract(HOUR From VAD.ORDER_DEPOSIT_TS)                                  As ACT_HH                          ,
  VAD.ORDER_LAST_STATUT_MODIF_TS                                           As ACT_LAST_UPD_TS                 ,
  VAD.ACT_PRODUCT_ID_PRE                                                   As ACT_PRODUCT_ID_PRE              ,
  VAD.ACT_SEG_COM_ID_PRE                                                   As ACT_SEG_COM_ID_PRE              ,
  VAD.ACT_SEG_COM_AGG_ID_PRE                                               As ACT_SEG_COM_AGG_ID_PRE          ,
  VAD.ACT_CODE_MIGR_PRE                                                    As ACT_CODE_MIGR_PRE               ,
  VAD.ACT_OPER_ID_PRE                                                      As ACT_OPER_ID_PRE                 ,
  VAD.ACT_PRODUCT_ID_FINAL                                                 As ACT_PRODUCT_ID_FINAL            ,
  VAD.ACT_SEG_COM_ID_FINAL                                                 As ACT_SEG_COM_ID_FINAL            ,
  VAD.ACT_SEG_COM_AGG_ID_FINAL                                             As ACT_SEG_COM_AGG_ID_FINAL        ,
  VAD.ACT_CODE_MIGR_FINAL                                                  As ACT_CODE_MIGR_FINAL             ,
  -- Dans VAD on a que des acquisitions
  'ADD'                                                                    As ACT_OPER_ID_FINAL               ,
  VAD.ACT_TYPE_SERVICE_FINAL                                               As ACT_TYPE_SERVICE_FINAL          ,
  VAD.ACT_TYPE_COMMANDE_ID                                                 As ACT_TYPE_COMMANDE_ID            ,
  VAD.ACT_DELTA_TARIF                                                      As ACT_DELTA_TARIF                 ,
  VAD.ACT_CD                                                               As ACT_CD                          ,
  VAD.ACT_REM_ID                                                           As ACT_REM_ID                      ,
  VAD.ACT_FLAG_ACT_REM                                                     As ACT_FLAG_ACT_REM                ,
  VAD.ACT_FLAG_PEC_PERPVC                                                  As ACT_FLAG_PEC_PERPVC             ,
  --On Calcul si on doit envoyer ou pas l'acte à PVC
  Case  When  (   --Condition d'éligibilité
                    (1=1)
                    -- L'acte doit être rémunérable
                    And VAD.ACT_FLAG_ACT_REM = 'O'
                    -- L'acte doit avoir un conseiller
                    And VAD.ORG_AGENT_ID_UPD Is Not Null
                    --L'acte doit avoir un Canal de REM éligible PVC (CCO / SCH)
                    And VAD.ORG_REM_CHANNEL_CD IN (${L_PIL_043}) 
                    --L'acte ne doit pas être annulé
                    And VAD.CLOSURE_DT              Is Null
                )
        Then 'O' 
       Else 'N'  
  End                                                                      As ACT_FLAG_PVC_REM                ,
  VAD.ACT_ACTE_VALO                                                        As ACT_ACTE_VALO                   ,
  VAD.ACT_ACTE_FAMILLE_KPI                                                 As ACT_ACTE_FAMILLE_KPI            ,
  VAD.ACT_PERIODE_ID                                                       As ACT_PERIODE_ID                  ,
  VAD.ACT_PERIODE_STATUS                                                   As ACT_PERIODE_STATUS              ,
  VAD.ACT_PERIODE_CLOSURE_DT                                               As ACT_PERIODE_CLOSURE_DT          ,
  VAD.ORIG_DEM                                                             As ORIGIN_CD                       ,
  trim(VAD.ORG_AGENT_ID )                                                  As AGENT_ID                        ,
  trim(VAD.ORG_AGENT_ID_UPD )                                              As AGENT_ID_UPD                    ,
  VAD.ORG_AGENT_ID_UPD_DT                                                  As AGENT_ID_UPD_DT                 ,
  VAD.ORG_AGENT_FIRST_NAME                                                 As AGENT_FIRST_NAME                ,
  VAD.ORG_AGENT_LAST_NAME                                                  As AGENT_LAST_NAME                 ,
  VAD.ORG_STORE_NAME                                                       As UNIFIED_SHOP_CD                 ,
  VAD.ORG_CANAL_ID_MACRO                                                   As ORG_SPE_CANAL_ID_MACRO          ,
  VAD.ORG_CANAL_ID                                                         As ORG_SPE_CANAL_ID                ,
  VAD.ORG_REM_CHANNEL_CD                                                   As ORG_REM_CHANNEL_CD              ,
  VAD.ORG_CHANNEL_CD                                                       As ORG_CHANNEL_CD                  ,
  VAD.ORG_SUB_CHANNEL_CD                                                   As ORG_SUB_CHANNEL_CD              ,
  VAD.ORG_SUB_SUB_CHANNEL_CD                                               As ORG_SUB_SUB_CHANNEL_CD          ,
  VAD.ORG_GT_ACTIVITY                                                      As ORG_GT_ACTIVITY                 ,
  VAD.ORG_FIDELISATION                                                     As ORG_FIDELISATION                ,
  VAD.ORG_WEB_ACTIVITY                                                     As ORG_WEB_ACTIVITY                ,
  VAD.ORG_AUTO_ACTIVITY                                                    As ORG_AUTO_ACTIVITY               ,
  VAD.ORG_EDO_ID                                                           As ORG_EDO_ID                      ,
  VAD.ORG_TYPE_EDO                                                         As ORG_TYPE_EDO                    ,
  VAD.ORG_FLAG_PLT_CONV                                                    As ORG_FLAG_PLT_CONV               ,
  VAD.ORG_FLAG_TEAM_MKT                                                    As ORG_FLAG_TEAM_MKT               ,
  VAD.ORG_FLAG_TYPE_CMP                                                    As ORG_FLAG_TYPE_CMP               ,
  Null                                                                     As ORG_RESP_EDO_ID                 ,
  Null                                                                     As ORG_RESP_TYPE_EDO               ,
  Null                                                                     As ORG_RESP_FLAG_PLT_CONV          ,
  Null                                                                     As ACTIVITY_CD                     ,
  Null                                                                     As ACTIVITY_GROUPNG_CD             ,
  Null                                                                     As AUTO_ACTIVITY_IN                ,
  '${P_PIL_366}'                                                           As ORG_TYPE_CD                     ,
  Null                                                                     As ORG_TEAM_TYPE_ID                ,
  Null                                                                     As ORG_TEAM_LEVEL_1_CD             ,
  Null                                                                     As ORG_TEAM_LEVEL_1_DS             ,
  Null                                                                     As ORG_TEAM_LEVEL_2_CD             ,
  Null                                                                     As ORG_TEAM_LEVEL_2_DS             ,
  Null                                                                     As ORG_TEAM_LEVEL_3_CD             ,
  Null                                                                     As ORG_TEAM_LEVEL_3_DS             ,
  Null                                                                     As ORG_TEAM_LEVEL_4_CD             ,
  Null                                                                     As ORG_TEAM_LEVEL_4_DS             ,
  VAD.WORK_TEAM_LEVEL_1_CD                                                 As WORK_TEAM_LEVEL_1_CD            ,
  VAD.WORK_TEAM_LEVEL_1_DS                                                 As WORK_TEAM_LEVEL_1_DS            ,
  VAD.WORK_TEAM_LEVEL_2_CD                                                 As WORK_TEAM_LEVEL_2_CD            ,
  VAD.WORK_TEAM_LEVEL_2_DS                                                 As WORK_TEAM_LEVEL_2_DS            ,
  VAD.WORK_TEAM_LEVEL_3_CD                                                 As WORK_TEAM_LEVEL_3_CD            ,
  VAD.WORK_TEAM_LEVEL_3_DS                                                 As WORK_TEAM_LEVEL_3_DS            ,
  VAD.WORK_TEAM_LEVEL_4_CD                                                 As WORK_TEAM_LEVEL_4_CD            ,
  VAD.WORK_TEAM_LEVEL_4_DS                                                 As WORK_TEAM_LEVEL_4_DS            ,
  VAD.CONFIRMATION_IN                                                      As CONFIRMATION_IN                 ,
  --Flag perennité
  Case  When VAD.ACT_FLAG_PEC_PERPVC = 'N'
          Then  'O' --Si le flag est à Non alors on force la perennité à Oui
        Else    VAD.PERNNT_IN
  End                                                                      As PERNNT_IN                       ,
  Case  When VAD.ACT_FLAG_PEC_PERPVC <> 'N'
          Then   VAD.PERNNT_END_DT 
        Else    null
  End                                                                      As PERNNT_END_DT                   ,
    Case  When VAD.ACT_FLAG_PEC_PERPVC <> 'N'
          Then   VAD.PERNNT_MOTIF 
        Else    null
  End                                                                      As PERNNT_MOTIF                    ,
  VAD.PERNNT_CALC_END_DT                                                   As PERNNT_CALC_END_DT              ,
  VAD.MIGRA_DT                                                             As MIGRA_DT                        ,
  VAD.MIGRA_NEXT_OFFRE                                                     As MIGRA_NEXT_OFFRE                ,
  --Dans le cas de VAD on a tjs c'est un nouveau client donc il n'y a pas de parc avant
  0                                                                        As PRES_SEGMENT_IN_PARK_BEFORE_IN  ,
  Case  When  (VAD.ORDER_DEPOSIT_DT + VAD.DELIVERY_DEAD_LINE_NU) >= VAD.SEG_FIND_LIVR_DT
          Then VAD.SEG_FIND_LIVR_DT 
        Else Null
  End                                                                      As SEGMENT_DELIVERY_IN_PARK_DT     ,
  PPROD.STATUT_ANNUL                                                       As ORDER_CANCELING_DT              ,
  VAD.DMC_LINE_ID                                                          As LINE_ID                         ,
  VAD.DMC_MASTER_LINE_ID                                                   As MASTER_LINE_ID                  ,
  VAD.PAR_TYPE                                                             As CUST_TYPE_CD                    ,
  Coalesce(VAD.PAR_ADV_DOSSIER_NU, '0000000000')                           As MSISDN_ID                       ,
  Coalesce(VAD.PAR_ND, '0000000000')                                       As NDS_VALUE_DS                    ,
  Coalesce(VAD.PAR_ADV_CLIENT_NU, '0000000000')                            As EXTERNAL_PARTY_ID               ,
  VAD.PAR_EXTERNAL_PARTY_BSS_ID                                            As RES_VALUE_DS                    ,
  VAD.PAR_ACCES_SERVICE                                                    As PAR_ACCES_SERVICE               ,
  VAD.PAR_MOB_TAC                                                          As TAC_CD                          ,
  VAD.PAR_MOB_IMEI                                                         As IMEI_CD                         ,
  VAD.PAR_IMSI                                                             As IMSI_CD                         ,
  Null                                                                     As HOM_START_DT                    ,
  Null                                                                     As MOB_START_DT                    ,
  Null                                                                     As I_SCORE_VALUE                   ,
  Null                                                                     As I_SCORE_TRESHOLD                ,
  Null                                                                     As I_SCORE_IN                      ,
  VAD.PAR_SCORE_NU                                                         As M_SCORE_VALUE                   ,
  Case
    When VAD.PAR_TRESHOLD_NU > 100 Then -1
    Else VAD.PAR_TRESHOLD_NU        
  End                                                                      As M_SCORE_TRESHOLD                ,
    VAD.PAR_SCORE_IN                                                       As M_SCORE_IN                      ,
  Cast(Case When VAD.OTO_OSCAR_VALUE_NU = 'SC' Then -1
            Else VAD.OTO_OSCAR_VALUE_NU
  End As BYTEINT)                                                          As OSCAR_VALUE                     ,
  '${P_PIL_376}'                                                           As CUST_BU_TYPE_CD                 ,
  VAD.PAR_USCM                                                             As CUST_BU_CD                      ,
  '${P_PIL_373}'                                                           As ADDRESS_TYPE                    ,
  Trim(
    Trim(Coalesce(Case When VAD.PAR_BILL_ADRESS_1 = 'null' Then Null Else VAD.PAR_BILL_ADRESS_1 End,'')) || ' ' || 
    Trim(Coalesce(Case When VAD.PAR_BILL_ADRESS_2 = 'null' Then Null Else VAD.PAR_BILL_ADRESS_2 End,'')) || ' ' || 
    Trim(Coalesce(Case When VAD.PAR_BILL_ADRESS_3 = 'null' Then Null Else VAD.PAR_BILL_ADRESS_3 End,'')) || ' ' ||
    Trim(Coalesce(Case When VAD.PAR_BILL_ADRESS_4 = 'null' Then Null Else VAD.PAR_BILL_ADRESS_4 End,'')) || ' ' || 
    Trim(Coalesce(VAD.PAR_BILL_CD_POSTAL,'')) || ' ' || 
    Trim(Coalesce(VAD.PAR_BILL_VILLE,'')) 
  )                                                                        As ADDRESS_CONCAT_NM               ,
  Coalesce(VAD.PAR_POSTAL_CD,VAD.PAR_BILL_CD_POSTAL )                      As POSTAL_CD                       ,
  Coalesce(VAD.PAR_INSEE_CD,VAD.INSEE_CD )                                 As INSEE_CD                        ,
  VAD.PAR_BU_CD                                                            As BU_CD                           ,
  Coalesce(VAD.PAR_DEPARTMNT_ID,VAD.PAR_DO )                               As DEPARTMNT_ID                    ,
  VAD.ACT_DELTA_TARIF                                                      As ACT_CA_LINE_AM                  ,
  VAD.PAR_GEO_MACROZONE	                                                   As PAR_GEO_MACROZONE               ,
  VAD.PAR_UNIFIED_PARTY_ID                                                 As PAR_UNIFIED_PARTY_ID            ,
  VAD.PAR_PARTY_REGRPMNT_ID                                                As PAR_PARTY_REGRPMNT_ID           ,
  VAD.PAR_CID_ID                                                           As PAR_CID_ID                      ,
  VAD.PAR_PID_ID                                                           As PAR_PID_ID                      ,
  VAD.PAR_FIRST_IN                                                         As PAR_FIRST_IN                    ,
  VAD.ORG_AGENT_IOBSP                                                      As ORG_AGENT_IOBSP                 ,
  VAD.ORG_EDO_IOBSP                                                        As ORG_EDO_IOBSP                   ,
  VAD.PAR_IRIS2000_CD                                                      As PAR_IRIS2000_CD                 ,
  PPROD.EAN_FTT                                                            As EAN_CD                          ,
  VAD.PAR_MOB_SIM                                                          As SIM_CD                          ,
  Null                                                                     As SIM_EAN_CD                      ,
  VAD.ORG_RESP_AGENT_ID                                                    As ORG_RESP_ID                     ,
  VAD.CHECK_INITIAL_STATUS_CD                                              As CHECK_INITIAL_STATUS_CD         ,
  VAD.CHECK_NAT_STATUS_CD                                                  As CHECK_NAT_STATUS_CD             ,
  VAD.CHECK_NAT_COMMENT                                                    As CHECK_NAT_COMMENT               ,
  VAD.CHECK_NAT_STATUS_LN                                                  As CHECK_NAT_STATUS_LN             ,
  VAD.CHECK_LOC_STATUS_CD                                                  As CHECK_LOC_STATUS_CD             ,
  VAD.CHECK_LOC_COMMENT                                                    As CHECK_LOC_COMMENT               ,
  VAD.CHECK_LOC_STATUS_LN                                                  As CHECK_LOC_STATUS_LN             ,
  VAD.CHECK_VALIDT_DT                                                      As CHECK_VALIDT_DT                 ,
  Null                                                                     As ACT_END_UNIFIED_DT              ,
  Null                                                                     As ACT_END_UNIFIED_DS              ,
  VAD.CLOSURE_DT                                                           As ACT_CLOSURE_DT                  ,
  Case When VAD.CLOSURE_DT Is Not Null
       Then 'Acte Clos'        
  End                                                                      As ACT_CLOSURE_DS                  ,
  0                                                                        As HOT_IN                          ,
  Null                                                                     As RUN_ID                          ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As CREATION_TS                     ,
  Cast('${KNB_BATCH_DATE}' AS TIMESTAMP(0))                                As LAST_MODIF_TS                   ,
  1                                                                        As FRESH_IN                        ,
  0                                                                        As COHERENCE_IN                    
From ${KNB_PCO_VM}.V_ORD_F_ACTE_VAD As VAD 
Left Outer Join ${KNB_PCO_SOC}.V_COM_F_PLACEMENT_VAD PPROD
    On VAD.ACTE_ID = PPROD.ACTE_ID 
Where (1=1) 
  And Substr(VAD.ACT_CD,1,3) Not In (${L_PIL_036}) 
  And VAD.ACT_SEG_COM_ID_FINAL <> '${P_PIL_295}' 
  And VAD.ACT_CD <> '${P_PIL_067}' 
  And VAD.ACT_ACTE_FAMILLE_KPI Not In (${L_PIL_626}) -- NS, NSTECH
  And VAD.ACT_PERIODE_ID > 12
  And VAD.ORDER_DEPOSIT_DT >= Current_date - 250
  And VAD.ORG_CHANNEL_CD Not In ('Online','DNU')
  And ((VAD.LAST_MODIF_TS >  '${KNB_PILCOM_EXTRACT_BORNE_INF}' And VAD.LAST_MODIF_TS <= '${KNB_PILCOM_EXTRACT_BORNE_MAX}') Or VAD.ORDER_DEPOSIT_DT > Current_date - 15)
;
.if errorcode <> 0 then .quit 1;

Collect Stats On ${KNB_PCO_TMP}.ORD_T_ACTE_UNIFIED_VAD;
.if errorcode <> 0 then .quit 1;


