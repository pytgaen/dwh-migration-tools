-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_ERC_Miroir_ORD_T_ORDER_ERC.sql  $
-- TYPE         : Script SQL
-- DESCRIPTION  : SQL de chargement Tmp Miroir 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 19/01/2015      YZH         Modification: Alim ORD_T_ORDER_ERC (FA_4804)
--------------------------------------------------------------------------------

.set width 2500;


----------------------------------------------------------------*/
-- Etape 1 : Delete de la table TMP Basc                        */
----------------------------------------------------------------*/
Delete From ${KNB_PCO_TMP}.ORD_T_ORDER_ERC All;
.if errorcode <> 0 then .quit 1


----------------------------------------------------------------*/
-- Etape 2 : Alimentation de la table TMP Basc                  */
----------------------------------------------------------------*/



INSERT INTO ${KNB_PCO_TMP}.ORD_T_ORDER_ERC
(
  REPRISE_ID                  ,
  AGENT_ID                    ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  EDO_ID                      ,
  IMEI                        ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  REPRISE_TS                  ,
  REPRISE_VAL                 ,
  PROMOTION_VAL               ,
  RECEPTION_TS                ,
  TRTMT_TS                    ,
  HOMOLOGATION_TS             ,
  HOMOLOGATION_CD             ,
  POST_TRTMT_VAL              ,
  AJUSTMNT_RAISON             ,
  AJUSTMNT_VAL                ,
  ECART_RAISON                ,
  FIRST_NAME_NM               ,
  LAST_NAME_NM                ,
  MSISDN                      ,
  REPRISE_NUM                 ,
  BON_ID                      ,
  MODE_PAIEMENT               ,
  PAIEMENT_STATUT             ,
  CONSUMPTN_TS                ,
  MAX_VALIDITY_TS             ,
  CANCELLATION_TS             ,
  EQPT_CD                     ,
  BRAND_SHOP_CD               ,
  SEGMENT                     ,
  RAISON_SOCIALE              ,
  SIRET                       ,
  HOT_IN                      ,
  CREATION_TS                 ,
  LAST_MODIF_TS               ,
  FRESH_IN                    ,
  COHERENCE_IN
)
SELECT
  REPRISE_ID                  ,
  AGENT_ID                    ,
  STORE_CD                    ,
  ADV_STORE_CD                ,
  EDO_ID                      ,
  IMEI                        ,
  TERMINAL_BRAND              ,
  TERMINAL_MODEL              ,
  REPRISE_TS                  ,
  REPRISE_VAL                 ,
  PROMOTION_VAL               ,
  RECEPTION_TS                ,
  TRTMT_TS                    ,
  HOMOLOGATION_TS             ,
  HOMOLOGATION_CD             ,
  POST_TRTMT_VAL              ,
  AJUSTMNT_RAISON             ,
  AJUSTMNT_VAL                ,
  ECART_RAISON                ,
  FIRST_NAME_NM               ,
  LAST_NAME_NM                ,
  MSISDN                      ,
  REPRISE_NUM                 ,
  BON_ID                      ,
  MODE_PAIEMENT               ,
  PAIEMENT_STATUT             ,
  CONSUMPTN_TS                ,
  MAX_VALIDITY_TS             ,
  CANCELLATION_TS             ,
  EQPT_CD                     ,
  BRAND_SHOP_CD               ,
  SEGMENT                     ,
  RAISON_SOCIALE              ,
  SIRET                       ,
  0                           ,                                          
  Current_Timestamp(0)        ,                                          
  Current_Timestamp(0)        ,                                          
  1                           ,                                          
  0                                                                     
FROM 
  -- On extrait les donnees de la table ODS 
    ${KNB_PCO_TMP}.ORD_W_ORDER_ERC ODS
;
.if errorcode <> 0 then .quit 1

Collect stat on ${KNB_PCO_TMP}.ORD_T_ORDER_ERC
;
.if errorcode <> 0 then .QUIT 1

.quit 0
