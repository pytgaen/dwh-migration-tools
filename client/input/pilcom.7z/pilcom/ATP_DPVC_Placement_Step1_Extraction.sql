-- $HEADER: %HEADER%
--------------------------------------------------------------------------------
--
-- NOM FICHIER  : $Workfile:   ATP_DPVC_Placement_Step1_Extraction.sql  $
-- TYPE         : Script SQL                                                    
-- DESCRIPTION  : SQL de 
--------------------------------------------------------------------------------
--                HISTORIQUE
--
-- DATE            AUTEUR      CREATION/MODIFICATION
-- 07/07/2014      HZO         Creation
--------------------------------------------------------------------------------

.set width 2500;
----------------------------------------------------------------------------------------------
-- Etape 1 : Delete de la table TMP                                                       ----
----------------------------------------------------------------------------------------------
Delete From ${KNB_PCO_TMP}.ACT_W_PLACEMENT_DECLAR_PVC All;
.if errorcode <> 0 then .quit 1
----------------------------------------------------------------------------------------------
-- Etape 2 : Alimentation de la table TMP                                                 ----
----------------------------------------------------------------------------------------------
Insert Into ${KNB_PCO_TMP}.ACT_W_PLACEMENT_DECLAR_PVC
(
  ACTE_ID                           ,
  EXTERNAL_ACTE_ID                  ,
  INTRNL_SOURCE_ID                  ,
  PVC_ACTE_ID                       ,
  PVC_ACTE_ID_EXTERNE               ,
  ACTE_ID_CONTACTE                  ,
  ACTE_ID_DETAIL_CONTACTE           ,
  ACTE_ID_COMMANDE_REFERENCE        ,
  SOURCE_ID                         ,
  ACTE_STATUT                       ,
  ACTION_ACTE                       ,
  ORDER_DEPOSIT_DT                  ,
  ORDER_DEPOSIT_TS                  ,
  CUID                              ,
  ORDER_STATUT                      ,
  ORDER_STATUT_TS                   ,
  SELLER_LAST_NAME                  ,
  SELLER_FIRST_NAME                 ,
  SALE_CHANNEL_DLC                  ,
  SALE_CHANNEL_ORDER                ,
  CODE_PARC_CLI                     ,
  ORIGINE_DLC_DS                    ,
  CUSTOMER_TYPE                     ,
  CUSTOMER_SEG                      ,
  CUSTOMER_LAST_NAME                ,
  CUSTOMER_FIRST_NAME               ,
  CUSTOMER_SIRET                    ,
  MISISDN                           ,
  ND                                ,
  NDIP                              ,
  CUSTOMER_CAT                      ,
  CUSTOMER_AGENCE                   ,
  CUSTOMER_ZIPCODE                  ,
  VOLUME                            ,
  VALEUR                            ,
  CA                                ,
  STATUT_CSO                        ,
  STATUT_CSO_DS                     ,
  COMMENTAIRE_DS                    ,
  TEAM_DLC_DES                      ,
  TEAM_ORDER_DES                    ,
  ACT_CD                            ,
  ACT_TYPE_COMMANDE_ID              ,
  TYPE_COMMANDE_INI                 ,
  CODE_COMMANDE_FIN                 ,
  TYPE_COMMANDE_FIN                 ,
  CODE_PRODUCT_FIN                  ,
  PRODUCT_DSC_FIN                   ,
  SEGMENT_COM_FIN                   ,
  CODE_PRODUCT_INI                  ,
  PRODUCT_DSC_INI                   ,
  SEGMENT_COM_INI                   ,
  CODE_MIGR_INI                     ,
  DSC_MIGR_INI                      ,
  CODE_MIGR_FIN                     ,
  DSC_MIGR_FIN                      ,
  ID_FREGATE                        ,
  DT_CHECK_PARC                     ,
  DT_END_PARC                       ,
  END_PARC_DSC                      ,
  TAUX_PERENNITE                    ,
  DELAIS_PERENNITE                  ,
  OSCAR_VALUE                       ,
  DUREE_ENG                         ,
  IMEI                              ,
  EAN                               ,
  SIM                               ,
  ID_PARSIFAL                       ,
  MOTIF_DLC_DS                      ,
  CREATION_TS                       ,
  LAST_MODIF_TS                     ,
  FRESH_IN                          ,
  COHERENCE_IN                      ,
  RUN_ID                            
)
Select
  ActeId.ACTE_ID                                                          As ACTE_ID                            ,
  Placement.EXTERNAL_ACTE_ID                                              As EXTERNAL_ACTE_ID                   ,
  Placement.INTRNL_SOURCE_ID                                              As INTRNL_SOURCE_ID                   ,
  Placement.ACTE_ID                                                       As PVC_ACTE_ID                            ,
  Placement.ACTE_ID_EXTERNE                                               As PVC_ACTE_ID_EXTERNE                    ,
  Placement.ACTE_ID_CONTACTE                                              As ACTE_ID_CONTACTE                   ,
  Placement.ACTE_ID_DETAIL_CONTACTE                                       As ACTE_ID_DETAIL_CONTACTE            ,
  Placement.ACTE_ID_COMMANDE_REFERENCE                                    As ACTE_ID_COMMANDE_REFERENCE         ,
  Placement.SOURCE_ID                                                     As SOURCE_ID                          ,
  Placement.ACTE_STATUT                                                   As ACTE_STATUT                        ,
  Placement.ACTION_ACTE                                                   As ACTION_ACTE                        ,
  Cast(Placement.ORDER_DEPOSIT_TS As Date Format 'YYYYMMDD')              As ORDER_DEPOSIT_DT                   ,
  Placement.ORDER_DEPOSIT_TS                                              As ORDER_DEPOSIT_TS                   ,
  Placement.CUID                                                          As CUID                               ,
  Placement.ORDER_STATUT                                                  As ORDER_STATUT                       ,
  Placement.ORDER_STATUT_TS                                               As ORDER_STATUT_TS                    ,
  Placement.SELLER_LAST_NAME                                              As SELLER_LAST_NAME                   ,
  Placement.SELLER_FIRST_NAME                                             As SELLER_FIRST_NAME                  ,
  Placement.SALE_CHANNEL_DLC                                              As SALE_CHANNEL_DLC                   ,
  Placement.SALE_CHANNEL_ORDER                                            As SALE_CHANNEL_ORDER                 ,
  Placement.CODE_PARC_CLI                                                 As CODE_PARC_CLI                      ,
  Placement.ORIGINE_DLC_DS                                                As ORIGINE_DLC_DS                     ,
  Placement.CUSTOMER_TYPE                                                 As CUSTOMER_TYPE                      ,
  Placement.CUSTOMER_SEG                                                  As CUSTOMER_SEG                       ,
  Placement.CUSTOMER_LAST_NAME                                            As CUSTOMER_LAST_NAME                 ,
  Placement.CUSTOMER_FIRST_NAME                                           As CUSTOMER_FIRST_NAME                ,
  Placement.CUSTOMER_SIRET                                                As CUSTOMER_SIRET                     ,
  Placement.MISISDN                                                       As MISISDN                            ,
  Placement.ND                                                            As ND                                 ,
  Placement.NDIP                                                          As NDIP                               ,
  Placement.CUSTOMER_CAT                                                  As CUSTOMER_CAT                       ,
  Placement.CUSTOMER_AGENCE                                               As CUSTOMER_AGENCE                    ,
  Placement.CUSTOMER_ZIPCODE                                              As CUSTOMER_ZIPCODE                   ,
  Placement.VOLUME                                                        As VOLUME                             ,
  Placement.VALEUR                                                        As VALEUR                             ,
  Placement.CA                                                            As CA                                 ,
  Placement.STATUT_CSO                                                    As STATUT_CSO                         ,
  Placement.STATUT_CSO_DS                                                 As STATUT_CSO_DS                      ,
  Placement.COMMENTAIRE_DS                                                As COMMENTAIRE_DS                     ,
  Placement.TEAM_DLC_DES                                                  As TEAM_DLC_DES                       ,
  Placement.TEAM_ORDER_DES                                                As TEAM_ORDER_DES                     ,
  Placement.ACT_CD                                                        As ACT_CD                             ,
  Placement.ACT_TYPE_COMMANDE_ID                                          As ACT_TYPE_COMMANDE_ID               ,
  Placement.TYPE_COMMANDE_INI                                             As TYPE_COMMANDE_INI                  ,
  Placement.CODE_COMMANDE_FIN                                             As CODE_COMMANDE_FIN                  ,
  Placement.TYPE_COMMANDE_FIN                                             As TYPE_COMMANDE_FIN                  ,
  Placement.CODE_PRODUCT_FIN                                              As CODE_PRODUCT_FIN                   ,
  Placement.PRODUCT_DSC_FIN                                               As PRODUCT_DSC_FIN                    ,
  Placement.SEGMENT_COM_FIN                                               As SEGMENT_COM_FIN                    ,
  Placement.CODE_PRODUCT_INI                                              As CODE_PRODUCT_INI                   ,
  Placement.PRODUCT_DSC_INI                                               As PRODUCT_DSC_INI                    ,
  Placement.SEGMENT_COM_INI                                               As SEGMENT_COM_INI                    ,
  Placement.CODE_MIGR_INI                                                 As CODE_MIGR_INI                      ,
  Placement.DSC_MIGR_INI                                                  As DSC_MIGR_INI                       ,
  Placement.CODE_MIGR_FIN                                                 As CODE_MIGR_FIN                      ,
  Placement.DSC_MIGR_FIN                                                  As DSC_MIGR_FIN                       ,
  Placement.ID_FREGATE                                                    As ID_FREGATE                         ,
  Placement.DT_CHECK_PARC                                                 As DT_CHECK_PARC                      ,
  Placement.DT_END_PARC                                                   As DT_END_PARC                        ,
  Placement.END_PARC_DSC                                                  As END_PARC_DSC                       ,
  Placement.TAUX_PERENNITE                                                As TAUX_PERENNITE                     ,
  Placement.DELAIS_PERENNITE                                              As DELAIS_PERENNITE                   ,
  Placement.OSCAR_VALUE                                                   As OSCAR_VALUE                        ,
  Placement.DUREE_ENG                                                     As DUREE_ENG                          ,
  Placement.IMEI                                                          As IMEI                               ,
  Placement.EAN                                                           As EAN                                ,
  Placement.SIM                                                           As SIM                                ,
  Placement.ID_PARSIFAL                                                   As ID_PARSIFAL                        ,
  Placement.MOTIF_DLC_DS                                                  As MOTIF_DLC_DS                       ,
  Cast(Placement.FRESH_TS As Timestamp(0))                                As CREATION_TS                        ,
  Current_Timestamp(0)                                                    As LAST_MODIF_TS                      ,
  1                                                                       As FRESH_IN                           ,
  1                                                                       As COHERENCE_IN                       ,
  Null                                                                    As RUN_ID                             
From
  --On prend tout le contenu
  ${KNB_PCO_TMP}.ACT_W_DECLAR_PVC_EXT Placement
  --On jointe avec la table referentiel pour générer le bon nombre de ligne
  Inner Join ${KNB_PCO_SOC}.ACT_F_ACTE_GEN ActeId
    On    Placement.EXTERNAL_ACTE_ID          = ActeId.EXTERNAL_ACTE_ID
      And Placement.TYPE_SOURCE_ID            = ActeId.TYPE_SOURCE_ID
Where
  (1=1)
;
.if errorcode <> 0 then .quit 1

Collect Stat On ${KNB_PCO_TMP}.ACT_W_PLACEMENT_DECLAR_PVC;
.if errorcode <> 0 then .quit 1

.quit 0
